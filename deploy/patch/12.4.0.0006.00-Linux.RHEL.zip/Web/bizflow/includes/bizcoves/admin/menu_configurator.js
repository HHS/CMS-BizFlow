var _DELIMETER = "~|_";
var _menuID = 0;
var _currentMenuItemAction = null;
var _selectedMenu = null;
var _XML_HEAD = '<?xml version="1.0" encoding="utf-8" ?>';
if (! Array.prototype.remove) {
	Array.prototype.remove = function(dx) {
		if (isNaN(dx) || dx > this.length)
			return false;

		for (var i = 0, n = 0; i < this.length; i++)
			if (i != dx)
				this[n++] = this[i];

		this.length -= 1;
	};
}
if (! Array.prototype.indexOf) {
	Array.prototype.indexOf = function(object) {
		for (var i = 0; i < this.length; i++)
			if (this[i] == object)
				return i;
		return -1;
	};
}
function appendMenu(menu)
{
	var elOptNew = document.createElement('option');
	elOptNew.style.fontSize = "larger";
	elOptNew.text = menu.getName();
	elOptNew.value = menu.getMenuID();
	var elSel = document.getElementById('menuItems');

	try {
		elSel.add(elOptNew, null); // standards compliant; doesn't work in IE
	}
	catch(ex) {
		elSel.add(elOptNew); // IE only
	}
}

function getNodeText(node)
{
	return (typeof(node.text) != 'undefined')?	node.text: node.textContent;
}
function asValue(node)
{
	var str = getNodeText(node);
	if (null == str)
	{
		return "null";
	}
	else if ("true" == str || "false" == str)
	{
		return str;
	}
	else
	{
		var s = new String(str);
		s = s.replace(/\'/g,"\\'");
		s = s.replace(/&apos;/g,"\\'");
		s = s.replace(/&gt;/g,">");
		s = s.replace(/&lt;/g,"<");
		s = s.replace(/&quot;/g,"\"");
		s = s.replace(/&amp;/g,"&");

		return "'"+s+"'";
	}
}
function addChild(name, content)
{
	return element(name, content, false);
}
function element(name,content,escaping)
{
    var xml;
    if (null == content)
    {
        xml='<' + name + '/>';
    }
    else
    {
	    if ('boolean' == typeof(content))
	    {
		    content = content?"true":"false";
	    }

	    if ('undefined' == typeof(escaping) || escaping)
	    {
		    s = new String(content);
		    s = s.replace(/&/g,"&amp;");
		    s = s.replace(/\'/g,"&apos;");
		    s = s.replace(/>/g,"&gt;");
		    s = s.replace(/</g,"&lt;");
		    s = s.replace(/\"/g,"&quot;");
		    content = s;
	    }
        xml='<' + name + '>' + content + '</'+name+'>';
    }
    return xml;
}

function _copyValue(src)
{
	var target = null;
    if (null != src)
    {
	    target = new Array();
        var len = src.length;
        for (var i = 0; i < len; i++)
        {
            target[i] = src[i];
        }
    }
	return target;
}

var UserGroups = Class.create();
UserGroups.prototype =
{
	initialize: function(userGroups)
	{
		this.ids = new Array();
		this.names = new Array();

		if(null != userGroups && "undefined" != typeof(userGroups))
		{
            this.ids = _copyValue(userGroups.ids);
            this.names = _copyValue(userGroups.names);
        }
    },
	parse: function(jo)
	{
		eval('var o=' + jo);
		if('undefined'==typeof(o) || 0 == o.length)
		{
			return;
		}
		this.ids = new Array();
		this.names = new Array();
		for(var i=0; i<o.length; i++)
		{
			this.ids[this.ids.length] = o[i].TYPE + o[i].ID;
			this.names[this.names.length] = o[i].NAME;
		}
	},
	removeAll: function()
	{
		this.ids = new Array();
		this.names = new Array();
	},
	remove: function(id)
	{
		var idx = this.ids.indexOf(id);
		if(-1<idx)
		{
			this.ids.remove(idx);
			this.names.remove(idx);
		}
		var container = document.getElementById("itemUserGroupsContainer");
		container.removeChild(document.getElementById("_iug_" + id));
	},
	setIDs: function(o)
	{
		this.ids = _copyValue(o);
    },
	setNames: function(o)
	{
		this.names = _copyValue(o);
    },
	setIDsString: function(s)
	{
		this.ids = s.split(_DELIMETER);
	},
	setNamesString: function(s)
	{
		this.names = s.split(_DELIMETER);
	},
	getIDsString: function()
	{
		var str = "";
		for(var i=0; i<this.ids.length; i++)
		{
			str += this.ids[i] + _DELIMETER;
		}
		return (3<=str.length)?str.substring(0, str.length-3):str;
	},
	getNamesString: function()
	{
		var str = "";
		for(var i=0; i<this.names.length; i++)
		{
			str += this.names[i] + _DELIMETER;
		}
		return (3<=str.length)?str.substring(0, str.length-3):str;
	}
}

var Menus = Class.create();
Menus.prototype =
{
	initialize: function(menus)
	{
		this.menu = new Array();

		if(null != menus && "undefined" != typeof(menus))
		{
			for(var i=0; i < menus.getLength(); i++)
			{
				this.menu[i] = new Menu(menus.getMenu(i));
			}
		}
	},
	setMenu: function(m)
	{
		var index = this.indexOf(m);
		if (index < 0)
		{
			this.menu[this.menu.length] = new Menu(m);
		}
		else
		{
			this.menu[index] = new Menu(m);
		}
	},
	addMenu: function(m)
	{
		this.menu[this.menu.length] = new Menu(m);
	},
	indexOf: function(m)
	{
		for(var i=0; i<this.menu.length; i++)
		{
			//if (this.menu[i].getName() == m.getName())
			if (this.menu[i].getMenuID() == m.getMenuID())
			{
				return i;
			}
		}
		return -1;
	},
	isDuplicatedName: function(name)
	{
		var count = 0;
		for(i=0; i<this.menu.length; i++)
		{
			if (this.menu[i].getName() == name)
			{
				count++;
			}
		}
		return (1 < count);
	},
	getMenuByName: function(num)
	{
		for(i=0; i<this.menu.length; i++)
		{
			if (this.menu[i].name == num)
			{
				return this.menu[i];
			}
		}
		return null;
	},
	getMenuById: function(id)
	{
		for(var i=0; i<this.menu.length; i++)
		{
			if (this.menu[i].menuID == id)
			{
				return this.menu[i];
			}
		}
		return null;
	},
	getMenu: function(index)
	{
		return this.menu[index];
	},
	getLength: function()
	{
		return this.menu.length;
	},
	sortDisplyOrder: function(a, b)
	{
		return a.getDisplayOrder() - b.getDisplayOrder();
	},
	sortMenu: function()
	{
		this.menu.sort(this.sortDisplyOrder);
	},
	swapDisplayOrder: function(a, b)
	{
		var pos = a.getDisplayOrder();
		a.setDisplayOrder(b.getDisplayOrder());
		b.setDisplayOrder(pos);
	},
	remove: function(m)
	{
		var index = this.menu.indexOf(m)
		this.menu.remove(index);
		for(var i=0; i<this.menu.length; i++)
		{
			this.menu[i].setDisplayOrder(i);
		}
	},
	getMenuItemCount: function()
	{
		return this.menu.length;
	},
	load: function(xmlDoc)
	{
		if (!xmlDoc) return;

		if(typeof(xmlDoc.documentElement) != 'undefined')
		{
			xmlDoc = xmlDoc.documentElement;
		}
		else
		{
			if(!xmlDoc.childNodes)
			{
				return;
			}
			else
			{
				xmlDoc = xmlDoc.firstChild;
			}
		}
		
		this.setXMLDocument(xmlDoc);
	},
	setXMLDocument: function(xmlDoc)
	{
		if (!xmlDoc || !xmlDoc.childNodes ) return;
		var w = xmlDoc.childNodes;
		var cnt = w.length;
		for(var i=0; i<cnt; i++)
		{
			var m = new Menu();
			if(m.setXMLDocument(w[i]))
			{
				this.menu[this.menu.length] = m;
			}
		}
		if(1<cnt)
		{
			this.sortMenu();
		}
	},
	toXML: function(tagName)
	{
		if(typeof tagName == 'undefined')
		{
			tagName = 'menus';
		}
		var child = "";
		for(var i=0; i < this.menu.length; i++)
		{
			child += this.menu[i].toXML();
		}
		return addChild(tagName, child);
	}
};

var Menu = Class.create();
Menu.prototype =
{
	initialize: function(menu)
	{
		this.name = null;
		this.menuID = (new Date()).getTime();
		this.displayOrder = 0;
		this.linkDisplayName = null;
		this.linkType = null;
		this.linkID = null;
		this.userGroups = new UserGroups();
		this.linkDescriptor = null;
		this.description = null;
		this.menuResourceID = null;
		this.submenusOption = "none";
		this.submenus = null;
		this.href = null;
		this.help = null;
		this.newWindow = false;

		if(null != menu && "undefined" != typeof(menu))
		{
			this.name = menu.name;
			this.menuID = menu.menuID;
			this.displayOrder = menu.displayOrder;
			this.linkDisplayName = menu.linkDisplayName;
			this.linkType = menu.linkType;
			this.linkID = menu.linkID;
			this.userGroups = new UserGroups(menu.userGroups);
			this.linkDescriptor = menu.linkDescriptor;
			this.description = menu.description;
			this.menuResourceID = menu.menuResourceID;
			this.submenusOption = menu.submenusOption;
			this.submenus = menu.submenus;
			this.href = menu.href;
			this.help = menu.help;
			this.newWindow = menu.newWindow;
		}
	},
	setMenuID: function(o)
	{
		this.menuID = o;
	},
	getMenuID: function()
	{
		return this.menuID;
	},
	setName: function(o)
	{
		this.name = o;
	},
	getName: function()
	{
		return this.name;
	},
	setSubmenus: function(o)
	{
		this.submenus = o;
	},
	getSubmenus: function()
	{
		return this.submenus;
	},
	setDisplayOrder: function(o)
	{
		this.displayOrder = o;
	},
	getDisplayOrder: function()
	{
		return this.displayOrder;
	},
	setLinkType: function(o)
	{
		this.linkType = o;
	},
	getLinkType: function()
	{
		return this.linkType;
	},
	setLinkDescriptor: function(o)
	{
		this.linkDescriptor = o;
	},
	getLinkDescriptor: function()
	{
		return this.linkDescriptor;
	},
	setLinkDisplayName: function(o)
	{
		this.linkDisplayName = o;
	},
	getLinkDisplayName: function()
	{
		return this.linkDisplayName;
	},
	setLinkID: function(o)
	{
		this.linkID = o;
	},
	getLinkID: function()
	{
		return this.linkID;
	},
	setUserGroupID: function(o)
	{
		this.userGroups.setIDs(o);
	},
	setUserGroupName: function(o)
	{
		this.userGroups.setNames(o);
	},
	getUserGroupID: function()
	{
		return this.userGroups.getIDsString();
	},
	getUserGroupName: function()
	{
		return this.userGroups.getNamesString();
	},
	setDescription: function(o)
	{
		this.description = o;
	},
	getDescription: function()
	{
		return this.description;
	},
	setSubmenusOption: function(o)
	{
		this.submenusOption = o;
	},
	getSubmenusOption: function()
	{
		return this.submenusOption;
	},
	setMenuResourceID: function(o)
	{
		this.menuResourceID = o;
	},
	getMenuResourceID: function()
	{
		return this.menuResourceID;
	},
	setHref: function(o)
	{
		this.href = o;
	},
	getHref: function()
	{
		return this.href;
	},
	setHelp: function(o)
	{
		this.help = o;
	},
	getHelp: function()
	{
		return this.help;
	},
	setNewWindow: function(o)
	{
		this.newWindow = o;
	},
	getNewWindow: function()
	{
		return this.newWindow;
	},
	getClassName: function()
	{
		return 'menu';
	},
	setXMLDocument: function(xmlDoc)
	{
		if (!xmlDoc || !xmlDoc.childNodes ) return;
		var cnt = xmlDoc.childNodes.length;
		if(0 == cnt) return false;

		for(var i=0; i<cnt; i++)
		{
			try
			{
				//debugger;
				if("submenus" == xmlDoc.childNodes[i].tagName)
				{
					this.submenus = new Menus();
					this.submenus.setXMLDocument(xmlDoc.childNodes[i]);
				}
				else if("userGroupID" == xmlDoc.childNodes[i].tagName)
				{
					this.userGroups.setIDsString(getNodeText(xmlDoc.childNodes[i]));
				}
				else if("userGroupName" == xmlDoc.childNodes[i].tagName)
				{
					this.userGroups.setNamesString(getNodeText(xmlDoc.childNodes[i]));
				}
				else
				{
					eval("this." + xmlDoc.childNodes[i].tagName + "=" + asValue(xmlDoc.childNodes[i]));
				}
			}catch(e)
			{
				alert(e);
				return false;
			}
		}
		return true;
	},
	toXML: function()
	{
		var child = element('name', this.name);
		child += element('menuID', _menuID++);
		child += element('displayOrder', this.displayOrder);
		child += element('linkDisplayName', this.linkDisplayName);
		child += element('linkType', this.linkType);
		child += element('linkDescriptor', this.linkDescriptor);
		child += element('linkID', this.linkID);
		child += element('userGroupID', this.userGroups.getIDsString());
		child += element('userGroupName', this.userGroups.getNamesString());
		child += element('description', this.description);
		child += element('menuResourceID', this.menuResourceID);
		child += element('submenusOption', this.submenusOption);
		if("custom" == this.submenusOption && null != this.submenus)
		{
			child += this.submenus.toXML('submenus');
		}
		child += element('href', this.href);
		child += element('help', this.help);
		child += element('newWindow', this.newWindow);

		return addChild('menu', child);
	}
};

var _menus = new Menus();
var AjaxObject = {
	successHandler:function(o){
		if(o.argument == "getMenus")
		{
			this.setMenus(o);
		}
		else if(o.argument == "sendPost")
		{
			var r = {};
			if(o.responseText) {
				r = o.responseText;
			} else {
				r = o;
			}
			if(r.code == 0)
			{
				goMenuList(r.menuID);				
			}
			else
			{
				alert(r.msg);
				enableMainWrapper()
			}
		}
		else if(o.argument == "preview")
		{
			enableMainWrapper()
			openPreview();
		}
	},
	failureHandler:function(o){
		alert(o.statusText);
		enableMainWrapper();
	},
	setMenus:function(o){
		_menus.load(o.responseXML);
		refreshMenuItem();
	},
	sendCommand:function(callback, params) {		
		var url = contextPath + '/bizcoves/user/bizcoves/menu/menu_action.jsp?_t=' + (new Date().getTime());
		url += "&command=" + callback.argument + ((typeof(params) == "undefined") ? "" : "&"+params);
		YAHOO.util.Connect.asyncRequest('GET', url, callback);
	},
	preview:function(postData) {
		disableMainWrapper();
		YAHOO.util.Connect.asyncRequest('POST', contextPath + '/bizcoves/user/bizcoves/menu/menu_action.jsp', previewCallback, postData);
	},
	sendPost:function(postData) {
		disableMainWrapper();
		YAHOO.util.Connect.asyncRequest('POST', contextPath + '/bizcoves/user/bizcoves/menu/menu_action.jsp', sendPostCallback, postData);
	}
};

var getMenusCallback =
{
	success:AjaxObject.successHandler,
	failure:AjaxObject.failureHandler,
	timeout: 300000,
	argument: "getMenus",
	scope: AjaxObject
};
var sendPostCallback =
{
	success:AjaxObject.successHandler,
	failure:AjaxObject.failureHandler,
	timeout: 300000,
	argument: "sendPost",
	scope: AjaxObject
};
var previewCallback =
{
	success:AjaxObject.successHandler,
	failure:AjaxObject.failureHandler,
	timeout: 300000,
	argument: "preview",
	scope: AjaxObject
};
function getSelectedMenu()
{
	var eSel = document.getElementById('menuItems');
	if(eSel.selectedIndex < 0)
	{
		return null;
	}
	var eOpt = eSel.options[eSel.selectedIndex];
	return _menus.getMenuById(eOpt.value);
}
function getMenus()
{
	return _menus;
}
function setMenus(m)
{
	if(m == null)
	{
		m = new Menus();
	}
	_menus = m;
}
function refreshMenuItem()
{
	removeAllSelectOptions();
	for(var i=0; i<_menus.getLength(); i++)
	{
		appendMenu(_menus.getMenu(i))
	}

	var selectedMenu = getSelectedMenu();
	if(selectedMenu == null)
	{
		noFocusItemActionButton();
	}
}
function removeAllSelectOptions()
{
	var eSel = document.getElementById('menuItems');
	var len = eSel.options.length;
	for(var i=0; i<len; i++)
	{
		eSel.remove(0);
	}
}
function clearItemUserGroupsContainer()
{
	var container = document.getElementById("itemUserGroupsContainer");
	container.style.visibility = "visible";
	var length = container.options.length;
	for(var i=0; i<length; i++)
	{
		container.remove(0);
	}
}
function displayUserGroupsContainer(ug)
{
	clearItemUserGroupsContainer();
	var container = document.getElementById("itemUserGroupsContainer");

	for(var i=0; i<ug.ids.length; i++)
	{
		container.options[i] = document.createElement('option');
		container.options[i].value = ug.ids[i];
		container.options[i].innerHTML = ug.names[i];
	}
}
function displayInfo(menu, isEditable)
{
	document.getElementById('detailTable').style.visibility = "visible";
	document.getElementById('itemName').value = menu.getName();
	document.getElementById('itemLinkType').value = menu.getLinkType();
	document.getElementById('itemLinkID').value = menu.getLinkID();
	document.getElementById('itemHelp').value = menu.getHelp();
	document.getElementById('itemLinkDescriptor').value = menu.getLinkDescriptor();
	document.getElementById('itemLinkDisplayName').value = menu.getLinkDisplayName();
	document.getElementById('itemDescription').value = menu.getDescription();
	displayUserGroupsContainer(menu.userGroups);

	if(isSubmenusConfiguration)
	{
		if(menu.getNewWindow())
		{
			document.getElementById('itemNewWindow_true').checked = true;
		}
		else
		{
			document.getElementById('itemNewWindow_false').checked = true;
		}
	}
	else
	{
		var eSel = document.getElementById('itemSubmenusOption');
		for(var i=0; i<eSel.options.length; i++)
		{
			if(eSel.options[i].value == menu.getSubmenusOption())
			{
				eSel.options[i].selected = true;
			}
		}

		document.getElementById('submenusConfigButton').disabled = ("custom" != menu.getSubmenusOption());
	}
	if(isEditable)
		enableDetail(LBL_CMM_MODIFY);
	else
		disableDetail();
}
function swapSelectItem(a, b)
{
	var text = a.text;
	var value = a.value;
	a.text = b.text;
	a.value = b.value;
	b.text = text;
	b.value = value;
	a.selected = true;
}
function disableMainWrapper()
{
	document.getElementById('mainWrapper').disabled = true;
}
function enableMainWrapper()
{
	document.getElementById('mainWrapper').disabled = false;
}
function disableDetail()
{
	document.getElementById('detailTableFrame').style.borderColor = "white";
	document.getElementById('itemName').readOnly = true;
	document.getElementById('itemHelp').readOnly = true;
	document.getElementById('selectLinkButton').disabled = true;
	document.getElementById('selectItemUserGroupButton').disabled = true;
	document.getElementById('deleteItemUserGroupButton').disabled = true;
	//document.getElementById('itemUserGroupsContainer').readOnly = true;
	document.getElementById('itemDescription').readOnly = true;
	document.getElementById('itemApplyButton').style.visibility = "hidden";
	document.getElementById('itemCancelButton').style.visibility = "hidden";
	document.getElementById('selectLinkButton').style.visibility = "hidden";
	document.getElementById('selectItemUserGroupButton').style.visibility = "hidden";
	document.getElementById('deleteItemUserGroupButton').style.visibility = "hidden";

	if(isSubmenusConfiguration)
	{
		document.getElementById('itemNewWindow_true').disabled = true;
		document.getElementById('itemNewWindow_false').disabled = true;
	}
	else
	{
		document.getElementById('itemSubmenusOption').disabled = true;
		document.getElementById('submenusConfigButton').style.visibility = "hidden";
	}
}
function enableDetail(btnName)
{
	document.getElementById('detailTableFrame').style.borderColor = "#6CABF9";
	document.getElementById('detailTable').style.visibility = "visible";
	document.getElementById('itemName').readOnly = false;
	document.getElementById('itemHelp').readOnly = false;
	document.getElementById('selectLinkButton').disabled = false;
	document.getElementById('selectItemUserGroupButton').disabled = false;
	document.getElementById('deleteItemUserGroupButton').disabled = false;
	//document.getElementById('itemUserGroupsContainer').readOnly = false;
	document.getElementById('itemDescription').readOnly = false;
	document.getElementById('itemApplyButton').value = btnName;
	document.getElementById('itemApplyButton').style.visibility = "visible";
	document.getElementById('itemCancelButton').style.visibility = "visible";
	document.getElementById('selectLinkButton').style.visibility = "visible";
	document.getElementById('selectItemUserGroupButton').style.visibility = "visible";
	document.getElementById('deleteItemUserGroupButton').style.visibility = "visible";

	if(isSubmenusConfiguration)
	{
		document.getElementById('itemNewWindow_true').disabled = false;
		document.getElementById('itemNewWindow_false').disabled = false;
	}
	else
	{
		document.getElementById('itemSubmenusOption').disabled = false;
		document.getElementById('submenusConfigButton').style.visibility = "visible";
	}
}
function disableActionButton()
{
	document.getElementById('addMenuButton').disabled = true;
	document.getElementById('modifyMenuButton').disabled = true;
	document.getElementById('deleteMenuButton').disabled = true;
	document.getElementById('moveUpButton').disabled = true;
	document.getElementById('moveDownButton').disabled = true;
	document.getElementById('applyButton').disabled = true;
	document.getElementById('menuItems').disabled = true;

	if(!isSubmenusConfiguration)
	{
		document.getElementById('previewButton').disabled = true;
	}
}
function enableActionButton()
{
	document.getElementById('addMenuButton').disabled = false;
	document.getElementById('modifyMenuButton').disabled = false;
	document.getElementById('deleteMenuButton').disabled = false;
	document.getElementById('moveUpButton').disabled = false;
	document.getElementById('moveDownButton').disabled = false;
	document.getElementById('applyButton').disabled = false;
	document.getElementById('menuItems').disabled = false;

	if(!isSubmenusConfiguration)
	{
		document.getElementById('previewButton').disabled = false;
	}
}
function noFocusItemActionButton()
{
	document.getElementById('addMenuButton').disabled = false;
	document.getElementById('modifyMenuButton').disabled = true;
	document.getElementById('deleteMenuButton').disabled = true;
	document.getElementById('moveUpButton').disabled = true;
	document.getElementById('moveDownButton').disabled = true;
}
function disableDetailTable()
{
	document.getElementById('detailTable').style.visibility = "hidden";
}

function selectMenu()
{
	_selectedMenu = getSelectedMenu();
	if(_selectedMenu)
	{
		_submenus = _selectedMenu.getSubmenus();
	}
	if(_selectedMenu != null)
	{
		_currentMenuItemAction = "select";
		displayInfo(_selectedMenu, false);
	}
	document.getElementById('modifyMenuButton').disabled = false;
	document.getElementById('deleteMenuButton').disabled = false;
	document.getElementById('moveUpButton').disabled = false;
	document.getElementById('moveDownButton').disabled = false;
}
function moveUp()
{
	var selectedMenu = getSelectedMenu();
	if(selectedMenu == null) return;
	_currentMenuItemAction = "moveup";
	var eSel = document.getElementById('menuItems');
	var selectedIndex = eSel.selectedIndex;
	if (selectedIndex == 0) return;
	var eOpt = eSel.options[selectedIndex-1];
	var preMenu = _menus.getMenuById(eOpt.value);
	swapSelectItem(eSel.options[selectedIndex-1], eSel.options[selectedIndex]);
	_menus.swapDisplayOrder(preMenu, selectedMenu);
}
function moveDown()
{
	var selectedMenu = getSelectedMenu();
	if(selectedMenu == null) return;
	_currentMenuItemAction = "movedown";
	var eSel = document.getElementById('menuItems');
	var selectedIndex = eSel.selectedIndex;
	if (selectedIndex >= eSel.options.length-1) return;
	var eOpt = eSel.options[selectedIndex+1];
	var postMenu = _menus.getMenuById(eOpt.value);
	swapSelectItem(eSel.options[selectedIndex+1], eSel.options[selectedIndex]);
	_menus.swapDisplayOrder(postMenu, selectedMenu);
}
function resetDetails()
{
	document.getElementById('itemLinkID').value = "";
	document.getElementById('itemHelp').value = "";
	document.getElementById('itemLinkDescriptor').value = "";
	document.getElementById('itemLinkType').value = "";
	document.getElementById('itemLinkDisplayName').value = "";
	document.getElementById('itemName').value = "";
	document.getElementById('itemDescription').value = "";

	clearItemUserGroupsContainer();

	if(isSubmenusConfiguration)
	{
		document.getElementById('itemNewWindow_false').checked = true;
	}
	else
	{
		document.getElementById('itemSubmenusOption').options[0].selected = true;
		document.getElementById('submenusConfigButton').disabled = true;
		resetItemSubmenus();
	}
}
function addMenu()
{
	_currentMenuItemAction = "add";
	_selectedMenu = null;
	enableDetail(LBL_CMM_ADD);

	resetDetails();
	disableActionButton();

	var eSel = document.getElementById('menuItems');
	var selectedIndex = eSel.selectedIndex;
	if(selectedIndex > -1)
	{
		eSel.options[selectedIndex].selected = false;
	}
	document.getElementById('itemName').focus();
}
function modifyMenu()
{
	var selectedMenu = getSelectedMenu();
	if(selectedMenu == null) return;
	_submenus = _selectedMenu.getSubmenus();
	
	_currentMenuItemAction = "modify";
	enableDetail(LBL_CMM_MODIFY);

	changeToUnselectedItem();
	disableActionButton();

//	var eSel = document.getElementById('menuItems');
//	var selectedIndex = eSel.selectedIndex;
//	if(selectedIndex > -1)
//	{
//		eSel.options[selectedIndex].selected = false;
//	}
	document.getElementById('itemName').focus();
}
function deleteMenu()
{
	var selectedMenu = getSelectedMenu();
	if(selectedMenu == null) return;

	_currentMenuItemAction = "delete";
	disableDetail();

	resetDetails();
	_menus.remove(selectedMenu);
	refreshMenuItem();

}
function goMenuList(menuID)
{
	if ("" == menuID)
	{
		location.href = contextPath + "/bizcoves/user/bizcoves/menu/menu_list.jsp";
	}
	else
	{
		location.href = contextPath + "/bizcoves/user/bizcoves/menu/menu_list.jsp?ActionTag=checkin&menuID=" + menuID;
	}
}
function openSubmenus()
{
	var baseUserGroupID = document.getElementById('userGroupID').value;
	if(!isGlobalMenu && baseUserGroupID == "")
	{
		alert(MSG_ORG_SEL_UG);
		return;
	}
	var sURL = contextPath + "/bizcoves/user/bizcoves/menu/menu_submenus.jsp?baseUserGroupID=" + baseUserGroupID;
    openPopup(sURL, "", "submenus", 770, 500, true, true, true, false, true);
}
function openSelectLink()
{
	var sURL = contextPath + "/bizcoves/user/bizcoves/menu/menu_link_bizcoveview.jsp";
    openPopup(sURL, "", "selectBizCove", 750, 520, true, true, true, false, true);
}
function openSelectUserGroup()
{
	var sURL = contextPath + "/common/orgtree.jsp?callback=openSelectUserGroupCallback&showMemberList=false&windowHeight=440&windowWidth=300";
    openPopup(sURL, "", "orgTree", 320, 470, false, false);
}
function itemSubmenusOption_onchange(eSel)
{
	var selectedIndex = eSel.selectedIndex;
	if (-1 < selectedIndex)
	{
		if("custom" == eSel.options[selectedIndex].value)
		{
			document.getElementById("submenusConfigButton").disabled = false;
		}
		else
		{
			document.getElementById("submenusConfigButton").disabled = true;
		}
	}
}
function openSelectItemUserGroup()
{
	var sURL = contextPath + "/common/orgtree.jsp?showMemberList=false&callback=openSelectItemUserGroupCallback&maxSelection=100&windowHeight=450&windowWidth=300";
	var topOrgID = document.getElementById("userGroupID").value;
	if(null != topOrgID && 9 < topOrgID.length)
	{
        var rootType = topOrgID.substring(0,1);
        sURL += "&rootType=" + rootType + "&rootID=" + topOrgID.substring(1);
        if (rootType == 'H')
            sURL += "&showRoot=true";
        else
        {
            sURL += "&showRoot=false";
            var userGroupName = document.getElementById("userGroupName");
            if(userGroupName) {
                var topOrgName = userGroupName.value;
                if(null != topOrgName && "" != topOrgName)
                {
                    sURL += "&rootDisplayName=" + topOrgName;
                }
            }
        }
    }
    else
    {
        sURL += "&showRoot=true";
    }
    
    var preSelectedIDs = "";
	var ids	= getItemUserGroupIDsFromContainer();
	for(var i=0; i<ids.length; i++)
	{
		preSelectedIDs += ids[i] + _DELIMETER;
	}

    sURL += "&preSelectedID=" + preSelectedIDs;
    openPopup(sURL, TTL_ORG_SELECT_USER_GROUP, "orgTree", 320, 470, false, false);
}
function openSelectUserGroupCallback(jo)
{
	eval("var o=" + jo);
	if(typeof o != 'undefined')
	{
		document.getElementById("userGroupID").value = o.TYPE + o.ID;
		document.getElementById("userGroupName").value = o.NAME;
	}
}
var currentItemUserGroups=null;
function openSelectItemUserGroupCallback(jo)
{
	currentItemUserGroups = new UserGroups();
	currentItemUserGroups.parse(jo);
	displayUserGroupsContainer(currentItemUserGroups);
}
function bizcoveChangeCallBack(id, type, descriptor, name)
{
	var num = parseInt(id);
	if(num > 1000100 && descriptor.length<10)
	{
		descriptor = descriptor + 'I' + id;
	}

	document.getElementById('itemLinkType').value = type;
	document.getElementById('itemLinkID').value = id;
	document.getElementById('itemLinkDescriptor').value = descriptor;
	document.getElementById('itemLinkDisplayName').value = name + "(" + type + ")";
}
function checkValidItem()
{
	var itemName = document.getElementById('itemName').value = trimString(document.getElementById('itemName').value);
	if(itemName == "")
	{
		alert(MSG_BC_NAME_CANNOT_BLANK);
		return false;
	}
	if(document.getElementById('itemLinkID').value == "")
	{
		alert(MSG_MENU_SEL_LINK);
		return false;
	}
//	if (_menus.isDuplicatedName(itemName))
//	{
//		alert(MSG_MENU_ITEM_DUP_NAME);
//		return false;
//	}
	return true;
}
function checkValidMenu()
{
    var name = document.getElementById('name').value = trimString(document.getElementById('name').value);
	if(name == "")
	{
		alert(MSG_BC_NAME_CANNOT_BLANK);
		return false;
	}
	if(!isGlobalMenu && document.getElementById('userGroupID').value == "")
	{
		alert(MSG_ORG_SEL_UG);
		return false;
	}
	return true;
}
function changeToUnselectedItem()
{
	var eSel = document.getElementById('menuItems');
	var selectedIndex = eSel.selectedIndex;
	if (-1 < selectedIndex)
	{
		eSel.options[selectedIndex].selected = false;
	}

	if(-1<eSel.selectedIndex)
	{
		if(eSel.options.length >= 1)
		{
			document.getElementById('modifyMenuButton').disabled = false;
			document.getElementById('deleteMenuButton').disabled = false;
			if(eSel.options.length >= 2)
			{
				document.getElementById('moveUpButton').disabled = false;
				document.getElementById('moveDownButton').disabled = false;
			}
		}
		else
		{
			document.getElementById('modifyMenuButton').disabled = true;
			document.getElementById('deleteMenuButton').disabled = true;
			document.getElementById('moveUpButton').disabled = true;
			document.getElementById('moveDownButton').disabled = true;
		}
	}
	else
	{
		document.getElementById('modifyMenuButton').disabled = true;
		document.getElementById('deleteMenuButton').disabled = true;
		document.getElementById('moveUpButton').disabled = true;
		document.getElementById('moveDownButton').disabled = true;
	}
}

function sendJSON(postData, argument) {
	$.ajax({
		type: "POST"
		,url: contextPath + '/bizcoves/user/bizcoves/menu/menu_action.jsp'
		,data: postData
		,dataType: "text"
		,cache: false
		,async: false
	}).done(function(jsonStr) { // @return {code:codeNumber, menuID: menuID, msg:"error message"}
		var jsonStr2 = jsonStr.replace(/[\n|\r|\t]/g, '');
		var json = JSON.parse(jsonStr2);
		json["argument"] = argument;
		AjaxObject.successHandler(json);
	}).always(function() {
	}).fail(function(jqXHR, textStatus, errorThrown) {
		AjaxObject.failureHandler(textStatus);
	});
}

function apply()
{
	if(!checkValidMenu()) return;

    if(_menus.getMenuItemCount() < 1)
	{
		alert(MSG_MENU_NO_ITEM_TO_APPLY);
		return;
	}

    var postData = "command=sendPost&menuID=" + document.getElementById("menuID").value;
	postData += "&name=" + encodeURIComponent(document.getElementById("name").value);
	postData += "&userGroupID=" + (document.getElementById("userGroupID").value);
	postData += "&description=" + encodeURIComponent(document.getElementById("description").value);
	postData += "&menusXML=" + encodeURIComponent(_XML_HEAD + _menus.toXML());
	sendJSON(postData, "sendPost");
}
function preview()
{
	if(!checkValidMenu()) return;
	if(_menus.getMenuItemCount() < 1)
	{
		alert(MSG_MENU_NO_ITEM);
		return;
	}
	var postData = "command=preview&menusXML=" + encodeURIComponent(_XML_HEAD + _menus.toXML());
	AjaxObject.preview(postData);
}

function openPreview()
{
	var sURL = contextPath + "/bizcoves/common/previewmenu.jsp";
    if(BrowserDetect.mobile) {
        openNewTab(sURL);
    } else {
	    openPopup(sURL, "", "preview menu", "100%", "100%", true, true, true, false);
    }
}
function deleteItemUserGroup(id)
{
	currentItemUserGroups.remove(id);
}
function itemCancelButton_onclick()
{
	resetDetails();
	disableDetail();
	enableActionButton();
	changeToUnselectedItem();
	selectMenu();
	refreshMenuItem();
}
function getItemUserGroupIDsFromContainer()
{
	var ids = new Array();
	var opt = document.getElementById('itemUserGroupsContainer').options;
	for(var i=0; i<opt.length; i++)
	{
		ids[ids.length] = opt[i].value;
	}
	return ids;
}
function getItemUserGroupNamesFromContainer()
{
	var names = new Array();
	var opt = document.getElementById('itemUserGroupsContainer').options;
	for(var i=0; i<opt.length; i++)
	{
		names[names.length] = opt[i].innerHTML;
	}
	return names;
}
function itemApplyButton_onclick()
{
	if(!checkValidItem()) return;	
	if ("add" == _currentMenuItemAction)
	{
		var m = new Menu();
		m.setDisplayOrder(document.getElementById('menuItems').options.length);
		m.setMenuID(m.getDisplayOrder());
		m.setName(document.getElementById('itemName').value);
		m.setHelp(document.getElementById('itemHelp').value);
		m.setLinkID(document.getElementById('itemLinkID').value);
		m.setUserGroupID(getItemUserGroupIDsFromContainer());
		m.setUserGroupName(getItemUserGroupNamesFromContainer());
		m.setLinkDescriptor(document.getElementById('itemLinkDescriptor').value);
		m.setLinkType(document.getElementById('itemLinkType').value);
		m.setLinkDisplayName(document.getElementById('itemLinkDisplayName').value);
		m.setDescription(document.getElementById('itemDescription').value);

		if(isSubmenusConfiguration)
		{
			m.setNewWindow(document.getElementById('itemNewWindow_true').checked);
		}
		else
		{
			var eSel = document.getElementById("itemSubmenusOption");
			var selectedIndex = eSel.selectedIndex;
			if (-1 < selectedIndex)
			{
				m.setSubmenusOption(eSel.options[selectedIndex].value);
			}

			if("custom" == m.getSubmenusOption())
			{
				m.setSubmenus(_submenus);
			}
		}
		_menus.addMenu(m);
		appendMenu(m);
	}
	else if ("modify" == _currentMenuItemAction)
	{
		var m = _selectedMenu;
		if(m == null) return;
		m.setName(document.getElementById('itemName').value);
		m.setHelp(document.getElementById('itemHelp').value);
		m.setLinkID(document.getElementById('itemLinkID').value);
		m.setUserGroupID(getItemUserGroupIDsFromContainer());
		m.setUserGroupName(getItemUserGroupNamesFromContainer());
		m.setLinkDescriptor(document.getElementById('itemLinkDescriptor').value);
		m.setLinkType(document.getElementById('itemLinkType').value);
		m.setLinkDisplayName(document.getElementById('itemLinkDisplayName').value);
		m.setDescription(document.getElementById('itemDescription').value);

		if(isSubmenusConfiguration)
		{
			m.setNewWindow(document.getElementById('itemNewWindow_true').checked);
		}
		else
		{
			var eSel = document.getElementById("itemSubmenusOption");
			var selectedIndex = eSel.selectedIndex;
			if (-1 < selectedIndex)
			{
				m.setSubmenusOption(eSel.options[selectedIndex].value);
			}

			if("custom" == m.getSubmenusOption())
			{
				m.setSubmenus(_submenus);
			}
		}

		eSel = document.getElementById('menuItems');
		eSel.options[m.getDisplayOrder()].text = m.getName();
		eSel.options[m.getDisplayOrder()].value = m.getMenuID();
	}
	enableActionButton();
	changeToUnselectedItem();
	disableDetail();
}
function deleteSelectedItemUserGroup()
{
	var container = document.getElementById("itemUserGroupsContainer");
	var length = container.length;
	for(var i=length-1; 0<=i; i--)
	{
		if(container.options[i].selected)
		{
			container.remove(i);
		}
	}
}
var _submenus = null;
function resetItemSubmenus()
{
	_submenus = null;
}
function setItemSubmenus(menus)
{
	_submenus = new Menus(menus);
}
function getCurrentItemSubmenus()
{
	if(null != _submenus)
	{
		return _submenus;
	}
	if("add" == _currentMenuItemAction)
	{
		return null;
	}
	var m = getSelectedMenu();
	if(null==m)
	{
		if(null==_selectedMenu)
		{
			return null;
		}
		else
		{
			return _selectedMenu.getSubmenus();
		}
	}
	return m.getSubmenus();
}
