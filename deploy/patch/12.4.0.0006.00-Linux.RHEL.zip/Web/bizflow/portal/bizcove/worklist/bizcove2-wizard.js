function TemplateClass () {
	// Constructor
	this.json = "";

	// private

	// public
	this.setJSON = function (properties) {
		this.json = properties;
	};
	this.getJSON = function () {
		return this.json;
	};
}

TemplateClass.prototype = {
	setInitial : function() {
		var actionList = $("#action-available");
		this.json.layout.contextMenu = (typeof this.json.layout.contextMenu == 'boolean') ? this.json.layout.contextMenu : false;	// set default value
		$.each(this.json.actions, function(i, v) {
			if(!v.custom) {
				v.isToolbarItem = (typeof v.isToolbarItem == 'boolean') ? v.isToolbarItem : (v.isToolbarItem!="false");	// set default value as true
				var item = $("<li onclick='onclickActionLi(this);'>");
				item.attr("class", "list-item action-item");
				//item.click(function(){onclickActionLi(this)});
				item.data("bf-prop", v);
				item.append('<a class="list-item-title">' + v.title + '</a><div class="list-item-swap" onclick="moveAction(this);"><i class="fa fa-arrow-right"></i></div>');
				actionList.append(item);
			}
		});

		var columnList = $('#column-available');
		$.each(this.json.columns, function(i, v) {
			v.displayTitle = (typeof v.displayTitle == 'boolean') ? v.displayTitle : (v.displayTitle!="false");	// set default value as true
			if(!v.custom) {
				v.procDataType = getProcDataType(v.dataType);
				var item = $('<li onclick="onclickColumnLi(this);">');
				item.attr("class", "list-item column-item");
				item.data("bf-prop", v);
				item.append('<a class="list-item-title">' + v.title + '</a><div class="list-item-swap" onclick="moveColumn(this);"><i class="fa fa-arrow-right"></i></div>');
				columnList.append(item);
			}
		});
	},
	uptJSON : function() {
		var bcName = this.json.name;
		var description = this.json.description;
		var icon = this.json.icon;
		var theme = this.json.theme;
		var refreshInterval = this.json.refreshInterval;
		var defaultInterval = this.json.defaultInterval;
		var pageable = this.json.layout.pageable;
		var pageSize = this.json.layout.pageSize;
		var groupable = this.json.layout.groupable;
		var quickSearch = this.json.layout.quickSearch;
		var contextMenu = this.json.layout.contextMenu;
		var organizationUnitWork = this.json.scope.type.organizationUnitWork;
		var tasksSent = this.json.scope.type.tasksSent;
		var delegatedWork = this.json.scope.type.delegatedWork;
		var groupWork = this.json.scope.type.groupWork;
		var myWork = this.json.scope.type.myWork;
		var recallableWork = this.json.scope.type.recallableWork;
		var actions = this.json.actions;
		var columns = this.json.columns;
		var maxNumOfRows = this.json.datasource.maxNumOfRows;

		$('#bcName').val(bcName);
		$('#description').val(description);
		$('#theme').val(theme);
		$('#refreshInterval').val(refreshInterval);
		$('#defaultInterval').val(defaultInterval);
		$('#pageable').val("" + pageable);
		$('#pageSize').val(pageSize);
		$('#groupable').val("" + groupable);
		$('#enableQuickSearch').val("" + quickSearch);
		$('#enableContextMenu').val("" + contextMenu);
		$("input:checkbox[name='SCOPE_TYPE_ORGANIZATIONUNITWORK']").attr("checked", organizationUnitWork);
		$("input:checkbox[name='SCOPE_TYPE_TASKSSENT']").attr("checked", tasksSent);
		$("input:checkbox[name='SCOPE_TYPE_DELEGATEDWORK']").attr("checked", delegatedWork);
		$("input:checkbox[name='SCOPE_TYPE_GROUPWORK']").attr("checked", groupWork);
		$("input:checkbox[name='SCOPE_TYPE_MYWORK']").attr("checked", myWork);
		$("input:checkbox[name='SCOPE_TYPE_RECALLABLEWORK']").attr("checked", recallableWork);
		$('#maxNumOfRows').val(maxNumOfRows);
		iconTarget = "headerIcon";
		showIcon(icon, true);

		// action
		disableAction();
		for(var i in actions) {
			var action = actions[i];
			if(action.defaultSelected) {
				//enableAction();
				moveActionTrigger(action);
			}
		}
		unselectAction();
		setColumnLinkedAction();
		// column
		disableColumn();
		for(var i in columns) {
			var column = columns[i];
			if(column.title) {
				column.field = column.field.toLowerCase();
				if(column.defaultSelected) {
					//enableColumn();
					var fieldObj = this.json.datasource.schema.fields[column.field.toLowerCase()];
					if(fieldObj) {
						moveColumnTrigger(column, fieldObj.format, fieldObj.type);
					} else if(column.dataType) {
						moveColumnTrigger(column, "", column.dataType);
					} else {
						moveColumnTrigger(column, "", "");
					}
				}
			}
		}
		unselectColumn();
		// custom sql
		var selectSQL = this.json.sql.list.text;
		var selectParam = this.json.sql.list.parameter;

		var selectEditor = getAceEditor("customSQLEditor1stCodeEdit");
		selectEditor.setValue(selectSQL, -1);
		$("#customSQLparameter1").val(selectParam);
		changeCustomSQLlistEnable();

		//var countSqlEnable = this.json.sql.count.enable;
		//var countSQL = this.json.sql.count.text;
		//var countParam = this.json.sql.count.parameter;
		//
		//$('#customSQLcountEnable').prop('checked', countSqlEnable);
		//var countEditor = getAceEditor("customSQLEditor2ndCodeEdit");
		//countEditor.setValue(countSQL, -1);
		//$("#customSQLparameter2").val(countParam);
		//changeCustomSQLcountEnable();

		checkCustomSQLEditorValue('customSQLEditor1stCodeEdit');
		//checkCustomSQLEditorValue('customSQLEditor2ndCodeEdit');

		var jsFile = this.json.external.js;
		$('input:text[name=jsURL]').each(function(i) {
			$(this).val(jsFile[i]);
		});
		var cssFile = this.json.external.css;
		$('input:text[name=cssURL]').each(function(i) {
			$(this).val(cssFile[i]);
		});
	},
	defaultSelected : function () {
		$.each(this.json.actions, function(i, v) {
			if(v.defaultSelected) {
				moveActionTrigger(v);
			}
		});

		$.each(this.json.columns, function(i, v) {
			if(v.defaultSelected) {
				moveColumnTrigger(v, "", "");
			}
		});
	},
	setDefaultSort : function () {
		var sortPreferences = this.json.datasource.sort;
		for(var i in sortPreferences) {
			var sortPreference = sortPreferences[i];
			if(sortPreference.field) {
				moveSortColumnTrigger(sortPreference.field, sortPreference.dir);
				break;
			}
		}
	},
	get : function (path) {
		return this.getValue(path);
	},
	set : function (path, value) {
		this.setString(path, value);
	},
	setString : function (path, value) {
		this.setValue(path, String(value));
	},
	setNumber : function (path, value) {
		this.setValue(path, Number(value));
	},
	setBoolean : function (path, value) {
		this.setValue(path, Boolean(value));
	},
	setJSONobject : function (path, object) {
		this.setValue(path, object);
	},
	addJSONObject : function (parent, key, jsonObj) {
		if(""==parent) {
			this.json[key] = jsonObj;
		} else {
			var path = parent+"."+key;
			var fields = path.split(".");
			var result = this.json;
			for (var i = 0, n = fields.length; i < n && result !== undefined; i++) {
				var field = fields[i];
				if (i === n - 1) {
					this.json[result[field]] = jsonObj;
				} else {
					result = result[field];
				}
			}
		}
	},
	removeJSONObject : function (path) {
		var fields = path.split(".");
		var result = this.json;
		for (var i = 0, n = fields.length; i < n && result !== undefined; i++) {
			var field = fields[i];
			if (i === n - 1) {
				delete JSON[result[field]];
			} else {
				result = result[field];
			}
		}
	},
	setValue : function (path, val) {
		var fields = path.split(".");
		var result = this.json;
		for (var i = 0, n = fields.length; i < n && result !== undefined; i++) {
			var field = fields[i];
			if (i === n - 1) {
				if(typeof val == 'number')
					result[field] = Number(val);
				else if(typeof val == 'boolean')
					result[field] = Boolean(val);
				else if(typeof val == 'object')
					result[field] = val;
				else
					result[field] = val;
			} else {
				if (typeof result[field] === 'undefined') {
					result[field] = {};
				}
				result = result[field];
			}
		}
	},
	getValue : function (path) {
		var jsonObj = this.json;
		var args = path.split('.'), i, l;
		for (i=0, l=args.length; i<l; i++) {
			if (!jsonObj.hasOwnProperty(args[i])) {
				return;
			}
			jsonObj = jsonObj[args[i]];
		}

		return jsonObj;
	}
};

var validationNotifyOpts = {
	'className'	: 'warn',
	'autoHide'	: true
};

function getCurrentStepIndex()
{
	return $('#rootwizard').bootstrapWizard('currentIndex');
}
function getCurrentStepName()
{
	var index = getCurrentStepIndex();
	for (var item in MENU) {
		var menu = MENU[item];
		if(index == menu.INDEX) {
			return menu.NAME;
		}
	}
}
function jumpToStep(name)
{
	for (var item in MENU) {
		var menu = MENU[item];
		if(name == menu.NAME) {
			$('#rootwizard ul.nav li:has([data-toggle="tab"])').removeClass('active');
			$('#rootwizard ul.nav li:has([data-toggle="tab"]):eq('+menu.INDEX+')').addClass('active');
			$('#rootwizard div.tab-pane').removeClass('active');
			$('#rootwizard div.tab-pane:eq('+menu.INDEX+')').addClass('active');
			return;
		}
	}
}
function validationCheck(menuName) {
	if(bSkipValidation) return true;
//console.log("check msg for validation : validationCheck is called");
	var currentStepName = getCurrentStepName() || menuName;
	var jumpStepName = menuName;
	var checkAllSteps = (menuName == undefined);

	var isValid = true;
	if(MENU.START.NAME == menuName || checkAllSteps) {				// START
		jumpStepName = MENU.START.NAME;
		if(isEmpty("bcName")) {
			notify(BC_CANNOT_BLANK.replace("{0}",NAME), validationNotifyOpts);
			jumpToStep(jumpStepName);
			return false;
		}
	}

	if(MENU.OPTIONS.NAME == menuName || checkAllSteps) {		// SELECT_DISPLAY_OPTION
		jumpStepName = MENU.OPTIONS.NAME;
		if(isEmpty("maxNumOfRows")) {
			notify(BC_CANNOT_BLANK.replace("{0}",MAXIMUM_NUMBER_OF_LIST), validationNotifyOpts);
			isValid = false;
		}
		else {
			isValid = isValidNum("maxNumOfRows");
		}

		if(!isValid) {
			jumpToStep(jumpStepName);
			return false;
		}

		if(isEmpty("pageSize")) {
			notify(BC_CANNOT_BLANK.replace("{0}",ITEMS_PER_PAGE), validationNotifyOpts);
			isValid = false;
		}
		else {
			isValid = isValidNum("pageSize");

			var elementValue = $('#pageSize').val();
			if( elementValue < 1) {
				notify(MUST_BE_GREATER_THAN_ZERO.replace("{0}",ITEMS_PER_PAGE), validationNotifyOpts);
				isValid = false;
			}
		}

		if(!isValid) {
			jumpToStep(jumpStepName);
			return false;
		}

		if(isEmpty("refreshInterval")) {
			notify(BC_CANNOT_BLANK.replace("{0}",MINIMUM_REFRESH_INTERVAL), validationNotifyOpts);
			isValid = false;
		}
		else {
			isValid = isValidNum("refreshInterval");
		}

		if(!isValid) {
			jumpToStep(jumpStepName);
			return false;
		}

		if(isEmpty("defaultInterval")) {
			notify(BC_CANNOT_BLANK.replace("{0}",DEFAULT_REFRESH_INTERVAL), validationNotifyOpts);
			isValid = false;
		}
		else {
			isValid = isValidNum("defaultInterval");
		}

		if(!isValid) {
			jumpToStep(jumpStepName);
			return false;
		}

		var refreshInterval = $('#refreshInterval').val();
		var defaultInterval = $('#defaultInterval').val();

		if(parseInt(defaultInterval) != 0 && (parseInt(defaultInterval) < parseInt(refreshInterval))) {
			notify(ENTER_BIGGER_DEFAULT_REFRESH_INTERVAL, validationNotifyOpts);
			isValid = false;
		}


		if(!isValid) {
			jumpToStep(jumpStepName);
			return false;
		}
	}
	if(MENU.ACTION.NAME == menuName || checkAllSteps) {		// SELECT_ACTIONS
		jumpStepName = MENU.ACTION.NAME;
		isValid = isValidAction();
		if(!isValid) {
			jumpToStep(jumpStepName);
			return false;
		}
	}

	if(MENU.COLUMN.NAME == menuName || checkAllSteps) {		// SELECT_COLUMN_DISPLAY
		jumpStepName = MENU.COLUMN.NAME;
		isValid = isValidColumn();
		if(!isValid) {
			jumpToStep(jumpStepName);
			return false;
		}
	}

	if(MENU.SORT.NAME == menuName || checkAllSteps) {		// SORT
		jumpStepName = MENU.SORT.NAME;
		if(0 == $("#sort-selected li").length)
		{
			notify(SELECT_DEFAULT_SORT_ORDER, validationNotifyOpts);
			isValid = false;
		}

		if(!isValid) {
			jumpToStep(jumpStepName);
			return false;
		}
	}

	if(MENU.SQL.NAME == menuName || checkAllSteps) {		// CUSTOM_SQL
		jumpStepName = MENU.SQL.NAME;
		var aceEditor1 = getAceEditor('customSQLEditor1stCodeEdit');
		if (aceEditor1.getValue() == "") {
			notify(BIZCOVE_ENTER_LIST_SQL, validationNotifyOpts);
			isValid = false;
		}
		var customSQLparamInput = $('#customSQLParameter1').siblings('input').val();
		if(customSQLparamInput.length <= 2) {
			notify(BIZCOVE_ENTER_PARAMETER_SQL, validationNotifyOpts);
			isValid = false;
		}

		if($('#customSQL-DRC').is(':visible')) {
			var countSqlEnable = $("input:checkbox[id='customSQLcountEnable']").is(":checked");
			if(countSqlEnable) {
				var aceEditor2 = getAceEditor('customSQLEditor2ndCodeEdit');
				if (typeof(aceEditor2) != 'undefined' && aceEditor2.getValue() == "") {
					notify(BIZCOVE_ENTER_COUNT_SQL, validationNotifyOpts);
					//alert(BIZCOVE_ENTER_COUNT_SQL);
					isValid = false;
				}
			}
		}

		if(!isValid) {
			jumpToStep(jumpStepName);
			return false;
		}

	}
	return isValid;
}
function getAceEditor(id)
{
	if($("#"+id).length)
	{
		return ace.edit(id);
	}
	else
	{
		return undefined;
	}
}

function isValidNum(elementName) {
	if(bSkipValidation) return true;
//console.log("check msg for validation : isValidNum("+elementName+") is called");
	var elementValue, isValid;
	if($('#'+elementName)) {
		elementValue = $('#'+elementName).val();
	}
	else {
		notify(ID_X_DOES_NOT_EXIST.replace("{0}",elementName), validationNotifyOpts);
		isValid = false;
		return isValid;
	}

	if (!(/^[0-9]+$/.test(elementValue))) {
		notify(NUMBER_VALUE_ONLY, validationNotifyOpts);
		isValid = false;
		return isValid;
	}
	return true;
}

function isEmpty(elementName) {
	if(bSkipValidation) return false;
//console.log("check msg for validation : isEmpty("+elementName+") is called");
	var returnVal = true, elementValue;
	if($('#'+elementName)) {
		elementValue = $('#'+elementName).val();
		returnVal = (typeof(elementValue) == 'undefined' ? true : ("" == elementValue.trim() ? true : false));
	}
	else {
		notify(ID_X_DOES_NOT_EXIST.replace("{0}",elementName), validationNotifyOpts);
		returnVal = false;
	}

	return returnVal;
	//var elementValue = $("#"+elementName).val();
	//return null == elementValue ? false : ("" == elementValue.trim() ? true : false);
}

function isValidAction() {
	if(bSkipValidation) return true;
//console.log("check msg for validation : isValidAction is called");
	var isValid = true;
	//var prop = selectedActionLi.data("bf-prop");
	if(!selectedActionLi || selectedActionLi.length == 0) {
		return true;
	}
	if($("#action-selected li").length > 0 && selectedActionLi) {
		if(isEmpty("actionName")) {			// string validation
			notify(BC_CANNOT_BLANK.replace("{0}",DISPLAY_NAME), validationNotifyOpts);
			isValid = false;
			return isValid;
		}

		if(isEmpty("actionHandler")) {		// string validation
			notify(BC_CANNOT_BLANK.replace("{0}",SCRIPT_FUNCTION_NAME), validationNotifyOpts);
			isValid = false;
			return isValid;
		}
		else {
			var actionHandlerName = $('#actionHandler').val();
			if(!isValidJavaScriptVariableName(actionHandlerName)) {		// function name validation
				notify(INVALID_FUNCTION_NAME + " [" + actionHandlerName + "]", validationNotifyOpts);	// INVALID_FUNCTION_NAME
				//isValid = false;
				//return isValid;
			}
		}

		//if(isEmpty("actionClass")) {		// string validation
		//	notify(BC_CANNOT_BLANK.replace("{0}",STYLING_CLASS_NAME), validationNotifyOpts);
		//	isValid = false;
		//}
		if(isEmpty("actionId")) {			// string and duplicate validation
			notify(BC_CANNOT_BLANK.replace("{0}",BIZCOVE_ACTION_ID), validationNotifyOpts);
			isValid = false;
			return isValid;
		}
		else {
			var actionId, actionName, dupCount = 0;

			if($('#actionId')) {
				actionId = $('#actionId').val();
			}
			else {
				notify(ID_X_DOES_NOT_EXIST.replace("{0}","actionId"), validationNotifyOpts);
				//isValid = false;
				//return isValid;
			}

			actionName = $('#actionName').val();
			$("#action-selected li").each(function(i) {
				var actionLi = $(this);
				var prop = actionLi.data("bf-prop");
				if(prop.actionid && (actionId == prop.actionid.trim())) {
					dupCount++;
				}
			});
			if(dupCount > 1) {
				notify(DUPLICATED_ID.replace("{0}",BIZCOVE_ACTION_ID + ":" + actionId), validationNotifyOpts);
				isValid = false;
				return isValid;
			}
		}
	}

	return isValid;
}

function isValidColumn() {
	if(bSkipValidation) return true;
//console.log("check msg for validation : isValidColumn is called");
	var isValid = true;
	//var prop = selectedActionLi.data("bf-prop");
	if(!selectedColumnLi || selectedColumnLi.length == 0) {
		return true;
	}

	if($("#column-selected li").length > 0) {
		if (isEmpty("columnName")) {			// string validation
			notify(BC_CANNOT_BLANK.replace("{0}", DISPLAY_NAME), validationNotifyOpts);
			//isValid = false;
			//return isValid;
		}

		if (isEmpty("columnWidth")) {		// number validation
			notify(BC_CANNOT_BLANK.replace("{0}", COLUMN_WIDTH), validationNotifyOpts);
			//isValid = false;
			//return isValid;
		}
		else {
			var columnWidthVal = $('#columnWidth').val();

			if (!(/^[0-9]+$/.test(columnWidthVal))) {
				notify(NUMBER_VALUE_ONLY, validationNotifyOpts);
				//isValid = false;
				//return isValid;
			}
		}

		//if(isEmpty("columnClass")) {		// string validation
		//	notify(BC_CANNOT_BLANK.replace("{0}",STYLING_CLASS_NAME), validationNotifyOpts);
		//	isValid = false;
		//}

		if (isEmpty("columnId")) {			// string and duplicate validation
			notify(BC_CANNOT_BLANK.replace("{0}", BIZCOVE_COLUMN_ID), validationNotifyOpts);
			isValid = false;
			return isValid;
		}
		else {
			var columnId, columnName, dupCount = 0;

			if ($('#columnId')) {
				columnId = $('#columnId').val();
			}
			else {
				notify(ID_X_DOES_NOT_EXIST.replace("{0}", "columnId"), validationNotifyOpts);
				//isValid = false;
				//return isValid;
			}

			columnName = $('#columnName').val();
			$("#column-selected li").each(function (i) {
				var columnLi = $(this);
				var prop = columnLi.data("bf-prop");
				if (prop.field && (columnId == prop.field.trim())) {
					dupCount++;
				}
			});
			if(dupCount > 1) {
				notify(DUPLICATED_ID.replace("{0}",columnId), validationNotifyOpts);
				//isValid = false;
				//return isValid;
			}
		}

		var prop = selectedColumnLi.data("bf-prop");
		if(prop && prop.isActionColumn) {
			if(prop.columnActions.length == 0) {
				isValid = confirm(NO_ACTION_CONFIRM);
				return isValid;
			}
			//var selectedCount = 0;
			//$('#customActionList li').each(function(j) {
			//	var cb = $(this).find("input");
			//	if($(cb).prop("checked")) {
			//		selectedCount++;
			//	}
			//});
			//if(selectedCount == 0) {
			//	isValid = confirm(NO_ACTION_CONFIRM);
			//	return isValid;
			//}
		}
	}
	return isValid;
}

var FldrDefActModal = "";
var IconModal = "";
var PVnAttrModal = "";
var selectedColumnLi, selectedActionLi, selectedPrevActionLi, selectedPrevColumnLi;

function replaceStyleProperty(content, name, newValue)
{
	var newStyle = "";
	var styles = content.split(";");
	var found = false;
	$.each(styles, function(index, value){
		try
		{
			var p = value.split(":");
			if(p[0].trim() == name)
			{
				found = true;
				newStyle += name + ":" + newValue + ";";
			}
			else
			{
				newStyle += value + ";";
			}
		}
		catch (e)
		{
			return false;
		}
	});

	if(!found)
	{
		newStyle = name + ":" + newValue;
	}
	return newStyle;
}
//function addActionsColumn() {
//	var actJSON = {"title":"Actions", "field":"_actions_","command":[]}
//	addCustomColumn(actJSON);
//}
function moveActionTrigger(action) {
	if(!action.custom) {
		$("#action-available li").each(function(i) {
			var prop = $(this).data("bf-prop");
			if((prop.actionid == action.actionid)&&(action.defaultSelected)) {
				$(this).find('a').html(action.title);
				$(this).data("bf-prop",action);
				var arrow = $(this).find("div.list-item-swap");
				moveAction(arrow);
				return false;
			}
		});
	} else {
		addCustomAction(action);
	}
}
function getProcDataType(dataType) {
	var procDataType = "";
	var type = new String(dataType);
	switch(type.toLowerCase()) {
		case 'date': procDataType = "D"; break;
		case 'number': procDataType = "N"; break;
		default: procDataType = "S"; break;
	}
	return procDataType;
}
function getStyleProperty(content, name, defaultValue)
{
	var val = defaultValue ? defaultValue:"";
	var styles = content.split(";");
	$.each(styles, function(index, value){
		try
		{
			var p = value.split(":");
			if(p[0].trim() == name)
			{
				val = p[1].trim();
				return false;
			}
		}
		catch (e)
		{
			return false;
		}
	});

	return val;
}

// Excel = {multi : true}
// Simple = {mode : menu, simple: true}
// Menu = {mode : menu, simple: false} <== default
// Disable = false
function getColumnFilterable(attr) {
	var filterable = "Disable";
	if (typeof attr == 'object') {
		if (attr.multi) {
			filterable = "Excel";
		} else {
			filterable = "Menu";
			if(attr.simple){
				filterable = "Simple";
			}
		}
	} else if(typeof attr == 'string') {
		filterable = attr;
	}
	return filterable;
}
function moveColumnTrigger(column, format, dataType) {
	if(!column.custom) {
		$("#column-available li").each(function (i) {
			var prop = $(this).data("bf-prop");
			if (prop.field == column.field) {
				if(!column.procDataType) {
					column.procDataType = getProcDataType(dataType);
				}
				column.format = format;
				column.dataType = dataType;
				$(this).find('a').html(column.title);
				$(this).data("bf-prop", column);
				var arrow = $(this).find("div.list-item-swap");
				moveColumn(arrow);
				return false;
			}
		});
	} else {
		if(!column.procDataType) {
			column.procDataType = getProcDataType(column.dataType);
		}
		column.format = format;
		column.dataType = dataType;
		addCustomColumn(column);
	}
}
function actionEvent() {
	$("#action-available").kendoSortable({
	// connectWith: "#action-selected",
	placeholder : placeholder,
	cursor : "move",
	change : function(e) {
			if(e.oldIndex >= 0 && e.newIndex < 0) { // remove item
			} else if(e.newIndex >= 0 && e.oldIndex < 0) { // add item
			}
		}
	});

	$("#action-selected").kendoSortable({
	// connectWith: "#action-available",
	placeholder : placeholder,
	cursor : "move",
	change : function(e) {
			if(e.oldIndex >= 0 && e.newIndex < 0) { // remove item
			} else if(e.newIndex >= 0 && e.oldIndex < 0) { // add item
			}
		}
	});
}
function columnEvent() {
	$("#column-available").kendoSortable({
	// connectWith: "#column-selected",
	placeholder : placeholder,
	cursor : "move",
	change : function(e) {
			if(e.oldIndex >= 0 && e.newIndex < 0) { // remove item
			} else if(e.newIndex >= 0 && e.oldIndex < 0) { // add item
			}
		}
	});

	$("#column-selected").kendoSortable({
	// connectWith: "#column-available",
	placeholder : placeholder,
	cursor : "move",
	disabled : ".disabled",
	change : function(e) {
			if(e.oldIndex >= 0 && e.newIndex < 0) { // remove item
			} else if(e.newIndex >= 0 && e.oldIndex < 0) { // add item
			}
		}
	});
}
function sortEvent() {
	//$("#sort-available").kendoSortable({
	//	// connectWith: "#column-selected",
	//	placeholder : placeholder,
	//	cursor : "move",
	//	change : function(e) {
	//		if(e.oldIndex >= 0 && e.newIndex < 0) { // remove item
	//		} else if(e.newIndex >= 0 && e.oldIndex < 0) { // add item
	//		}
	//	}
	//});

	$("#sort-selected").kendoSortable({
		// connectWith: "#column-available",
		placeholder : placeholder,
		cursor : "move",
		disabled : ".disabled",
		change : function(e) {
			if(e.oldIndex >= 0 && e.newIndex < 0) { // remove item
			} else if(e.newIndex >= 0 && e.oldIndex < 0) { // add item
			}
		}
	});
}
function placeholder(element) {
	return $("<li class='list-item dropPlace' id='placeholder'>"+DROP_HERE+"</li>");
}
function updateBcName() {
	var bcName = $("#bcName").val();
	$('#bcTitle').html(bcName);
}

function disableAction() {
	$('#actionId').prop("disabled", true);
	$('#actionName').prop("disabled", true);
	$('#actionIsToolbarItem').prop("disabled", true);
	$('#actionType').prop("disabled", true);
	$('#actionIcon').prop("disabled", true);
	$('#actionHandler').prop("disabled", true);
	$('#actionClass').prop("disabled", true);
}

function enableAction() {
	$('#actionId').prop("disabled", false);
	$('#actionName').prop("disabled", false);
	$('#actionIsToolbarItem').prop("disabled", false);
	$('#actionType').prop("disabled", false);
	$('#actionIcon').prop("disabled", false);
	$('#actionHandler').prop("disabled", false);
	$('#actionClass').prop("disabled", false);
}

// action step
function clearAction() {
	$('#actionId').val("");
	$('#actionName').val("");
	$('#actionIsToolbarItem').val("");
	$('#actionType').val("");
	$('#actionIcon').val("");
	$('#actionHandler').val("");
	$('#actionClass').val("");
	$("#selectedActionName").html("");
}
function setAction() {
	if("action-selected" == selectedActionLi.parent().attr("id")) {
		var prop = selectedActionLi.data("bf-prop");
		$('#actionId').val(prop.actionid);
		$('#actionName').val(prop.title);
		$('#actionIsToolbarItem').val(""+prop.isToolbarItem);
		$('#actionType').val(prop.type);
		$('#actionIcon').val(prop.icon);
		$('#actionHandler').val(prop.handler);
		$('#actionClass').val(prop.cls);
		if(selectedPrevActionLi) {
			selectedPrevActionLi.toggleClass("list-item-selected list-item");
			selectedPrevActionLi.attr("onclick","onclickActionLi(this);");
		}
		selectedPrevActionLi = selectedActionLi;
		selectedActionLi.toggleClass("list-item list-item-selected");
		selectedActionLi.attr("onclick","void(0)");
		if("icon" == prop.type) {
			var src = "";
			if(prop.icon) {
				src = themeBasePath + "/icons/" + prop.icon;
			} else {
				src = themeBasePath + "/icons/blankicon.gif";
			}
			$("#actionIconView").attr("src", src);
			$("#actionIconSelection").show();
		} else {
			$("#actionIconSelection").hide();
		}
		// Change ICON menu
		updateActionItem('actionIcon');
		if(prop.custom) {
			$('#actionId').prop('readonly', false);
		} else {
			$('#actionId').prop('readonly', true);
		}
		$("#selectedActionName").html(prop.title);
	}
	//else {
	//	disableAction();
	//	selectedActionLi = "";
	//}
}
//function updateAction(part) {
	//for (var i = 1; i <= 6; i++) {
	//	updateActionItem(i);
	//}
//}
var oldActionTitle = "";
function updateActionItem(part) {
	if(!selectedActionLi) {
		return;
	}
	var prop = selectedActionLi.data('bf-prop');
	var $sourceObj = $('#' + part);
	switch (part) {
	case 'actionId':
		prop.actionid = $sourceObj.val();
		break;
	case 'actionName':
		oldActionTitle = prop.title;
		selectedActionLi.find('a').html($sourceObj.val());
		$("#selectedActionName").html($sourceObj.val());
		prop.title = $sourceObj.val();
		updateLinkedAction(oldActionTitle, prop.title);
		break;
	case 'actionIsToolbarItem':
		prop.isToolbarItem = $sourceObj.val();
		break;
	case 'actionType':
		prop.type = $sourceObj.val();
		if("icon" == $sourceObj.val()) {
			var actionIcon = $('#actionIcon').val();
			var src = "";
			if(actionIcon) {
				src = themeBasePath + "/icons/" + actionIcon;
			} else {
				src = themeBasePath + "/icons/blankicon.gif";
			}
			$("#actionIconView").attr("src", src);
			$("#actionIconSelection").show();
		} else {
			$("#actionIconSelection").hide();
		}
		break;
	case 'actionIcon':
		prop.icon = $sourceObj.val();
		break;
	case 'actionHandler':
		prop.handler = $sourceObj.val();
		break;
	case 'actionClass':
		prop.cls = $sourceObj.val();
		break;
	}
}
function getCustomActionStub()
{
	return {
		"resourceid" : {"sectionid":"","itemid":""},
		"actionid" : "",
		"useresourcebag" : false,
		"type" : "button",
		"cls" : "btn-primary",
		"title" : "Custom Action",
		"icon" : "",
		"handler" : "",
		"isToolbarItem" : true,
		"defaultSelected" : false,
		"custom" : true
	}
}
function addCustomAction(prop) {
	if(!isValidAction()) {
		return false;
	}
	var data = $.extend({}, getCustomActionStub(), typeof(prop) != 'undefined' ? prop : {});
	var item = $("<li>");
	item.attr("class", "list-item action-item");
	item.attr("onclick", "onclickActionLi(this)");
	item.data("bf-prop", data);
	item.append('<a class="list-item-title">' + data.title + '</a><div class="list-item-swap"  onclick="deleteCustom(this,\'action\');"><i class="fa fa-trash"></i>');

	var actionRight = $('#action-selected');
	actionRight.append(item);
	lastActionLi();
	setAction();
	enableAction();
	//updateAction();
}
function onclickActionLi(e) {
	var selectedLi = $(e).closest("li");
	var src = selectedLi.closest("ul").attr("id");
	if("action-selected" == src) {
		if(!isValidAction()) {
			return false;
		}
		selectedActionLi = selectedLi;
		enableAction();
		setAction();
	}
}
function lastActionLi() {
	var lastAction = $('#action-selected li:last');
	selectedActionLi = lastAction;
}
function moveAction(e) {
	var selectedLi =  $(e).closest("li");
	var src = selectedLi.closest("ul").attr("id");
	var salClone = selectedLi.clone();
	salClone.data('bf-prop',selectedLi.data('bf-prop') );

	if("action-available" == src) { // move right
		if(!isValidAction()) {
			return false;
		}
		selectedActionLi = selectedLi;
		$('#action-selected').append(salClone);
		$(selectedActionLi).remove();
		$('#action-selected li:last').find('i').toggleClass("fa-trash fa-arrow-right");
		lastActionLi();
		enableAction();
		setAction();
		//updateAction();
	} else { // move left
		$('#action-available').prepend(salClone);
		$(selectedLi).remove();
		var actionLeftFirst = $('#action-available li:first');
		actionLeftFirst.find('i').toggleClass("fa-trash fa-arrow-right");
		if(actionLeftFirst.hasClass("list-item-selected")) {
			actionLeftFirst.toggleClass("list-item-selected list-item");
			selectedActionLi = "";
			selectedPrevActionLi = "";
			clearAction();
			disableAction();
		}
		else {
			var existSelected = false;
			$("#action-selected li").each(function (i) {
				var actionLi = $(this);
				if(actionLi.hasClass("list-item-selected")) {
					existSelected = true;
				}
			});
			if (!existSelected) {
				selectedActionLi = "";
				selectedPrevActionLi = "";
				clearAction();
				disableAction();
			}
//			selectedActionLi = "";
//			selectedPrevActionLi = "";
//			clearAction();
//			disableAction();
		}
	}
}
function unselectAction() {
	$("#action-selected li").each(function (i) {
		var actionLi = $(this);
		if(actionLi.hasClass("list-item-selected")) {
			actionLi.toggleClass("list-item list-item-selected");
			actionLi.attr("onclick","onclickActionLi(this);");
		}
		selectedActionLi = "";
		selectedPrevActionLi = "";
		clearAction();
		disableAction();
	});
}
function deleteCustom(e, option) {
	var deleteConfirm = confirm(MSG_CMM_FORCE_CONFIRM_DELETE);
	if (deleteConfirm) {
		var selectedLi = $(e).closest("li");
		selectedLi.remove();
		if("action" == option) {
			var existSelected = false;
			$("#action-selected li").each(function (i) {
				var actionLi = $(this);
				if(actionLi.hasClass("list-item-selected")) {
					existSelected = true;
				}
			});
			if (!existSelected) {
				selectedActionLi = "";
				selectedPrevActionLi = "";
				clearAction();
				disableAction();
			}
			else {
				//setAction();
			}

// //			selectedActionLi = "";
// 			clearAction();
// 			setAction();
		} else {
			var existSelected = false;
			$("#column-selected li").each(function (i) {
				var columnLi = $(this);
				if(columnLi.hasClass("list-item-selected")) {
					existSelected = true;
				}
			});
			if (!existSelected) {
				selectedColumnLi = "";
				selectedPrevColumnLi = "";
				clearColumn();
				disableColumn();
			}
			else {
				//setColumn();
			}
		}
	}
	else {
		return false;
	}
}
// column display
function disableColumn() {
	//clearColumn();
	$('#columnId').prop("disabled", true);
	$('#columnName').prop("disabled", true);
	$('#columnDisplayTitle').prop("disabled", true);
	$('#columnDataType').prop("disabled", true);
	$('#columnWidth').prop("disabled", true);
	$('#columnAlign').prop("disabled", true);
	$('#columnRenderer').prop("disabled", true);
	$('#columnClass').prop("disabled", true);
	$('#columnFilterable').prop("disabled", true);
	$('#columnSortable').prop("disabled", true);
	$('#columnLinkedAction').prop("disabled", true);
	$('#columnSearchable').prop("disabled", true);
	$('#dtFormat').prop("disabled", true);
	$('#numFormat').prop("disabled", true);
}
function enableColumn() {
	//clearColumn();
	$('#columnId').prop("disabled", false);
	$('#columnName').prop("disabled", false);
	$('#columnDisplayTitle').prop("disabled", false);
	$('#columnDataType').prop("disabled", false);
	$('#columnWidth').prop("disabled", false);
	$('#columnAlign').prop("disabled", false);
	$('#columnRenderer').prop("disabled", false);
	$('#columnClass').prop("disabled", false);
	$('#columnFilterable').prop("disabled", false);
	$('#columnSortable').prop("disabled", false);
	$('#columnLinkedAction').prop("disabled", false);
	$('#columnSearchable').prop("disabled", false);
	$('#dtFormat').prop("disabled", false);
	$('#numFormat').prop("disabled", false);
}
function showDataFormat(format) {
	if("clear"==format || "init"==format || "number"==format || "string"==format) {
		$('#dtFormat').hide();
		$('#numFormat').val('');
		$('#numFormat').show();
		$('#numFormat').prop("disabled", true);
	//} else if("number"==mode) {
	//	$('#dtFormat').hide();
	//	$('#numFormat').val("number");
	//	$('#numFormat').show();
	} else if("date"==format || "datetime"==format) {
		$('#numFormat').hide();
		$('#dtFormat').val(format);
		$('#dtFormat').show();
	}
}
function clearColumn() {
	$('#columnId').val("");
	$('#columnName').val("");
	$('#columnDisplayTitle').val("");
	$('#columnDataType').val("");
	$('#columnWidth').val("");
	$('#columnAlign').val("");
	$('#columnRenderer').val("");
	$('#columnClass').val("");
	$('#columnFilterable').val("");
	$('#columnSortable').val("");
	$('#columnLinkedAction').val("");
	$('#columnSearchable').val("");
	$('#columnSource').val("");
	$('#columnSourceDisplay').val("");
	$('#columnProcDataType').val("");
	$('#columnSourceScope').val("");
	$('#columnSourceScopeDisplay').val("");
	$("#selectedColumnName").html("");
}
function setColumn() {
//	if($("#action-selected li").length < 1) {
//		disableColumn();
//		return;
//	}
    if("column-selected" == selectedColumnLi.parent().attr("id")) {
        var prop = selectedColumnLi.data("bf-prop");
        $('#columnId').val(prop.field);
		$('#columnName').val(prop.title);
		$('#columnDisplayTitle').val(""+prop.displayTitle);
		$('#columnDataType').val(prop.dataType);
		$('#columnWidth').val(prop.width);
		$('#columnAlign').val(getStyleProperty(prop.attributes.style, "text-align", "left"));
		$('#columnRenderer').val(prop.renderer);
		$('#columnClass').val(prop.attributes.class);
		$('#columnFilterable').val(getColumnFilterable(prop.filterable));
		$('#columnSortable').val(""+prop.sortable);
		$('#columnSearchable').val(""+prop.searchable);
		$('#columnLinkedAction').val(prop.linkedAction);
		$('#columnSource').val(prop.source);
		$('#columnSourceDisplay').val(convertDisplayValue('columnSource', prop.source));
		$('#columnProcDataType').val(prop.procDataType);
		$('#columnSourceScope').val(prop.sourceScope);
		$('#columnSourceScopeDisplay').val(convertDisplayValue('columnSourceScope', prop.source, prop.sourceScope));

		if(prop.dataType && "DATE" == prop.dataType.toUpperCase()) {
			if(!prop.format) {
				prop.format = "datetime";
			}
			showDataFormat(prop.format);
		} else {
			showDataFormat("init");
		}

		if(selectedPrevColumnLi) {
			selectedPrevColumnLi.toggleClass("list-item-selected list-item");
			selectedPrevColumnLi.attr("onclick","onclickColumnLi(this);");
		}
		selectedPrevColumnLi = selectedColumnLi;
		selectedColumnLi.toggleClass("list-item list-item-selected");
		selectedColumnLi.attr("onclick","void(0)");
		if(prop.field) {
			$('#columnId').prop('readonly', true);
		}
		else {
			$('#columnId').prop('readonly', false);
		}
		var isActionColumn = prop.isActionColumn;
		if(prop.custom) {
			$('#columnId').removeAttr('readOnly');
		}
		if(isActionColumn == true) {
			$('*[role="columnField"]').hide();
			$('*[role="actionColumnField"]').show();
			$('#columnId').removeAttr('readOnly');

			$('#customActionList li').each(function (j) {
				$("input:checkbox[id='actionColumn" + j + "']").prop('checked', false);
			});

			var columnActions = prop.columnActions;
			if(columnActions.length > 0) {
				for (var i in columnActions) {
					var columnActionid = columnActions[i];// actionId
					$('#customActionList li').each(function (j) {
						if (columnActionid == $(this).data("actionid")) {
							$("input:checkbox[id='actionColumn" + j + "']").prop('checked', true);
						}
					});
				}
			} else {
				$('#customActionList li').each(function (j) {
					$("input:checkbox[id='actionColumn" + j + "']").prop('checked', false);
				});
			}
		}
		else {
			$('*[role="columnField"]').show();
			$('*[role="actionColumnField"]').hide();
		}

		if("bfindicator"==prop.field) {
			$('*[role="columnField"]').hide();
			$('*[role="attrField"]').hide();
		} else {
			$('*[role="columnField"]').show();
			$('*[role="attrField"]').show();
		}
		$("#selectedColumnName").html(prop.title);
	}
//	else {
//		disableColumn();
//		selectedColumnLi = "";
//	}
}
//function columnFilterConvert(s) {
//	if (s == 'Menu') {
//		var result = {'mode' : 'menu'};
//	}
//	else if (s == 'Excel') {
//		var result = {'multi' : true};
//	}
//	else {
//		var result = false;
//	}
//	return result;
//}
function updateColumnItem(part) {
	if(!selectedColumnLi) {
		return;
	}
	var prop = selectedColumnLi.data('bf-prop');
	var $sourceObj = $('#' + part);
	switch (part) {
	case 'columnName':
		selectedColumnLi.find('a').html($sourceObj.val());
		$("#selectedColumnName").html($sourceObj.val());
		prop.title = $sourceObj.val();
		break;
	case 'columnDisplayTitle':
		prop.displayTitle = $sourceObj.val();
		break;
	case 'columnSortable':
		prop.sortable = $sourceObj.val();
		break;
	case 'columnFilterable':
		prop.filterable = $sourceObj.val();//columnFilterConvert($sourceObj.val());
		break;
	case 'columnWidth':
		prop.width = $sourceObj.val();
		break;
	case 'columnAlign':
		prop.attributes.style = replaceStyleProperty(prop.attributes.style, "text-align", $sourceObj.val());
		break;
	case 'columnSearchable':
		prop.searchable = $sourceObj.val();
		break;
	case 'columnLinkedAction':
		prop.linkedAction = $sourceObj.val();
		break;
	case 'columnDataType':
		prop.dataType = $sourceObj.val();
		showDataFormat(prop.dataType); // Pass the Data Type instead of the Format
		break;
	case 'columnId':
		prop.field = $sourceObj.val();
		break;
	case 'columnRenderer':
		if(!prop.renderer) prop.renderer = "";
		prop.renderer = $sourceObj.val();
		break;
	case 'columnClass':
		prop.attributes.class = $sourceObj.val();
		break;
	case 'numFormat':
		prop.format = $sourceObj.val();
		break;
	case 'dtFormat':
		prop.format = $sourceObj.val();
		if(prop.format=='datetime') {
			prop.renderer = "bfDateAndTimeRenderer";
		} else {
			prop.renderer = "bfDateRenderer";
		}
		$('#columnRenderer').val(prop.renderer);
		break;
	case 'columnSource':
		prop.source = $sourceObj.val();
		break;
	case 'columnProcDataType':
		prop.procDataType = $sourceObj.val();
		break;
	case 'columnSourceScope':
		prop.sourceScope = $sourceObj.val();
		break;
	}
}
function updateColumnActionList(cb) {
	var prop = selectedColumnLi.data('bf-prop');
	//var li = $(cb).closest("li");
	//var actionid = li.data('actionid');
	//if($(cb).prop("checked")) {
	//	console.log("check: ", actionid);
	//} else {
	//	console.log("uncheck: ", actionid);
	//}
	prop.columnActions = [];

	$('#customActionList li').each(function(j) {
		var actionid = $(this).data("actionid");
		var cb = $(this).find("input");
		if($(cb).prop("checked")) {
			prop.columnActions.push(actionid);
		}
	});
}
function updateLinkedAction(oldActionTitle, newActionTitle){
	$("#column-selected li").each(function(i) {
		var prop = $(this).data("bf-prop");
		if(prop.linkedAction == oldActionTitle) {
			prop.linkedAction = newActionTitle;
		}
	});
	setColumnLinkedAction();
}

function getCustomColumnStub()
{
	return {
		"title" : "Custom Column",
		"displayTitle" : true,
		"filterable": {"mode": "menu"},
		"field" : "",
		"dataType" : "string",
		"width" : 100,
		"linkedAction" : "",
		"searchable" : false,
		"sortable" : true,
		"attributes" : {
			"class" : "table-cell",
			"style" : "text-align: left"
		},
		"source" : "column",
		"defaultSelected" : false,
		"custom" : true,
		"procDataType" : "D",
		"sourceScope" : "I"
	}
}
function addActionColumn() {
	if(!isValidColumn()) {
		return;
	}
	addCustomColumn({
		"title" : "Action Column",
		"filterable": {"mode": "menu"},
		"field" : "Action",
		"dataType" : "string",
		"width" : 150,
		"linkedAction" : "",
		"searchable" : false,
		"sortable" : false,
		"attributes" : {
			"class" : "table-cell",
			"style" : "text-align: left"
		},
		"source" : "Action",
		"defaultSelected" : false,
		"custom" : true,
		"columnActions" : [],
		"isActionColumn" : true
	});
}
function addCustomColumn(prop) {
	var data = $.extend({}, getCustomColumnStub(), typeof(prop) != 'undefined' ? prop : {});
	var item = $("<li>");
	item.attr("class", "list-item column-item");
	item.attr("onclick", "onclickColumnLi(this)");
	//item.bind("click", function(){onclickColumnLi(this)});
	item.data("bf-prop", data);
	item.append('<a class="list-item-title">' + data.title + '</a><div class="list-item-swap"  onclick="deleteCustom(this,\'column\');"><i class="fa fa-trash"></i>');

	var columnRight = $('#column-selected');
	columnRight.append(item);
	lastColumnLi();
	setColumn();
	enableColumn();
}
function onclickColumnLi(e) {
	var selectedLi = $(e).closest("li");
	var src = selectedLi.closest("ul").attr("id");
	if("column-selected" == src) {
		if(!isValidColumn()) {
			return;
		}
		selectedColumnLi = selectedLi;
		enableColumn();
		setColumn();
	}
}
function lastColumnLi() {
	var lastColumn = $('#column-selected li:last');
	selectedColumnLi = lastColumn;
}
function moveColumn(e) {
	var selectedLi = $(e).closest("li");
	var src = selectedLi.closest("ul").attr("id");
	var salClone = selectedLi.clone();
	salClone.data('bf-prop',selectedLi.data('bf-prop') );

	if("column-available" == src) { // move to right
		if(!isValidColumn()) {
			return false;
		}
		selectedColumnLi = selectedLi;
		$('#column-selected').append(salClone);
		$(selectedColumnLi).remove();
		$('#column-selected li:last').find('i').toggleClass("fa-trash fa-arrow-right");
		lastColumnLi();
		enableColumn();
		setColumn();
	} else { // move to left
		$('#column-available').prepend(salClone);
		$(selectedLi).remove();
		var columnLeftFirst = $('#column-available li:first');
		columnLeftFirst.find('i').toggleClass("fa-trash fa-arrow-right");
		if(columnLeftFirst.hasClass("list-item-selected")) {
			columnLeftFirst.toggleClass("list-item-selected list-item");
			selectedColumnLi = "";
			selectedPrevColumnLi = "";
			clearColumn();
			disableColumn();
		}
		else {
			var existSelected = false;
			$("#column-selected li").each(function (i) {
				var columnLi = $(this);
				if(columnLi.hasClass("list-item-selected")) {
					existSelected = true;
				}
			});
			if (!existSelected) {
				selectedColumnLi = "";
				selectedPrevColumnLi = "";
				clearColumn();
				disableColumn();
			}
//			selectedPrevColumnLi = selectedColumnLi;
//			selectedColumnLi = "";
//			//clearColumn();
//			//disableColumn();
		}
	}
}
function unselectColumn() {
	$("#column-selected li").each(function (i) {
		var columnLi = $(this);
		if(columnLi.hasClass("list-item-selected")) {
			columnLi.toggleClass("list-item list-item-selected");
			columnLi.attr("onclick","onclickColumnLi(this);");
		}
		selectedColumnLi = "";
		selectedPrevColumnLi = "";
		clearColumn();
		disableColumn();
	});
}
function setColumnLinkedAction() {
	var cLinkedAction = $('#columnLinkedAction');
	cLinkedAction.html("");
	cLinkedAction.append('<option value=""></option>');
	$("#action-selected li").each(function(i) {
		var aID = $(this).data('bf-prop').actionid;
		var aName = $(this).data('bf-prop').title;
		cLinkedAction.append('<option value="' + aID + '">' + aName + '</option>');
	});
	if(selectedColumnLi) {
		setColumn();
	}
}
function redrawSortPreference() {
	// clear prior items
	var availableSortColumnList = $("#sort-available");
	availableSortColumnList.html("");

	// Copy from selected columns
	$("#column-selected li").each(function(i) {
		var propL = $(this).data("bf-prop");
		var item = $("<li onclick=''>");
		item.attr("class", "list-item column-item sortColumn");
		item.attr("bf-fieldName", propL.field);
		item.append('<a class="list-item-title">' + propL.title + '</a><input type="checkbox" class="sortDirectionSW"><span class="btn sortBtn sortDesc " onclick="setColumnSortOrder(\'' + propL.field + '\',\'desc\')">Descending</span><span class="btn sortBtn sortAsc active" onclick="setColumnSortOrder(\'' + propL.field + '\',\'asc\')">Ascending</span><div class="list-item-swap" onclick="moveSortColumn(this, true);"><i class="fa fa-arrow-right"></i></div>');
		availableSortColumnList.append(item);
	});
	var defaultSortShow = true;
	// Adjust
	$("#sort-selected li").each(function () {
		var selectedFieldName = $(this).attr("bf-fieldName");
		var isAscendingOrder = $(this).find('.sortDirectionSW').prop('checked');
		var found = false;
		$("#sort-available li").each(function() {
			var availableFieldName = $(this).attr("bf-fieldName");
			if (selectedFieldName == availableFieldName) {
				found = true;
				return false;
			}
		});

		$('#sort-selected li[bf-fieldName='+selectedFieldName+']').remove();

		if(found) {
			moveSortColumn($('#sort-available li[bf-fieldName='+selectedFieldName+']').find('.list-item-swap'), isAscendingOrder);
			found=false;
			defaultSortShow = false;
			return false;
		}
	});

	if(defaultSortShow) {
		bizcoveInstance.setDefaultSort();
	}
}
function setColumnSortOrder(field, order)
{
	var e = $('#sort-selected li[bf-fieldName='+field+']');
	if("asc" == order)
	{
		var target = e.find('.sortAsc');
		target.siblings('.sortDirectionSW').prop('checked',true);
		target.siblings('.sortDesc').removeClass('active');
		target.addClass('active');
	}
	else
	{
		var target = e.find('.sortDesc');
		target.siblings('.sortDirectionSW').prop('checked',false);
		target.siblings('.sortAsc').removeClass('active');
		target.addClass('active');
	}
}

function moveSortColumn(e, cb) {
	var selectedLi =  $(e).closest("li");
	var src = selectedLi.closest("ul").attr("id");
	var salClone = selectedLi.clone();
	var fieldName = selectedLi.attr('bf-fieldName');
	salClone.attr('bf-fieldName', fieldName );

	if("sort-available" == src) { // move right
		if(1 <= $('#sort-selected li').length)
		{
			notify(ONLY_ONE_COLUMN_IS_ALLOWED, validationNotifyOpts);
			return false;
		}

		if(0 == $('#sort-selected li[bf-fieldName='+fieldName+']').length) {
			$('#sort-selected').append(salClone);
			var lastLi = $('#sort-selected li:last');
			lastLi.find('.sortBtn').show();
			lastLi.find('i').toggleClass("fa-trash fa-arrow-right");
			setColumnSortOrder(fieldName, (cb?"asc":"desc"));
			//lastLi.find('.sortDirectionSW').prop("checked", cb); //true: asc, false: desc
			//if(cb) {
			//	lastLi.find('.sortAsc').addClass('active');
			//	lastLi.find('.sortDesc').removeClass('active');
			//} else {
			//	lastLi.find('.sortAsc').removeClass('active');
			//	lastLi.find('.sortDesc').addClass('active');
			//}
		}
		$(selectedLi).remove();
	} else { // move left
		$('#sort-available').prepend(salClone);
		$(selectedLi).remove();
		var sortLeftFirst = $('#sort-available li:first');
		sortLeftFirst.find('.sortBtn').hide();
		sortLeftFirst.find('i').toggleClass("fa-trash fa-arrow-right");
	}
}
function moveSortColumnTrigger(field, dir) {
	var column = $('#sort-available li[bf-fieldName='+field+']');
	if(column.length)
	{
		var sourceLocation = column.find("div.list-item-swap");
		moveSortColumn(sourceLocation, ("asc" == dir));
	}
}
//function getSelectedColumnActions() {
//	var columnActions = $('#columnActions');
//	columnActions.html("");
//	columnActions.append('<option value=""></option>');
//	$("#action-selected li").each(function(i) {
//		var aID = $(this).data("bf-prop").actionid;
//		var aName = $(this).data("bf-prop").title;
//		var aDisplayAt = $(this).data('bf-prop').isToolbarItem;
//		if(aDisplayAt.indexOf("Column") != -1) {
//			columnActions.append('<option value="' + aID + '">' + aName + '</option>');
//		}
//	});
//}
/*function addColumnActions() {
	var action = $('#columnActions').val();
	$("#selectedColumnActions").append("<li class='sortable'>" + action + "<span class='rightAlign deleteRightDelete' onclick='javascript:removeColumnActions(this);'></span></li>");
}
function removeColumnActions(e) {
	var selectedLi = $(e).closest("li");
	selectedLi.remove();
}*/
var iconTarget = "";
function showIcon(iconFile, reset) {
	if(0<iconFile.length)
	{
		var src = themeBasePath + "/icons/" + iconFile;
		$("#" + iconTarget + "View").attr("src", src);
		$("#" + iconTarget).val(iconFile);
		if(reset) $("#iconResetBtn").show();
		else {
			$("#iconResetBtn").hide();
		}
	}
}
function selectIcon(target) {
	iconTarget = target;
	IconModal.refresh(contextPath + "/bizcoves/user/bizcoves/fileview.jsp?dir="+themeDir+"/icons");
	IconModal.center().open();
}
function okIconBtn() {
	var iconFile = $('#iconFrame').contents().find(':radio[name="imageSrc"]:checked').val();
	showIcon(iconFile, true);
	updateActionItem('actionIcon');
	cancelIconBtn();
}
function cancelIconBtn() {
	IconModal.close();
}
function resetIcon(target) {
	iconTarget = target;
	showIcon("blankicon.gif", false);
	var iconFile = "";
	$("#" + iconTarget).val("");
}
//function selfClose() {
//	var isModal = isModalWindowMode();
//	if(isModal) {
//		closeWindow();
//	}
//	else {
//		this.close();
//	}
//}
var isPreview = false;

function submitJSON(JSONString) {
	$.ajax({
		type : "POST",
		cache: false,
		url : contextPath + "/portal/bizcove/worklist/worklistaction.jsp",
		data : {"worklistJSON":encodeURIComponent(JSONString)},
		dataType : "text",
		async : true
	}).done(function(data) {
		var jsonStr = data.replace(/[\r|\n|\t]/g, '');
		var rc = JSON.parse(jsonStr);
		if(!isPreview) {
			if(!rc.success) {
				alert(rc.message);
				notifyInternalServerError();
			}
			var caller = getModalCaller();
			caller.reload();
			closeWindow();
		} else { // for preview
			var previewId = rc.bizcoveid;
			previewing(previewId);
		}
	}).always(function() {
	}).fail(function(jqXHR, textStatus, errorThrown) {
		var errdata = JSON.stringify(jqXHR) + "\n" + textStatus + ': ' + errorThrown;
		notifyInternalServerError();
	});
}
function preview() {
	isPreview = true;
	$("#bizcoveid").val("PREVIEW");
	finish();
	unselectAction();
	unselectColumn();
}
function previewing(previewid) {
	var openURL = contextPath + "/portal/bizcove/worklist/page.jsp?bizcove="+previewid+"&viewMode=PREVIEW";
	wndPOPUP = openPopup(openURL, "Preview", "Preview", 1200, 540);
	$("#bizcoveid").val(bizcoveId);
	isPreview = false;
}
function showPVnAttr() {
	if(!isValidColumn()) {
		return;
	}
	var id = "PVnAttrModal_"+(new Date().getTime());
	PVnAttrModal = $("<div><iframe class='k-content-frame customColumnModal' name='" + id + "'></div>").kendoWindow({
		title : CONFIGURE_BIZCOVE_COLUMN,
		modal : true,
		resizable : false,
		visible : false,
		width : "900",
		height : "500",
		iframe : true
	}).data("kendoWindow");
	PVnAttrModal.open().center();
	$("<form />", {
		action: "customcolumn.jsp",
		method: "post",
		target: id
	}).hide().appendTo("body")
		.append("<input name='bizcoveType' />").find("[name=bizcoveType]").val("worklist").end()
		.submit().remove();
}

function closePvnAttrModal() {
	PVnAttrModal.close();
}

function changeCustomSQLlistEnable() {
	var selectSqlEnable = $("input:checkbox[id='customSQLselectEnable']").is(":checked");
	var selectEditor = ace.edit("customSQLEditor1stCodeEdit");

	// if(!selectSqlEnable) {
		// selectEditor.setReadOnly(true);
	// } else {
		// selectEditor.setReadOnly(false);
	// }
}

function changeCustomSQLcountEnable() {
	var countSqlEnable = $("input:checkbox[id='customSQLcountEnable']").is(":checked");
	var countEditor = getAceEditor("customSQLEditor2ndCodeEdit");

	// if(!countSqlEnable) {
		// countEditor.setReadOnly(true);
	// } else {
		// countEditor.setReadOnly(false);
	// }
}

function initCustomSQLParameterEditor() {
	$('.wzEnableHeaderIconCheckBox').change(function () {
		var iconContainer = $('.browseIconContainer');
		if ($('.wzEnableHeaderIconCheckBox').prop("checked")) {
			$(this).closest('.row').find(iconContainer).show(function () {
				$(this).fadeIn('200');
			});
		}
		else {
			$(this).closest('.row').find(iconContainer).hide(function () {
				$(this).fadeOut('200');
			});
		}
	});

	// CustomSQL - ACE Code Editor
	ace.config.set("basePath", contextPath + "/js/jquery/ace");
	var customSQLEditor1stCodeEdit = getAceEditor("customSQLEditor1stCodeEdit");
	customSQLEditor1stCodeEdit.setTheme("ace/theme/sqlserver");
	customSQLEditor1stCodeEdit.getSession().setMode("ace/mode/sql");
	customSQLEditor1stCodeEdit.setShowPrintMargin(false);
	customSQLEditor1stCodeEdit.getValue();

	//var customSQLEditor2ndCodeEdit = getAceEditor("customSQLEditor2ndCodeEdit");
	//customSQLEditor2ndCodeEdit.setTheme("ace/theme/sqlserver");
	//customSQLEditor2ndCodeEdit.getSession().setMode("ace/mode/sql");
	//customSQLEditor2ndCodeEdit.setShowPrintMargin(false);
	//customSQLEditor2ndCodeEdit.getValue();

	$('.customSQLParameterInput')
		.textext({
			plugins: 'tags arrow autocomplete'
		})
		.bind('getSuggestions', function (e, data) {
			var list = ['$$CURUSER','$$STARTROWNUM','$$ENDROWNUM'];
			var textext = $(e.target).textext()[0];
			var	query = (data ? data.query : '') || '';
			$(this).trigger(
				'setSuggestions',
				{result: textext.itemManager().filter(list, query)}
			);
		});
}
function checkCustomSQLEditorValue(id) {
	var aceEditor = getAceEditor(id);
	if (aceEditor.getValue() == "") {
		$("#" + id).addClass('customSQLEditor-empty');
	}
}
function customSQLCheckboxAutoEnable(id, checkbox) {
	if($("#"+id).length)
	{
		var aceEditor = getAceEditor(id);
		if(typeof(checkbox) != 'undefined')
		{
			aceEditor.on("change", function(){
				if ($("#" + id).hasClass('customSQLEditor-empty') && aceEditor.getValue().length == 0) {
					$("#" + id).parents('.tab-pane').find("input:checkbox[id='" + checkbox + "']").prop('checked', false);
				}
				else if ($("#" + id).hasClass('customSQLEditor-empty') && aceEditor.getValue().length > 0) {
					$("#" + id).parents('.tab-pane').find("input:checkbox[id='" + checkbox + "']").prop('checked', true);
				}
			})
		}
	}
}

function cancelCheckout(bizcoveid) {
	return callCheckIn(bizcoveid);
}
function callCheckIn(bizcoveid) {
	var isCheckIn = true;
	var forcedCheckout = false;
	return callCheckInOut(bizcoveid, isCheckIn, forcedCheckout);
}
function callCheckout(bizcoveid, forcedCheckout) {
	var isCheckIn = false;
	return callCheckInOut(bizcoveid, isCheckIn, forcedCheckout);
}

function callCheckInOut(bizcoveid, isCheckIn, forcedCheckout) {
	var returnVal = "-1";
	if(("" != bizcoveid)&&(null != bizcoveid)) {
		$.ajax({
			type: "GET"
			,cache: false
			,url: contextPath + "/portal/bizcove/worklist/checkoutaction.jsp"
			,data: {"bizcovetype":"5", "bizcoveid":bizcoveid, "checkIn":isCheckIn, "forcedCheckout":forcedCheckout}
			,async: false
		}).done(function(resultObj, status) {
			if(!resultObj) {
				return -1;
			}
			var checkoutUserID = isCheckIn ? "" : resultObj.checkoutuserid;
			if((status == "success") && (resultObj.success)) {
				returnVal = checkoutUserID;
				return returnVal;
			}
			else
			{
				//TODO: show a proper error message to end user
				//resultObjErrorMsg(resultObj.message);
//				notify(resultObj.message, "error");
				return resultObj.message;
			}
		}).always(function() {
		}).fail(function(jqXHR, textStatus, errorThrown) {
			notifyInternalServerError();
			return "-1";
		});
	}
	return returnVal;
}

function initCustomSQL()
{
	var params = bizcoveInstance.get("sql.list.parameter");
	var $customSQLParameter = $("#customSQLParameter1");
	if($customSQLParameter.length) {
		$customSQLParameter.textext()[0].tags().addTags(params);
	}

	params = bizcoveInstance.get("sql.count.parameter");
	$customSQLParameter = $("#customSQLParameter2");
	if($customSQLParameter.length) {
		$customSQLParameter.textext()[0].tags().addTags(params);
	}
}

function createUpdate() {
	$("#finishBtn").attr("disabled", true);
	$("#bizcoveid").val(bizcoveId);
	finish();
	$("#finishBtn").attr("disabled", false);
}

function finish() {

	redrawSortPreference();

	if(!validationCheck()) {
		return;
	}
	bizcoveInstance.setString("bizcoveid",$("#bizcoveid").val());
	bizcoveInstance.setString("type",$("#bcType").val());
	bizcoveInstance.setString("name",$("#bcName").val());
	bizcoveInstance.setString("icon",$("#headerIcon").val());
	bizcoveInstance.setString("description",$("#description").val());
	bizcoveInstance.setString("theme",$("#theme").val());
	bizcoveInstance.setNumber("refreshInterval",$("#refreshInterval").val());
	bizcoveInstance.setNumber("defaultInterval",$("#defaultInterval").val());

	var externalResource = bizcoveInstance.get("external");
	if(externalResource) {
		externalResource.js = [];
		$("input[name=jsURL]").each(function (i, obj) {
			var val = $(this).val();
			if (val.trim() != '') {
				externalResource.js.push(val);
			}
		});
		externalResource.css = [];
		$("input[name=cssURL]").each(function(i, obj) {
			var val = $(this).val();
			if(val.trim() != '')
			{
				externalResource.css.push(val);
			}
		});
	}

	bizcoveInstance.setBoolean("scope.type.organizationUnitWork", $("input:checkbox[name='SCOPE_TYPE_ORGANIZATIONUNITWORK']").is(":checked"));
	bizcoveInstance.setBoolean("scope.type.tasksSent", $("input:checkbox[name='SCOPE_TYPE_TASKSSENT']").is(":checked"));
	bizcoveInstance.setBoolean("scope.type.delegatedWork", $("input:checkbox[name='SCOPE_TYPE_DELEGATEDWORK']").is(":checked"));
	bizcoveInstance.setBoolean("scope.type.groupWork", $("input:checkbox[name='SCOPE_TYPE_GROUPWORK']").is(":checked"));
	bizcoveInstance.setBoolean("scope.type.myWork", $("input:checkbox[name='SCOPE_TYPE_MYWORK']").is(":checked"));
	bizcoveInstance.setBoolean("scope.type.recallableWork", $("input:checkbox[name='SCOPE_TYPE_RECALLABLEWORK']").is(":checked"));
	bizcoveInstance.setBoolean("layout.groupable",( $("#groupable").val() == "true"));
	bizcoveInstance.setBoolean("layout.quickSearch",( $("#enableQuickSearch").val() == "true"));
	bizcoveInstance.setBoolean("layout.contextMenu",( $("#enableContextMenu").val() == "true"));

	var pageable = true;
	if($("#pageable").val() == "false") pageable = false;
	var pageSize = $("#pageSize").val();
	if(isNaN(pageSize)) pageSize = 10;
	var listHeight = (pageSize*40) + 120; // 120 means menu and header's height
	if(listHeight < 150) listHeight = 520;
	if(pageable) listHeight += 35; // 35 means tail's height
	bizcoveInstance.setBoolean("layout.pageable", pageable);
	bizcoveInstance.setString("layout.selectable", "multiple");
	bizcoveInstance.setNumber("layout.pageSize", pageSize);
	bizcoveInstance.setNumber("layout.height", listHeight);
	bizcoveInstance.setJSONobject("layout.sortable", {"allowUnsort":false});

	var actionArray = new Array();
	$("#action-selected li").each(function(i) {
		selectedActionLi = $(this);
		var prop = selectedActionLi.data("bf-prop");
		prop.defaultSelected = true;
		prop.isToolbarItem = (typeof prop.isToolbarItem == 'boolean') ? prop.isToolbarItem : (prop.isToolbarItem!="false");	// set default value as true
		actionArray.push(prop);
	});
	bizcoveInstance.setJSONobject("actions", actionArray);
	var columnArray = [];
	var fieldArray = [];
	var sortArray = [];
	$("#column-selected li").each(function(i) {
		selectedColumnLi = $(this);
		var prop = selectedColumnLi.data("bf-prop");
		prop.defaultSelected = true;
		if (typeof prop.field != 'undefined') {
			prop.field = prop.field.toLowerCase();
		}
		if(typeof prop.displayTitle != 'boolean') {
			prop.displayTitle = (prop.displayTitle=="true");
		}
		if(typeof prop.sortable != 'boolean') {
			prop.sortable = (prop.sortable=="true");
		}
		if(typeof prop.searchable != 'boolean') {
			prop.searchable = (prop.searchable=="true");
		}
		if(!prop.renderer) {
			prop.renderer = "";
		}
		if("bfindicator" == prop.field) {
			bizcoveInstance.setBoolean("layout.selectable", false);
		}

		var column={"title": prop.title,
					"displayTitle": Boolean(prop.displayTitle),
					"field": prop.field,
					"width": Number(prop.width),
					"sortable": Boolean(prop.sortable),
					"linkedAction": prop.linkedAction,
					"searchable": Boolean(prop.searchable),
					"template": prop.template,
					"attributes": prop.attributes,
					"filterable": getColumnFilterable(prop.filterable),
					"source": prop.source,
					"dataType": prop.procDataType,
					"defaultSelected": prop.defaultSelected,
					"custom" : prop.custom,
					"sourceScope": prop.sourceScope,
					"columnActions" : prop.columnActions,
					"isActionColumn": prop.isActionColumn,
					"renderer": prop.renderer};
		var field ={"field": prop.field,
					"format": ""+ (prop.format ? prop.format : ""),
					"type": ""+prop.dataType};
		columnArray.push(column);
		fieldArray.push(field);
	});
	bizcoveInstance.setJSONobject("datasource.schema.fields", fieldArray);
	bizcoveInstance.setJSONobject("columns", columnArray);

	$("#sort-selected li").each(function(i) {
		var checked = $(this).find('.sortDirectionSW').is(":checked");
		var dir = checked ? "asc" : "desc";
		var field = $(this).attr("bf-fieldName");
		var sortObj = { "field": field, "dir": dir };
		sortArray.push(sortObj);
	});
	bizcoveInstance.setJSONobject("datasource.sort", sortArray);

	var maxNumOfRows = $("#maxNumOfRows").val();
	if(isNaN(maxNumOfRows)) maxNumOfRows = 1000;
	bizcoveInstance.setNumber("datasource.maxNumOfRows", maxNumOfRows);

	if(!bizcoveInstance.get("sql")) { // Not exist SQL key
		var sqlObject =	{ "enable" : false, "list" : { "text" : "", "parameter" : [] }, "count" : { "enable" : false, "text" : "", "parameter" : [] } };
		bizcoveInstance.addJSONObject("","sql",sqlObject);
	}
	
	var selectSqlEnable = $("input:checkbox[id='customSQLselectEnable']").is(":checked");
	var selectEditor = getAceEditor("customSQLEditor1stCodeEdit");
	var selectSQL = selectEditor.getValue();
	bizcoveInstance.setBoolean("sql.enable",selectSqlEnable);
	bizcoveInstance.setString("sql.list.text",selectSQL);
	var param1Array = $("#customSQLParameter1").textext()[0];
	param1Array = JSON.parse(param1Array.hiddenInput().val());
	bizcoveInstance.setJSONobject("sql.list.parameter",param1Array);

	var countSqlEnable = $("input:checkbox[id='customSQLcountEnable']").is(":checked");
	var countEditor = getAceEditor("customSQLEditor2ndCodeEdit");
	if(typeof(countEditor) != 'undefined')
	{
		var countSQL = countEditor.getValue();
		countSQL = JSON.stringify(countSQL).replace(/\"/g,"");
		bizcoveInstance.setBoolean("sql.count.enable",countSqlEnable);
		bizcoveInstance.setString("sql.count.text",countSQL);
		var param2Array = $("#customSQLParameter2").textext()[0];
		param2Array = JSON.parse(param2Array.hiddenInput().val());
		bizcoveInstance.setJSONobject("sql.count.parameter",param2Array);
	}

    submitJSON(JSON.stringify(bizcoveInstance.getJSON()));
}
function checkCheckoutStatus(bizcoveid, loginID) {
	var checkoutUserID = callCheckout(bizcoveid, false);

	if(checkoutUserID && (checkoutUserID != loginID)) {
		if (confirm(BIZCOVE_FORCE_CHECKOUT)) {
			callCheckout(bizcoveid, true);
		}
		else {
			closeWindow();
		}
	}
}
var javascriptFunctionNameJSExp = /^(?!(?:do|if|in|for|let|new|try|var|case|else|enum|eval|null|this|true|void|with|await|break|catch|class|const|false|super|throw|while|yield|delete|export|import|public|return|static|switch|typeof|default|extends|finally|package|private|continue|debugger|function|arguments|interface|protected|implements|instanceof)$)(?:[\$A-Z_a-z])(?:[\$0-9A-Z_a-z])*$/
function isValidJavaScriptVariableName(name)
{
	return (typeof(name) == 'string')?javascriptFunctionNameJSExp.test(name.trim()):false;
}

function convertDisplayValue(category, val1, val2)
{
	if("columnSource" == category)
	{
		return COLUMN_SOURCE_VALUE[val1.toLowerCase()];
	}
	else if(("columnSourceScope" == category) && ("pv" == val1 || "ca" == val1))
	{
		// source + sourceScope
		var val = val1.toLowerCase() + val2.toUpperCase();
		return COLUMN_SOURCE_SCOPE_VALUE[val];
	}
	return undefined;
}
function refreshActionColumn() {
	$('#customActionList').html('');
	var customActionListObj = $('#customActionList');
	$("#action-selected li").each(function(i) {
		var actionLi = $(this);
		var prop = actionLi.data("bf-prop");
		var item = $('<li>');
			item.data("actionid", prop.actionid);
			item.append('<input id="actionColumn' + i + '" onclick="updateColumnActionList(this)" type="checkbox" hidden><label for="actionColumn' + i + '">' + prop.title + '</label>');
			customActionListObj.append(item);
		//selectedActionLi = "";	// don't delete this line for validation logic.
	});
}
$(document).ready(function() {
	customSQLCheckboxAutoEnable("customSQLEditor1stCodeEdit");
	customSQLCheckboxAutoEnable("customSQLEditor2ndCodeEdit", "customSQLcountEnable");
	$('#columnDisplayTabBtn').click(function() {
		refreshActionColumn();
	});
});
