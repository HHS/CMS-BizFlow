IF EXISTS (SELECT * FROM dbo.sysobjects WHERE id = object_id(N'[dbo].[fn_get_inherited_groups]'))
DROP FUNCTION [dbo].[fn_get_inherited_groups]
GO

CREATE FUNCTION fn_get_inherited_groups
(
	@i_memberid		VARCHAR(10)
)
RETURNS @tab_inherited_groups TABLE
(
	memberid		VARCHAR(10)
)
AS
-- Version 12.4.0.0007.00
BEGIN
	WITH inh_group(usrgrpid, parentid, inherittype)
	AS
	(
		SELECT convert(varchar(10), dept.memberid), convert(varchar(10), dept.parentdeptid), convert(char(1), dept.inherittype)
		  FROM member dept, member deptmember
		 WHERE deptmember.memberid = @i_memberid
		   AND dept.memberid = deptmember.deptid
		   AND dept.type = 'D'
		 UNION ALL
		SELECT grp.memberid, grp.parentdeptid AS parentid, grp.inherittype
		  FROM member grp, usrgrpprtcp grpmember
		 WHERE grpmember.prtcp = @i_memberid
		   AND grp.memberid = grpmember.usrgrpid
		   AND grp.type = 'G'
		 UNION ALL
		SELECT v.memberid, v.parentdeptid AS parentid, convert(char(1), v.inherittype)
		  FROM vusrgrp v, inh_group g
		 WHERE v.memberid = g.parentid
		   AND g.inherittype IN ('U', 'B', 'P', 'Q')
	)
	INSERT @tab_inherited_groups
	SELECT distinct usrgrpid FROM inh_group

	RETURN
END
