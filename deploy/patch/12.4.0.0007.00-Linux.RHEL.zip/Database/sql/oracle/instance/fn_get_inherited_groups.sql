DECLARE I_COUNT NUMBER;
BEGIN

SELECT COUNT(1) INTO I_COUNT FROM USER_OBJECTS WHERE UPPER(OBJECT_NAME) = 'GROUP_TYPE2_COLL';
IF I_COUNT = 1 THEN
DBMS_OUTPUT.PUT_LINE('Dropping type (group_type2_coll)');
EXECUTE IMMEDIATE '
    drop type group_type2_coll
';
END IF;

END;
/

CREATE OR REPLACE TYPE group_type2 IS OBJECT
(
    memberid VARCHAR2(10)
);
/

CREATE OR REPLACE TYPE group_type2_coll AS TABLE OF group_type2;
/

CREATE OR REPLACE FUNCTION fn_get_inherited_groups(
    i_memberid IN VARCHAR2)
RETURN group_type2_coll
AS
    groups group_type2_coll;
-- Version 12.4.0.0007.00
BEGIN
    SELECT group_type2(g.memberid)
      BULK COLLECT INTO groups
      FROM (SELECT distinct dept.memberid, dept.parentdeptid, dept.inherittype
              FROM vusrgrp dept
              LEFT JOIN member deptmember ON dept.memberid = deptmember.deptid
        START WITH deptmember.memberid = i_memberid
               AND deptmember.type = 'U'
               AND dept.type = 'D'
        CONNECT BY PRIOR dept.parentdeptid = dept.memberid
               AND PRIOR dept.inherittype IN ('U', 'B', 'P', 'Q')
         UNION ALL
            SELECT distinct grp.memberid, grp.parentdeptid, grp.inherittype
              FROM vusrgrp grp
              LEFT JOIN usrgrpprtcp grpmember ON grp.memberid = grpmember.usrgrpid
        START WITH grpmember.prtcp = i_memberid
               AND grpmember.prtcptype = 'U'
               AND grp.type = 'G'
        CONNECT BY PRIOR grp.parentdeptid = grp.memberid
               AND PRIOR grp.inherittype IN ('U', 'B', 'P', 'Q')
           ) g;
    RETURN groups;
END;
/