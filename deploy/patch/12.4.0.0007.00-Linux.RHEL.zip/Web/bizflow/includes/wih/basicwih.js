var contextPath = '/bizflow';
var wihDiscussion;
var useAccessibility = false;
var useLayoutFramework = false;
var _readCommentRequired = false;
var _readComment = false;
var _readOnly =false;
var _lastUpdatedTimeKey='';
var _responseMenu;
var _mainToolbar;
var outerLayout;
var innerLayout;
var responseGroup = [];
var currentResponseId = null;
var currentUserId = null;
var layoutStore = null;
var layoutStateId = "WIH";
var wihLayoutState = {};
var workitemContextInfo = undefined;
var processId = 0;
var workId = 0;
var PANE_INSTRUCTION = "instruction";
var PANE_TOOL = "tool";
var PANE_PROCESS_MAP = "processMap";
var PANE_CONTEXT_INFORMATION = "contextInformation";
var PANE_MENU = "menu";
var PANE_ATTACHMENT = "attachment";
var PANE_INTERNAL_DISCUSSION = "internalDiscussion";
var PANE_CORRESPONDENCE = "correspondence";

$(window).resize(function () {
	try
	{
		if(window.resizeContents)
		{
			setTimeout(resizeContents, 500);
		}
		if(window.resizeEastToggleBttton)
		{
			resizeEastToggleBttton();
		}
		if(window.hideAppListBox)
		{
			hideAppListBox();
		}
	}
	catch(e){alert(e)}
});

//function changeWIHBodySize() {
//    if (document.all) {
//        var ieVersion = getTopBrowserVersion();
//        if (ieVersion == 9) {
//            var wihBody = $object("wihBody");
//            var wihToolbarBox = $object("wihToolbarBox");
//            if (wihBody && wihToolbarBox) {
//                var offset = 0;
//                var height = document.body.clientHeight - wihToolbarBox.clientHeight - offset;
//                wihBody.style.height = height + "px";
//            }
//        }
//    }
//}
var showSupplementalToolsToggleBar = true;
var showInstructionToggleBar = true;
var displayStatus = {isMaxApp:false, menuToolbar:true, instruction:true, supplementalTools:false, contextInfo:true, processDiagram:true};
var supplementalToolBoxWin;
function showSupplementalTools(app)
{
	showSupplementalToolsToggleBar = true;
	if(useLayoutFramework)
	{
        var westPanel = Ext.getCmp('uiLayoutWestPanel');
        if(westPanel) {
            westPanel.expand();
            if(app == 'discussion')
            {
                setFocusToDiscussion();
            }
        }
	}
	else
	{
		if(!supplementalToolBoxWin)
		{
			$("#wihSupplementalTools").show();
			supplementalToolBoxWin = new Ext.Window({
				autoHeight: true,
				modal: false,
				closeAction: 'hide',
				x:0,
				y:36,
				width: 262,
				height: 590,
				autoScroll:false,
				resizable: false,
				contentEl: 'wihSupplementalTools'
			});
		}
		if(app == 'discussion')
		{
			setReadComment(true);
			supplementalToolBoxWin.setTitle(DISCUSSION_WINDOW_TITLE);
			$("#wihAttachments").hide();
			$("#wihDiscussion").show();
		}
		else if(app == 'attachment')
		{
			supplementalToolBoxWin.setTitle(ATTACHMENT_WINDOW_TITLE);
			$("#wihAttachments").show();
			$("#wihDiscussion").hide();
		}
		else
		{
			setReadComment(true);
			supplementalToolBoxWin.setTitle("");
			$("#wihAttachments").show();
			$("#wihDiscussion").show();
		}
		supplementalToolBoxWin.show();
	}
}
function restoreSupplementalTools()
{
	showSupplementalToolsToggleBar = true;
    var westPanel = Ext.getCmp('uiLayoutWestPanel');
	if(displayStatus.supplementalTools)
	{
        if(westPanel) {
            westPanel.show();
        }
    }
	else
	{
        if(westPanel) {
            westPanel.hide();
        }
		positioningToggleButton("west", true)
	}
}
function hideSupplementalTools()
{
	if(useLayoutFramework)
	{
        var westPanel = Ext.getCmp('uiLayoutWestPanel');
        if(westPanel) {
            displayStatus.supplementalTools = !westPanel.isHidden();
            showSupplementalToolsToggleBar = false;
            westPanel.hide();
            positioningToggleButton("west", true)
        }
	}
	else
	{
		$("#wihSupplementalTools").hide("slide");
	}
}
function hideInstruction()
{
    var eastPanel = Ext.getCmp('uiLayoutEastPanel');
    if(eastPanel) {
        displayStatus.instruction = !eastPanel.isHidden();
        showInstructionToggleBar = false;
        eastPanel.hide();
        //if(displayStatus.instruction == false) {
		positioningToggleButton("east", true)
        //}
    }
}
function restoreInstruction()
{
    var eastPanel = Ext.getCmp('uiLayoutEastPanel');
    showInstructionToggleBar = true;
    if(displayStatus.instruction)
	{
       if(eastPanel) {
           eastPanel.show();
      }
	}
	else
	{
        if(eastPanel) {
            eastPanel.hide();
            positioningToggleButton("east", true);
        }
	}
}
function hideMenuToolbar()
{
	if(useLayoutFramework)
	{
        var northPanel = Ext.getCmp('uiLayoutNorthPanel');
        if(northPanel) {
            displayStatus.menuToolbar = !northPanel.isHidden();
            northPanel.hide();
        }
	}
	else
	{
		displayStatus.menuToolbar = ($("#menubar:visible").length == 1);
		$("#menubar").hide();
	}
}
function restoreMenuToolbar()
{
	if(useLayoutFramework)
	{
        var northPanel = Ext.getCmp('uiLayoutNorthPanel');
        if(northPanel) {
            if(displayStatus.menuToolbar)
            {
                northPanel.show();
            }
            else
            {
                northPanel.hide();
            }
        }
	}
	else
	{
		if(displayStatus.menuToolbar)
		{
			$("#menubar").show();
		}
	}
}
function toggleContextInfo()
{
	$("#wihContextInfoOuterDiv").toggle();
}
function restoreContextInfo()
{
	$("#wihContextInfoOuterDiv").show();
}
function toggleProcessDiagram()
{
	$("#trProcessMap").toggle();
}
function restoreProcessDiagram()
{
	$("#trProcessMap").show();
}
function restoreApp()
{
	displayStatus.isMaxApp = false;
	restoreMenuToolbar();
	toggleContextInfo();
	if(useLayoutFramework)
	{
		restoreInstruction();
		restoreSupplementalTools();
		toggleProcessDiagram();
		$("#divPaddingApplicationArea").toggleClass("wih-app-margin");
	}
	resizeContents();
}
function maxApp()
{
	displayStatus.isMaxApp = true;
	hideMenuToolbar();
	toggleContextInfo();
	if(useLayoutFramework)
	{
		hideInstruction();
		hideSupplementalTools();
		toggleProcessDiagram();
		$("#divPaddingApplicationArea").toggleClass("wih-app-margin");
	}
	resizeContents();
}
function isMaxApp()
{
	return displayStatus.isMaxApp;
}
//function resizeEastToggleBttton() {
//	var tBtn = $("#east-toggle");
//	if(tBtn.length)
//	{
//		var resizer = $(".resizer-east-open");
//		if(resizer.length)
//		{
//			tBtn.css("left", resizer.position().left-tBtn.width()+1);
//		}
//		else
//		{
//			var span = $("body");
//			if(span.length)
//			{
//				tBtn.css("left", span.width()-tBtn.width());
//			}
//		}
//	}
//}
function resizeEastToggleBttton() {
	var tBtn = $("#east-toggle");
	if(tBtn.length)
	{
        tBtn.show();
        var wihInstructions = $('#uiLayoutEastPanel');
		if(wihInstructions.length && 0<wihInstructions.position().left)
		{
			tBtn.css("left", wihInstructions.position().left-tBtn.width()-5);
		}
		else
		{
			var span = $("body");
			if(span.length)
			{
				tBtn.css("left", span.width()-tBtn.width());
			}
		}
	}
}

function setCurrentResponseId(id) {
    currentResponseId = id;
}
function getCurrentResponseId() {
    return currentResponseId;
}
function setCommentRequired(req) {
	if(req)
	{
		getBasicWIHActionObject().passedRequiredAction = false;
	}
	$.ajax({
		type: "GET",
		url: contextPath + "/bizcoves/wih/action2.jsp",
		data: {"wihAction": "setCommentRequired", "param": req},
		dataType: "json",
		cache:false,
		async: false,
		success: function(response) {			
			if(!response.success)
			{
				if(typeof response.msg != 'undefined')
				{
					alert(response.msg);
				}
			}
		},
		error: function(e){
			alert('Communication failure: ' + e.statusText);
		}
	});
}
function setAttachmentRequired(req, count) {

	getBasicWIHActionObject().passedRequiredAction = false;

	var attCount=0;

	if(req)
	{
		if(typeof(count) == 'undefined')
		{
			attCount = 1;
		}
		else
		{
			attCount = count;
		}
	}
	else
	{
		attCount = 0;
	}

	$.ajax({
		type: "GET",
		url: contextPath + "/bizcoves/wih/action2.jsp",
		data: {"wihAction": "setAttachmentRequired", "param": attCount},
		dataType: "json",
		cache:false,
		async: false,
		success: function(response) {
			if(!response.success)
			{
				if(typeof response.msg != 'undefined')
				{
					alert(response.msg);
				}
			}
		},
		error: function(e){
			alert('Communication failure: ' + e.statusText);
		}
	});
}
function setReadCommentRequired(req) {
	if(req)
	{
		getBasicWIHActionObject().passedRequiredAction = false;
	}
	$.ajax({
		type: "GET",
		url: contextPath + "/bizcoves/wih/action2.jsp",
		data: {"wihAction": "setReadCommentRequired", "param": req},
		dataType: "json",
		cache:false,
		async: false,
		success: function(response) {
			if(response.success)
			{
				_readCommentRequired = req;
			}
			else
			{
				if(typeof response.msg != 'undefined')
				{
					alert(response.msg);
				}
			}
		},
		error: function(e){
			alert('Communication failure: ' + e.statusText);
		}
	});
}
function setReadComment(val) {
    _readComment = val;
}
var bContinue;
function getOpenPageName() {
    return openPageName;
}

var curAppIdOpenedInRightPane = 0;
function setCurAppIdOpenedInRightPane(value) {
    curAppIdOpenedInRightPane = value;
}

function fire_onChangeWorkitemAttachment(operationType, attachmentInfo_json) {
	// todo:infinit loop
    if (WIH_action.event_onChangeWorkitemAttachment) {
        WIH_action.event_onChangeWorkitemAttachment(operationType, attachmentInfo_json);
    }
    else {
        setTimeout(function(){fire_onChangeWorkitemAttachment(operationType,attachmentInfo_json)}, 500);
    }
}

function getCurAppIdOpenedInRightPane() {
    return curAppIdOpenedInRightPane;
}

//function checkPassword() {
//    var url = contextPath + "/common/passwordframe.jsp";
//    completePassword = ShowWindowWithObject(url, "wndPassword", TTL_CMM_CHECK_PASSWORD, 300, 140, "no", self);
//}
//
//function getCheckPasswordValue(value) {
//    if ("true" == value) {
//        if (!window.showModalDialog)
//            window.top.releaseEvents(Event.CLICK | Event.FOCUS)
//        WIH_action.saveAfterPasswordChecking();
//    }
//}

function save(completeNow) {
    WIH_action.save(completeNow);
}
function updateToServer(wihaction, option) {
	var opt;
	if(typeof(option) != 'undefined')
	{
		if(typeof(option) == 'String')
		{
			opt = jQuery.parseJSON(option);
		}
		else if(typeof(option) == 'Object')
		{
			opt = option;
		}
	}
	WIH_action.updateToServer(wihaction, opt);
}

var bffReqCompInfo = new Array();
function setBffAppReqCompInfo(appId, alreadyCalled) {
    bffReqCompInfo['' + appId] = alreadyCalled;
}
function getBffAppReqCompInfo(appId) {
    if ('undefined' == typeof(bffReqCompInfo['' + appId]))
        return false;
    else if (null == bffReqCompInfo['' + appId])
        return false;
    return bffReqCompInfo['' + appId];
}

// form application related
var bffURL = "";
var xmlURL = "";

function getBFFURL() {
    return bffURL;
}

function getDataXMLURL() {
    return xmlURL;
}

function setBFFURL(str) {
    bffURL = str;
}

function setXMLURL(str) {
    xmlURL = str;
}
// closeWihOnComplete
// completionWindow : default true
var wihOptions = new Object();
function getWIHOption(key, defaultVal) {
    var o = wihOptions[key];
	return (typeof(o) == 'undefined') ? defaultVal : o;
}

function setWIHOption(key, value) {
    wihOptions[key] = value;
}

var actionReady = true;
/**
 * @since 12.4.0002.00
 */
function setActionReady(value)
{
	actionReady = value;
}

/**
 * @since 12.4.0002.00
 * @return {boolean}
 */
function isActionReady()
{
	return actionReady;
}

/**
 * @since 12.4.0002.00
 */
function completeApplication(appId, config)
{
	$.ajax({
		type: "POST",
		url: contextPath + "/bizcoves/wih/action2.jsp",
		data: {wihAction: "completeApplication", processId: processId, workId: workId, param: appId}
	}).done(function(response){
		if(response.msg)
		{
			notify(response.msg, 5000);
		}

		try
		{
			if(config && typeof(config.success)=='function')
			{
				config.success(response);
			}
		}
		catch(e)
		{
			notify(e);
		}
	});
}

function window_onbeforeunload() {
    if (opener != null && 'undefined' != typeof(opener.wih_undo)) {
        try {
            opener.wih_undo(basicWihReadOnly);
        } catch (e) {
        }
    }
	removeOpenTimestamp();
}
function positioningToggleButton(position, isClosed)
{
	var tBtn = $("#"+position+"-toggle");
	if(tBtn)
	{
		if(position == "west")
		{
			if(isClosed)
			{
				tBtn.css("left", 0);
			}
			else
			{
                var resizer = $("#uiLayoutWestPanel-splitter");
				if(resizer)
				{
					tBtn.css("left", resizer.position().left + 6);
				}
			}
			if(showSupplementalToolsToggleBar)
			{
				tBtn.show();
			}
			else
			{
				tBtn.hide();
			}
		}
		else if(position == "east")
		{
			if(isClosed)
			{
				var span = $("#menubar");
				if(span)
				{
					tBtn.show();
					tBtn.css("left", span.width()-tBtn.width());
				}
			}
			else
			{
				resizeEastToggleBttton();
			}
			if(showInstructionToggleBar)
			{
				tBtn.show();
			}
			else
			{
				tBtn.hide();
			}
		}
	}
}
function notify(msg, opt)
{
	var div =$("#notify");
	div.html(msg);
	div.css("position","absolute");
    div.css("top", ($("#menubar").height() + 4) + "px");
    div.css("left", Math.max(0, (($(window).width() - div.outerWidth()) / 2) + $(window).scrollLeft()) + "px");
	div.fadeIn();
	var duration = 4000;
	if(opt)
	{
		if(typeof(opt) == 'number')
		{
			duration = opt;
		}
		else
		{
			duration = opt.duration || 4000;
		}
	}
	setTimeout(function(){$("#notify").fadeOut();}, duration);
}
function doEdit(obj)
{
	obj.hide();
	var p = jQuery(obj.parent());
	p.toggleClass("enableEditField");
	p.find(".editValueDiv").hide();
    var contextInfoTable = p.parents(".contextInfoTable");
    if(contextInfoTable.length > 0) {
        contextInfoTable.find(".editButton").hide();
    }
	p.find(".editBox").show().focus().val(p.find(".editValue").text());
	p.find(".saveButton").show();
	p.find(".cancelButton").show();
}
function doCancel(obj)
{
	var p = jQuery(obj.parent());
	p.toggleClass("enableEditField");
	p.find(".editValueDiv").show();
	p.find(".editBox").hide();
    var contextInfoTable = p.parents(".contextInfoTable");
    if(contextInfoTable.length > 0) {
        contextInfoTable.find(".editButton").show();
    }
	p.find(".saveButton").hide();
	p.find(".cancelButton").hide();
	p.find(".editButton").focus();
}
function doSave(obj, forWhom, extId, callbackHandler)
{
    if ("undefined" == typeof(callbackHandler)) {
        callbackHandler = null;
    }
    if ("undefined" == typeof(forWhom)) {
        forWhom = "";
    }
    if ("undefined" == typeof(extId)) {
        extId = "";
    }

    var p = jQuery(obj.parent());
	var o = p.find(".editBox");
	var val = $.trim(o.val());
	var fieldname = o.attr("name");
	if(fieldname == "PROCESSNAME" || fieldname == "ACTIVITYNAME")
	{
		if(0 == val.length)
		{
			doCancel(obj);
			return;
		}
	}

	var orgValue = p.find(".editValue").text();
	if(orgValue != val)
	{
		$.ajax({
			type: "POST",
			url: contextPath + "/bizcoves/wih/contextinfo_action.jsp",
			data: {fieldname: fieldname, value: val, forWhom: forWhom, extId:extId}
		}).done(function(data){eval("var o="+data);saveDone(obj, o, callbackHandler)});
	}
	else
	{
		doCancel(obj);
	}
}
function saveDone(obj, data, callbackHandler)
{
	try{
//		var obj = $("input[name$='"+data.fieldName+"']");
		var p = jQuery(obj.parent());
		p.toggleClass("enableEditField");
		p.find(".editValue").attr("title", p.find(".editBox").val());
		p.find(".editValue").text(p.find(".editBox").val());
		p.find(".editValueDiv").show();
		p.find(".editBox").hide();
        var contextInfoTable = p.parents(".contextInfoTable");
        if(contextInfoTable.length > 0) {
            contextInfoTable.find(".editButton").show();
        }
		p.find(".saveButton").hide();
		p.find(".cancelButton").hide();
        if(callbackHandler != null) {
            callbackHandler();
        }
		notify(SAVED);
		p.find(".editButton").focus();
	}catch(e){};
}
var appListBoxClosed = true;
function hideAppListBox()
{
	$("#appListBox2").hide();
	appListBoxClosed = true;
}
function toggleAppListBox()
{
	if(appListBoxClosed)
	{
		if($("#appListBox2").has("#appListBox").length == 0)
		{
			if(WIH_application.getAppListBox)
			{
				$("#appListBox2").append(WIH_application.getAppListBox());
				$("#appListBox").show();
			}
		}
		setHightlightApp();
		resizeAppListBox();
		appListBoxClosed = false;
	}
	else
	{
		hideAppListBox();
	}
}
function setHightlightApp()
{
	if(WIH_application.getCurrentAppMenuId)
	{
		$("#appListBox li").removeClass("selectedApp");

		var menuID = WIH_application.getCurrentAppMenuId();
		if(menuID)
		{
			var li = $("#li_" + menuID)
			if(li.length)
			{
				li.addClass("selectedApp");
			}
		}
	}
}
function resizeAppListBox()
{
	var div =$("#appListBox2");
	var btn = $("#appListBtn");
	if(div.length == 1 && btn.length == 1)
	{
		div.css("left", btn.offset().left - div.width() + 10);
		div.css("top", btn.offset().top+btn.height()+8);
		div.show();
	}
}
function changeTab(appId, appType, raiseEvent)
{
	WIH_application.changeTab(appId, appType, raiseEvent);
}
function iPad()
{
	$("#WIH_information").css("height", "100%");
	$("#tblCenter").css("height", "");
	$("#wihCenter").css("height", "100%").css("overflow", "");
	$("#divPaddingApplicationArea").css("height", "100%").css("overflow", "");
	$("#divApplicationArea").css("height", "100%").css("overflow", "");
	var height = $("#WIH_information").height();
	$("#divApplicationArea").css("height", height);
	$("#divPaddingApplicationArea").css("height", height);
	$("#wihCenter").css("height", height);
}
function resizeContents()
{
	if(isNoneUI)
	{
		$("#divApplicationArea").css("height", "100%");
	}
	else
	{
		if($("#wihCenter").length)
		{
			var wihCenterHeight = $("#wihCenter").height();
			$("#tblCenter").css("height", wihCenterHeight);
			//var divContextHeaderHeight = ("none" ==  $("#divContextHeader").css("display")) ? 0 : $("#divContextHeader").height();
			var wihContextHeaderHeight = ("none" ==  $("#wihContextInfoOuterDiv").css("display")) ? 0 : $("#wihContextInfoOuterDiv").height();
			var divApplicationTabHeight = ("none" ==  $("#divApplicationTab").css("display")) ? 0 : $("#divApplicationTab").height();
			var trProcessMapHeight = ("none" ==  $("#trProcessMap").css("display")) ? 0 : $("#trProcessMap").height();
			var appHeight = wihCenterHeight - wihContextHeaderHeight - divApplicationTabHeight - trProcessMapHeight - 8;
			$("#divApplicationArea").css("height", appHeight);
		}
		else
		{
			$("#WIH_information").css("height", "100%");
			//$("#divApplicationArea").css("height", "100%");
	//        var ieVersion = getTopBrowserVersion();
	//        if (ieVersion == 9) {
	//            var wihBody = $object("divApplicationArea");
	//            var wihToolbarBox = $object("wihToolbarBox");
	//            if (wihBody && wihToolbarBox) {
	//                var offset = 0;
	//                var height = document.body.clientHeight - wihToolbarBox.clientHeight - offset;
	//                wihBody.style.height = height + "px";
	//            }
	//        }
		}

		if(displayStatus.isMaxApp)
		{
			$("#appListBtn").hide();
		}
		else
		{
			if($("#appListBtn").length)
			{
				setTimeout(resizeAppListBtn,500);
			}
		}
	}
}
function resizeAttachmentBoxHeight()
{
    var westPanel = Ext.getCmp('uiLayoutWestPanel');

	if(westPanel && !westPanel.collapsed)
	{

        if($("#divCorrespondence").length > 0) {
	        $("#WIH_correspondence").css("height", $("#divCorrespondence").height());
        }
	}
}
function resizeSupplementalTools()
{
    var westPanel = Ext.getCmp('uiLayoutWestPanel');
	if(westPanel && !westPanel.collapsed)
	{
		$("#wihDiscussion").css("width","auto");
		$("#wihAttachments").css("width","auto");
		if($("#divCorrespondence").length > 0) {
        	$("#divCorrespondence").css("width","auto");
        }
		if(wihDiscussion)
		{
	        setTimeout(function(){
		        resizeDiscussionPanel();
	        }, 500);
		}
		
		$("#wihAttachments-resizer").css("width",$("#wihAttachments").width());
	}
}
function resizeDiscussionPanel()
{
	var wihInnerDiscussionHeight = $("#wihInnerDiscussion").height();
	var tblCommentActionAreaHeight = $("#tblCommentActionArea").height();
	if(wihInnerDiscussionHeight > tblCommentActionAreaHeight ) {
		$("#divCommentList").height( wihInnerDiscussionHeight - tblCommentActionAreaHeight);
	}
	wihDiscussion.resizeCommentBoxes();
}
function openAddAttachmentWin(event)
{
	var sUrl = contextPath + "/bizcoves/wih/attachadd.jsp?basicWihReadOnly="+basicWihReadOnly;

    //for modal
	var statusbar;
	var toolbar;
	var caller;
	var sFeatures;
	var left;
	var top;
    openModalPopup(sUrl, LBL_WIH_ATTACHMENT, "Attachment_Add", 460, 220, true, true, 
		statusbar, toolbar, caller, sFeatures, left, top, isForcedModal);
//	openPopup(sUrl, LBL_WIH_ATTACHMENT, "Attachment_Add", 460, 220, true, true);
	try{ event.stopPropagation(); }catch(e){};
    return false;
}
function deleteAttachment(id) {
	var ids = id;
	if (confirm(MSG_CMM_CONFIRM_DELETE)) {
		removeAttachment(id);
	}
}
function _markUrlRewrite(url)
{
    var obj = new Object();
    obj.src = url;
    return obj.src;
}
function sessionKeepAlive()
{
    var url = contextPath + '/common/sessionKeepAlive.jsp?_t=' + (new Date()).getTime();
	url = _markUrlRewrite(url);
	$.ajax({type: "GET",url: url});
	self.setTimeout(sessionKeepAlive,900000);
}
function contextEditBoxKeyHandle(obj, event)
{
	var keycode = (event.keyCode ? event.keyCode : event.which);
	if(keycode == '13'){ // enter
		$(obj).parent().find(".saveButton").click();
	} else if(keycode == '27'){ // esc
		$(obj).parent().find(".cancelButton").click();
	}
}
function resizeAppListBtn()
{
	var btn =$("#appListBtn");
	if(btn.length)
	{
		var tr = $("#divApplicationTab");
		btn.css("left", tr.width()-btn.width()-21);
		btn.css("top", tr.position().top+2);
		btn.show();
	}
}
function resizeContextEditableFields()
{
	$("#contextInfoTable div.editValueDiv").each(function(){
		var s = $(this);
		var maxWidth = s.attr("max-width");
		if(maxWidth < s.width())
		{
			s.width(maxWidth);
		}
	});
}

var currentCommentID = 0;
var currentCommentProcID = 0;
function setFocusToDiscussion()
{
	var discussionPanel = Ext.getCmp('discussionPanel');
	if(discussionPanel) {
		discussionPanel.expand();
		setReadComment(true);
	}
}
function changeModifyCommentUI(procId, commID)
{
	currentCommentID = commID;
	currentCommentProcID = procId;
//	$("#addCommentAction").hide();
//	$("#modifyCommentAction").show();
//	$("#cancelCommentAction").show();
//	//$("td.comment-header span.actionBtns").hide();
//	$("#wihInnerDiscussion").scrollTop(0);
//	var $content = $("textarea#commentContent");
//	$content.val($("textarea#comment" + commID).val());
//	$content.focus();

    var jsonData = {"processId": procId, "mode": "Modify", "commID": currentCommentID};
    openDiscussionPopup(jsonData);
}
function modifyComment()
{
	wihDiscussion.modify(currentCommentProcID, currentCommentID);
}
function deleteComment(procId, commID)
{
	if(confirm(CONFIRM_DELETE_COMMENT))
	{
		wihDiscussion.remove(procId, commID);
	}
}
function addComment()
{
	wihDiscussion.add();
}
function cancelComment()
{
	$("textarea#commentContent").val("");
	$("#addCommentAction").show();
	$("#modifyCommentAction").hide();
	$("#cancelCommentAction").hide();
	$("td.comment-header span.actionBtns").show();
}
function getCommentCount()
{
	return wihDiscussion.getCount();
}
function showRequirements()
{
	if($("#requirementListBox").length)
	{
		openPopupRequirementInfo();
	}
	else
	{
		expandContextInfo('requirementListBoxOnContextInfo');
	}
}
function loadContextInfo(view, spotlightElementId)
{
	var div = $("#wihContextInfoDiv");
	div.load(contextPath + "/bizcoves/wih/contextinfo.jsp?basicWihReadOnly=" + basicWihReadOnly +"&view="+view+(isForcedModal?"&isForcedModal=true":"")+"&_t=" + (new Date()).getTime(), function(response, status, xhr) {
		var outerDiv = $("#wihContextInfoOuterDiv");
		if(view == "more")
		{
			$("#wihContextInfoOuterDiv").css("height", "250px");
			outerDiv.css("height", "250px");
			outerDiv.css("overflow-y", "auto");
		}
		else if(view == "less")
		{
			$("#wihContextInfoOuterDiv").css("height", "85px");
			outerDiv.css("height", "85px");
			outerDiv.css("overflow", "hidden");
			outerDiv.css("overflow-y", "hidden");
		}
		resizeContents();
		setTimeout(resizeContextEditableFields, 100);
		if(typeof(spotlightElementId) != 'undefined')
		{
			spotlight(spotlightElementId);
		}
	});
}
function reloadContextInfo()
{
	var $anchor = $("#contextInfoToggleBarAnchor");
	if($anchor.length)
	{
		if($anchor.attr("_expand") == "true")
		{
			loadContextInfo("more");
		}
		else
		{
			loadContextInfo("less");
		}
	}
}
function spotlight(id)
{
	var el = $("#"+id);
	if(el.length)
	{
		el.addClass("spotlight");
		setTimeout(function(){ try{el.removeClass("spotlight");}catch(e){} }, 5000);
	}
}
function collapseContextInfo()
{
	hideAppListBox();
	$("#appListBtn").hide();
	loadContextInfo("less");
}
function expandContextInfo(spotlightElementId)
{
	hideAppListBox();
	$("#appListBtn").hide();
	loadContextInfo("more", spotlightElementId);
}

function setResponseByName(name)
{
	for(var i=0; i<responseGroup.length; i++)
	{
		if(responseGroup[i].NAME == name)
		{
			currentResponseId = responseGroup[i].ID;
			return responseGroup[i];
		}
	}
	return null;
}
function setSelectedResponseById(id)
{
	for(var i=0; i<responseGroup.length; i++)
	{
		if(responseGroup[i].ID == id)
		{
			currentResponseId = responseGroup[i].ID;
			return responseGroup[i];
		}
	}
	return null;

}
function getSelectedResponse()
{
    if(currentResponseId != null)
    {
	    for(var i=0; i<responseGroup.length; i++)
	    {
		    if(responseGroup[i].ID == currentResponseId)
		    {
			    return responseGroup[i];
		    }
	    }
    }
    return null;
}
function getResponsesInfo()
{
	return responseGroup;
}

var _workitemkey = '';
function workitemkey()
{
	return 'U'+currentUserId + '.WIH.MSG.' + _workitemkey;
}
function saveViewMessageInfo()
{
	if(window.localStorage)
	{
		try
		{
			localStorage.setItem(workitemkey(), (new Date()).getTime());
		}
		catch(e)
		{
			try
			{
				if(e == QUOTA_EXCEEDED_ERR)
				{
					var target = 'U'+currentUserId + '.WIH.MSG.';
					Object.keys(localStorage)
					.forEach(function(key){
								if(0 == key.indexOf(target))
								{
									localStorage.removeItem(key);
								}
							});
					localStorage.setItem(workitemkey(), (new Date()).getTime());
				}
			}
			catch(ee)
			{
				localStorage.clear();
			}
		}
	}
}
function isNewMessage()
{
	if(window.localStorage)
	{
		var val = localStorage.getItem(workitemkey());
		return (typeof(val) == 'undefined' || val == null);
	}
	else
	{
		return true;
	}
}
function setCurrentUserId(userId)
{
	currentUserId = userId;
}
function saveOpenTimestamp()
{
	if(!_readOnly && window.localStorage)
	{
		try
		{
			_lastUpdatedTimeKey = 'U'+currentUserId+'.WIH.lastUpdatedTime';
			localStorage.setItem(_lastUpdatedTimeKey, (new Date()).getTime());
		}
		catch(e)
		{
			try
			{
				if(e == QUOTA_EXCEEDED_ERR)
				{
					localStorage.clear();
					localStorage.setItem(_lastUpdatedTimeKey, (new Date()).getTime());
				}
			}
			catch(ee)
			{
				localStorage.clear();
			}
		}
	}
}
function removeOpenTimestamp()
{
	if(!_readOnly && window.localStorage)
	{
		localStorage.removeItem(_lastUpdatedTimeKey);
	}
}
function setLocalCacheKey(key)
{
	_workitemkey = key;
}
function removeLocalCacheInfo()
{
	if(window.localStorage)
	{
		localStorage.removeItem(workitemkey());
	}
}
function getAnimatedMessageBoxTargetId()
{
	if(1==$("#viewMessageLink").length && 0<$("#viewMessageLink").position().left)
	{
		return "viewMessageLink";
	}
	else if(1==$("#east-toggle").length && 0<$("#east-toggle").position().left)
	{
		return "east-toggle";
	}
	else if("undefined" != typeof(getMainToolbar)) //  'ReferenceError:getMainToolbar is not defined'
    {
        if(getMainToolbar().getComponent('viewMessage'))
	{
		return getMainToolbar().getComponent('viewMessage').getEl().id;
        }
	}
	else
	{
		return null;
	}
}
var _messageBoxWin;
var _msgtype = "";
function viewMessage()
{
	try
	{
		if(!_messageBoxWin)
		{
			var title = ("FORWARD" == _msgtype)? FORWARDED_WINDOW_TITLE : REPLIED_WINDOW_TITLE;
			_messageBoxWin = new Ext.Window({
				title: title,
				autoHeight: true,
				modal: true,
				closeAction: 'hide',
				width: 400,
				minWidth: 350,
				height: 200,
				autoScroll:true,
				contentEl: 'messageBoxMain'
			});
			saveViewMessageInfo();
		}
		_messageBoxWin.animateTarget = getAnimatedMessageBoxTargetId();
		_messageBoxWin.show(_messageBoxWin.animateTarget);
	}catch(e){alert(e)};
}
var _requirementListBoxWin;
function getAnimatedRequirementBoxTargetId()
{
	if($("#showReqLink").length)
	{
		return "showReqLink";
	}
	else if($("#wih_view_requirement").length)
	{
		return "wih_view_requirement";
	}
	else
	{
		return null;
	}
}
function openPopupRequirementInfo()
{
	if(!_requirementListBoxWin)
	{
		_requirementListBoxWin = new Ext.Window({
			title: REQUIREMENTS_WINDOW_TITLE,
			autoHeight: true,
			modal: false,
			closeAction: 'hide',
			width: 400,
			minWidth: 350,
			height: 200,
			autoScroll:true,
			contentEl: 'requirementListBox'
		});
	}
	_requirementListBoxWin.animateTarget = getAnimatedRequirementBoxTargetId();
	_requirementListBoxWin.show(_requirementListBoxWin.animateTarget);
}

function doAction(command)
{
	var cmd = {};
	if(typeof(command) == 'string')
	{
		cmd = {action: command};
	}
	else if(typeof(command) == 'object')
	{
		cmd = command;
	}

	getBasicWIHActionObject().setContinue();

	if(cmd.action == 'viewMessage')
	{
		viewMessage();
	}
	else if(cmd.action == 'viewRequirement')
	{
		showRequirements();
	}
	else if(cmd.action == 'save')
	{
		WIH_action.save(false);
	}
	else if(cmd.action == 'respond')
	{
		if(typeof(cmd.responseId) == 'undefined')
		{
			WIH_action.respond();
		}
		else
		{
			if(getWIHOption('completionWindow', true) || typeof(cmd.responseName) == 'undefined')
			{
				WIH_action.respond(cmd.responseId);
			}
			else
			{
				var confirmed = false;
				if(0<MSG_CONFIRM_RESPOND.length)
				{
					confirmed = confirm(Ext.String.format(MSG_CONFIRM_RESPOND, cmd.responseName));
				}
				else
				{
					confirmed = true;
				}
				if(confirmed)
				{
					WIH_action.respond(cmd.responseId);
				}
			}
		}
	}
	else
	{
		eval('WIH_action.'+cmd.action+'()');
	}
}
function getBasicWIHActionObject()
{
	return WIH_action.getBasicWIHActionObject();
}
function supplementalToolLayoutState(config)
{
	if(_readOnly) return false;

	if(typeof(wihLayoutState.supplementalTool) == 'undefined')
	{
		wihLayoutState.supplementalTool = {isClosed:true, size:250};
	}

	if(typeof(config) == 'object')
	{
		saveLayoutState(wihLayoutState.supplementalTool, config);
	}
	return wihLayoutState.supplementalTool;
}
function instructionLayoutState(config)
{
	if(_readOnly) return false;

	if(typeof(wihLayoutState.instruction) == 'undefined')
	{
		wihLayoutState.instruction = {isClosed:true, size:300};
	}

	if(typeof(config) == 'object')
	{
		saveLayoutState(wihLayoutState.instruction, config);
	}
	return wihLayoutState.instruction;
}
function processMapLayoutState(config)
{
	if(typeof(wihLayoutState.processMap) == 'undefined')
	{
		wihLayoutState.processMap = {isClosed:true};
	}

	if(typeof(config) == 'object')
	{
		saveLayoutState(wihLayoutState.processMap, config);
	}
	return wihLayoutState.processMap;
}
function attachAccordionLayoutState(config)
{
    if(_readOnly) return false;

    if(typeof(wihLayoutState.attachAccordion) == 'undefined')
    {
        wihLayoutState.attachAccordion = {isClosed:false, size:250};
    }

    if(typeof(config) == 'object')
    {
        saveLayoutState(wihLayoutState.attachAccordion, config);
    }
    return wihLayoutState.attachAccordion;
}

function discussionAccordionLayoutState(config)
{
    if(_readOnly) return false;

    if(typeof(wihLayoutState.discussionAccordion) == 'undefined')
    {
        wihLayoutState.discussionAccordion = {isClosed:false, size:250};
    }

    if(typeof(config) == 'object')
    {
        saveLayoutState(wihLayoutState.discussionAccordion, config);
    }
    return wihLayoutState.discussionAccordion;
}

function correspondenceAccordionLayoutState(config)
{
    if(_readOnly) return false;

    if(typeof(wihLayoutState.correspondenceAccordion) == 'undefined')
    {
        wihLayoutState.correspondenceAccordion = {isClosed:false, size:250};
    }

    if(typeof(config) == 'object')
    {
        saveLayoutState(wihLayoutState.correspondenceAccordion, config);
    }
    return wihLayoutState.correspondenceAccordion;
}

function saveLayoutState(targetObj, config)
{
	if(_readOnly) return;
	var old = jQuery.extend({}, targetObj);
	jQuery.extend(targetObj, config);
	if(!layoutStore.compare(targetObj, old))
	{
		layoutStore.save(layoutStateId, wihLayoutState);
	}
}


function expandProcessMap()
{
	$("#processMapViewContainer").show();
	$("#processMapViewContainer").css("height", "93px");
	$("#expandProcessMapIcon").hide();
	$("#collapseProcessMapIcon").show();
	$("#trProcessMap").css("height", "145px");
	loadProcessMap();
	resizeContents();
	processMapLayoutState({isClosed:false});
}
function collapseProcessMap()
{
	$("#processMapViewContainer").css("height", "1px");
	$("#collapseProcessMapIcon").hide();
	$("#expandProcessMapIcon").show();
	$("#trProcessMap").css("height", "35px");
	resizeContents();
	processMapLayoutState({isClosed:true});
}
function loadProcessMap()
{
	var $map = $("#diagramView");
	if($map.length && $("#processMapViewContainer:visible").length)
	{
		if($map.attr("_load") != "true")
		{
            var category;
            if (isArchivedProcess) category = "archive";
            else category = "instance";

			$map.attr("src", contextPath + "/common/graphview.jsp?pid=" + getWorkitemContext().Process.ID + "&category=" + category + "&focusActivity="+getWorkitemContext().Activity.Sequence+"&refreshBtn=false&showWindowTitle=no");
			$map.attr("_load", "true");
		}
	}
}

/*
 * Returns the comments
 */
function getComments()
{
	if(wihDiscussion)
	{
		return wihDiscussion.getComments();
	}
	else
	{
		return undefined;
	}
}
function openCustomFile(attrbid, extension)
{
	var sUrl = contextPath + "/bizcoves/wih/customfileopen.jsp?pid="+getWorkitemContext().Process.ID+"&attrbid=" + attrbid + "&extension=" + extension;
	var iWidth = window.screen.availWidth-100;
	var iHeight = window.screen.availHeight-200;
	var iLeft = 50;
	var iTop = 50;
	var sFeatures = "menubar=yes,status=no,resizable=yes,toolbar=yes,scrollbars=yes,left=" + iLeft + "," + "top=" + iTop + "," + "width=" + iWidth + "," + "height=" + iHeight;
	window.open(sUrl,"Attachment_View",sFeatures).focus();
}
/*
 * Returns the workitem context information
 */
function getWorkitemContext()
{
	if(typeof(workitemContextInfo) == 'undefined')
	{
		var $c = $("#_orgContextInfoData");
		if($c.length == 1)
		{
			workitemContextInfo = JSON.parse(decode64($c.val()));
		}
		else
		{
			workitemContextInfo = undefined;
		}

	}
	return workitemContextInfo;
}
/*
 * Affected area: workitemContext, context info pane, Description of Instructions
 */
function reloadWorkitemContext(callback)
{
	$.ajax({
		type: "GET",
		url: contextPath + "/bizcoves/wih/reloadWorkitemContext.jsp",
		data: {pid: getWorkitemContext().Process.ID, wid: getWorkitemContext().Workitem.Sequence},
		dataType: "json",
		cache: false,
		success: function(data) {
			if(data.isError)
			{
				if(0<data.errorMsg.length)
				{
					alert(data.errorMsg);
					//parent.unblockUI();
				}
				return;
			}
			else
			{
				var $c = $("#_orgContextInfoData");
				if($c.length == 1 && typeof(data.workitemContext_base64) != 'undefined')
				{
					workitemContextInfo = undefined;
					$c.val(data.workitemContext_base64);
				}

				onWorkitemContext(data, callback);
			}
			//parent.unblockUI();
		},
		error: function(e){
			//parent.unblockUI();
			alert('Error: ' + e.statusText);
		}
	});
}

function onWorkitemContext(data, callback)
{
	var wc = getWorkitemContext();
	if(data.title)
	{
		setWindowTitle(data.title);
	}

	if(data.instructionSummary)
	{
		$("#instructionSummary").html(data.instructionSummary);
	}

	reloadContextInfo();

	if(typeof(callback) == 'function')
	{
		callback();
	}
}
/*********************************************************************************************************************/
/**
 * @classdesc
 * This class provides interfaces for bi-directional integration with Web WIH.
 * You can get events from Web WIH when a user uses a built-in feature, or can command Web WIH when your application needs to use a built-in feature.
 * This class also provides a method to get {@link WIHUI} class, which allows you to interact with Web WIH's user interface components;
 * for example, showing or hiding an out of the box button in Web WIH.
 * <p>
 * The event model is useful when your application needs to receive appropriate signals when users deal with Web WIH's built-in features.
 * For example, when a user clicks on Save button in Web WIH, your application can receive the event and performs saving data received from the user.
 * When a user attempts to complete the workitem, your application can perform its own validation rules and then either prevents the user
 * from completing the workitem if the validation rules are not passed or allows the user to continue with the complete.
 * With the event model, you can make your applications seamlessly integrated with Web WIH and provide a single application experience to your end users.
 * <p>
 * In some cases, you might want to hide Web WIH's out of the box buttons and provide the same features from your application.
 * For example, your application has Save button and you want users to use the Save button instead of another Save button on Web WIH toolbar.
 * You would want to hide Web WIH's Save button to avoid making users confused with two Save buttons.
 * While you can hide a certain button or the whole toolbar using {@link WIHUI} class, you also need to send a signal to Web WIH to Save its own changes
 * when a user clicks on the Save button on your application. In order to do that, you will use one of WIHActionClient's methods, basicWIHActionClient.save().
 * <p>
 * The following document provides detailed explanation and examples for all published interfaces of WIHActionClient.
 * <h6>Events</h6>
 * Whenever a user performs action clicking a menu on the toolbar of WIH,
 * Web WIH sends an event corresponding to the action to a web application.
 * Therefore, if you want a custom Web application to handle a specific event, the custom Web application must declare
 * an event handler function corresponding to the Web WIH event. If an event corresponding to an event is not declared
 * is a custom Web application, the event is not sent to the Web application.
 * The WIHActionClient Object offers a set of APIs and constants that you can use in a Web application.
 * This WIHActionClient object is passed to a Web application whenever an event is fired.
 * <p>
 * <table class="params">
 *     <thead>
 *     <tr>
 *       <th>Event fired when a user...</td>
 *       <th>Function</td>
 *     </tr>
 *     </thead>
 *     <tr>
 *       <td>Clicks Complete menu</td>
 *       <td>onWorkitemComplete(basicWIHAction)</td>
 *     </tr>
 *     <tr>
 *       <td>Makes a selection from the Response drop box</td>
 *       <td>onWorkitemChangeResponse(basicWIHAction)</td>
 *     </tr>
 *     <tr>
 *       <td>Clicks Save menu</td>
 *       <td>onWorkitemSave(basicWIHAction)</td>
 *     </tr>
 *     <tr>
 *       <td>Clicks Exit menu. The menu shown if the pop-up window mode enabled.</td>
 *       <td>onWorkitemExit(basicWIHAction)</td>
 *     </tr>
 *     <tr>
 *       <td>Clicks Monitor menu. This menu shown if the Process Map panel disabled.</td>
 *       <td>onWorkitemMonitor(basicWIHAction)</td>
 *     </tr>
 *     <tr>
 *       <td>Clicks Ad Hoc menu</td>
 *       <td>onWorkitemAdHoc(basicWIHAction)</td>
 *     </tr>
 *     <tr>
 *       <td>Clicks Select Next Application menu</td>
 *       <td>onWorkitemSelectNextApplication(basicWIHAction)</td>
 *     </tr>
 *     <tr>
 *       <td>Clicks Select Next User menu</td>
 *       <td>onWorkitemSelectNextUser(basicWIHAction)</td>
 *     </tr>
 *     <tr>
 *       <td>Clicks Reply menu</td>
 *       <td>onWorkitemReply(basicWIHAction)</td>
 *     </tr>
 *     <tr>
 *       <td>Clicks Forward menu</td>
 *       <td>onWorkitemForward(basicWIHAction)</td>
 *     </tr>
 *     <tr>
 *       <td>On change application tab</td>
 *       <td>onWorkitemTabChange(basicWIHAction, applicationId, applicationType)
 *          <OL>
 *          <LI>applicationId: Application ID
 *          <LI>applicationType: Application Type
 *              <UL>
 *                  <LI>BizFlow Form : 'B'
 *          	    <LI>BizFlow WebMaker Form : 'M'
 *          	    <LI>URL Application : 'H'
 *          	    <LI>Document File: 'D'
 *              </UL>
 *          </OL>
 *       </td>
 *     </tr>
 *     <tr>
 *       <td>On change attachment</td>
 *       <td>onChangeWorkitemAttachment(basicWIHAction, operation, updatedAttachmentsInfo)
 *          <OL>
 *          <LI>operation: 'ADDED', 'DELETED'
 *          <LI>updatedAttachmentsInfo: Modified an attachment object.
 *          <pre><code>
 *          {
 *           "ID": <i>Attachment ID</i>,
 *           "ACTIVITYSEQUENCE": <i>Activity Sequence,</i>
 *           "WORKITEMSEQUENCE": <i>Workitem Sequence,</i>
 *           "DESCRIPTION": <i>Description,</i>
 *           "FILENAME": <i>File Name,</i>
 *           "DISPLAYNAME": <i>Display Name,</i>
 *           "CREATOR": <i>Creator ID,</i>
 *           "CREATORNAME": <i>Creator Name,</i>
 *           "CREATIONDATE": <i>Creation Date. ex: "2013/05/29 09:32:36",</i>
 *           "ACTIVITYNAME": <i>Activity Name</i>
 *           "SIZE": <i>File Size (Bytes),</i>
 *           "TYPE": <i>Type of attachment.
 *                        'U': URL
 *                        'G': General File
 *                        'M': Attach a format-type file
 *                        'E': Attachment file form parent or subprocess
 *                        'R': BizFlow Form format file from parent or subprocess.
 *                        'A': Format-type file from parent or subprocess.</i>,
 *           "INTYPE": <i>Input Type.
 *                        'C': Current Process
 *                        'P': Parent Process
 *                        'S': Subprocess</i>
 *           "OUTTYPE": <i>Output Type.
 *                        'N': Don't send attachment
 *                        'S': Send to subprocess
 *                        'P': Send parent process
 *                        'B': Send parent process and subprocess</i>,
 *           "DMDOCRTYPE": <i>EDMS's Document Type,</i>
 *           "DMDOCUMENTID": <i>EDMS's Document ID,</i>
 *          }</code></pre>
 *          </OL>
 *       </td>
 *     </tr>
 * </table>
 * <p>
 * Deprecated events:
 * <table class="params">
 *     <thead>
 *     <tr>
 *       <th>Event fired when a user...</td>
 *       <th>Function</td>
 *     </tr>
 *     </thead>
 *     <tr>
 *       <td>Clicks Attach menu</td>
 *       <td>onWorkitemAttach(basicWIHAction)</td>
 *     </tr>
 *     <tr>
 *       <td>Clicks EDMS Attach menu</td>
 *       <td>onWorkitemAttachEdms(basicWIHAction)</td>
 *     </tr>
 *     <tr>
 *       <td>Closes the comment window</td>
 *       <td>onCloseWorkitemCommentWindow(basicWIHAction)</td>
 *     </tr>
 *     <tr>
 *       <td>Clicks Activity Help menu</td>
 *       <td>onWorkitemGeneralInfo(basicWIHAction)</td>
 *     </tr>
 * </table>
 * <p>
 * <h6>Flow Control</h6>
 * An event can stop or keep going depending on the value of the continue option.
 * <p>
 * For example, when a user clicks the Complete icon, the onWorkitemComplete() event handler checks
 * if the data which the user enters is valid. If the data is not valid, the onWorkitemComplete() event handler
 * can stop the event from calling the basicWIHActionClient.setStop() API.
 * <p>
 * Web Workitem Handler has a flow control flag. The name of the flag is "Continue".
 * A Web application sets the value of the Continue flag using the setContinueOption(option),
 * setContinue(), setStop() or setWait() APIs.
 * <p>
 * <h6>Web Application Example</h6>
 * A Web application must get an instance of WIHActionClient Class. There are two way to get an instance.
 * <p>
 * 1) You can get an instance via getWIHActionClient() API on Web Workitem Handler page(parent page) in your Web application.
 * <pre>
 * <code>
 *     var basicWIHActionClient = parent.getWIHActionClient();
 * </code>
 * </pre>
 * 2) Include the JavaScript basicwihactionclient.js to your Web application.
 * <p>
 * There are three ways to include the basicwihactionclient.js
 * <ol>
 *     <li>&lt;script src="/bizflow/includes/wih/basicwihactionclient.js">&lt;/script>
 *     <li>&lt;script src="http://BizFlowServer/bizflow/includes/wih/basicwihactionclient.js">&lt;/script>
 *     <li>Copy baicwihactionclient.js from the includes\wih directory under the directory
 *     where the BizFlow web application is installed to your Web application directory and add the following code:<br>
 *     &lt;script src="basicwihactionclient.js">&lt;/script>
 * </ol>
 * <p>
 * A custom Web applications must be deployed on a same server in which BizFlow is deployed to resolve security policy problems (that is, the Same-Origin Policy).
 * <p>
 * The WebMaker application has been included itself. Therefore you do not need to include it.
 * <p>
 * See sample application: bizflow/bizcoves/wih/sample/basicwihactionclient_sample1.jsp
 * @class
 * @copyright BizFlow Corp.
 * @version 12.1.0.0003
 */
function WIHActionClient()
{
	this.version = 12.3;
	this.minorVersion = 3;
	this.basicWIH = null;
	this.init = function(){this.basicWIH = getBasicWIHActionObject();};
	this.getBasicWIHActionObject = function(){this.init();return this.basicWIH;};

	/**
	 * Let the Basic Workitem Handler continue to perform the current action.
	 * @constant
	 * @type {string}
	 */
	this.OPTION_CONTINUE = "continue";
	/**
	 * Let the Basic Workitem Handler stop the current action.
	 * @constant
	 * @type {string}
	 */
	this.OPTION_STOP = "stop";
	/**
	 * Let the Basic Workitem Handler wait until the Continue flag is set to "continue".
	 * If the Continue flag is set to "wait", all actions are disabled.
	 * @constant
	 * @type {string}
	 */
	this.OPTION_WAIT = "wait";

	/**
	 * Sets the continue option. The value of option is one of the continue option constants.
	 * @param option {string} One of the following constants: <code>OPTION_CONTINUE, OPTION_STOP, OPTION_WAIT</code>
	 * @see {@link OPTION_CONTINUE}
	 * @see {@link OPTION_STOP}
	 * @see {@link OPTION_WAIT}
	 */
	this.setContinueOption = function(option){this.init();return this.basicWIH.setContinueOption(option);};
	/**
	 * Gets the current continue option.
	 * @return {string} "continue", "stop", or "wait"
	 */
	this.getContinueOption = function(){this.init();return this.basicWIH.getContinueOption();};
	/**
	 * Sets continue option to a "continue" state.
	 */
	this.setContinue = function(){this.init();return this.basicWIH.setContinue();};
	/**
	 * Sets continue option to a "stop" state.
	 */
	this.setStop = function(){this.init();return this.basicWIH.setStop();};
	/**
	 * Sets continue option to a "wait" state.
	 */
	this.setWait = function(){this.init();return this.basicWIH.setWait();};
	/**
	 * Completes the current workitem and sends it to the next step.
	 */
	this.complete = function(){this.init();return this.basicWIH.complete();};
	/**
	 * Saves the workitem to the server, and closes and returns to the worklist.
	 */
	this.save = function(){this.init();return this.basicWIH.save();};
	/**
	 * Launches the audit trail monitor
	 */
	this.monitor = function(){this.init();return this.basicWIH.monitor();};
	/**
	 * Shows the supplemental tool pane and focus to the discussion area.
	 */
	this.comment = function(){this.init();return this.basicWIH.comment();};
	/**
	 * Launches the Attach dialog box.
	 * @param config {Object} Optional.
	 * Config object:<pre><code>
	 *     {
	 *      partialPage: String. Partial page location. Relative path.
	 *      width: Number. Optional. Window width. defaults to 500
	 *      height: Number. Optional. Window height. defaults to 300
	 *      parameter: Object. Optional. Additional parameters to pass to the Attach dialog box.
	 *     }
	 * </code></pre>
	 * @example
	 *  basicWIHActionClient.attach({partialPage: 'sample/attachadd_partialpage.jsp',
	 *                               parameter:{param1: 'value1', param2:'value2'},
	 *                               width:500,
	 *                               height:400})
	 *
	 * @see bizflow/bizcoves/wih/sample/attachadd_partialpage.jsp
	 */
	this.attach = function(config){this.init();return this.basicWIH.attach(config);};
	/**
	 * Launches the Attach EDMS document dialog box.
	 */
	this.edmsAttach = function(){this.init();return this.basicWIH.edmsAttach();};
	/**
	 * Launches the Participant Selection dialog box which allows you to route the workitem to another process participant.
	 */
	this.adHoc = function(){this.init();return this.basicWIH.adHoc();};
	/**
	 * Exits the Web Workitem Handler without saving changes to the workitem.
	 * @param config (Object} Optional.
	 * Config object:<pre><code>
	 *     {
	 *     confirmMsg: String. Use confirm message when exit.
	 *     eventFn: Function. The function to call. Default function is onWorkitemExit().
	  *    }
	 * </code></pre>
	 * @example
	 *  basicWIHActionClient.exit({confirmMsg: "Exit this application?",
	 *                             eventFn: function(){return validation();}})
	 */
	this.exit = function(config){this.init();return this.basicWIH.exit(config);};
	/**
	 * Launches the Activity Help (General Information) information box.
	 */
	this.generalInfo = function(){this.init();return this.basicWIH.generalInfo();};
	/**
	 * Launches the Select Next User dialog box.
	 */
	this.selectNextUser = function(){this.init();return this.basicWIH.selectNextUser();};
	/**
	 * Launches the Select Next Appplication dialog box.
	 */
	this.selectNextApplication = function(){this.init();return this.basicWIH.selectNextApplication();};
	/**
	 * Replies the current workitem to prior participant.
	 * @since 12.1.0.0002
	 */
	this.reply = function(){this.init();return this.basicWIH.reply();};
	/**
	 * Forwards the current workitem to an another participant.
	 * @since 12.1.0.0002
	 */
	this.forward = function(){this.init();return this.basicWIH.forward();};
	/**
	 * Responds the current workitem with the response and sends it to the next step.
	 * @param responseName {String} The response name should be one of the defined by the activity.
	 * @since 12.1.0.0002
	 */
	this.respond = function(responseName){this.init();return this.basicWIH.respond(responseName);};
	/**
	 * Returns responses.
	 * @return {Array} Array of response object.
	 * <p>
	 *     The response object:
	 *     {ID: <i>Response ID</i>, NAME: <i>Response Name</i>, COMMENTREQUIRED: <i>If true, a comment required when respond</i>}
	 * @example <caption>Returned object</caption>
	 *   [{
	 *   	"ID": 1,
	 *   	"COMMENTREQUIRED": false,
	 *   	"NAME": "Save"
	 *   },
	 *   {
	 *   	"ID": 2,
	 *   	"COMMENTREQUIRED": true,
	 *   	"NAME": "Go next"
	 *   }]
	 */
	this.getResponsesInfo = function(){return getResponsesInfo();};
	/**
	 * Sets the response by specified name.
 	 * @param name {String} A response name of the defined by the activity
	 */
	this.setResponseByName = function(name){return setResponseByName(name);};
	/**
	 * Returns a selected response.
	 * @return {Object} {ID: <i>Response ID</i>, NAME: <i>Response Name</i>, COMMENTREQUIRED: <i>If true, a comment required when respond</i>}
	 * @example <caption>Returned object</caption>
	 *   {
	 *   	"ID": 1,
	 *   	"COMMENTREQUIRED": false,
	 *   	"NAME": "Save"
	 *   }
	 */
	this.getSelectedResponse = function(){return getSelectedResponse();};
	/**
	 * Sets comment required flag.
	 * @param require {boolean} If true, the participant have to leave a comment when complete (or respond) workitem.
	 */
	this.setCommentRequired = function(require){return setCommentRequired(require);}
	/**
	 * Sets attachment required flag.
	 * @param require {boolean} If true, the participant have to leave attachment(s) when complete (or respond) workitem.
	 * @param count  {Number} Number of attachments. This parameter valid when the require is true.
	 * @since 12.1.0.0007
	 */
	this.setAttachmentRequired = function(require, count){return setAttachmentRequired(require, count);}
	/**
	 * Sets read comment required flag.
	 * @param require {boolean} If true, the participant have to read comments when complete (or respond) workitem.
	 */
	this.setReadCommentRequired = function(require){return setReadCommentRequired(require);};
	/**
	 * Returns number of comments.
	 * @return {Number} Number of comments.
	 */
	this.getCommentCount = function(){return getCommentCount();};
	/**
	 * @deprecated Use getAttachments
	 */
	this.getAttachmentInfo = function(){return this.getAttachments();};
	/**
	 * Returns attachments information.
	 * @return {Array} Array of attachment object.
	 * @example <caption>Returned object</caption>
	 *   [{
	 *      "PROCESSID": 1000,
	 *   	"DESCRIPTION": "",
	 *   	"DMDOCRTYPE": "N",
	 *   	"WORKITEMSEQUENCE": 109,
	 *   	"FILENAME": "Timeslip New Project Codes.xlsx",
	 *   	"CREATOR": "0000000133",
	 *   	"INTYPE": "C",
	 *   	"CREATIONDATE": "2013/05/21 12:57:55",
	 *   	"DISPLAYNAME": "Timeslip New Project Codes",
	 *   	"OUTTYPE": "B",
	 *   	"ACTIVITYSEQUENCE": 5,
	 *   	"DMDOCUMENTID": "",
	 *   	"ID": 115,
	 *   	"SIZE": 16934,
	 *   	"CREATORNAME": "Chae, Chang Hwan",
	 *   	"TYPE": "G",
	 *   	"ACTIVITYNAME": "Activity 1",
	 *   	"CATEGORY": "",
	 *   	"ETCINFO": "",
	 *   	"FILEEXTENSION": "xlsx"
	 *   },
	 *   {
	 *      "PROCESSID": 1000,
	 *   	"DESCRIPTION": "",
	 *   	"DMDOCRTYPE": "N",
	 *   	"WORKITEMSEQUENCE": 109,
	 *   	"FILENAME": "logo.png",
	 *   	"CREATOR": "0000000133",
	 *   	"INTYPE": "C",
	 *   	"CREATIONDATE": "2013/05/29 09:32:36",
	 *   	"DISPLAYNAME": "logo",
	 *   	"OUTTYPE": "B",
	 *   	"ACTIVITYSEQUENCE": 5,
	 *   	"DMDOCUMENTID": "",
	 *   	"ID": 117,
	 *   	"SIZE": 27560,
	 *   	"CREATORNAME": "Chae, Chang Hwan",
	 *   	"TYPE": "G",
	 *   	"ACTIVITYNAME": "Activity 1",
	 *   	"CATEGORY": "",
	 *   	"ETCINFO": "",
	 *   	"FILEEXTENSION": "png"
	 *   }]
	 *  @since 12.1.0.0003
	 */
	this.getAttachments = function(){return getAttachments();};
	/**
	 * Returns comments.
	 * @return {Array} Array of comment object.
	 * @example <caption>Returned object</caption>
	 *   [{
	 *   	"commentID": 118,
	 *   	"type": "COMMENT",
	 *   	"activitySeq": 9,
	 *   	"activityName": "Activity 3",
	 *   	"workitemSeq": 112,
	 *   	"creatorID": "0000000135",
	 *   	"creatorName": "Lee, Michael",
	 *   	"creationDate": "05/29/13 14:02",
	 *   	"creationDateLong": 1369864971000,
	 *   	"comments": "Great"
	 *   },
	 *   {
	 *   	"commentID": 114,
	 *   	"type": "COMMENT",
	 *   	"activitySeq": 5,
	 *   	"activityName": "Activity 1",
	 *   	"workitemSeq": 109,
	 *   	"creatorID": "0000000133",
	 *   	"creatorName": "Chae, Chang Hwan",
	 *   	"creationDate": "05/21/13 11:10",
	 *   	"creationDateLong": 1369163425000,
	 *   	"comments": "Good"
	 *   }]
	 * @since 12.1.0.0003
	 */
	this.getComments = function(){return getComments();};
	/**
	 * Returns Discussion object.
	 * Available functions: stopAutoFeed(), startAutoFeed(int), getComments()
	 * @since 12.3.0.0002
	 */
	this.getDiscussion = function(){return wihDiscussion;};
	/**
	 * Removes an attachment by ID
	 * @param attachmentId {Number} Attachment ID
	 * @since 12.1.0.0003
	 */
	this.removeAttachment = function(attachmentId){return removeAttachment(attachmentId, arguments[1]);};
	/**
	 * Updates attachments
	 * @param attachments {Array} Attachment objects.
	 * Mandatory field: ID
	 * Updatable fields: FILENAME, DESCRIPTION, DISPLAYNAME, CATEGORY, ETCINFO
	 * Sending metadata to EDMS: set JavaScript Object to predefined field "edmsMetadata".
	 *
	 * @example <caption>Input parameter</caption>
	 * [{
	 *	"PROCESSID": 1000,
	 *	"ID": 106,
	 *	"DESCRIPTION": "policy",
	 *	"CATEGORY": "Group",
	 *	"FILENAME": "file.png",
	 *	"DISPLAYNAME": "medical chart",
	 *	"ETCINFO": "<tag>123</tag>"
	 *},
	 * {
	 *	"PROCESSID": 2000,
	 *	"ID": 105,
	 *  "DMSERVERID": "1000000002",
	 *	"edmsMetadata": [{name: "Case Number", type: "Number", value: 1234567890, displayName:"Case Number"},
	 *	                 {name: "Creator", type: "Text", value:"Changhwan", displayName:"Creator Name"},
	 *		             {name: "Created", type: "DateTime", value:"12/25/2014", displayName:"Created"}]
	 *}]
	 * @since 12.3.0.0002
	 */
	this.updateAttachments = function(attachments){return updateAttachments(attachments);};
	/**
	 * Reload attachments from server.
	 * @since 12.3.0.0002
	 */
	this.reloadAttachments = function(config){return reloadAttachments(config);};

	/**
	 * Returns the current workitem context information.
	 * @return {Object}
	 * @example  <caption>Returned object</caption>
	 *   {
	 *   	"User": {
	 *   		"Name": "Chae, Chang Hwan",
	 *   		"MemberID": "0000000133"
	 *   	},
	 *   	"Activity": {
	 *   		"Name": "Activity 1",
	 *   		"Sequence": 5
	 *   	},
	 *   	"SessionInfoXML": "&lt;SESSIONINFO KEY=\"2620_1369230133\" USERID=\"0000000133\" SERVERID=\"0000001001\" IP=\"bf12\" PORT=\"7201\" DEPTID=\"0000000118\" USERTYPE=\"U\" />",
	 *   	"Process": {
	 *   		"Initiator": "0000000133",
	 *   		"ProcessDefinitionID": 172,
	 *   		"Name": "Timeslip",
	 *   		"Description": "",
	 *   		"CompleteDateTime": 0,
	 *   		"CreationDateTime": 1368563416000,
	 *   		"InitiatorName": "Chae, Chang Hwan",
	 *   		"ID": 683,
	 *   		"ProcessState": "R"
	 *   	},
	 *   	"Workitem": {
	 *   		"StartDateTime": 0,
	 *   		"DeadlineDateTime": 0,
	 *   		"State": "I",
	 *   		"CreationDateTime": 1368739313000,
	 *   		"ParticipantName": "Chae, Chang Hwan",
	 *   		"Sequence": 109,
	 *   		"ParticipantType": "U"
	 *   	}
	 *   }
	 * @since 12.1.0.0003
	 */
	this.getWorkitemContext =  function(){return getWorkitemContext();};

	/**
	 * Reload the workitem context information from server.
	 * @param callback callback function
	 * @returns 12.1.0.0006
	 */
	this.reloadWorkitemContext =  function(callback){return reloadWorkitemContext(callback);};
	/**
	 * Returns a workitem handler option by specified name.
	 * @param opt {string} "closeWihOnComplete", "completionWindow"
	 * @see {@link setWIHOption}
	 * @return {*}
	 */
    this.getWIHOption = function(opt){return getWIHOption(opt);};

	/**
	 * Sets a workitem handler option.
	 * <p>
	 *     Available options:
	 *     <ul>
	 *     <li>"closeWihOnComplete": boolean. If true, the workitem handler close when complete (or respond) workitem.
	 *     <li>"completionWindow": boolean. If false, the Completion Window bypass when complete (or respond) workitem.
	 *     </ul>
	 * @param opt {string} Option name
	 * @param value {*} Value
	 */
    this.setWIHOption = function(opt, value){return setWIHOption(opt, value);};

	/**
	 * Returns the Workitem Handler's UI Controller.
	 * @return {WIHUI}
	 * @since 12.1.0.0003
	 */
	this.getUI = function(){return getUI();};

	/**
	 * Notify message.
	 * @param msg {string} display message
	 * @param opt {object} number or {duration: milliseconds}
	 * @example
	 * basicWIHActionClient.notify("Hello");
	 * basicWIHActionClient.notify("Hello", 5000);
	 * basicWIHActionClient.notify("Hello", {duration:5000});
	 * @since 12.3.0.0000
	 */
	this.notify = function(msg, opt){notify(msg, opt);};

	/**
	 * Loads the application form data from server.
	 * @param config {object}
	 * @since NOT PUBLISHED
	 */
	this.loadFormData = function(config){return loadFormData(config);};

	/**
	 * Saves the application form data.
	 * @param formData {object}
	 * @param config {object}
	 * @since NOT PUBLISHED
	 */
	this.saveFormData = function(formData, config){return saveFormData(formData, config);};

	/**
	 * Returns the URL to open an attachment or EDMS file viewer URL.
	 * @param processId process Id
	 * @param attachmentId attachment Id
	 * @param metadata metadata for EDMS file viewer
	 * @return {string} URL
	 * @since 12.3.0.0002
	 */
	this.getDocumentURL = function(processId, attachmentId, metadata){return getDocumentURL(processId, attachmentId, metadata);};

	/**
	 * Sets enable or disable actions of the Workitem handler.
	 * @param value {boolean}
	 * @since 12.4.0.0002
	 */
	this.setActionReady = function(value){setActionReady(value);};

	/**
	 * Returns true if action ready.
	 * @return {boolean}
	 * @since 12.4.0.0002
	 */
	this.isActionReady = function(){return isActionReady();};

	/**
	 * Complete application
	 * @param appId Application ID or "ALL"
	 * @param config {object}
	 * @since 12.4.0.0002
	 */
	this.completeApplication = function(appId, config){completeApplication(appId, config);};

	/**
	 * @deprecated
	 */
	this.doAction = function(command)
	{
		var ret;
		if(command == this.basicWIH.ACTION_COMPLETE)ret = this.complete();
		else if(command == this.basicWIH.ACTION_SAVE) ret = this.save();
		else if(command == this.basicWIH.ACTION_MONITOR) ret = this.monitor();
		else if(command == this.basicWIH.ACTION_COMMENT) ret = this.comment();
		else if(command == this.basicWIH.ACTION_ATTACH) ret = this.attach();
		else if(command == this.basicWIH.ACTION_EDMSATTACH) ret = this.edmsAttach();
		else if(command == this.basicWIH.ACTION_ADHOC) ret = this.adHoc();
		else if(command == this.basicWIH.ACTION_EXIT) ret = this.exit();
		else if(command == this.basicWIH.ACTION_GENERALINFO) ret = this.generalInfo();
		else if(command == this.basicWIH.ACTION_SELECT_NEXT_USER) ret = this.selectNextUser();
		else if(command == this.basicWIH.ACTION_SELECT_NEXT_APPLICATION) ret = this.selectNextApplication();
		else if(command == this.basicWIH.ACTION_REPLY) ret = this.reply();
		else if(command == this.basicWIH.ACTION_FORWARD) ret = this.forward();
		else if(command == this.basicWIH.ACTION_RESPONSE) ret = this.respond();
		return ret;
	};

	/**
	 * Returns the Workitem Handler's utility functions.
	 * @since 12.1.0.0007
	 */
	this.utility = {
		/**
		 * Returns encrypted text
		 * @param text plain text
		 * @returns {string} encrypted text
		 * @since 12.1.0.007
		 */
		encryptText: function(text){return encrypt(text);},
		/**
		 * Returns decrypted text
		 * @param text encrypted text
		 * @returns {string} decrypted text
		 * @since 12.1.0.007
		 */
		decryptText: function(text){return decrypt(text);}
	};

	this.init();
}

/**
 * @classdesc
 * A base class for layout panes that require layout-related functionality such as show, hide, etc.
 * This instance can get by <code>basicWIHActionClient.getUI().getPanel(paneId)</code>.
 *
 * @param paneId {string} One of the following constants: <code>PANE_INSTRUCTION, PANE_TOOL, PANE_CONTEXT_INFORMATION, PANE_PROCESS_MAP, PANE_MENU, PANE_ATTACHMENT, PANE_INTERNAL_DISCUSSION, PANE_CORRESPONDENCE</code>
 * @class
 * @since 12.1.0.003
 */
function WIHPane(paneId)
{
	var id = paneId;
	/**
	 * Hides this pane. When a pane is hidden, it has no toggler button as if it did not exist.
	 * @return {WIHPane} this
	 * @example
	 * var ui = basicWIHActionClient.getUI();
	 * ui.getPane(ui.PANE_TOOL).hide();
	 * @since 12.1.0.003
	 */
	this.hide = function()
	{
		if(id == PANE_INSTRUCTION)
		{
			hideInstruction();
		}
		else if(id == PANE_TOOL)
		{
			hideSupplementalTools();
		}
		else if(id == PANE_CONTEXT_INFORMATION)
		{
			$("#wihContextInfoOuterDiv").hide();
			resizeContents();
		}
		else if(id == PANE_PROCESS_MAP)
		{
			$("#trProcessMap").hide();
			resizeContents();
		}
		else if(id == PANE_MENU)
		{
            var northPanel = Ext.getCmp('uiLayoutNorthPanel');
            if(northPanel) {
                northPanel.hide();
            }
		}
		else if(id == PANE_ATTACHMENT)
		{
			var panel = Ext.getCmp('attachmentPanel');
			if(panel)
			{
				panel.hide();
			}
		}
		else if(id == PANE_INTERNAL_DISCUSSION)
		{
			var panel = Ext.getCmp('discussionPanel');
			if(panel)
			{
				panel.hide();
			}
		}
		else if(id == PANE_CORRESPONDENCE)
		{
			var panel = Ext.getCmp('correspondencePanel');
			if(panel)
			{
				panel.hide();
			}
		}
		return this;
	};
	/**
	 * Un-hide this pane.
	 * @return {WIHPane} this
	 * @example
	 * var ui = basicWIHActionClient.getUI();
	 * ui.getPane(ui.PANE_TOOL).show();
	 * @since 12.1.0.003
	 */
	this.show = function()
	{
		if(id == PANE_INSTRUCTION)
		{
			var instructionPanel = Ext.getCmp('uiLayoutEastPanel');
			showInstructionToggleBar = true;
			if(instructionPanel) {
				instructionPanel.show();
				positioningToggleButton("east", instructionPanel.isHidden());
			}
		}
		else if(id == PANE_TOOL)
		{
			var supplementalToolsPanel = Ext.getCmp('uiLayoutWestPanel');
			showSupplementalToolsToggleBar = true;
			if(supplementalToolsPanel) {
				supplementalToolsPanel.show();
				positioningToggleButton("west", supplementalToolsPanel.isHidden());
			}
		}
		else if(id == PANE_CONTEXT_INFORMATION)
		{
			$("#wihContextInfoOuterDiv").show();
			resizeContents();
		}
		else if(id == PANE_PROCESS_MAP)
		{
			$("#trProcessMap").show();
			resizeContents();
		}
		else if(id == PANE_MENU)
		{
            var northPanel = Ext.getCmp('uiLayoutNorthPanel');
            if(northPanel) {
                northPanel.show();
            }
		}
		else if(id == PANE_ATTACHMENT)
		{
			var panel = Ext.getCmp('attachmentPanel');
			if(panel)
			{
				panel.show();
			}
		}
		else if(id == PANE_INTERNAL_DISCUSSION)
		{
			var panel = Ext.getCmp('discussionPanel');
			if(panel)
			{
				panel.show();
			}
		}
		else if(id == PANE_CORRESPONDENCE)
		{
			var panel = Ext.getCmp('correspondencePanel');
			if(panel)
			{
				panel.show();
			}
		}
		return this;
	};
	/**
	 * Opens the pane.
	 * @return {WIHPane} this
	 * @example
	 * var ui = basicWIHActionClient.getUI();
	 * ui.getPane(ui.PANE_TOOL).show();
	 * @since 12.3.0.000
	 */
	this.open = function()
	{
		if(id == PANE_INSTRUCTION)
		{
			var instructionPanel = Ext.getCmp('uiLayoutEastPanel');
			if(!displayStatus.instruction)
			{
				if(instructionPanel) {
					instructionPanel.expand();
					positioningToggleButton("east", false);
					displayStatus.instruction = true;
				}
			}
		}
		else if(id == PANE_TOOL)
		{
			var supplementalToolsPanel = Ext.getCmp('uiLayoutWestPanel');
			if(!displayStatus.supplementalTools)
			{
				if(supplementalToolsPanel) {
					supplementalToolsPanel.expand();
					positioningToggleButton("west", false);
					displayStatus.supplementalTools = true;
				}
			}
		}
		else if(id == PANE_CONTEXT_INFORMATION)
		{
			$("#wihContextInfoOuterDiv").show();
			resizeContents();
		}
		else if(id == PANE_PROCESS_MAP)
		{
			expandProcessMap();
		}
		else if(id == PANE_MENU)
		{
			var northPanel = Ext.getCmp('uiLayoutNorthPanel');
			if(northPanel) {
				northPanel.show();
			}
		}
		else if(id == PANE_ATTACHMENT)
		{
			var panel = Ext.getCmp('attachmentPanel');
			if(panel)
			{
				panel.expand();
			}
		}
		else if(id == PANE_INTERNAL_DISCUSSION)
		{
			var panel = Ext.getCmp('discussionPanel');
			if(panel)
			{
				panel.expand();
			}
		}
		else if(id == PANE_CORRESPONDENCE)
		{
			var panel = Ext.getCmp('correspondencePanel');
			if(panel)
			{
				panel.expand();
			}
		}

		return this;
	};
	/**
	 * Close this pane. If the pane is already closed, nothing happens.
	 * @return {WIHPane} this
	 * @example
	 * var ui = basicWIHActionClient.getUI();
	 * ui.getPane(ui.PANE_TOOL).close();
	 * @since 12.1.0.003
	 */
	this.close = function()
	{
		if(id == PANE_INSTRUCTION)
		{
			var instructionPanel = Ext.getCmp('uiLayoutEastPanel');
			if(displayStatus.instruction)
			{
				if(instructionPanel) {
					instructionPanel.collapse();
					positioningToggleButton("east", true);
					displayStatus.instruction = false;
				}
			}
		}
		else if(id == PANE_TOOL)
		{
			var supplementalToolsPanel = Ext.getCmp('uiLayoutWestPanel');
			if(displayStatus.supplementalTools)
			{
				if(supplementalToolsPanel) {
					supplementalToolsPanel.collapse();
					positioningToggleButton("west", true);
					displayStatus.supplementalTools = false;
				}
			}
		}
		else if(id == PANE_CONTEXT_INFORMATION)
		{
			collapseContextInfo();
		}
		else if(id == PANE_PROCESS_MAP)
		{
			collapseProcessMap();
		}
		else if(id == PANE_MENU)
		{
            var northPanel = Ext.getCmp('uiLayoutNorthPanel');
            if(northPanel) {
                northPanel.hide();
            }
		}
		else if(id == PANE_ATTACHMENT)
		{
			var panel = Ext.getCmp('attachmentPanel');
			if(panel)
			{
				panel.collapse();
			}
		}
		else if(id == PANE_INTERNAL_DISCUSSION)
		{
			var panel = Ext.getCmp('discussionPanel');
			if(panel)
			{
				panel.collapse();
			}
		}
		else if(id == PANE_CORRESPONDENCE)
		{
			var panel = Ext.getCmp('correspondencePanel');
			if(panel)
			{
				panel.collapse();
			}
		}
		return this;
	};
}

/**
 * @classdesc
 * A base class for Web workitem handler menu items that require menu-related functionality such as show, hide, etc.
 * This instance can get by <code>basicWIHActionClient.getUI().getMenuItem(menuItemId)</code>.
 * @class
 * @since 12.1.0.003
 */
function WIHMenuItem(menuItemId, obj)
{
	var id = menuItemId;
	this.comp = obj;
	/**
	 * Shows this menu
	 * @return {WIHMenuItem} this
	 * @since 12.1.0.003
	 */
	this.show = function()
	{
		this.comp.show();
		try
		{
			this.comp.up().getComponent(menuItemId + 'Separator').show();
		}
		catch(e)
		{
			// ignore
		}
		return this;
	};

	/**
	 * Hides this menu
	 * @return {WIHMenuItem} this
	 * @since 12.1.0.003
	 */
	this.hide = function()
	{
		this.comp.hide();
		try
		{
			this.comp.up().getComponent(menuItemId + 'Separator').hide();
		}
		catch(e)
		{
			// ignore
		}
		return this;
	};

	/**
	 * Sets this menu's text
	 * @param text {string} The menu text
	 * @return {WIHMenuItem} this
	 * @since 12.1.0.003
	 */
	this.setText = function(text)
	{
		if(typeof(this.comp.setText) != 'undefined')
		{
			this.comp.setText(text);
		}
		return this;
	};

	/**
	 * Gets the text for this menu
	 * @return {string} The menu text
	 * @since 12.1.0.003
	 */
	this.getText = function()
	{
		if(typeof(this.comp.getText) != 'undefined')
		{
			return this.comp.getText();
		}
		else if(typeof(this.comp.text) != 'undefined')
		{
			return this.comp.text;
		}
		else
		{
			return undefined;
		}
	};

	/**
	 * Gets the sub menu item. You can retrieve the responses selection box.
	 * @example
	 * // Rename the response name by response ID
	 * // You can get the responses information from getResponsesInfo()
	 * var ui = basicWIHActionClient.getUI();
	 * ui.getMenuItem('response').getMenuItem('1').setText('Reject')
 	 * @param menuItemId {string} sub-menu item id. In case of the response menu, menuItemId should be a response Id.
	 * @return {WIHMenuItem}
	 * @since 12.1.0.003
	 */
	this.getMenuItem = function(menuItemId)
	{
		if(typeof(this.comp.menu) != 'undefined')
		{
			if(typeof(this.comp.menu.getComponent) != 'undefined')
			{
				var subComp = this.comp.menu.getComponent(menuItemId);
				if(typeof(subComp) != 'undefined')
				{
					return new WIHMenuItem(menuItemId, subComp);
				}
			}
		}
	};
}

/**
 * @classdesc
 * This class provides interfaces for graphical user interface components of Web WIH.
 * You can hide or show the toolbar, a pane, or a section of Web WIH.
 * You can hide or show a specific button on the toolbar with the interfaces of this class.
 * Refer to BizFlowWIHClient for programming & event interfaces of Web WIH.
 * <p>
 * This instance can get by <code>basicWIHActionClient.getUI()</code>.
 * @class
 * @since 12.1.0.003
 */
function WIHUI()
{
	var paneTool, paneInstruction, paneProcessMap, paneContextInfo, paneMenu, paneAttachment, paneInternalDiscussion, paneCorrespondence;

	/**
	 * The Instruction pane name.
	 * @constant
	 * @type {string}
	 */
	this.PANE_INSTRUCTION = PANE_INSTRUCTION;
	/**
	 * The Tool pane name.
	 * @constant
	 * @type {string}
	 */
	this.PANE_TOOL = PANE_TOOL;
	/**
	 * The Process Map pane name.
	 * @constant
	 * @type {string}
	 */
	this.PANE_PROCESS_MAP = PANE_PROCESS_MAP;
	/**
	 * The Context Information pane name.
	 * @constant
	 * @type {string}
	 */
	this.PANE_CONTEXT_INFORMATION = PANE_CONTEXT_INFORMATION;
	/**
	 * The Menu pane name.
	 * @constant
	 * @type {string}
	 */
	this.PANE_MENU = PANE_MENU;
	/**
	 * The attachment pane name.
	 * @constant
	 * @type {string}
	 */
	this.PANE_ATTACHMENT = PANE_ATTACHMENT;
	/**
	 * The internal discussion pane name.
	 * @constant
	 * @type {string}
	 */
	this.PANE_INTERNAL_DISCUSSION = PANE_INTERNAL_DISCUSSION;
	/**
	 * The correspondence pane name.
	 * @constant
	 * @type {string}
	 */
	this.PANE_CORRESPONDENCE = PANE_CORRESPONDENCE;

	/**
	 * Get the menu object by specified Id.
	 * @example <caption>Run from Web Application</caption>
	 *  // Rename response's selection box label
	 *  basicWIHActionClient.getUI().getMenuItem('response').setText('Select one...');
	 *  // Hide Save menu
	 *  basicWIHActionClient.getUI().getMenuItem('save').hide();
	 * @param menuItemId {string} <code>complete, response, reply, forward, save, attachment, discussion, monitor, adhoc, selectNextUser, selectNextApp, viewMessage, viewRequirement, exit, help</code>
	 * @return {WIHMenuItem}
	 * @since 12.1.0.0003
	 */
	this.getMenuItem = function(menuItemId){
		if(typeof(_mainToolbar) == 'undefined') return;
		var comp = _mainToolbar.getComponent(menuItemId);
		if(typeof(comp) == 'undefined') return;
		return new WIHMenuItem(menuItemId, comp);
	};

	/**
	 * Returns the pane by specified pane Id.
	 * @param {string} paneId One of the following constants: <code>PANE_INSTRUCTION, PANE_TOOL, PANE_CONTEXT_INFORMATION, PANE_PROCESS_MAP, PANE_MENU, PANE_ATTACHMENT, PANE_INTERNAL_DISCUSSION, PANE_CORRESPONDENCE</code>
	 * @return {WIHPane} Pane object
	 * @example
	 * // Hide the instruction pane
	 * var ui = basicWIHActionClient.getUI();
	 * ui.getPane(ui.PANE_INSTRUCTION).hide();
	 * @since 12.1.0.0003
	 */
	this.getPane = function(paneId)
	{
		var pane;
		if(paneId == this.PANE_INSTRUCTION)
		{
			pane = (typeof(paneInstruction) == 'undefined') ? new WIHPane(paneId) : paneInstruction;
		}
		else if(paneId == this.PANE_TOOL)
		{
			pane = (typeof(paneTool) == 'undefined') ? new WIHPane(paneId) : paneTool;
		}
		else if(paneId == this.PANE_CONTEXT_INFORMATION)
		{
			pane = (typeof(paneContextInfo) == 'undefined') ? new WIHPane(paneId) : paneContextInfo;
		}
		else if(paneId == this.PANE_PROCESS_MAP)
		{
			pane = (typeof(paneProcessMap) == 'undefined') ? new WIHPane(paneId) : paneProcessMap;
		}
		else if(paneId == this.PANE_MENU)
		{
			pane = (typeof(paneMenu) == 'undefined') ? new WIHPane(paneId) : paneMenu;
		}
		else if(paneId == this.PANE_ATTACHMENT)
		{
			pane = (typeof(paneAttachment) == 'undefined') ? new WIHPane(paneId) : paneAttachment;
		}
		else if(paneId == this.PANE_INTERNAL_DISCUSSION)
		{
			pane = (typeof(paneInternalDiscussion) == 'undefined') ? new WIHPane(paneId) : paneInternalDiscussion;
		}
		else if(paneId == this.PANE_CORRESPONDENCE)
		{
			pane = (typeof(paneCorrespondence) == 'undefined') ? new WIHPane(paneId) : paneCorrespondence;
		}

		return pane;
	};

	/**
	 * Removes a pane by specified name.
	 * @param {string} paneId One of the following constants: <code>PANE_INSTRUCTION, PANE_TOOL, PANE_CONTEXT_INFORMATION, PANE_PROCESS_MAP, PANE_MENU, PANE_ATTACHMENT, PANE_INTERNAL_DISCUSSION, PANE_CORRESPONDENCE</code>
	 * @example
	 * var ui = basicWIHActionClient.getUI();
	 * ui.removePane(ui.PANE_INSTRUCTION)
	 * @deprecated
	 */
	this.removePane = function(paneId)
	{
		this.getPane(paneId).remove();
	};

	/**
	 * Hides a pane by specified name. When a pane is hidden, it has no toggler button as if it did not exist.
	 * @param {string} paneId One of the following constants: <code>PANE_INSTRUCTION, PANE_TOOL, PANE_CONTEXT_INFORMATION, PANE_PROCESS_MAP, PANE_MENU, PANE_ATTACHMENT, PANE_INTERNAL_DISCUSSION, PANE_CORRESPONDENCE</code>
	 * @example
	 * var ui = basicWIHActionClient.getUI();
	 * ui.hidePane(ui.PANE_TOOL)
	 * @deprecated
	 */
	this.hidePane = function(paneId)
	{
		this.getPane(paneId).hide();
	};

	/**
	 * Shows a pane by specified name if the pane is available.
	 * @param {string} paneId One of the following constants: <code>PANE_INSTRUCTION, PANE_TOOL, PANE_CONTEXT_INFORMATION, PANE_PROCESS_MAP, PANE_MENU, PANE_ATTACHMENT, PANE_INTERNAL_DISCUSSION, PANE_CORRESPONDENCE</code>
	 * @example
	 * var ui = basicWIHActionClient.getUI();
	 * ui.showPane(ui.PANE_TOOL)
	 * @deprecated
	 */
	this.showPane = function(paneId)
	{
		this.getPane(paneId).show();
	};

	/**
	 * Returns the response menu object.
	 * @return {Ext.menu.Menu} {@link http://docs.sencha.com/extjs/4.1.0/#!/api/Ext.menu.Menu|Ext.menu.Menu}
	 * @deprecated
	 */
	this.getResponseMenu = function(){
		return _responseMenu;
	};

	/**
	 * Get the main menu toolbar object. You can retrieve to each menu via {@link http://docs.sencha.com/extjs/4.1.0/#!/api/Ext.toolbar.Toolbar-method-getComponent|getComponent(menuId)} API. <p>
	 * menuId : <code>complete, response, reply, forward, save, attachment, discussion, monitor, adhoc, selectNextUser, selectNextApp, viewMessage, viewRequirement, exit, help</code>
	 * @example <caption>Run from Web Application</caption>
	 *  // Hide Save menu with separator
	 *  basicWIHActionClient.getUI().getMainToolbar().getComponent('save').hide();
	 *  basicWIHActionClient.getUI().getMainToolbar().getComponent('saveSeparator').hide();
	 * @return {Ext.toolbar.Toolbar} {@link http://docs.sencha.com/extjs/4.1.0/#!/api/Ext.toolbar.Toolbar|Ext.toolbar.Toolbar}
	 * @deprecated
	 */
	this.getMainToolbar = function(){
		return _mainToolbar;
	};
}

var _wihActionClient;
/**
 * Returns an instance of WIHActionClient Class
 * @access private
 * @return {WIHActionClient}
 */
function getWIHActionClient()
{
	if(typeof(_wihActionClient) == "undefined")
	{
		_wihActionClient = new WIHActionClient();
	}
	return _wihActionClient;
}

var _wihUI;
/**
 * Returns an instance of WIHUI Class
 * @access private
 * @return {WIHUI}
 */
function getUI()
{
	if(typeof(_wihUI) == "undefined")
	{
		_wihUI = new WIHUI();
	}
	return _wihUI;
}

function removeAttachment(attachmentId, config)
{
	$.ajax({
		type: "GET",
		url: contextPath + "/_scriptlibrary/attachdelete.jsp",
		data: {ids: attachmentId},
		dataType: "json",
		cache:false,
		success: function(response) {
			if(response.success)
			{
				loadAttachments({event:'DELETED'});
			}
			else if(response.message)
			{
				notify(response.message);
			}
		},
		error: function(e){
			notify('Error: ' + e.statusText);
		}
	});
}

function reloadAttachments(config)
{
	var obj = $.extend({}, config, {event:'LOADED'});
	loadAttachments(obj);
}

function updateAttachments(attachments)
{
	$.ajax({
		type: "POST",
		url: contextPath + "/_scriptlibrary/updateattachments.jsp",
		data: {procId: processId, attachments: JSON.stringify(attachments)},
		dataType: "json",
		cache:false,
		success: function(response) {
			if(response.success)
			{
				loadAttachments({event:'UPDATED'});
			}
			else if(response.message)
			{
				notify(response.message);
			}
		},
		error: function(e){
			notify('Error: ' + e.statusText);
		}
	});
}
/**
 * @since 12.3.0002.00
 */
function getDocumentURL(processId, attachmentId, metadata)
{
	var att = getAttachment(processId, attachmentId);
	if(att == null) return undefined;

	var url;
	if(att.FILEEXTENSION.toUpperCase() == "URL")
	{
		url = contextPath + "/common/viewurlfile.jsp?procId=" + processId + "&attachSeq=" + attachmentId;
		if(metadata)
		{
			url += "&metadata=" + encodeURIComponent(JSON.stringify(metadata));
		}
	}
	else
	{
		url = contextPath + "/bizcoves/wih/attachopen.jsp?basicWihReadOnly="+basicWihReadOnly + "&procId=" + processId + "&attachid=" + attachmentId;
		if(metadata)
		{
			url += "&metadata=" + encodeURIComponent(JSON.stringify(metadata));
		}
		url += "&FILENAME=" + encodeURIComponent(att.FILENAME);
	}
	return url;
}
function getAttachment(processId, attachmentId)
{
	var atts = getAttachments();
	var att = null;
	if(atts != null)
	{
		jQuery.each(atts, function(index, elem){
			if(elem.PROCESSID == processId && elem.ID == attachmentId)
			{
				att = elem;
				return false;
			}
		});
	}
	return att;
}
/**
 * @since 12.1.0003.00
 * @return {*}
 */
function getAttachments()
{
	try
	{
		return _attachments;
	}
	catch(e)
	{
		consoleError("getAttachments()", e);
	}

	return null;
}

function loadFormData(config)
{
	//not implemented
}
function saveFormData(formData, config)
{
	//not implemented
}
function consoleError()
{
	if(console && console.error)
	{
		console.error(arguments);
	}
}
var _attachments = null;
function loadAttachments(config)
{
	$.ajax({
		type: "POST",
		url: contextPath + "/_scriptlibrary/loadattachments.jsp",
		data: {procId: processId,
			actId: getWorkitemContext().Activity.Sequence,
			readOnly: ("y"==basicWihReadOnly),
			authority: activityAuthority,
			archived:isArchivedProcess,
			forceLoad: (config && config.forceLoad)? config.forceLoad : false},
		dataType: "json",
		cache:false,
		success: function(response) {
			if(response.success)
			{
				_attachments = response.data;
				createAttachmentList();
				var eventString = (config && typeof(config.event)=='string') ? config.event : "LOADED";
				fire_onChangeWorkitemAttachment(eventString, JSON.stringify(_attachments));
			}
			else if(response.message)
			{
				notify(response.message, 5000);
			}

			try
			{
				if(config && typeof(config.success)=='function')
				{
					config.success(response);
				}
			}
			catch(e)
			{
				notify(e);
			}
		},
		error: function(e){
			notify('load attachments - fail: ' + e.statusText);
		}
	});
}
function createAttachmentList()
{
	try
	{
		$('#file-attachments').empty();
		var attachments = getAttachments();
		if(attachments == null || attachments.length == 0)
		{
			$('#no-attachment-container').show();
		}
		else
		{
			$('#no-attachment-container').hide();
			var template = $('#attachment-item-template').html();
			Mustache.parse(template);
			$.each(attachments, function(index, att){
				att._url = getDocumentURL(att.PROCESSID, att.ID);
				att._title = createAttachmentTitle(att);
				att._iconClass = (att.DMSERVERID && 0<att.DMSERVERID.length)?"fileType large edms":"fileType large";
				att._displayDeleteAction = att.MODIFIABLE ? "" : "hidden";
				att._ownerProcess = function() {
					var owner = "";
					if (0 < att.TAG.length) {
						owner = FROM_PROCESS.replace("{0}", att.TAG);
					}
					return owner;
				};
				att._displayOwnerProcess = (0 < att.TAG.length)?"" : "hidden";
				var rendered = Mustache.render(template, att);
				$('#file-attachments').append(rendered);
			});
		}
	}
	catch(e)
	{
		if(console) console.error(e);
	}
}
function createAttachmentTitle(att)
{
	try
	{
		var title = att.FILENAME
			+ "\n " + COL_AT_CREATIONDATE + ": " + att.CREATIONDATE
			+ "\n " + COL_AT_CREATORNAME + ": " + att.CREATORNAME
			+ "\n " + COL_WL_PROCESSID + ": " + att.PROCESSID
			+ "\n " + COL_WL_PROCESSNAME + ": " + ((0<att.TAG.length)?att.TAG:getWorkitemContext().Process.Name)
			+ "\n " + ATTACHMENT_CATEGORY + ": " + att.CATEGORY
			+ "\n " + LBL_CMM_DESCRIPTION + ": " + att.DESCRIPTION;
		return title;
	}
	catch(e)
	{
		return att.FILENAME;
	}
}