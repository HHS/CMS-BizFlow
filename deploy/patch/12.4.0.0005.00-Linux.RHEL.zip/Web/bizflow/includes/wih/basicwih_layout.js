var outerLayout, innerLayout;
Ext.onReady(function() {
//    var bodyHeight = $(parent.parent.window.document).height() - 27;
//    var bodyWidth = $(parent.parent.window.document).width();
    var bodyWidth = Ext.getBody().getViewSize().width;
    var bodyHeight = Ext.getBody().getViewSize().height;

    outerLayout = Ext.create('Ext.panel.Panel', {
        id: 'outerLayout',
        width: bodyWidth, // Ext.getBody().getViewSize().width,
        height:  bodyHeight,
        layout: 'border',
        defaults: {
            collapsible: false,
            split: true
        },
        items: [
            {
                id: 'uiLayoutCenterPanel',
                region: 'center',     // center region is required, no width/height specified
                xtype: 'panel',
//                bodyStyle: 'background:rgb(211, 211, 211);',
                bodyStyle: 'background:#eaeaea;',
				minWidth: 300,
				minHeight: 400,
                contentEl: 'wihCenter',
                layout: 'fit'
            }
        ],
        renderTo: 'layoutMain'
    });
    if(Ext.get('menubar') && showToolbar) {
        outerLayout.add(
        {
            region: 'north',     // position for region
            xtype: 'panel',
            id: 'uiLayoutNorthPanel',
            height: 35,
            collapsed:	!showToolbar,
            split: false,         // enable resizing
            contentEl: 'menubar',
	        bodyBorder: false,
	        border:false
        });
    }
    if(Ext.get('wihSupplementalTools')) {
        outerLayout.add(
            {
                region: 'west',
                xtype: 'panel',
                width: 360,
//                bodyStyle: 'background:rgb(211, 211, 211);',
                bodyStyle: 'background:#eaeaea;',
                id: 'uiLayoutWestPanel',
                contentEl: 'wihSupplementalTools',
                collapsible: true,   // make collapsible
                collapseMode: 'mini',
                animCollapse: false,
                hideCollapseTool: true,
                collapsed: supplementalToolLayoutState().isClosed,
                header: false,
                listeners: {
                    resize: {
                        fn: function (el) {
                            $("#west-toggle").hide();

                            positioningToggleButton("west", false);
                            resizeContents();
                            resizeSupplementalTools();
                        }
                    },
                    collapse: {
                        fn: function (el) {
                            $("#west-toggle").attr("title", openThisPane).attr("src", imageBasePath + "/wihicons/west_open.png");
                            $("#west-toggle").hide();
                            hideAppListBox();

                            positioningToggleButton("west", true);
                            resizeContents();
                            supplementalToolLayoutState({isClosed: true});
                        }
                    },
                    expand: {
                        fn: function (el) {
                            $("#west-toggle").attr("title", closeThisPane).attr("src", imageBasePath + "/wihicons/west_close.png");
                            $("#west-toggle").hide();
                            hideAppListBox();

                            setReadComment(true);
                            positioningToggleButton("west", false);
                            resizeContents();
                            resizeSupplementalTools();
                            supplementalToolLayoutState({isClosed: false});
                        }
                    }
                },
                layout: {
                    // layout-specific configs go here
                    type: 'accordion',
                    multi: false,
                    titleCollapse: true,
                    hideCollapseTool: true,
                    animate: true,
                    activeOnTop: true
                },
                items: [
                ]
                //                renderTo: 'divAccordionMenu'
            });

	    var accordionItems = [];
	    if(Ext.get('wihAttachments') && Ext.getCmp('uiLayoutWestPanel'))
        {
	        accordionItems.push({
		        id:'attachmentPanel',
		        title: getAttachmentAccordionTitle(),
		        contentEl: 'wihAttachments',
		        iconCls: 'attachAccorionIcon',
		        listeners: {
			        beforecollapse: function (p, direction, animate, eOpts) {
				        var elem = null;
				        if (typeof (event) != 'undefined' && event != null) {
					        if (event.srcElement) {
						        elem = event.srcElement;
					        } else if (event.target) {
						        elem = event.target;
					        }
				        }
				        if (elem && elem.id == 'btnAddAttachment') {
					        if (!p.collapsed) {
						        return false;
					        }
				        }
				        return true;
			        },
			        collapse: function ( p, eOpts ) {
				        attachAccordionLayoutState({isClosed: true});
			        },
			        expand: function ( p, eOpts ) {
				        attachAccordionLayoutState({isClosed: false});
			        }
		        }
	        });
        }

        accordionItems.push({
	        id:'discussionPanel',
	        title: getInternalDiscussionAccordionTitle(),
	        contentEl: 'wihDiscussion',
	        iconCls: 'discussionAccordionIcon',
	        listeners: {
		        beforecollapse: function (p, direction, animate, eOpts) {
			        var elem = null;
			        if (typeof (event) != 'undefined' && event != null) {
				        if (event.srcElement) {
					        elem = event.srcElement;
				        } else if (event.target) {
					        elem = event.target;
				        }
			        }
			        if (elem && elem.id == 'btnAddDiscussion') {
				        if (!p.collapsed) {
					        return false;
				        }
			        }
			        return true;
		        },
		        collapse: function ( p, eOpts ) {
			        discussionAccordionLayoutState({isClosed: true});
		        },
		        expand: function ( p, eOpts ) {
			        resizeDiscussionPanel();
			        discussionAccordionLayoutState({isClosed: false});
			        setReadComment(true);
		        }
	        }
        });

        if(Ext.get('divCorrespondence') && Ext.getCmp('uiLayoutWestPanel')) {
            accordionItems.push({
	            id:'correspondencePanel',
                title: getCorrespondenceAccordionTitle(),
                contentEl: 'divCorrespondence',
                iconCls: 'correspondenceAccordionIcon',
                listeners: {
                    beforecollapse: function (p, direction, animate, eOpts) {
                        var elem = null;
                        if (typeof (event) != 'undefined' && event != null) {
                            if (event.srcElement) {
                                elem = event.srcElement;
                            } else if (event.target) {
                                elem = event.target;
                            }
                        }
                        if (elem && elem.id == 'btnAddCorrespondence') {
                            if (!p.collapsed) {
                                return false;
                            }
                        }
                        return true;
                    },
                    collapse: function ( p, eOpts ) {
                        correspondenceAccordionLayoutState({isClosed: true});
                    },
                    expand: function ( p, eOpts ) {
                        correspondenceAccordionLayoutState({isClosed: false});
                    }
                }
            });
        }
        Ext.getCmp('uiLayoutWestPanel').add(accordionItems);

    }
    if(Ext.get('wihInstructions')) {
        outerLayout.add(
            {
                region: 'east',
                xtype: 'panel',
                bodyCls: 'pane pane-east',
                width: 280,
                id: 'uiLayoutEastPanel',
                contentEl: 'wihInstructions',
                collapsible: true,   // make collapsible
                collapseMode: 'mini',
                animCollapse: false,
                hideCollapseTool: true,
                collapsed:	instructionLayoutState().isClosed,
                header: false,
                listeners: {
                    resize: {
                        fn: function(el) {
                            $("#east-toggle").hide();

                            positioningToggleButton("east", false);
                            resizeContents();
                            instructionLayoutState({isClosed:true});
                        }
                    },
                    collapse: {
                        fn: function(el) {
                            $("#east-toggle").attr("title", openThisPane).attr("src", imageBasePath + "/wihicons/east_open.png" );
                            $("#east-toggle").hide();
                            $("#appListBtn").hide();
                            hideAppListBox();

                            positioningToggleButton("east", true);
                            resizeContents();
                            instructionLayoutState({isClosed:true});
                        }
                    },
                    expand: {
                        fn: function(el) {
                            $("#east-toggle").attr("title", closeThisPane).attr("src",imageBasePath + "/wihicons/east_close.png" );
                            $("#east-toggle").hide();
                            hideAppListBox();

                            positioningToggleButton("east", false);
                            resizeContents();
                            instructionLayoutState({isClosed:false});
                        }
                    }
                },
                layout: 'fit'
            }
        );
    }

    if(Ext.get('uiLayoutWestPanel')) {
        var expandCnt = 0;
        if(attachAccordionLayoutState().isClosed) {
//            Ext.getCmp('uiLayoutWestPanel').items.get(0).collapse();
        } else {
            Ext.getCmp('uiLayoutWestPanel').items.get(0).expand();
            expandCnt++;
        }
        if(0 == expandCnt) {
            if(discussionAccordionLayoutState().isClosed) {
//                Ext.getCmp('uiLayoutWestPanel').items.get(1).collapse();
            } else {
                Ext.getCmp('uiLayoutWestPanel').items.get(1).expand();
                expandCnt++;
            }
        }
        if(0 == expandCnt) {
		    if(Ext.get('divCorrespondence')) {
	            if( correspondenceAccordionLayoutState().isClosed) {
	//                Ext.getCmp('uiLayoutWestPanel').items.get(2).collapse();
	            } else {
	                Ext.getCmp('uiLayoutWestPanel').items.get(2).expand();
                    expandCnt++;
	            }
	        }
        }
        if(0 == expandCnt) {
            Ext.getCmp('uiLayoutWestPanel').items.get(0).expand();
        }
    }
    Ext.EventManager.onWindowResize(function(w, h){
        var width = Ext.getBody().getViewSize().width;
        var height = Ext.getBody().getViewSize().height;
        outerLayout.setSize(width, height);
    });
    if(Ext.get('west-toggle-link')) {
        Ext.get('west-toggle-link').on('click', function(e, t){
            Ext.getCmp('uiLayoutWestPanel').toggleCollapse();
        });
    }
    if(Ext.get('east-toggle-link')) {
        Ext.get('east-toggle-link').on('click', function(e, t){
            Ext.getCmp('uiLayoutEastPanel').toggleCollapse();
        });
    }
});
