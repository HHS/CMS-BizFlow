function skipNavigation() {
    var url = "" + this.location.href;
    url = url.replace("#WORKAREA", "");
    url += "#WORKAREA";
    this.location.href = url;

    try {
        var goToBizCove = document.querySelector("#BizCoveAreaContainer");
        if (goToBizCove) {
            goToBizCove.setAttribute("tabindex", "0");
            goToBizCove.focus();
            goToBizCove.removeAttribute("tabindex");
        }
        //var goToBizCove = document.getElementById("goToBizCove0");
        //if (goToBizCove) {
        //    goToBizCove.focus();
        //}
    } catch (e) {
    }
}

function _modalWindowOnResize() {
    if (typeof modalWindowOnResize != "undefined") {
        modalWindowOnResize();
    }
}

function StartPageLayout(doc) {
    this.doc = doc;
    this.formerWidth = 0;
    this.formerHeight = 0;
    this.width = 0;
    this.height = 0;
    this.availWidth = 0;
    this.availHeight = 0;
    this.initWidth = doc.clientWidth;
    this.initHeight = doc.clientHeight;

    this.updateWidth = function() {
        this.formerWidth = this.width;
        this.width = this.doc.clientWidth;
        this.availWidth = this.width;
    };

    this.updateHeight = function() {
        this.formerHeight = this.height;
        this.height = this.doc.clientHeight
        this.availHeight = this.height;
    };

    this.updateSize = function() {
        this.updateWidth();
        this.updateHeight();
    };

    this.isSizeChanged = function() {
        return this.formerWidth != this.width || this.formerHeight != this.height;
    };

    this.isWidthIncreased = function() {
        return this.width > this.formerWidth;
    };

    this.toString = function() {
        return "formerSize=" + this.formerWidth + "x" + this.formerHeight
                + ", currentSize=" + this.width + "x" + this.height;
    };
}

var _startPageLayout = null;

function setBizCoveAreaSize() {
    var body = getDocumentBody();
    var bizCoveArea = $object("BizCoveArea");
    var pos = getElementPosition(bizCoveArea);
    var offset = 10;
    var clientHeight =  body.clientHeight;
    if ("undefined" != typeof(window.innerHeight)) {
        clientHeight =  window.innerHeight;
    }
    var height =  clientHeight - pos.y - 10;
    if(bizCoveArea) {
        bizCoveArea.style.height = height + "px";
    }
}

function startpage_onresize() {
    setTimeout(function(){
        setBizCoveAreaSize();
        _modalWindowOnResize();
        try{
            _resizeBizCoves();
        }catch(e) {}
    }, 1);
}

function _makeScrollBarForSkipNavigation() {
    var body = document.body;
    var bizCoveArea = $object("BizCoveArea");

    if(bizCoveArea.clientHeight < body.clientHeight) {
        var height = body.clientHeight - bizCoveArea.clientHeight;
        var dummyDiv = document.getElementById("_dummyDivForScrollBar");
        if (null == dummyDiv) {
            dummyDiv = document.createElement("div");
            dummyDiv.setAttribute("id", "_dummyDivForScrollBar");
            document.body.appendChild(dummyDiv);
        }

        dummyDiv.style.width = "10px";
        dummyDiv.style.height = (height) + "px";
    }
}

function startpage_onload() {
    _startPageLayout = new StartPageLayout(document.body);
    _startPageLayout.updateSize();

    if(typeof(resizeAllBizCoves) != 'undefined'){
	    resizeAllBizCoves();
    }

    if (useAccessibility) {
        _makeScrollBarForSkipNavigation();
        if (isSkipNavigation) {
            skipNavigation();
        }
    }
}

function _resizeBizCoves() {
    _startPageLayout.updateSize();
    if (_startPageLayout.isSizeChanged()) {
        __resizeBizCoves();
    }
}

function __resizeBizCoves() {
    var frames = document.getElementsByTagName("iframe");
    if (null != frames) {
        var frameLen = frames.length;
        for (var i = 0; i < frameLen; i++) {
            var frame = frames[i]
            var _colIdx = frame.getAttribute("colidx");
            if ("undefined" != typeof(frame.tagName) && "undefined" != typeof(frame.id) && _colIdx != null && "undefined" != typeof(_colIdx)) {
                var bizCoveCol = document.getElementById("BizCoveCol" + _colIdx);
                var id = "" + frame.id;
                if (id.length > 5 && id.substring(0, 5) == frameIdPrefix) {
                    var initWidth = frame.getAttribute("initWidth");
                    if (null != initWidth) {
                        frame.contentWindow.document.body.style.width = initWidth;
                        frame.style.width = initWidth;
                    }
//                    var initHeight = frame.getAttribute("initHeight");
//                    if (null != initHeight) {
//                        frame.contentWindow.document.body.style.height = initHeight;
//                        frame.style.height = initHeight;
//                    }
                }
            }
        }
    }

	if(typeof(resizeAllBizCoves) != 'undefined'){
		resizeAllBizCoves();
	}
}