SET SERVEROUTPUT ON SIZE 1000000;

DECLARE I_COUNT NUMBER;
		I_LENGTH NUMBER;
		I_SVRID VARCHAR2(10);
BEGIN

DBMS_OUTPUT.PUT_LINE('upgradedb-12.4.0.0010.00-1000.sql(8): member: Checking index xie9member');
SELECT COUNT(1) INTO I_COUNT FROM USER_OBJECTS WHERE UPPER(OBJECT_NAME) = 'XIE9MEMBER';
IF I_COUNT > 0 THEN
	DBMS_OUTPUT.PUT_LINE('upgradedb-12.4.0.0010.00-1000.sql(11): member: Dropping index xie9member');
	EXECUTE IMMEDIATE '
		DROP INDEX xie9member
	';
END IF;

DBMS_OUTPUT.PUT_LINE('upgradedb-12.4.0.0010.00-1000.sql(17): member: Creating index xie9member');
EXECUTE IMMEDIATE '
	CREATE INDEX xie9member ON member (parentdeptid asc)
';

COMMIT;

END;
/