DECLARE @I_LENGTH INT
DECLARE @I_SVRID VARCHAR(10)
BEGIN

PRINT 'upgradedb-12.4.0.0010.00-1000.sql(5): member: Checking index xie9member'
IF EXISTS (SELECT 1 FROM dbo.sysindexes WHERE id = OBJECT_ID(N'member') AND name = N'xie9member')
BEGIN
	PRINT 'upgradedb-12.4.0.0010.00-1000.sql(8): member: Dropping index xie9member'
	DROP INDEX xie9member ON member
END

PRINT 'upgradedb-12.4.0.0010.00-1000.sql(12): member: Creating index xie9member'
CREATE INDEX xie9member ON member (parentdeptid)

END
