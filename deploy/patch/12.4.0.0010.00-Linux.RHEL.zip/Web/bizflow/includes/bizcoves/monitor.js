var wndMonitor;
var passwordValue = "false";
var curBizID;
var sMoveCopyFlag = null;
var actionType = "";
var isArchive = "false";
var forceRemove = "false";
var tmpUseAccessibility = false;

function monitor_OpenSearch(bizid, isSS, reservedParam, useAccessibility)
{
	var sURL = contextPath + "/bizcoves/user/search.jsp?bizcoveID="+bizid+"&first=t" + "&__bizcoveId=" + bizid;
    openPopup(sURL, "", "Search", 780, 300, true, false);
}

function monitor_OpenAdvSearch(bizid, isSS, reservedParam, useAccessibility)
{
	curBizID = bizid;	
	var sUrl = contextPath + "/bizcoves/common/advsearch.jsp?task=search&bizcove="+bizid+"&t=" + (new Date().getTime()) + "&__bizcoveId=" + bizid;
    openPopup(sUrl, "", "Print", 730, 600, false, true);
}

// bug22820,cs18016: quick search
function callQuickSearchOnMonitor(bizid)
{
//	var task="search";
//	var qsearch = eval("document.defActions.qsearch.value");
//	qsearch = qsearch.replace(/%/g, '%25');
//	var newURL = contextPath + servletPath + "?bizcove="+ bizid + "&task="+task + "&qsearch="+qsearch.replace(/ /g, '+');;
//	location.href = newURL;
	document.defActions.submit();
}

function searchMonitorCallBack(bizid, task)
{
	var newURL="";
	
	if(bizid.length == 10)
	{
		newURL= contextPath + getBizcoveServletPath(bizid) + "?bizcove="+ bizid+"&preview_bizcove=y&task=" + task ;
		//newURL += ("&sort="+ eval("monitor_curSortColName"+bizid) + "|"+ eval("monitor_curSortDataType"+bizid)
		//			+"|"+ eval("monitor_curSortDirection"+bizid)+ "&ap="+eval("curpage"+bizid));
		newURL += "&ap=" + eval("curpage"+bizid);
	}
	else
	{
		newURL= contextPath +  getBizcoveServletPath(bizid) + "?bizcove="+ bizid + "&task="+task;
		//newURL += ("&sort="+ eval("monitor_curSortColName"+bizid) + "|"+ eval("monitor_curSortDataType"+bizid)
		//			+"|"+ eval("monitor_curSortDirection"+bizid)+ "&ap="+eval("curpage"+bizid));
		newURL += "&ap=" + eval("curpage"+bizid);
	}

    newURL = adjustMaximizeURL(newURL, bizid);

	location.href = newURL + "&__bizcoveId=" + bizid;
}

function monitor_OpenExcel(bizid, isSS, reservedParam, useAccessibility)
{
	curBizID = bizid;
    var ret = confirm(MSG_CMM_CONFIRM_EXPORT);
    if(ret == true) {
        var sUrl = contextPath + "/data/bizcoves/monitor/monitor_" + bizid + ".jsp?isexcel=y"
            + "&rtime=" + new Date().getMilliseconds()
            + "&__bizcoveId=" + bizid
            + "&bizcove=" + bizid;

        var qsearch = getUrlValue(this.location, "qsearch");
        if (null != qsearch) {
            sUrl += "&qsearch=" + escape(qsearch);
        }

        thisLocationHref(sUrl);
    }
}

var wndDetail;

function monitor_OpenDetail(bizid, isSS, reservedParam, useAccessibility)
{
	curBizID = bizid;
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}
	tmpUseAccessibility = useAccessibility;

	if(isSS)
	{
		 if("F" == eval("item_arr_singleStorage"+bizid+"[3]"))
		{
			var pid = eval("item_arr_singleStorage"+bizid+"[0]");
			var fid = eval("item_arr_singleStorage"+bizid+"[7]");
			var passFlag = eval("item_arr_singleStorage"+bizid+"[3]");
			var urgency =  eval("item_arr_singleStorage"+bizid+"[4]");
			var deadlinesec =eval("item_arr_singleStorage"+bizid+"[5]");
			var initeddate = eval("item_arr_singleStorage"+bizid+"[6]");
			var sType;
			var sStatus = eval("item_arr_singleStorage"+bizid+"[2]");
			if ('R' == sStatus || 'E' == sStatus || 'V' == sStatus || 'S' == sStatus || 'D' == sStatus || 'J' == sStatus)
			{
				sType = 'instance';
			}
			else  // A, T C  <-- Arhicve type
			{
				sType = 'archive';
			}	
			
			var sUrl = "";

			if ('instance' == sType)
			{
				sUrl = contextPath + "/instance/pidetailframe.jsp?type=instance&PROCESSID=" + pid + "&folderid=" + fid 
						  + "&passwordflag=" + passFlag + "&pageid=pi" + "&defid="  + "&defnm=" 
						  + "&urgentstate=" + urgency + "&deadlinesec=" + deadlinesec + "&initiateddate=" +initeddate 
						  + "&rtime=" + new Date().getMilliseconds();
			}
			else
			{
				sUrl = contextPath + "/archive/padetailframe.jsp?type=archive&PROCESSID=" + pid + "&folderid=" + fid 
							+ "&passwordflag=" + passFlag + "&pageid=pa" + "&defid=" + "&defnm=" 
							+ "&rtime=" + new Date().getMilliseconds();
			}
			
			sUrl += "&__bizcoveId=" + bizid;
            wndDetail = openDetailPopup(sUrl, "Process Detail", "ProcDetail", 700, 600, true, true, true, true);
			if(!useAccessibility) {
				monitor_refreshWhenDetailWindowClosed(bizid);
			}
		}
		else if("T" == eval("item_arr_singleStorage"+bizid+"[3]"))
		{
			passwordValue = "false";
			actionType = "detail";

			var sUrl = contextPath + "/common/passwordframe.jsp?callbackname=getCheckPasswordValueMonitor&rtime=" + new Date().getMilliseconds();
			wndPassword = ShowWindow(sUrl, "wndPassword", CHK_PASSWORD, 300, 140, "no");
			
		}
	}
	else
	{
		
		 if (eval("item_arr"+bizid+".length > 1"))
		{
			alert(MSG_CMM_ONLY_ONE_SELECT_ITEM);
		}
		else if (eval("item_arr"+bizid+".length == 0"))
		{
			alert(MSG_CMM_SELECT_ITEM);
		}
		else
		{
			 if("F" == eval("item_arr"+bizid+"[0][3]"))
			{
				var pid = eval("item_arr"+bizid+"[0][0]");
				var fid = eval("item_arr"+bizid+"[0][7]");
				var passFlag = eval("item_arr"+bizid+"[0][3]");
				var urgency =  eval("item_arr"+bizid+"[0][4]");
				var deadlinesec =eval("item_arr"+bizid+"[0][5]");
				var initeddate = eval("item_arr"+bizid+"[0][6]");;
				var sType;
				var sStatus = eval("item_arr"+bizid+"[0][2]");
				if ('R' == sStatus || 'E' == sStatus || 'V' == sStatus || 'S' == sStatus || 'D' == sStatus || 'J' == sStatus)
				{
					sType = 'instance';
				}
				else  // A, T C  <-- Arhicve type
				{
					sType = 'archive';
				}	
				
				var sUrl = "";

				if ('instance' == sType)
				{
					sUrl = contextPath + "/instance/pidetailframe.jsp?type=instance&PROCESSID=" + pid + "&folderid=" + fid 
							  + "&passwordflag=" + passFlag + "&pageid=pi" + "&defid="  + "&defnm=" 
							  + "&urgentstate=" + urgency + "&deadlinesec=" + deadlinesec + "&initiateddate=" +initeddate 
							  + "&rtime=" + new Date().getMilliseconds();
				}
				else
				{
					sUrl = contextPath + "/archive/padetailframe.jsp?type=archive&PROCESSID=" + pid + "&folderid=" + fid 
								+ "&passwordflag=" + passFlag + "&pageid=pa" + "&defid=" + "&defnm=" 
								+ "&rtime=" + new Date().getMilliseconds();
				}
				
				sUrl += "&__bizcoveId=" + bizid;
                wndDetail = openDetailPopup(sUrl, "", "ProcDetail", 700, 600, true, true, true, true);

				if(!useAccessibility) {
					monitor_refreshWhenDetailWindowClosed(bizid);
				}
			}
			else if("T" == eval("item_arr"+bizid+"[0][3]"))
			{
				passwordValue = "false";
				actionType = "detail";

				eval("item_arr_singleStorage"+bizid+"[0] = item_arr"+bizid+"[0][0]");
				eval("item_arr_singleStorage"+bizid+"[1] = item_arr"+bizid+"[0][1]");
				eval("item_arr_singleStorage"+bizid+"[2] = item_arr"+bizid+"[0][2]");
				eval("item_arr_singleStorage"+bizid+"[3] = item_arr"+bizid+"[0][3]");
				eval("item_arr_singleStorage"+bizid+"[4] = item_arr"+bizid+"[0][4]");
				eval("item_arr_singleStorage"+bizid+"[5] = item_arr"+bizid+"[0][5]");
				eval("item_arr_singleStorage"+bizid+"[6] = item_arr"+bizid+"[0][6]");
				eval("item_arr_singleStorage"+bizid+"[7] = item_arr"+bizid+"[0][7]");
				eval("item_arr_singleStorage"+bizid+"[8] = item_arr"+bizid+"[0][8]");


				var sUrl = contextPath + "/common/passwordframe.jsp?callbackname=getCheckPasswordValueMonitor&rtime=" + new Date().getMilliseconds();
				wndPassword = ShowWindow(sUrl, "wndPassword", CHK_PASSWORD, 300, 140, "no");
				
			}
		}
	} 
}

var enableRefreshWhenDetailWindowClosed = false;
function monitor_refreshWhenDetailWindowClosed(bizid)
{
	try
	{
		//console.log("monitor_refreshWhenDetailWindowClosed");
		if(null == wndDetail || ('undefined' == typeof(wndDetail.closed)) || (wndDetail && 'undefined' != typeof(wndDetail.closed) && !wndDetail.closed))
		{
			window.setTimeout(function(){monitor_refreshWhenDetailWindowClosed(bizid)}, 1000);
		}
		else
		{
			if(enableRefreshWhenDetailWindowClosed)
			{
				reloadAllBizCoves('task=detail');
			}
			else
			{
				return;
			}
		}
	}catch(e)
	{
		//
	}
}

var wndUrgentState;
function monitor_OpenEscalate(bizid, isSS, reservedParam, useAccessibility)
{
	curBizID = bizid;
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}
	tmpUseAccessibility = useAccessibility;

	if (isSS)
	{
		var sType;
		var sStatus = eval("item_arr_singleStorage"+bizid+"[2]");
		if ('R' == sStatus || 'E' == sStatus || 'V' == sStatus || 'S' == sStatus || 'D' == sStatus || 'J' == sStatus)
		{
			sType = 'instance';
		}
		else  // A, T C  <-- Arhicve type
		{
			alert(MSG_CMM_NO_ESCALATE_IN_PROC_ARCHIVES);
			return;
		}	

		if("F" == eval("item_arr_singleStorage"+bizid+"[3]"))
		{
			var fid = eval("item_arr_singleStorage"+bizid+"[7]");
			var urgency = eval("item_arr_singleStorage"+bizid+"[4]");
			var deadlinesec = eval("item_arr_singleStorage"+bizid+"[5]");
			var initeddate = escapeUnicode(eval("item_arr_singleStorage"+bizid+"[6]"));
			var pid = eval("item_arr_singleStorage"+bizid+"[0]");

			var sUrl = contextPath + "/common/urgentstate.jsp?bizcove=" + bizid+"&folderid=" + fid + "&authority=2146959359" 
						   + "&defid=" + "&defnm=" + "&ap=" 
						   + "&urgentstate=" + urgency + "&deadlinesec=" 
						   + deadlinesec + "&initiateddate=" + initeddate + "&pid=" + pid 
						   + "&rtime=" + new Date().getMilliseconds();
						   
			sUrl += "&__bizcoveId=" + bizid;

			wndUrgentState = openPopup(sUrl, "", "wndUrgentState", 400, 250);
        }
		else if("T" == eval("item_arr_singleStorage"+bizid+"[3]"))
		{
			passwordValue = "false";
			actionType = "urgency";

			var sUrl = contextPath + "/common/passwordframe.jsp?callbackname=getCheckPasswordValueMonitor";
			wndPassword = ShowWindow(sUrl, "wndPassword", CHK_PASSWORD, 300, 140, "no");
		}
	}
	else
	{
		 if (eval("item_arr"+bizid+".length > 1"))
		{
			alert(MSG_CMM_ONLY_ONE_SELECT_ITEM);
		}
		else if (eval("item_arr"+bizid+".length == 0"))
		{
			alert(MSG_CMM_SELECT_ITEM);
		}
		else
		{
			var sType;
			var sStatus = eval("item_arr"+bizid+"[0][2]");
			if ('R' == sStatus || 'E' == sStatus || 'V' == sStatus || 'S' == sStatus || 'D' == sStatus || 'J' == sStatus)
			{
				sType = 'instance';
			}
			else  // A, T C  <-- Arhicve type
			{
				alert(MSG_CMM_NO_ESCALATE_IN_PROC_ARCHIVES);
				return;
			}	

			if("F" == eval("item_arr"+bizid+"[0][3]"))
			{
				var fid = eval("item_arr"+bizid+"[0][7]");
				var urgency = eval("item_arr"+bizid+"[0][4]");
				var deadlinesec = eval("item_arr"+bizid+"[0][5]");
				var initeddate = escapeUnicode(eval("item_arr"+bizid+"[0][6]"));
				var pid = eval("item_arr"+bizid+"[0][0]");

				var sUrl = contextPath + "/common/urgentstate.jsp?bizcove="+bizid+"&folderid=" + fid + "&authority=2146959359" 
							   + "&defid=" + "&defnm=" + "&ap=" 
							  + "&urgentstate=" + urgency + "&deadlinesec=" 
							 + deadlinesec + "&initiateddate=" + initeddate + "&pid=" + pid 
							 + "&rtime=" + new Date().getMilliseconds();
							 
				sUrl += "&__bizcoveId=" + bizid;

				wndUrgentState = openPopup(sUrl, "", "wndUrgentState", 400, 250);
            }
			else if("T" == eval("item_arr"+bizid+"[0][3]"))
			{
				passwordValue = "false";
				actionType = "urgency";
				eval("item_arr_singleStorage"+bizid+"[0] = item_arr"+bizid+"[0][0]");
				eval("item_arr_singleStorage"+bizid+"[1] = item_arr"+bizid+"[0][1]");
				eval("item_arr_singleStorage"+bizid+"[2] = item_arr"+bizid+"[0][2]");
				eval("item_arr_singleStorage"+bizid+"[3] = item_arr"+bizid+"[0][3]");
				eval("item_arr_singleStorage"+bizid+"[4] = item_arr"+bizid+"[0][4]");
				eval("item_arr_singleStorage"+bizid+"[5] = item_arr"+bizid+"[0][5]");
				eval("item_arr_singleStorage"+bizid+"[6] = item_arr"+bizid+"[0][6]");
				eval("item_arr_singleStorage"+bizid+"[7] = item_arr"+bizid+"[0][7]");
				eval("item_arr_singleStorage"+bizid+"[8] = item_arr"+bizid+"[0][8]");
				
				var sUrl = contextPath + "/common/passwordframe.jsp?callbackname=getCheckPasswordValueMonitor";
				wndPassword = ShowWindow(sUrl, "wndPassword", CHK_PASSWORD, 300, 140, "no");
			}
		}
	}
}

function monitor_OpenAlter(bizid, isSS) 
{
	alert(MSG_CMM_NO_ALTER);
}


var sFid = null;
var sMoveCopyFlag = null;
var moveProc = null;
function monitor_OpenMove(bizid, isSS, reservedParam, useAccessibility)
{
	curBizID = bizid;
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}
	tmpUseAccessibility = useAccessibility;

	if (isSS)
	{
			moveProc =eval("item_arr_singleStorage"+bizid+"[0]");

			if("F" == eval("item_arr_singleStorage"+bizid+"[3]"))
			{
				var sType;
				var sStatus = eval("item_arr_singleStorage"+bizid+"[2]");
				if ('R' == sStatus || 'E' == sStatus || 'V' == sStatus || 'S' == sStatus || 'D' == sStatus || 'J' == sStatus)
				{
					sType = 'instance';
				}
				else  // A, T C  <-- Arhicve type
				{
					sType = 'archive';
				}
				
				if ('instance' == sType)
				{
					var fid = eval("item_arr_singleStorage"+bizid+"[7]");
					sMoveCopyFlag = "PI";
					var sUrl = contextPath + "/portal/common/selectfolderbody.jsp?category=instance&fid=" + fid + "&menu=" + sMoveCopyFlag;
                    sUrl += "&__bizcoveId=" + bizid;
                    openPopup(sUrl, "", "SelFolder", 400, 500, false, true);
                }
				else
				{		
					var fid = eval("item_arr_singleStorage"+bizid+"[8]");
					sMoveCopyFlag = "PA";				

					var sUrl = contextPath + "/portal/common/selectfolderbody.jsp?category=archive&fid=" + fid + "&menu=" + sMoveCopyFlag;
					sUrl += "&__bizcoveId=" + bizid;
                    openPopup(sUrl, "", "SelFolder", 400, 500, false, true);
                }
				
			}
			else if("T" == eval("item_arr_singleStorage"+bizid+"[3]"))
			{
				passwordValue = "false";
				actionType = "move";
				var sUrl = contextPath + "/common/passwordframe.jsp?callbackname=getCheckPasswordValueMonitor";
				wndPassword = ShowWindow(sUrl, "wndPassword", CHK_PASSWORD, 300, 140, "no");
			}
	}
	else
	{		
		var arrLen = eval("item_arr"+bizid+".length");
		if (arrLen > 1)
		{
			alert(MSG_CMM_ONLY_ONE_SELECT_ITEM);
		}
		else if (arrLen == 0)
		{
			alert(MSG_CMM_SELECT_ITEM);
		}
		else
		{
			moveProc =eval("item_arr"+bizid+"[0][0]");

			if("F" == eval("item_arr"+bizid+"[0][3]"))
			{
				var sType;
				var sStatus = eval("item_arr"+bizid+"[0][2]");
				if ('R' == sStatus || 'E' == sStatus || 'V' == sStatus || 'S' == sStatus || 'D' == sStatus || 'J' == sStatus)
				{
					sType = 'instance';
				}
				else  // A, T C  <-- Arhicve type
				{
					sType = 'archive';
				}
				
				if ('instance' == sType)
				{
					var fid = eval("item_arr"+bizid+"[0][7]");
					sMoveCopyFlag = "PI";
					var sUrl = contextPath + "/portal/common/selectfolderbody.jsp?category=instance&fid=" + fid + "&menu=" + sMoveCopyFlag;
					sUrl += "&__bizcoveId=" + bizid;
                    openPopup(sUrl, "", "SelFolder", 400, 500, false, true);
                }
				else
				{		
					var fid = eval("item_arr"+bizid+"[0][8]");
					sMoveCopyFlag = "PA";				

					var sUrl = contextPath + "/portal/common/selectfolderbody.jsp?category=archive&fid=" + fid + "&menu=" + sMoveCopyFlag;
					sUrl += "&__bizcoveId=" + bizid;
                    openPopup(sUrl, "", "SelFolder", 400, 500, false, true);
                }
				
			}
			else if("T" == eval("item_arr"+bizid+"[0][3]"))
			{
				passwordValue = "false";
				actionType = "move";	
				eval("item_arr_singleStorage"+bizid+"[0] = item_arr"+bizid+"[0][0]");
				eval("item_arr_singleStorage"+bizid+"[1] = item_arr"+bizid+"[0][1]");
				eval("item_arr_singleStorage"+bizid+"[2] = item_arr"+bizid+"[0][2]");
				eval("item_arr_singleStorage"+bizid+"[3] = item_arr"+bizid+"[0][3]");
				eval("item_arr_singleStorage"+bizid+"[4] = item_arr"+bizid+"[0][4]");
				eval("item_arr_singleStorage"+bizid+"[5] = item_arr"+bizid+"[0][5]");
				eval("item_arr_singleStorage"+bizid+"[6] = item_arr"+bizid+"[0][6]");
				eval("item_arr_singleStorage"+bizid+"[7] = item_arr"+bizid+"[0][7]");
				eval("item_arr_singleStorage"+bizid+"[8] = item_arr"+bizid+"[0][8]");
		
				var sUrl = contextPath + "/common/passwordframe.jsp?callbackname=getCheckPasswordValueMonitor";
				wndPassword = ShowWindow(sUrl, "wndPassword", CHK_PASSWORD, 300, 140, "no");
			}
		}
	}
	
}

var sSelectFolderID = null;
function onFolderChange(fid)
{
	sSelectFolderID = fid;
	moveCopyDefinition(sMoveCopyFlag);
}

var delprocessIds = "";
function monitor_Delete(bizid, isSS, reservedParam, useAccessibility) //done
{
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}
	tmpUseAccessibility = useAccessibility;
    if("undefined" != typeof(reservedParam)) forceRemove = reservedParam;
    else forceRemove = "false";

    curBizID = bizid;
	var checkValue = "F";

	if (isSS)
	{		
		delprocessIds =eval("item_arr_singleStorage"+bizid+"[0]") ;
		var sStatus = eval("item_arr_singleStorage"+bizid+"[2]");
		if ('R' == sStatus || 'E' == sStatus || 'V' == sStatus || 'S' == sStatus || 'D' == sStatus || 'J' == sStatus)
			isArchive = 'false';
		else  // A, T C  <-- Arhicve type
			isArchive = 'true';

		if("F" == eval("item_arr_singleStorage"+bizid+"[3]"))
		{
			var ret;
			ret = confirm(MSG_CMM_CONFIRM_DELETE);
			if(ret == true)
			{	
				var serverUrl = contextPath + "/_scriptlibrary/procdelete.jsp";
				RSExecute("deleteProcCallBack", serverUrl, "deleteProcess", delprocessIds,  forceRemove, isArchive);
			}
			else
			{
				return;
			}

		}
		else 
		{
			passwordValue = "false";
			actionType = "delete";
			var sUrl = contextPath + "/common/passwordframe.jsp?callbackname=getCheckPasswordValueMonitor";
			wndPassword = ShowWindow(sUrl, "wndPassword", CHK_PASSWORD, 300, 140, "no");
		}
	}
	else
	{
		if (eval("item_arr"+bizid+".length == 0"))
		{
			alert(MSG_CMM_SELECT_ITEM);	
			return;
		}
		else
		{
			//checking password flag
			var j = 0;
			for (j = 0; j < eval("item_arr"+bizid+".length"); j++)
			{
				if("T" == eval("item_arr"+bizid+"[j][3]"))
				{
					checkValue = "T"; 
					break;
				}
			}

			delprocessIds = "";

			for (i = 0; i < eval("item_arr"+bizid+".length"); i++) {
				if ("" != delprocessIds) delprocessIds += ";";
				delprocessIds += eval("item_arr"+bizid+"[i][0]");
			}

			var sStatus = eval("item_arr"+bizid+"[0][2]");
			if ('R' == sStatus || 'E' == sStatus || 'V' == sStatus || 'S' == sStatus || 'D' == sStatus || 'J' == sStatus)
				isArchive = 'false';
			else  // A, T C  <-- Arhicve type
				isArchive = 'true';

			if("F" == checkValue)
			{
				var ret;
				ret = confirm(MSG_CMM_CONFIRM_DELETE);
				if(ret == true)
				{
					var i = 0;					
					var serverUrl = contextPath + "/_scriptlibrary/procdelete.jsp";

					RSExecute("deleteProcCallBack", serverUrl, "deleteProcess", delprocessIds, forceRemove, isArchive);
				}
				else
				{
					return;
				}
			}
			else if("T" == checkValue)
			{
				passwordValue = "false";
				actionType = "delete";
				var sUrl = contextPath + "/common/passwordframe.jsp?callbackname=getCheckPasswordValueMonitor";
				wndPassword = ShowWindow(sUrl, "wndPassword", CHK_PASSWORD, 300, 140, "no");
			}
		}
	}	
}

function reloadAllBizCoves(paramVal)
{
    var needAction = paramVal.indexOf("task=move") != -1 || paramVal.indexOf("task=close") != -1 || paramVal.indexOf("task=suspend") != -1
        || paramVal.indexOf("task=resume") != -1;

    if(!needAction && typeof(document.forms["bizcoveReferer"]) != "undefined")
	{
		var _form = document.forms["bizcoveReferer"];
		_form.submit();
		return;
	}

	bizid = curBizID;
	var newURL="";
	if(bizid.length == 10)
			newURL= contextPath +  getBizcoveServletPath(bizid) + "?bizcove="+ bizid+"&preview_bizcove=y";
	else
			newURL= contextPath +  getBizcoveServletPath(bizid) + "?bizcove="+ bizid;

	var i;
	var obj_arrBizCoves =  "'undefined' ==typeof(arrBizCoves)";
	var result_arrBizCoves = eval(obj_arrBizCoves);

	if(result_arrBizCoves == false)
	{
		for (i = 0; i != arrBizCoves.length; ++i)
		{
			if (arrBizCoves[i].type != "definition")
				newURL += ("&bizcove=" + arrBizCoves[i].id);
		}
	}

	if(bizid.length == 10)
		newURL += ("&refresh=y&osort="+ eval("monitor_curSortColName"+bizid) + "|"+ eval("monitor_curSortDataType"+bizid)
					+"|"+ eval("monitor_curSortDirection"+bizid)+ "&ap="+eval("curpage"+bizid));
	else
		newURL += ("&refresh=y&osort="+ eval("monitor_curSortColName"+bizid) + "|"+ eval("monitor_curSortDataType"+bizid)
					+"|"+ eval("monitor_curSortDirection"+bizid)+ "&ap="+eval("curpage"+bizid));
	
	newURL += "&__bizcoveId=" + bizid;
    newURL = adjustMaximizeURL(newURL, bizid);
    location.href = newURL + "&" + paramVal + "&__refreshAll=y";
}

function deleteProcCallBack (retVal) {
	if ("" == retVal) {
		
		reloadAllBizCoves("task=delete");

	} else if (retVal.match(/^\[4032\] /)) {
		var msg = MSG_EXCEPTION_4032 + "\n" + MSG_CMM_FORCE_CONFIRM_DELETE;
		if (confirm(msg)) {
			var serverUrl = contextPath + "/_scriptlibrary/procdelete.jsp";
			var processIds = retVal.substring(7);
			RSExecute("deleteProcCallBack", serverUrl, "deleteProcess", processIds, "false", isArchive);
		}
    }
    else if (retVal.match(/^\[4043\]/)) {
        var idx = retVal.indexOf("]:");
        var msg = retVal.substring(idx+2);
        if (confirm(msg)) {
			var serverUrl = contextPath + "/_scriptlibrary/procdelete.jsp";
			var processIds = retVal.substring(7, idx);
            RSExecute("deleteProcCallBack", serverUrl, "deleteProcess", processIds, "true", isArchive);
		}
    } else {
		alert(retVal);
	}
}

function moveCopyDefinition(movecopyflag) 
{
	var bizid = curBizID;
	var i = 0;
	var procID = moveProc;
	var folderType = movecopyflag;
	var paramVal = "procid="+procID+"&foldertype="+folderType+"&task=move&selectedfolderid="+sSelectFolderID
					+"&taskbizid="+ bizid;
	reloadAllBizCoves(paramVal);   
}

function monitor_OpenMonitor(bizid, isSS, reservedParam, useAccessibility)
{
	var iWidth = window.screen.availWidth-100;
	var iHeight = window.screen.availHeight-200;
	curBizID = bizid;
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}
	tmpUseAccessibility = useAccessibility;
	if (isSS)
	{
		var sPasswordFlag = eval("item_arr_singleStorage"+bizid+"[3]");

		if('F' == sPasswordFlag)
			{
				var sProcName = escapeUnicode(eval("item_arr_singleStorage"+bizid+"[1]"));
				var sProcID = eval("item_arr_singleStorage"+bizid+"[0]"); 
				var sType;
				var sStatus = eval("item_arr_singleStorage"+bizid+"[2]");
				if ('R' == sStatus || 'E' == sStatus || 'V' == sStatus || 'S' == sStatus || 'D' == sStatus || 'J' == sStatus)
				{
					sType = 'instance';
				}
				else  // A, T C  <-- Arhicve type
				{
					sType = 'archive';
				}
				//var sUrl = contextPath + "/common/audit.jsp?pid=" + sProcID + "&isbizcove=y"
				//								 + "&type=" + sType + "&pnm=" + sProcName + "&passwordflag=F&t=" + (new Date().getTime());				
				var sUrl = contextPath + "/common/audit.jsp?__ep__=";
				var pmsg = "?pid=" + sProcID + "&isbizcove=y&type=" + sType + "&pnm=" + sProcName + "&passwordflag=F";
				var key = CryptoJS.enc.Latin1.parse(getAesKeyString(HWSESSIONINFO_KEY));
				var encrypted = CryptoJS.AES.encrypt(pmsg, key, {mode: CryptoJS.mode.ECB, padding:CryptoJS.pad.Pkcs7});
				encrypted = encrypted.ciphertext.toString();
				sUrl += encrypted +"&t="+ (new Date).getTime();
				sUrl += "&__bizcoveId=" + bizid;
				if(isModalMonitorMode())
                {
                    iWidth = "100%";
                    iHeight = "100%";
                }
                wndMonitor = openMonitorPopup(sUrl, "", "Monitor", iWidth, iHeight, true, true, true, true);
            }
			else if("T" == eval("item_arr_singleStorage"+bizid+"[3]"))
			{
				passwordValue = "false";
				actionType = "monitor";
				var sUrl = contextPath + "/common/passwordframe.jsp?callbackname=getCheckPasswordValueMonitor";
				wndPassword = ShowWindow(sUrl, "wndPassword", CHK_PASSWORD, 300, 140, "no");
			}
	}
	else
	{
		var arrLen = eval("item_arr"+bizid+".length");

		if (arrLen > 1)
		{
			alert(MSG_CMM_ONLY_ONE_SELECT_ITEM);
		}
		else if (arrLen == 0)
		{
			alert(MSG_CMM_SELECT_ITEM);
		}
		else
		{			
			var sPasswdFlag = eval("item_arr"+bizid+"[0][3]");
			var sProcName = escapeUnicode(eval("item_arr"+bizid+"[0][1]"));
			var sStatus = eval("item_arr"+bizid+"[0][2]");
			var sProcID = eval("item_arr"+bizid+"[0][0]");
			var sType;
			if ('R' == sStatus || 'E' == sStatus || 'V' == sStatus || 'S' == sStatus || 'D' == sStatus || 'J' == sStatus)
			{
				sType = 'instance';
			}
			else  // A, T C  <-- Arhicve type
			{
				sType = 'archive';
			}
			
			if("F" == sPasswdFlag)
			{
				//var sUrl = contextPath + "/common/audit.jsp?pid=" + sProcID + "&isbizcove=y&type=" + sType+ "&pnm=" + sProcName + "&passwordflag=F&t=" + (new Date().getTime());				
				var sUrl = contextPath + "/common/audit.jsp?__ep__=";
				var pmsg = "?pid=" + sProcID + "&isbizcove=y&type=" + sType+ "&pnm=" + sProcName + "&passwordflag=F";
				var key = CryptoJS.enc.Latin1.parse(getAesKeyString(HWSESSIONINFO_KEY));
				var encrypted = CryptoJS.AES.encrypt(pmsg, key, {mode: CryptoJS.mode.ECB, padding:CryptoJS.pad.Pkcs7});
				encrypted = encrypted.ciphertext.toString();
				sUrl += encrypted +"&t="+ (new Date).getTime();
				sUrl += "&__bizcoveId=" + bizid;
                if(isModalMonitorMode())
                {
                    iWidth = "100%";
                    iHeight = "100%";
                }
                wndMonitor = openMonitorPopup(sUrl, "", "Monitor", iWidth, iHeight, true, true, true, true);
            }
			else if("T" == sPasswdFlag)
			{
				passwordValue = "false";
				actionType = "monitor";

				eval("item_arr_singleStorage"+bizid+"[0] = item_arr"+bizid+"[0][0]");
				eval("item_arr_singleStorage"+bizid+"[1] = item_arr"+bizid+"[0][1]");
				eval("item_arr_singleStorage"+bizid+"[2] = item_arr"+bizid+"[0][2]");
				eval("item_arr_singleStorage"+bizid+"[3] = item_arr"+bizid+"[0][3]");
				eval("item_arr_singleStorage"+bizid+"[4] = item_arr"+bizid+"[0][4]");
				eval("item_arr_singleStorage"+bizid+"[5] = item_arr"+bizid+"[0][5]");
				eval("item_arr_singleStorage"+bizid+"[6] = item_arr"+bizid+"[0][6]");
				eval("item_arr_singleStorage"+bizid+"[7] = item_arr"+bizid+"[0][7]");
				eval("item_arr_singleStorage"+bizid+"[8] = item_arr"+bizid+"[0][8]");

				var sUrl = contextPath + "/common/passwordframe.jsp?callbackname=getCheckPasswordValueMonitor";
			   wndPassword = ShowWindow(sUrl, "wndPassword", CHK_PASSWORD, 300, 140, "no");
			}
		}
	}  
}

function monitor_sel_item(process, processName, state, passwordflag, urgency, deadlinesec, initiateddate, src, bizid, instfolderid, archfolderid)
{
	var i, j, k, inx;

	if (src.checked)
	{
		inx = eval("item_arr"+bizid+".length");
		eval("item_arr"+bizid+"[inx] = new Array(10)");
		eval("item_arr"+bizid+"[inx][0] = process");
		eval("item_arr"+bizid+"[inx][1] = processName");
		eval("item_arr"+bizid+"[inx][2] = state");
		eval("item_arr"+bizid+"[inx][3] = passwordflag");
		eval("item_arr"+bizid+"[inx][4] = urgency");
		eval("item_arr"+bizid+"[inx][5] = deadlinesec");
		eval("item_arr"+bizid+"[inx][6] = initiateddate");
		eval("item_arr"+bizid+"[inx][7] = instfolderid");
		eval("item_arr"+bizid+"[inx][8] = archfolderid"); 
	}
	else
	{
		var arrLen = eval("item_arr"+bizid+".length");
		for (i=0;i< arrLen ;i++)
		{
			if (eval("item_arr"+bizid+"[i][0]== process"))
			{
				for (j=i;j<arrLen-1;j++)
				{
					k = j + 1;
					eval("item_arr"+bizid+"[j][0] = item_arr"+bizid+"[k][0]");
					eval("item_arr"+bizid+"[j][1] = item_arr"+bizid+"[k][1]");
					eval("item_arr"+bizid+"[j][2] = item_arr"+bizid+"[k][2]");
					eval("item_arr"+bizid+"[j][3] = item_arr"+bizid+"[k][3]");
					eval("item_arr"+bizid+"[j][4] = item_arr"+bizid+"[k][4]");
					eval("item_arr"+bizid+"[j][5] = item_arr"+bizid+"[k][5]");
					eval("item_arr"+bizid+"[j][6] = item_arr"+bizid+"[k][6]");
					eval("item_arr"+bizid+"[j][7] = item_arr"+bizid+"[k][7]");
					eval("item_arr"+bizid+"[j][8] = item_arr"+bizid+"[k][8]");
				}

				eval("item_arr"+bizid+".length = item_arr"+bizid+".length-1");
			
				break;
			}
		}
	}
}

var wndVaris;
function monitor_OpenVariables(bizid, isSS, reservedParam, useAccessibility) //done
{
	curBizID = bizid;
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}
	tmpUseAccessibility = useAccessibility;

	if (isSS)
	{
		var passwdFlag = eval("item_arr_singleStorage"+bizid+"[3]");
		var sStatus = eval("item_arr_singleStorage"+bizid+"[2]");
		var sType;

		if ('R' == sStatus || 'E' == sStatus || 'V' == sStatus || 'S' == sStatus || 'D' == sStatus || 'J' == sStatus)
		{
			sType = 'instance';
		}
		else  // A, T C  <-- Arhicve type
		{
			sType = 'archive';
		}

		var iWidth;

		if("F" == passwdFlag)
		{
			if ('instance' == sType)
			{
				//var sUrl = contextPath + "/common/processvariable.jsp?PROCESSID=" + eval("item_arr_singleStorage"+bizid+"[0]")
				//							 + "&openpage=INSTANCE&now=" + (new Date).getTime();
				var sUrl = contextPath + "/common/processvariable.jsp?__ep__=";
				var pmsg = "?PROCESSID=" + eval("item_arr_singleStorage"+bizid+"[0]") + "&openpage=INSTANCE";
				var key = CryptoJS.enc.Latin1.parse(getAesKeyString(HWSESSIONINFO_KEY));
				var encrypted = CryptoJS.AES.encrypt(pmsg, key, {mode: CryptoJS.mode.ECB, padding:CryptoJS.pad.Pkcs7});
				encrypted = encrypted.ciphertext.toString();
				sUrl += encrypted +"&now="+ (new Date).getTime();
				iWidth = 740;
			}
			else
			{
				//var sUrl = contextPath + "/common/processvariable.jsp?PROCESSID=" + eval("item_arr_singleStorage"+bizid+"[0]") + "&ISREADONLY=Y" + "&openpage=ARCHIVE";
				var sUrl = contextPath + "/common/processvariable.jsp?__ep__=";
				var pmsg = "?PROCESSID=" + eval("item_arr_singleStorage"+bizid+"[0]") + "&ISREADONLY=Y" + "&openpage=ARCHIVE";
				var key = CryptoJS.enc.Latin1.parse(getAesKeyString(HWSESSIONINFO_KEY));
				var encrypted = CryptoJS.AES.encrypt(pmsg, key, {mode: CryptoJS.mode.ECB, padding:CryptoJS.pad.Pkcs7});
				encrypted = encrypted.ciphertext.toString();
				sUrl += encrypted +"&now="+ (new Date).getTime();
				iWidth = 650;
				
			}
			
			sUrl += "&__bizcoveId=" + bizid;
			
			var iHeight = window.screen.availHeight - 200;
			wndVaris = openPopup(sUrl, "", "ProcessVariable", iWidth, iHeight, true, true);

		}
		else if("T" == eval("item_arr_singleStorage"+bizid+"[3]"))
		{
			passwordValue = "false";
			actionType = "variables";			
			var sUrl = contextPath + "/common/passwordframe.jsp?callbackname=getCheckPasswordValueMonitor";
			wndPassword = ShowWindow(sUrl, "wndPassword", CHK_PASSWORD, 300, 140, "no");
		}
		
	}
	else
	{
		var arrLen = eval("item_arr" + bizid+ ".length");

		if (arrLen > 1)
		{
			alert(MSG_CMM_ONLY_ONE_SELECT_ITEM);
		}
		else if (arrLen == 0)
		{
			alert(MSG_CMM_SELECT_ITEM);
		}
		else
		{
			var passwdFlag = eval("item_arr"+bizid+"[0][3]");
			var sStatus = eval("item_arr"+bizid+"[0][2]");
			var sType;

			if ('R' == sStatus || 'E' == sStatus || 'V' == sStatus || 'S' == sStatus || 'D' == sStatus || 'J' == sStatus)
			{
				sType = 'instance';
			}
			else  // A, T C  <-- Arhicve type
			{
				sType = 'archive';
			}

			var iWidth;
			if("F" == passwdFlag)
			{
				if ('instance' == sType)
				{
					// bug22779,cs17740: authority check over instance folder in PV window.
					var sUrl = contextPath + "/common/processvariable.jsp?__ep__=";
					var pmsg = "?PROCESSID=" + eval("item_arr"+bizid+"[0][0]")+ "&fid=" + eval("item_arr"+bizid+"[0][7]") + "&openpage=INSTANCE";
					var key = CryptoJS.enc.Latin1.parse(getAesKeyString(HWSESSIONINFO_KEY));
					var encrypted = CryptoJS.AES.encrypt(pmsg, key, {mode: CryptoJS.mode.ECB, padding:CryptoJS.pad.Pkcs7});
					encrypted = encrypted.ciphertext.toString();
					sUrl += encrypted +"&now="+ (new Date).getTime();
					iWidth = 740;
				}
				else
				{
					//var sUrl = contextPath + "/common/processvariable.jsp?PROCESSID=" + eval("item_arr"+bizid+"[0][0]") + "&ISREADONLY=Y" + "&openpage=ARCHIVE";
					var sUrl = contextPath + "/common/processvariable.jsp?__ep__=";
					var pmsg = "?PROCESSID=" + eval("item_arr"+bizid+"[0][0]") + "&ISREADONLY=Y" + "&openpage=ARCHIVE";
					var key = CryptoJS.enc.Latin1.parse(getAesKeyString(HWSESSIONINFO_KEY));
					var encrypted = CryptoJS.AES.encrypt(pmsg, key, {mode: CryptoJS.mode.ECB, padding:CryptoJS.pad.Pkcs7});
					encrypted = encrypted.ciphertext.toString();
					sUrl += encrypted +"&now="+ (new Date).getTime();
					iWidth = 650;
					
				}
				
				sUrl += "&__bizcoveId=" + bizid;
				
				var iHeight = window.screen.availHeight - 200;
				wndVaris = openPopup(sUrl, "", "ProcessVariable", iWidth, iHeight, true, true);

			}
			else if("T" == eval("item_arr"+bizid+"[0][3]"))
			{
				passwordValue = "false";
				actionType = "variables";

				eval("item_arr_singleStorage"+bizid+"[0] = item_arr"+bizid+"[0][0]");
				eval("item_arr_singleStorage"+bizid+"[1] = item_arr"+bizid+"[0][1]");
				eval("item_arr_singleStorage"+bizid+"[2] = item_arr"+bizid+"[0][2]");
				eval("item_arr_singleStorage"+bizid+"[3] = item_arr"+bizid+"[0][3]");
				eval("item_arr_singleStorage"+bizid+"[4] = item_arr"+bizid+"[0][4]");
				eval("item_arr_singleStorage"+bizid+"[5] = item_arr"+bizid+"[0][5]");
				eval("item_arr_singleStorage"+bizid+"[6] = item_arr"+bizid+"[0][6]");
				eval("item_arr_singleStorage"+bizid+"[7] = item_arr"+bizid+"[0][7]");
				eval("item_arr_singleStorage"+bizid+"[8] = item_arr"+bizid+"[0][8]");


				var sUrl = contextPath + "/common/passwordframe.jsp?callbackname=getCheckPasswordValueMonitor";
				wndPassword = ShowWindow(sUrl, "wndPassword", CHK_PASSWORD, 300, 140, "no");
			}
		}
	}
}

var curIsSingleStorage = false;
function monitor_OpenStatus(bizid, isSS, reservedParam, useAccessibility)// need to work..
{
	curBizID = bizid;
	curIsSingleStorage = isSS;
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}
	tmpUseAccessibility = useAccessibility;

	if (isSS)
	{
        var passwdFlag = eval("item_arr_singleStorage"+bizid+"[3]");
        var sStatus = eval("item_arr_singleStorage"+bizid+"[2]");
		var sType;

		if ('R' == sStatus || 'E' == sStatus || 'V' == sStatus || 'S' == sStatus || 'D' == sStatus || 'J' == sStatus)
		{
			sType = 'instance';
		}
		else  // A, T C  <-- Arhicve type
		{
			alert(MSG_CMM_NO_STATUS_IN_PROC_ARCHIVES);
			return;
		}

        if("F" == passwdFlag)
		{
            var modifyGranted = true;
            var deleteGranted = true;
            var instfid = eval("item_arr_singleStorage"+bizid+"[7]");
            var authority = "2146959359";
            var defid = "";
            var defnm = "";
            var ap = eval("curpage"+bizid);

            var sUrl = contextPath + "/instance/status.jsp?modifygranted=" + modifyGranted + "&deletegranted="
                                   + deleteGranted+"&fid="+ instfid + "&authority=" + authority
                                   + "&defid=" + defid + "&defnm=" + defnm + "&ap=" +ap;

            sUrl += "&__bizcoveId=" + bizid;

            openPopup(sUrl, "", "SelStatus", 330, 150);
        }
        else
        {
            passwordValue = "false";
			actionType = "status";
			var sUrl = contextPath + "/common/passwordframe.jsp?callbackname=getCheckPasswordValueMonitor";
			wndPassword = ShowWindow(sUrl, "wndPassword", CHK_PASSWORD, 300, 140, "no");
        }
    }
	else
	{
		var arrLen = eval("item_arr"+bizid+".length");
		if (arrLen > 1)
		{
			alert(MSG_CMM_ONLY_ONE_SELECT_ITEM);
		}
		else if (arrLen == 0)
		{
			alert(MSG_CMM_SELECT_ITEM);
		}
		else
		{
            var passwdFlag = eval("item_arr"+bizid+"[0][3]");
            var sStatus = eval("item_arr"+bizid+"[0][2]");
			var sType;

			if ('R' == sStatus || 'E' == sStatus || 'V' == sStatus || 'S' == sStatus || 'D' == sStatus || 'J' == sStatus)
			{
				sType = 'instance';
			}
			else  // A, T C  <-- Arhicve type
			{
				alert(MSG_CMM_NO_STATUS_IN_PROC_ARCHIVES);
				return;
			}

            if("F" == passwdFlag)
            {
                var modifyGranted = true;
                var deleteGranted = true;
                var instfid = eval("item_arr"+bizid+"[0][7]");
                var authority = "2146959359";
                var defid = "";
                var defnm = "";
                var ap = eval("curpage"+bizid);

                var sUrl = contextPath + "/instance/status.jsp?modifygranted=" + modifyGranted + "&deletegranted="
                                       + deleteGranted+"&fid="+ instfid + "&authority=" + authority
                                       + "&defid=" + defid + "&defnm=" + defnm + "&ap=" +ap;

                sUrl += "&__bizcoveId=" + bizid;
                openPopup(sUrl, "", "SelStatus", 330, 150);
            }
            else
            {
                passwordValue = "false";
				actionType = "status";

				eval("item_arr_singleStorage"+bizid+"[0] = item_arr"+bizid+"[0][0]");
				eval("item_arr_singleStorage"+bizid+"[1] = item_arr"+bizid+"[0][1]");
				eval("item_arr_singleStorage"+bizid+"[2] = item_arr"+bizid+"[0][2]");
				eval("item_arr_singleStorage"+bizid+"[3] = item_arr"+bizid+"[0][3]");
				eval("item_arr_singleStorage"+bizid+"[4] = item_arr"+bizid+"[0][4]");
				eval("item_arr_singleStorage"+bizid+"[5] = item_arr"+bizid+"[0][5]");
				eval("item_arr_singleStorage"+bizid+"[6] = item_arr"+bizid+"[0][6]");
				eval("item_arr_singleStorage"+bizid+"[7] = item_arr"+bizid+"[0][7]");
				eval("item_arr_singleStorage"+bizid+"[8] = item_arr"+bizid+"[0][8]");


				var sUrl = contextPath + "/common/passwordframe.jsp?callbackname=getCheckPasswordValueMonitor";
				wndPassword = ShowWindow(sUrl, "wndPassword", CHK_PASSWORD, 300, 140, "no");
            }
        }
	}
}


function resumeProcess(fid, authority, defid, defnm, ap)
{
	bizid = curBizID;
	if (curIsSingleStorage)
	{
        if ("S" == eval("item_arr_singleStorage"+bizid+"[2]"))
        {
            var paramVal = "task=resume&procid="+ eval("item_arr_singleStorage"+bizid+"[0]")
                                + "&folderid=" + eval("item_arr_singleStorage"+bizid+"[7]")
                                +"&taskbizid="+ bizid;

            reloadAllBizCoves(paramVal);
        }
        else
        {
            alert(MSG_CMM_SELECT_SUSPEND_PROCESS);
        }
	}
	else
	{
        if ("S" == eval("item_arr"+bizid+"[0][2]"))
        {
            var paramVal = "task=resume&procid="+ eval("item_arr"+bizid+"[0][0]")
                                + "&folderid=" + eval("item_arr"+bizid+"[0][7]")
                                +"&taskbizid="+ bizid;

            reloadAllBizCoves(paramVal);
        }
        else
        {
            alert(MSG_CMM_SELECT_SUSPEND_PROCESS);
        }
	}
}

function suspendProcess(fid, authority, defid, defnm, ap)
{
	bizid = curBizID;

	if (curIsSingleStorage)
	{
        if ("R" == eval("item_arr_singleStorage"+bizid+"[2]") || "V" == eval("item_arr_singleStorage"+bizid+"[2]"))
        {
            var paramVal = "task=suspend&procid="+ eval("item_arr_singleStorage"+bizid+"[0]")
                                + "&folderid=" + eval("item_arr_singleStorage"+bizid+"[7]")
                                +"&taskbizid="+ bizid;

            reloadAllBizCoves(paramVal);
        }
        else
        {
            alert(MSG_CMM_NOT_SUSPEND);
        }
	}
	else
	{
        if ("R" == eval("item_arr"+bizid+"[0][2]") || "V" == eval("item_arr"+bizid+"[0][2]"))
        {
            var paramVal = "task=suspend&procid="+ eval("item_arr"+bizid+"[0][0]")
                                + "&folderid=" + eval("item_arr"+bizid+"[0][7]")
                                +"&taskbizid="+ bizid;

            reloadAllBizCoves(paramVal);
        }
        else
        {
            alert(MSG_CMM_NOT_SUSPEND);
        }
	}
}

function closeProcess(fid, authority, defid, defnm, ap)
{
	bizid = curBizID;

	if (curIsSingleStorage)
	{
        if ("A" == eval("item_arr_singleStorage"+bizid+"[2]") || "T" == eval("item_arr_singleStorage"+bizid+"[2]")
                                                                                      || "C" == eval("item_arr_singleStorage"+bizid+"[2]"))
        {
            alert(MSG_CMM_NOT_CLOSE);
        }
        else
        {
            var ret;
            ret = confirm(MSG_CMM_CONFIRM_CLOSE);
            if(ret == true)
            {
                var paramVal = "task=close&procid="+ eval("item_arr_singleStorage"+bizid+"[0]")
                                + "&folderid=" + eval("item_arr_singleStorage"+bizid+"[7]")
                                +"&taskbizid="+ bizid;

                reloadAllBizCoves(paramVal);
            }
            else
            {
                return;
            }
        }
	}
	else
	{
        if ("A" == eval("item_arr"+bizid+"[0][2]") || "T" == eval("item_arr"+bizid+"[0][2]") || "C" == eval("item_arr"+bizid+"[0][2]"))
        {
            alert(MSG_CMM_NOT_CLOSE);
        }
        else
        {
            var ret;
            ret = confirm(MSG_CMM_CONFIRM_CLOSE);
            if(ret == true)
            {
                var paramVal = "task=close&procid="+ eval("item_arr"+bizid+"[0][0]")
                                + "&folderid=" + eval("item_arr"+bizid+"[0][7]")
                                +"&taskbizid="+ bizid;

                reloadAllBizCoves(paramVal);
            }
            else
            {
                return;
            }
        }
	}
	   
}

function monitor_SingleStorage(process, processName, state, passwordflag, urgency, deadlinesec, initiateddate, src, bizid, instfolderid, archfolderid)
{
	eval("item_arr_singleStorage"+bizid+"[0] = process");
	eval("item_arr_singleStorage"+bizid+"[1] = processName");
	eval("item_arr_singleStorage"+bizid+"[2] = state");
	eval("item_arr_singleStorage"+bizid+"[3] = passwordflag");
	eval("item_arr_singleStorage"+bizid+"[4] = urgency");
	eval("item_arr_singleStorage"+bizid+"[5] = deadlinesec");
	eval("item_arr_singleStorage"+bizid+"[6] = initiateddate");
	eval("item_arr_singleStorage"+bizid+"[7] = instfolderid");	
	eval("item_arr_singleStorage"+bizid+"[8] = archfolderid");
}

function getCheckPasswordValueMonitor(value)
{
	passwordValue = value;
	moveActionMonitor();
}

function moveActionMonitor() 
{
	var bizid = curBizID;
	var useAccessibility = tmpUseAccessibility;
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}

	if("true" == passwordValue)
	{
		if("detail" == actionType)
		{
			var pid = eval("item_arr_singleStorage"+bizid+"[0]");
			var fid = eval("item_arr_singleStorage"+bizid+"[7]");
			var passFlag = eval("item_arr_singleStorage"+bizid+"[3]");
			var urgency =  eval("item_arr_singleStorage"+bizid+"[4]");
			var deadlinesec =eval("item_arr_singleStorage"+bizid+"[5]");
			var initeddate = eval("item_arr_singleStorage"+bizid+"[6]");
			var sType;
			var sStatus = eval("item_arr_singleStorage"+bizid+"[2]");
			if ('R' == sStatus || 'E' == sStatus || 'V' == sStatus || 'S' == sStatus || 'D' == sStatus || 'J' == sStatus)
			{
				sType = 'instance';
			}
			else  // A, T C  <-- Arhicve type
			{
				sType = 'archive';
			}	
			
			var sUrl = "";

			if ('instance' == sType)
			{
				sUrl = contextPath + "/instance/pidetailframe.jsp?type=instance&PROCESSID=" + pid + "&folderid=" + fid 
						  + "&passwordflag=" + passFlag + "&pageid=pi" + "&defid="  + "&defnm=" 
						  + "&urgentstate=" + urgency + "&deadlinesec=" + deadlinesec + "&initiateddate=" +initeddate 
						  + "&rtime=" + new Date().getMilliseconds();
			}
			else
			{
				sUrl = contextPath + "/archive/padetailframe.jsp?type=archive&PROCESSID=" + pid + "&folderid=" + fid 
							+ "&passwordflag=" + passFlag + "&pageid=pa" + "&defid=" + "&defnm=" 
							+ "&rtime=" + new Date().getMilliseconds();
			}
			
			sUrl += "&__bizcoveId=" + bizid;

		    wndDetail = openDetailPopup(sUrl, "", "ProcDetail", 800, 600, true, true, true, true);
			if(!useAccessibility) {
				monitor_refreshWhenDetailWindowClosed(bizid);
			}
		}
		else if("monitor" == actionType)
		{
			var sProcName = escapeUnicode(eval("item_arr_singleStorage"+bizid+"[1]"));
			var sProcID = eval("item_arr_singleStorage"+bizid+"[0]"); 
			var sType;
			var sStatus = eval("item_arr_singleStorage"+bizid+"[2]");
			if ('R' == sStatus || 'E' == sStatus || 'V' == sStatus || 'S' == sStatus || 'D' == sStatus || 'J' == sStatus)
			{
				sType = 'instance';
			}
			else  // A, T C  <-- Arhicve type
			{
				sType = 'archive';
			}
			//var sUrl = contextPath + "/common/audit.jsp?pid=" + sProcID  + "&isbizcove=y"
			//								 + "&type=" + sType + "&pnm=" + sProcName + "&passwordflag=F&t=" + (new Date().getTime());				

			var sUrl = contextPath + "/common/audit.jsp?__ep__=";
			var pmsg = "?pid=" + sProcID  + "&isbizcove=y&type=" + sType + "&pnm=" + sProcName + "&passwordflag=F";
			var key = CryptoJS.enc.Latin1.parse(getAesKeyString(HWSESSIONINFO_KEY));
			var encrypted = CryptoJS.AES.encrypt(pmsg, key, {mode: CryptoJS.mode.ECB, padding:CryptoJS.pad.Pkcs7});
			encrypted = encrypted.ciphertext.toString();
			sUrl += encrypted +"&t="+ (new Date).getTime();
			sUrl += "&__bizcoveId=" + bizid;

            var iWidth = window.screen.availWidth-100;
	        var iHeight = window.screen.availHeight-200;
            if(isModalMonitorMode())
            {
                iWidth = "100%";
                iHeight = "100%";
            }

            wndMonitor = openMonitorPopup(sUrl, "", "Monitor", iWidth, iHeight, true, true, true, true);
        }
		else if("multiviewer" == actionType)	// Promise#86862
		{
			var sProcName = escapeUnicode(eval("item_arr_singleStorage"+bizid+"[1]"));
			var sProcID = eval("item_arr_singleStorage"+bizid+"[0]"); 
			var sType;
			var sStatus = eval("item_arr_singleStorage"+bizid+"[2]");
			if ('R' == sStatus || 'E' == sStatus || 'V' == sStatus || 'S' == sStatus || 'D' == sStatus || 'J' == sStatus)
			{
				sType = 'cpinstance';
			}
			else  // A, T C  <-- Arhicve type
			{
				sType = 'cparchive';
			}
			//var sUrl = contextPath + "/common/audit.jsp?pid=" + sProcID  + "&isbizcove=y"
			//								 + "&type=" + sType + "&pnm=" + sProcName + "&passwordflag=F&t=" + (new Date().getTime());				

			var sUrl = contextPath + "/common/audit.jsp?__ep__=";
			var pmsg = "?pid=" + sProcID  + "&isbizcove=y&type=" + sType + "&pnm=" + sProcName + "&passwordflag=F";
			var key = CryptoJS.enc.Latin1.parse(getAesKeyString(HWSESSIONINFO_KEY));
			var encrypted = CryptoJS.AES.encrypt(pmsg, key, {mode: CryptoJS.mode.ECB, padding:CryptoJS.pad.Pkcs7});
			encrypted = encrypted.ciphertext.toString();
			sUrl += encrypted +"&t="+ (new Date).getTime();
			sUrl += "&__bizcoveId=" + bizid;

            var iWidth = window.screen.availWidth-100;
	        var iHeight = window.screen.availHeight-200;
            if(isModalMonitorMode())
            {
                iWidth = "100%";
                iHeight = "100%";
            }

            wndMonitor = openMonitorPopup(sUrl, "", "Monitor", iWidth, iHeight, true, true, true, true);
        }
		else if("mergeprocess" == actionType)
		{
			var arrLen = eval("item_arr"+bizid+".length");

			if (arrLen == 0)
			{
				alert(MSG_CMM_SELECT_ITEM);
				return;
			}
			else if (arrLen != 2)
			{
				alert(MSG_CMM_ONLY_TWO_SELECT_ITEM);
				return;
			}
			var procid = eval("item_arr"+bizid+"[0][0]");
			var linkedprocid = eval("item_arr"+bizid+"[1][0]");
			var sStatus1 = eval("item_arr"+bizid+"[0][2]");
			var sStatus2 = eval("item_arr"+bizid+"[1][2]");
			if ('R' == sStatus1 || 'E' == sStatus1 || 'V' == sStatus1 || 'S' == sStatus1 || 'D' == sStatus1 || 'J' == sStatus1)
			{
				// okay
			}
			else 
			{
				alert(MSG_CMM_MERGE_PROCESS_IS_COMPLETED);
				return;
			}
			if ('R' == sStatus2 || 'E' == sStatus2 || 'V' == sStatus2 || 'S' == sStatus2 || 'D' == sStatus2 || 'J' == sStatus2)
			{
				// okay
			}
			else
			{
				alert(MSG_CMM_MERGE_PROCESS_IS_COMPLETED);
				return;
			}

		    var sUrl = contextPath + "/instance/merge.jsp?pid=" + procid + "&lpid=" + linkedprocid;
		    sUrl += "&__bizcoveId=" + bizid;
            var iWidth = window.screen.availWidth-100;
	        var iHeight = window.screen.availHeight-200;
            if(isModalMonitorMode())
            {
                iWidth = "100%";
                iHeight = "100%";
            }

            wndMonitor = openMonitorPopup(sUrl, "", "Monitor", iWidth, iHeight, true, true, true, true);
        }
        else if("splitprocess" == actionType)
        {
            var arrLen = eval("item_arr"+bizid+".length");

            if (arrLen == 0)
            {
                alert(MSG_CMM_SELECT_ITEM);
                return;
            }
            else if (arrLen > 1)
            {
                alert(MSG_CMM_ONLY_ONE_SELECT_ITEM);
                return;
            }
            var procid = eval("item_arr"+bizid+"[0][0]");
            var sStatus1 = eval("item_arr"+bizid+"[0][2]");
            var sType = "";
            if ('R' == sStatus1 || 'E' == sStatus1 || 'V' == sStatus1 || 'S' == sStatus1 || 'D' == sStatus1 || 'J' == sStatus1)
            {
                sType = "instance";
            }
            else
            {
                sType = "archive";
                alert(MSG_CMM_SPLIT_PROCESS_IS_COMPLETED);
                return;
            }

            var sUrl = contextPath + "/instance/split.jsp?pid=" + procid +"&type=" + sType;
            sUrl += "&__bizcoveId=" + bizid;
            var iWidth = window.screen.availWidth-100;
            var iHeight = window.screen.availHeight-200;
            if(isModalMonitorMode())
            {
                iWidth = "100%";
                iHeight = "100%";
            }

            wndMonitor = openMonitorPopup(sUrl, "", "Monitor", iWidth, iHeight, true, true, true, true);
        }
		else if("resume" == actionType)
		{
			if ("S" == eval("item_arr_singleStorage"+bizid+"[2]"))
			{
			   var paramVal = "task=resume&procid="+ eval("item_arr_singleStorage"+bizid+"[0]") 
									+ "&folderid=" + eval("item_arr_singleStorage"+bizid+"[7]")
									+"&taskbizid="+ bizid;
				
				reloadAllBizCoves(paramVal);
			}
			else
			{
				alert(MSG_CMM_SELECT_SUSPEND_PROCESS);
			}
		}
		else if("suspend" == actionType)
		{

			if ("R" == eval("item_arr_singleStorage"+bizid+"[2]") || "V" == eval("item_arr_singleStorage"+bizid+"[2]"))
			{
				var paramVal = "task=suspend&procid="+ eval("item_arr_singleStorage"+bizid+"[0]") 
									+ "&folderid=" + eval("item_arr_singleStorage"+bizid+"[7]")
									+"&taskbizid="+ bizid;
				
				reloadAllBizCoves(paramVal);
			}
			else
			{
				alert(MSG_CMM_NOT_SUSPEND);
			}
		}
		else if("close" == actionType)
		{
			if ("A" == eval("item_arr_singleStorage"+bizid+"[2]") || "T" == eval("item_arr_singleStorage"+bizid+"[2]") 
																						  || "C" == eval("item_arr_singleStorage"+bizid+"[2]"))
			{
				alert(MSG_CMM_NOT_CLOSE);
			}
			else
			{
				var ret;
				ret = confirm(MSG_CMM_CONFIRM_CLOSE);
				if(ret == true)
				{
					var paramVal = "task=close&procid="+ eval("item_arr_singleStorage"+bizid+"[0]") 
									+ "&folderid=" + eval("item_arr_singleStorage"+bizid+"[7]")
									+"&taskbizid="+ bizid;
				
					reloadAllBizCoves(paramVal);
				}
				else
				{
					return;
				}
			}
		}
		else if("delete" == actionType)
		{
			var ret;
			ret = confirm(MSG_CMM_CONFIRM_DELETE);
			if(ret == true)
			{
				var serverUrl = contextPath + "/_scriptlibrary/procdelete.jsp";
				RSExecute("deleteProcCallBack", serverUrl, "deleteProcess", delprocessIds, forceRemove, isArchive);
			}
			else
			{
				return;
			}
		}
		else if("variables" == actionType) //done
		{

			var sStatus = eval("item_arr_singleStorage"+bizid+"[2]");
			var sType;
			var iWidth;

			if ('R' == sStatus || 'E' == sStatus || 'V' == sStatus || 'S' == sStatus || 'D' == sStatus || 'J' == sStatus)
			{
				sType = 'instance';
			}
			else  // A, T C  <-- Arhicve type
			{
				sType = 'archive';
			}

			if ('instance' == sType)
			{
				//var sUrl = contextPath + "/common/processvariable.jsp?PROCESSID="
				//							 + eval("item_arr_singleStorage"+bizid+"[0]") + "&openpage=INSTANCE&now=" + (new Date).getTime() ;
				var sUrl = contextPath + "/common/processvariable.jsp?__ep__=";
				var pmsg = "?PROCESSID=" + eval("item_arr_singleStorage"+bizid+"[0]") + "&openpage=INSTANCE";
				var key = CryptoJS.enc.Latin1.parse(getAesKeyString(HWSESSIONINFO_KEY));
				var encrypted = CryptoJS.AES.encrypt(pmsg, key, {mode: CryptoJS.mode.ECB, padding:CryptoJS.pad.Pkcs7});
				encrypted = encrypted.ciphertext.toString();
				sUrl += encrypted +"&now="+ (new Date).getTime();
				iWidth = 740;
			}
			else
			{
				//var sUrl = contextPath + "/common/processvariable.jsp?PROCESSID="
				//								 + eval("item_arr_singleStorage"+bizid+"[0]") + "&ISREADONLY=Y" + "&openpage=ARCHIVE";
				var sUrl = contextPath + "/common/processvariable.jsp?__ep__=";
				var pmsg = "?PROCESSID=" + eval("item_arr_singleStorage"+bizid+"[0]") + "&ISREADONLY=Y" + "&openpage=ARCHIVE";
				var key = CryptoJS.enc.Latin1.parse(getAesKeyString(HWSESSIONINFO_KEY));
				var encrypted = CryptoJS.AES.encrypt(pmsg, key, {mode: CryptoJS.mode.ECB, padding:CryptoJS.pad.Pkcs7});
				encrypted = encrypted.ciphertext.toString();
				sUrl += encrypted +"&now="+ (new Date).getTime();
				iWidth = 650;
			}
			
			sUrl += "&__bizcoveId=" + bizid;
			
			var iHeight = window.screen.availHeight - 200;
			wndVaris = openPopup(sUrl, "", "ProcessVariable", iWidth, iHeight, true, true);
		}
		else if("urgency" == actionType)
		{
			var fid = eval("item_arr_singleStorage"+bizid+"[7]");
			var urgency = eval("item_arr_singleStorage"+bizid+"[4]");
			var deadlinesec = eval("item_arr_singleStorage"+bizid+"[5]");
			var initeddate = escapeUnicode(eval("item_arr_singleStorage"+bizid+"[6]"));
			var pid = eval("item_arr_singleStorage"+bizid+"[0]");

			var sUrl = contextPath + "/common/urgentstate.jsp?bizcove="+bizid+"&folderid=" + fid + "&authority=2146959359" 
						   + "&defid=" + "&defnm=" + "&ap=" 
						  + "&urgentstate=" + urgency + "&deadlinesec=" 
						 + deadlinesec + "&initiateddate=" + initeddate + "&pid=" + pid 
						 + "&rtime=" + new Date().getMilliseconds();

			sUrl += "&__bizcoveId=" + bizid;

			wndUrgentState = openPopup(sUrl, "", "wndUrgentState", 400, 250);
        }
		else if("move" == actionType)
		{
			var sType;
			var sStatus = eval("item_arr_singleStorage"+bizid+"[2]");
			if ('R' == sStatus || 'E' == sStatus || 'V' == sStatus || 'S' == sStatus || 'D' == sStatus || 'J' == sStatus)
			{
				sType = 'instance';
			}
			else  // A, T C  <-- Arhicve type
			{
				sType = 'archive';
			}
			
			if ('instance' == sType)
			{
				var fid = eval("item_arr_singleStorage"+bizid+"[7]");
				sMoveCopyFlag = "PI";
				var sUrl = contextPath + "/portal/common/selectfolderbody.jsp?category=instance&fid=" + fid + "&menu=" + sMoveCopyFlag;
				sUrl += "&__bizcoveId=" + bizid;
				openPopup(sUrl, "", "SelFolder", 400, 500, false, true);
            }
			else
			{		
				var fid = eval("item_arr_singleStorage"+bizid+"[8]");
				sMoveCopyFlag = "PA";				

				var sUrl = contextPath + "/portal/common/selectfolderbody.jsp?category=archive&fid=" + fid + "&menu=" + sMoveCopyFlag;
				sUrl += "&__bizcoveId=" + bizid;
                openPopup(sUrl, "", "SelFolder", 400, 500, false, true);
            }
		}
        else if ("status" == actionType)
        {
            var passwdFlag = eval("item_arr_singleStorage"+bizid+"[3]");
            var sStatus = eval("item_arr_singleStorage"+bizid+"[2]");
            var sType = 'instance';


            var modifyGranted = true;
            var deleteGranted = true;
            var instfid = eval("item_arr_singleStorage"+bizid+"[7]");
            var authority = "2146959359";
            var defid = "";
            var defnm = "";
            var ap = eval("curpage"+bizid);

            var sUrl = contextPath + "/instance/status.jsp?modifygranted=" + modifyGranted + "&deletegranted="
                                   + deleteGranted+"&fid="+ instfid + "&authority=" + authority
                                   + "&defid=" + defid + "&defnm=" + defnm + "&ap=" +ap;

            sUrl += "&__bizcoveId=" + bizid;

            openPopup(sUrl, "", "SelStatus", 330, 150);
        }
    }
	else
	{
		return;
	}
}

function monitor_printNum(sURL, bizid, obj)
{
    try
    {
        if ("undefined" != typeof(obj))
        {
            enableDisableAnchor(obj, false);
        }

        enableDisableAllLinks(false);
    }
    catch(e)
    {
    }

    if(bizid.length == 10)
		sURL = sURL +"&preview_bizcove=y";
		
	sURL = sURL + "&__bizcoveId=" + bizid;

    sURL = adjustMaximizeURL(sURL, bizid);

    location.href = sURL;
}

function monitor_printNumDirect(sURL, bizid, totalCount, customizedQueryBizcove, obj)
{
    try
    {
        if ("undefined" != typeof(obj))
        {
            enableDisableAnchor(obj, false);
        }

        enableDisableAllLinks(false);
    }
    catch(e)
    {
    }

    if(bizid.length ==10)
		sURL = sURL + "&preview_bizcove=y";
		
	sURL += "&__bizcoveId=" + bizid;

    sURL = adjustMaximizeURL(sURL, bizid);

    var getap = eval("document.thepage_" + bizid + ".monitor_getnum.value");
    
    if (totalCount == 0 && customizedQueryBizcove.toLowerCase() == "true")
    {
        sURL = sURL + "&ap=" + getap;
        location.href = sURL;
    }
    else
    {
        if (parseInt(getap) > parseInt(eval("monitor_totpagecount" + bizid)) || parseInt(getap) < 1)
            alert(msgErrorWrongNumber);
        else
        {
            sURL = sURL + "&ap=" + getap;
            location.href = sURL;
        }
    }
}

function monitor_OpenMultiViewer(bizid, isSS, reservedParam, useAccessibility)
{
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}
	tmpUseAccessibility = useAccessibility;
    var iWidth = window.screen.availWidth-100;
	var iHeight = window.screen.availHeight-200;
	curBizID = bizid;
	var arrLen = eval("item_arr"+bizid+".length");

	if (!isSS)
	{
		if (arrLen > 1)
		{
			alert(MSG_CMM_ONLY_ONE_SELECT_ITEM);
			return;
		}
		else if (arrLen == 0)
		{
			alert(MSG_CMM_SELECT_ITEM);
			return;
		}
	}

	var sPasswdFlag = eval("item_arr"+bizid+"[0][3]");
	var sProcName = escapeUnicode(eval("item_arr"+bizid+"[0][1]"));
	var sStatus = eval("item_arr"+bizid+"[0][2]");
	var sProcID = eval("item_arr"+bizid+"[0][0]");
	var sType;
	if ('R' == sStatus || 'E' == sStatus || 'V' == sStatus || 'S' == sStatus || 'D' == sStatus || 'J' == sStatus)
	{
		sType = 'cpinstance';
	}
	else  // A, T C  <-- Arhicve type
	{
		sType = 'cparchive';
	}

	if("F" == sPasswdFlag)
	{
		//var sUrl = contextPath + "/common/audit.jsp?pid=" + sProcID + "&isbizcove=y&type=" + sType+ "&pnm=" + sProcName + "&passwordflag=F&t=" + (new Date().getTime());
		var sUrl = contextPath + "/common/audit.jsp?__ep__=";
		var pmsg = "?pid=" + sProcID + "&isbizcove=y&type=" + sType+ "&pnm=" + sProcName + "&passwordflag=F";
		var key = CryptoJS.enc.Latin1.parse(getAesKeyString(HWSESSIONINFO_KEY));
		var encrypted = CryptoJS.AES.encrypt(pmsg, key, {mode: CryptoJS.mode.ECB, padding:CryptoJS.pad.Pkcs7});
		encrypted = encrypted.ciphertext.toString();
		sUrl += encrypted +"&t="+ (new Date).getTime();
		sUrl += "&__bizcoveId=" + bizid;

		if(isModalMonitorMode())
		{
			iWidth = "100%";
			iHeight = "100%";
		}
		wndMonitor = openMonitorPopup(sUrl, "", "Monitor", iWidth, iHeight, true, true, true, true);
	}
	else if("T" == sPasswdFlag)
	{
		passwordValue = "false";
		actionType = "multiviewer";

		eval("item_arr_singleStorage"+bizid+"[0] = item_arr"+bizid+"[0][0]");
		eval("item_arr_singleStorage"+bizid+"[1] = item_arr"+bizid+"[0][1]");
		eval("item_arr_singleStorage"+bizid+"[2] = item_arr"+bizid+"[0][2]");
		eval("item_arr_singleStorage"+bizid+"[3] = item_arr"+bizid+"[0][3]");
		eval("item_arr_singleStorage"+bizid+"[4] = item_arr"+bizid+"[0][4]");
		eval("item_arr_singleStorage"+bizid+"[5] = item_arr"+bizid+"[0][5]");
		eval("item_arr_singleStorage"+bizid+"[6] = item_arr"+bizid+"[0][6]");
		eval("item_arr_singleStorage"+bizid+"[7] = item_arr"+bizid+"[0][7]");
		eval("item_arr_singleStorage"+bizid+"[8] = item_arr"+bizid+"[0][8]");

		var sUrl = contextPath + "/common/passwordframe.jsp?callbackname=getCheckPasswordValueMonitor";
	   wndPassword = ShowWindow(sUrl, "wndPassword", CHK_PASSWORD, 300, 140, "no");
	}
}

function monitor_OpenMergeProcess(bizid)
{
	curBizID = bizid;
	var arrLen = eval("item_arr"+bizid+".length");

	if (arrLen == 0)
	{
		alert(MSG_CMM_SELECT_ITEM);
		return;
	}
	else if (arrLen != 2)
	{
		alert(MSG_CMM_ONLY_TWO_SELECT_ITEM);
		return;
	}
	var procid = eval("item_arr"+bizid+"[0][0]");
	var linkedprocid = eval("item_arr"+bizid+"[1][0]");
	var sStatus1 = eval("item_arr"+bizid+"[0][2]");
	var sStatus2 = eval("item_arr"+bizid+"[1][2]");
	if ('R' == sStatus1 || 'E' == sStatus1 || 'V' == sStatus1 || 'S' == sStatus1 || 'D' == sStatus1 || 'J' == sStatus1)
	{
		// okay
	}
	else
	{
		alert(MSG_CMM_MERGE_PROCESS_IS_COMPLETED);
		return;
	}
	if ('R' == sStatus2 || 'E' == sStatus2 || 'V' == sStatus2 || 'S' == sStatus2 || 'D' == sStatus2 || 'J' == sStatus2)
	{
		// okay
	}
	else
	{
		alert(MSG_CMM_MERGE_PROCESS_IS_COMPLETED);
		return;
	}

    var sUrl = contextPath + "/instance/merge.jsp?pid=" + procid + "&lpid=" + linkedprocid;
    sUrl += "&__bizcoveId=" + bizid;

    openPopup(sUrl, "", "MergeProcess", 520, 270);
}

function monitor_OpenSplitProcess(bizid)
{
    curBizID = bizid;
    var arrLen = eval("item_arr"+bizid+".length");

    if (arrLen == 0)
    {
        alert(MSG_CMM_SELECT_ITEM);
        return;
    }
    else if (arrLen > 1)
    {
        alert(MSG_CMM_ONLY_ONE_SELECT_ITEM);
        return;
    }
    var procid = eval("item_arr"+bizid+"[0][0]");
    var sStatus1 = eval("item_arr"+bizid+"[0][2]");
    if ('R' == sStatus1 || 'E' == sStatus1 || 'V' == sStatus1 || 'S' == sStatus1 || 'D' == sStatus1 || 'J' == sStatus1)
    {
        // okay
    }
    else
    {
        alert(MSG_CMM_SPLIT_PROCESS_IS_COMPLETED);
        return;
    }

    var sUrl = contextPath + "/instance/split.jsp?pid=" + procid;
    sUrl += "&__bizcoveId=" + bizid;

    openPopup(sUrl, "", "SplitProcess", 520, 270);
}

function monitor_SingleCustom1(bizid, isSS)
{
	if (!isSS)
	{
		var bizcove = new Object();
		var procs = new Object(); 
		var variables = new Object(); // for future use.
		bizcove.id = bizid;
		procs.archivefldrid = eval("item_arr"+bizid+"[0][8]");
		procs.creationdtime = eval("item_arr"+bizid+"[0][6]");
		procs.deadline = eval("item_arr"+bizid+"[0][5]");
		procs.instfldrid = eval("item_arr"+bizid+"[0][7]");
		procs.name = eval("item_arr"+bizid+"[0][1]");
		procs.passwdflag = eval("item_arr"+bizid+"[0][3]");
		procs.procid = eval("item_arr"+bizid+"[0][0]");
		procs.state = eval("item_arr"+bizid+"[0][2]");
		procs.urgency = eval("item_arr"+bizid+"[0][4]");
		alert('bizcove.id = ' + bizcove.id
			+ '\nprocs.archivefldrid = ' + procs.archivefldrid
			+ '\nprocs.creationdtime = ' + procs.creationdtime
			+ '\nprocs.deadline = ' + procs.deadline
			+ '\nprocs.instfldrid = ' + procs.instfldrid
			+ '\nprocs.name = ' + procs.name
			+ '\nprocs.passwdflag = ' + procs.passwdflag
			+ '\nprocs.procid = ' + procs.procid
			+ '\nprocs.state = ' + procs.state
			+ '\nprocs.urgency = ' + procs.urgency
			+ '\n\n(Custom 1 is not yet implemented - edit includes/bizcoves/monitor.js to add more actions)');
/*
		var sUrl = contextPath + "/solutions/monitorcustom1.jsp?procid=" + procs.procid + "&rtime=" + new Date().getMilliseconds();
		var iWidth = window.screen.availWidth * 0.6;
		var iHeight = window.screen.availWidth * 0.4;
		var iLeft = (window.screen.availWidth - iWidth) / 2;
		var iTop = (window.screen.availHeight - iHeight) / 2;
		var features = "status=no,toolbars=no,resizable=yes,left=" + iLeft + "," + "top=" + iTop + "," + "width=" + iWidth + "," + "height=" + iHeight;
		w = window.open(sUrl, "monitorCustom1", features);
		w.focus();
*/
	}
	else
	{
		alert("monitor.js: Custom 1 does not support 'isSS = true'");
	}
}

function monitor_SingleCustom2(bizid, isSS)
{
	if (!isSS)
	{
		var bizcove = new Object();
		var procs = new Object(); 
		var variables = new Object(); // for future use.
		bizcove.id = bizid;
		procs.archivefldrid = eval("item_arr"+bizid+"[0][8]");
		procs.creationdtime = eval("item_arr"+bizid+"[0][6]");
		procs.deadline = eval("item_arr"+bizid+"[0][5]");
		procs.instfldrid = eval("item_arr"+bizid+"[0][7]");
		procs.name = eval("item_arr"+bizid+"[0][1]");
		procs.passwdflag = eval("item_arr"+bizid+"[0][3]");
		procs.procid = eval("item_arr"+bizid+"[0][0]");
		procs.state = eval("item_arr"+bizid+"[0][2]");
		procs.urgency = eval("item_arr"+bizid+"[0][4]");
		alert('bizcove.id = ' + bizcove.id
			+ '\nprocs.archivefldrid = ' + procs.archivefldrid
			+ '\nprocs.creationdtime = ' + procs.creationdtime
			+ '\nprocs.deadline = ' + procs.deadline
			+ '\nprocs.instfldrid = ' + procs.instfldrid
			+ '\nprocs.name = ' + procs.name
			+ '\nprocs.passwdflag = ' + procs.passwdflag
			+ '\nprocs.procid = ' + procs.procid
			+ '\nprocs.state = ' + procs.state
			+ '\nprocs.urgency = ' + procs.urgency
			+ '\n\n(Custom 2 is not yet implemented - edit includes/bizcoves/monitor.js to add more actions)');
/*
		var sUrl = contextPath + "/solutions/monitorcustom2.jsp?procid=" + procs.procid + "&rtime=" + new Date().getMilliseconds();
		var iWidth = window.screen.availWidth * 0.6;
		var iHeight = window.screen.availWidth * 0.4;
		var iLeft = (window.screen.availWidth - iWidth) / 2;
		var iTop = (window.screen.availHeight - iHeight) / 2;
		var features = "status=no,toolbars=no,resizable=yes,left=" + iLeft + "," + "top=" + iTop + "," + "width=" + iWidth + "," + "height=" + iHeight;
		w = window.open(sUrl, "monitorCustom2", features);
		w.focus();
*/
	}
	else
	{
		alert("monitor.js: Custom 2 does not support 'isSS = true'");
	}
}

function monitor_SingleCustom3(bizid, isSS)
{
	if (!isSS)
	{
		var bizcove = new Object();
		var procs = new Object(); 
		var variables = new Object(); // for future use.
		bizcove.id = bizid;
		procs.archivefldrid = eval("item_arr"+bizid+"[0][8]");
		procs.creationdtime = eval("item_arr"+bizid+"[0][6]");
		procs.deadline = eval("item_arr"+bizid+"[0][5]");
		procs.instfldrid = eval("item_arr"+bizid+"[0][7]");
		procs.name = eval("item_arr"+bizid+"[0][1]");
		procs.passwdflag = eval("item_arr"+bizid+"[0][3]");
		procs.procid = eval("item_arr"+bizid+"[0][0]");
		procs.state = eval("item_arr"+bizid+"[0][2]");
		procs.urgency = eval("item_arr"+bizid+"[0][4]");
		alert('bizcove.id = ' + bizcove.id
			+ '\nprocs.archivefldrid = ' + procs.archivefldrid
			+ '\nprocs.creationdtime = ' + procs.creationdtime
			+ '\nprocs.deadline = ' + procs.deadline
			+ '\nprocs.instfldrid = ' + procs.instfldrid
			+ '\nprocs.name = ' + procs.name
			+ '\nprocs.passwdflag = ' + procs.passwdflag
			+ '\nprocs.procid = ' + procs.procid
			+ '\nprocs.state = ' + procs.state
			+ '\nprocs.urgency = ' + procs.urgency
			+ '\n\n(Custom 3 is not yet implemented - edit includes/bizcoves/monitor.js to add more actions)');
/*
		var sUrl = contextPath + "/solutions/monitorcustom3.jsp?procid=" + procs.procid + "&rtime=" + new Date().getMilliseconds();
		var iWidth = window.screen.availWidth * 0.6;
		var iHeight = window.screen.availWidth * 0.4;
		var iLeft = (window.screen.availWidth - iWidth) / 2;
		var iTop = (window.screen.availHeight - iHeight) / 2;
		var features = "status=no,toolbars=no,resizable=yes,left=" + iLeft + "," + "top=" + iTop + "," + "width=" + iWidth + "," + "height=" + iHeight;
		w = window.open(sUrl, "monitorCustom3", features);
		w.focus();
*/
	}
	else
	{
		alert("monitor.js: Custom 3 does not support 'isSS = true'");
	}
}

function monitor_SingleCustom4(bizid, isSS)
{
	if (!isSS)
	{
		var bizcove = new Object();
		var procs = new Object(); 
		var variables = new Object(); // for future use.
		bizcove.id = bizid;
		procs.archivefldrid = eval("item_arr"+bizid+"[0][8]");
		procs.creationdtime = eval("item_arr"+bizid+"[0][6]");
		procs.deadline = eval("item_arr"+bizid+"[0][5]");
		procs.instfldrid = eval("item_arr"+bizid+"[0][7]");
		procs.name = eval("item_arr"+bizid+"[0][1]");
		procs.passwdflag = eval("item_arr"+bizid+"[0][3]");
		procs.procid = eval("item_arr"+bizid+"[0][0]");
		procs.state = eval("item_arr"+bizid+"[0][2]");
		procs.urgency = eval("item_arr"+bizid+"[0][4]");
		alert('bizcove.id = ' + bizcove.id
			+ '\nprocs.archivefldrid = ' + procs.archivefldrid
			+ '\nprocs.creationdtime = ' + procs.creationdtime
			+ '\nprocs.deadline = ' + procs.deadline
			+ '\nprocs.instfldrid = ' + procs.instfldrid
			+ '\nprocs.name = ' + procs.name
			+ '\nprocs.passwdflag = ' + procs.passwdflag
			+ '\nprocs.procid = ' + procs.procid
			+ '\nprocs.state = ' + procs.state
			+ '\nprocs.urgency = ' + procs.urgency
			+ '\n\n(Custom 4 is not yet implemented - edit includes/bizcoves/monitor.js to add more actions)');
/*
		var sUrl = contextPath + "/solutions/monitorcustom4.jsp?procid=" + procs.procid + "&rtime=" + new Date().getMilliseconds();
		var iWidth = window.screen.availWidth * 0.6;
		var iHeight = window.screen.availWidth * 0.4;
		var iLeft = (window.screen.availWidth - iWidth) / 2;
		var iTop = (window.screen.availHeight - iHeight) / 2;
		var features = "status=no,toolbars=no,resizable=yes,left=" + iLeft + "," + "top=" + iTop + "," + "width=" + iWidth + "," + "height=" + iHeight;
		w = window.open(sUrl, "monitorCustom4", features);
		w.focus();
*/
	}
	else
	{
		alert("monitor.js: Custom 4 does not support 'isSS = true'");
	}
}
