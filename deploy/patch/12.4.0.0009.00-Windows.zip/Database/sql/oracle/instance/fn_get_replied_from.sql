CREATE OR REPLACE
function		 fn_get_replied_from
  ( i_procid IN number,
	i_workid IN number)
  RETURN  number IS
	l_value 	int;
-- Version 12.4.0.0009.00
BEGIN
	select witemseq into l_value
	  from (select * from witemti
	 where procid = i_procid
	   and fromseq = i_workid
	   and state = 'J'
	 order by dtime desc
     ) where rownum = 1;
	
	RETURN l_value;
END;
/