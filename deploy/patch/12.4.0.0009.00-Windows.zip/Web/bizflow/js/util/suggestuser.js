function initializeSuggestUser(id, objId, url, itemAdded, itemRemoved, formatList, multiple, extraParams, selectionAdded) {
    $("#" + objId).autoSuggest(url,
        {
            asHtmlID:objId,
            itemAdded:itemAdded,
            itemRemoved:itemRemoved,
            formatList:formatList,
            startText:enterNameHere,
            limitText:noMoreSelection,
            minChars:1,
            neverSubmit:true,
            selectionLimit:!multiple,
            extraParams:extraParams,
            selectionAdded:selectionAdded,
            selectedItemProp:'name',
            selectedValuesProp:'id',
            searchObjProps:'name',
            queryParam:'query'});
}

function __highlight(str) {
    return "<span style='font-weight:bold'>" + str + "</span>";
}

function generateSuggestUserHtml(data, imageBasePath) {
    var aMarkup = "";
    var type = data["type"];
    var email = data["email"];
    var isAbsent = data["isabsent"];
    var additionalMessage = data["message"];
    if(null == additionalMessage || "undefined" == typeof(additionalMessage)) {
        additionalMessage = "";
    }
    var $divSearchTop = $("<div/>");
    var $divSearchResult = $('<div class="searchresult"></div>');
    if (type == "G") {
        $divSearchResult.append("<img src='" + imageBasePath + "/usergroup.gif'/>&nbsp;");
        $divSearchResult.append(__highlight(data["name"]));
    }
    else if (type == "U") {
        var emailTag = "";
        if (email && email.length > 0)
            emailTag = " &lt;" + __highlight(email) + "&gt;";

        var image = "";
        if (isAbsent == "true")
            image = "<img src='" + imageBasePath + "/icons/icon_user_abs.gif' title='" + additionalMessage + "'/>";
        else
            image = "<img src='" + imageBasePath + "/icon_user.gif'/>";
        $divSearchResult.append(image + "&nbsp;");
        $divSearchResult.append(__highlight(data["name"]));
        $divSearchResult.append(emailTag);
    }
    else if (type == "E") {
        $divSearchResult.append(__highlight(data["name"]));
    }
    else if (type == "N") {
        $divSearchResult.append(data["name"]);
    }
    $divSearchTop.append($divSearchResult);
    return $divSearchTop.html();

}

function addSuggestUser(id4Id, id4Name, id, name) {
    var idField = document.getElementById(id4Id);
    var idFieldValue = idField.value;
    if ((idFieldValue + ";").indexOf(id) == -1) {
        if (idFieldValue != "") {
            idFieldValue += ";";
        }
        idField.value = idFieldValue + id;
        var nameField = document.getElementById(id4Name);
        var nameFieldValue = nameField.value;
        if (nameFieldValue != "") {
            nameFieldValue += ";";
        }
        nameField.value = nameFieldValue + name;
        return true;
    }

    return false;
}

function onSuggestUserAdded(data, id4Id, id4Name) {
    if(data["type"] == "N") return false; // bug27994
    var id = "[" + data["type"] + "]" + data["id"];
    var rc = addSuggestUser(id4Id, id4Name, id, data["name"]);
    var obj = eval(id4Name + "Obj");
    if (obj) {
        obj.onSuggestUserAdded(data);
    }
    return rc;
}

function onSuggestUserRemoved(id, id4Id, id4Name) {
    var idField = document.getElementById(id4Id);
    var nameField = document.getElementById(id4Name);
    var ids = idField.value.split(";");
    var names = nameField.value.split(";");
    var newIds = "";
    var newNames = "";
    for (var i = 0; i < ids.length; i++) {
        var _id = ids[i].substring(3);
        if (id != _id) {
            if (newIds != "") {
                newIds += ";";
            }
            newIds += ids[i];
            if (newNames != "") {
                newNames += ";"
            }
            newNames += names[i];
        }
    }

    idField.value = newIds;
    nameField.value = newNames;

    var obj = eval(id4Name + "Obj");
    if (obj && obj.onSuggestUserRemoved) {
        obj.onSuggestUserRemoved();
    }
}

function SuggestUser(id, id4Id, multiple) {
    this.id = id;
    this.id4Id = id4Id;
    this.isMultiple = multiple;
    this.displayDivId = id + "Display";

    this.getCurrentInput = function () {
        return "";
    };

    this.removeAll = function () {
        $("#" + this.id + "Auto").trigger("removeAll");
        var userIdsField = document.getElementById(this.id4Id);
        var userNamesField = document.getElementById(this.id);
        userIdsField.value = "";
        userNamesField.value = "";
    };

    this.addSelectedUser = function (type, id, name) {
        var data = [
            {message:"", id:id, isabsent:"false", email:"", name:name, type:type}
        ];
        $("#" + this.id + "Auto").trigger("addItem", data[0]);
    };

    this.setFixedUser = function (id) { // A fixed user cannot be removed.
        $("#" + this.id + "Auto").trigger("setFixedUser", id);
    };

    this.addSelectedUserMultiple = function (idString, nameString) {
        this.addUsers(idString, nameString);
    };

    this.addUser = function (userId, userName) {
        if (userId != "" && userName != "") {
            var type = userId.substring(1, 2);
            var id = userId.substring(3);
            this.addSelectedUser(type, id, userName);
        }
    };

    this.addUsers = function (userIdString, userNameString) {
        if (userIdString != "") {
            var ids = userIdString.split(";");
            var names = userNameString.split(";");
            for (var i = 0; i < ids.length; i++) {
                this.addUser(ids[i], names[i]);
            }
        }
    };

    this.clearUsers = function (focused) {
        this.removeAll();
    };

    this.extractUserName = function (participantId) {
        var name = "";
        var userIdsField = document.getElementById(this.id4Id);
        var userNamesField = document.getElementById(this.id);

        var ids = userIdsField.value.split(";");
        var names = userNamesField.value.split(";");
        for (var i = 0; i < ids.length; i++) {
            if (ids[i] == participantId) {
                name = names[i];
                break;
            }
        }

        return name;
    };

    this.extractUserNames = function () {
        var userNames = "";

        var userNamesField = document.getElementById(this.id);
        userNames = userNamesField.value;

        if (userNames.lastIndexOf(";") == userNames.length - 1)
            userNames = userNames.substring(0, userNames.length - 1);

        return userNames;
    };


    // Check whether current selection is valid.
    // This only applies when isMultiple = false.
    this.isValidSelection = function () {
        var isValid = true;

        if (!this.isMultiple) {
//            var autoCmplField = document.getElementById(this.id + "Auto");
            var userIdsField = document.getElementById(this.id4Id);
            var userNamesField = document.getElementById(this.id);

            if (userIdsField.value.length == 0
//                && autoCmplField.value.length == 0
                && userNamesField.value.length == 0) {
                //if anything is not yet selected, it is valid.
            }
            else {
                var participantId = userIdsField.value;
                if (participantId.length < 4
                    || !(participantId.match(/(\[U\]|\[G\]|\[D\]|\[E\])/g)))
                    isValid = false;

                // autoCmplField and userNamesField should match.
//                if (autoCmplField.value != userNamesField.value)
//                    isValid = false;
            }

            //clears value.
            if (!isValid) {
                userIdsField.value = "";
                userNamesField.value = "";
            }
        }
        return isValid;
    };

    this.onSuggestUserAdded = function (data) {
    };
}
