
var __RS_IFRAME_MODE = false;
var __RS_LAYER_MODE = false;
var __RS_PROXY_WINDOW = null;
var __RS_PROXY_BLANK = null;

function RSEnableRemoteScripting(proxyWindow, blankURL) {
	if ('undefined' != typeof(proxyWindow) && null != proxyWindow) {
		__RS_PROXY_WINDOW = proxyWindow;
	} else {
			var iframe = null;

                iframe = document.getElementById("_RS_IFRAME");
				if ('undefined' == typeof(iframe) || null == iframe) {
                    try
                    {
                        iframe = document.createElement("IFRAME");
                        iframe.setAttribute('id', '_RS_IFRAME');
						iframe.setAttribute('name', '_RS_IFRAME');
						iframe.setAttribute('title', 'No user content');
						iframe.setAttribute('aria-hidden', 'true');
                        iframe.style.border = '0px';
                        iframe.style.width = '0px';
                        iframe.style.height = '0px';
						iframe.style.display = "none";
                        iframe.src = blankURL;
                        if("undefined" != typeof(document.body))
                        {
                            document.body.appendChild(iframe);
                        }
                        else
                        {
                            document.appendChild(iframe);
                        }
                    }
                    catch(e)
                    {
                        document.writeln("<IFRAME TITLE=\"No user content\" ID=\"_RS_IFRAME\" NAME=\"_RS_IFRAME\" SRC=\"" + blankURL + "\" aria-hidden=\"true\" style=\"WIDTH: 200px; HEIGHT: 200px; DISPLAY: none\"></IFRAME>");
                    }
                }

			__RS_IFRAME_MODE = true;
	}
	__RS_PROXY_BLANK = blankURL;
}

function strReplace(Str, repstr, prefix, suffix)
{
	var str = '' + Str;
	var ret=str;
	var idx = str.indexOf(prefix);
	if(idx >= 0)
	{
		ret = str.substring(0, idx);
		ret += repstr;
		var Suffstr = str.substring(idx + prefix.length);
		idx = Suffstr.indexOf(suffix);
		if(idx >= 0)
		{
			ret += Suffstr.substring(idx);
		}
	}
	return ret;
}

function revisionUrl(url)
{
	var thisLocation = "" + this.location.href;

	var idx = url.indexOf("/");
	if(idx == 0)
	{
		var idx2 = url.indexOf("/", 1);
		if(idx2 != -1)
		{
			var contextPath = url.substring(0, idx2+1);
			var idx3 = thisLocation.indexOf(contextPath);
			if(idx3 != -1)
			{
				var newUrl = thisLocation.substring(0, idx3) + url;
				return newUrl;
			}
		}
	}

	return url;
}


function RSExecute()
{
	if (__RS_IFRAME_MODE) {
		__RS_PROXY_WINDOW = document.getElementById("_RS_IFRAME");
	}

	if ('undefined' != typeof(__RS_PROXY_WINDOW) && null != __RS_PROXY_WINDOW) {
		var args = RSExecute.arguments;
		var argc = args.length;

		if (argc >= 3) {
			var url =	args[1] 
						+ "?_mtype=execute&_method=" + args[2] 
						+ "&_callback=" + args[0];

			if (true == __RS_IFRAME_MODE)
				url += "&iframe=y";
			url += "&pcount=" + (argc - 3);
			var i;
			for (i = 3; i != argc; ++i)
				url += "&p" + (i - 3) + "=" + encodeURIComponent(args[i]);
			url += "&t=" + (new Date().getTime());
			var str = '' + this.location;
			if(str.indexOf('/portal/server.pt/gateway') > 0)
			{
				url = revisionUrl(url);
			}

			url = getSecurityTokenUrl(url);

			var obj = new Object();
			obj.src = url;
			__RS_PROXY_WINDOW.src = obj.src;

		}
	}
	return null;
}

function RSClearContext() {
	if ('undefined' != typeof(__RS_PROXY_WINDOW) && null != __RS_PROXY_WINDOW && null != __RS_PROXY_BLANK)
	{
		try
		{
			__RS_PROXY_WINDOW.contentDocument.location.replace(__RS_PROXY_BLANK);
		}
		catch(e)
		{}
    }
}
