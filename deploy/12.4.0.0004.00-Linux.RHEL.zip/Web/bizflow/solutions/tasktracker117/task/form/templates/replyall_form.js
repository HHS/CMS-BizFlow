//Ext.require(['*']);
//Ext.require([
//    'Ext.tab.*',
//    'Ext.window.*',
//    'Ext.tip.*',
//    'Ext.layout.container.Border'
//]);

var winReplyAllForm;
var winReplyAllFormOpened = false;
var toNameObj = null;
var ccNameObj = null;

function closeReplyAll()
{
    if(winReplyAllForm)
	{
		try
		{
			// delete all attachments before closing
			if(document.taskForm) {
				if(document.taskForm.selAttach) {
					if (document.taskForm.selAttach.options.length > 0) {
						deleteAttachments("ALL");
					
						document.taskForm.selAttach.options.length = 0;
					}
				}
			}
		}
		catch (e) {alert(e);}
		
		$("#attachmentDisplayContainer").remove();
		__attachmentIndex = 0;
        winReplyAllForm.close();
        try { // clear DOM for reply-all form
            winReplyAllForm.removeAll();
            $( "#winReplyAllForm" ).remove();
            $( "div.x-window-ghost" ).remove();
        } catch(e) {};
        winReplyAllFormOpened = false;
        winReplyAllForm = null;
    }

    var fromAddressStore = Ext.getStore('fromAddressStore');
    if (fromAddressStore) {
        fromAddressStore.removeAll(true);
        fromAddressStore = null;
    }
}

function replyAllForm(mode, imageLinks, hideTopToolbar)
{
    if(winReplyAllFormOpened) {
        return;
    }
    winReplyAllFormOpened = true;

    if ("undefined" == typeof(mode)) {
        mode = "";
    }
    if ("undefined" == typeof(hideTopToolbar)) {
        hideTopToolbar = false;
    }

    Ext.define('emails', {
        extend: 'Ext.data.Model',
        fields: [
            {name: 'name', type: 'string'},
            {name: 'email', type: 'string'}
        ]
    });
    var fromAddressStore = Ext.create('Ext.data.Store', {
        model: 'emails',
        storeId: 'fromAddressStore',
        proxy: {
            type: 'ajax',
            url: contextPath + '/webdesign/correspondence?method=getemails',
            extraParams: {
                en1: emailSenderName,
                ev1: emailSenderAddress,
                en2: personalEmailAddress,
                ev2: personalEmailAddress
            },
            reader: {
                type: 'json',
                root: 'response.data',
                totalProperty: 'totalCount'
            }
        },
        autoLoad: {
            scope: this,
            callback: function () {
                var comboBox = Ext.getCmp("comboFromAddress");
                if (comboBox) {
                    comboBox.setValue(emailSenderAddress);
                }
            }
        }
    });

    var form = Ext.create('Ext.form.Panel', {
        plain: true,
        border: 0,
        bodyPadding: 5,
        bodyStyle: 'background:transparent;',

        fieldDefaults: {
            labelWidth: 55,
            anchor: '100%'
        },

        layout: {
            type: 'vbox',
            align: 'stretch'  // Child items are stretched to full width
        },

        items: [{
            xtype:          'combo',
            id:				'comboFromAddress',
            value:          emailSenderAddress,
            triggerAction:  'all',
            forceSelection: true,
            selectOnFocus: true,
            editable:       false,
            fieldLabel:     resObject.formFromLabel,
            name:           'from',
            displayField:   'email',
            valueField:     'email',
            queryMode: 'remote',
            store: fromAddressStore
        }, {
            xtype: 'textfield',
            fieldLabel: resObject.formToLabel,
            name: 'toNameAuto',
            inputId: 'toNameAuto',
            fieldCls: 'text',
            maxLength: 2000,
            value: ''
        }, {
            xtype: 'textfield',
            fieldLabel: resObject.formCcLabel,
            name: 'ccNameAuto',
            inputId: 'ccNameAuto',
            maxLength: 2000,
            fieldCls: 'text',
            value: ''
        }, {
            xtype: 'textfield',
            fieldLabel: resObject.formSubjectLabel,
            name: 'subject',
            maxLength: 2000,
            value: emailSubjectValue
        }, {
            xtype: 'htmleditor',
            id: 'htmleditor',
            fieldLabel: 'Message text',
            hideLabel: true,
            name: 'msg',
            value: emailBodyValue,
            maxLength: 200000, // almost 200 Kb
            style: 'margin:0', // Remove default margin
            flex: 1  // Take up all *remaining* vertical space
        }, {
            xtype: 'hidden',
            hidden: true, hideLabel: true,
            name: 'taskID',
            value: taskId
        }, {
            xtype: 'hidden',
            hidden: true, hideLabel: true,
            name: 'subTaskID',
            value: subTaskId
        }, {
            xtype: 'hidden',
            hidden: true, hideLabel: true,
            name: 'mode',
            value: mode
        }, {
            xtype: 'hidden',
            hidden: true, hideLabel: true,
            name: 'toId',
            inputId: 'toId',
            value: ''
        }, {
            xtype: 'hidden',
            hidden: true, hideLabel: true,
            name: 'toName',
            inputId: 'toName',
            value: ''
        }, {
            xtype: 'hidden',
            hidden: true, hideLabel: true,
            name: 'ccId',
            inputId: 'ccId',
            value: ''
        }, {
            xtype: 'hidden',
            hidden: true, hideLabel: true,
            name: 'ccName',
            inputId: 'ccName',
            value: ''
        }, {
            xtype: 'hidden',
            hidden: true, hideLabel: true,
            name: 'processId',
            inputId: 'processId',
            value: processId
        }, {
            xtype: 'hidden',
            hidden: true, hideLabel: true,
            name: 'activityId',
            inputId: 'activityId',
            value: activityId
        }, {
            xtype: 'hidden',
            hidden: true, hideLabel: true,
            name: 'templateId',
            inputId: 'templateId',
            value: templateId
        }, {
            xtype: 'hidden',
            hidden: true, hideLabel: true,
            name: 'isarchive',
            inputId: 'isarchive',
            value: isarchive
        }]
    });

    winReplyAllForm = Ext.create('Ext.window.Window', {
        id: "winReplyAllForm",
        closable: false,
        closeAction: 'destroy',
        draggable: false,
        layout: 'fit',
        bodyStyle: 'padding: 5px;',
        //animateTarget: 'btnReplyall', // sometimes not working
        modal: true,
        maximized : true,
        resizable: false,
        items: form
    });

    if(!hideTopToolbar) {
        winReplyAllForm.addDocked(
            {
                xtype: 'toolbar', dock: 'top', layout: {pack: 'left'},
                id: 'topToolbarBack',
                items: [{
                    text: resObject.backLabel, handler: closeReplyAll
                }]
            }
        );
    }
    var toptoolbarMenuItems = [];
    toptoolbarMenuItems.push({
        id:'sendButton',
        scope: this,
        text:resObject.sendMenuText,
        iconCls:'sendEMail',
        handler: function(){
            var isValid = true;
            clearInnerHTML("fromName_err");
            clearInnerHTML("toName_err");
            clearInnerHTML("ccName_err");
            if($("input[name='from']").val().length == 0) {
                var msg = MSG_REQUIRED_FIELD.replace(/\{0\}/g, resObject.fromLabel);
                displayErrorMessage("fromName_err", msg);
                isValid = false;
            }
            if($("#as-values-toNameAuto").val().length == 0) {
                var msg = MSG_REQUIRED_FIELD.replace(/\{0\}/g, resObject.toLabel);
                displayErrorMessage("toName_err", msg);
                isValid = false;
            }
            if(isValid && $("#toNameAuto.as-input").length > 0) {
                var $str = $.trim($("#toNameAuto").val());
                if(($str != enterNameHere) && ($str.length > 0)) {
                    var msg = MSG_INVALIDTO;
                    displayErrorMessage("toName_err", msg);
                    isValid = false;
                }
            }
            if($("#ccNameAuto.as-input").length > 0) {
                var $str = $.trim($("#ccNameAuto").val());
                if(($str != enterNameHere) && ($str.length > 0)) {
                    var msg = $("#ccName_err").html() + " " + MSG_INVALIDCC;
                    displayErrorMessage("ccName_err", msg);
                    isValid = false;
                }
            }

            var editor = form.items.get('htmleditor');
            if ("undefined" != typeof(MSG_EMAIL_CONTENTS_EXCEED_LIMIT)) {
                if(editor.maxLength < editor.value.length)
                {
                    alert(MSG_EMAIL_CONTENTS_EXCEED_LIMIT);
                    isValid = false;
                }
            }

            if(isValid) {
                blockUI(mode);
                Ext.Ajax.request ( {
                    url: basePath + '/task/send_correspondence.jsp',
                    timeout: 120000, // 120 seconds
                    method: 'POST',
                    params:
                    {
                        formData: Ext.encode(form.getValues())
                    },

                    success: function (response, opts)
                    {
                        var json = JSON.parse(response.responseText);
                        if(json.response.success) {
                            afterSend(resObject.replyResultMsg);
                            try {
                                var grid = Ext.getCmp("correspondenceGrid");
                                if(null == grid) {
                                    if(window.getWIHCorrespondence) {
                                        var caller = window.getWIHCorrespondence();
                                        if(caller) {
                                            grid = caller.Ext.getCmp("correspondenceGrid");
                                        }
                                    }
                                }
                                if (null != grid) {
                                    grid.loadCorrespondences();
                                }
                            } catch(e)
                            {

                            }
                        } else {
                            alert(json.response.message);
                        }
                        unblockUI(mode);
                    },
                    failure: function (response, opts)
                    {
                        if(response.timedout) {
                            afterSend("Time out error. Correspondence will be reload.");
                            try {
                                var grid = Ext.getCmp("correspondenceGrid");
                                if (null != grid) {
                                    grid.loadCorrespondences();
                                }
                            } catch(e)
                            {

                            }
                        } else {
                            alert("Exception: " + response.statusText);
                        }
                        unblockUI(mode);
                    }
                });
            }
        }
    });
    toptoolbarMenuItems.push({
        id:'separatorSendButton',
        scope: this,
        xtype: 'tbseparator'
    });
    toptoolbarMenuItems.push({
        id:'btnAttachments',
        scope: this,
        text:resObject.attachmentsMenuLabel,
        iconCls:'attachment',
        handler: onAttachmentClick
    });

    winReplyAllForm.addDocked(
        {
            xtype: 'toolbar', dock: 'top', layout: {pack: 'left'},
            id: 'toptoolbarMenu',
            items: toptoolbarMenuItems
        }
    );

    if ("undefined" != typeof(mode) && ("onNew" == mode)) {
        deleteAttachments("ALL");
        winReplyAllForm.modal = false;
        winReplyAllForm.animateTarget = null;
        winReplyAllForm.shadow = false;
        winReplyAllForm.renderTo = 'mailBodyFrame';
        winReplyAllForm.width = Ext.get("mailBodyFrame").getWidth() + 10;
        winReplyAllForm.height = Ext.get("mailBodyFrame").getHeight() + 10;
        winReplyAllForm.x = Ext.get("mailBodyFrame").getX();
        winReplyAllForm.y = Ext.get("mailBodyFrame").getY();
        winReplyAllForm.maximized = false;

        Ext.getCmp('sendButton').hide();
        Ext.getCmp('separatorSendButton').hide();
    } else {
        deleteAttachments("ALL");
        setTimeout(function() {
            Ext.getCmp('toptoolbarMenu').add( '-', {id:'btnTemplate',  text: resObject.templateMenuText,  iconCls:'template',  handler: onTemplateClick} );
        }, 100);
    }

    winReplyAllForm.show();
    $("<div id='attachmentDisplayContainer' style='padding:4px;max-height:48px;overflow:auto;'></div>").insertAfter("input[name='subject']");
    $("<span id='fromName_err' class='error' style='position:relative;top:-3px' ></span>").insertAfter("input[name='from']");
    $("<span id='toName_err' class='error' style='position:relative;top:-3px' ></span>").insertAfter("input[name='toNameAuto']");
    $("<span id='ccName_err' class='error' style='position:relative;top:-3px' ></span>").insertAfter("input[name='ccNameAuto']");
    initializeSuggestUserComponent("toId","toName", emailReplyToId, emailReplyToName, toNameObj);
    initializeSuggestUserComponent("ccId","ccName", emailCCId, emailCCName, ccNameObj);

    if ("undefined" != typeof(mode) && ("onNew" == mode)) {
        setTimeout(function(){
            Ext.select("#winReplyAllForm .x-window-body .x-window-item .x-panel-body .x-form-item").setWidth(winReplyAllForm.width - 34);
            Ext.select("#winReplyAllForm .x-window-body .x-window-item .x-panel-body").setHeight(winReplyAllForm.height - 62);
            var winReplyAllFormBodyWidth = Ext.get("winReplyAllForm-body").getWidth();
            if(Ext.firefoxVersion > 0) {
                winReplyAllFormBodyWidth = winReplyAllFormBodyWidth -4;
                Ext.select("#winReplyAllForm .x-form-text").setStyle('width', '99%');
            }
            Ext.select("#toptoolbarMenu").setWidth(winReplyAllFormBodyWidth);
        }, 500);
    }

    if(Ext.firefoxVersion > 0) {
        var comboFromAddressWidth = Ext.get("comboFromAddress-bodyEl").getWidth() - 24;
        Ext.select("#comboFromAddress-inputEl").setWidth(comboFromAddressWidth);
    }

    $("#topToolbarBack").removeClass("x-toolbar").removeClass("x-toolbar-default").removeClass("x-toolbar-docked-top").removeClass("x-toolbar-default-docked-top");
    if ("undefined" != typeof(mode) && ("onForward" == mode)) {
        if ("undefined" != typeof(imageLinks)) { // display the attachments for forwarding
            if(0 < imageLinks.length) {
                var attachArray =  new Array();
                for (var i = 0; i < imageLinks.length; i++) {
                    var fileName = $(imageLinks[i]).attr("title");
                    fileName = fileName.replace(new RegExp('[' + String.fromCharCode(0x1a) + ']', 'g'), ''); // clear unicode '0x1a' in fileName
                    var procID = $(imageLinks[i]).attr("procid");
                    var mapID = $(imageLinks[i]).attr("mapid");
                    attachArray[i] = {filename: fileName, procid: procID, mapid: mapID};
                    addAttachment(fileName);
                }
                setTimeout(function(){
                    Ext.Ajax.request ( {
                        url: basePath + '/common/attach/forwardattachment.jsp',
                        timeout: 120000, // 120 seconds
                        method: 'POST',
                        params:
                        {
                            attachData: Ext.encode(attachArray)
                        },
                        success: function (response, opts)
                        {
                            var json = JSON.parse(response.responseText);
                            if(json.response.success) {
                                //
                            } else {
                                alert(json.response.message);
                            }
                        },
                        failure: function (response, opts)
                        {
                            if(response.timedout) {
                                afterSend("Time out error.");
                            } else {
                                alert("Exception: " + response.statusText);
                            }
                        }
                    });
                }, 500);
            }
        }
    }
}

function initializeSuggestUserComponent(inputId, inputName, idValues, nameValues, suggestObj) {
    initializeSuggestUser(inputName, inputName + "Auto",contextPath + "/common/getuserlist.jsp",
        function (data, num) {
            if(("U" == data.type )|| ("G" == data.type )) {
                if (data.email && data.email.length > 0) {
                    data.id = data.email;
                    data.type = "E";
                } else {
                    var msg = MSG_NOEMAILADDRESS.replace(/\{0\}/g, data.name);
                    alert(msg);
                    return;
                }
            }
            return onSuggestUserAdded(data, inputId, inputName);
        },
        function (data){
            onSuggestUserRemoved(data, inputId, inputName);
        },
        function (data, elem) {
            var new_elem = elem.html(generateSuggestUserHtml(data, imageBasePath));
            return new_elem;
        },
        true,"&return=array&type=B&isoe=true&hierarchyid=" + hierarchyid + "&usesaas=" + useSaas + "&allowDirectInputEmail=true&maxResultCount=10&mode=suggest",
        function (elem, data) {
            $(elem).attr("title",data.id);
            try {$("#" + inputName + "Auto").parent().focus();} catch(e) {}
            try {$("#" + inputName + "Auto").focus();} catch(e) {}
            return elem;
        }
    );

    suggestObj = new SuggestUser(inputName,inputId, true);
    if (idValues.length > 0) {
        suggestObj.addSelectedUserMultiple(idValues, nameValues);
    }
    if(Ext.firefoxVersion > 0) {
        Ext.get("as-selections-" + inputName + "Auto").set({style:"width:99%;max-height:65px;"});
    } else {
        Ext.get("as-selections-" + inputName + "Auto").set({style:"width:100%;max-height:65px;"});
    }
    Ext.get("as-original-" + inputName + "Auto").set({style:"min-width:140px;"});
}
function afterSend(msg)
{
    if(parent.notify) {
        parent.notify(msg, 2000);
    } else {
        if(window.getWIHCorrespondence) {
            var caller = window.getWIHCorrespondence();
            if(caller && caller.parent.notify) {
                caller.parent.notify(msg, 2000);
            } else {
                alert(msg);
            }
        } else {
            alert(msg);
        }
    }
    if(parent.reloadAttachments) {
        parent.reloadAttachments();
    } else {
        if(window.getWIHCorrespondence) {
            var caller = window.getWIHCorrespondence();
            if(caller && caller.parent.reloadAttachments) {
                caller.parent.reloadAttachments();
            }
        }
    }

    closeReplyAll();

    if (typeof (callbackAfterSendMail) != 'undefined' && callbackAfterSendMail != null){
    	callbackAfterSendMail();
    }
}

function blockUI(mode)
{
    var $blockObj =  $("#winReplyAllForm");
    if ("undefined" != typeof(mode) && ("onNew" == mode)) {
        $blockObj =  $(document.body).add("#winReplyAllForm")
    }

    $blockObj.block({
        message: null,
        css: {
            border: 'none',
            backgroundColor: 'gray',
            opacity: 0.7,
            width: '100%',
            height: '100%'
        }
    });
}

function unblockUI(mode)
{
    var $blockObj =  $("#winReplyAllForm");
    if ("undefined" != typeof(mode) && ("onNew" == mode)) {
        $blockObj =  $(document.body).add("#winReplyAllForm")
    }

    $("div.blockUI").css("cursor","default");
    $blockObj.unblock();
}

function callBackOnTemplateClick(returnParam)
{
	var jsonObj = $.parseJSON(returnParam);
	if(jsonObj) {
		var templateId = jsonObj.ID;
        Ext.Ajax.request ( {
            url: contextPath + '/webdesign/template',
            timeout: 120000, // 120 seconds
            method: 'POST',
			params: {
                method: 'generate',
                id: templateId,
                procId : processId
            },
            success: function (response, opts) {
                var json = JSON.parse(response.responseText);
                if(json.response.success == "Y") {
					var contents = winReplyAllForm.down('[name="msg"]').getValue();
					winReplyAllForm.down('[name="msg"]').setValue(json.response.data + "<br/>" + contents);
                    winReplyAllForm.down('[name="templateId"]').setValue(templateId);
                } else {
                    alert(json.response.message);
                }
            },
            failure: function (response, opts) {
                if(response.timedout) {
                    alert("Time out error.");
                } else {
                    alert("Exception: " + response.statusText);
                }
            }
        });
	}
}
function sendMail()
{
	Ext.getCmp('toptoolbarMenu').getComponent('sendButton').handler.call()
}