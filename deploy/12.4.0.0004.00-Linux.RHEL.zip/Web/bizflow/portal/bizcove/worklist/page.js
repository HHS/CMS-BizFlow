(function($){
    var SERVER_DATE_FORMAT = "yyyy/MM/dd";
    var SERVER_DATETIME_FORMAT = "yyyy/MM/dd HH:mm:ss";
    var ROW_CLASS_NAME = "__rowClassName__";
    var timezoneOffset = (new Date()).getTimezoneOffset()*60000;

    var createPluginData = function(element, bizcoveid, options) {
        var json = "";
        var contextPath = "/bizflow";
        var servletPath = "";
        var serverId = "";
        var config ={contextPath: "/bizflow",
            servletPath: "",
            kendoUserDateFormat : SERVER_DATETIME_FORMAT,
            dateOnlyFormat : "MM/dd/yy",
            themeBasePath : "/bizflow/themes/oceanblue",
            isPreviewMode : false,
            isBizCoveManager : false,
            recentActiveMenu : "refreshBizCove",
            defaultLayout: {}};

        var queryJSON = {};
        var sortJSON = [];
        var filterJSON = [];
        var selectedItems = [];
        var dateFields = [];
        var numFields = [];
        var dateDataFormats = [];
        var grid = null;
        var WORKITEM_STATE = {};
        var serverMode = true;
        var frameHeight = 460;
        var originalData;
        var totalCount;
        var refreshInterval = 0;
        var pageLoaded = false;
        var wndWIH = "";
        var isSorting = false;
        var isFiltering = false;
        var onsearching = false;
        var winMode = "normal";
        var startEventSearchDone = false;
        var reorderable = false;
        var defaultColumns;
        var defaultColumnNameField = "field";
        var groupable = false;
        var navigatable = true;
        var currow;
        var useAccessibility = false;
        if(options.useAccessibility) {
            useAccessibility = options.useAccessibility;
        }
        var callbackFocusEl;
        var workTypeFilterSelect;

        var timeStamp = {
            gridDataSource: 0,
            columnFilterDataSource: [],
            setGridDataSourceTimeStamp: function()
            {
                this.gridDataSource = (new Date()).getTime();
            },
            setTimeStamp: function(field){
                this.columnFilterDataSource[field] = (new Date()).getTime();
            },
            isOutdated: function(field){
                if(this.columnFilterDataSource[field])
                {
                    return (this.gridDataSource == 0 || this.columnFilterDataSource[field] < this.gridDataSource)
                }
                else
                {
                    return true;
                }
            }
        };

        var elem = $(element);
        var me = this;

        function setCallbackFocusEl()
        {
            callbackFocusEl = document.activeElement;
        }
	    function focusCallbackEl()
	    {
		    if(typeof callbackFocusEl && typeof callbackFocusEl.focus === 'function'){
			    callbackFocusEl.focus();
			    callbackFocusEl = undefined;
            };
	    }
	    this.selector = function (idname) {
            return $("div#bf-bizcove"+bizcoveid).find(idname);
        };
        this.setTitle = function (title) {
            me.selector(".title").html(title);
        };
        this.setHeaderIcon = function (icon) {
            if (typeof(icon) != 'undefined' && 0 < icon.length) {
                var src = config.themeBasePath + "/icons/" + icon;
                me.selector(".headerIcon").attr("src", src);
                me.showObject(".workListTitleIcon", true)
            }
            else {
                me.showObject(".workListTitleIcon", false)
            }
        };
        this.showObject = function (obj, show) {
            if(show) {
                me.selector(obj).show();
            }
            else {
                me.selector(obj).hide();
            }
        };
        this.getContextMenuTag = function()
        {
            return me.selector("#bf-bizcove-contextmenu" + bizcoveid);
        };
        this.saveAsExcel = function () {
            me.selector('.grid').getKendoGrid().saveAsExcel();
        };
        this.getHtmlByID = function (id) {
            return me.selector('#'+id).html();
        };
        this.getHtmlByClassName = function (className) {
            return me.selector('.'+className).html();
        };
        this.setHtmlByClassName = function (className, value) {
            me.selector('.' + className).html(value);
        };
        this.setTxtSearchString = function (val) {
            me.selector('.txtSearchString').val(val);
        };
        this.getTxtSearchString = function () {
            return me.selector('.txtSearchString').val();
        };
        this.showClearSearch = function (show) {
            me.showObject(".clearSearch", show)
        };
        this.isVisible = function (className) {
            return me.selector('.'+className).is(':visible');
        };
        this.getRows = function (row) {
            return me.selector(row);
        };
        this.getButton = function (btnId) {
            return me.selector("BUTTON[id='"+btnId+"BTN']");
        };
        this.showActionBox = function (menu, show) {
            me.showObject(".actionBox."+menu, show);
        };
        this.showActionBoxMenu = function (show) {
            me.showObject(".actionBoxMenu", show);
        };
        this.selectorByClassName = function (className) {
            return me.selector('.'+className);
        };
        this.selectorById = function (id) {
            return me.selector('#'+id);
        };
        this.getSelectedItems = function(bizcoveid)
        {
            var result = [];
            var grid = me.selector(".grid").data("kendoGrid");
            for(var idx in selectedItems){
                if(selectedItems[idx]){
                    var row = grid.tbody.find(">tr").eq(idx);
                    if(row)
                    {
                        var item = grid.dataItem(row);
                        if(item != null)
                        {
                            item["svrid"] = serverId;
                            item["rowIndex"] = idx;
                            result.push(item);
                        }
                    }
                }
            }
            return result;
        };
        this.resetSearch = function () {
            me.setTxtSearchString('');
            me.showClearSearch(false);
            queryJSON.qsearch = me.getTxtSearchString();
            me.searchHeader("off");
            //queryJSON.sort = me.getSortString();
            grid.dataSource.read(queryJSON);
            onsearching = false;
        };
        this.searchHeader = function (sw) {
            if(onsearching) {
                return true;
            }
            if(me.isVisible('clearSearch')) {
                return true;
            }

            var opts = grid.getOptions();
            var className = "";

            if("on" == sw) {
                className = "unselectedHeader";
            }
            for(var i=0; i<opts.columns.length; i++) {
                if(!opts.columns[i].searchable) {
                    opts.columns[i].attributes["class"] = className;
                }
            }
            grid.setOptions(opts);
            grid.dataSource.data(originalData);
            me.startEvent();
        };
        this.refreshData = function(){
            grid.dataSource.read(queryJSON);
            selectedItems.length = 0;
        };
        this.refreshGrid = function (fetch) {
            if(fetch) {
                //queryJSON.sort = me.getSortString();
                grid.dataSource.read(queryJSON);
            } else {
                reload();
            }
            selectedItems.length = 0;
        };
        this.getActionById = function (actionid) {
            var result = null;
            $.each(json.actions, function(i, action){
                if(action.actionid == actionid)
                {
                    result = action;
                    return false;
                }
            });
            return result;
        };
        this.getRowStyleByDeadline = function (item) {
            var className = "";
            try {
                if(typeof(item) == 'object') {
                    var state = item["state"];
                    var deadlinedtime = item["deadlinedtime"];
                    if(typeof(state) == 'string' && typeof(deadlinedtime) == 'string' && 8 < deadlinedtime.length) {
                        var deadline = kendo.parseDate(deadlinedtime, SERVER_DATETIME_FORMAT);
                        var today = new Date();
                        var sunday = new Date(today.getFullYear(), today.getMonth(), today.getDate() - today.getDay() + 7);
                        if(state == 'V') {
                            return "overdueItem";
                        }
                        else if(today.getYear() == deadline.getYear() && today.getMonth() == deadline.getMonth() && today.getDate() == deadline.getDate()) {
                            return "dueTodayItem";
                        }
                        else if(deadline.getTime() <= sunday.getTime()) {
                            return "dueThisWeekItem";
                        }
                        else {
                            var tomorrow = new Date();
                            tomorrow.setDate(today.getDate()+1);
                            if(tomorrow.getYear() == deadline.getYear() && tomorrow.getMonth() == deadline.getMonth() && tomorrow.getDate() == deadline.getDate()) {
                                return "dueTomorrowItem";
                            }
                        }
                    }
                }
            }
            catch(e) {
                //
            }
            return className;
        };
        this.getProperty = function (name) {
            return this[name];
        };
        this.onChangeDataSource = function () {
            if(isSorting || isFiltering) return;
            var thisSortJSON = grid.dataSource.sort();
            var thisFilterJSON = grid.dataSource.filter();
            var isTheSameSort = (JSON.stringify(sortJSON) == JSON.stringify(thisSortJSON) ? true : false);
            var isTheSameFilter = (JSON.stringify(filterJSON) == JSON.stringify(thisFilterJSON) ? true : false);
            var gridOptions = grid.getOptions();
            getSortDirection(gridOptions.dataSource.sort, gridOptions.dataSource.group);

            if(!isTheSameSort) {
                isSorting = true;
                queryJSON.sort = thisSortJSON;
                sortJSON = queryJSON.sort;
                isSorting = false;
            }
            if(!isTheSameFilter) {
                isFiltering = true;
                queryJSON.filter = thisFilterJSON;
                filterJSON = queryJSON.filter;
                isFiltering = false;
            }
            timeStamp.setGridDataSourceTimeStamp();
        };
        function getOrderedColumn(userColumns, ColumnsArray, checkField)
        {
            checkField = !checkField ? defaultColumnNameField : checkField;

            for(var toPosition = 0 ; toPosition < userColumns.length ; toPosition++) {
                var fromPosition = ColumnsArray
                                    .map(function(e) {return e[checkField]; })
                                    .indexOf(userColumns[toPosition][checkField]);
                ColumnsArray.splice(toPosition, 0, ColumnsArray.splice(fromPosition, 1)[0]);
            }
        }
        function isOnlyReordered(userColumns, defaultColumns, checkField)
        {
            var result = false;
            checkField = !checkField ? defaultColumnNameField : checkField;

            if (userColumns.length == defaultColumns.length) {
                var sortedUserColumns = sortObjectData(userColumns.slice(0), checkField);
                var sortedDefaultColumns = sortObjectData(defaultColumns.slice(0), checkField);
                result = isModifiedColumn(sortedUserColumns, sortedDefaultColumns, checkField) ? false : true;
            }
            else {
                result = false;
            }
            return result;
        }
        function isModifiedColumn(userColumns, defaultColumns, checkField)
        {
            var isModified = false;
            checkField = !checkField ? defaultColumnNameField : checkField;

            if (userColumns.length == defaultColumns.length) {
                for (var i = 0 ; i < userColumns.length ; i++) {
                    if( userColumns[i][checkField] != defaultColumns[i][checkField]) {
                        isModified = true;
                        break;
                    }
                }
            }
            else {
                isModified = true;
            }
            return isModified;
        }
        function normalizeFilterValue(inputFilters)
        {
            if(inputFilters.filters) {
                for (var i = 0; i<inputFilters.filters.length; i++) {
                    var item = inputFilters.filters[i];
                    if (item.filters) {
                        normalizeFilterValue(item);
                    }
                    else if(isDateField(item.field))
                    {
                        try
                        {
                            item.value = kendo.parseDate(item.value);
                        }
                        catch(e)
                        {}
                    }
                }
            }
        }
        function removeValidFilters(inputFilters)
        {
            if(inputFilters.filters)
            {
                for(var i = inputFilters.filters.length - 1; i >= 0; i--) {
                    var item = inputFilters.filters[i];
                    if(item.filters)
                    {
                        removeValidFilters(item);
                        if(typeof(item.filters) == 'undefined' || item.filters.length == 0)
                        {
                            inputFilters.filters.splice(i,1);
                        }
                    }
                    else
                    {
                        var column = me.getColumnByName(item.field);
                        if(typeof(column) == 'undefined' || !column.filterable) {
                            inputFilters.filters.splice(i,1);
                        }
                    }
                }

                if(inputFilters.filters.length == 0)
                {
                    inputFilters = undefined;
                }
            }
        }
        this.getColumnByName = function(field)
        {
            var ret = undefined;
            $.each(json.columns, function (index, column) {
                if(field == column.field)
                {
                    ret = column;
                    return false;
                }
            });
            return ret;
        };
        function isDateField(field)
        {
            try {
                var c = json.datasource.schema.fields[field];
                return (c.type == "date");
            }
            catch(e)
            {
                return false;
            }
        }
        function removeInvalidColumns (inputColumns) {
            for (var i = inputColumns.length - 1 ; i >= 0 ; i--) {
                var column = me.getColumnByName(inputColumns[i].field);
                if (typeof(column) == 'undefined') {
                    inputColumns.splice(i,1);
                }
            }
            if (inputColumns.length == 0) {
                inputColumns = undefined;
            }
        }
        function getSortDirection(sort, groups) {
            if(sort) {
                $.each(groups, function (index, column) {
                    var found;
                    sort.some(function (obj) {
                        if (obj.field === column.field) {
                            found = obj;
                            return true;
                        }
                    });
                    column.dir = found ? found.dir : column.dir;
                });
            }
        }
        this.loadOptions = function () {
            var newJSON = grid.getOptions();
            defaultColumns = grid.columns;
            //var quickSearch = worklistJSON.layout.quickSearch;
            $('#bf-bizcove' + bizcoveid).find($('.worklistQuickSearch')).hide();
            for (var k = 0; k < newJSON.columns.length; k++) {
                if (newJSON.columns[k].searchable == true) {
                    $('#bf-bizcove' + bizcoveid).find($('.worklistQuickSearch')).show();
                    break;
                }
            }
            try
            {
                //if (quickSearch == false) {
                //    $('#worklistQuickSearch').hide();
                //}
                //for (var i = 0; i < dateFields.length; i++) {
                //    for (var j = 0; j < newJSON.columns.length; j++) {
                //        if (newJSON.columns[j].field == dateFields[i]) {
                //            if("DATE" == dateDataFormats[i].toUpperCase()) {
                //                newJSON.columns[j].format = "{0:" + config.dateOnlyFormat + "}";
                //            } else {
                //                newJSON.columns[j].format = "{0:" + config.kendoUserDateFormat + "}";
                //            }
                //            //if(newJSON.columns[j].template) {
                //            //    var originalTemplate = newJSON.columns[j].template;
                //            //    var newFormat = "("+newJSON.columns[j].field+" == null) ? '' : kendo.format('"+newJSON.columns[j].format+"', "+newJSON.columns[j].field+")";
                //            //    newJSON.columns[j].template = originalTemplate.replace(newJSON.columns[j].field, newFormat);
                //            //}
                //        }
                //    }
                //}
                //for (var i = 0; i < numFields.length; i++) {
                //    for (var j = 0; j < newJSON.columns.length; j++) {
                //        if (newJSON.columns[j].field == numFields[i]) {
                //            if(newJSON.columns[j].template) {
                //                var originalTemplate = newJSON.columns[j].template;
                //                var newFormat = newJSON.columns[j].field + " == null ? '' : (isNaN(" + newJSON.columns[j].field + ") ? '' : " + newJSON.columns[j].field + ")";
                //                newJSON.columns[j].template = originalTemplate.replace(newJSON.columns[j].field, newFormat);
                //            }
                //        }
                //    }
                //}

                if(!config.isPreviewMode) {
                    //config.defaultLayout = {"sort":[{"field":"procname","dir":"asc"}],"groups":[{"field":"creationdtime","dir":"asc","aggregates":[]}],"filters":null}
                    var oldLayout = config.defaultLayout;

                    if (typeof(oldLayout) == 'object') {
                        var newSort = newJSON.dataSource.sort;
                        var oldSort = oldLayout.sort;
                        if (oldSort && oldSort != newSort) {
                            removeInvalidColumns (oldSort);
                            newJSON.dataSource.sort = oldSort;
                            sortJSON = newJSON.dataSource.sort;
                        }

                        if (groupable) {
                            var oldGroups = oldLayout.groups;
                            if (oldGroups && oldGroups.length != 0) {
                                var newGroups = newJSON.dataSource.group;
                                if (oldGroups != newGroups) {
                                    removeInvalidColumns (oldGroups);
                                    getSortDirection(oldSort, oldGroups);
                                    newJSON.dataSource.group = oldGroups;
                                }
                            }
                        }
                        var oldFilters = oldLayout.filters;
                        if(oldFilters) {
                            removeValidFilters(oldFilters);
                            if(oldFilters) {
                                normalizeFilterValue(oldFilters);
                                var newFilters = newJSON.dataSource.filter;
                                if (oldFilters && oldFilters != newFilters) {
                                    newJSON.dataSource.filter = oldFilters;
                                    filterJSON = newJSON.dataSource.filter;
                                }
                            }
                        }
                        if (reorderable) {
                            var userColumnsName = oldLayout.columns;
                            if (userColumnsName) {
                                if (userColumnsName.length == defaultColumns.length) {
                                    var userColumns = new Array();
                                    for (var i = 0 ; i < userColumnsName.length ; i++) {
                                        var newObject = {};
                                        newObject.field = userColumnsName[i];
                                        userColumns.push(newObject);
                                    }
                                    if (isModifiedColumn(userColumns, defaultColumns, defaultColumnNameField)) {
                                        if (isOnlyReordered(userColumns, defaultColumns)) {
                                            // use reordered columns
                                            getOrderedColumn(userColumns, newJSON.columns, defaultColumnNameField);
                                        }
                                        else {
                                            // remove user columns at ini file.(modified by admin)
                                            me.saveOptions();
                                        }
                                    }
                                    else {
                                        // remove user columns at ini file.(same with default)
                                        me.saveOptions();
                                    }
                                }
                                else {
                                    // remove user columns at ini file.(modified by admin)
                                    me.saveOptions();
                                }
                            }
                        }
                        else {
                            // TODO : required decision : delete or keep reordered column when reorderable is disabled.
                            // me.saveOptions();
                        }
                    }
                }
                grid.setOptions(newJSON);
            }
            catch(e)
            {
                notifyInternalServerError(e);
            }
            finally {
                queryJSON.sort = sortJSON;
                queryJSON.filter = filterJSON;
                grid.dataSource.read(queryJSON);
                pageLoaded = true;
            }
        };
        this.onSelect = function () {
            var selectedRows = this.select();
            selectedItems.length = 0;
            selectedRows.each(function(index, row) {
                //var selectedItem = grid.dataItem(row);
                var rowIdx = $(this).closest("tr").index();
                selectedItems[rowIdx] = true;
            });
        };
        this.getGridComponent = function() {
            return grid;
        };
        this.getSortString = function () {
            var sortString = "";
            for(var i=0 in sortJSON) {
                if(i>0) sortString += ",";
                sortString += sortJSON[i].field+" "+sortJSON[i].dir;
            }
            return sortString;
        };
        // This method fired when the widget is bound to data from its data source.
        this.onBizCoveDataBound = function (arg) {
            try {
                var rows = arg.sender.tbody.children();
                for(var i=0; i<rows.length; i++)
                {
                    var row = me.getRows(rows[i]);
                    var item = arg.sender.dataItem(row);
                    var className = item.get(ROW_CLASS_NAME);
                    if(typeof(className) != 'undefined' && 0<className.length)
                    {
                        row.addClass(className);
                    }
                    row.addClass('itemRow');
                }

				adjustBizCoveFrameSize();
            }
            catch(e) {
            }

	        if(useAccessibility) {
                setTimeout(function() {
                    var link$ = grid.thead.find("tr th.k-filterable a.k-link");
                    if(link$.length > 0) {
                        link$.each(function() { // swap a.k-link and a.k-grid-filter
                            $(this).find(".k-i-sort-asc-sm").attr("title", "in ascending order");
                            $(this).find(".k-i-sort-desc-sm").attr("title", "in descending order");
                            $(this).attr("style", "position: relative;float: left;").prependTo($(this).parent());
                        });
                    }
                    grid.thead.find("tr th.k-header a").removeAttr("tabindex");
                    grid.pager.element.find("a").not(".k-state-disabled").removeAttr("tabindex");
                    grid.content.find("table").attr("tabindex", "-1");
                    grid.content.find("table").removeAttr("role"); // Jaws should announce the focused button not all buttons
                    grid.thead.parent("table").removeAttr("role"); // Jaws should announce the focused button not all buttons
                    grid.thead.parent("table").attr("role", "application");

                    grid.thead.find("tr th.k-header a").off("keydown");
                    grid.thead.find("tr th.k-header a").on( "keydown", function(e) {
                        var keyCode = e.keyCode || e.which;
                        if(keyCode == 13) {
                            if($(e.target).hasClass("k-link")) {
                                e.stopImmediatePropagation();
                                $(e.target).click();
                                setTimeout(function() {
                                    $(e.target).focus();
                                }, 1000);
                                return false;
                            } else if($(e.target).hasClass("k-grid-filter")) {
                                e.stopImmediatePropagation();
                                $(e.target).find(".k-i-filter").click();
                                return false;
                            }
                        }
                    });

                }, 100);
	        }
        };
        this.saveOptions = function () {
            var newOptions = {};
            var newSort = grid.dataSource.sort();
            var newGroups = grid.dataSource.group();
            var newFilters = grid.dataSource.filter();
            var newColumns = grid.columns;

            newOptions.sort = newSort;
            newOptions.groups = newGroups;
            newOptions.filters = newFilters;

            if (reorderable && isModifiedColumn(newColumns, defaultColumns, defaultColumnNameField)) {
                var columnFields = new Array();
                for(var i=0; i<newColumns.length; i++) {
                    columnFields.push(newColumns[i].field);
                }
                newOptions.columns = columnFields;
            }

            queryJSON.sort = newSort;
            $.ajax({
                type: "POST"
                ,url: "setsessionutil.jsp"
                ,data: {"section":"BIZCOVE", "id":"LAYOUT_"+bizcoveid, "value":kendo.stringify(newOptions)}
                ,dataType: "text"
                ,cache: false
                ,async: true
            }).done(function() {
            }).always(function() {
            }).fail(function(jqXHR, textStatus, errorThrown) {
                notifyInternalServerError(textStatus);
            });
        };
        this.onSearch = function () {
            onsearching = true;
            var q = me.getTxtSearchString().trim();
            if (!q) {
                me.resetSearch();
                return;
            }
            if(serverMode) {
                queryJSON.qsearch = q;
            	grid.dataSource.query({page:1, pageSize:grid.dataSource.pageSize()});
            	grid.dataSource.read(queryJSON);
            }
            else {
                var searchables = new Array();
                var opts = grid.getOptions();
                for(var i=0; i<opts.columns.length; i++) {
                    if( opts.columns[i].searchable ) {
                        searchables.push(opts.columns[i].field);
                    }
                }
                var newJsonData = [];
                var re = new RegExp(q, 'g');
                $.each(originalData, function (index, item) {
                    for (var i = 0; i < searchables.length; i++) {
                        try {
                            var found = item[searchables[i]].search(/re/i);
                            if (found) {
                                newJsonData.push(item);
                            }
                        } catch (e) {
                        }
                    }
                });
                grid.dataSource.data(newJsonData);
            }
            me.showClearSearch(true);
            onsearching = false;
        };
        this.rowSelectByUID = function (uid) {
            var tr = grid.tbody.find("tr[data-uid='"+uid+"']");
            this.rowSelect(tr);
        };
        this.rowSelectByEl = function (el) {
            var tr = $(el.closest("tr"));
            this.rowSelect(tr);
        };
        this.rowSelect = function (tr) {
            if ($(tr).find(".check_row")) {
                var cb = $(tr).find(".check_row");
            }
            if(cb && cb.length > 0) {
                if(!$(cb).prop("checked")) {
                    cb.trigger("click");
                }
            } else { // select ROW
                grid.select(tr);
            }
        };
        this.rowUnSelect = function (tr) {
            if ($(tr).find(".check_row")) {
                var cb = $(tr).find(".check_row");
            }
            if(cb && cb.length > 0) {
                if($(cb).prop("checked")) {
                    cb.trigger("click");
                }
            } else { // select ROW
                grid.select(tr);
            }
        };
        this.allRowUnselect = function () {
            if(grid.options.selectable) {
                grid.clearSelection();
            } else {
                var gridRows = grid.tbody.find("tr");
                gridRows.each(function (e) {
                    var cb = $(this).find(".check_row")
                    if ($(cb).prop("checked")) {
                        cb.trigger("click");
                    }
                });
            }
        };
        this.clickButtonId = function (event, btnId) {
            if (config.isPreviewMode) {
                return;
            }
            var btn = me.getButton(btnId);
            if(btn.data()) {
                btn.trigger("click");
            }
            else {
                var action = me.getActionById(btnId);
                try {
                    if(action) {
                        if(typeof(window[action.handler]) == 'function')
                        {
                            window[action.handler]({"bizcoveid":bizcoveid, "event":event});
                        }
                        else {
                            notify(INVALID_FUNCTION_NAME, "warn");
                        }
                    }
                    else {
                        notify(ACTION_ID_IS_NOT_DEFINED, "warn");
                    }
                }
                catch (e) {
                    notify(NO_FUNCTION_NAME, "warn");
                }
            }
        };
        this.startEventSearch = function () {
            if (!startEventSearchDone) {
                var obj = me.selector("input.txtSearchString");
                if (obj && obj.prop("tagName") == "INPUT") {
                    me.selector("input.txtSearchString").keydown(function (event) {
                        if (event.which == 13) {
                            event.preventDefault();
                            if(!onsearching) me.onSearch();
                        }
                    });
                    me.selector("a.k-icon.k-i-search").mousedown(function () {
                        if(!onsearching) me.onSearch();
                    });
                    startEventSearchDone = true;
                } else {
                    setTimeout(function () {
                        me.startEventSearch();
                    }, 100);
                }
            }
        };
        // This method fired on data loaded from server. This method can be overwritten by configuration option.
        this.recordPreprocessing = function (idx, item) {
            item[ROW_CLASS_NAME] = me.getRowStyleByDeadline(item);

            if(item.state) {
                item.state = WORKITEM_STATE[item.state];
            }
            if(item.passwdflag) {
                item.passwdflag = PASSWORDFLAG[item.passwdflag];
            }
            if(item.urgent) {
                item.urgent = PROCESS_URGENCY[item.urgent];
            }
            if(item.witemtype) {
                item.witemtype = WORKITEM_TYPE[item.witemtype];
            }
            if(item.prtcptype) {
                item.prtcptype = PARTICIPANTS_TYPE[item.prtcptype];
            }
            if(item.isoe_status) {
                item.isoe_status = TASKSTATE[item.isoe_status];
            }
            if(item.lastcorrespondence) {
                item.lastcorrespondence = CORRESPONSE_STATE[item.lastcorrespondence];
            }

            for(var i=0; i<dateFields.length; i++) {
                item[dateFields[i]] = me.gmtToLocal(item[dateFields[i]], "DATE" == dateDataFormats[i].toUpperCase());
            }
        };
        this.filterPreprocessing = function (oldFilterJSON) {
            if(!oldFilterJSON) {
                return oldFilterJSON;
            }
            else {
                if(oldFilterJSON.filters) {
                    $.each(oldFilterJSON.filters, function(i, v) {
                        switch(v.field) {
                            case 'state':
                                for (var key in WORKITEM_STATE) {
                                    if(v.value == WORKITEM_STATE[key]) {
                                        v.value = key;
                                        break;
                                    }
                                }
                                break;
                            case 'passwdflag':
                                for (var key in PASSWORDFLAG) {
                                    if(v.value == PASSWORDFLAG[key]) {
                                        v.value = key;
                                        break;
                                    }
                                }
                                break;
                            case 'urgent':
                                for (var key in PROCESS_URGENCY) {
                                    if(v.value == PROCESS_URGENCY[key]) {
                                        v.value = key;
                                        break;
                                    }
                                }
                                break;
                            case 'witemtype':
                                for (var key in WORKITEM_TYPE) {
                                    if(v.value == WORKITEM_TYPE[key]) {
                                        v.value = key;
                                        break;
                                    }
                                }
                                break;
                                break;
                            case 'prtcptype':
                                for (var key in PARTICIPANTS_TYPE) {
                                    if(v.value == PARTICIPANTS_TYPE[key]) {
                                        v.value = key;
                                        break;
                                    }
                                }
                                break;
                            case 'isoe_status':
                                for (var key in TASKSTATE) {
                                    if(v.value == TASKSTATE[key]) {
                                        v.value = key;
                                        break;
                                    }
                                }
                                break;
                            case 'lastcorrespondence':
                                for (var key in CORRESPONSE_STATE) {
                                    if(v.value == CORRESPONSE_STATE[key]) {
                                        v.value = key;
                                        break;
                                    }
                                }
                                break;
                            default: break;
                        }
                    });
                }
            }
            return oldFilterJSON;
        };
        this.startInterval = function () {
            if(refreshInterval > 0) {
                window.setTimeout(function(){me.refreshGrid(true); me.startInterval();}, refreshInterval*60000);
            }
        };
        this.startEvent = function () {
            //grid.table.on("click", ".check_row" , selectRow($(event.target)));
            me.selector("TABLE").on("click", function( event ) {
                var el = $(event.target);
                var classType = el.attr("class");
                if(classType == 'check_row') {
                    var checked = el.context.checked,
                        row = $(el).closest("tr"),
                        rowIdx = $("div#bf-bizcove"+bizcoveid).find("tr", grid.tbody).index(row);
                    selectedItems[rowIdx-1] = checked;
                    if (checked) {
                        $(el.context).closest('tr').addClass('gridRowSelected');
                    }
                    else {
                        $(el.context).closest('tr').removeClass('gridRowSelected');
                    }
                }
                else if (classType == 'linkedAction') {
                    // skip : onClick is called by template
                }
                else if (classType && classType.indexOf('k-button') == 0) {
                    var x = el.attr("class").split("k-grid-");//class: k-button k-button-icontext btn-primary k-grid-open
                    var name = x[1];
                    if(name) {
                        me.allRowUnselect();
                        me.rowSelectByEl(el);
                        me.clickButtonId(event, name);
                    }
                }
                return false;
            });
            me.startEventSearch();
        };
        this.setRecentActionButton = function (menu) {
            if(typeof(menu) == 'undefined') {
                menu = "refreshBizCove";
            }
            else if("modifyBizCove" == menu) {
                if(!config.isBizCoveManager) {
                    menu = "refreshBizCove";
                }
            }

            var toolContextMenu = $("#toolContextMenu"+bizcoveid);
            var title = "";
            if(isTopMenuBizCove()) {
                toolContextMenu.find(".maximizeBizCove").hide();
                toolContextMenu.find(".restoreBizCove").hide();
                if(("maximizeBizCove" == menu) || (("restoreBizCove" == menu))) {
                    menu = "refreshBizCove";
                }
            }
            else {
                if(("maximizeBizCove" == menu) || (("restoreBizCove" == menu))) {
                    toolContextMenu.find(".maximizeBizCove").hide();
                    toolContextMenu.find(".restoreBizCove").hide();

                    menu = "restoreBizCove" == menu ? "maximizeBizCove" : "restoreBizCove";
                    toolContextMenu.find("."+menu).show();
                }
                else {
                    if(winMode == "maximize") {
                        toolContextMenu.find(".maximizeBizCove").hide();
                        toolContextMenu.find(".restoreBizCove").show();
                    }
                }
            }
            title = toolContextMenu.find("."+menu).attr("title");
            me.selector(".recentActionButton").attr("title", title);
            var className = toolContextMenu.find(".actionBox."+menu+" i").first().attr("class");
            me.selector(".recentActionButton i").removeClass().addClass(className);

            me.selector(".recentActionButton").unbind("click");
            me.selector(".recentActionButton").click(function(){
                _toolAction(bizcoveid, menu);
            });
        };
        this.load = function() {
            $.ajax({
                type: "GET"
                ,url: contextPath + "/portal/bizcove/getbizcoveproperties.jsp"
                ,data: {"type":"5", "bizcoveid":bizcoveid, "resbag":"no" }
                ,dataType: "json"
                ,cache: false
                ,async: true
            }).done(function(resultObj) {
                if(resultObj.success) {
                    me.initialization(resultObj.data, options);
                    me.showGrid();
                    me.startEvent();
                    me.startInterval();
                    me.setRecentActionButton(config.recentActiveMenu);
                }
                else {
                    if(resultObj.message && 0<resultObj.message.length) {
                        notify(resultObj.message, "error");
                    }
                    else {
                        notifyInternalServerError();
                    }
                }
            }).always(function() {
            }).fail(function(jqXHR, textStatus, errorThrown) {
                notifyInternalServerError();
            });
        };
        this.displayRenderer = {
            bfIndicatorRenderer: function(dataItem, column)
            {
                return "<input class='check_row' type='checkbox' data-uid='"+ dataItem.uid+"' />";
            },
            bfLinkedActionRenderer: function(dataItem, column)
            {
                var val = dataItem[column.field];

                if(column.renderer)
                {
                    try
                    {
                        if(typeof(me.displayRenderer[column.renderer]) == 'function')
                        {
                            val = me.displayRenderer[column.renderer](dataItem, column);
                        }
                        else if(typeof(window[column.renderer]) == 'function')
                        {
                            val = window[column.renderer](dataItem, column);
                        }
                    }
                    catch(e)
                    {
                        consoleError(e);
                        val = dataItem[column.field];
                    }
                }
                if(val == null || val == 'undefined' || val.length == 0)
                {
                    return '';
                }
                else
                {
                    val = (typeof(val) == 'string') ? kendo.htmlEncode(val) : val;
                    return "<a href='#' class='linkedAction' onclick=\"linkedAction('"+bizcoveid+"', this,'"+ dataItem.uid +"','"+column.linkedAction+"');return false;\">"+val+"</a>";
                }
            },
            bfDateAndTimeRenderer: function(dataItem, column)
            {
                var val = dataItem[column.field];
                if(typeof(val) == 'undefined' || val == null)
                {
                    return "";
                }

                if(typeof(val.getTime) == 'function')
                {
                    return kendo.toString(val, config.kendoUserDateFormat);
                }
                else
                {
                    return val;
                }
            },
            bfDateRenderer: function(dataItem, column)
            {
                var val = dataItem[column.field];
                if(typeof(val) == 'undefined' || val == null)
                {
                    return "";
                }

                if(typeof(val.getTime) == 'function')
                {
                    return kendo.toString(val, config.dateOnlyFormat);
                }
                else
                {
                    return val;
                }
            }
        };
        this.initialization = function (properties, opts) {
            json = properties;
            config = $.extend(config, opts || {});
            contextPath =opts.contextPath;
            servletPath =opts.servletPath;
            serverId = opts.serverId;
            winMode = opts.winMode;
            reorderable = json.layout.reorderable;
            if(!useAccessibility) {
                groupable = json.layout.groupable;
                navigatable = json.layout.navigatable;
            }

            if(json.user)
            {
                if(json.user.recentActiveMenu.toUpperCase() === "refreshBizCove".toUpperCase()) {
                    json.user.recentActiveMenu = "refreshBizCove";
                }
                config.kendoUserDateFormat = json.user.userDateFormat;
                try {
                    config.defaultLayout = JSON.parse(json.user.defaultLayout);
                } catch(e) {
                    config.defaultLayout = {};
                }
                config.dateOnlyFormat = json.user.dateOnlyFormat;
                config.isBizCoveManager = json.user.isBizCoveManager;
                config.recentActiveMenu = json.user.recentActiveMenu;
            }

            queryJSON = {
                "bizcoveid": bizcoveid,
                "wcat": "",
                "page": 1,
                "pageSize": 10,
                "sort": [],
                "filter": [],
                "qsearch": ""
            };

            WORKITEM_STATE = $.extend({}, opts.WORKITEM_STATE || {});
            selectedItems = [];
            dateFields = [];
            numFields = [];
            dateDataFormats = [];

            //var bizcovename = json.name;
            me.setTitle(json.name);
            refreshInterval = json.refreshInterval;
            me.setHeaderIcon(json.icon);

            //workTypeFilterOptions
            var organizationUnitWork = json.scope["type"]["organizationUnitWork"];
            var tasksSent = json.scope["type"]["tasksSent"];
            var delegatedWork = json.scope["type"]["delegatedWork"];
            var groupWork = json.scope["type"]["groupWork"];
            var myWork = json.scope["type"]["myWork"];
            var recallableWork = json.scope["type"]["recallableWork"];
            if(organizationUnitWork || tasksSent || delegatedWork || groupWork || myWork || recallableWork ) {
                var workTypeData = [{text: WORKITEM_TYPE["all"], value : ""}];
                if(myWork) workTypeData.push( {text: WORKITEM_TYPE["U"], value : "U"} );
                if(delegatedWork) workTypeData.push( {text: WORKITEM_TYPE["S"], value : "S"} );
                if(groupWork) workTypeData.push( {text: WORKITEM_TYPE["G"], value : "G"} );
                if(organizationUnitWork) workTypeData.push( {text: WORKITEM_TYPE["D"], value : "D"} );
                if(recallableWork) workTypeData.push( {text: WORKITEM_TYPE["C"], value : "C"} );
                if(tasksSent) workTypeData.push( {text: WORKITEM_TYPE["T"], value : "T"} );

                workTypeFilterSelect = me.selectorByClassName("workTypeFilterSelect").kendoDropDownList({
                    dataTextField: "text",
                    dataValueField: "value",
                    dataSource: workTypeData,
                    index: 0,
                    change: function(e) {
                        queryJSON.wcat = this.value();
                        grid.dataSource.read(queryJSON);
                    }
                }).data("kendoDropDownList");

                if(useAccessibility) {
                    // Jaws alt+down arrow key issue with listbox
                    if($("#dummyWorkTypeFilterSelect").length > 0) {
                        $("#dummyWorkTypeFilterSelect").on("focusin", function(e) {
                            if($(e.relatedTarget).hasClass("workTypeFilterSelect")) {
                                return false;
                            }
                            setTimeout(function () {
                                $(".workTypeFilterSelect").focus();
                            }, 100);
                            return false;
                        });
                    }
                }
                $(".workTypeFilterOptions").show();
            }

            // create tool menu
            me.createToolActionMenu();
            $.each(json.external.js, function (index, value) {
                var val = value.trim();
                if (val) {
                    var script = document.createElement("script");
                    script.type = "text/javascript";
                    script.src = val;
                    $("head").append(script);
                }
            });
            $.each(json.external.css, function(index, value){
                var val = value.trim();
                if(val) {
                    var link	= document.createElement("link");
                    link.rel	= "stylesheet";
                    link.type	= "text/css";
                    link.href	= val;
                    $("head").append(link);
                }
            });
            var actionBtnArea = me.selectorByClassName('actionBtnArea');
            $.each(json.actions, function(i, v) {
                if(v.isToolbarItem) {
                    var actionid = v.actionid;
                    var type = v.type;
                    var resourceid = v.resourceid;
                    var title = v.title;
                    var useResourceBag = v.useResourceBag;
                    var icon = v.icon;
                    if(icon == "") {
                        icon = "blankicon.gif";
                    }
                    var cls = v.cls;
                    var handler = v.handler;
                    var btnId = actionid+"BTN"+bizcoveid;
                    if(resourceid instanceof Object) {
                        resourceid = "NULL";
                    }
                    if(useResourceBag) {
                        title = resourceid;
                    }
                    if(type=="button" || type=="icon") {
                        var actionBtn = $('<button></button>', {
                            "id": btnId,
                            "handler": handler,
                            "title": title,
                            "class": (type == "icon" ? "iconActionBtn" : cls),
                            "text": (type == "button" ? title : ""),
                            "click": (config.isPreviewMode ? "" : function (e) {
                                if(typeof(window[handler]) == 'function')
                                {
                                    window[handler]({"bizcoveid":bizcoveid, "event":e});
                                }
                                else {
                                    notify(INVALID_FUNCTION_NAME, "warn");
                                }
                            })
                        });
                        actionBtn.appendTo(actionBtnArea);
                        if (type == "icon") {
                            $("#" + btnId).kendoButton({imageUrl: config.themeBasePath + "/icons/" + icon});
                        }
                        else {
                            $("#" + btnId).kendoButton();
                        }
                    }
                    else { // link
                        var actionLink = $('<a></a>', {
                            "id": btnId,
                            "title": title,
                            "href": "#",
                            "click": (config.isPreviewMode ? "" : function (e) {
                                        if(typeof(window[handler]) == 'function')
                                        {
                                            window[handler]({"bizcoveid":bizcoveid, "event":e});
                                        }
                                        else {
                                            notify(INVALID_FUNCTION_NAME, "warn");
                                        }
                                    }),
                            "text": title
                        });
                        actionLink.appendTo(actionBtnArea);
                    }
                }
            });
            $.each(json.columns, function(i, column) {
                if(typeof(column.displayTitle) != 'undefined' && !column.displayTitle) {
                    column.title = " ";
                    column.groupable = false;
                }
                if(column.isActionColumn && column.columnActions) {
                    $.each(column.columnActions, function(k, actionid) {
                        var action = me.getActionById(actionid);
                        if(action != null) {
                            if(typeof(column.command) == 'undefined') {
                                column.command = [];
                            }
                            column.command.push({"name": actionid, "className": action.cls, "text": action.title});
                        }
                    });
                }

                if(column.linkedAction)
                {
                    column.template = function (dataItem) {
                        return me.displayRenderer.bfLinkedActionRenderer(dataItem, column);
                    }
                }
                else if(column.renderer)
                {
                    if(typeof(me.displayRenderer[column.renderer]) == 'function')
                    {
                        column.template = function(dataItem) {
                            return me.displayRenderer[column.renderer](dataItem, column);
                        };
                        if (column.renderer === 'bfDateAndTimeRenderer') {
                            column.groupHeaderTemplate = column.title + ": #=  kendo.toString(value, '" + config.kendoUserDateFormat + "') #";
                        }
                        else if (column.renderer === 'bfDateRenderer') {
                            column.groupHeaderTemplate = column.title + ": #=  kendo.toString(value, '" + config.dateOnlyFormat + "') #";
                        }
                    }
                    else if(typeof(window[column.renderer]) == 'function')
                    {
                        column.template = window[column.renderer];
                    }
                    else
                    {
                        notify("Function not found: " + column.renderer, "error");
                    }
                }
            });

            //frameHeight = json.layout.height+10;
            //try {
            //    parent.adjustBizCoveFrameSize("frame"+bizcoveid, "100%", frameHeight, 1, false);
            //} catch(e){}
        };
        this.createToolActionMenu = function()
        {
            me.selector("#toolContextMenu"+bizcoveid).kendoContextMenu({
                target: me.selector(".toolContextMenuTarget"),
                showOn: "click",
                alignToAnchor: true
            });
        };

        this.dataSourceTransportRead =function (options) {
            try
            {
                var sortList = [];
                var gridComp = me.getGridComponent();
                if(typeof(gridComp) != 'undefined' && gridComp.getOptions().groupable)
                {
                    var group = gridComp.dataSource.group();
                    $.each(group, function(index, g){
                        sortList.push({dir: g.dir, field: g.field});
                    });
                }

                var dsSort = gridComp.dataSource.sort();
                if(typeof(dsSort) != 'undefined')
                {
                    sortList = sortList.concat(dsSort);
                }

                queryJSON.sort = sortList;
            }
            catch(e)
            {
            }

            queryJSON.filter = me.filterPreprocessing(options.data.filter);

            try {
                $("tr.gridRowSelected .check_row").each(function () {
                    $(this).trigger("click");
                });
            } catch (e) {
            }

            $.ajax({
                type: "POST"
                , url: contextPath + "/portal/bizcove/worklist/" + json.datasource.url
                , dataType: json.datasource.type
                , data: {"queryJSON": JSON.stringify(queryJSON)}
                , async: false
                , cache: false
                , success: function (result) {
                    if (result.success) {
                        options.success(result);
                    }
                    else {
                        if (result.code == 3103) {
                            top.location.href = "../../../common/gotohome.jsp";
                        }
                    }
                }
            });
        };

        this.showGrid = function () {
            var fieldsData = json.datasource.schema.fields;

            for(var name in fieldsData) {
                var item = fieldsData[name];
                if("DATE"==item.type.toUpperCase()) {
                    dateFields.push(name);
                    dateDataFormats.push(item.format);
                }
                if("NUMBER"==item.type.toUpperCase()) {
                    numFields.push(name);
                }
            }

            var dataSource = new kendo.data.DataSource({
                serverSorting: false,
                serverGrouping: false,
                serverFiltering: true,
                pageSize: (json.layout.pageable ? json.layout.pageSize : Number.MAX_VALUE),
                type: json.datasource.type,
                transport: {
                    read: me.dataSourceTransportRead
                },
                schema: {
                    type: json.datasource.type,
                    parse:function (jsonObject) {
                        originalData = jsonObject.data;
                        totalCount = originalData.length;
                        $.each(originalData, function (idx, item) {
                            try {
                                me.recordPreprocessing(idx, item);
                            }
                            catch(e) {}
                        });
                        return originalData;
                    },
                    model: {
                        id: json.datasource.schema.id,
                        fields: json.datasource.schema.fields
                    }// model
                },// schema
                change: function(e) { // Fired when the data source is populated
                    if(serverMode && pageLoaded) {
                        me.onChangeDataSource();
                    }
                }
            });// datasource

            grid = me.selectorByClassName('grid').kendoGrid({
                
                "filterable": 	json.layout.filterable,
                "reorderable": 	reorderable,
                "sortable": 	json.layout.sortable,
                "pageable": 	json.layout.pageable,
                "resizable": 	json.layout.resizable,
                "selectable": 	json.layout.selectable,
                "navigatable": 	navigatable,
                "groupable": 	groupable,
                excel: {
                    proxyURL:   "excelproxy.jsp",
                    allPages:   true,
                    fileName:   "worklist.xlsx"
                },
                dataSource:     dataSource,
                columns:        json.columns,
                change:         me.onSelect,	// Fired when the user selects a table row or cell in the grid.
                dataBound:      me.onBizCoveDataBound,
                autoBind:       false,
                noRecords:      true,
                filterMenuInit: function(e) {
                    var _this = e;
                    var filterWindow = $(_this.container);
                    var grid = _this.sender;
                    var column = me.getColumnByName(_this.field);
                    var simpleDataType = "string";

                    try {
                        var field = grid.dataSource.options.schema.model.fields[_this.field];
                        simpleDataType = (typeof field != 'undefined') ? field.type : "string";
                    }
                    catch(e) {
                        simpleDataType = "string";
                    }

                    if(column.filterable && column.filterable.simple) {
                        _this.container.find(".k-dropdown").hide();

                        if("date" == simpleDataType) {
                            _this.container.find(".k-widget.k-datepicker.k-header").eq(0).prepend( "<span style='position: absolute;margin-top: 5px;'>"+FROM_DATE+"</span>" );
                            _this.container.find(".k-widget.k-datepicker.k-header").eq(1).prepend( "<span style='position: absolute;margin-top: 5px;'>"+TO_DATE+"</span>" );
                            _this.container.find(".k-picker-wrap.k-state-default").eq(0).addClass("moveDatepicker");
                            _this.container.find(".k-picker-wrap.k-state-default").eq(1).addClass("moveDatepicker");
                            filterWindow.on('click', 'button[type=submit]', function (e) {
                                e.preventDefault();
                                if (!config.isPreviewMode) {
                                    var datePicker = filterWindow.find('input[data-role=datepicker]');
                                    if (datePicker.length > 0) {
                                        e.preventDefault();
                                        var filterType = "range";//filterWindow.find('select[data-role=dropdownlist]').eq(0).val();
                                        var startDate = datePicker.eq(0).data('kendoDatePicker').value();
                                        var endDate = datePicker.eq(1).data('kendoDatePicker').value();
                                        if (!startDate) {
                                            startDate = new Date();
                                        }
                                        startDate.setHours(0, 0, 0, 0);
                                        if (!endDate) {
                                            endDate = new Date();
                                        }
                                        endDate.setHours(23, 59, 59, 999);
                                        if ((endDate - startDate) > 0) {
                                            var dsFilter = getGridDataSourceFilter();
                                            removeFiltersForField(dsFilter, _this.field);
                                            dsFilter.filters.push({logic: "and", filters:[
                                                {field: _this.field, operator: "gte", value: kendo.parseDate(startDate, SERVER_DATETIME_FORMAT)},
                                                {field: _this.field, operator: "lte", value: kendo.parseDate(endDate, SERVER_DATETIME_FORMAT)}
                                            ]});
                                            grid.dataSource.filter(dsFilter);
                                        }
                                        else {
                                            notify(MSG_CMM_INVALID_SEARCH_FROM_DATE, "error");
                                        }
                                    }
                                }
                                filterWindow.data('kendoPopup').close();
                            });// Date, for submit;
                        }
                        else if("number" == simpleDataType) {
                            try{
                                _this.container.find('.k-numeric-wrap.k-state-default').addClass("extendNumberbox");
                                _this.container.find('.k-textbox').addClass("fullWidth");
                                var numericTextBox = $(_this.container.find("input.k-input[data-role='numerictextbox']")[0]).data("kendoNumericTextBox");
                                numericTextBox.options.format = "string";
                            } catch(e) {}

                            filterWindow.on('click', 'button[type=submit]', function (e) {
                                e.preventDefault();
                                if (!config.isPreviewMode) {
                                    var numericTextBox = $(filterWindow.find("input.k-input[data-role='numerictextbox']")[0]).data("kendoNumericTextBox");
                                    var text = numericTextBox.value();
                                    var dsFilter = getGridDataSourceFilter();
                                    removeFiltersForField(dsFilter, _this.field);
                                    dsFilter.filters.push({logic: "and", filters:[{field: _this.field, operator: "eq", value: Number(text)}]});
                                    grid.dataSource.filter(dsFilter);
                                }
                                filterWindow.data('kendoPopup').close();
                            });
                        }
                        else {
                            _this.container.find(".k-textbox").addClass("extendTextbox");
                            var databindValue = _this.container.find(".k-textbox").attr("data-bind"); // Jaws does not announce text box in simple filter popup.
                            if(databindValue) {
                                if(databindValue.startsWith("value:filters")) {
                                    databindValue = databindValue.replace("value:filters", "value: filters");
                                    _this.container.find(".k-textbox").attr("data-bind", databindValue);
                                }
                            }
                            filterWindow.on('click', 'button[type=submit]', function (e) {
                                e.preventDefault();
                                if (!config.isPreviewMode) {
                                    var text = filterWindow.find('.k-textbox').val();
                                    var dsFilter = getGridDataSourceFilter();
                                    removeFiltersForField(dsFilter, _this.field);
                                    dsFilter.filters.push({logic: "and", filters:[{field: _this.field, operator: "contains", value: text}]});
                                    grid.dataSource.filter(dsFilter);
                                }
                                filterWindow.data('kendoPopup').close();
                            });
                        }
                    } else {
                        // tab issue in datatimepicker
                        if(column.filterable && ("datetimepicker" == column.filterable.ui)) {
                            var kSelect$ = _this.container.find(".k-datetimepicker .k-select");
                            if(kSelect$.length > 0) {
                                kSelect$.each(function() {
                                    var kLink$ = $(this).find(".k-link");
                                    if (kLink$.length > 0) {
                                        kLink$.each(function () {
                                            if ($(this).parent("a").length > 0) {
                                                return;
                                            }
                                            var anchor$ = $("<a href='#' role='button'></a>").click(function (e) {
                                                $(e.target).find(".k-link span.k-icon").click();
                                                return false;
                                            });
                                            $(this).parent(".k-select").append(anchor$);
                                            $(this).appendTo(anchor$);
                                        });
                                    }
                                });
                            }
                        }
                    }
                    e.container.data("kendoPopup").bind("open", function() {
	                    setCallbackFocusEl();
                        if(column.filterable && column.filterable.multi) {
                            if(timeStamp.isOutdated(column.field))
                            {
                                me.redrawMultiCheck(column.field);
                            }
                        }
                    }).bind("close", function() {
                        focusCallbackEl();
                    });
                }, // for filterMenuInit
                messages:{
                    noRecords: MSG_BC_NO_RECORD_ON_PAGE
                },
                columnReorder: function(e) {
                    grid.reorderColumn(e.newIndex, grid.columns[e.oldIndex]);
                    me.saveOptions();
                }
            }).data("kendoGrid");


	        me.loadOptions();
            if (json.layout.contextMenu == true) {
                me.contextMenuGenerator();
            }
            grid.dataSource.bind('change',function(){ me.saveOptions(); });
            //selector(bizcoveid,".grid").kendoTooltip({
            //    filter: "td",
            //    position: "right",
            //    show: function(e){
            //        if(this.content.text() != ""){
            //            $('[role="tooltip"]').css("visibility", "visible");
            //        }
            //    },pa
            //    hide: function(){
            //        $('[role="tooltip"]').css("visibility", "hidden");
            //    },
            //    content: function(e){
            //        var element = e.target[0];
            //        if(element.offsetWidth < element.scrollWidth){
            //            return htmlEncode(e.target.text());
            //        }else{
            //            return "";
            //        }
            //    }
            //})
        };
        function adjustBizCoveFrameSize() {
            var listTopElement = me.selectorByClassName('listTop');
            var listTopHeight = listTopElement.innerHeight();

            var gridElement = me.selectorByClassName('grid');
            var nonDataArea = gridElement.children().not(".k-grid-content");
            var nonDataAreaHeight = listTopHeight;

            nonDataArea.each(function(){
                var a = $(this).outerHeight();
                nonDataAreaHeight += $(this).outerHeight();
            });

            var dataArea = gridElement.children(".k-grid-content");
            var dataAreaHeight = 392;
            if (dataArea && dataArea[0] && dataArea[0].firstChild) {
                dataAreaHeight = dataArea[0].firstChild.clientHeight ? Math.max(392, dataArea[0].firstChild.clientHeight) : 392;   // min height of list
                dataAreaHeight += (dataArea[0].firstChild.scrollWidth > dataArea[0].clientWidth) ? 17 : 0;   // height of horizontal scrollbar
                dataArea.height(dataAreaHeight);
            }

            var frameMargin = 3;
            frameHeight = Math.max(520, nonDataAreaHeight + dataAreaHeight);
            try {
                parent.adjustBizCoveFrameSize("frame"+bizcoveid, "100%", frameHeight+frameMargin, 1, false);
            } catch(e){}
        }
        function getGridDataSourceFilter()
        {
            var dsFilter = grid.dataSource.filter();
            if(!dsFilter)
            {
                dsFilter = {logic:"and", filters:[]};
            }
            else
            {
                if(dsFilter.logic == "or")
                {
                    dsFilter = {logic:"and", filters:[dsFilter]};
                }
            }
            return dsFilter;
        }
        function removeFiltersForField(expression, field) {
            if (expression.filters) {
                expression.filters = $.grep(expression.filters, function (filter) {
                    removeFiltersForField(filter, field);
                    if (filter.filters) {
                        return filter.filters.length;
                    } else {
                        return filter.field != field;
                    }
                });
            }
        }
        this.redrawMultiCheck = function (field) {
            var filterMultiCheck = grid.thead.find("[data-field=" + field + "]").data("kendoFilterMultiCheck");
            var jsonData = filterMultiCheck.dataSource.data().toJSON();
            jsonData = removeDupJSONData(jsonData, field);
            if(jsonData != null && jsonData.length > 1) {
                jsonData = sortObjectData(jsonData, field, "asc");
            }
            filterMultiCheck.checkSource.data(jsonData);
            filterMultiCheck.refresh();
            //filterMultiCheck.checkSource.read();
            filterMultiCheck.container.empty();
            filterMultiCheck.createCheckBoxes();

            // Jaws does not announce the last checkbox
            $(filterMultiCheck.form[0]).find(".k-multicheck-wrap [type=checkbox]:last")
                .on("focusin", function(e) {
                    $(filterMultiCheck.form[0]).find(".k-filter-selected-items").attr("aria-hidden","true");
                })
                .on("focusout", function(e) {
                    $(filterMultiCheck.form[0]).find(".k-filter-selected-items").removeAttr("aria-hidden");
                });

			// keep tabbing within filter popup
            var blankAnchor$ = $("<a href='#' aria-hidden='true'></a>");
            blankAnchor$.on("focusin", function(e) {
                $(this).parent().find("input:first").focus();
                return false;
            });
            $(filterMultiCheck.form[0]).append(blankAnchor$);

            timeStamp.setTimeStamp(field);
        };
        // Context Menu
        this.contextMenuGenerator = function (){
            this.getContextMenuTag().kendoContextMenu({
                orientation: 'vertical',
                target: ".listArea",
                filter: ".itemRow",
                animation: {
                    open: { effects: "fadeIn" },
                    duration: 0
                },
                dataSource: me.contextMenuListGenerator(),
                select: function(e) {
                    var fnName = me.selectedMenuHandler(e);
                    if (fnName != "bfConsolidate" && fnName != "bfExcel"
                        && fnName != "bfForward" && fnName != "bfSubmit" && fnName != "bfReject") {
                        me.allRowUnselect();
                    }
                    me.rowSelect(e.target);
                    me.clickButtonId(e.event, fnName);
                    //me.processing(me.selectedMenuHandler(e), e.target.rowIndex);
                }
            });
        };
        this.contextMenuListGenerator = function() {
            var contextMenuArray = [];
            $.each(json.actions, function(i, v) {
                var actionLink = $({
                    "id": v.actionid,
                    "cssClass" : v.cls,
                    "handler": v.handler,
                    "text": v.title
                    //"cssClass": "k-item k-state-default"
                });
                $.merge(contextMenuArray, actionLink);
            });
            return contextMenuArray;
        };
        this.selectedMenuHandler = function(e) {
            var selectedMenu = e.item,
                contextMenuOptions = e.sender.options.dataSource,
                contextMenuList = e.sender.element.context.children;
            for (var i=0; i < contextMenuList.length; i++) {
                if (selectedMenu == contextMenuList[i]) {
                    var actionFn = contextMenuOptions[i].handler;
                    break;
                }
            }
            return actionFn;
        };
        this.toggleActionBoxMenu = function () {
            if(me.isVisible('actionBoxMenu')) {
                me.showActionBoxMenu(false);
                me.getClassByName('tailoredWorkList').unbind("click");
            }
            else {
                me.showActionBoxMenu(true);
                me.getClassByName('tailoredWorkList').bind("click", function(e) {
                    if("menuListIcon" != e.target.id) {
                        me.toggleActionBoxMenu();
                    }
                });
            }
        };
        this.toolAction = function (menu) {
            if(config.isPreviewMode) {
                return false;
            }
            var openURL;
            switch(menu) {
                case 'modifyBizCove':
                    openURL = contextPath + "/portal/bizcove/worklist/createworklist.jsp?bizcoveid="+bizcoveid;
                    openPopup(openURL, LBL_BC_WIZARD, "ModifyBizCove", 980, 590);
                    break;
                case 'configureBizCove':
                    break;
                case 'openPrefWindow':
                    openURL = contextPath + "/preference/preferenceframe.jsp?_t="+(new Date().getTime());
                    openPopup(openURL, TTL_PREFERENCE, "openPrefWindow", 560, 520);
                    break;
                case 'refreshBizCove':
                    me.refreshGrid();
                    break;
                case 'maximizeBizCove':
                    parent.maximizeBizCove(bizcoveid, "", "");
                    break;
                case 'restoreBizCove':
                    parent.restoreBizCove(bizcoveid, "", "");
                    break;
                default :
                    menu = "refreshBizCove";
            }
            var bDone = false;
            $.ajax({
                type: "POST"
                ,url: "setsessionutil.jsp"
                ,data: {"section":"BIZCOVE", "id":"PREFERENCEACTIVEMENU_"+bizcoveid, "value":menu}
                ,dataType: "text"
                ,cache: false
                ,async: false
            }).done(function(data) {
                bDone = true;
            }).always(function() {
            }).fail(function(jqXHR, textStatus, errorThrown) {
                notifyInternalServerError();
            });
            if(bDone) {
                me.setRecentActionButton(menu);
            }
        };
        this.linkedAction = function (e, uid, actionid) {
            try {
                //var grid = me.selector(".grid").data("kendoGrid");
                //if(grid) {
                //    grid.clearSelection();
                //}
                $("tr.gridRowSelected .check_row").each(function() {
                    $(this).trigger("click");
                    //this.checked = false; //deselect all checkboxes
                });
            } catch(e) {
            }

            me.allRowUnselect();
            me.rowSelectByUID(uid);
            me.clickButtonId(e, actionid);
        };
        this.bfOpen = function (param) {
            var items = me.getSelectedItems();
            if(!selectedItemValidation(items, "onlyOne"))
            {
                return false;
            }
            var isBizflow = (servletPath.indexOf("/portal/startpage")== -1) ? "n" : "y";
            var wi = items[0];
            var openURL = contextPath + "/work/wih.jsp";
            openURL += "?sid="+wi.svrid;
            openURL += "&pid="+wi.procid;
            openURL += "&seq="+wi.witemseq;
            openURL += "&asq="+wi.actseq;
            openURL += "&pro="+wi.priority;
            openURL += "&rid="+wi.respseq;
            openURL += "&openpage=page";
            openURL += "&wihinfo=";
            openURL += "&bizcovecall=y";
            openURL += "&currow="+wi.rowIndex;
            openURL += "&isbizflow="+isBizflow;
            openURL += "&bizcoveid="+bizcoveid;
            var windowTitle = "Activity - "+wi.actname + " in " + wi.procname;
            wndWIH = openWIHPopup(openURL, windowTitle, "Complete", "100%", "100%", true, true, true, false);
            currow = wi.rowIndex;
        };
        this.bfForward = function (param) {
	        var focusedEl = document.activeElement;
            var items = me.getSelectedItems();
            if(!selectedItemValidation(items, "moreThanZero"))
            {
                return false;
            }

            var pids="", aseqs="", wseqs="";
            for(var i=0; i<items.length; i++) {
                var wi = items[i];
                pids += wi.procid+";";
                aseqs += wi.actseq+";";
                wseqs += wi.witemseq+";";
            }

            $.ajax({
                type: "GET",
                url: contextPath + "/common/getprocesstype.jsp",
                dataType: "json",
                data : {pids: pids},
                cache:false,
                success: function(json) {
                    if (json.response.success) {
                        if(json.response.processType == "OE") {
                            var url = contextPath + "/solutions/tasktracker117/action/forwardworkitemtask.jsp";
                            url += "?sid=" + items[0].svrid + "&pid=" + items[0].procid + "&actseq=" +items[0].actseq;
	                        focusedEl.focus();
                            executeHiddenCall(url, this);
                        } else if(json.response.processType == "QP") {
                            var url = contextPath + "/webdesign/openapp?method=openForwardFromBizcove&procid=" + items[0].procid  + "&actseq=" + items[0].actseq + "&workseq=" + items[0].witemseq;
	                        focusedEl.focus();
                            executeHiddenCall(url, this);
                        } else {
                            var url = contextPath + "/work/forwardworkitem.jsp?pid="+pids + "&aseq="+aseqs + "&wseq="+wseqs + "&__bizcoveId="+bizcoveid;
	                        var w = openPopup(url, ORGANIZATION, "OpenOrg", 530, 500, true, false);
	                        w.setLastFocusedElement(focusedEl);
                        }
                    } else {
                        notify(json.response.message, "error");
                    }
                },
                error: function(e){
                    notify(e.statusText, "error");
                }
            });
        };
        this.bfSubmit = function (param) {
            var items = me.getSelectedItems();
            if(!selectedItemValidation(items, "moreThanZero"))
            {
                return false;
            }

            var delimeter="", ServerIDs="", ProcessIDs="", ActivityIDs="", WorkItemSeqs="", RespIDs="", Priorities="", CommentChecks="";
            for(var i=0; i<items.length; i++) {
                if(i>0) delimeter = ";";
                var wi = items[i];
                ServerIDs 		+= delimeter+wi.svrid;
                ProcessIDs 		+= delimeter+wi.procid;
                ActivityIDs 	+= delimeter+wi.actseq;
                WorkItemSeqs 	+= delimeter+wi.witemseq;
                RespIDs 		+= delimeter+wi.respseq;
                Priorities 		+= delimeter+wi.priority;
                CommentChecks 	+= delimeter+wi.passwdflag;
            }

            $.ajax({
                type: "POST"
                ,url: contextPath + "/_scriptlibrary/completeworkitem.jsp"
                ,data: {
                    "serverid":ServerIDs,
                    "processid":ProcessIDs,
                    "activityid":ActivityIDs,
                    "workitemseq":WorkItemSeqs,
                    "respid":RespIDs,
                    "priority":Priorities,
                    "commentcheck":CommentChecks
                }
                ,dataType: "json"
                ,cache: false
            }).done(function(resultObj) {
                if(resultObj.success)
                {
                    me.refreshData();
                }
                else
                {
                    notify(resultObj.message, "error");
                }
            }).always(function() {
            }).fail(function(jqXHR, textStatus, errorThrown) {
                notifyInternalServerError(textStatus);
            });
        };
        this.bfMonitoring = function (param) {
            var items = me.getSelectedItems();
            if(!selectedItemValidation(items, "onlyOne"))
            {
                return false;
            }

            var wi = items[0];
            var openURL = contextPath + "/common/audit.jsp";
            openURL += "?pid="+wi.procid;
            openURL += "&pnm="+wi.procname;
            openURL += "&isbizflow=n";
            openURL += "&type=instance";
            openURL += "&isbizcove=y";
            openURL += "&__bizcoveId="+bizcoveid;
            wndWIH = openMonitorPopup(openURL, "", "Monitor", "100%", "100%", true, true, true, true);
        };
        this.bfExcel = function (param) {
            me.saveAsExcel();
        };
        this.bfReject = function (param) {
            var items = me.getSelectedItems();
            if(!selectedItemValidation(items, "moreThanZero"))
            {
                return false;
            }

            var delimeter="", ServerIDs="", ProcessIDs="", ActivityIDs="", WorkItemSeqs="", RespIDs="", Priorities="", CommentChecks="";
            for(var i=0; i<items.length; i++) {
                if(i>0) delimeter = ";";
                var wi = items[i];
                ServerIDs 		+= delimeter+wi.svrid;
                ProcessIDs 		+= delimeter+wi.procid;
                ActivityIDs 	+= delimeter+wi.actseq;
                WorkItemSeqs 	+= delimeter+wi.witemseq;
                RespIDs 		+= delimeter+wi.respseq;
                Priorities 		+= delimeter+wi.priority;
                CommentChecks 	+= delimeter+wi.passwdflag;
            }

            $.ajax({
                type: "POST"
                ,url: contextPath + "/_scriptlibrary/rejectworkitem.jsp"
                ,data: {
                    "serverid":ServerIDs,
                    "processid":ProcessIDs,
                    "activityid":ActivityIDs,
                    "workitemseq":WorkItemSeqs,
                    "commentcheck":CommentChecks
                }
                ,dataType: "json"
                ,cache: false
            }).done(function(resultObj) {
                if(resultObj.success)
                {
                    me.refreshData();
                }
                else
                {
                    notify(resultObj.message, "error");
                }
            }).always(function() {
            }).fail(function(jqXHR, textStatus, errorThrown) {
                notifyInternalServerError(textStatus);
            });
        };
        this.bfRecall = function (param) {
            var items = me.getSelectedItems();
            if(!selectedItemValidation(items, "moreThanZero"))
            {
                return false;
            }

            var delimeter="", ServerIDs="", ProcessIDs="", ActivityIDs="", WorkItemSeqs="";
            for(var i=0; i<items.length; i++) {
                if(i>0) delimeter = ";";
                var wi = items[i];
                ServerIDs 		+= delimeter+wi.svrid;
                ProcessIDs 		+= delimeter+wi.procid;
                ActivityIDs 	+= delimeter+wi.actseq;
                WorkItemSeqs 	+= delimeter+wi.witemseq;
            }

            $.ajax({
                type: "POST"
                ,url: contextPath + "/_scriptlibrary/rejectworkitem.jsp"
                ,data: {
                    "serverid":ServerIDs,
                    "processid":ProcessIDs,
                    "activityid":ActivityIDs,
                    "workitemseq":WorkItemSeqs
                }
                ,dataType: "json"
                ,cache: false
            }).done(function(resultObj) {
                if(resultObj.success)
                {
                    me.refreshData();
                }
                else
                {
                    notify(resultObj.message, "error");
                }
            }).always(function() {
            }).fail(function(jqXHR, textStatus, errorThrown) {
                notifyInternalServerError(textStatus);
            });
        };
        this.bfConsolidate = function (param) {
            var items = me.getSelectedItems();
            if(!selectedItemValidation(items, "onlyTwo"))
            {
                return false;
            }

            var wi1 = items[0];
            var wi2 = items[1];
            var mergeURL = contextPath + "/instance/merge.jsp";
            mergeURL += "?pid=" + wi1.procid;
            mergeURL += "&lpid=" + wi2.procid;
            mergeURL += "&__bizcoveId="+bizcoveid;
            wndWIH = openPopup(mergeURL, "", "Consolidate", 520, 310, true, false);
        };
        this.bfClone = function (param) {
            var items = me.getSelectedItems();
            if(!selectedItemValidation(items, "onlyOne"))
            {
                return false;
            }

            var wi = items[0];
            var cloneURL = contextPath + "/instance/split.jsp";
            cloneURL += "?pid=" + wi.procid;
            cloneURL += "&__bizcoveId="+bizcoveid;
            wndWIH = openPopup(cloneURL, "", "Clone", 520, 310, true, false);
        };
        this.doForward = function (selectedID, selectedName) {
            var items = me.getSelectedItems();
            if (!selectedItemValidation(items, "moreThanZero")) {
                return false;
            }

            var delimeter = "", ServerIDs = "", ProcessIDs = "", ActivityIDs = "", WorkItemSeqs = "";
            for (var i = 0; i < items.length; i++) {
                if (i > 0) delimeter = ";";
                var wi = items[i];
                ProcessIDs += delimeter + wi.procid;
                ActivityIDs += delimeter + wi.actseq;
                WorkItemSeqs += delimeter + wi.witemseq;
            }

            $.ajax({
                type: "POST"
                , url: contextPath + "/work/forward.jsp?t="+Math.random()+_pageKey
                , data: {
                    "hUserID": selectedID,
                    "hUserName": selectedName,
                    "hDeptName": "",
                    "hTagProcessID": ProcessIDs,
                    "hTagATSequence": ActivityIDs,
                    "hTagWISequence": WorkItemSeqs,
                    "bizcove": bizcoveid,
                    "callpage": "bizcove",
                    "bizcoveContextPath": contextPath,
                    "bizcoveServletPath": servletPath,
                    "responseDataType": "json"
                }
                , dataType: "json"
                , cache: false
            }).done(function(resultObj) {
                if(resultObj.success)
                {
                    if(resultObj.message)
                    {
                        notify(resultObj.message, "info");
                    }
                    me.refreshData();
                }
                else
                {
                    notify(resultObj.message, "error");
                }
            }).always(function () {
            }).fail(function (jqXHR, textStatus, errorThrown) {
                notifyInternalServerError(textStatus);
            });
        };
        this.gmtToLocal = function (gmt, removeTime) {
            removeTime = removeTime || (config.dateOnlyFormat == config.kendoUserDateFormat);

            if ((typeof(gmt) == "string") && (gmt.length != 0)) {
                var dt = kendo.parseDate(gmt, SERVER_DATETIME_FORMAT);
                var ldt = new Date(dt.getTime() - timezoneOffset);
                var fdt = kendo.toString(ldt, config.kendoUserDateFormat);
                if (removeTime) {
                    //return new Date(ldt.getFullYear(), ldt.getMonth(), ldt.getDate());
                    return kendo.parseDate(fdt, config.dateOnlyFormat);
                }
                else {
                    return kendo.parseDate(fdt, config.kendoUserDateFormat);
                }
            } else {
                return gmt;
            }
        };
        this.getNextWorkItem = function(param) {
            if(currow >= 0) {
                currow = parseInt(currow);
                var wi;
                var grid = me.selector(".grid").data("kendoGrid");
                var dataSource = grid.dataSource;
                var prevRow = grid.tbody.find(">tr:not(.k-grouping-row)").eq(currow);
                var nextRow = null;
                if((currow+1) >= dataSource.pageSize()) { // GET Next Page
                    currow = -1;
                    prevRow = null;
                    wi = null;
                    //var curpage = dataSource.page();
                    //dataSource.fetch(function() {
                    //    dataSource.page(curpage);
                    //});
                } else {
                    nextRow = grid.tbody.find(">tr:not(.k-grouping-row)").eq(currow + 1);
                }
                if(prevRow) { // unselect a checkbox
                    this.rowUnSelect(prevRow);
                }
                if(nextRow) { // select a checkbox
                    this.rowSelect(nextRow);
                    var items = me.getSelectedItems();
                    wi = items[0];
                    currow = currow+1;
                }
                return wi;
            }
        };
// create end
    };

    function selectedItemValidation(items, validCount)
    {
        if(typeof(validCount) == 'undefined')
        {
            return true;
        }
        else if((typeof (items) == 'undefined' || items.length == 0) && "moreThanZero" == validCount)
        {
            notify(MSG_WARN_SELECT_AT_LEAST_ONE_ITEM, "warn");
            return false;
        }
		else if(items.length == 0)
        {
            notify(MSG_WARN_SELECT_AT_LEAST_ONE_ITEM, "warn");
            return false;
        }
        else if(1 != items.length && "onlyOne" == validCount )
        {
            notify(MSG_WARN_SELECT_ONLY_ONE_ITEM, "warn");
            return false;
        }
        else if(2 != items.length && "onlyTwo" == validCount )
        {
            notify(MSG_WARN_SELECT_ONLY_TWO_ITEMS, "warn");
            return false;
        }

        return true;
    }

    $.fn.WorkListBizCove = function(bizcoveid, options)
    {
        return this.each(function() {
            var element = $(this);

            if (element.data('pluginData')) {
                return;
            }

            var pluginData = new createPluginData(this, bizcoveid, options);
            element.data('pluginData', pluginData);

            pluginData.load();
        });
    };
})(jQuery);
/**
 * Gets selected items.
 * @param bizcoveid BizCove ID
 * @returns {Array}
 * @since 12.4
 */
function getSelectedItems(bizcoveid)
{
    return getBizCoveComponent(bizcoveid).getSelectedItems();
}

function linkedAction(bizcoveid, e, _data, _linkedAction) {
    getBizCoveComponent(bizcoveid).linkedAction(e,_data,_linkedAction);
}
function bfOpen(param) {
    getBizCoveComponent(param.bizcoveid).bfOpen(param);
}
function bfForward(param) {
    getBizCoveComponent(param.bizcoveid).bfForward(param);
}
function bfSubmit(param) {
    getBizCoveComponent(param.bizcoveid).bfSubmit(param);
}
function bfMonitoring(param) {
    getBizCoveComponent(param.bizcoveid).bfMonitoring(param);
}
function bfExcel(param) {
    getBizCoveComponent(param.bizcoveid).bfExcel(param);
}
function bfReject(param) {
    getBizCoveComponent(param.bizcoveid).bfReject(param);
}
function bfRecall(param) {
    getBizCoveComponent(param.bizcoveid).bfRecall(param);
}
function bfConsolidate(param) {
    getBizCoveComponent(param.bizcoveid).bfConsolidate(param);
}
function bfClone(param) {
    getBizCoveComponent(param.bizcoveid).bfClone(param);
}
function getBizCoveComponent(bizcoveid) {
    return $('#bf-bizcove'+bizcoveid).data('pluginData');
}
function reloadData (bizcoveid) {
    if(!bizcoveid || bizcoveid.length == 0) {
        $(".BizCove").each(function(index, item){
            var bizcove = $(this);
            var bf_bizcoveid = bizcove.data("bf-bizcoveid");
            if(bf_bizcoveid)
            {
                getBizCoveComponent(bf_bizcoveid).refreshGrid(true);
            }
        });
    }
    else
    {
        getBizCoveComponent(bizcoveid).refreshGrid(true);
    }
}
function reload() {				// for modal window
    this.location.reload();
}
function refreshBizcove(bizcoveid) {
    reloadData(bizcoveid);
}
function _toolAction(bizcoveid, menu) {
    getBizCoveComponent(bizcoveid).toolAction(menu);
}
function isTopMenuBizCove() {
    var parentPathName = parent.location.pathname;
    return (parentPathName.indexOf("bizpage.jsp") > 0);
}
function onorgselchange(selectedID, selectedName, bizcoveid) {
    getBizCoveComponent(bizcoveid).doForward(selectedID, selectedName);
}
function consoleError()
{
    if(console)
    {
        if(console.error)
        {
            console.error(arguments);
        }
        else if(console.log)
        {
            console.log(arguments);
        }
    }
}
function getNextWorkItem(bizcoveid) {
    return getBizCoveComponent(bizcoveid).getNextWorkItem(bizcoveid);
}