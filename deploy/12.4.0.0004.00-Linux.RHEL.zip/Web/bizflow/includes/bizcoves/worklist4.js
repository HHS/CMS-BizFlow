var wndPref = null;
function openPrefWindow()
{
	var sUrl = contextPath + "/preference/preferenceframe.jsp";
	wndPref = openPopup(sUrl, "", "Preference", 564, 540);
}

function worklist_openWIH(category, pagecount, mode, bizid)
{
	var isBizflow = "y";
	if(servletPath.indexOf("/portal/startpage")== -1)
		isBizflow = "n";

	if (parseInt(eval("item_arr"+bizid+".length")) > 1)
		alert(msgOnlyOneItem);
	else if (parseInt(eval("item_arr"+bizid+".length")) == 0)
		alert(msgSelectItem);
	else 
	{
		if("T" == eval("item_arr"+bizid+"[0][8]"))
		{
			passwordValue = "false";
			actionType = mode;
			var sUrl =  contextPath + "/common/passwordframe.jsp?isbizflow="+isBizflow;
			wndPassword = ShowWindowEx2(contextPath, sUrl, "wndPassword", CHECKPASSWD, 300, 140, "no");
		}
		else if("F" == eval("item_arr"+bizid+"[0][8]"))
			passwordValue = "true";

		if ("true" == passwordValue)
		{
			getWIHInfoString();
			var sUrl =  contextPath +"/work/wih.jsp?sid=" + eval("item_arr"+bizid+"[0][3]") 
						+ "&pid=" + eval("item_arr"+bizid+"[0][0]") + "&seq=" + eval("item_arr"+bizid+"[0][2]")
						+ "&asq=" + eval("item_arr"+bizid+"[0][4]") + "&pro=" + eval("item_arr"+bizid+"[0][5]") 
						+ "&rid=" + eval("item_arr"+bizid+"[0][6]") + "&time=" + now.getTime() 
						+ "&openpage=page" + "&mode=" + mode + "&bizcovecall=y";
			var sFeatures = "status=yes,toolbar=no,resizable=yes,scrollbars=yes";
			wndWIH = window.open(sUrl, "Complete", sFeatures);
			refreshWhenWIHWindowClosed(bizid);
		}
	}
}

var wndMonitor;
var curBrowser;
function worklist_ActionopenMonitor(category, pagecount, sBrowser, bizid)
{
	curbizID = bizid;
	var isBizflow = "y";
	curBrowser = sBrowser;

	if(servletPath.indexOf("/portal/startpage")== -1)
		 isBizflow = "n";

	if (parseInt(eval("item_arr"+bizid+".length")) > 1)
		alert(msgOnlyOneItem);
	else if (parseInt(eval("item_arr"+bizid+".length")) == 0)
		alert(msgSelectItem);
	else 
	{
		if("T" == eval("item_arr"+bizid+"[0][8]"))
		{
			passwordValue="false";
			actionType = "monitor";

			var sUrl = contextPath + "/common/passwordframe.jsp?isbizflow" + isBizflow;
			wndPassword = ShowWindow(sUrl, "wndPassword", CHECKPASSWD, 300, 140, "no");
		}
		else if("F" == eval("item_arr"+bizid+"[0][8]"))
		   currentMonitor(bizid); 
	}
}

function currentMonitor(bizid)
{
	var useAccessibility = tmpUseAccessibility;
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}
	var sBrowser = curBrowser;
	passwordValue = "true";
	var isBizflow = "y";
	if(servletPath.indexOf("/portal/startpage")== -1)
		isBizflow = "n";

	var sProcName = "";
	var strVal = eval("item_arr"+bizid+"[0][1]");
	sProcName = URLEncode(strVal);

    var taskWbs = eval("item_arr" +bizid +"[0][14]");
    if(taskWbs != "") {
        var sUrl = contextPath + "/solutions/tasktracker117/action/monitorworkitemtask.jsp?taskWbs=" + taskWbs
        executeHiddenCall(sUrl, this);
    } else {
        if ("PIE" == sBrowser)
        {
            top.location.href =  contextPath + "/common/auditdetail.jsp?pid="
                    + eval("item_arr"+bizid+"[0][0]") + "&type=instance&passwordflag=F&isbizflow="+isBizflow + "&pnm=" + sProcName
                    + "&__bizcoveId=" + bizid;
        }
        else
        {
            var sUrl =  contextPath + "/common/audit.jsp?pid=" + eval("item_arr"+bizid+"[0][0]")  + "&isbizcove=y"
                        + "&type=instance" + "&pnm=" + sProcName +"&isbizflow="+isBizflow
                        + "&__bizcoveId=" + bizid;
            var iWidth = window.screen.availWidth-100;
            var iHeight = window.screen.availHeight-200;

            if(isModalMonitorMode())
            {
                iWidth = "100%";
                iHeight = "100%";
            }
            wndWIH = openMonitorPopup(sUrl, "", "Monitor", iWidth, iHeight, true, true, true, true);
			if(!useAccessibility) {
				refreshWhenWIHWindowClosed(bizid);
			}
        }
    }
}


function worklist_OpenMonitor(bizid, browsername, useAccessibility)
{
	curbizID = bizid;
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}
	tmpUseAccessibility = useAccessibility;

	if ("false" == isAuthorizedMonitor)
		alert (msg_no_auth_monitor);
	else
	{
		var passwordflag_init = eval("item_arr_singleStorage"+bizid+"[8]");
		var isBizflow = "y";
		if(servletPath.indexOf("/portal/startpage")== -1)
			 isBizflow = "n";

		if("T" == passwordflag_init)
		{
			passwordValue="false";
			actionType = "singlemonitor";
			var sUrl = contextPath + "/common/passwordframe.jsp?isbizflow="+isBizflow;
			wndPassword = ShowWindowEx2(contextPath, sUrl, "wndPassword", CHECKPASSWD, 300, 140, "no"); 
		}
		else if("F" == eval("item_arr_singleStorage"+bizid+"[8]"))
		{
			passwordValue = "true";
			var sProcName = "";
			var strVal = eval("item_arr_singleStorage"+bizid+"[1]");
			var sProcName = URLEncode(strVal);
						
			if ("PIE" == browsername)
				top.location.href =  contextPath + "/common/auditdetail.jsp?pid=" 
						+ eval("item_arr_singleStorage"+bizid+"[0]") + "&type=instance&passwordflag=F&isbizflow="+isBizflow + "&pnm=" + sProcName;
			else
				singleMonitor(bizid);
		}
	}
}

function singleMonitor(bizid)
{
	var isBizflow = "y";
	var useAccessibility = tmpUseAccessibility;
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}

	if(servletPath.indexOf("/portal/startpage")== -1)
		isBizflow = "n";

	var sProcName = "";
	var strVal = eval("item_arr_singleStorage"+bizid+"[1]");
	var sProcName = URLEncode(strVal);
	var sUrl = contextPath + "/common/audit.jsp?pid=" 
			   + eval("item_arr_singleStorage"+bizid+"[0]") + "&isbizcove=y" + "&type=instance&isbizflow="+isBizflow + "&pnm=" + sProcName;

	var iWidth = window.screen.availWidth-100;
	var iHeight = window.screen.availHeight-200;

    if(isModalMonitorMode())
    {
        iWidth = "100%";
        iHeight = "100%";
    }
    wndWIH = openMonitorPopup(sUrl, "", "Monitor", iWidth, iHeight, true, true, true, true);
	if(!useAccessibility) {
		refreshWhenWIHWindowClosed(bizid);
	}
}

function worklist_SingleCustom1(bizid)
{
	var bizcove = new Object();
	var procs = new Object();
	var act = new Object();
	var witem = new Object();
	var variables = new Object(); // for future use.
	bizcove.id = bizid;
	bizcove.selectedindex = eval("item_arr"+bizid+"[0][12]"); // [0][9] has the same value as this?
	bizcove.havesubmit = eval("item_arr"+bizid+"[0][10]");
	procs.serverid = eval("item_arr"+bizid+"[0][3]");
	procs.procid = eval("item_arr"+bizid+"[0][0]");
	procs.name = eval("item_arr"+bizid+"[0][1]");
	procs.passwdflag = eval("item_arr"+bizid+"[0][8]");
	act.actseq = eval("item_arr"+bizid+"[0][4]");
	act.actinfo = eval("item_arr"+bizid+"[0][13]");
	witem.witemseq = eval("item_arr"+bizid+"[0][2]");
	witem.state = eval("item_arr"+bizid+"[0][7]");
	witem.priority = eval("item_arr"+bizid+"[0][5]");
	witem.respseq = eval("item_arr"+bizid+"[0][6]");
	passwdflag_pref = eval("item_arr"+bizid+"[0][11]");
	alert('bizcove.id = ' + bizcove.id
		+ '\nbizcove.selectedindex = ' + bizcove.selectedindex
		+ '\nbizcove.havesubmit = ' + bizcove.havesubmit
		+ '\nprocs.serverid = ' + procs.serverid
		+ '\nprocs.procid = ' + procs.procid
		+ '\nprocs.name = ' + procs.name
		+ '\nprocs.passwdflag = ' + procs.passwdflag
		+ '\nact.actseq = ' + act.actseq
		+ '\nact.actinfo = ' + act.actinfo
		+ '\nwitem.witemseq = ' + witem.witemseq
		+ '\nwitem.state = ' + witem.state
		+ '\nwitem.priority = ' + witem.priority
		+ '\nwitem.respseq = ' + witem.respseq
		+ '\npasswdflag_pref = ' + passwdflag_pref
		+ '\n\n(Custom 1 is not yet implemented - edit includes/bizcoves/worklist4.js to add more actions)');
/*
	var sUrl = contextPath + "/solutions/worklistcustom1.jsp?procid=" + procs.procid + "&actseq=" + act.actseq + "&witemseq=" + witem.witemseq + "&t=" + new Date().getMilliseconds();
	var iWidth = window.screen.availWidth * 0.6;
	var iHeight = window.screen.availWidth * 0.4;
	var iLeft = (window.screen.availWidth - iWidth) / 2;
	var iTop = (window.screen.availHeight - iHeight) / 2;
	var features = "status=no,toolbars=no,resizable=yes,left=" + iLeft + "," + "top=" + iTop + "," + "width=" + iWidth + "," + "height=" + iHeight;
	w = window.open(sUrl, "worklistCustom1", features);
	w.focus();
*/
}

function worklist_SingleCustom2(bizid)
{
	var bizcove = new Object();
	var procs = new Object();
	var act = new Object();
	var witem = new Object();
	var variables = new Object(); // for future use.
	bizcove.id = bizid;
	bizcove.selectedindex = eval("item_arr"+bizid+"[0][12]"); // [0][9] has the same value as this?
	bizcove.havesubmit = eval("item_arr"+bizid+"[0][10]");
	procs.serverid = eval("item_arr"+bizid+"[0][3]");
	procs.procid = eval("item_arr"+bizid+"[0][0]");
	procs.name = eval("item_arr"+bizid+"[0][1]");
	procs.passwdflag = eval("item_arr"+bizid+"[0][8]");
	act.actseq = eval("item_arr"+bizid+"[0][4]");
	act.actinfo = eval("item_arr"+bizid+"[0][13]");
	witem.witemseq = eval("item_arr"+bizid+"[0][2]");
	witem.state = eval("item_arr"+bizid+"[0][7]");
	witem.priority = eval("item_arr"+bizid+"[0][5]");
	witem.respseq = eval("item_arr"+bizid+"[0][6]");
	passwdflag_pref = eval("item_arr"+bizid+"[0][11]");
	alert('bizcove.id = ' + bizcove.id
		+ '\nbizcove.selectedindex = ' + bizcove.selectedindex
		+ '\nbizcove.havesubmit = ' + bizcove.havesubmit
		+ '\nprocs.serverid = ' + procs.serverid
		+ '\nprocs.procid = ' + procs.procid
		+ '\nprocs.name = ' + procs.name
		+ '\nprocs.passwdflag = ' + procs.passwdflag
		+ '\nact.actseq = ' + act.actseq
		+ '\nact.actinfo = ' + act.actinfo
		+ '\nwitem.witemseq = ' + witem.witemseq
		+ '\nwitem.state = ' + witem.state
		+ '\nwitem.priority = ' + witem.priority
		+ '\nwitem.respseq = ' + witem.respseq
		+ '\npasswdflag_pref = ' + passwdflag_pref
		+ '\n\n(Custom 2 is not yet implemented - edit includes/bizcoves/worklist4.js to add more actions)');
/*
	var sUrl = contextPath + "/solutions/worklistcustom2.jsp?procid=" + procs.procid + "&actseq=" + act.actseq + "&witemseq=" + witem.witemseq + "&t=" + new Date().getMilliseconds();
	var iWidth = window.screen.availWidth * 0.6;
	var iHeight = window.screen.availWidth * 0.4;
	var iLeft = (window.screen.availWidth - iWidth) / 2;
	var iTop = (window.screen.availHeight - iHeight) / 2;
	var features = "status=no,toolbars=no,resizable=yes,left=" + iLeft + "," + "top=" + iTop + "," + "width=" + iWidth + "," + "height=" + iHeight;
	w = window.open(sUrl, "worklistCustom2", features);
	w.focus();
*/
}

function worklist_SingleCustom3(bizid)
{
	var bizcove = new Object();
	var procs = new Object();
	var act = new Object();
	var witem = new Object();
	var variables = new Object(); // for future use.
	bizcove.id = bizid;
	bizcove.selectedindex = eval("item_arr"+bizid+"[0][12]"); // [0][9] has the same value as this?
	bizcove.havesubmit = eval("item_arr"+bizid+"[0][10]");
	procs.serverid = eval("item_arr"+bizid+"[0][3]");
	procs.procid = eval("item_arr"+bizid+"[0][0]");
	procs.name = eval("item_arr"+bizid+"[0][1]");
	procs.passwdflag = eval("item_arr"+bizid+"[0][8]");
	act.actseq = eval("item_arr"+bizid+"[0][4]");
	act.actinfo = eval("item_arr"+bizid+"[0][13]");
	witem.witemseq = eval("item_arr"+bizid+"[0][2]");
	witem.state = eval("item_arr"+bizid+"[0][7]");
	witem.priority = eval("item_arr"+bizid+"[0][5]");
	witem.respseq = eval("item_arr"+bizid+"[0][6]");
	passwdflag_pref = eval("item_arr"+bizid+"[0][11]");
	alert('bizcove.id = ' + bizcove.id
		+ '\nbizcove.selectedindex = ' + bizcove.selectedindex
		+ '\nbizcove.havesubmit = ' + bizcove.havesubmit
		+ '\nprocs.serverid = ' + procs.serverid
		+ '\nprocs.procid = ' + procs.procid
		+ '\nprocs.name = ' + procs.name
		+ '\nprocs.passwdflag = ' + procs.passwdflag
		+ '\nact.actseq = ' + act.actseq
		+ '\nact.actinfo = ' + act.actinfo
		+ '\nwitem.witemseq = ' + witem.witemseq
		+ '\nwitem.state = ' + witem.state
		+ '\nwitem.priority = ' + witem.priority
		+ '\nwitem.respseq = ' + witem.respseq
		+ '\npasswdflag_pref = ' + passwdflag_pref
		+ '\n\n(Custom 3 is not yet implemented - edit includes/bizcoves/worklist4.js to add more actions)');
/*
	var sUrl = contextPath + "/solutions/worklistcustom3.jsp?procid=" + procs.procid + "&actseq=" + act.actseq + "&witemseq=" + witem.witemseq + "&t=" + new Date().getMilliseconds();
	var iWidth = window.screen.availWidth * 0.6;
	var iHeight = window.screen.availWidth * 0.4;
	var iLeft = (window.screen.availWidth - iWidth) / 2;
	var iTop = (window.screen.availHeight - iHeight) / 2;
	var features = "status=no,toolbars=no,resizable=yes,left=" + iLeft + "," + "top=" + iTop + "," + "width=" + iWidth + "," + "height=" + iHeight;
	w = window.open(sUrl, "worklistCustom3", features);
	w.focus();
*/
}

function worklist_SingleCustom4(bizid)
{
	var bizcove = new Object();
	var procs = new Object();
	var act = new Object();
	var witem = new Object();
	var variables = new Object(); // for future use.
	bizcove.id = bizid;
	bizcove.selectedindex = eval("item_arr"+bizid+"[0][12]"); // [0][9] has the same value as this?
	bizcove.havesubmit = eval("item_arr"+bizid+"[0][10]");
	procs.serverid = eval("item_arr"+bizid+"[0][3]");
	procs.procid = eval("item_arr"+bizid+"[0][0]");
	procs.name = eval("item_arr"+bizid+"[0][1]");
	procs.passwdflag = eval("item_arr"+bizid+"[0][8]");
	act.actseq = eval("item_arr"+bizid+"[0][4]");
	act.actinfo = eval("item_arr"+bizid+"[0][13]");
	witem.witemseq = eval("item_arr"+bizid+"[0][2]");
	witem.state = eval("item_arr"+bizid+"[0][7]");
	witem.priority = eval("item_arr"+bizid+"[0][5]");
	witem.respseq = eval("item_arr"+bizid+"[0][6]");
	passwdflag_pref = eval("item_arr"+bizid+"[0][11]");
	alert('bizcove.id = ' + bizcove.id
		+ '\nbizcove.selectedindex = ' + bizcove.selectedindex
		+ '\nbizcove.havesubmit = ' + bizcove.havesubmit
		+ '\nprocs.serverid = ' + procs.serverid
		+ '\nprocs.procid = ' + procs.procid
		+ '\nprocs.name = ' + procs.name
		+ '\nprocs.passwdflag = ' + procs.passwdflag
		+ '\nact.actseq = ' + act.actseq
		+ '\nact.actinfo = ' + act.actinfo
		+ '\nwitem.witemseq = ' + witem.witemseq
		+ '\nwitem.state = ' + witem.state
		+ '\nwitem.priority = ' + witem.priority
		+ '\nwitem.respseq = ' + witem.respseq
		+ '\npasswdflag_pref = ' + passwdflag_pref
		+ '\n\n(Custom 4 is not yet implemented - edit includes/bizcoves/worklist4.js to add more actions)');
/*
	var sUrl = contextPath + "/solutions/worklistcustom4.jsp?procid=" + procs.procid + "&actseq=" + act.actseq + "&witemseq=" + witem.witemseq + "&t=" + new Date().getMilliseconds();
	var iWidth = window.screen.availWidth * 0.6;
	var iHeight = window.screen.availWidth * 0.4;
	var iLeft = (window.screen.availWidth - iWidth) / 2;
	var iTop = (window.screen.availHeight - iHeight) / 2;
	var features = "status=no,toolbars=no,resizable=yes,left=" + iLeft + "," + "top=" + iTop + "," + "width=" + iWidth + "," + "height=" + iHeight;
	w = window.open(sUrl, "worklistCustom4", features);
	w.focus();
*/
}
