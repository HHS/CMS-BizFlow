var wndPref = null;
function openPrefWindow()
{
	var sUrl = contextPath + "/preference/preferenceframe.jsp";
	wndPref = openPopup(sUrl, "", "Preference", 564, 540);
}

function ViewDef(bizid, browsername, type)
{
	ViewDefinition('','','','', bizid, browsername, type);
}

function definition_View(bizid, browsername, useAccessibility)
{
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}
	tmpUseAccessibility = useAccessibility;
	var sProcDefID = eval("def_item_arr_ss"+bizid+"[0]");
	var sProcDefName = "";
	var sBrecser = "";
	var strVal = eval("def_item_arr_ss"+bizid+"[1]");
	sProcDefName = URLEncode(strVal);
	
	var isBizflow = "y";
	if(servletPath.indexOf("/portal/startpage")== -1)
		isBizflow = "n";

	var sUrl = contextPath + "/common/audit.jsp?defid=" + sProcDefID 
				+ "&defnm=" + sProcDefName + "&type=definition&isbizflow="+isBizflow;

	if(browsername =="PIE")
		location.href = sUrl;
	else
	{
		var iWidth = window.screen.availWidth-100;
		var iHeight = window.screen.availHeight-200;
		var iLeft = 50;
		var iTop = 50;
		var sFeatures = "scrollbars=yes,status=yes,toolbar=yes,resizable=yes,left=" + iLeft + "," + "top=" + iTop + "," + "width=" + iWidth + "," + "height=" + iHeight;

//		definition_wndWIH = window.open(sUrl, "ProcessDef", sFeatures);
        definition_wndWIH = openPopup(sUrl, "", "ProcessDef", "100%", "100%","yes");
		definition_wndWIH.focus();	 
		if(!useAccessibility) {
			definition_refreshWhenWIHWindowClosed(bizid);
		}
	}
}

function definition_CPView(bizid, browsername, useAccessibility)
{
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}
	tmpUseAccessibility = useAccessibility;
    var sProcDefID = eval("def_item_arr_ss"+bizid+"[0]");
    var sProcDefName = "";
    var sBrecser = "";
    var strVal = eval("def_item_arr_ss"+bizid+"[1]");
    sProcDefName = URLEncode(strVal);

    var isBizflow = "y";
    if(servletPath.indexOf("/portal/startpage")== -1)
        isBizflow = "n";

    var type = "cpdefinition";

    var sUrl =  contextPath + "/common/audit.jsp?defid=" + sProcDefID
        + "&defnm=" + sProcDefName + "&type=" + type + "&isbizflow=" + isBizflow;

    if(browsername =="PIE")
        location.href = sUrl;
    else
    {
        var iWidth = window.screen.availWidth-100;
        var iHeight = window.screen.availHeight-200;
        definition_wndWIH = openMonitorPopup(sUrl, "", "ProcessDef", iWidth, iHeight, true, true, true, true);
		if(!useAccessibility) {
			definition_refreshWhenWIHWindowClosed(bizid);
		}
    }
}

var wndMonitor = null;
function ViewDefinition(fid, authority, pagecount, sBrecser, bizid,browsername, type)
{
	var useAccessibility = tmpUseAccessibility;
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}
	if (parseInt(eval("def_item_arr"+bizid+".length")) > 1)
		alert(msgCmmOnlyOneSelectItem);
	else if (parseInt(eval("def_item_arr"+bizid+".length")) == 0)
		alert(msgCmmSelectItem);
	else
	{
		var isBizflow = "y";
		if(servletPath.indexOf("/portal/startpage")== -1)
			isBizflow = "n";

		if (type == "cpview")
			type = "cpdefinition";
		else
			type = "definition";

		var sProcDefID = eval("def_item_arr"+bizid+"[0][0]");
		var strVal = eval("def_item_arr"+bizid+"[0][1]");
		var sProcDefName = URLEncode(strVal);
		var sUrl =  contextPath + "/common/audit.jsp?defid=" + sProcDefID 
					+ "&defnm=" + sProcDefName + "&type=" + type + "&isbizflow=" + isBizflow;

		if(browsername =="PIE")
			location.href = sUrl; 
		else
		{
			var iWidth = window.screen.availWidth-100;
			var iHeight = window.screen.availHeight-200;
			definition_wndWIH = openMonitorPopup(sUrl, "", "ProcessDef", iWidth, iHeight, true, true, true, true);
			if(!useAccessibility) {
				definition_refreshWhenWIHWindowClosed(bizid);
			}
		}
	}   
}
