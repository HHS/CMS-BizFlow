// worklist1.js: 2/8/2011, just touched to force download of worklist2.js, worklist3.js or worklist4.js. script.mres uses this file as the javascript cache expiration time.

var UserID;
var selfuserid;		
var wndPassword;
var passwordValue = "false";
var actionType;			
var now = new Date();
var forwardlink = "false";
var wndWorkOrg;	
var wndWIH;
var _ErrorMsg = "";
var tmpUseAccessibility = false;

function URLEncode(s)
{
	if (!BrowserDetect.isExplorer())
		return escape(s);
	
	var escaped = "";
	var len = s.length;
	var code;

	for (i = 0; i != len; ++i)
	{
		code = s.charCodeAt(i);
		
		if (code < 256)
			escaped += escape(s.charAt(i));
		else
			escaped += s.charAt(i);
	}

	return escaped;
}

function getWorklist(actionType, bizid, browsername, useAccessibility)
{
    var taskWbs = "";
    try { taskWbs = eval("item_arr" +bizid +"[0][14]"); } catch(e) { } // Bug 27544
    var orgprocdefid = "";
    try { orgprocdefid = eval("item_arr" +bizid +"[0][15]"); } catch(e) { }
	tmpUseAccessibility = useAccessibility;

	if(actionType == "open")
	{
		if( eval("item_arr"+bizid+".length") > 1)
			alert(msgOnlyOneItem);
		else if(parseInt(eval("item_arr"+bizid+".length")) == 0 )
			alert(msgSelectItem);
		else
		{
			var serverid, processid, workseq, activityseq, priority, responseid, passwordflag, mode;
			serverid = eval("item_arr" +bizid +"[0][3]");
			processid = eval("item_arr"+bizid +"[0][0]");
			workseq = eval("item_arr" +bizid + "[0][2]");
			activityseq = eval("item_arr" +bizid +"[0][4]");
			priority = eval("item_arr" +bizid +"[0][5]");
			responseid = eval("item_arr" +bizid +"[0][6]");
			passwordflag_init = eval("item_arr" +bizid +"[0][8]");
			passwordflag_pref = eval("item_arr" +bizid +"[0][11]");
			curWorkIndex = prevWorkCount + parseInt(eval("item_arr" +bizid +"[0][12]"));
			mode = "complete";
			openWIH_worklistLink(serverid, processid, workseq, activityseq, priority, responseid, passwordflag_init, passwordflag_pref, mode, bizid);
		}
	}
	else if(actionType == "submit")
	{
		if(parseInt(eval("item_arr"+bizid+".length")) == 0)
			alert(msgSelectItems);
		else
			completeWI(bizid);
	}
	else if(actionType == "forward")
	{
        var procIdList = "";
        if(parseInt(eval("item_arr"+bizid+".length")) == 0)
        {
            alert(msgSelectItems);
            return false;
        }
        for (var i = 0; i < parseInt(eval("item_arr"+bizid+".length")); i++)
        {
            procIdList = procIdList + eval("item_arr"+bizid+"[i][0]") + ";";
        }

        $.ajax({
            type: "GET",
            url: contextPath + "/common/getprocesstype.jsp",
            dataType: "json",
            data : {pids: procIdList},
            cache:false,
            success: function(json) {
                if (json.response.success) {
                    if(json.response.processType == "OE") {
                        var sUrl = contextPath + "/solutions/tasktracker117/action/forwardworkitemtask.jsp";
                        if(taskWbs != "") {
                            sUrl = sUrl + "?taskWbs=" + taskWbs;
                        } else {
                            var processid = eval("item_arr" + bizid + "[0][0]");
                            var serverid = eval("item_arr" +bizid +"[0][3]");
                            var activityseq = eval("item_arr" + bizid + "[0][4]");
                            sUrl = sUrl + "?sid=" + serverid + "&pid=" + processid + "&actseq=" +activityseq;
                        }
                        executeHiddenCall(sUrl, this);
                    } else if(json.response.processType == "QP") {
                        var processid = eval("item_arr" + bizid + "[0][0]");
                        var workseq = eval("item_arr" + bizid + "[0][2]");
                        var activityseq = eval("item_arr" + bizid + "[0][4]");
                        var sUrl = contextPath + "/webdesign/openapp?method=openForwardFromBizcove&procid=" + processid + "&actseq=" + activityseq + "&workseq=" + workseq;
                        executeHiddenCall(sUrl, this);
                    } else {
                        if ("false" == isAuthorizedForward) {
                            alert (msg_no_auth_forward);
                        }
                        else {
                            openOrg("", bizid, browsername);
                        }
                    }
                } else {
                    alert(json.response.message);
                }
            },
            error: function(e){
                alert(e.statusText);
            }
        });
	}
	else if(actionType == "monitoring")
	{
		if ("false" == isAuthorizedMonitor)
			alert (msg_no_auth_monitor);
		else
			worklist_ActionopenMonitor("", 0, browsername, bizid);
	}
	else if(actionType == "excel")
	{
		worklist_OpenExcel(bizid, browsername, useAccessibility);
	}
	else if (actionType =="search")
	{
		worklist_OpenSearch(bizid, browsername, useAccessibility);
	}
	else if (actionType == "reject")
	{
		if(parseInt(eval("item_arr"+bizid+".length")) == 0)
			alert(msgSelectItem);
		else
			worklist_Reject(bizid);
	}
	else if (actionType == "recall")
	{
		if(parseInt(eval("item_arr"+bizid+".length")) == 0)
			alert(msgSelectItem);
		else
			worklist_Recall(bizid);
	}
	else if (actionType == "viewTaskComments")
	{
		if(parseInt(eval("item_arr"+bizid+".length")) == 0)
			alert(msgSelectItem);
		else if( eval("item_arr"+bizid+".length") > 1)
			alert(msgOnlyOneItem);
		else
			worklist_SingleTaskComment(bizid, browsername, useAccessibility, eval("item_arr"+bizid+"[0]"));
	}
	else if (actionType == "mergeprocess")
	{
		if(parseInt(eval("item_arr"+bizid+".length")) == 0)
			alert(msgSelectItem);
		else if( eval("item_arr"+bizid+".length") != 2)
			alert(MSG_CMM_ONLY_TWO_SELECT_ITEM);
		else
			worklist_OpenMergeProcess(bizid, browsername, useAccessibility, eval("item_arr"+bizid+"[0]"), eval("item_arr"+bizid+"[1]"));
	}
	else if (actionType == "splitprocess")
	{
		if(parseInt(eval("item_arr"+bizid+".length")) == 0)
			alert(msgSelectItem);
		else if( eval("item_arr"+bizid+".length") > 1)
			alert(msgOnlyOneItem);
		else
			worklist_OpenSplitProcess(bizid, browsername, useAccessibility, eval("item_arr"+bizid+"[0]"));
	}
	else if (actionType == "custom1")
	{
		if(parseInt(eval("item_arr"+bizid+".length")) == 0)
			alert(msgSelectItem);
		else
			worklist_SingleCustom1(bizid);
	}
	else if (actionType == "custom2")
	{
		if(parseInt(eval("item_arr"+bizid+".length")) == 0)
			alert(msgSelectItem);
		else
			worklist_SingleCustom2(bizid);
	}
	else if (actionType == "custom3")
	{
		if(parseInt(eval("item_arr"+bizid+".length")) == 0)
			alert(msgSelectItem);
		else
			worklist_SingleCustom3(bizid);
	}
	else if (actionType == "custom4")
	{
		if(parseInt(eval("item_arr"+bizid+".length")) == 0)
			alert(msgSelectItem);
		else
			worklist_SingleCustom4(bizid);
	}
}	

function worklist_OpenExcel(bizid, browsername, useAccessibility)
{
    curBizID = bizid;
    var sUrl = contextPath + "/data/bizcoves/worklist/worklist_" +bizid+".jsp?isexcel=y"
						   + "&rtime=" + new Date().getMilliseconds()
						   + "&__bizcoveId=" + bizid;
	
    // bug22972: Excel export from worklist bizcove does not use 'Filter By' conditino. It always returns the result of 'All Work' (cs18202).
    sUrl = sUrl + "&wcat=" + eval("wcat" + bizid);

	var qsearch = getUrlValue(this.location, "qsearch");
	if(null != qsearch) {
		sUrl += "&qsearch=" + escape(qsearch);
	}

    thisLocationHref(sUrl);
}

// bug22820,cs18016: quick search
function callQuickSearchOnWorklist(bizid)
{
//	var task="search";
//	var qsearch = eval("document.worklistAction.qsearch.value");
//	qsearch = qsearch.replace(/%/g, '%25');
//	var newURL = contextPath + servletPath + "?bizcove="+ bizid + "&task="+task + "&qsearch="+ qsearch.replace(/ /g, '+');
//	location.href = newURL;
	document.worklistAction.submit();
}

function submitWI(bizid)
{
	passwordValue = "true";
	var objName_filter =  "'undefined' ==typeof(document.filterfrm_"+bizid+".filter)";
	var result_filter = eval(objName_filter);		
	var ResponseID = 0;	
	var ProcessID = "";
	var ServerID = "";
	var ActivityID = "";
	var WorkItemSeq = "";
	var Priority = "";
	var default_respid = ""
	var ExistSubmit = "";
	var RespIDs = "";
	var co, val, num;	
	var strLocation = "";
	var j, i;
	var arr_bizcoveid = "";
	var obj_arrBizCoves =  "'undefined' ==typeof(arrBizCoves)";
	var result_arrBizCoves = eval(obj_arrBizCoves);
	var CommentChecks = "";
	var CommentCheck = "F";
	var State = "";
	var ActivityInfo = "";

	if(result_arrBizCoves == false)
	{
		for (i = 0; i != arrBizCoves.length; ++i)
		{
			if ((arrBizCoves[i].type != "definition") && (arrBizCoves[i].id != bizid))
				arr_bizcoveid += ("&bizcove=" + arrBizCoves[i].id);
		}
	}

	strLocation = contextPath +  getBizcoveServletPath(bizid) + "?bizcove=" + bizid +  "&refresh=y" + arr_bizcoveid+"&osort="
					  + eval("curSortColName"+bizid) +"|"+eval("curSortDataType"+bizid) + "|";

	var serverURL = contextPath + "/_scriptlibrary/submitcomplete.jsp";
	var rsString ="parent.fralist.rsCallBackSubmit"+bizid;
	var k;

	for (k = 0 ; k < parseInt(eval("item_arr"+bizid+".length")) ; k++)
	{
		State = eval("item_arr" +bizid +"[k][7]");
		ActivityInfo = eval("item_arr"+bizid+"[k][13]");
		if ((0x08==(ActivityInfo & 0x08)) && ("P" != State)) //view
		{
			_ErrorMsg = MSG_WIH_REQUIRE_COMMENT_RESPONSE;
			continue;
		}
		if (0x10==(ActivityInfo & 0x10)) //add
			CommentCheck = "T";
		else
			CommentCheck = "F";

		ServerID = ServerID + eval("item_arr"+bizid+"[k][3]") + ";";
		ProcessID = ProcessID + eval("item_arr"+bizid+"[k][0]") + ";";
		ActivityID = ActivityID + eval("item_arr"+bizid+"[k][4]") + ";";
		WorkItemSeq = WorkItemSeq + eval("item_arr"+bizid+"[k][2]") + ";";
		Priority = Priority + eval("item_arr"+bizid+"[k][5]") + ";";
		default_respid = eval("item_arr" +bizid +"[k][6]");
		if ("" == default_respid)
			default_respid ="0";
		ResponseID = default_respid;
		num = eval("item_arr"+bizid+"[k][9]"); //get the number
		ExistSubmit = eval("item_arr" +bizid+"[k][10]");

		var objName = "'undefined' ==typeof(document.thedata_"+bizid+".selResponse" + num +")";
		var result = eval(objName);
		
		if (result == false)
		{							
			var form = eval("document.thedata_"+bizid);
			var filter = "form.selResponse" + num;
			var objFilter = eval(filter);
			var options = objFilter.options;
			var getval;
			var respId=0;
			var respInfo=0;

			for (i = 0; i != options.length; ++i)
			{
				if (options[i].selected)
				{
					getval = options[i].value.split(',');
					respId = getval[0];
					respInfo = getval[1];
					break;
				}
			}		
			ResponseID = respId;
			if ( respInfo > 0 )
			{
				CommentCheck = "T";
			}
		}

		if(ExistSubmit == false)
			ResponseID = default_respid;
		
		RespIDs = RespIDs + ResponseID + ";";
		CommentChecks = CommentChecks + CommentCheck + ";";
	}	
	
	RSExecute(rsString, serverURL, "Complete", ServerID, ProcessID, ActivityID, WorkItemSeq, RespIDs, Priority, CommentChecks);
}

function completeWI(bizid)
{	
	curbizID = bizid;
	var arrLen = eval("item_arr"+bizid+".length");
	var passwordFlag = "false";
	var isBizflow = "y";
	if(servletPath.indexOf("/portal/startpage")== -1)
		isBizflow = "n";

	var k;
	for (k = 0 ; k < arrLen; k++)
	{
		if ("T" == eval("item_arr"+bizid+"[k][8]"))
			passwordFlag = "true";
	}

	if (passwordFlag == "false")
	{
		for (k = 0 ; k < arrLen; k++)
		{
			if ("T" == eval("item_arr"+bizid+"[k][11]"))
				passwordFlag = "true";
		}
	}

	if (passwordFlag =="true")
	{
		passwordValue="false";
		actionType = "submit";
	
		var sUrl = contextPath + "/common/passwordframe.jsp?isbizflow" + isBizflow;
		wndPassword = ShowWindow(sUrl, "wndPassword", CHECKPASSWD, 300, 140, "no");
	}
	else 
		submitWI(bizid);
}

function worklist_SingleStorage(serverid, process, processName, sequence, activitysequence, priority, responseid, state, passwordflag_init, passwordflag_pref, position, bizid, actinfo)
{
	eval("item_arr_singleStorage"+bizid+"[0] = process");
	eval("item_arr_singleStorage"+bizid+"[1] = processName");
	eval("item_arr_singleStorage"+bizid+"[2] = sequence")
	eval("item_arr_singleStorage"+bizid+"[3] = serverid");
	eval("item_arr_singleStorage"+bizid+"[4] = activitysequence");
	eval("item_arr_singleStorage"+bizid+"[5] = priority");
	eval("item_arr_singleStorage"+bizid+"[6] = responseid");
	eval("item_arr_singleStorage"+bizid+"[7] = state");
	eval("item_arr_singleStorage"+bizid+"[8] = passwordflag_init");
	eval("item_arr_singleStorage"+bizid+"[9] = position");
	eval("item_arr_singleStorage"+bizid+"[10] = passwordflag_pref");
	eval("item_arr_singleStorage"+bizid+"[11] = actinfo");
}
function worklist_sel_item(serverid, process, processName, sequence, activitysequence, priority, responseid,
							state, passwordflag_init, passwordflag_pref, src, bizid, ExistSubmit, rowNum, actinfo, taskWbs, orgprocdefid)
{
	var i, j, k, inx, inxchkItemnum;
	
	if (src.checked) 
	{
		inxchkItemnum = src.name.substring(7);
		if (inxchkItemnum.length > 7) inxchkItemnum = inxchkItemnum.substring(7);
	
		inx = eval("item_arr"+bizid+".length");
		
		eval("item_arr"+bizid+"[inx] = new Array(12)");
		eval("item_arr"+bizid+"[inx][0] = process");
		eval("item_arr"+bizid+"[inx][1] = processName");
		eval("item_arr"+bizid+"[inx][2] = sequence");
		eval("item_arr"+bizid+"[inx][3] = serverid");
		eval("item_arr"+bizid+"[inx][4] = activitysequence");
		eval("item_arr"+bizid+"[inx][5] = priority");
		eval("item_arr"+bizid+"[inx][6] = responseid");
		eval("item_arr"+bizid+"[inx][7] = state");
		eval("item_arr"+bizid+"[inx][8] = passwordflag_init");
		eval("item_arr"+bizid+"[inx][9] = inxchkItemnum");
		eval("item_arr"+bizid+"[inx][10] = ExistSubmit");
		eval("item_arr"+bizid+"[inx][11] = passwordflag_pref");
		eval("item_arr"+bizid+"[inx][12] = rowNum");
		eval("item_arr"+bizid+"[inx][13] = actinfo");
        eval("item_arr"+bizid+"[inx][14] = taskWbs");
        eval("item_arr"+bizid+"[inx][15] = orgprocdefid");

	}
	else{
		for (i=0;i != parseInt(eval("item_arr"+bizid+".length"));i++){
			if (eval("item_arr"+bizid+"[i][0] == process")){
				for (j=i;j != parseInt(eval("item_arr"+bizid+".length")) -1;j++){
					k = j + 1;
					eval("item_arr"+bizid+"[j][0] = item_arr"+bizid+"[k][0]");
					eval("item_arr"+bizid+"[j][1] = item_arr"+bizid+"[k][1]");
					eval("item_arr"+bizid+"[j][2] = item_arr"+bizid+"[k][2]");
					eval("item_arr"+bizid+"[j][3] = item_arr"+bizid+"[k][3]");
					eval("item_arr"+bizid+"[j][4] = item_arr"+bizid+"[k][4]");
					eval("item_arr"+bizid+"[j][5] = item_arr"+bizid+"[k][5]");
					eval("item_arr"+bizid+"[j][6] = item_arr"+bizid+"[k][6]");
					eval("item_arr"+bizid+"[j][7] = item_arr"+bizid+"[k][7]");
					eval("item_arr"+bizid+"[j][8] = item_arr"+bizid+"[k][8]");
					eval("item_arr"+bizid+"[j][9] = item_arr"+bizid+"[k][9]");
					eval("item_arr"+bizid+"[j][10] = item_arr"+bizid+"[k][10]");
					eval("item_arr"+bizid+"[j][11] = item_arr"+bizid+"[k][11]");
					eval("item_arr"+bizid+"[j][12] = item_arr"+bizid+"[k][12]");
					eval("item_arr"+bizid+"[j][13] = item_arr"+bizid+"[k][13]");
                    eval("item_arr"+bizid+"[j][14] = item_arr"+bizid+"[k][14]");
                    eval("item_arr"+bizid+"[j][15] = item_arr"+bizid+"[k][15]");
                }

				eval("item_arr"+bizid+".length = item_arr"+bizid+".length-1");
				break;
			}
		}
	}
}
			
function sortCol(sURL, bizid, sortWarning, e)
{
     if(sortWarning != "yes" || confirm(MSG_CMM_SORT_MAY_BE_LATE))
     {
        var objName = "'undefined' ==typeof(document.filterfrm_"+bizid+".filter)";
        var result = eval(objName);
        sURL = sURL.replace("#", "%23");
        sURL += "&__bizcoveId=" + bizid;

        sURL = getBizCoveSortURL(sURL, e);
        sURL = adjustMaximizeURL(sURL, bizid); 

        if(result == false)
        {
            var form = eval("document.filterfrm_"+bizid);
            var filter = form.filter;
            var options = filter.options;
            var actname = "all";

            for (i = 0; i != options.length; ++i)
            {
                if (options[i].selected)
                {
                    actname = options[i].value;
                    break;
                }
            }

            actname= URLEncode(actname);

            if(actname=="all")
                location.href = sURL;
            else
                location.href = sURL + "&actname=" + actname;
        }
        else
        {
            objName = "'undefined' ==typeof(document.filterfrm_"+bizid+".filter_worklist)";
            result = eval(objName);
            if(result == false)
            {
                var form = eval("document.filterfrm_"+bizid);
                var filter = form.filter_worklist;
                var options = filter.options;
                var wcat = "all";

                if ("undefined" == typeof(options)) {
                    wcat = filter.value;
                } else {
                    for (i = 0; i != options.length; ++i)
                    {
                        if (options[i].selected)
                        {
                            wcat = options[i].value;
                            break;
                        }
                    }
				}
                wcat = URLEncode(wcat);

                if(wcat == "all")
                    location.href = sURL;
                else
                    location.href = sURL + "&wcat=" + wcat;
             }
             else
                location.href = sURL;
        }
    }
}

function getreturnSubmitVal(co_returns, browsername, bizid)
{
	var co_returnArr = co_returns.split(";");
	var co_return = co_returnArr[0];
	var co_message= co_returnArr[1];

	var objName_filter = "'undefined' ==typeof(document.filterfrm_"+bizid+".filter)";
	var result_filter = eval(objName_filter);

	var strLocation = contextPath +  getBizcoveServletPath(bizid) + "?bizcove=" + bizid;

	var i;
	var obj_arrBizCoves =  "'undefined' ==typeof(arrBizCoves)";
	var result_arrBizCoves = eval(obj_arrBizCoves);
	if(result_arrBizCoves == false)
	{
		for (i = 0; i != arrBizCoves.length; ++i)
		{
			if ((arrBizCoves[i].type != "definition") && (arrBizCoves[i].id != bizid))
				strLocation += ("&bizcove=" + arrBizCoves[i].id);
		}
	}
	strLocation += ("&refresh=y" + "&osort=" + eval("curSortColName"+bizid));
	strLocation += ("|"+ eval("curSortDataType"+bizid) + "|" + eval("curSortDirection"+bizid));
	strLocation += "&__bizcoveId=" + bizid;

    strLocation = adjustMaximizeURL(strLocation, bizid);

    if(eval("curSortDataType"+bizid) == "" || eval("curSortDataType"+bizid)== null)
		eval("curSortDataType"+bizid +"= 's'");

	if (co_return != "0")
	{		
		if(co_return == "3101" || co_return == "3103")
		{
			if(servletPath.indexOf("/portal/startpage")== -1)
			{	
				if(co_return =="3103")
					alert(msgErrorSessionDisconnected);
				else(co_return ="3103")
					alert( msgErrorSessionExpired);
			}
		}
		else if(co_return =="19852")
			alert(msgErrorInvalidSessionInfo);
		else if(co_return =="4031")
			alert(msgErrorAlreadyCompleted);
		else if(co_return =="MSG")
		{
			if(co_message == "MSG_PI_COMPLETE_BATCH_FAIL_FOR_MANDATORY_APP")
				alert(MandatoryApplicationExists);
			else if(co_message == "MSG_WIH_REQUIRE_COMMENT_RESPONSE")
				alert(MSG_WIH_REQUIRE_COMMENT_RESPONSE);
			else
				alert(co_message);
		}
		else
			alert("["+ co_message +"] ");
	}
	else if ("" != _ErrorMsg)
	{
		alert(_ErrorMsg);
		_ErrorMsg = "";
	}

	if(result_filter == false)
	{

		var form = eval("document.filterfrm_"+bizid);
		var filter = form.filter;
		var options = filter.options;
		var actname = "all";

		for (i = 0; i != options.length; ++i)
		{
			if (options[i].selected)
			{
				actname = options[i].value;
				break;
			}
		}
		actname = URLEncode(actname);

		if(actname== "all")
			location.href = strLocation + "&ap="+ eval("curpage"+bizid)+ "&rmsrch=y";
		else if(actname!="all")
			location.href = strLocation + "&actname="+ actname+"&ap="+ eval("curpage"+bizid);
	}
	else
	{
		objName_filter =  " 'undefined' ==typeof(document.filterfrm_"+bizid+".filter_worklist)";
		result_filter = eval(objName_filter);

		if(result_filter == false)
		{
			var form = eval("document.filterfrm_"+bizid);
			var filter = form.filter_worklist;
			var options = filter.options;
			var wcat = "all";

            if ("undefined" == typeof(options)) {
                wcat = filter.value;
            } else {
                for (i = 0; i != options.length; ++i) {
                    if (options[i].selected) {
                        wcat = options[i].value;
                        break;
                    }
                }
            }

			wcat = URLEncode(wcat);

			if(wcat == "all")
				location.href = strLocation + "&ap="+eval("curpage"+bizid)+ "&rmsrch=y";
			else
				location.href = strLocation + "&wcat=" +wcat+"&ap="+eval("curpage"+bizid);
		}
		else
			location.href = strLocation + "&ap="+ eval("curpage"+bizid)+ "&rmsrch=y";
	}
}

function getreturnForwardVal(arr, browsername, bizid, userName, deptName)
{
	var strURL = contextPath +  getBizcoveServletPath(bizid) + "?bizcove="+bizid + "&refresh=y" + "&__bizcoveId=" + bizid;
    strURL = adjustMaximizeURL(strURL, bizid);
    
    if (arr[0] == "0")
	{
		if(userName != "")
			alert(userName + " " + MSG_FORWARD_SUCCESS);   
		else if(deptName != "")
			alert(deptName + " " + MSG_FORWARD_SUCCESS); 
	   location.href= strURL;			
	}
	else
	{
		var errorNumber = parseInt(arr[0]);
		var errorDescription;

		if (errorNumber == 4030)
			errorDescription = ERROR_ALREADY_CHECKOUT;
		else
		{
			errorDescription = ERROR_FORWARD_FAIL;
		}

		alert("[" + arr[0] + "] " + errorDescription);
		
		location.href= strURL;
	}
}

function getreturnSubmitRejectVal(arr, browsername, bizid)
{
	objName_filter =  " 'undefined' ==typeof(document.filterfrm_"+bizid+".filter_worklist)";
	result_filter = eval(objName_filter);
	wcat = "all";
	
	if(result_filter == false)
	{
		var form = eval("document.filterfrm_"+bizid);
		var filter = form.filter_worklist;
		var options = filter.options;
		var wcat = "all";

        if ("undefined" == typeof(options)) {
            wcat = filter.value;
        } else {
            for (i = 0; i != options.length; ++i) {
                if (options[i].selected) {
                    wcat = options[i].value;
                    break;
                }
            }
        }
	
		wcat = URLEncode(wcat);
	}
	
	var strURL = contextPath +  getBizcoveServletPath(bizid) + "?bizcove="+bizid + "&wcat=" + wcat + "&refresh=y" + "&__bizcoveId=" + bizid;
    strURL = adjustMaximizeURL(strURL, bizid);
		
    if (arr[0] != "0")
	{
		var errorNumber = parseInt(arr[0]);
		var errorDescription;
		
		if (errorNumber == '4080')
			errorDescription = msgErrorCannotRejectWorkitem;
		else if (errorNumber == '4065')
			errorDescription = msgErrorCannotUseRejectAndRecall;
		else if (errorNumber == '4066')
			errorDescription = msgErrorNoTrackingInformationToRejectAndRecall;
		else if (errorNumber == '4085')
			errorDescription = msgErrorCannotRejectWorkitem_4085;
		else if (arr[1] == "MSG_WIH_REQUIRE_COMMENT_RESPONSE")
			errorDescription = MSG_WIH_REQUIRE_COMMENT_RESPONSE
		else
			errorDescription = msgRejectFailed;
		
		if (arr[1] == "MSG_WIH_REQUIRE_COMMENT_RESPONSE")
			alert(errorDescription);
		else
			alert("[" + arr[0] + "] " + errorDescription);
	}
	
	location.href= strURL;
}

function getreturnSubmitRecallVal(arr, browsername, bizid)
{
	objName_filter =  " 'undefined' ==typeof(document.filterfrm_"+bizid+".filter_worklist)";
	result_filter = eval(objName_filter);
	wcat = "all";
	
	if(result_filter == false)
	{
		var form = eval("document.filterfrm_"+bizid);
		var filter = form.filter_worklist;
		var options = filter.options;
		var wcat = "all";

        if ("undefined" == typeof(options)) {
            wcat = filter.value;
        } else {
            for (i = 0; i != options.length; ++i) {
                if (options[i].selected) {
                    wcat = options[i].value;
                    break;
                }
            }
        }
	
		wcat = URLEncode(wcat);
	}
	
	var strURL = contextPath +  getBizcoveServletPath(bizid) + "?bizcove="+ bizid + "&wcat=" + wcat + "&refresh=y" + "&__bizcoveId=" + bizid;
    strURL = adjustMaximizeURL(strURL, bizid);

    if (arr[0] != "0")
	{
		var errorNumber = parseInt(arr[0]);
		var errorDescription;
		
		if (errorNumber == '4070')
			errorDescription = msgErrorCannotRecallWorkitem;
		else if (errorNumber == '4065')
			errorDescription = msgErrorCannotUseRejectAndRecall;
		else if (errorNumber == '4066')
			errorDescription = msgErrorNoTrackingInformationToRejectAndRecall;
		else if (errorNumber == '4071')
			errorDescription = msgErrorCannotRecallUncompletedWorkitem;
		else
			errorDescription = msgRecallFailed;
		
		alert("[" + arr[0] + "] " + errorDescription);
	}
	
	location.href= strURL;
}
