var wndUserInfo;
function getPrefixURL(contextPath)
{
    return contextPath;
//	var url = "" + this.location.href;
//	var relatedStr = "";
//
//	var idx = url.indexOf(contextPath);
//	if(idx >= 0)
//	{
//		idx += contextPath.length +1;
//		var count = 0;
//
//		idx = url.indexOf("/", idx);
//		while(idx > 0)
//		{
//			if(relatedStr.length > 0) relatedStr += "/";
//			relatedStr += "..";
//			count++;
//			idx = url.indexOf("/", idx+1);
//		}
//	}
//
//	if(relatedStr.length == 0) relatedStr = ".";
//	return relatedStr;
}

function openUserInfoWindow(contextPath, userID, userName, serverid)
{
	var sUrl = contextPath + "/bizcoves/common/userinfo.jsp?userid=" + userID + "&serverid=" + serverid + "&now=" + (new Date).getTime();
	
	if (null == serverid)
	    sUrl = contextPath + "/bizcoves/common/userinfo.jsp?userid=" + userID + "&now=" + (new Date).getTime();


	wndUserInfo = openPopup(sUrl, "", "wndOrgUserInfo", 460, 235);
}


function openUserInfoModal(contextPath, userID, userName, serverid)
{
    var sUrl = contextPath + "/bizcoves/common/userinfo.jsp?userid=" + userID + "&serverid=" + serverid + "&now=" + (new Date).getTime();

    if (null == serverid)
        sUrl = contextPath + "/bizcoves/common/userinfo.jsp?userid=" + userID + "&isForcedModal=true&now=" + (new Date).getTime();

    wndUserInfo = openModalPopup(sUrl, "", "wndOrgUserInfo", 460, 235, true);
}

function openDetailUserInfoWindow(contextPath, userID, deptID)
{
	var deptid = deptID;
	var sUrl = contextPath + "/bizcoves/genadmin/orguserdetails.jsp?mode=view&haction=modify&first=t&hdeptID="+deptid+"&huserID="+userID + "&now=" + (new Date).getTime();
    openPopup(sUrl, "", "ModifyUser", 500, 300);
}