function filter_name(bizid)
{
	var form = eval("document.filterfrm_"+bizid);
	var filter = form.filter;
	var options = filter.options;
	var actname = "";

	for (i = 0; i != options.length; ++i)
	{
		if (options[i].selected)
		{
			actname = options[i].value;
			break;
		}
	}

	if(actname=="all")
	{
		if(bizid.length ==10)
			location.href = contextPath +  getBizcoveServletPath(bizid) + "?bizcove=" + bizid + "&ap=1"+"&preview_bizcove=y&rmsrch=y&refresh=y";
		else
			location.href = contextPath +  getBizcoveServletPath(bizid) + "?bizcove=" + bizid + "&ap=1"+"&rmsrch=y&refresh=y";
	}
	else
	{
		actname = URLEncode(actname);
		if(bizid.length == 10)
			location.href  = contextPath +  getBizcoveServletPath(bizid) + "?bizcove="
						+ bizid + "&ap=1"+"&actname="+actname+"&preview_bizcove=y&osort="
						+ eval("curSortColName"+bizid)+"|"+eval("curSortDataType"+bizid) + "|" + eval("curSortDirection"+bizid) ;
		else
			location.href  =contextPath +  getBizcoveServletPath(bizid) + "?bizcove="
						+ bizid + "&ap=1"+"&actname="+actname+"&osort="
						+ eval("curSortColName"+bizid)+"|"+eval("curSortDataType"+bizid) + "|" + eval("curSortDirection"+bizid) ;
	}
}

function filterWorklist(bizid, value)
{
	var wcat = value;

	wcat = URLEncode(wcat);

    var sURL = contextPath +  getBizcoveServletPath(bizid) + "?bizcove=" + bizid;
    sURL = adjustMaximizeURL(sURL, bizid);

    if(wcat == "all")
	{
        // bug24587: Use 'wcat=all' go back to 'All Work'
		if(bizid.length == 10)
			sURL += "&ap=1"+"&wcat=all&preview_bizcove=y&rmsrch=y&refresh=y&__bizcoveId=" + bizid;
		else
			sURL +=  "&ap=1"+"&wcat=all&rmsrch=y&refresh=y&__bizcoveId=" + bizid;

        location.href = sURL;
    }
	else
	{
		if(bizid.length ==10)
			sURL += "&preview_bizcove=y&ap=1"+"&wcat="+wcat+"&refresh=y&osort="
						+ eval("curSortColName"+bizid)+"|"+eval("curSortDataType"+bizid) + "|" + eval("curSortDirection"+bizid) 
						+ "&__bizcoveId=" + bizid;
		else
			sURL += "&ap=1"+"&wcat="+wcat+"&refresh=y&osort="
						+ eval("curSortColName"+bizid)+"|"+eval("curSortDataType"+bizid) + "|" + eval("curSortDirection"+bizid)
						+ "&__bizcoveId=" + bizid;

        location.href = sURL;
    }
}

function worklist_Open(bizid, browsername, useAccessibility)
{
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}
	tmpUseAccessibility = useAccessibility;
	var serverid, processid, workseq, activityseq, priority, responseid, passwordflag_init, passwordflag_pref;
	serverid = eval("item_arr_singleStorage"+bizid+"[3]");
	processid = eval("item_arr_singleStorage"+bizid+"[0]");
	workseq = eval("item_arr_singleStorage"+bizid+"[2]");
	activityseq = eval("item_arr_singleStorage"+bizid+"[4]");
	priority = eval("item_arr_singleStorage"+bizid+"[5]");
	responseid = eval("item_arr_singleStorage"+bizid+"[6]");
	passwordflag_init = eval("item_arr_singleStorage"+bizid+"[8]"); 
	passwordflag_pref = eval("item_arr_singleStorage"+bizid+"[10]");
    curWorkIndex = prevWorkCount + parseInt(eval("item_arr_singleStorage"+bizid+"[9]"));
	openWIH_worklistLink(serverid, processid, workseq, activityseq, priority, responseid, passwordflag_init, passwordflag_pref, "complete", bizid);
}
				
function worklist_Viewapp(bizid, browsername, useAccessibility)
{
	var mode = "view";
	var isBizflow = "y";
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}
	tmpUseAccessibility = useAccessibility;

	if(servletPath.indexOf("/portal/startpage")== -1)
		isBizflow = "n";

	var passwordflag_init = eval("item_arr_singleStorage"+bizid+"[8]");

	if("T" == passwordflag_init)
	{
		passwordValue = "false";
		actionType = mode;
		var sUrl = contextPath + "/common/passwordframe.jsp?isbizflow="+isBizflow + "&__bizcoveId=" + bizid;
		wndPassword = ShowWindowEx2(contextPath, sUrl, "wndPassword", CHECKPASSWD, 300, 140, "no");
	}
	else if("F" == eval("item_arr_singleStorage"+bizid+"[8]"))
		passwordValue = "true";
	if ("true" == passwordValue)
	{
		getWIHInfoString();		
		var sUrl =  contextPath +"/work/wih.jsp?sid=" 
					+ eval("item_arr_singleStorage"+bizid+"[3]") + "&pid=" 
					+ eval("item_arr_singleStorage"+bizid+"[0]") + "&seq=" 
					+ eval("item_arr_singleStorage"+bizid+"[2]") + "&asq=" 
					+ eval("item_arr_singleStorage"+bizid+"[4]") + "&pro=" 
					+ eval("item_arr_singleStorage"+bizid+"[5]") + "&rid=" 
					+ eval("item_arr_singleStorage"+bizid+"[6]") + "&time=" 
					+ now.getTime() + "&openpage=page" + "&mode=" 
					+ mode+"&bizcovecall=y" + "&__bizcoveId=" + bizid;
		var sFeatures = "status=yes,toolbar=no,resizable=yes,scrollbars=yes";
		wndWIH = window.open(sUrl, "Complete", sFeatures);
		if(!useAccessibility) {
			refreshWhenWIHWindowClosed(bizid);
		}
	}
}

function worklist_OpenSearch(bizID, browsername, useAccessibility)
{
	var sURL = contextPath + "/bizcoves/user/search.jsp?bizcoveID="+bizID+"&first=t&type=worklist" + "&__bizcoveId=" + bizID;
    var ugURL = window.location.href;
    var pos = ugURL.indexOf("_UG");
    if (pos != -1)
    {
        var ugid = ugURL.substring(pos+3, pos+13);
        sURL += "&ugid=" + ugid;
    }

    openPopup(sURL, "", "Search", 780, 300, true, false);
}

function worklist_OpenForward(bizid, browsername, useAccessibility)
{
	curbizID = bizid;
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}
	tmpUseAccessibility = useAccessibility;

	if ("false" == isAuthorizedForward)
		alert (msg_no_auth_forward);
	else
	{
		var checkValue = "F";
		var isBizflow = "y";

		if(servletPath.indexOf("/portal/startpage")== -1)
			 isBizflow = "n";

		var passwordflag_init = eval("item_arr_singleStorage"+bizid+"[8]");

		if("T" == passwordflag_init)
			checkValue = "T";

		if ("T" == checkValue)
		{
			passwordValue="false";
			actionType = "forward"; 
			var sUrl =  contextPath + "/common/passwordframe.jsp?isbizflow="+isBizflow;
			wndPassword = ShowWindowEx2(contextPath, sUrl, "wndPassword", CHECKPASSWD, 300, 140, "no"); 
		}
		else if ("F" == checkValue)
		{   
			if(eval("item_arr_singleStorage"+bizid+"[7]") == "C")
				alert(msgAlreadyCompleted);
			else
				singleForward(bizid, browsername);
		}
	}
}

var issinglestorage = "";
function singleForward(bizid, browsername)
{
	var isBizflow = "y";
	var procID = eval("item_arr_singleStorage"+bizid+"[0]");
	var actseq = eval("item_arr_singleStorage"+bizid+"[4]");
	var wseq = eval("item_arr_singleStorage"+bizid+"[2]");

	if(servletPath.indexOf("/portal/startpage")== -1)
		isBizflow = "n";

	passwordValue = "true";
	//var sUrl =  contextPath + "/portal/common/selectuserbody.jsp?rf=y&chkabsent=y" + "&__bizcoveId=" + bizid;
	var sUrl = contextPath + "/work/forwardworkitem.jsp?pid=" + procID + "&aseq=" + actseq + "&wseq=" + wseq + "&__bizcoveId=" + bizid;
	issinglestorage = "y";
	forwardBizID = bizid;
	if ("PIE" != browsername)
	{		
		wndWorkOrg = ShowWindow(sUrl, "OpenOrg",  ORGANIZATION, 502, 500, "yes");
	}
	else
	{
		top.location.href = sUrl + "&pid=" + procID + "&aseq=" + actseq + "&wseq=" + wseq;
	}
}

function  worklist_Submit(bizid, browsername, useAccessibility)
{ 
	curbizID = bizid;
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}
	tmpUseAccessibility = useAccessibility;

	var passwordflag_init = eval("item_arr_singleStorage"+bizid+"[8]");
	var passwordflag_pref = eval("item_arr_singleStorage"+bizid+"[10]");
	var isBizflow = "y";

	if(servletPath.indexOf("/portal/startpage")== -1)
		isBizflow = "n";

	var passwordcheck= "F";
	if(passwordflag_init == "T")
		passwordcheck = "T";
	else if(passwordflag_pref == "T")
		passwordcheck = "T";

	if("T" == passwordcheck)
	{
		passwordValue="false";
		actionType = "singlesubmit";
	   
		var sUrl = contextPath + "/common/passwordframe.jsp?isbizflow" + isBizflow;
		wndPassword = ShowWindow(sUrl, "wndPassword",  CHECKPASSWD, 300, 140, "no");
	}
	else if("F" == passwordcheck)
		singleSubmit(bizid);
}

function singleSubmit(bizid)
{
	passwordValue = "true";
	var rsString ="parent.fralist.rsCallBackSubmit"+bizid;
	var ServerID, ProcessID, ActivityID, WorkItemSeq,  Priority;
	var ResponseID = 0;
	var CommentCheck = "F";
	var ActivityInfo = 0;
	var State;
	var num;
	var serverURL =  contextPath + "/_scriptlibrary/submitcomplete.jsp";
	ServerID = eval("item_arr_singleStorage"+bizid+"[3]");
	ProcessID = eval("item_arr_singleStorage"+bizid+"[0]");
	ActivityID = eval("item_arr_singleStorage"+bizid+"[4]");
	WorkItemSeq = eval("item_arr_singleStorage"+bizid+"[2]");
	Priority = eval("item_arr_singleStorage"+bizid+"[5]");
	State = eval("item_arr_singleStorage"+bizid+"[7]");
	num = eval("item_arr_singleStorage"+bizid+"[9]"); //get the number
	ActivityInfo =  eval("item_arr_singleStorage"+bizid+"[11]");

	if ((0x08==(ActivityInfo & 0x08)) && ("P" != State)) //view
	{
		alert(MSG_WIH_REQUIRE_COMMENT_RESPONSE);
		return;
	}
	if (0x10==(ActivityInfo & 0x10)) //add
	{
		CommentCheck = "T";
	}

	var objName = "'undefined' ==typeof(document.thedata_"+bizid+".selResponse" + num +") ";
	var result = eval(objName);

	if(result == false)
	{   
		var form = eval("document.thedata_"+bizid);
		var filter = "form.selResponse" + num;
		var objFilter = eval(filter);
		var options = objFilter.options;
		var getval;
		var respId=0;
		var respInfo=0;

		for (i = 0; i != options.length; ++i)
		{
			if (options[i].selected)
			{
				getval = options[i].value.split(',');
				respId = getval[0];
				respInfo = getval[1];
				break;
			}
		}
		ResponseID = respId;
		if ( respInfo > 0 )
		{
			CommentCheck = "T";
		}
	}
	
	 RSExecute(rsString, serverURL, "Complete", ServerID, ProcessID, ActivityID, WorkItemSeq, ResponseID, Priority, CommentCheck);
}

function submit_worklistReject(bizid, isSingle)
{
	passwordValue="true";
	var rsString ="parent.fralist.rsCallBackSubmitReject"+bizid;
	var ServerID, ProcessID, ActivityID, WorkItemSeq;
	var CommentCheck = "F";
	var ActivityInfo = 0;
	var serverURL =  contextPath + "/_scriptlibrary/submitreject.jsp";
	
	if (isSingle)
	{
		ServerID = eval("item_arr_singleStorage" +bizid + "[3]");
		ProcessID = eval("item_arr_singleStorage" +bizid + "[0]");
		ActivityID = eval("item_arr_singleStorage" +bizid + "[4]");
		WorkItemSeq = eval("item_arr_singleStorage" +bizid + "[2]");
		ActivityInfo =  eval("item_arr_singleStorage" +bizid + "[11]");
	}
	else
	{	
		ServerID = eval("item_arr" +bizid + "[0][3]");
		ProcessID = eval("item_arr" +bizid + "[0][0]");
		ActivityID = eval("item_arr" +bizid + "[0][4]");
		WorkItemSeq = eval("item_arr" +bizid + "[0][2]");
		ActivityInfo =  eval("item_arr" +bizid + "[0][13]");
	}
	
	if ((0x02 == (ActivityInfo & 0x02)) && (0x04 == (ActivityInfo & 0x04)))
	{
		CommentCheck = "T";
	}
	
	RSExecute(rsString, serverURL, "reject", ServerID, ProcessID, ActivityID, WorkItemSeq, CommentCheck);
}

function submit_worklistRecall(bizid, isSingle)
{
	passwordValue="true";
	var rsString ="parent.fralist.rsCallBackSubmitRecall"+bizid;
	var ServerID, ProcessID, ActivityID, WorkItemSeq;
	var CommentCheck = "F";
	var ActivityInfo = 0;
	var serverURL =  contextPath + "/_scriptlibrary/submitrecall.jsp";
	
	if (isSingle)
	{
		ServerID = eval("item_arr_singleStorage" +bizid + "[3]");
		ProcessID = eval("item_arr_singleStorage" +bizid + "[0]");
		ActivityID = eval("item_arr_singleStorage" +bizid + "[4]");
		WorkItemSeq = eval("item_arr_singleStorage" +bizid + "[2]");
		ActivityInfo =  eval("item_arr_singleStorage" +bizid + "[11]");
	}
	else
	{	
		ServerID = eval("item_arr" +bizid + "[0][3]");
		ProcessID = eval("item_arr" +bizid + "[0][0]");
		ActivityID = eval("item_arr" +bizid + "[0][4]");
		WorkItemSeq = eval("item_arr" +bizid + "[0][2]");
		ActivityInfo =  eval("item_arr" +bizid + "[0][13]");
	}
	
	RSExecute(rsString, serverURL, "recall", ServerID, ProcessID, ActivityID, WorkItemSeq);
}

function worklist_Reject(bizid)
{
	curbizID = bizid;
	var passwordflag_init = eval("item_arr"+bizid+"[0][8]");
	var passwordflag_pref = eval("item_arr"+bizid+"[0][11]");
	var passwordcheck= "F";
	var isBizflow = "y";
	var isSingle = false;
	
	if(servletPath.indexOf("/portal/startpage")== -1)
		isBizflow = "n";
	
	if (parseInt(eval("item_arr"+bizid+".length")) == 0)
		alert(msgSelectItem);
	else if (parseInt(eval("item_arr"+bizid+".length")) == 1)
	{
		if(passwordflag_init == "T")
			passwordcheck = "T";
		else if (passwordflag_pref == "T")
			passwordcheck = "T";
			
		if (passwordcheck == "T")
		{
			passwordValue="false";
			actionType = "reject";
			
			var sUrl = contextPath + "/common/passwordframe.jsp?isbizflow" + isBizflow;
			wndPassword = ShowWindow(sUrl, "wndPassword",  CHECKPASSWD, 300, 140, "no");
		}
		else
			submit_worklistReject(bizid, isSingle);
	}
	else
		alert(msgOnlyOneItem);
}

function worklist_Recall(bizid)
{
	curbizID = bizid;
	var passwordflag_init = eval("item_arr"+bizid+"[0][8]");
	var passwordflag_pref = eval("item_arr"+bizid+"[0][11]");
	var passwordcheck= "F";
	var isBizflow = "y";
	var isSingle = false;
	
	if(servletPath.indexOf("/portal/startpage")== -1)
		isBizflow = "n";
	
	if (parseInt(eval("item_arr"+bizid+".length")) == 0)
		alert(msgSelectItem);
	else if (parseInt(eval("item_arr"+bizid+".length")) == 1)
	{
		if(passwordflag_init == "T")
			passwordcheck = "T";
		else if (passwordflag_pref == "T")
			passwordcheck = "T";
			
		if (passwordcheck == "T")
		{
			passwordValue="false";
			actionType = "recall";
			
			var sUrl = contextPath + "/common/passwordframe.jsp?isbizflow" + isBizflow;
			wndPassword = ShowWindow(sUrl, "wndPassword",  CHECKPASSWD, 300, 140, "no");
		}
		else
			submit_worklistRecall(bizid, isSingle);
	}
	else
		alert(msgOnlyOneItem);
}

function worklist_SingleReject(bizid, browsername, useAccessibility)
{
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}
	tmpUseAccessibility = useAccessibility;
	curbizID = bizid;
	var passwordflag_init = eval("item_arr_singleStorage"+bizid+"[8]");
	var passwordflag_pref = eval("item_arr_singleStorage"+bizid+"[10]");
	var passwordcheck= "F";
	var isBizflow = "y";
	var isSingle = true;
	
	if(servletPath.indexOf("/portal/startpage")== -1)
		isBizflow = "n";
		
	
	if(passwordflag_init == "T")
		passwordcheck = "T";
	else if (passwordflag_pref == "T")
		passwordcheck = "T";
		
	if (passwordcheck == "T")
	{
		passwordValue="false";
		actionType = "reject";
		
		var sUrl = contextPath + "/common/passwordframe.jsp?isbizflow" + isBizflow;
		wndPassword = ShowWindow(sUrl, "wndPassword",  CHECKPASSWD, 300, 140, "no");
	}
	else
		submit_worklistReject(bizid, isSingle);	
}

function worklist_SingleRecall(bizid, browsername, useAccessibility)
{
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}
	tmpUseAccessibility = useAccessibility;
	curbizID = bizid;
	var passwordflag_init = eval("item_arr_singleStorage"+bizid+"[8]");
	var passwordflag_pref = eval("item_arr_singleStorage"+bizid+"[10]");
	var passwordcheck= "F";
	var isBizflow = "y";
	var isSingle = true;
	
	if(servletPath.indexOf("/portal/startpage")== -1)
		isBizflow = "n";
		
	
	if(passwordflag_init == "T")
		passwordcheck = "T";
	else if (passwordflag_pref == "T")
		passwordcheck = "T";
		
	if (passwordcheck == "T")
	{
		passwordValue="false";
		actionType = "recall";
		
		var sUrl = contextPath + "/common/passwordframe.jsp?isbizflow" + isBizflow;
		wndPassword = ShowWindow(sUrl, "wndPassword",  CHECKPASSWD, 300, 140, "no");
	}
	else
		submit_worklistRecall(bizid, isSingle);	
}
function worklist_SingleTaskComment(bizID, browsername, useAccessibility, selectedObj)
{
	var isBizflow = "y";
	if(servletPath.indexOf("/portal/startpage")== -1)
		isBizflow = "n";

	var procID;
	var actseq;
	var wseq;
	if(typeof(selectedObj) == 'undefined')
	{
		procID = eval("item_arr_singleStorage"+bizID+"[0]");
		actseq = eval("item_arr_singleStorage"+bizID+"[4]");
		wseq = eval("item_arr_singleStorage"+bizID+"[2]");
	}
	else
	{
		procID = selectedObj[0];
		actseq = selectedObj[4];
		wseq = selectedObj[2];
	}

	var sUrl =  contextPath + "/bizcoves/wih/taskcomment.jsp?&__bizcoveId=" + bizID + "&procid=" + procID + "&actseq=" + actseq;
    openPopup(sUrl, "", "Comments", 800, "600", true, false);
}
function worklist_OpenMergeProcess(bizID, browsername, useAccessibility, selectedObj1, selectedObj2)
{
	var isBizflow = "y";
	if(servletPath.indexOf("/portal/startpage")== -1)
		isBizflow = "n";

	var procid;
	var linkedprocid;
	if(typeof(selectedObj1) == 'undefined')
	{
		procid = eval("item_arr_singleStorage"+bizID+"[0]");
	}
	else
	{
		procid = selectedObj1[0];
	}
	if(typeof(selectedObj2) == 'undefined')
	{
		linkedprocid = eval("item_arr_singleStorage"+bizID+"[1]");
	}
	else
	{
		linkedprocid = selectedObj2[0];
	}

    var sUrl = contextPath + "/instance/merge.jsp?pid=" + procid + "&lpid=" + linkedprocid + "&__bizcoveId=" + bizID;
    openPopup(sUrl, "", "MergeProcess", 520, 270, true, false);
}

function worklist_OpenSplitProcess(bizID, browsername, useAccessibility, selectedObj)
{
	var isBizflow = "y";
	if(servletPath.indexOf("/portal/startpage")== -1)
		isBizflow = "n";

	var procid;
	if(typeof(selectedObj) == 'undefined')
	{
		procid = eval("item_arr_singleStorage"+bizID+"[0]");
	}
	else
	{
		procid = selectedObj[0];
	}

    var sUrl = contextPath + "/instance/split.jsp?pid=" + procid + "&__bizcoveId=" + bizID;
    openPopup(sUrl, "", "SplitProcess", 520, 270, true, false);
}
