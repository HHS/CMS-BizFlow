var tmpUseAccessibility = false;
function URLEncode(s)
{
	if (!BrowserDetect.isExplorer())
		return escape(s);

	var escaped = "";
	var len = s.length;
	var code;

	for (i = 0; i != len; ++i)
	{
		code = s.charCodeAt(i);

		if (code < 256)
			escaped += escape(s.charAt(i));
		else
			escaped += s.charAt(i);
	}

	return escaped;
}

function get_Action(type, bizid, browsername, useAccessibility)
{
	tmpUseAccessibility = useAccessibility;
	if(type=="start")
		InitiateDef(bizid, browsername);
	else if(type == "view" || type == "cpview")
		ViewDef(bizid, browsername, type);
    	else if(type == "excel")
		definition_OpenExcel(bizid, browsername, useAccessibility)
	else if (type == "custom1")
	{
		if(parseInt(eval("def_item_arr"+bizid+".length")) > 1)
			alert(msgCmmOnlyOneSelectItem);
		else if(parseInt(eval("def_item_arr"+bizid+".length")) == 0 )
			alert(msgCmmSelectItem);
		else
			definition_SingleCustom1(bizid, browsername);
	}
	else if (type == "custom2")
	{
		if(parseInt(eval("def_item_arr"+bizid+".length")) > 1)
			alert(msgCmmOnlyOneSelectItem);
		else if(parseInt(eval("def_item_arr"+bizid+".length")) == 0 )
			alert(msgCmmSelectItem);
		else
			definition_SingleCustom2(bizid, browsername);
	}
	else if (type == "custom3")
	{
		if(parseInt(eval("def_item_arr"+bizid+".length")) > 1)
			alert(msgCmmOnlyOneSelectItem);
		else if(parseInt(eval("def_item_arr"+bizid+".length")) == 0 )
			alert(msgCmmSelectItem);
		else
			definition_SingleCustom3(bizid, browsername);
	}
	else if (type == "custom4")
	{
		if(parseInt(eval("def_item_arr"+bizid+".length")) > 1)
			alert(msgCmmOnlyOneSelectItem);
		else if(parseInt(eval("def_item_arr"+bizid+".length")) == 0 )
			alert(msgCmmSelectItem);
		else
			definition_SingleCustom4(bizid, browsername);
	}
}

function definition_OpenExcel(bizid, browsername, useAccessibility)
{
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}
	tmpUseAccessibility = useAccessibility;
	curBizID = bizid;
	var sUrl = contextPath + "/data/bizcoves/definition/definition_" +bizid+".jsp?isexcel=y"
						   + "&rtime=" + new Date().getMilliseconds()
						   + "&__bizcoveId=" + bizid;

    thisLocationHref(sUrl);
}

function initiateCustomOE(procID) {
	if(officeEngine_customJSONArray.length > 0 ) {
		for(var i=0; i <officeEngine_customJSONArray.length; i++) {
			if(officeEngine_customJSONArray[i].customDefID == procID) {
		        if (officeEngineAuthority) {
		        	var oeUrl = "/" + officeEngine_customJSONArray[i].customModulePath + "/";
					oeUrl.replace(/\/\//g,"/")
		            openPopup(contextPath + oeUrl + "/task/initiatetask.jsp", "", "wndInitiateForm", "100%", "100%", true, true);
		        }
		        else {
		            alert(MSG_MNG_NO_LICENSE);
		        }
		        return true;
			}
		}
	}
	return false;
}

function definition_Start(bizid, browsername, useAccessibility)
{
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}
	tmpUseAccessibility = useAccessibility;
	var procID, procName, fid, state;
	procID = eval("def_item_arr_ss"+bizid+"[0]");
	procName = eval("def_item_arr_ss"+bizid+"[1]");
	fid = eval("def_item_arr_ss"+bizid+"[2]");
	state = eval("def_item_arr_ss"+bizid+"[3]");
	var enableInitWindow = eval ("useinitWindow" + bizid);

    if (officeEngine_DefId == procID)
    {
        if (officeEngineAuthority)
            openPopup(contextPath + officeEngineURL + "/task/initiatetask.jsp", "", "wndInitiateForm", "100%", "100%", true, true);
        else
            alert(MSG_MNG_NO_LICENSE);
    }
    else if (officeEngineExt_DefId == procID)
    {
        if (officeEngineAuthority)
            openPopup(contextPath + "/webdesign/newtask", "", "wndInitiateForm", 860, 742, true, true);
        else
            alert(MSG_MNG_NO_LICENSE);
    }
    else
    {
    	if(initiateCustomOE(procID)) {
    		return false;
    	}
        if(enableInitWindow=="yes" && "PIE" != browsername)
            openInitProcessWindow(bizid, procID, state, fid, "1", "2146959359");
        else
            Initiate(procID, "T", bizid);
    }
}

function InitiateDef(bizid, browsername)
{
	if(parseInt(eval("def_item_arr"+bizid+".length")) > 1)
		alert(msgCmmOnlyOneSelectItem);
	else if(parseInt(eval("def_item_arr"+bizid+".length")) == 0 )
		alert(msgCmmSelectItem);
	else
	{
		var procID, procName;
		procID = eval("def_item_arr"+bizid+"[0][0]");
		procName= eval("def_item_arr"+bizid+"[0][1]");
		fid = eval("def_item_arr"+bizid+"[0][2]");
		state = eval("def_item_arr"+bizid+"[0][3]");
		var enableInitWindow = eval ("useinitWindow" + bizid);

        if (officeEngine_DefId == procID)
        {
            if (officeEngineAuthority)
                openPopup(contextPath + officeEngineURL + "/task/initiatetask.jsp", "", "wndInitiateForm", "100%", "100%", true, true);
            else
                alert(MSG_MNG_NO_LICENSE);
        }
        else if (officeEngineExt_DefId == procID)
        {
            if (officeEngineAuthority)
	            openPopup(contextPath + "/webdesign/newtask", "", "wndInitiateForm", 860, 742, true, true);
            
            else
                alert(MSG_MNG_NO_LICENSE);
        }
        else
        {
	    	if(initiateCustomOE(procID)) {
	    		return false;
	    	}
            if(enableInitWindow =="yes" && "PIE" != browsername)
                openInitProcessWindow(bizid, procID, state, fid, "1", "2146959359");
            else
                Initiate(procID, 'T', bizid);
        }
    }
}

function Initiate(DefinitionID, OpenWorkitem, bizid)
{
	var arr;
	var serverURL = contextPath+"/_scriptlibrary/initiate.jsp";
	var rsString ="parent.fralist.rsCallBack"+bizid;
	RSExecute(rsString, serverURL, "Initiate", DefinitionID, OpenWorkitem);
}

function sel_item(process, processname, fid, state,  src, bizid)
{
	var i, j, k, inx;
	if (src.checked)
	{

		inx = eval("def_item_arr"+bizid+".length");

		eval("def_item_arr"+bizid+"[inx] = new Array(2)");
		eval("def_item_arr"+bizid+"[inx][0] = process");
		eval("def_item_arr"+bizid+"[inx][1] = processname");
		eval("def_item_arr"+bizid+"[inx][2] = fid");
		eval("def_item_arr"+bizid+"[inx][3] = state");
	}
	else
	{
		for (i=0;i!= parseInt(eval("def_item_arr"+bizid+".length"));i++)
		{
			if (eval("def_item_arr"+bizid+"[i][0] == process") )
			{
				for (j=i;j!= parseInt(eval("def_item_arr"+bizid+".length-1"));j++)
				{
					k = j + 1;

					eval("def_item_arr"+bizid+"[j][0] = def_item_arr"+bizid+"[k][0]");
					eval("def_item_arr"+bizid+"[j][1] = def_item_arr"+bizid+"[k][1]");
					eval("def_item_arr"+bizid+"[j][2] = def_item_arr"+bizid+"[k][2]");
					eval("def_item_arr"+bizid+"[j][3] = def_item_arr"+bizid+"[k][3]");
				}

				eval("def_item_arr"+bizid+".length = def_item_arr"+bizid+".length-1");
				break;
			}
		}
	}
}

function refreshWhenWIHWindowClosedForDefinition(bizid)
{
	if(typeof(document.forms["bizcoveReferer"]) != "undefined")
	{	
		var _form = document.forms["bizcoveReferer"];
		_form.submit();
		return;
	}

	var newURL="";

	if(bizid.length == 10)
		newURL= contextPath + getBizcoveServletPath(bizid)  + "?bizcove="+ bizid+"&preview_bizcove=y";
	else
		newURL= contextPath + getBizcoveServletPath(bizid)  + "?bizcove="+ bizid;

	var i;
	var obj_arrBizCoves =  "'undefined' ==typeof(arrBizCoves)";
	var result_arrBizCoves = eval(obj_arrBizCoves);
	if(result_arrBizCoves == false)
	{
		for (i = 0; i != arrBizCoves.length; ++i)
		{
			if (arrBizCoves[i].type != "definition")
				newURL += ("&bizcove=" + arrBizCoves[i].id);
		}
	}

	if(bizid.length == 10)
		newURL += ("&preview_bizcove=y&refresh=y&osort="+ eval("def_curSortColName"+bizid) + "|"+ eval("def_curSortDataType"+bizid)
					+"|"+ eval("def_curSortDirection"+bizid)+ "&ap="+eval("def_curpage"+bizid));
	else
		newURL += ("&refresh=y&osort="+ eval("def_curSortColName"+bizid) + "|"+ eval("def_curSortDataType"+bizid)
				+"|"+ eval("def_curSortDirection"+bizid)+ "&ap="+eval("def_curpage"+bizid));

    newURL = adjustMaximizeURL(newURL, bizid);
    location.href = newURL + "&__bizcoveId=" + bizid;
}

function definition_refreshWhenWIHWindowClosed(bizid)
{
//	try
//	{
//		var time =1000;
//
//		if(null == definition_wndWIH)
//			window.setTimeout("definition_refreshWhenWIHWindowClosed('"+bizid+"')", 1000, "javascript");
//		else if ('undefined' == typeof(definition_wndWIH.closed))
//			window.setTimeout("definition_refreshWhenWIHWindowClosed('"+bizid+"')", 1000, "javascript");
//		else if (definition_wndWIH && 'undefined' != typeof(definition_wndWIH.closed) && !definition_wndWIH.closed)
//			window.setTimeout("definition_refreshWhenWIHWindowClosed('"+bizid+"')", 1000, "javascript");
//		else
//		{
//			refreshWhenWIHWindowClosedForDefinition(bizid);
//		}
//	}catch(e)
//	{
//		refreshWhenWIHWindowClosedForDefinition(bizid);
//	}
}

var wndInitProcess;
function openInitProcessWindow(bizid, sProcDefID, sStatus, fid, authInitiate, authority)
{       
	var useAccessibility = tmpUseAccessibility;
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}
	if(authInitiate == "1")
	{
		if (!(("P" == sStatus) || ("T" == sStatus)))
		{
			alert(msgPdNotPublished);
			return;
		}

		var sUrl = contextPath + "/definition/initiateframe.jsp?ProcDefID="
					+sProcDefID + "&fid=" + fid + "&authority=" + authority
					+ "&__bizcoveId=" + bizid;
		definition_wndWIH = openPopup(sUrl, "", "wndProcInitiatorinfo", 594, 510);
		if(!useAccessibility) {
			definition_refreshWhenWIHWindowClosed(bizid);
		}
	}
	else if(authInitiate == "0")
	{
		alert(msgPdNotAuthInitiate);
		return;
	}
}

function definition_SingleStorage(processID, processName, fldID, state, bizid)
{
	eval("def_item_arr_ss"+bizid+"[0] = processID");
	eval("def_item_arr_ss"+bizid+"[1] = processName");
	eval("def_item_arr_ss"+bizid+"[2] = fldID");
	eval("def_item_arr_ss"+bizid+"[3] = state");
}

function initProcess(sProcDefID, sStatus, fid, authInitiate, authority, msg)
{
	if(authInitiate == "1")
	{
		if (!(("P" == sStatus) || ("T" == sStatus)))
		{
			alert(msgPdNotPublished);
			return;
		}

		location.href =  contextPath + "/definition/ptinitiate5.jsp?ProcDefID="
						+ sProcDefID + "&fid=" + fid + "&authority=" + authority;
	}
	else if(authInitiate == "0")
	{
		alert(msgPdNotAuthInitiate);
		return;
	}
}

function definition_printNum(sURL, bizid, obj)
{
    try
    {
        if ("undefined" != typeof(obj))
        {
            enableDisableAnchor(obj, false);
        }

        enableDisableAllLinks(false);
    }
    catch(e)
    {
    }

    if(bizid.length == 10)
		sURL = sURL +"&preview_bizcove=y";

	sURL = sURL + "&__bizcoveId=" + bizid;
    
    sURL = adjustMaximizeURL(sURL, bizid);

    location.href = sURL;
}

function definition_printNumDirect(sURL, bizid, obj)
{
    try
    {
        if ("undefined" != typeof(obj))
        {
            enableDisableAnchor(obj, false);
        }

        enableDisableAllLinks(false);
    }
    catch(e)
    {
    }

    if(bizid.length == 10)
		sURL = sURL + "&preview_bizcove=y";

    sURL = adjustMaximizeURL(sURL, bizid);

    var getap = eval("document.thepage_"+bizid+".getnum.value");

	if (parseInt(getap) >  parseInt(eval("def_totpagecount"+bizid)) || parseInt(getap)  < 1)
		alert(msgErrorWrongNumber);
	else
	{
		sURL = sURL + "&ap=" +getap;
		location.href = sURL;
	}
}

function getreturnVal(arr,browsername, bizid)
{
	if (arr[0] == "0" && arr.length > 2)
	{
		if(browsername == "PIE")
			 location.href = contextPath +"/work/wih.jsp?sid="+ arr[1] + "&pid=" + arr[2] + "&seq=" + arr[3]
						+ "&asq=" + arr[4] + "&mode=" + "complete" + "&openpage=DEFINITION";
		else
		{
			var sUrl = contextPath +"/work/wih.jsp?sid="+ arr[1] + "&pid=" + arr[2] + "&seq=" + arr[3]
						+ "&asq=" + arr[4] + "&mode=" + "complete" + "&openpage=DEFINITION";
			var iWidth = window.screen.availWidth;
			var iHeight = window.screen.availHeight;
			definition_wndWIH = openPopup(sUrl, "", "Complete", iWidth, iHeight, true, true, true, false);
			definition_refreshWhenWIHWindowClosed(bizid);
		}
	}
	else
	{
		var errorNumber = parseInt(arr[0]);
		if(errorNumber != 0)
		{
			if(errorNumber ==3101 || errorNumber ==3103)
			{
				if(servletPath.indexOf("/portal/startpage")== -1)
				{
					if(errorNumber == 3101)
						alert(HW_SESSION_OUT);
					else if(errorNumber == 3103)
						alert(HW_FORCE_LOGOUT);
				}
			}
			else if(errorNumber ==19401)
				alert(HW_WITM_NOT_AVAILABLE);
			else if (errorNumber >= 2500 && errorNumber <= 2520)
				alert("[" + errorNumber + "] " + ERROR_NO_AUTHORIZED_INIT);
			else if(errorNumber == 19852)
				alert(HW_SERVER_DOWN);
			else
				alert("[" + errorNumber + "] "+ERROR_FAIL_TO_INIT);
		}

		var newURL="";
		if(bizid.length == 10)
			newURL= contextPath + getBizcoveServletPath(bizid)  + "?bizcove="+ bizid+"&preview_bizcove=y";
		else
			newURL= contextPath + getBizcoveServletPath(bizid)  + "?bizcove="+ bizid;

		var i;
		var obj_arrBizCoves =  "'undefined' ==typeof(arrBizCoves)";
		var result_arrBizCoves = eval(obj_arrBizCoves);

		if(result_arrBizCoves == false)
		{
			for (i = 0; i != arrBizCoves.length; ++i)
			{
				if (arrBizCoves[i].type != "definition")
					newURL += ("&bizcove=" + arrBizCoves[i].id);
			}
		}

		if(bizid.length == 10)
			newURL += ("&preview_bizcove=y&refresh=y&osort="+ eval("def_curSortColName"+bizid) + "|"+ eval("def_curSortDataType"+bizid)
						+"|"+ eval("def_curSortDirection"+bizid)+ "&ap="+eval("def_curpage"+bizid));
		else
			newURL += ("&refresh=y&osort="+ eval("def_curSortColName"+bizid) + "|"+ eval("def_curSortDataType"+bizid)
						+"|"+ eval("def_curSortDirection"+bizid)+ "&ap="+eval("def_curpage"+bizid));
		location.href = newURL;
	}
}

function definition_sortCol(sURL, bizid, e)
{
	var objName = "'undefined' ==typeof(document.theform"+bizid+".filter)";
	var result = eval(objName);
	sURL = sURL.replace("#", "%23");
	sURL += "&__bizcoveId=" + bizid;

    sURL = getBizCoveSortURL(sURL, e);
    sURL = adjustMaximizeURL(sURL, bizid);

    if(result == false)
	{
		var form = eval("document.theform"+bizid);
		var filter = form.filter;
		var options = filter.options;
		var actname = "all";

		for (i = 0; i != options.length; ++i)
		{
			if (options[i].selected)
			{
				actname = options[i].value;
				break;
			}
		}

		actname= URLEncode(actname);

		if(actname=="all")
			location.href = sURL;
		else
			location.href = sURL + "&actname=" + actname;
	}
	else
	{
		objName = "'undefined' ==typeof(document.theform"+bizid+".filter_worklist)";
		result = eval(objName);
		if(result == false)
		{
			var form = eval("document.filterfrm_"+bizid);
			var filter = form.filter_worklist;
			var options = filter.options;
			var wcat = "all";

            if ("undefined" == typeof(options)) {
                wcat = filter.value;
            } else {
                for (i = 0; i != options.length; ++i) {
                    if (options[i].selected) {
                        wcat = options[i].value;
                        break;
                    }
                }
            }

			wcat = URLEncode(wcat);

			if(wcat == "all")
				location.href = sURL;
			else
				location.href = sURL + "&wcat=" + wcat;
		 }
		 else
			location.href = sURL;
	}
}

