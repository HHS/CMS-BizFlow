function refreshWhenWIHWindowClosedForWorklist(bizid)
{
	refreshBizcove(bizid);
	//if(typeof(document.forms["bizcoveReferer"]) != "undefined")
	//{
	//	var _form = document.forms["bizcoveReferer"];
	//	_form.submit();
	//	return;
	//}
	//
	//if(bizid.length ==10)
	//	var strLocation = contextPath +  getBizcoveServletPath(bizid) + "?bizcove=" + bizid+"&preview_bizcove=y";
	//else
	//	var strLocation = contextPath +  getBizcoveServletPath(bizid) + "?bizcove=" + bizid;
	//
	//var i;
	//var obj_arrBizCoves =  "'undefined' ==typeof(arrBizCoves)";
	//var result_arrBizCoves = eval(obj_arrBizCoves);
	//if(result_arrBizCoves == false)
	//{
	//	for (i = 0; i != arrBizCoves.length; ++i)
	//	{
	//		if ((arrBizCoves[i].type != "definition") && (arrBizCoves[i].id != bizid))
	//			strLocation += ("&bizcove=" + arrBizCoves[i].id);
	//	}
	//}
	//strLocation += ("&refresh=y" + "&osort=" + eval("curSortColName"+bizid));
	//strLocation += ("|"+ eval("curSortDataType"+bizid) + "|" + eval("curSortDirection"+bizid));
	//
	//var form = eval("document.filterfrm_" + bizid);
	//var formFound = (('undefined' != typeof(form)) && (null != form));
	//var worklistFilter = true;
	//
	//if (!formFound)
	//	form = document.filterfrm;
	//
	//var filter = form.filter_worklist;
	//
	//if (('undefined' == typeof(filter)) || (null == filter))
	//{
	//	filter = form.filter;
	//	worklistFilter = false;
	//}
	//var wcat = "all";
	//var obj_filter =  "'undefined' ==typeof(filter)";
	//var result_obj_filter = eval(obj_filter);
	//if(result_obj_filter == false)
	//{
	//	var options = filter.options;
	//	for (i = 0; i != options.length; ++i)
	//	{
	//		if (options[i].selected)
	//		{
	//			wcat = options[i].value;
	//			break;
	//		}
	//	}
	//}
	//
	//wcat = URLEncode(wcat);
	//
	//strLocation += "&__bizcoveId=" + bizid;
	//strLocation = adjustMaximizeURL(strLocation, bizid);
	//
	//if("undefined" != typeof(refreshChartBizCoves)) {
     //   refreshChartBizCoves();
	//}
	//
	//if (wcat == "all")
	//	location.href = strLocation + "&ap="+ eval("curpage"+bizid)+ "&rmsrch=y";
	//else
	//{
	//	if (worklistFilter)
	//		location.href = strLocation + "&wcat=" +wcat+"&ap="+ eval("curpage"+bizid);
	//	else
	//		location.href = strLocation + "&actname=" +wcat+"&ap="+ eval("curpage"+bizid);
	//}
}
			
function refreshWhenWIHWindowClosed(bizid)
{          
    try
	{    
		if(null == wndWIH)
			window.setTimeout(function(){refreshWhenWIHWindowClosed(bizid)}, 1000, "javascript");
		else if ('undefined' == typeof(wndWIH.closed))
			window.setTimeout(function(){refreshWhenWIHWindowClosed(bizid)}, 1000, "javascript");
		else if (wndWIH && 'undefined' != typeof(wndWIH.closed) && !wndWIH.closed )
			window.setTimeout(function(){refreshWhenWIHWindowClosed(bizid)}, 1000, "javascript");
		else
		{
			refreshWhenWIHWindowClosedForWorklist(bizid);
		}
	}catch(e)
	{
		refreshWhenWIHWindowClosedForWorklist(bizid);
	}
}
						 
function openOrg(userid, bizid, browsername)
{
	curbizID = bizid;
	var checkValue = "F";
	selfuserid = userid;
	var isBizflow = "y";
	if(servletPath.indexOf("/portal/startpage")== -1)
		isBizflow = "n";
	
	if (parseInt(eval("item_arr"+bizid+".length")) == 0)
	{
		alert(msgSelectItems);
		return;
	}
	
	for (i = 0; i < parseInt(eval("item_arr"+bizid+".length")); i++)
	{
		if("T" == eval("item_arr"+bizid+"[i][8]"))
		{
			checkValue = "T";
			break;
		}
	}
				
	if("T" == checkValue)
	{
		passwordValue="false";
		actionType = "forward"; 
		var sUrl = contextPath + "/common/passwordframe.jsp?isbizflow" + isBizflow;
		wndPassword = ShowWindow(sUrl, "wndPassword", CHECKPASSWD, 300, 140, "no");
	}
	else if("F" == checkValue)
	{
		forwardWI(bizid, browsername);
	}
}

var forwardBizID = "";
function forwardWI(bizid, browsername)
{
	passwordValue = "true";
	var isBizflow = "y";
	if(servletPath.indexOf("/portal/startpage")== -1)
		isBizflow = "n";

	for(i = 0; i < parseInt(eval("item_arr"+bizid+".length")); i++)
	{
		if(eval("item_arr"+bizid+"[i][7]") == "C")
		{
			alert(msgAlreadyCompleted);
			return;
		}
	}

	var sUrl = contextPath + "/work/forwardworkitem.jsp?__bizcoveId=" + bizid;
	forwardBizID = bizid;

	var procID = "";
	var actseq = "";
	var wseq = "";

	for (i = 0; i < parseInt(eval("item_arr"+forwardBizID+".length")); i++)
	{
		procID = procID + eval("item_arr"+forwardBizID+"[i][0]") + ";";
		actseq = actseq + eval("item_arr"+forwardBizID+"[i][4]") + ";";
		wseq = wseq + eval("item_arr"+forwardBizID+"[i][2]") + ";";
	}

	sUrl = sUrl + "&pid=" + procID + "&aseq=" + actseq + "&wseq=" + wseq;

	if ("PIE" != browsername)
	{

		wndWorkOrg = ShowWindow(sUrl, "OpenOrg",  ORGANIZATION, 530, 500, "yes");
	}
	else
	{
		location.href = sUrl;
	}
}

function getWIHInfoString()
{
	return;
}

var curbizID ;
function openWIH_worklistLink(serverid, processid, workseq, activityseq, priority, responseid, passwordflag_init, passwordflag_pref, mode, bizid)
{
	curbizID = bizid;	
	var isBizflow = "y";
	if(servletPath.indexOf("/portal/startpage")== -1)
		isBizflow = "n";
	
	if (navigator.appName.indexOf("Microsoft Pocket Internet Explorer") >= 0)
	{
		passwordflag_init = "F";
		passwordValue = "true";
	}

	if ("T" == passwordflag_init)
	{
		passwordValue = "false";
		actionType = "complete";
		eval("item_arr_wihlink"+bizid+"[0] = serverid");
		eval("item_arr_wihlink"+bizid+"[1] = processid");
		eval("item_arr_wihlink"+bizid+"[2] = workseq;");
		eval("item_arr_wihlink"+bizid+"[3] = activityseq;");
		eval("item_arr_wihlink"+bizid+"[4] = priority;");
		eval("item_arr_wihlink"+bizid+"[5] = responseid;");
		eval("item_arr_wihlink"+bizid+"[6] = mode;");

		var sUrl = contextPath + "/common/passwordframe.jsp?isbizflow" + isBizflow;
		wndPassword = ShowWindow(sUrl, "wndPassword", CHECKPASSWD, 300, 140, "no");
	}
	else 
		opencurrentWIH(serverid, processid, workseq, activityseq, priority, responseid);
}

function removeWorkitemFromList(bizcoveId, processid, workseq, activityseq)
{
    if (BrowserDetect.OS != BrowserDetect.OSIPad && BrowserDetect.OS != BrowserDetect.OSIPhone) {
        var _id = bizcoveId + "_" + processid + "_" + workseq + "_" + activityseq;
        var rowObj = document.getElementById(_id);
        deleteRow(rowObj);

        if("undefined" != typeof(_refreshTimer) && null != _refreshTimer) {
            clearTimeout(_refreshTimer);
            _refreshTimer = null;
        }
    }
}

function opencurrentWIH(serverid, processid, workseq, activityseq, priority, responseid, afterCheckingPassword)
{
	var isBizflow = "y";
	var bizid = curbizID;
	if(servletPath.indexOf("/portal/startpage")== -1)
		isBizflow = "n";
	var useAccessibility = tmpUseAccessibility;
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}
	if(!useAccessibility) {
		removeWorkitemFromList(bizid, processid, workseq, activityseq);
	}

    var now = new Date();

	passwordValue = "true";
	actionType = "complete";
	var sUrl =  contextPath + "/work/wih.jsp?sid=" + serverid + "&pid=" + processid + "&seq=" + workseq 
					+ "&asq=" + activityseq + "&pro=" + priority + "&rid=" + responseid + "&time=" + now.getTime() 
					+ "&openpage=page" + "&wihinfo=" + getWIHInfoString() +"&bizcovecall=y&isbizflow="+isBizflow
					+ "&currow=" + curWorkIndex + "&bizcoveid=" + bizid;

	if (navigator.appName.indexOf("Microsoft Pocket Internet Explorer") >= 0)
		location.href = sUrl;
	else
	{
        var iWidth = window.screen.availWidth;
        var iHeight = window.screen.availHeight;
        if(isModalWIHMode())
        {
            iWidth = "100%";
            iHeight = "100%";
        }
        if("undefined" != typeof(BrowserDetect) && BrowserDetect.mobile && "undefined" != typeof(afterCheckingPassword) && afterCheckingPassword) {
            wndWIH = openNewTab(sUrl, "Complete");
        } else {
            wndWIH = openWIHPopup(sUrl, "", "Complete", iWidth, iHeight, true, true, true, false);
		if(!useAccessibility) {
			refreshWhenWIHWindowClosed(bizid);
		}
        }
	}
}

function getCheckPasswordValue(value)
{
	passwordValue = value;
	moveAction();
}

function moveAction()
{	
	var bizid = curbizID;
	var useAccessibility = tmpUseAccessibility;
	if ("undefined" == typeof(useAccessibility)) {
		useAccessibility = false;
	}

	if("true" == passwordValue)
	{		
		if ("submit" == actionType)
			submitWI(bizid);
		else if ("singlesubmit" == actionType)
			singleSubmit(bizid);
		else if("complete" == actionType)
		{		
			var serverid, processid, workseq, activityseq, priority, responseid;
			eval("serverid= item_arr_wihlink"+bizid+"[0];");
			eval("processid= item_arr_wihlink"+bizid+"[1];");
			eval("workseq= item_arr_wihlink"+bizid+"[2];")
			eval("activityseq=item_arr_wihlink"+bizid+"[3];")
			eval("priority = item_arr_wihlink"+bizid+"[4];")
			eval("responseid = item_arr_wihlink"+bizid+"[5];")
			opencurrentWIH(serverid, processid, workseq, activityseq, priority, responseid, true);
		}
		else if("forward" == actionType)
			 forwardWI(bizid, "");
		else if("singleforward" == actionType)
			singleForward(bizid);
		else if("monitor" == actionType)
			currentMonitor(bizid); 
		else if ("singlemonitor" == actionType)
			singleMonitor(bizid);
		else if ("reject" == actionType)
			submit_worklistReject(bizid);
		else if ("recall" == actionType)
			submit_worklistRecall(bizid);
	}
	else
		return;
}

//function onorgselchange(deptID, deptName, userID, userName, state, isAbsent, bizid, issinglestorage)
function onorgselchange(selectedID, selectedName)
{
    bizid = forwardBizID;
	var co, arr;
	var i = 0;
	var procID = "";
	var actseq = "";
	var wseq = "";
	var strURL= "";	

	var isBizflow = "y";
	if(servletPath.indexOf("/portal/startpage")== -1)
		isBizflow = "n";

	var userNamenode = eval("document.filterfrm_"+bizid+".userName");

	userNamenode.value = selectedName;
	//var deptNamenode = eval("document.filterfrm_"+bizid+".deptName");
	//deptNamenode.value = deptName;

	var serverURL = curLocation.substring(0, curLocation.indexOf(contextPath))
						+ contextPath +  "/_scriptlibrary/forward.jsp";


	if(issinglestorage == "y")
	{
		procID = eval("item_arr_singleStorage"+bizid+"[0]") + ";";
		actseq = eval("item_arr_singleStorage"+bizid+"[4]") + ";";
		wseq = eval("item_arr_singleStorage"+bizid+"[2]") + ";"; 
	}
	else
	{
		for (i = 0; i < parseInt(eval("item_arr"+bizid+".length")); i++)
		{
			procID = procID + eval("item_arr"+bizid+"[i][0]") + ";";
			actseq = actseq + eval("item_arr"+bizid+"[i][4]") + ";";
			wseq = wseq + eval("item_arr"+bizid+"[i][2]") + ";"; 
		}
	}

	var i = 0;
	var PROCESSID = "";
	var ACTIVITYSEQUENCE = "";
	var WORKITEMSEQUENCE = "";
	
	var curformObj = eval("document.filterfrm_" + bizid);

	curformObj.hUserID.value = selectedID;
	curformObj.hUserName.value = selectedName;
	//curformObj.hDeptName.value = deptName;
	curformObj.hTagProcessID.value = procID;
	curformObj.hTagATSequence.value = actseq;
	curformObj.hTagWISequence.value = wseq;
	curformObj.bizcove.value = bizid;

	var sURL =  contextPath + "/work/forward.jsp?isBizflow=" +isBizflow + "&callpage=bizcove&bizcoveContextPath="
													+ contextPath + "&bizcoveServletPath=" + getBizcoveServletPath(bizid);
    sURL = adjustMaximizeURL(sURL, bizid);

    curformObj.action =  sURL;
	curformObj.submit();

}

function printNum(sURL, bizid, obj)
{
    try
    {
        if ("undefined" != typeof(obj))
        {
            enableDisableAnchor(obj, false);
        }

        enableDisableAllLinks(false);
    }
    catch(e)
    {
    }

    var objName_filter = "'undefined' ==typeof(document.filterfrm_"+bizid+".filter)";
	var result = eval(objName_filter);

	if(bizid.length == 10)
		sURL = sURL + "&preview_bizcove=y";
		
	sURL = sURL + "&__bizcoveId=" + bizid;

	var qsearchValueElm = document.getElementById("qsearchValueForPagination" + bizid);
	if(qsearchValueElm)
	{
		sURL = sURL + "&qsearch=" + encodeURIComponent(qsearchValueElm.value);
	}

    sURL = adjustMaximizeURL(sURL, bizid);

    if(result == false)
	{   
		var form = eval("document.filterfrm_"+bizid);
		var filter = form.filter;
		var options = filter.options;
		var actname = "all";

		for (i = 0; i != options.length; ++i)
		{
			if (options[i].selected)
			{
				actname = options[i].value;
				break;
			}
		}

		actname = URLEncode(actname);   
		
		if(actname=="all")
			location.href = sURL;
		else
			location.href = sURL + "&actname=" + actname;
	}
	else
	{
		var objName_filter_worklist = "'undefined' ==typeof(document.filterfrm_"+bizid+".filter_worklist)";
		var result = eval(objName_filter_worklist);
		if(result == false)
		{
			var form = eval("document.filterfrm_"+bizid);
			var filter = form.filter_worklist;
			var options = filter.options;
			var wcat = "all";

            if ("undefined" == typeof(options)) {
                wcat = filter.value;
            } else {
                for (i = 0; i != options.length; ++i) {
                    if (options[i].selected) {
                        wcat = options[i].value;
                        break;
                    }
                }
            }

			wcat = URLEncode(wcat);
			
			if(wcat =="all")
				location.href = sURL;
			else
				location.href = sURL + "&wcat=" + wcat;
		}
		else
			location.href = sURL;
	}
}

function printNumDirect(sURL, bizid, totalCount, customizedQueryBizcove, obj)
{
    try
    {
        if ("undefined" != typeof(obj))
        {
            enableDisableAnchor(obj, false);
        }

        enableDisableAllLinks(false);
    }
    catch(e)
    {
    }

    if(bizid.length == 10)
		sURL = sURL + "&preview_bizcove=y";

	var qsearchValueElm = document.getElementById("qsearchValueForPagination" + bizid);
	if(qsearchValueElm)
	{
		sURL = sURL + "&qsearch=" + encodeURIComponent(qsearchValueElm.value);
	}

    sURL = adjustMaximizeURL(sURL, bizid);

    var actname="all";
	var wcat = "all";
	var getap = eval("document.thepage_"+bizid+".getnum.value");	

    if((parseInt(getap) > parseInt(eval("totpagecount"+bizid)) || parseInt(getap) < 1)
            && !(totalCount == 0 && customizedQueryBizcove.toLowerCase() == "true"))
    {
        alert(msgErrorWrongNumber);
    }
    else
	{
		var objName = "'undefined' ==typeof(document.filterfrm_"+bizid+".filter)";
		var result = eval(objName);
		if(result == false)
		{
			var form = eval("document.filterfrm_"+bizid);
			var filter = form.filter;
			var options = filter.options;
			var actname = "all";

			for (i = 0; i != options.length; ++i)
			{
				if (options[i].selected)
				{
					actname = options[i].value;
					break;
				}
			}
			actname = URLEncode(actname);
			
			if(actname=="all")
				location.href = sURL + "&ap=" +getap;
			else
				location.href = sURL + "&actname=" + actname + "&ap=" +getap;
		}
		else
		{
			
			objName = "'undefined' ==typeof(document.filterfrm_"+bizid+".filter_worklist)";
			 result = eval(objName);
			if(result == false)
			{
				var form = eval("document.filterfrm_"+bizid);
				var filter = form.filter_worklist;
				var options = filter.options;
				var wcat = "all";

                if ("undefined" == typeof(options)) {
                    wcat = filter.value;
                } else {
                    for (i = 0; i != options.length; ++i) {
                        if (options[i].selected) {
                            wcat = options[i].value;
                            break;
                        }
                    }
                }

				wcat = URLEncode(wcat);
				
				if(wcat =="all")
					location.href = sURL + "&ap=" +getap;
				else
					location.href = sURL + "&wcat=" + wcat + "&ap=" +getap;
			}
			else
			{
				location.href = sURL + "&ap=" +getap;
			}
		}
	}
}
