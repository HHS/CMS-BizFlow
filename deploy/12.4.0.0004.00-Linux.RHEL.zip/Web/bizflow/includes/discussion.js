function Discussion(objectid, svrid, procid, actseq, workseq, isArchive, currentUserID, contextPath, imageBasePath, resources, options, loadCallBack) {
    this.objectid = objectid;
	this.svrid = svrid;
	this.procid = procid;
	this.actseq = actseq;
	this.workseq = workseq;
	this.isArchive = isArchive;
	this.currentUserID = currentUserID;
	this.contextPath = contextPath;
	this.imageBasePath = imageBasePath;
    this.loadCallBack = loadCallBack;

	var me = this;
	var res = resources;
	var useAccessibility = false;
	var opts = {modify:true};
	if(options && typeof(options) != 'undefined')
	{
		opts.modify = (typeof(options.modify) != 'undefined')? options.modify : true;
        useAccessibility = (typeof(options.useAccessibility) != 'undefined')? options.useAccessibility : false;
	}
    var lastLoadedTime = 0;
	var checktimer = undefined;

	var checkChanges = function()
	{
		if ("undefined" == typeof(useBlockUI)) {
		    useBlockUI = false;
		}
		var returnVal = 0;
		var actionUrl = contextPath + "/webdesign/comment";
		if(useBlockUI) {
		    $.blockUI({message: "&nbsp;", css: cssBlockObj, overlayCSS: overlayCssBlockObj});
		}
		$("#ajaxForm").ajaxSubmit({
		    forceSync: true,
		    type:"POST",
		    url: actionUrl,
		    data: {
		        "method" : "checkanychanges",
		        "pid" : procid,
		        "executed" : lastLoadedTime
		    },
		    dataType:"json",
		    success: function(json) {
		        if("Y" == json.response.success) {
		            var planNotifyInfo = json.response.data;
		            if(planNotifyInfo != undefined) {
		                var cmntCreator = planNotifyInfo.cmntCreator;
		                var cmntCreatorname = planNotifyInfo.cmntCreatorname;
		                var cmntCreationCnt = planNotifyInfo.cmntCreationCnt;

			            if(0 < cmntCreationCnt)
			            {
							var notifyFunc;
							if ("undefined" != typeof(notify)) {
								notifyFunc = notify;
							}
							else if ("undefined" != typeof(parent.notify)) {
								notifyFunc = parent.notify;
							}

				            var message;
							if(notifyFunc)
							{
								if(cmntCreationCnt == 1)
								{
									message = (typeof(res.MSG_ADDED_NEW_COMMENT)=='undefined') ? '{0} added new comment.': res.MSG_ADDED_NEW_COMMENT;
									message = message.replace("{0}", cmntCreatorname);
								}
								else if(cmntCreationCnt > 1)
								{
									message = (typeof(res.MSG_THERE_ARE_NEW_COMMENTS)=='undefined') ? 'There are new comments.': res.MSG_THERE_ARE_NEW_COMMENTS;
								}
								notifyFunc(message);
							}
				            $("#msgNoComments").hide();
							me.load();
			            }
		            }
		        } else if(checktimer) {
                    clearInterval(checktimer);
		        }
		        if(useBlockUI) {
		            unblockUI();
		        }
		    },
		    error: function(e){
		        // ignore
//            alert('Error: ' + e.statusText);
		        if(useBlockUI) {
		            unblockUI();
		        }
			    if(checktimer)
			    {
				    clearInterval(checktimer);
			    }
		    }
		});
		return returnVal;
	};

	var notifyFunc;
	this.setNotifyFunc = function(func)
	{
		if(typeof(func) == 'function')
		{
			notifyFunc = func;
		}
	};
	this.startAutoFeed = function(intervalSec)
	{
		// 0 : disabled
		// default 60 sec, minimum 20 sec.
		if(typeof(intervalSec) == 'undefined')
		{
			intervalSec = 60;
		}

		if(0 < intervalSec)
		{
			var t=60;
			try
			{
				t = Math.max(Math.abs(intervalSec), 20);
			}
			catch(e){}
			checktimer = setInterval(checkChanges, t*1000);
		}
	};
	this.stopAutoFeed = function()
	{
		if(checktimer)
		{
			clearInterval(checktimer);
		}
	};
	var useBlockUI = false;
	this.setUseBlockUI = function(enable)
	{
		useBlockUI = enable;
	};

	var discussionData = [];
	var setDiscussionData = function(data)
	{
		discussionData = data;
	};
	this.getComments = function()
	{
		return JSON.parse(JSON.stringify(discussionData));
	};
    this.load = function(useBlockUI) {
        if ("undefined" != typeof(useBlockUI)) {
            useBlockUI = false;
        }
        if(useBlockUI) {
            $.blockUI({message: "&nbsp;", css: cssBlockObj, overlayCSS: overlayCssBlockObj});
        }

		$("#ajaxForm").ajaxSubmit({
			forceSync: true,
			type:"GET",
			url: this.contextPath + "/webdesign/comment",
			data: {
				"method" : "list",
				"sid" : this.svrid,
				"pid" : this.procid,
				"actseq" : this.actseq,
				"isarchive" : this.isArchive,
                "time": (new Date()).getUTCTime()
			},
			dataType:"json",
			success: function(json) {
				if("Y" == json.response.success) {
                    if(lastLoadedTime == 0) {
                        $("#" + objectid).empty();
                    }
					var dataList = json.response.data;
					setDiscussionData(dataList);
                    var newCount = 0;
                    var newCreatorName = "";
					if((dataList != null) && dataList.length > 0) {
						for(var i=0; i< dataList.length; i++) {
							var commentID = dataList[i].commentID;
							var creatorID = dataList[i].creatorID;
							var creatorName = dataList[i].creatorName;
							var creationDate = dataList[i].creationDate;
                            var creationDateLong = dataList[i].creationDateLong;
                            var comments = dataList[i].comments;
							var appendMode = true;
                            var isNew = false;
                            if(lastLoadedTime < creationDateLong)
                            {
                                if(lastLoadedTime > 0) {
                                    appendMode = false;
                                    isNew = true;
                                    newCount++;
                                    if(newCount == 1 ) {
                                        newCreatorName =  creatorName;
                                    }
                                    if(creatorID == currentUserID) {
                                        isNew = false;
                                    }
                                }
                                displayRow(objectid, appendMode, dataList[i], isNew);
                            }
                        }
                    }
					else
					{
						$("#msgNoComments").show();
					}
					lastLoadedTime = json.response.executed;
                    if ("undefined" != typeof(loadCallBack)) {
//                        lastLoadedTime = json.response.executed;
                        loadCallBack(newCount, newCreatorName);
                    }
                } else {
					alert(json.response.message);
				}
                if(useBlockUI) {
                    unblockUI();
                }
			},
			error: function(e){
                if(useBlockUI) {
                    alert('Error: ' + e.statusText);
                    unblockUI();
                }
				if(checktimer)
				{
					clearInterval(checktimer);
				}
            }
		});
	}

    this.displayInfo = function(appendMode, commentID, creatorID, creatorName, creationDate, comments, isNew) {
        displayRow(objectid, appendMode, {commentID: commentID, creatorID: creatorID, creatorName:creatorName, creationDate:creationDate, comments:comments}, isNew, false);
    }

	this.add = function(useBlockUI) {
        if ("undefined" == typeof(useBlockUI)) {
            useBlockUI = false;
        }
        $("#addCommentAction").attr("disabled", "true").attr("aria-hidden", "true");
		var actionUrl = this.contextPath + "/webdesign/comment?method=add";
		var contents = $("#commentContent").val();
		if(contents == "") {
			alert(res.MSG_DISCUSSION_ENTER);
			$("#addCommentAction").removeAttr("disabled").removeAttr("aria-hidden");
			return false;
		}
        if(useBlockUI) {
            $.blockUI({message: "&nbsp;", css: cssBlockObj, overlayCSS: overlayCssBlockObj});
        }
		$("#ajaxForm").ajaxSubmit({
			forceSync: true,
			type:"POST",
			url: actionUrl,
			data: {
				"sid" : this.svrid,
				"pid" : this.procid,
				"actseq" : this.actseq,
				"seq" : this.workseq,
                "contents" : contents
			},
			dataType:"json",
			success: function(json) {
				if("Y" == json.response.success) {
					var dataList = json.response.data;
					setDiscussionData(dataList);
                    var newCount = 0;
                    var newCreatorName = "";
                    if((dataList != null) && dataList.length > 0) {
	                    $("#msgNoComments").hide();
                        for(var i=0; i< dataList.length; i++) {
                            var commentID = dataList[i].commentID;
                            var creatorID = dataList[i].creatorID;
                            var creatorName = dataList[i].creatorName;
                            var creationDate = dataList[i].creationDate;
                            var creationDateLong = dataList[i].creationDateLong;
                            var comments = dataList[i].comments;
                            if(lastLoadedTime < creationDateLong)
                            {
                                newCount++;
                                if(newCount == 1 ) {
                                    newCreatorName =  creatorName;
                                }
                                displayRow(objectid, false, dataList[i], true);
                            }
                        }
                    }
					lastLoadedTime = json.response.executed;
                    if ("undefined" != typeof(loadCallBack)) {
//                        lastLoadedTime = json.response.executed;
                        loadCallBack(newCount, newCreatorName);
                    }
                    $("#commentContent").val("").focus();
					$("#addCommentAction").removeAttr("disabled").removeAttr("aria-hidden");;
				} else {
					alert(json.response.message);
					$("#addCommentAction").removeAttr("disabled").removeAttr("aria-hidden");;
				}
                if(useBlockUI) {
                    unblockUI();
                }
            },
			error: function(e){
                if(useBlockUI) {
                    alert('Error: ' + e.statusText);
                    unblockUI();
                }
            }
		});
		return false;
	}
	this.modify = function(cmntprocid, cmntseq, useBlockUI) {
        if ("undefined" == typeof(useBlockUI)) {
            useBlockUI = false;
        }
        $("#modifyCommentAction").attr("disabled", "true");
		$("#cancelCommentAction").attr("disabled", "true");
		var actionUrl = this.contextPath + "/webdesign/comment?method=modify";
		var contents = $("#commentContent").val();
		if(contents == "") {
			alert(res.MSG_DISCUSSION_ENTER);
			$("#modifyCommentAction").removeAttr("disabled");
			$("#cancelCommentAction").removeAttr("disabled");
			return false;
		}
		if(this.procid != cmntprocid) {
			alert(res.MSG_WIH_CANNOT_MODIFY_DISCUSSION);
			$("#modifyCommentAction").removeAttr("disabled");
			$("#cancelCommentAction").removeAttr("disabled");
			return false;
		}
        if(useBlockUI) {
            $.blockUI({message: "&nbsp;", css: cssBlockObj, overlayCSS: overlayCssBlockObj});
        }
		$("#ajaxForm").ajaxSubmit({
			forceSync: true,
			type:"POST",
			url: actionUrl,
			data: {
				"sid" : this.svrid,
				"pid" : this.procid,
				"actseq" : this.actseq,
				"seq" : this.workseq,
				"cmntprocid" : cmntprocid,
				"cmntseq" : cmntseq,
                "contents" : contents
			},
			dataType:"json",
			success: function(json) {
				if("Y" == json.response.success) {
					$("#" + objectid).empty();
					var dataList = json.response.data;
					setDiscussionData(dataList);
                    var newCount = 0;
                    var newCreatorName = "";
                    if((dataList != null) && dataList.length > 0) {
                        for(var i=0; i< dataList.length; i++) {
	                        displayRow(objectid, true, dataList[i], false);
                        }
                    }
					lastLoadedTime = (new Date()).getUTCTime();
                    if ("undefined" != typeof(loadCallBack)) {
//                        lastLoadedTime = json.response.executed;
                        loadCallBack(newCount, newCreatorName);
                    }
                    $("#commentContent").val("").focus();
					$("#modifyCommentAction").removeAttr("disabled");
					$("#cancelCommentAction").removeAttr("disabled");
					$("#addCommentAction").show();
					$("#modifyCommentAction").hide();
					$("#cancelCommentAction").hide();
					$("td.comment-header span.actionBtns").show();
				} else {
					alert(json.response.message);
					$("#modifyCommentAction").removeAttr("disabled");
					$("#cancelCommentAction").removeAttr("disabled");
					$("#addCommentAction").show();
					$("#modifyCommentAction").hide();
					$("#cancelCommentAction").hide();
					$("td.comment-header span.actionBtns").show();
				}
                if(useBlockUI) {
                    unblockUI();
                }
            },
			error: function(e){
                if(useBlockUI) {
                    alert('Error: ' + e.statusText);
                    unblockUI();
                }
            }
		});
		return false;
	}
	this.remove = function(cmntprocid, cmntseq, useBlockUI) {
        if ("undefined" == typeof(useBlockUI)) {
            useBlockUI = false;
        }
        if ("undefined" == typeof(cmntprocid)) {
            cmntprocid = this.procid;
        }
        $("#addCommentAction").attr("disabled", "true").attr("aria-hidden", "true");
		if(this.procid != cmntprocid) {
			alert(res.MSG_WIH_CANNOT_DELETE_DISCUSSION);
			$("#addCommentAction").removeAttr("disabled").removeAttr("aria-hidden");;
			return false;
		}
		var actionUrl = this.contextPath + "/webdesign/comment?method=remove";
        if(useBlockUI) {
            $.blockUI({message: "&nbsp;", css: cssBlockObj, overlayCSS: overlayCssBlockObj});
        }
        $("#ajaxForm").ajaxSubmit({
			forceSync: true,
			type:"POST",
			url: actionUrl,
			data: {
				"sid" : this.svrid,
				"pid" : this.procid,
				"actseq" : this.actseq,
				"seq" : this.workseq,
				"cmntprocid" : cmntprocid,
				"cmntseq" : cmntseq
			},
			dataType:"json",
			success: function(json) {
				if("Y" == json.response.success) {
					$("#" + objectid).empty();
					var dataList = json.response.data;
					setDiscussionData(dataList);
					if((dataList != undefined) && dataList.length > 0) {
						for(var i=0; i< dataList.length; i++) {
							displayRow(objectid, true, dataList[i], false);
						}
					}
					else
					{
						$("#msgNoComments").show();
					}
					$("#addCommentAction").removeAttr("disabled").removeAttr("aria-hidden");;
				} else {
					alert(json.response.message);
					$("#addCommentAction").removeAttr("disabled").removeAttr("aria-hidden");;
				}
                if(useBlockUI) {
                    unblockUI();
                }
            },
			error: function(e){
                if(useBlockUI) {
                    alert('Error: ' + e.statusText);
                    unblockUI();
                }
            }
		});
		return false;
	}

	this.getCount = function()
	{
		return $("#" + objectid +" .commentBox").length;
	}

    var displayRow = function (tableObjectid, appendMode, data, isNew) {
	    if($("#commentBox"+data.procId + "_" + data.commentID).length > 0) return;
        var $tableObj = $("#" + tableObjectid);
        var dataString = '';// data.rootProcId + "," + data.procId;
        if(isNew == true) {
	        dataString += "<table id='commentBox"+data.procId + "_" + data.commentID+"' class='commentBox newDiscussion'><tr>";
        } else {
            dataString += "<table id='commentBox"+data.procId + "_" + data.commentID+"' class='commentBox'><tr>";
        }
        dataString += "<td class='comment-header'>";
        if(currentUserID == data.creatorID) {
            dataString +="<img src='"+ imageBasePath+"/wihicons/me.png'/>&nbsp;" + res.ME;
        } else {
            if("undefined" != typeof(isForcedModal) && isForcedModal) {
                dataString +="<img src='"+ imageBasePath+"/wihicons/usericon.png'/>&nbsp;<a class='commentuser' href='javascript:openUserInfoModal(\"" + contextPath + "\",\"" + data.creatorID + "\",\"" + data.creatorName + "\")' >" + data.creatorName + "</a>";
            }
            else {
                dataString +="<img src='"+ imageBasePath+"/wihicons/usericon.png'/>&nbsp;<a class='commentuser' href='javascript:openUserInfoWindow(\"" + contextPath + "\",\"" + data.creatorID + "\",\"" + data.creatorName + "\")' >" + data.creatorName + "</a>";
            }
        }
		dataString += " " + res.DISCUSSION_PREP_ON + " " + data.creationDate;
        if(!data.rootActive && data.procName != null) {
            dataString += "<span class='fromprocess'>"+strEncode(res.FROM_PROCESS.replace('{0}', data.procName))+"</span>";
        }

        var actionBtns = "";
        try {
            if(!isArchive && opts.modify){
                if((data.creatorID == currentUserID && data.type == "COMMENT")
		        	&& ((procid == data.procId) && (data.activitySeq == actseq) && (data.workitemSeq == workseq)) || (workseq == 0 && actseq == 0)){
					actionBtns += "<span class='actionBtns'";
					if(useAccessibility) {
						actionBtns += " style='margin-top:-56px;' ";
					}
                    actionBtns += ">";
					actionBtns += "<a role='button' href='#' onclick='javascript:changeModifyCommentUI("+data.procId + "," + data.commentID+")' title='"+res.TIP_MODIFY_COMMENT+"'><img src='"+ imageBasePath+"/wihicons/modify_comment.png' class='commentActionButton'></a>";
					actionBtns += "<a role='button' href='#' onclick='javascript:deleteComment("+data.procId + "," + data.commentID+")' title='"+res.TIP_DELETE_COMMENT+"'><img src='"+ imageBasePath+"/wihicons/delete_comment.png' class='commentActionButton'></a></span>";
                }
            }
			if(!useAccessibility) {
				dataString += actionBtns;
			}
		}catch(e){};

	    try
	    {
			if(data.type == "COMPLETE")
			{
				dataString += "<br><span class='comment-type'>"+strEncode(res.COMMENT_TYPE_COMPLETE.replace('{0}', data.activityName))+"</span>";
			}
			else if(data.type == "REPLY")
			{
				dataString += "<br><span class='comment-type'>"+strEncode(res.COMMENT_TYPE_REPLY)+"</span>";
			}
			else if(data.type == "FORWARD")
			{
				dataString += "<br><span class='comment-type'>"+strEncode(res.COMMENT_TYPE_FORWARD.replace('{0}', data.activityName))+"</span>";
			}
	    }catch(e){}

	    dataString += "</td></tr>";
        if(isNew == true) {
            dataString += "<tr xclass='newDiscussion' >";
        } else {
            dataString += "<tr>";
        }
        dataString += "<td class='comment-contents'><textarea class='commentlistreadonly' readonly id='comment" + data.procId + "_" + data.commentID + "' >" + data.comments + "</textarea>";
		if(useAccessibility) {
			dataString += actionBtns;
		}
        dataString += "</td>";
	    dataString += "</tr></table></td></tr>";

        if(appendMode) {
			$tableObj.append(dataString);
        } else {
			$tableObj.prepend(dataString);
        }
	    resizeCommentBox("#comment" + data.procId + "_" + data.commentID);
        $("#comment" + data.procId + "_" + data.commentID).attr("title", data.comments);
        if(isNew == true) {
            setTimeout(function() { $("#" + tableObjectid + " .newDiscussion").removeClass("newDiscussion"); }, 10000);
        }
    };
    this.resizeCommentBoxes = function() {resizeCommentBox();};
	var resizeCommentBox = function (cid) {
        var id = cid?cid:".commentlistreadonly";
		if($.browser.msie && parseInt($.browser.version, 10)<9)
		{
			$(id).each(function(e) {
				try{
					var rows = this.value.split("\n");
					if(typeof(rows) == 'object' && 3<rows.length)
					{
						$(this).height(15 * rows.length);
					}
					if($(this).height() < 40)
					{
						$(this).height(40);
					}
					this.style.overflowY = 'auto';
				}catch(x){};
			});
		}
		else
		{
			$(id).each(function(e) {
			    $(this).height(40);
			    while($(this).outerHeight() < this.scrollHeight + parseFloat($(this).css("borderTopWidth")) + parseFloat($(this).css("borderBottomWidth"))) {
			        $(this).height($(this).height()+10);
			    };
			});
		}
    };
	var strEncode = function(s)
	{
		return s.replace(/&/g,"&amp;").replace(/>/g,"&gt;").replace(/</g,"&lt;");
	};
}
function __discussion_load()
{

}

function openDiscussionPopup(json){
    var jsonData = JSON.stringify(json);
    var url = contextPath + "/bizcoves/wih/discussionpopup.jsp?data="+jsonData;

    //for modal
    var statusbar;
    var toolbar;
    var caller;
    var sFeatures;
    var left;
    var top;
    if("undefined" != typeof(isForcedModal) && isForcedModal) {
        openModalPopup(url, MSG_DISCUSSION_POPUP_TITLE, MSG_DISCUSSION_POPUP_TITLE,  460, 150, true, true, 
        statusbar, toolbar, caller, sFeatures, left, top, isForcedModal);
    }
    else {
        openPopup(url, MSG_DISCUSSION_POPUP_TITLE, MSG_DISCUSSION_POPUP_TITLE,  460, 150, true, true);
    }
    return false;
}
