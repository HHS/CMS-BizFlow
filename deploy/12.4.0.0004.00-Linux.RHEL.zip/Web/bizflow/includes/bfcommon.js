// set forced modal on WIH
var isForcedModal = true;

function getModalPopupTop() {
    var _top = null;
    try {
        if (null != top && "undefined" != typeof(top)) {
            if ("undefined" != typeof(top.getUserClientType) && "undefined" != typeof(top.openModalPopupWindow)) {
                _top = top;
            } else if (null != top.opener && "undefined" != typeof(top.opener)) {
                if ("undefined" != typeof(top.opener.getUserClientType) && "undefined" != typeof(top.opener.openModalPopupWindow)) {
                    _top = top.opener;
                } else if (null != top.opener.top && "undefined" != typeof(top.opener.top)) {
                    if ("undefined" != typeof(top.opener.top.getUserClientType) && "undefined" != typeof(top.opener.top.openModalPopupWindow)) {
                        _top = top.opener.top;
                    }
                }
            }
        } else if (parent) {
            if (null != parent.top && "undefined" != typeof(parent.top)) {
                if (typeof(parent.top.getUserClientType) != "undefined" && "undefined" != typeof(parent.top.openModalPopupWindow)) {
                    _top = parent.top;
                } else if (null != parent.top.opener && "undefined" != typeof(parent.top.opener)) {
                    if ("undefined" != typeof(parent.top.opener.getUserClientType) && "undefined" != typeof(parent.top.opener.openModalPopupWindow)) {
                        _top = parent.top.opener;
                    } else if (null != parent.top.opener.top && "undefined" != typeof(parent.top.opener.top)) {
                        if ("undefined" != typeof(parent.top.opener.top.getUserClientType) && "undefined" != typeof(parent.top.opener.top.openModalPopupWindow)) {
                            _top = parent.top.opener.top;
                        }
                    }
                }
            }
        }

        if (null == _top) {
            if (top && "undefined" != typeof(top.WIH_information)) {
                _top = top.WIH_information;
            }
        }
    } catch (e) {
    }

    return _top;
}

//*************** Browser Detect ********************************************//
var BrowserDetect =
{
    initConstants:function () {
        // Browser Type
        this.BrowserChrome = "Chrome";
        this.BrowserOmniWeb = "OmniWeb";
        this.BrowserSafari = "Safari";
        this.BrowserOpera = "Opera";
        this.BrowseriCab = "iCab";
        this.BrowserKonqueror = "Konqueror";
        this.BrowserFirefox = "Firefox";
        this.BrowserCamino = "Camino";
        this.BrowserNetscape = "Netscape";
        this.BrowserExplorer = "Explorer";
        this.BrowserMozilla = "Mozilla";
        // OS
        this.OSWindows = "Windows";
        this.OSMac = "Mac";
        this.OSIPhone = "iPhone/iPod";
        this.OSIPad = "iPad";
        this.OSLinux = "Linux";

    },
    init:function () {
        this.initConstants();

        this.browser = this.searchString(this.dataBrowser) || "An unknown browser";
        this.version = this.searchVersion(navigator.userAgent)
            || this.searchVersion(navigator.appVersion)
            || "an unknown version";
        this.OS = this.searchString(this.dataOS) || "an unknown OS";
        this.mobile = this.OS == BrowserDetect.OSIPad || this.OS == BrowserDetect.OSIPhone;

        var _top = getModalPopupTop();
        try { // Fixed permission denied
            if (null != _top && "undefined" != typeof(_top.isUserDeviceMobile)) {
                this.mobile = _top.isUserDeviceMobile();
            }
        }catch(e) {};
    },
    searchString:function (data) {
        for (var i = 0; i < data.length; i++) {
            var dataString = data[i].string;
            var dataProp = data[i].prop;
            this.versionSearchString = data[i].versionSearch || data[i].identity;
            if (dataString) {
                if (dataString.indexOf(data[i].subString) != -1)
                    return data[i].identity;
            }
            else if (dataProp)
                return data[i].identity;
        }
    },
    searchVersion:function (dataString) {
        var index = dataString.indexOf(this.versionSearchString);
        if (index == -1) return;
        try
        {
            return parseFloat(dataString.substring(index).match(/ ([\d.]+)/)[1]);
        }
        catch(e)
        {
            return;
        }
    },
    isExplorer: function(){
        return this.browser == this.BrowserExplorer;
    },
    isFirefox: function(){
        return this.browser == this.BrowserFirefox;
    },
    isChrome: function(){
        return this.browser == this.BrowserChrome;
    },
    isNetscape: function(){
        return this.browser == this.BrowserNetscape;
    },
    dataBrowser:[
        {
            string:navigator.userAgent,
            subString:"Chrome",
            identity:"Chrome"
        },
        {
            string:navigator.userAgent,
            subString:"OmniWeb",
            versionSearch:"OmniWeb/",
            identity:"OmniWeb"
        },
        {
            string:navigator.vendor,
            subString:"Apple",
            identity:"Safari",
            versionSearch:"Version"
        },
        {
            prop:window.opera,
            identity:"Opera"
        },
        {
            string:navigator.vendor,
            subString:"iCab",
            identity:"iCab"
        },
        {
            string:navigator.vendor,
            subString:"KDE",
            identity:"Konqueror"
        },
        {
            string:navigator.userAgent,
            subString:"Firefox",
            identity:"Firefox"
        },
        {
            string:navigator.vendor,
            subString:"Camino",
            identity:"Camino"
        },
        {
            // for newer Netscapes (6+)
            string:navigator.userAgent,
            subString:"Netscape",
            identity:"Netscape"
        },
        {
            string:navigator.userAgent,
            subString:"MSIE",
            identity:"Explorer",
            versionSearch:"MSIE"
        },
        {
            string:navigator.userAgent,
            subString:"Trident/",
            identity:"Explorer",
            versionSearch:"rv"
        },
        {
            string:navigator.userAgent,
            subString:"Gecko",
            identity:"Mozilla",
            versionSearch:"rv"
        },
        {
            // for older Netscapes (4-)
            string:navigator.userAgent,
            subString:"Mozilla",
            identity:"Netscape",
            versionSearch:"Mozilla"
        }
    ],
    dataOS:[
        {
            string:navigator.userAgent,
            subString:"iPhone",
            identity:"iPhone/iPod"
        },
        {
            string:navigator.userAgent,
            subString:"iPad",
            identity:"iPad"
        },
        {
            string:navigator.platform,
            subString:"Win",
            identity:"Windows"
        },
        {
            string:navigator.platform,
            subString:"Mac",
            identity:"Mac"
        },
        {
            string:navigator.platform,
            subString:"Linux",
            identity:"Linux"
        }
    ]
};

BrowserDetect.init();

function getTopBrowserDetect() {
    var _browserDetect = BrowserDetect;
    var _top = getModalPopupTop();
    if (_top) {
        try { // Fixed Permission denied.
            if ("undefined" != typeof(_top.BrowserDetect)) {
                _browserDetect = _top.BrowserDetect;
            }
        } catch(e) {};
    }

    return _browserDetect;
}

function getTopBrowserVersion() {
    var _browserDetect = getTopBrowserDetect();
    return _browserDetect.version;
}

//*************** INCLUDE COMMON JS and CSS ********************************************//
function _getTopUrl() {
    var loc = "";
    try {
        loc = top.location.href;
        if (opener) {
            loc = opener.top.location.href;
        }
        else if (top && top.opener) {
            loc = top.opener.top.location.href;
        }
    }
    catch (e) {
    }

    if (typeof(loc) == "undefined") {
        loc = top.location.href;
        if (typeof(loc) == "undefined") {
            loc = this.location.href;
        }
    }

    return loc;
}

var BizflowCommon =
{
    adjustCss:function () {
        document.writeln("<style type='text/css'>");
        document.write("div.popupbody{");

        try {
            var _top = getModalPopupTop();
            if (null != _top && "undefined" != typeof(_top.isIPadApplication)) {
                if (_top.isIPadApplication()) {
                    document.write("overflow:auto;")
                }
            }
        } catch (e) {
        }

        if (BrowserDetect.mobile) {
            document.write("margin-left:auto !important;");
            document.write("margin-right:auto !important;");
        }
        document.writeln("}");

        if (BrowserDetect.mobile) {
            document.write("div.buttons { width: 100% !important; }");
        }
        document.writeln("</style>");

        if (BrowserDetect.mobile) {
            var themeDir = getThemeDir();
            if (null != themeDir && themeDir.length > 0) {
                document.write("<link href=\"");
                document.write(themeDir);
                document.writeln("mobile.css\" rel=\"stylesheet\" type=\"text/css\"/>");
            }
        }
    },
    includeIeLteCss:function () {
        var ieVersion = getTopBrowserVersion();
        var themeDir = getThemeDir();
        if (null != themeDir && themeDir.length > 0) {
            if (ieVersion < 9) {
                document.writeln("<!--[if lt IE 9]>");
                document.write("<link href=\"");
                document.write(themeDir);
                document.writeln("ielte8.css\" rel=\"stylesheet\" type=\"text/css\"/>");
                document.writeln("<![endif]-->");
            }
            if (ieVersion < 10) {
                document.writeln("<!--[if lt IE 10]>");
                document.write("<link href=\"");
                document.write(themeDir);
                document.writeln("ielte9.css\" rel=\"stylesheet\" type=\"text/css\"/>");
                document.writeln("<![endif]-->");

                if ("undefined" != typeof(top) && "undefined" != typeof(top.opener)) {
                    document.write("<link href=\"");
                    document.write(themeDir);
                    document.writeln("ielte9_newwin.css\" rel=\"stylesheet\" type=\"text/css\"/>");
                }
            }
        }
    },
    require:function (libraryName) {
        document.write('<script type="text/javascript" src="' + libraryName + '"></script>');
    },
    requireNoBrigetranslation:function (libraryName) {
        document.write('<script type="text/javascript" src="' + libraryName + '" bridgetranslation="no"></script>');
    },
    writeUrlRewriteFunc:function (path) {
        document.write('<script type="text/javascript" bridgetranslation="no">');
        document.write('function _markUrl' + 'Rewrite(url){return url;}');//DON'T REMOVE CONCATENATOR(+)!!
        document.write('</script>');
    },
    load:function () {
        this.adjustCss();

        if (BrowserDetect.browser == BrowserDetect.BrowserExplorer) {
            this.includeIeLteCss();
        }

        var scriptTags = document.getElementsByTagName("script");
        for (var i = 0; i < scriptTags.length; i++) {
            if (scriptTags[i].src && scriptTags[i].src.match(/bfcommon\.js$/)) {
                var path = scriptTags[i].src.replace(/bfcommon\.js$/, '');
                this.require(path + 'jsutil.js');
                this.require(path + 'urlutil.js');
                this.require(path + 'modalwin.js');
                this.require(path + 'modalpopup/modalpopupclient.js');
                this.require(path + 'positionutil.js');
                this.require(path + 'customcommon.js');
                this.writeUrlRewriteFunc();

                break;
            }
        }
    }
}

/**
 * Disable context menu of a document
 */
function _disableDocumentContextMenu() {
    try {
        if (__enableWebBrowserContextMenu != true) {
            document.oncontextmenu = function () {
                return false;
            }
        }
    }
    catch (e) {
    }
}

if (typeof __bfcommonLoaded == "undefined") {
    var loc = _getTopUrl();
    var debug = (loc.indexOf("debug=true") != -1);
    var _enableContextMenu = true;

    // Declare variables for global options
    document.writeln("<script language=\"javascript\">")
    document.writeln("var __bfcommonLoaded = true;");
    document.writeln("var __enableWebBrowserContextMenu = " + _enableContextMenu + ";");
    document.writeln("</script>");

    _disableDocumentContextMenu();

    BizflowCommon.load();
}

function openModalPopup(url, title, windowName, width, height, isForcedModal) {
    var resizable;
    var scrollbar;
    var statusbar;
    var toolbar;
    var caller;
    var sFeatures;
    var left;
    var top;
    return openPopup(url, title, windowName, width, height, resizable, scrollbar, statusbar, toolbar, caller, sFeatures, left, top, isForcedModal)
}
/**
 * Open popup window with default settings.
 * url
 * title
 * windowName.  This is used when window.open is called.
 * width
 * height
 * resizable, scrollbar, statusbar, toolbar  - all boolean.  Optional.
 */
function openPopup(url, title, windowName, width, height, resizable, scrollbar, statusbar, toolbar, caller, sFeatures, left, top, isForcedModal) {
    url = getSecurityTokenUrl(url);
    if (typeof(caller) == "undefined") {
        caller = this;
    }
    if (typeof isForcedModal == "undefined") {
        isForcedModal = false;
    }
    else {
//        isForcedModal = true;
        url = urlValueReplace(url, "isForcedModal", isForcedModal);
    }

    var _modalWinMode = true;

    if (typeof(caller.temporayWinMode) != "undefined") {
        _modalWinMode = caller.temporayWinMode();
        url = urlValueReplace(url, "_tempModalWinMode", _modalWinMode ? "true":"false");
    }

    url = urlValueReplace(url, "_t", new Date().getTime());

    var windowOpen;

    if(isForcedModal) {
        //this.focus();
        windowOpen = openNewWindow(this, url, title, width, height, sFeatures, left, top, isForcedModal);
    }
    else {
        if (isModalWindowMode() && _modalWinMode) {
            //this.focus();
            windowOpen = openNewWindow(this, url, title, width, height, sFeatures, left, top);
        }
        else {
            windowOpen = openNonPopup(url, windowName, width, height, resizable, scrollbar, statusbar, toolbar)
        }
    }
    return windowOpen;
}


function openWIHPopup(url, title, windowName, width, height, resizable, scrollbar, statusbar, toolbar, caller, sFeatures) {
    if (typeof(caller) == "undefined") {
        caller = this;
    }

    url = urlValueReplace(url, "_t", new Date().getTime());

    var windowOpen;
    if (isModalWIHMode()) {
        //this.focus();
        windowOpen = openNewWindow(caller, url, title, width, height, sFeatures);
    }
    else {
        windowOpen = openNonPopup(url, windowName, width, height, resizable, scrollbar, statusbar, toolbar)
        if ((width == "100%" && height == "100%") || (width == window.screen.availWidth && height == window.screen.availHeight)) {
            maximizeWindow(windowOpen);
        }
    }
    return windowOpen;
}

function openMonitorPopup(url, title, windowName, width, height, resizable, scrollbar, statusbar, toolbar, caller) {
    if (typeof(caller) == "undefined") {
        caller = this;
    }

    url = urlValueReplace(url, "_t", new Date().getTime());

    var windowOpen;
    if (isModalMonitorMode()) {
        //this.focus();
        windowOpen = openNewWindow(this, url, title, width, height, "");
    }
    else {
        windowOpen = openNonPopup(url, windowName, width, height, resizable, scrollbar, statusbar, toolbar)
    }
    return windowOpen;
}

function openDetailPopup(url, title, windowName, width, height, resizable, scrollbar, statusbar, toolbar, caller) {
    if (typeof(caller) == "undefined") {
        caller = this;
    }

    url = urlValueReplace(url, "_t", new Date().getTime());

    var windowOpen;
    if (isModalMonitorMode()) {
        //this.focus();
        windowOpen = openNewWindow(this, url, title, width, height, "");
    }
    else {
        windowOpen = openNonPopup(url, windowName, width, height, resizable, scrollbar, statusbar, toolbar)
    }
    return windowOpen;
}

function openNonPopup(url, windowName, width, height, resizable, scrollbar, statusbar, toolbar) {
    // for now, we just forcefully set toolbar to false.
    toolbar = false;

    var ignoreSize = false;
    var strWidth = new String(width);
    var strHeight = new String(height);
    if (strWidth.indexOf("%") != -1 || strHeight.indexOf("%") != -1)
        ignoreSize = true;

    var sFeatures = "";
    var widthOffset = 0;
    if (scrollbar == 'undefined' || !scrollbar) {
        sFeatures += "scrollbars=no";
    }
    else {
        sFeatures += "scrollbars=yes";
        widthOffset = 17;
    }

    if (strWidth.indexOf("%") == -1 && window.screen.availWidth >= (width + 17))
        width += widthOffset;               // due to scrollbar area.

    if (!ignoreSize) {
        var iLeft = (window.screen.availWidth - width) / 2;
        var iTop = (window.screen.availHeight - height) / 2;
        sFeatures += ",left=" + iLeft + "," + "top=" + iTop + "," + "width=" + width + "," + "height=" + height + ",";
    }

    if (statusbar == 'undefined' || !statusbar)
        sFeatures += ",status=no";
    else
        sFeatures += ",status=yes";

    if (toolbar == 'undefined' || !toolbar)
        sFeatures += ",toolbar=no";
    else
        sFeatures += ",toolbar=yes";

    if (resizable == 'undefined' || !resizable)
        sFeatures += ",resizable=no";
    else
        sFeatures += ",resizable=yes";

    var wnd = openNewBrowser(url, windowName, sFeatures);
    try {
        // Bug 21562 Script error when new window is opened from BizCove in Outlook
        // This error happens when a site is not registered on IE as a trusted site
        wnd.focus();
    }
    catch (e) {
    }

    return wnd;
}

// begin of bug20036
function bizflowIdentifier() {
    var id = "bf" + window.location.hostname + window.location.port;
    //id = id.replace(/[^a-zA-Z0-9]/g, '');
    return id;
}
// end of bug20036

// Following is for Plumtree gateway.  Same exact function is defined in bizflowgateway.jsp
function openNewBrowser(url, windowName, sFeatures) {
    // window name can not have spaces;
    windowName = (windowName + bizflowIdentifier()).replace(/[^a-zA-Z0-9]/g, '');
    return window.open(url, windowName, sFeatures);
}

function __adjustPopupWindowScrollbar(maxWidthRate, maxHeightRate) {
    try {
        var popupbody = getPopupElement("popupbodyDiv", "popupbody");
        if (null != popupbody) {
            var adjusted = false;
            document.body.style.height = "100%";
            var clientWidth = document.body.clientWidth;
            var clientHeight = document.body.clientHeight;
            var scrollWidth = document.body.scrollWidth;
            var scrollHeight = document.body.scrollHeight;

//            var _pw = popupbody.scrollWidth * 100 / clientWidth;
//            var _ph = popupbody.scrollHeight * 100 / clientHeight;
//
////            alert(_pw + " x " + _ph + "%\nclientSize=" + clientWidth + "x" + clientHeight + "\nscrollSize=" + scrollWidth + "x" + scrollHeight
////                    + "\npopup.clientSize=" + popupbody.clientWidth + "x" + popupbody.clientHeight + "\npopup.scrollSize=" + popupbody.scrollWidth + "x" + popupbody.scrollHeight);
//
//            if (popupbody.clientWidth == popupbody.scrollWidth && scrollWidth > clientWidth) {
//                document.body.style.width = clientWidth;
//            }
//
//            if (_pw > 100 && _pw <= maxWidthRate && clientWidth != scrollWidth) {
//                popupbody.style.width = (clientWidth * ((200 - _pw) / 100));
//                adjusted = true;
//            }
//
//            if (popupbody.clientHeight == popupbody.scrollHeight && scrollHeight > clientHeight) {
//                document.body.style.height = clientHeight;
//            }
//
//            if (_ph > 100 && _ph <= maxHeightRate && clientHeight != scrollHeight) {
//                popupbody.style.height = clientHeight * ((200 - _ph) / 100);
//                adjusted = true;
//            }


            var popupHeight = clientHeight;
            var buttonHeight = 31;
            var buttons = getPopupElement("popupbuttons", "buttons");
            if(buttons)
            {
                buttonHeight = buttons.style.height == "" ? buttonHeight : buttons.style.height;
                popupHeight = popupHeight -  buttonHeight;
            }

            popupbody.style.height = popupHeight + "px";
            popupbody.style.overflow = "auto";

//            if (adjusted) {
//                if (BrowserDetect.browser == BrowserDetect.BrowserFirefox) {
//                    popupbody.style.overflow = "auto";
//                }
//                else if (BrowserDetect.browser == BrowserDetect.BrowserSafari || BrowserDetect.browser == BrowserDetect.BrowserChrome) {
//                    popupbody.style.overflow = "visible";
//                } else if(BrowserDetect.browser == BrowserDetect.BrowserExplorer) {
//                    popupbody.style.overflow = "hidden";
//                }
//            }
        }
    }
    catch (e) {
    }
}

function __autoAdjustIFramesHeight() {
    var frames = document.getElementsByTagName("iframe");
    for (var f = 0; f < frames.length; f++) {
        var frame = frames[f];
        var heightAttr = frame.getAttribute("height");
        if("100%" == heightAttr) {
            if(frame.parentNode) {
                var p = frame.parentNode;
                var pHeightAttr = p.getAttribute("height");
                if(null != pHeightAttr && -1 == pHeightAttr.indexOf("%")) {
                    frame.style.height = pHeightAttr + "px";
                }
            }
        }
    }
}

function bfcommon_onload() {

    try {
        if (!BrowserDetect.mobile) {
            __adjustPopupWindowScrollbar(107, 107);
        }
    } catch (e) {
    }

    try {
        if (BrowserDetect.browser == BrowserDetect.BrowserExplorer) {
            __autoAdjustIFramesHeight();
        }
    } catch (e) {
    }

    try {
        attachDisableBackSpaceNavigationHandlerStart();
    } catch (e) {
    }
}

if (window.addEventListener) window.addEventListener("load", bfcommon_onload, false);
else if (window.attachEvent) window.attachEvent("onload", bfcommon_onload);
else if (document.getElementById) window.onload = bfcommon_onload;

var GMToffset = function() {
    return -(new Date()).getTimezoneOffset() / 60;
};

function _getGMToffset() {
    return -(new Date()).getTimezoneOffset() / 60;
}

function isCurrentTimeInBetween(start, end) {
    var sD = new Date(start);
    sD.setHours(sD.getHours() + GMToffset);
    var eD = new Date(end);
    eD.setHours(eD.getHours() + GMToffset);
    var today = (new Date()).getTime();
    return (today >= sD.getTime() && today <= eD.getTime());
}

function getWorkAreaSize() {
    var size = new Object();
    var body = document.body;

    size.width = body.clientWidth;
    size.height = body.clientHeight;
    size.offsetTop = 0;

    var topWrapper = document.getElementById("topWrapper");
    if (null != topWrapper) {
        var pos = getElementPosition(topWrapper);
        size.offsetTop = pos.y + topWrapper.clientHeight;
        size.height -= size.offsetTop;
    }

    return size;
}

function getWindowSize() {
    var myWidth = 0, myHeight = 0;
    if (typeof( window.innerWidth ) == 'number') {
        //Non-IE
        myWidth = window.innerWidth;
        myHeight = window.innerHeight;
    } else if (document.documentElement && ( document.documentElement.clientWidth || document.documentElement.clientHeight )) {
        //IE 6+ in 'standards compliant mode'
        myWidth = document.documentElement.clientWidth;
        myHeight = document.documentElement.clientHeight;
    } else if (document.body && ( document.body.clientWidth || document.body.clientHeight )) {
        //IE 4 compatible
        myWidth = document.body.clientWidth;
        myHeight = document.body.clientHeight;
    }

    var size = new Object();
    size.width = myWidth;
    size.height = myHeight;

    return size;
}

function getWindowScrollXY() {
    var scrOfX = 0, scrOfY = 0;
    if (typeof( window.pageYOffset ) == 'number') {
        //Netscape compliant
        scrOfY = window.pageYOffset;
        scrOfX = window.pageXOffset;
    } else if (document.body && ( document.body.scrollLeft || document.body.scrollTop )) {
        //DOM compliant
        scrOfY = document.body.scrollTop;
        scrOfX = document.body.scrollLeft;
    } else if (document.documentElement && ( document.documentElement.scrollLeft || document.documentElement.scrollTop )) {
        //IE6 standards compliant mode
        scrOfY = document.documentElement.scrollTop;
        scrOfX = document.documentElement.scrollLeft;
    }

    var scroll = new Object();
    scroll.x = scrOfX;
    scroll.y = scrOfY;

    return scroll;
}

//********************* Adjust List box size to make scrollbar inside visible area of a browser *************************//
function fitMainViewToDocumentBody(id) {
    var body = getDocumentBody();
    var mainView = $object(id);
    mainView.style.height = body.clientHeight + "px";
}

function adjustIFramesHeight(doc) {
    doc = doc || document;
    var body = getDocumentBody();
    var frames = doc.getElementsByTagName("iframe");
    for (var f = 0; f < frames.length; f++) {
        var frame = frames[f];
        var heightAttr = "" + frame.getAttribute("height");
        if(-1 != heightAttr.indexOf("%")) {
            if (frame.parentNode) {
                heightAttr = heightAttr.replace(/\s/g,'');
                var height = heightAttr;
                try {
                    height = parseInt(heightAttr);
                } catch (e) {
                    height = heightAttr.replace(/\%/g, '');
                }

                var h = body.clientHeight * height / 100;
                frame.style.height = h + "px";
            }
        }
    }
}

function adjustListBoxWidth(list, offset, body) {
    if ("undefined" == typeof(body)) body = getDocumentBody();

    if ("undefined" == typeof(offset)) offset = 5;

    if (null != list && "undefined" != typeof(list)) {
        var listObj = getElementObject(list);
        if(listObj) {
            listObj.style.width = body.clientWidth - offset;
        }
    }
}

function adjustContainerWidth(id) {
    var modal = isModalWindowMode();
    if (BrowserDetect.browser == BrowserDetect.BrowserExplorer) {
        if (modal) {
            adjustListBoxWidth(id, 10);
        }
    } else {
        adjustListBoxWidth(id, 10);
    }
}

function adjustListBoxSize2(list, bottom, body) {
    var height = getAvailableListHeight(list, bottom, body);
    if (height > 0) {
        var listObj = getElementObject(list);

        listObj.style.height = height;
        listObj.style.overflow = "auto";
        try {
            listObj.style.overflowX = "hidden";
        } catch (e) {
        }
    }
}

function adjustListBoxSize(table, theader, tbody, list, bottom, body) {
    if ("undefined" == typeof(body)) body = document.body;

    var height = getAvailableListHeight(list, bottom, body);
    if (height > 0) {
        if (BrowserDetect.isExplorer()) {
            list = getElementObject(list);
            table = getElementObject(table);
            theader = getElementObject(theader);
            tbody = getElementObject(tbody);

            var theaderPos = getElementPosition(theader);
            var tbodyPos = getElementPosition(table);
            var sizes = getColumnSizes(theader);

            // Create dummy header
            var dummyTHeader = document.createElement("thead");
            var dummyTr = document.createElement("tr");
            var dummyTd = document.createElement("td");
            var offset = theader.offsetHeight - 2;
            dummyTd.height = offset <= 0 ? 1 : offset;
            dummyTHeader.appendChild(dummyTr);
            dummyTr.appendChild(dummyTd);
            var dummyTable = document.createElement("table");
            dummyTable.appendChild(dummyTHeader);
            try {
                list.parentNode.insertBefore(dummyTable, list);
            } catch (e) {
                table.appendChild(dummyTHeader);
            }

            var div = document.createElement("div");
            div.style.position = "absolute";
            div.style.left = theaderPos.x - 1;
            div.style.top = theaderPos.y - 1;
            div.style.width = "100%";
            div.style.margin = 0;
            div.style.padding = 0;
            div.style.zIndex = 1;

            var table2 = document.createElement("table");
            table2.className = table.className;

            table2.appendChild(theader);
            div.appendChild(table2);
            body.appendChild(div);

            adjustListBoxSize2(list, bottom, body);

            adjustColumnSizes(theader.childNodes[0], sizes);
            adjustColumnSizes(tbody.childNodes[0], sizes);
        } else {
            adjustListBoxSize2(tbody, bottom, body);
        }
    }
}

function makeScrollBarWithFixedHeader(table, bottom, body) {
    table = getElementObject(table);
    if (table) {
        if ("undefined" == typeof(body)) {
            body = document.body;
        }

        var list = table.parentNode;
        var height = getAvailableListHeight(list, bottom, body);
        if (height > 0) {
            var theader = table.getElementsByTagName("thead")[0];
            var tbody = table.getElementsByTagName("tbody")[0];

            if (theader && tbody) {
//                if (document.all) {
                var sizes = getColumnSizes(theader);
                var div = document.createElement("div");
                div.style.width = "100%";
                div.style.margin = 0;
                div.style.padding = 0;
                div.style.zIndex = 1;

                var table2 = document.createElement("table");
                table2.className = table.className;

                table2.appendChild(theader);
                div.appendChild(table2);
                list.parentNode.insertBefore(div, list);

                adjustListBoxSize2(list, bottom, body);

                adjustColumnSizes(theader.childNodes[0], sizes);
                adjustColumnSizes(tbody.childNodes[0], sizes);
//                } else {
//                    adjustListBoxSize2(tbody, bottom, body);
//                }
            }
        }
    }
}

function executeHiddenCall(url, target) {
    var root = top;
    if (null != target && "undefined" != typeof(target)) {
        root = target;
    }

    var _id = "_RS_IFRAME";
    var iframe = null;
    try {
        iframe = root.document.getElementById(_id);
    }
    catch (e) {
        root = this;
        iframe = root.document.getElementById(_id);
    }

    if ('undefined' == typeof(iframe) || null == iframe) {
        iframe = root.document.createElement("IFRAME");
        iframe.setAttribute('id', _id);
        iframe.style.border = '0px';
        iframe.style.width = '0px';
        iframe.style.height = '0px';
        var blank = "about:blank";
        iframe.src = blank;
        root.document.body.appendChild(iframe);
    }

    iframe.style.display = "";
    iframe.src = url;
    iframe.style.display = "none";
}

//********************* Adjust Windows*************************//
function maximizeWindow(wndWIH) {
    try {
        if (wndWIH) {
            wndWIH.moveTo(0, 0);
            if (BrowserDetect.isExplorer()) {
                wndWIH.resizeTo(wndWIH.screen.availWidth, wndWIH.screen.availHeight);
            }
            else if (document.layers || document.getElementById) {
                if (wndWIH.outerHeight < screen.availHeight || wndWIH.outerWidth < screen.availWidth) {
                    wndWIH.outerHeight = wndWIH.screen.availHeight;
                    wndWIH.outerWidth = wndWIH.screen.availWidth;
                }
            }
        }
    }
    catch (e) {
    }
}

//********************* Portal *************************//
function isIOnPortalBridge() {
    return (typeof(PORTAL_BRIDGE_CONTEXT_PATH) != "undefined");
}

function getPortalBridgeBasePath() {
    var path = "";
    if (isIOnPortalBridge()) {
        if (typeof(PORTAL_BRIDGE_DIRECT_CONTEXT_PATH) != "undefined") {
            path = PORTAL_BRIDGE_DIRECT_CONTEXT_PATH;
        }
        else {
            path = PORTAL_BRIDGE_CONTEXT_PATH.replace(PORTAL_BRIDGE_RESOURCE_SERVLET_NAME, PORTAL_BRIDGE_SERVLET_NAME);
        }
    }

    return path;
}

function getPortalBridgeResourceBasePath() {
    var path = "";
    if (isIOnPortalBridge()) {
        path = PORTAL_BRIDGE_CONTEXT_PATH;
    }

    return path;
}

function __makeURLWithoutDoubleSlash(basePath, url) {
    try {
        if (url.substring(0, 1) == "/" && basePath.substring(basePath.length - 1) == "/") {
            basePath = basePath.substring(0, basePath.length - 1);
        }
    }
    catch (e) {
    }

    return basePath + url;
}

function reviseURLWhenIsOnPortal(url) {
    if (isIOnPortalBridge) {
        return __makeURLWithoutDoubleSlash(getPortalBridgeBasePath(), url);
    }

    return url;
}

function reviseResourceURLWhenIsOnPortal(url) {
    if (isIOnPortalBridge) {
        return __makeURLWithoutDoubleSlash(getPortalBridgeResourceBasePath(), url);
    }

    return url;
}

function getCssImportURL(styleHtml) {
    var url = "";
    styleHtml = "" + styleHtml.replace(/[\r\n]/g, "");
    var idx = styleHtml.indexOf("url(");
    if (-1 != idx) {
        var idx2 = styleHtml.lastIndexOf(");");
        if (-1 != idx2) {
            url = styleHtml.substring(idx + 4, idx2);
        }
    }

    return url;
}

function getCssDir(cssFilename) {
    var cssDir = "";
    var links = document.getElementsByTagName("link");
    for (var i = 0; i < links.length; i++) {
        var link = links[i];
        var href = link.getAttribute("href");
        var idx = href.lastIndexOf(cssFilename);
        if (idx != -1) {
            cssDir = href.substring(0, idx);
            break;
        }
    }

    if ("" == cssDir) {
        var links = document.getElementsByTagName("style");
        for (var i = 0; i < links.length; i++) {
            var link = links[i];
            var href = getCssImportURL(link.innerHTML);
            var idx = href.lastIndexOf(cssFilename);
            if (idx != -1) {
                cssDir = href.substring(0, idx);
                break;
            }
        }
    }

    return cssDir;
}

function getThemeDir() {
    var themeDir = getCssDir("commoncss.mres");
    if ("" == themeDir) {
        themeDir = getCssDir("top.css");
    }

    return themeDir;
}

function getBizFlowContextPath() {
    var contextPath = "";
    var scriptTags = document.getElementsByTagName("script");
    for (var i = 0; i < scriptTags.length; i++) {
        if (scriptTags[i].src) {
            if (scriptTags[i].src.match(/\/includes\/bfcommon\.js$/)) {
                contextPath = scriptTags[i].src.replace(/\/includes\/bfcommon\.js$/, '');
                break;
            } else {
                var idx = scriptTags[i].src.indexOf("/js/bfcommon-");
                if (-1 != idx) {
                    contextPath = scriptTags[i].src.substring(0, idx);
                    break;
                }
            }
        }
    }

    return contextPath;
}

function showRequestInProgress(id) {
    try {
        var overlayObject = document.getElementById(id);
        //    overlayObject.style.left = 0;
        //    overlayObject.style.top = 0;
        //    overlayObject.style.width = document.body.scrollWidth;
        //    overlayObject.style.height = document.body.scrollHeight;
        overlayObject.style.display = "";
        this.focus();
    }
    catch (e) {
    }
}

function hideRequestInProgress(id) {
    var overlayObject = document.getElementById(id);
    overlayObject.style.display = "none";
    try {
        this.focus();
    }
    catch (e) {
    }
}

function createHiddenFormElement(form, keyName, keyValue) {
    var inp = document.createElement("input");
    inp.setAttribute("type", "hidden");
    inp.setAttribute("name", keyName);
    inp.setAttribute("value", keyValue);
    form.appendChild(inp);
}

//********************* Security Token *************************//
var PageKeyParamName = "__PK_";
function getSecurityTokenPageKeyParamString() {
    var paramString = "";
    var forms = document.getElementsByTagName("form");
    for(var f=0; f < forms.length; f++) {
        var form = forms[f];
        var inputs = form.getElementsByTagName("input");
        for(var i=0; i < inputs.length; i++) {
            var input = inputs[i];
            var name = input.getAttribute("name");
            if(name != null && name.length >= PageKeyParamName.length) {
                var k = name.substring(0, PageKeyParamName.length);
                if(PageKeyParamName == k) {
                    if(paramString.length > 0) {
                        paramString += "&";
                    }
                    paramString += name + "=" + input.getAttribute("value");
                }
            }
        }

        if("" != paramString) {
            break;
        }
    }

    return paramString;
}

function getSecurityTokenUrl(url) {
    if (typeof(url) != 'undefined' && url.indexOf("&" + PageKeyParamName) == -1 && url.indexOf("?" + PageKeyParamName) == -1) {
        var tokenParam = getSecurityTokenPageKeyParamString();
        if (null != tokenParam && tokenParam.length > 0) {
            if (url.indexOf("?") == -1) {
                url += "?";
            } else {
                url += "&";
            }

            url += tokenParam;
        }
    }

    return url;
}

function getDocumentBody(doc) {
    doc = doc || document;
    return (!window.opera && doc.compatMode && doc.compatMode != "BackCompat") ? doc.documentElement : doc.body;
}

function $object(id) {
    return document.getElementById(id);
}

//********************* find window object *************************//
function findUpUrlWindow(urlRegEx) {
    var win = null;
    var p = parent;
    while (null != p && "undefined" != typeof(p)) {
        var loc = "undefined" != typeof(p.location) ? p.location : p.document.location;
        var url = "" + loc;
        if (url.match(urlRegEx)) {
            win = p;
            break;
        }

        if (p != p.parent) {
            p = p.parent;
        } else {
            break;
        }
    }

    return win;
}

function findUrlFrame(urlRegEx, frames) {
    var win = null;
    if (frames) {
        for (var i = 0; i < frames.length; i++) {
            var frame = frames[i];
            var url = frame.src;

            if (url.match(urlRegEx)) {
                win = frame;
                break;
            }
        }
    }

    return win;
}

function findDownUrlFrame(urlRegEx, frames) {
    var win = findUrlFrame(urlRegEx, frames);
    if (null == win) {
        if (frames) {
            for (var i = 0; i < frames.length; i++) {
                win = findDownUrlWindow(urlRegEx, frames[i]);
                if (null != win) {
                    break;
                }
            }
        }
    }

    return win;
}

function findDownUrlWindow(urlRegEx, container) {
    if ("undefined" == typeof(container)) {
        container = top;
    }

    var win = null;
    if (null != container) {
        var doc = "undefined" != typeof(container.contentWindow) ? container.contentWindow.document : container.document;
        win = findDownUrlFrame(urlRegEx, doc.getElementsByTagName("iframe"));
        if (null == win) {
            win = findDownUrlFrame(urlRegEx, doc.getElementsByTagName("frame"));
        }
    }

    return win;
}


function findAllUrlFrames(urlRegEx, frames, wins) {
    if (null == wins || "undefined" == typeof(wins)) {
        wins = new Array();
    }
    if (frames) {
        for (var i = 0; i < frames.length; i++) {
            var frame = frames[i];
            var url = frame.src;

            if (url.match(urlRegEx)) {
                wins[wins.length] = frame;
            }
        }
    }

    return wins;
}

function findDownAllUrlFrames(urlRegEx, frames, wins) {
    if (null == wins || "undefined" == typeof(wins)) {
        wins = new Array();
    }

    findAllUrlFrames(urlRegEx, frames, wins);
    if (frames) {
        for (var i = 0; i < frames.length; i++) {
            findDownAllUrlWindows(urlRegEx, frames[i], wins);
        }
    }

    return wins;
}

function findDownAllUrlWindows(urlRegEx, container, wins) {
    if ("undefined" == typeof(container)) {
        container = top;
    }

    if (null == wins || "undefined" == typeof(wins)) {
        wins = new Array();
    }

    if (null != container) {
        var doc = "undefined" != typeof(container.contentWindow) ? container.contentWindow.document : container.document;
        wins = findDownAllUrlFrames(urlRegEx, doc.getElementsByTagName("iframe"), wins);
        wins = findDownAllUrlFrames(urlRegEx, doc.getElementsByTagName("frame"), wins);
    }

    return wins;
}

Date.prototype.getUTCTime = function(){
    return new Date(
        this.getUTCFullYear(),
        this.getUTCMonth(),
        this.getUTCDate(),
        this.getUTCHours(),
        this.getUTCMinutes(),
        this.getUTCSeconds()
    ).getTime();
};

var defaultNotifyOptions = {
    globalPosition: 'top center',
    clickToHide: true,
    className: 'info',
    hideAnimation: 'fadeOut',
    autoHide: false,
    autoHideDelay: 5000,
    hideDuration: 500,
    gap: 2};

function notifyInternalServerError(msg)
{
    var options = {className: 'error'};
    (typeof(msg) == 'undefined') ? notify("Sorry, We were unable to service your request. Please try again later.", options) : notify(msg, options);
}
/*
 Required Notify.js plugin.
 opts: 'success', 'info', 'error', 'warn', or options object.
 */
function notify(msg, opts) {
    try
    {
        if(isAccessibility()){
            alert(msg);
        }
        else {
	        if (typeof(opts) == 'string') {
		        opts = {'className': opts};
	        }

	        var options = $.extend(defaultNotifyOptions, opts);
	        if (typeof($.notify) == 'function') {
		        $.notify(msg, options);

		        // Central position.
		        var oHeight = $('.notifyjs-wrapper').length,
				        vPosition = ($('.notifyjs-wrapper').width()) / 2,
				        hPosition = $('.notifyjs-wrapper').height() * oHeight / 2;
		        $('.notifyjs-corner').css({
			        'top': '50%',
			        'left': '50%',
			        'margin-left': -vPosition,
			        'margin-top': -hPosition
		        });
	        }
	        else {
		        // Used in basicwih.js
		        var div = $("#notify");
		        if (div.length) {
			        div.html(msg);
			        div.css("position", "absolute");
			        div.css("top", ($("#menubar").height() + 4) + "px");
			        div.css("left", Math.max(0, (($(window).width() - div.outerWidth()) / 2) + $(window).scrollLeft()) + "px");
			        div.fadeIn();
			        var duration = 4000;
			        if (opts) {
				        if (typeof(opts) == 'number') {
					        duration = opts;
				        }
				        else {
					        duration = opts.duration || 4000;
				        }
			        }
			        setTimeout(function () {
				        $("#notify").fadeOut();
			        }, duration);
		        }
		        else {
			        alert(msg);
		        }
	        }
        }
    }
    catch (e)
    {
        console && console.error ? console.error(e) : alert(e);
    }
}

function enableAccessibility()
{
	try
	{
        top.accessibility = true;
	}
	catch(e)
	{
		document.accessibility = true;
	}
}

function isAccessibility()
{
    if(top.accessibility){
        return top.accessibility;
    } else if(document.accessibility) {
        return document.accessibility;
    } else {
        return false;
    }
}