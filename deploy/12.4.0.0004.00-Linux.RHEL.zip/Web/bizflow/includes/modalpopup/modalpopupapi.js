/**
 * Revise features of a window
 * @param sFeatures
 */
function _reviseFeatures(sFeatures, left, top)
{
    var features = parseFeatures(sFeatures);
    
    sFeatures = features.string;
    sFeatures = reviseFeatures(sFeatures, "left", left);
    sFeatures = reviseFeatures(sFeatures, "top", top);

    return sFeatures;
}

/**
 *  Open a modal window after revising width and height if width or height are percentage
 * @param caller caller object, usuall this value is this
 * @param sURL a url to call
 * @param title name a window name
 * @param width window width, if you wnat to use the whole width, use 100% as this value
 * @param height window height, if you want to use the whole height, use 100% as this value
 * @param sFeatures window features such as "scrollbars=no,status=no,toolbar=no,resizable=yes"
 * @param left the initial left position of a window
 * @param top the initial top position of a window
 * @param lastFocusedEl restores the last focused element before open modal
 */
function openModalPopupWindowEx(caller, sURL, title, width, height, sFeatures, left, top, lastFocusedEl)
{
    sFeatures = _reviseFeatures(sFeatures, left, top);
    return openModalPopupWindow(caller, sURL, title, width, height, sFeatures,lastFocusedEl);
}

/**
 *  Open a single modal window after revising width and height if width or height are percentage
 * @param caller caller object, usuall this value is this
 * @param sURL a url to call
 * @param title name a window name
 * @param width window width, if you wnat to use the whole width, use 100% as this value
 * @param height window height, if you want to use the whole height, use 100% as this value
 * @param sFeatures window features such as "scrollbars=no,status=no,toolbar=no,resizable=yes"
 * @param left the initial left position of a window
 * @param top the initial top position of a window
 */
function openSingleModalPopupWindowEx(caller, sURL, title, width, height, sFeatures, left, top)
{
    sFeatures = _reviseFeatures(sFeatures, left, top);
    return openSingleModalPopupWindow(caller, sURL, title, width, height, sFeatures);
}

/*************** ETC ****************************/
/**
 * @param caller caller object, usuall this value is this
 * @param targetName  a target name for example, document.theForm.date
 * @param defaultDate the initial date
 * @param mode calendar mode, the value can be one of "", "datetime"
 * @param format date format
 */
function openCalendarWindow(caller, targetName, defaultDate, mode, format)
{
    var h = 290;
    var sURL = basePath + "/common/calendar.jsp?targetName=" + escape(targetName);
    var targetObj = eval("caller." + targetName);

    if (null != targetObj)
    {
        var value = targetObj.value;
        if (value.length > 0)
        {
            defaultDate = value;
        }
    }

    if ("undefined" != typeof(defaultDate) && null != defaultDate)
    {
        sURL = sURL + "&defaultDate=" + escape(defaultDate);
    }

    if ("undefined" != typeof(mode) && null != mode)
    {
        sURL = sURL + "&mode=" + mode;
    }

    if ("undefined" != typeof(format) && null != format)
    {
        sURL = sURL + "&format=" + format;
    }

    if ("undefined" != typeof(mode) && mode == "datetime")
    {
        h = 210;
    }

    return openModalPopupWindowEx(caller, sURL, "Calendar", 202, h);
}
