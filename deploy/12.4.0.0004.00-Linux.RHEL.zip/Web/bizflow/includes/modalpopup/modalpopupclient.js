/**
 * Open new window calling window.open
 * @param url a url to open
 * @param name a window name
 * @param w width of a window
 * @param h height of a window
 * @param opt option of a window
 * @param left the left position of a window
 * @param top the top position of a window
 */
function _newWindowOpen(url, name, w, h, opt, left, top) {
    var l = screen.width / 2 - w / 2;
    var t = screen.height / 2 - h / 2;

    if ("undefined" != typeof(left) && null != left) {
        l = left;
    }

    if ("undefined" != typeof(top) && null != top) {
        t = top;
    }

    if (name) {
        name = name.replace(/ /g, "_");
        name = name.replace(/;/g, "");
        name = name.replace(/&/g, "");
    }

    var _win = window.open(url, name, "left=" + l + ",top=" + t + ",width=" + w + ",height=" + h + "," + opt);
    return _win;
}

/**
 * Get the top object of a modal window
 */
function getModalTop() {
    try {
        if ("undefined" != typeof(top.openModalPopupWindow)) {
            return top;
        }
        else if (parent && "undefined" != typeof(parent.top.openModalPopupWindow)) {
            return parent.top;
        }
        else {
            if (top && "undefined" != typeof(top.WIH_information)) {
                return top.WIH_information;
            }
        }
    } catch (e) {

    }

    if ("undefined" != typeof(getModalPopupTop)) {
        return getModalPopupTop();
    } else {
        return null;
    }
}

/**
 * Get current modal window object
 * @param singleWindow if this value is true, get the single modal window object
 */
function getCurrentModalWindow(singleWindow) {
    var _top = getModalTop();
    var _modalWin = null;

    if (null != _top && isModalWindowMode()) {
        if (singleWindow) {
            _modalWin = _top.getSingleModalPopupWindow();
        }
        else {
            _modalWin = _top.getCurrentModalPopupWindow();
        }
    }

    return _modalWin;
}

/**
 * Get the caller of a modal window
 * @param singleWindow if this value is true, get the caller of the single modal window object
 */
function getModalCaller(singleWindow) {
    var _caller = null;
    var _top = getModalTop();

    if (null != _top && isModalWindowMode()) {
        if ("undefined" == typeof(singleWindow)) {
            singleWindow = _top.isSingleModalPopupWindowActive();
        }

        if (singleWindow) {
            _caller = _top.getSingleModalPopupCaller();
        }
        else {
            _caller = _top.getModalPopupCaller();
        }
    }
    else {
        if (opener) {
            _caller = opener;

        }
        else if (parent) {
            if (parent.opener) {
                _caller = parent.opener;
            } else {
                if (parent.top) {
                    _caller = parent.top.opener;
                }

                if ("undefined" == typeof(_caller)) {
                    if (parent.parent) {
                        _caller = parent.parent.opener;
                    }
                }
	            if ("undefined" == typeof(_caller)) {
	                if(parent.dialogArguments)
	                {
		                _caller = parent.dialogArguments[0];
                    }
                }
            }
        }
        else {
            _caller = top.opener;
        }
    }

    return _caller;
}

function getPopupElement(id, classname) {
    var obj = document.getElementById(id);
    if (null == obj) {
        var objs = document.getElementsByTagName("div");
        if (null != objs) {
            for (var i = 0; i < objs.length; i++) {
                var cls = objs[i].className;

                if (classname == cls) {
                    obj = objs[i];
                    break;
                }
            }
        }
    }

    return obj;
}

function popupBodyResizeTo(width, height) {
//    if (!BrowserDetect.isExplorer()) {
//        var offset = getModalScreenOffset();
//        width += offset.width;
//        height += offset.height;
//    }
//
//    var popupbody = getPopupElement("popupbody", "popupbody");
//    if (null != popupbody) {
//        popupbody.style.width = width;
//    }
//
//    var popupbuttons = getPopupElement("popupbuttons", "buttons");
//    if (null != popupbuttons) {
//        popupbuttons.style.width = width;
//    }
}

function getPopupContentSize() {
    var size = new Object();

    size.width = document.body.scrollWidth;
    size.height = document.body.scrollHeight;

    var popupbody = getPopupElement("popupbody", "popupbody");
    if (null != popupbody) {
        var width = popupbody.scrollWidth;
        var height = popupbody.scrollHeight;

        if (width > size.width) {
            size.width = width;
        }

        if (height > size.height) {
            size.height = height;
        }
    }

    return size;
}

function windowResizeTo(width, height) {
    if (!isModalWindowMode()) {
        top.window.resizeTo(width, height);
    } else {
        var win = getCurrentModalPopupWindow();
        if (null != win) {
            win.resizeTo(width, height);
        }
    }
}

function modalWindowResizeTo(width, height) {
    try {
        var _top = getModalTop();
        if (null != _top && isModalWindowMode()) {
            var singleWindow = _top.isSingleModalPopupWindowActive();
            var _modalWin = getCurrentModalWindow(singleWindow);
            if (null != _modalWin) {
                var popSize = getPopupContentSize();

                if ("undefined" == typeof(width)) {
                    width = popSize.width;
                }

                if ("undefined" == typeof(height)) {
                    height = popSize.height;
                }

                var size = _modalWin.getSize();

                if (size.width <= width || size.height <= height) {
                    size.width = width;
                    size.height = height;

                    _modalWin.resizeTo(size.width, size.height);
                    popupBodyResizeTo(size.width, size.height);
                }

                return size;
            }
        } else {
            var popSize = getPopupContentSize();

            if ("undefined" == typeof(width)) {
                width = popSize.width;
            }

            if ("undefined" == typeof(height)) {
                height = popSize.height;
            }

            var size = getWindowSize();
            if (size.width <= width || size.height <= height) {
                size.width = width;
                size.height = height;

                var widthOffset = 9;
                var heightOffset = 30;

                if (BrowserDetect.browser == BrowserDetect.BrowserExplorer) {
                    widthOffset = 27;
                }
                else if (BrowserDetect.browser == BrowserDetect.BrowserFirefox) {
                    heightOffset = 80;
                }

                window.resizeTo(width + widthOffset, height + heightOffset);
                popupBodyResizeTo(size.width, size.height);
            }

            return size;
        }
    }
    catch (e) {
        // ignore
    }

    return null;
}

/**
 * Set the title of a modal window
 * @param title the title of a modal window
 * @param singleWindow if this value is true, set the title of the single modal window
 */
function setWindowTitle(title, singleWindow) {
    try {
        var _top = getModalTop();
        if (null != _top && isModalWindowMode()) {
            if ("undefined" == typeof(singleWindow)) {
                singleWindow = _top.isSingleModalPopupWindowActive();
            }

            var _modalWin = getCurrentModalWindow(singleWindow);
            if (null != _modalWin) {
                if (typeof title == "undefined") {
                    var titleObj = document.getElementsByTagName("title");
                    if (null != titleObj && titleObj.length > 0) {
                        title = titleObj[0].innerHTML;
                    } else {
                        title = "&nbsp;";
                    }
                }

                _modalWin.setTitle(_top.adjustModalWindowTitle(title));
                return true;
            }
        }
    }
    catch (e) {
        // ignore
    }

    return false;
}

/**
 * Get the title of a modal window
 * @param singleWindow if this value is true, get the title of the single modal window
 */
function getWindowTitle(singleWindow) {
    var title = "";
    try {
        var _top = getModalTop();
        if (null != _top && isModalWindowMode()) {
            var _modalWin = getCurrentModalWindow(singleWindow);
            if (null != _modalWin) {
                title = _modalWin.getTitle();
            }
        }
    }
    catch (e) {
        // ignore
    }

    return title;
}

/**
 * Open a new modal window
 * @param caller caller object, usuall this value is this, mandatory parameter
 * @param sURL a url to call, this is a mandatory parameter
 * @param title title a window name, mandatory parameter
 * @param width window width, if you wnat to use the whole width, use 100% as this value, mandatory parameter
 * @param height window height, if you want to use the whole height, use 100% as this value, mandatory parameter
 * @param sFeatures window features such as "scrollbars=no,status=no,toolbar=no,resizable=yes"
 * @param left the initial left position of a window
 * @param top the initial top position of a window
 * @param isForcedModal forces a window modal
 */
function openNewWindow(caller, sURL, title, width, height, sFeatures, left, top, isForcedModal) {
    var lastFocusedElement = document.activeElement;
    try {
        if(lastFocusedElement) {
            if("BODY" == lastFocusedElement.tagName.toUpperCase()) {
                lastFocusedElement = parent.window.document.activeElement.contentWindow.document.activeElement;
            }
        }
    } catch(e) {}
    try {
        var evt = event || window.event;
        if (typeof evt != "undefined") {
            if(typeof evt.srcElement.focus === 'function'){
	            lastFocusedElement = evt.srcElement;
            }
        }
    } catch(e) {}
    if (typeof isForcedModal == "undefined") {
        isForcedModal = false;
    }
    if (typeof sFeatures == "undefined") {
        sFeatures = "";
    }

    var _modalWin = null;
    var _top = getModalTop();

    if(null != _top && isForcedModal){	// force to modal popup
        _modalWin = _top.openModalPopupWindowEx(caller, sURL, title, width, height, sFeatures, left, top, lastFocusedElement);
    }
    else {
        if (null != _top && isModalWindowMode()) {
            _modalWin = _top.openModalPopupWindowEx(caller, sURL, title, width, height, sFeatures, left, top, lastFocusedElement);
        }
        else {
            _modalWin = _newWindowOpen(sURL, title, width, height, sFeatures);
        }
    }

    return _modalWin;
}

/**
 *  close top window
 */
function _topClose() {
    var _opener = null;
    if (opener) {
        _opener = opener;
    }
    else if (top.opener) {
        _opener = top.opener;
    }

    if (null != _opener) {
        try {
            if (typeof(_opener.blockEvents) != "undefined") // in case of Mac
            {
                try {
                    _opener.blockEvents();
                } catch (e) {
                    //bug 20303
                    top.window.close();
                }
            }
            else {
                if(!top.window.close()) { // Using "Kendo Modal Window UI"
                    var openDialog = window.top.$("#topModalWindow").data("kendoWindow");
                    openDialog.close();
                }
            }
        }
        catch (e) {
            top.window.close();
        }
    } else {
        var openDialog = window.top.$("#topModalWindow").data("kendoWindow");
        if(openDialog) {
            openDialog.close();
        } else {
            top.close();
            // Scripts may not close windows that were not opened by the script
            try {
                if(!top.closed) {
                    var workitemdoneUrl = "";
                    if("undefined" != typeof(getBizFlowContextPath)) {
                        workitemdoneUrl = getBizFlowContextPath() + "/bizcoves/wih/";
                    }
                    workitemdoneUrl += "workitemdone.jsp?msgId=MSG_WORKITEM_CLOSED";

                    top.location.replace(workitemdoneUrl);
                }
            } catch(e) {};
        }
    }
}

/**
 * Close a modal window
 * @param singleWindow if this value is true, close the single modal window
 */
function closeWindow(singleWindow, modalWinMode) {
    var dialog = getModalDialogWindow();
    if(null != dialog) {
        dialog.close();
        return;
    }

    var _top = getModalTop();
    if (null != _top && (("undefined" != typeof(modalWinMode) && modalWinMode) || isModalWindowMode())) {
        if ("undefined" == typeof(singleWindow)) {
            singleWindow = _top.isSingleModalPopupWindowActive();
        }

        if (singleWindow) {
            _top.closeSingleModalPopupWindow();
        }
        else {
            var closed = _top.closeModalPopupWindow();
            if (closed == false) {
                _topClose();
            }
        }
    }
    else {
        _topClose();
    }
}

function setModalPopupToolbar(html) {
    var _top = getModalTop();
    if (null != _top && isModalWindowMode()) {
        _top.setModalPopupToolbar(html);
    }
}

function setModalPopupSubTitle(html) {
    var _top = getModalTop();
    if (null != _top && isModalWindowMode()) {
        _top.setModalPopupSubTitle(html);
    }
}

function adjustWindowSize(viewAreaIds) {
    try {
        var _body = document.body;
        var docW = _body.scrollWidth;
        var docH = _body.scrollHeight;
        var _top = getModalTop();
        var ids = null;

        if (typeof viewAreaIds != "undefined") {
            ids = viewAreaIds.split(",");
        }

        if (null != _top && isModalWindowMode()) {
            if (BrowserDetect.isExplorer()) {
                if (null != ids) {
                    for (var i = 0; i < ids.length; i++) {
                        var obj = document.getElementById(ids[i]);
                        if (null != obj) {
                            obj.style.width = docW;
                        }
                    }
                }
            }

            _top.resizeModalPopupWindow(docW, docH);
        }
    }
    catch (e) {
    }
}

/*************** Single Modal Popup Window ****************************/
/**
 * Get the caller of the single modal window
 */
function getSingleModalCaller() {
    return getModalCaller(true);
}

/**
 * Set the title of the single modal window
 * @param title
 */
function setSingleWindowTitle(title) {
    setWindowTitle(title, true);
}

/**
 * Get the title of the single modal window
 */
function getSingleWindowTitle() {
    return getWindowTitle(true);
}

/**
 *  Open the single modal window
 * @param caller caller object, usuall this value is this, mandatory parameter
 * @param sURL a url to call, this is a mandatory parameter
 * @param title title a window name, mandatory parameter
 * @param width window width, if you wnat to use the whole width, use 100% as this value, mandatory parameter
 * @param height window height, if you want to use the whole height, use 100% as this value, mandatory parameter
 * @param sFeatures window features such as "scrollbars=no,status=no,toolbar=no,resizable=yes"
 * @param left the initial left position of a window
 * @param top the initial top position of a window
 */
function openNewSingleWindow(caller, sURL, title, width, height, sFeatures, left, top) {
    var _modalWin = null;
    var _top = getModalTop();
    if (null != _top && isModalWindowMode()) {
        _modalWin = _top.openSingleModalPopupWindowEx(caller, sURL, title, width, height, sFeatures, left, top);
    }
    else {
        _modalWin = _newWindowOpen(sURL, title, width, height, sFeatures);
    }

    return _modalWin;
}

/**
 * Close the single modal window
 */
function closeSingleWindow() {
    closeWindow(true);
}

function getCurrentModalPopupWindow() {
    var _top = getModalTop();
    var _modal = null;

    if (null != _top) {
        _modal = _top.getCurrentModalPopupWindow();
    }

    return _modal;
}

/*************** ETC ****************************/
/**
 *  Open a calendar window
 * @param caller caller object, usuall this value is this
 * @param targetName  a target name for example, document.theForm.date
 * @param defaultDate the initial date
 * @param mode calendar mode, the value can be one of "", "datetime"
 * @param format date format
 */
function openCalendarWindow(caller, targetName, defaultDate, mode, format) {
    var _top = getModalTop();

    if (null != _top) {
        _top.openCalendarWindow(caller, targetName, defaultDate, mode, format);
    }
}

function reloadCallerPage(singleWindow) {
    var caller = getModalCaller(singleWindow);
    if (caller && caller.reloadPage) {
        try {
            caller.reloadPage();
        }
        catch (e) {
        }
    }
}

/*************** Modal Dialog Window ****************************/
function getModalDialogTop() {
    var _top = null;
    if("undefined" != typeof(top) && "undefined" != typeof(top.opener)) {
        _top = top;
    } else {
        _top = getModalPopupTop();
    }

    return _top;
}

function _openModalDialogWindow(caller, winName, modalType, url, title, sFeatures, reCalOnLoad) {
    var dialogWin = null;
    var _top = getModalDialogTop();
    if (_top && "undefined" != typeof(_top.dhtmlwindow)) {
        dialogWin = _top.dhtmlwindow.open(winName, modalType, url, title, sFeatures, reCalOnLoad);
        dialogWin.caller = caller;
    }

    return dialogWin;
}

function _getModalDialogWindowOption(opt) {
    var option = 0;
    if (typeof(opt) == 'string') {
        option = opt.toLowerCase() == "true" ? 1 : 0;
    } else if (typeof(opt) == 'number') {
        option = opt;
    } else if (typeof(opt) == 'boolean') {
        option = opt ? 1 : 0;
    }

    return option;
}

function openNewModalDialogWindow(caller, url, winName, title, width, height, scroll, resize) {
    var scrolling = _getModalDialogWindowOption(scroll);
    var resizing = _getModalDialogWindowOption(resize);
    var sFeatures = "width=" + width + "px,height=" + height + "px,minimize=0,center=1,resize=" + resizing + ",scrolling=" + scrolling;

    return _openModalDialogWindow(caller, winName, "iframe", url, title, sFeatures);
}

function getModalDialogWindow() {
    var dialogWin = null;
    var p = parent;
    var found = false;
    while (null != p && "undefined" != typeof(p)) {
        var iframes = p.document.getElementsByTagName("iframe");
        if (iframes) {
            for (var i = 0; i < iframes.length; i++) {
                var iframe = iframes[i];
                var name = iframe.getAttribute("name");
                if (null != name && name.indexOf("_iframe-") == 0) {
                    found = true;
                    var dialogName = name.substring("_iframe-".length);
                    dialogWin = p.document.getElementById(dialogName);
                    if(null != dialogWin) {
                        if(dialogWin.closed) {
                            dialogWin = null;
                        }
                    }
                    break;
                }
            }

            if(found) {
                break;
            }

            if(p != p.parent) {
                p = p.parent;
            } else {
                break;
            }
        }
    }

    return dialogWin;
}

