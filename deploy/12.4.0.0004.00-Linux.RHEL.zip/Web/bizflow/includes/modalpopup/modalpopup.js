var _currentActiveModal = null;

var _modalOffsetX = 0;
var _modalOffsetY = 0;
var _modalTempX = 0;
var _modalTempY = 0;
var _dragApproved = false;

function ModalPopup(parentObj, id, initialWidth, initialHeight) {
    this.parentObj = parentObj;
    this.lastFocusedElement = null;
    this.id = id;
    this.maxIconName = this.id + "MaxIcon";
    this.minrestore = -1;
    this.initialWidth = "100%";
    if ("undefined" != typeof(initialWidth)) this.initialWidth = initialWidth;
    this.initialHeight = "100%";
    if ("undefined" != typeof(initialHeight)) this.initialHeight = initialHeight;
    this.ie = BrowserDetect.isExplorer();
    this.firefox = BrowserDetect.isFirefox() || BrowserDetect.isChrome();
    this.modalBasePath = "";

    this.wantedWidth = 0;
    this.wantedHeight = 0;
    this.initialPopupX = -1;
    this.initialPopupY = -1;
    this.modalBasePath = "";
    this.blankPageURL = "";
    this.padding = new Object();
    this.padding.width = 0;
    this.padding.height = 0;

    this.closed = true;
    this.caller = null;
    this.features = null;
    this.url = null;

    this.adjustTitleWidth = null;
    this.closeEventHandler = null;
    this.closeEventUrl = null;
    this.basicWihReadOnly = 'n';

    this.initialize = function (x, i) {
        x = document.body || null;
        var __ie = x && typeof x.insertAdjacentHTML != "undefined";
        var __dom = (x && !__ie &&
            typeof x.appendChild != "undefined" &&
            typeof document.createRange != "undefined" &&
            typeof (i = document.createRange()).setStartBefore != "undefined" &&
            typeof i.createContextualFragment != "undefined");
        var __ihtm = !__ie && !__dom && x && typeof x.innerHTML != "undefined";
        var __moz = __dom && typeof x.style.MozOpacity != "undefined";

        this.ie = __ie;
        this.firefox = __moz;

        var scriptTags = document.getElementsByTagName("script");
        for (var i = 0; i < scriptTags.length; i++) {
            if (scriptTags[i].src && scriptTags[i].src.match(/modalpopup\.js$/)) {
                this.modalBasePath = scriptTags[i].src.replace(/modalpopup\.js$/, '');
                break;
            }
        }

        var modal = this.getModalElement();
        if (modal) {
            this.initialWidth = modal.style.width;
            this.initialHeight = modal.style.height;
        }
    };

    this.getParentObj = function () {
        return this.parentObj;
    };

    this.setParentObj = function (parentObj) {
        this.parentObj = parentObj;
    };

    this.getModalElement = function () {
        return document.getElementById(this.id);
    };

    this.getModal3DElementName = function () {
        return (this.id + "3D");
    };

    this.getModalTitleBarBoxElementName = function () {
        return (this.id + "TitleBarBox");
    };

    this.getModalTitleBarElementName = function () {
        return (this.id + "TitleBar");
    };

    this.getModalBottomElementName = function () {
        return (this.id + "Bottom");
    };

    this.getModalOverlayElementName = function () {
        return (this.id + "Overlay");
    };

    this.getModalContentElementName = function () {
        return (this.id + "Content");
    };

    this.getModalFrameElementName = function () {
        return (this.id + "Frame");
    };

    this.getModalCloseButtonElementName = function () {
        return (this.id + "CloseButton");
    };

    this.getModal3DElement = function () {
        return document.getElementById(this.getModal3DElementName());
    };

    this.getModalTitleBarBoxElement = function () {
        return document.getElementById(this.getModalTitleBarBoxElementName())
    };

    this.getModalBottomElement = function () {
        return document.getElementById(this.getModalBottomElementName());
    };

    this.getModalOverlayElement = function () {
        return document.getElementById(this.getModalOverlayElementName());
    };

    this.getModalContentElement = function () {
        return document.getElementById(this.getModalContentElementName());
    };

    this.getModalFrameElement = function () {
        return document.getElementById(this.getModalFrameElementName());
    };

    this.getModalCloseButton = function () {
        return document.getElementById(this.getModalCloseButtonElementName());
    };

    this.getModalWindowTitleBarElement = function () {
        var titleBar = document.getElementById(this.getModalTitleBarBoxElementName());
        return titleBar;
    };

    this.modalIECompattest = function () {
        return (!window.opera && document.compatMode && document.compatMode != "BackCompat") ? document.documentElement : document.body;
    };

    this.dragDrop = function (e) {
	    if(_dragApproved)
	    {
		    var modal = _currentActiveModal;
		    if (BrowserDetect.isExplorer() && event.button == 1) {
			    modal.style.left = _modalTempX + event.clientX - _modalOffsetX + "px";
			    modal.style.top = _modalTempY + event.clientY - _modalOffsetY + "px";
		    }
		    else {
			    modal.style.left = _modalTempX + e.clientX - _modalOffsetX + "px";
			    modal.style.top = _modalTempY + e.clientY - _modalOffsetY + "px";
		    }
	    }
    };

    this.initializeDrag = function (e) {
        var modal = this.getModalElement();
        var modalContent = this.getModalContentElement();

        _modalOffsetX = this.ie ? event.clientX : e.clientX;
        _modalOffsetY = this.ie ? event.clientY : e.clientY;

        //modal.style.display = "none";
        //modalContent.style.display = "none";

        _modalTempX = parseInt(modal.style.left);
        _modalTempY = parseInt(modal.style.top);
        _dragApproved = true;

        _currentActiveModal = modal;
        modal.onmousemove = this.dragDrop;
    };

    this.stopDrag = function () {
        var modal = this.getModalElement();
        var modalContent = this.getModalContentElement();

        this._dragApproved = false;
        modal.onmousemove = null;
        modalContent.style.display = "";
    };

    /**
     * Set a modal window title
     * @param title title string
     */
    this.setTitle = function (title) {
        var titleBar = this.getModalWindowTitleBarElement();

        if (null != titleBar) {
            if (title == "") {
                title = "&nbsp;";
            }

            if ("undefined" != typeof(titleBar.contentWindow)) {
                setTitle(this.id, title);
            }
            else if (typeof setTitle != "undefined") {
                setTitle(this.id, title);
            }
        }
    };

    /**
     * Get a window title
     */

    this.getTitle = function () {
        var titleBar = this.getModalWindowTitleBarElement();
        var title = "";

        if (null != titleBar) {
            if ("undefined" != typeof(titleBar.contentWindow)) {
                title = titleBar.contentWindow.getTitle();
            }
            else if (titleBar.getTitle) {
                title = titleBar.getTitle(this.id);
            }
        }

        return title;
    };

    /**
     * Set event handler to be called when a popup window is closed.
     * @param eventHandler
     */
    this.setCloseEventHandler = function (eventHandler, url, basicWihReadOnly) {
        this.closeEventHandler = eventHandler;
        this.closeEventUrl = url;
        if ("undefined" == typeof(basicWihReadOnly)) {
            basicWihReadOnly = 'n';
        }
        this.basicWihReadOnly = basicWihReadOnly;
    };

    this.getCloseEventHandler = function () {
        return this.closeEventHandler;
    };

    this.getCloseEventUrl = function () {
        return this.closeEventUrl;
    };

    /**
     * Load a url
     */
    this.load = function (url) {
        this.setCloseEventHandler(null, null);

        var modalFrame = this.getModalFrameElement();
        // in case of plumtree, plumtree does not handle a code to load a url in a js so make a exposed function on jsp and call it
        //modalFrame.src = url;
        loadFrameURL(modalFrame, url);
        this.url = url;

        //modalFrame.setAttribute("title", getTitle(this.id));
    };

    /**
     * Open a modal window
     * @param url a url to call
     * @param title the title of a modal window
     * @param width the width of a modal window
     * @param height the height of a modal window
     * @param sFeatures the features of a modal window, this is optioal and has same valuea as the feature of window.open()
     */
    this.open = function (url, title, width, height, sFeatures) {
        this.wantedWidth = width;
        this.wantedHeight = height;

        this.features = parseFeatures(sFeatures);
//        if (typeof this.features.paddingWidth != "undefined") {
//            this.padding.width = _getInt(this.features.paddingWidth);
//        }

//        if (typeof this.features.paddingHeight != "undefined") {
//            this.padding.height = _getInt(this.features.paddingHeight);
//        }

        this.showCloseButton();

        if (typeof this.features.closeButton != "undefined") {
            if (this.features.closeButton.toLowerCase() == "no") {
                this.hideCloseButton();
            }
        }

	    this.resizeTo(width, height, null, false);
        this.show();
        this.setTitle(title);

        this.load(url);

        if ("undefined" != typeof(this.features.max) && (this.features.max.toLowerCase() == "yes" || this.features.max == "1")) {
            this.minrestore = 0;
            this.maximize();
        }
    };

    this.setLastFocusedElement = function(element){
        this.lastFocusedElement = element;
    };

    /**
     * This method is to hanle onmove event
     */
    this.onmove = function () {
        var availWidth = this.modalIECompattest().clientWidth;
        var availHeight = this.modalIECompattest().clientHeight;

        var screenOffset = this.getModalScreenOffset();

        var leftPosition = (availWidth - parseInt(this.initialWidth) + screenOffset.width) / 2;
        var topPosition = (availHeight - parseInt(this.initialHeight) + screenOffset.height) / 2;

        if (leftPosition < 0) leftPosition = 0;
        if (topPosition < 0) topPosition = 0;

        this.moveTo(leftPosition, topPosition);
    };

    /**
     * This method is to handle onresize event
     */
    this.onresize = function () {
        this.resizeTo(this.wantedWidth, this.wantedHeight);
        this.show();
    };

    /**
     * Get the size of a client screen
     * @return an object which has width and height attributes
     * obj.clientWidth: the width of a client screen
     * obj.clientHeight: the height of a client screen
     */
    this.getClientScreenSize = function () {
        var client = this.modalIECompattest();
        var size = new Object();

        if (BrowserDetect.OS == BrowserDetect.OSIPad || BrowserDetect.OS == BrowserDetect.OSIPhone) {
            var domclientWidth = document.documentElement && parseInt(document.documentElement.clientWidth) || 100000; //Preliminary doc width in non IE browsers
            size.clientWidth = (/Safari/i.test(navigator.userAgent)) ? window.innerWidth : Math.min(domclientWidth, window.innerWidth - 16);
            size.clientHeight = window.innerHeight;
        } else {
            size.clientWidth = client.clientWidth;
            size.clientHeight = client.clientHeight;
        }

        return size;
    };

    /**
     * Get the scroll size of a client screen
     * @return an object which has width and height attributes
     * obj.scrollWidth: the scroll width of a client screen
     * obj.scrollHeight: the scroll height of a client screen
     */
    this.getClientScreenScrollSize = function () {
        var client = this.modalIECompattest();
        var size = new Object();

        size.scrollWidth = client.scrollWidth;
        size.scrollHeight = client.scrollHeight;

        return size;
    };

    /**
     * Get the size of a screen
     * @return an object which has width and height attributes
     * obj.width: the width of a client screen
     * obj.height: the height of a client screen
     */
    this.getScreenSize = function () {
        var size1 = this.getClientScreenSize();
        var size2 = this.getClientScreenScrollSize();
        var width = size2.scrollWidth;
        var height = size2.scrollHeight;

        if (size1.clientWidth > size2.scrollWidth) {
            width = size1.clientWidth;
        }

        if (size1.clientHeight > size2.scrollHeight) {
            height = size1.clientHeight;
        }

        var size = new Object();
        size.width = width;
        size.height = height;

        return size;
    };

    /**
     * Revise size as the size of a client screen.
     * if width or height has percentage value, they will be calculated with a client screen width
     * @return an object which has width and height attributes
     * obj.width: a width calculated
     * obj.hegith: a heigt calculated
     */
    this.reviseSize = function (width, height) {
        var clientSize = this.getClientScreenSize();
        if (("" + width).indexOf("%") != -1) {
            var w = parseInt(width);
            width = clientSize.clientWidth * w / 100;
        }

        if (("" + height).indexOf("%") != -1) {
            var h = parseInt(height);
            height = clientSize.clientHeight * h / 100;
        }

        var size = new Object();
        size.width = width;
        size.height = height;

        return size;
    };

    this.getModalScreenOffset = function () {
        var offset = getModalScreenOffset();
        return offset;
    };


    this.setTitleWidth = function (width) {
        var titleSpan = document.getElementById(this.id + "Title");
        titleSpan.style.width = width;
    };

    this.autoSetTitleWidth = function () {
        var div = document.getElementById(this.id + "Title");
        if (null != div) {
            div.style.width = div.parentNode.clientWidth;
        }
    };

    this.getClientViewPoint = function () {
        var vp = new Object();
        var ie = BrowserDetect.isExplorer();
        var domclientWidth = document.documentElement && parseInt(document.documentElement.clientWidth) || 100000; //Preliminary doc width in non IE browsers
        var standardbody = (document.compatMode == "CSS1Compat") ? document.documentElement : document.body; //create reference to common "body" across doctypes
        vp.scrollTop = (ie) ? standardbody.scrollTop : window.pageYOffset;
        vp.scrollLeft = (ie) ? standardbody.scrollLeft : window.pageXOffset;
        vp.clientWidth = (ie) ? standardbody.clientWidth : (/Safari/i.test(navigator.userAgent)) ? window.innerWidth : Math.min(domclientWidth, window.innerWidth - 16);
        vp.clientHeight = (ie) ? standardbody.clientHeight : window.innerHeight;

        return vp;
    };

    /**
     * Resize a modal window
     * @param width width, mandatory
     * @param height height, mandatory
     * @param sFeatures, features string. for example, left=10, top=20,...
     * @param features, features object
     */
    this.resizeTo = function (width, height, sFeatures, adjustTitleWidth) {
        this.adjustTitleWidth = adjustTitleWidth;
        if (adjustTitleWidth || typeof(adjustTitleWidth) == "undefined") {
            this.setTitleWidth(50);
        }

        if (typeof sFeatures != "undefined" && null != sFeatures) {
            this.features = parseFeatures(sFeatures);
        }

        var modalSize = this.reviseSize(width, height);
        var screenOffset = this.getModalScreenOffset();
        var clientSize = this.getClientScreenSize();

        var _width = clientSize.clientWidth + screenOffset.width;
        var _height = clientSize.clientHeight + screenOffset.height;

        if (modalSize.width > _width) {
            modalSize.width = _width;
        }

        if (modalSize.height > _height) {
            modalSize.height = _height;
        }

        var leftPosition = (clientSize.clientWidth - modalSize.width + screenOffset.width) / 2;
        var topPosition = (clientSize.clientHeight - modalSize.height + screenOffset.height) / 2;

        if (leftPosition < 0) leftPosition = 0;
        if (topPosition < 0) topPosition = 0;

        if (BrowserDetect.OS == BrowserDetect.OSIPad || BrowserDetect.OS == BrowserDetect.OSIPhone) {
            var vp = this.getClientViewPoint();
            leftPosition += vp.scrollLeft;
            topPosition += vp.scrollTop;
        }

//        alert("modalpopup.js: leftPosition=" + leftPosition + ", topPosition=" + topPosition + ", clientSize=" + clientSize.clientWidth + "x" + clientSize.clientHeight + ", modalSize=" + modalSize.width + "x" + modalSize.height
//        + ",vp=" + vp.scrollTop + "," + vp.scrollLeft + "," + vp.clientWidth + "," + vp.clientHeight) ;

        var modal = this.getModalElement();
        var modalContent = this.getModalContentElement();
        var modalFrame = this.getModalFrameElement();
	    var modalToolBar = this.getModalTitleBarBoxElement();

        // set size
        modalContent.style.width = modal.style.width = this.initialWidth = modalSize.width + "px";
	    modal.style.height = modalSize.height;
        this.initialHeight = modalSize.height + "px";
	    modalFrame.style.height = modalContent.style.height = (parseInt(modalSize.height) - parseInt(modalToolBar.style.height)) + "px";

        // padding
        modal.style.width = (parseInt(modal.style.width) + this.padding.width) + "px";
        modal.style.height = (parseInt(modal.style.height) + this.padding.height) + "px";

        if ("undefined" != typeof(this.features.left)) {
            leftPosition = parseInt(this.features.left);
        }

        if ("undefined" != typeof(this.features.top)) {
            topPosition = parseInt(this.features.top);
        }

        modal.style.left = leftPosition + "px";
        modal.style.top = topPosition + "px";

        this.initialPopupX = modal.style.left;
        this.initialPopupY = modal.style.top;

//        var modal3D = this.getModal3DElement();
//        if (modal3D) {
//            var modalToolBar = this.getModalTitleBarBoxElement();
//            var modalBottom = this.getModalBottomElement();
//            var clientHeight = parseInt(document.body.clientHeight);
//
//            var _offsetLeft = 10;
//            var _offsetTop = 10;
//
//            if (leftPosition < _offsetLeft) {
//                _offsetLeft = leftPosition;
//            }
//
//            if (topPosition < _offsetTop) {
//                _offsetTop = topPosition;
//            }
//
//            var _mH = parseInt(modal.style.height);
//            var _tH = parseInt(modalToolBar.style.height);
//            var _bH = parseInt(modalBottom.style.height);
//
//            modal3D.style.width = modal.style.width;
//            modal3D.style.height = _mH + _tH + _bH;
//            modal3D.style.left = leftPosition + _offsetLeft;
//            modal3D.style.top = topPosition + _offsetTop;
//
//            var _3DTop = parseInt(modal3D.style.top);
//            var _3DHeight = parseInt(modal3D.style.height);
//
//            if (_3DTop + _3DHeight > clientHeight) {
//                modal3D.style.height = clientHeight - _3DTop;
//            }
//
//            modal.style.left = -_offsetLeft;
//            modal.style.top = -_offsetTop;
//        }

        if (adjustTitleWidth || typeof(adjustTitleWidth) == "undefined") {
            this.autoSetTitleWidth();
        }
    };

    /**
     * Move a modal window
     * @param left the left position
     * @param top the top position
     */
    this.moveTo = function (left, top) {
        var modal = this.getModalElement();
        modal.style.left = left;
        modal.style.top = top;
    };

    /**
     * Get the width of a modal window
     */
    this.getWidth = function () {
        var modal = this.getModalElement();
        return parseInt(modal.style.width);
    };

    /**
     * Get the height of a modal window
     */
    this.getHeight = function () {
        var modal = this.getModalElement()
        return parseInt(modal.style.height);
    };

    /**
     * Get a modal window size
     */
    this.getSize = function () {
        var obj = new Object();
        obj.width = this.getWidth();
        obj.height = this.getHeight();

        return obj;
    };

    this.getInitialSize = function () {
        var obj = new Object();
        obj.width = this.initialWidth;
        obj.height = this.initialHeight;

        return obj;
    };

    this.forceMaximize = function (maxIconObj, left, top) {
        this.minrestore = 0;
        this.maximize(maxIconObj, left, top);
    };

    this.forceMinimize = function (maxIconObj, left, top) {
        this.minrestore = 1;
        this.maximize(maxIconObj, left, top);
    };

    this.maximize = function (maxIconObj, left, top) {
        var modalOverlay = this.getModalOverlayElement();
        var modal = this.getModalElement();
        var modalContent = this.getModalContentElement();
        var modalFrame = this.getModalFrameElement();

        if ("undefined" == typeof(maxIconObj)) {
            maxIconObj = document.getElementById(this.maxIconName);
        }

        if (this.minrestore <= 0) {
            //maximize window
            this.minrestore = 1;
            if (null != maxIconObj) maxIconObj.setAttribute("src", this.modalBasePath + "restore.gif");

            var width = this.ns6 ? window.innerWidth - 20 + "px" : this.modalIECompattest().clientWidth + "px";
            var height = this.ns6 ? window.innerHeight - 20 + "px" : this.modalIECompattest().clientHeight + "px";

            if ("undefined" != typeof(left) || "undefined" != typeof(top)) {
                modal.style.position = "absolute";
                //height = "100%";
            }

            if ("undefined" == typeof(left)) {
                left = this.ns6 ? window.pageXOffset + "px" : this.modalIECompattest().scrollLeft + "px";
            }

            if ("undefined" == typeof(top)) {
                top = this.ns6 ? window.pageYOffset + "px" : this.modalIECompattest().scrollTop + "px";
            }

            modal.style.top = top;
            modal.style.left = left;

            modalContent.style.width = modal.style.width = width;
            modalContent.style.height = modal.style.height = height;

            modalFrame.style.width = width;
            modalFrame.style.height = height;

        }
        else {
            //restore window
            this.minrestore = 0;

            if ("undefined" != typeof(left) || "undefined" != typeof(top)) {
                modal.style.position = "relative";
            }

            if (null != maxIconObj) {
                maxIconObj.setAttribute("src", this.modalBasePath + "max.gif");
            }

            if (this.initialPopupX != -1) modal.style.left = this.initialPopupX;
            else modal.style.left = this.ns6 ? window.pageXOffset + "px" : this.modalIECompattest().scrollLeft + "px";

            if (this.initialPopupY != -1) modal.style.top = this.initialPopupY;
            else modal.style.top = this.ns6 ? window.pageYOffset + "px" : this.modalIECompattest().scrollTop + "px";

            modal.style.width = this.initialWidth;
            modal.style.height = this.initialHeight;

            modalFrame.style.width = modalContent.style.width = "100%";
            modalFrame.style.height = modalContent.style.height = "100%";
        }
    };

    /**
     * Show a modal window
     */
    this.show = function () {
        this.setCallerStyle(false);
        this.closed = false;
        this.lastFocusedElement = null;

        var effect = false;
        var modalOverlay = this.getModalOverlayElement();
        if (null != modalOverlay) {
            var size = this.getScreenSize();

            modalOverlay.style.width = size.width;
            modalOverlay.style.height = size.height;
            modalOverlay.style.display = '';
			modalOverlay.style.zIndex = 1000;
        }
        try {

            var frameWindow = this.getCaller();
            var frameElement = frameWindow.frameElement;
            if(this.id == "modalPopupMax0") {
                frameElement = this.parentObj.document.querySelector("#workAreaFrame");
            } else {
                do {
                    if(frameElement) {
                        if(frameElement.getAttribute("popupContent") == "true") {
                            break;
                        } else {
                            frameWindow = frameWindow.parent;
                            frameElement = frameWindow.frameElement;
                        }
                    } else {
                        break;
                    }
                } while(true);
            }
            if(frameElement) {
                frameElement.setAttribute("tabindex", "-1");
                var modalPopupMaxCloseButtonId = frameElement.id.replace("Frame", "CloseButton");
                if(modalPopupMaxCloseButtonId) {
                    var modalPopupMaxCloseButton = frameElement.ownerDocument.querySelector("#" + modalPopupMaxCloseButtonId);
                    if(modalPopupMaxCloseButton) {
                        modalPopupMaxCloseButton.setAttribute("tabindex", "-1");
                    }
                }
            }
        } catch(e) {}
        var modal = this.getModalElement()
        modal.style.display = '';
		modal.style.zIndex = 1000;

        var modal3D = this.getModal3DElement();
        if (null != modal3D) {
            modal3D.style.display = "";
			modal3D.style.zIndex = 1000;
        }
    };

    /**
     * Hide the close button on a modal dialog
     */
    this.hideCloseButton = function () {
        var closeButton = this.getModalCloseButton();
        closeButton.style.display = "none";
    };

    /**
     * Show the close button on a modal dialog
     */
    this.showCloseButton = function () {
        var closeButton = this.getModalCloseButton();
        closeButton.style.display = "";
    };

    /**
     * Hide a modal window
     * @param resetFrameSrc
     */
    this.hide = function (resetFrameSrc) {
        this.setCallerStyle(true);

        if (resetFrameSrc) {
            this.clear();
        }

        var modalOverlay = this.getModalOverlayElement();
        if (null != modalOverlay) {
            modalOverlay.style.display = 'none';
        }
        try {
            var frameWindow = this.getCaller();
            var frameElement = frameWindow.frameElement;
            if(this.id == "modalPopupMax0") {
                frameElement = this.parentObj.document.querySelector("#workAreaFrame");
            } else {
                do {
                    if(frameElement) {
                        if(frameElement.getAttribute("popupContent") == "true") {
                            break;
                        } else {
                            frameWindow = frameWindow.parent;
                            frameElement = frameWindow.frameElement;
                        }
                    } else {
                        break;
                    }
                } while(true);
            }
            if(frameElement) {
                frameElement.setAttribute("tabindex", "0");
                var modalPopupMaxCloseButtonId = frameElement.id.replace("Frame", "CloseButton");
                if(modalPopupMaxCloseButtonId) {
                    var modalPopupMaxCloseButton = frameElement.ownerDocument.querySelector("#" + modalPopupMaxCloseButtonId);
                    if(modalPopupMaxCloseButton) {
                        modalPopupMaxCloseButton.setAttribute("tabindex", "0");
                    }
                }
            }
        } catch(e) {}
        var modal = this.getModalElement();
        modal.style.display = "none";

        var modal3D = this.getModal3DElement();
        if (null != modal3D) {
            modal3D.style.display = 'none';
        }
    };

    /**
     * Clear a modal window content
     */
    this.clear = function () {
        var modalFrame = this.getModalFrameElement();
        // in case of plumtree, plumtree does not handle a code to load a url in a js so make a exposed function on jsp and call it
        //modalFrame.src = this.blankPageURL;
        loadFrameURL(modalFrame, this.blankPageURL)
    };

    this.writeClear = function () {
        var modalFrame = this.getModalFrameElement();
        var doc = modalFrame.contentWindow.document;
        doc.open();
        doc.write("&nbsp;");
        doc.close();
    };

    this.setScrollOption = function (option) {
        if (BrowserDetect.isExplorer()) {
            var modalFrame = this.getModalFrameElement();
            modalFrame.scrolling = option;
        }
    };

    this.setBlankPageURL = function (blankPageURL) {
        this.blankPageURL = blankPageURL;
    };

    this.focus = function () {
    };

    this.undoCheckout = function () {
        if('y' == this.basicWihReadOnly) {
            return;
        }
        try
        {
            if (this.caller != null && typeof(this.caller) != 'undefined') {
                if (this.caller.wih_undo && "undefined" != typeof(this.caller.wih_undo)) {
                    this.caller.wih_undo(this.basicWihReadOnly);
                }
            }
        }
        catch(e) {
            if (console && console.error) {
                console.error(e);
            }
        }
    };

    /**
     * Cloase a modal window
     * @decreaseIndex  if this value is true, decrease the number which has the count of executed modal window
     */
    this.close = function (decreaseIndex, where) {
        var _closeContinue = true;

        // Call predefined function on caller to fire close event
        if (typeof(where) != "undefined" && where.toLowerCase() == "toolbar") {
            if (null != this.caller && typeof(this.caller.onModalPopupClose) != "undefined") {
                var _rc = this.caller.onModalPopupClose();
                if (typeof(_rc) != "undefined") {
                    _closeContinue = _rc;
                }
            }
        }

        if (_closeContinue) {
            if (this.closed == false) {
                this.undoCheckout();
                if (this.adjustTitleWidth) {
                    this.setTitleWidth(50);
                }
                this.closed = true;

                if ("undefined" == typeof(decreaseIndex) || (decreaseIndex != false)) {
                    if (null != parentObj && typeof parentObj._decreaseModalIndex != "undefined") {
                        parentObj._decreaseModalIndex();
                    }
                }

                this.hide(true);
            }
        }
        // begin -- cs-26060
        try {
            var modalFrame = this.getModalFrameElement();
            var objs = modalFrame.contentWindow.document.getElementsByTagName("*");
            if(objs.length > 0) {
                this.purge(objs);
            }
            if(typeof(CollectGarbage) == "function") {
                CollectGarbage();
            }
        } catch(e) {
        }
        // end -- cs-26060
        return this.closed;
    };
    // begin -- cs-26060
    this.purge = function (elem) {
        var i, attrs, nodeName;
        if ("undefined" == typeof(elem)) {
            return;
        }
        if((null != elem.attributes) && "undefined" != typeof(elem.attributes)) {
            attrs = elem.attributes;
            for(i = attrs.length -1; i >= 0; i--) {
                nodeName = attrs[i].name;
                if(typeof elem[nodeName] === "function") {
                    elem[nodeName] = null;
                }
            }
        }
        if((null != elem.childNodes) && "undefined" != typeof(elem.childNodes)) {
            attrs = elem.childNodes;
            for (i = 0; i < attrs.length; i++) {
                this.purge(elem.childNodes[i]);
            }
        }
    }
    // end -- cs-26060

    this.setCaller = function (caller) {
        this.caller = caller;
    };

    this.getCaller = function () {
        return this.caller;
    };

    /**
     * This method hide or show objects on the caller.
     * In case of IE6, select boxes show up the front
     */
    this.setCallerStyle = function (visible) {
        try {
            this.caller.setObjectVisibility(visible);
        } catch (e) {
        }

        var userAgent = "" + navigator.userAgent;
        if (null != this.caller && userAgent.indexOf("MSIE 7") == -1 && userAgent.indexOf("Firefox") == -1) {
            try {
                var doc = this.caller.document;
                var objs = doc.getElementsByTagName("select");
                if (objs) {
                    if ("undefined" == typeof(objs.length)) {
//                        objs.style.visibility = visible ? "visible" : "hidden";
                        objs.style.visibility = visible ? "" : "hidden";
                    }
                    else {
                        for (var i = 0; i < objs.length; i++) {
                            var obj = objs[i];
//                            obj.style.visibility = visible ? "visible" : "hidden";
                            obj.style.visibility = visible ? "" : "hidden";
                        }
                    }
                }

                // In case Application is Bizflow Form, hide Bizflow Form because Bizflow Form breaks a modal dialog
                // bug18492: Adding comment in Basic WIH with BizFlow form running in background
                if ("WIH_action" == this.caller.name) {
                    var parent = this.caller.parent;
                    if (parent && parent.frames) {
                        var appFrame = parent.WIH_information;
                        if (appFrame && appFrame.frames) {
                            var frame = appFrame.frames["bffBody"];
                            var appDoc = frame.document;
                            if (frame.contentWindow) {
                                appDoc = frame.contentWindow.document;
                            }
                            var BFFCtl = appDoc.getElementsByName("BFFCtl");
                            if (BFFCtl && BFFCtl.length > 0) {
                                for (var i = 0; i < BFFCtl.length; i++) {
//                                    BFFCtl[i].style.visibility = visible ? "visible" : "hidden";
                                    BFFCtl[i].style.visibility = visible ? "" : "hidden";
                                }
                            }
                        }
                    }
                }
            }
            catch (e) {
            }
        }
    };

    this.initialize();
}

/**
 * Parse a features string
 * var sFeatures = "scrollbars= yes ,status = no,toolbar=no,resizable=no,left=10,top=20,width=600,height=400";
 */
function parseFeatures(sFeatures) {
    var features = new Object();
    var string = "";

    if ("undefined" != sFeatures && null != sFeatures && sFeatures != "") {
        var s1 = sFeatures.split(",");

        if (null != s1) {
            for (var i = 0; i < s1.length; i++) {
                var f1 = s1[i].split("=");
                var name = f1[0];
                var value = "";
                if (f1.length == 2) {
                    value = f1[1];
                }

                name = name.replace(/ /g, "");
                value = value.replace(/ /g, "");

                if (name.length > 0) {
                    if (string.length > 0) {
                        string += ",";
                    }

                    string += name + "=" + value;

                    var code = "features." + name + "='" + value + "'";
                    eval(code);
                }
            }
        }
    }

    features.string = string;

    return features;
}

function reviseFeatures(sFeatures, name, value) {
    if (sFeatures.length > 0) {
        sFeatures = sFeatures.replace(eval("/" + name + "/g"), "_" + name);
    }

    if ("undefined" != typeof(value)) {
        if (sFeatures.length > 0) {
            sFeatures += ",";
        }
        sFeatures += name + "=" + value;
    }

    return sFeatures;
}

function _getInt(value) {
    var _int = 0;
    try {
        _int = parseInt(value);
    }
    catch (e) {
        _int = 0;
    }

    return _int;
}

function disableContextMenu(element) {
    element.oncontextmenu = function () {
        return false;
    }
}

function getModalScreenOffset() {
    var screenOffset = new Object();

    screenOffset.width = 0;
    screenOffset.height = 0;

    return screenOffset;
}

var __modalPopupMaxWindows = new Array();
var __singleModalPopupWindows = null;

function initializeModalPopups() {
    if (null == __singleModalPopupWindows) {
        var blankUrl = null;
	    if(document.forms["blankform"])
	    {
	        blankUrl = document.forms["blankform"].action;
	    }
        // in case of plumtree, blankUrl is undefined
        // Bug 18615 About new windows opening in modal
        if (null == blankUrl || typeof blankUrl == "undefined") {
            blankUrl = __basePath + "/includes/modalpopup/blank.jsp";
        }
        for (var i = 0; i < maxModalCount; i++) {
            __modalPopupMaxWindows[i] = new ModalPopup(this, "modalPopupMax" + i);
            __modalPopupMaxWindows[i].setBlankPageURL(blankUrl);
        }
        __singleModalPopupWindows = __modalPopupMaxWindows[maxModalIndex];
    }
}

function adjustModalWindowTitle(title) {
    var userLang = getUserLang();
    if ("ko" == userLang) {
        title = "<B>" + title + "</B>";
    }

    return title;
}

// this function is called by ModalPopup.close()
function _decreaseModalIndex() {
    if (__currentModalIndex >= 0) {
        __currentModalIndex--;
    }
}

function getCurrentModalIndex() {
    return  __currentModalIndex;
}

function getCurrentModalPopupFrame() {
    var modalFrame = document.getElementById("modalPopupMax" + __currentModalIndex + "Frame");
    return modalFrame;
}

function getModalPopupTargetFrame(frameName) {
    var frame = null;
    var modalFrame = getCurrentModalPopupFrame();
    if (modalFrame) {
        frame = modalFrame.contentWindow.frames[frameName];
    }

    return frame;
}

function setModalPopupSubTitle(title) {
    var subTitle = document.getElementById("modalPopupMax" + __currentModalIndex + "SubTitle");
    subTitle.innerHTML = title;
}

function setModalPopupToolbar(html) {
    var toolbar = document.getElementById("toolbarHolder" + __currentModalIndex);
    toolbar.innerHTML = html;
}

function openModalPopupWindow(caller, url, title, width, height, sFeatures, lastFocusedEl) {
    initializeModalPopups();
    if (__currentModalIndex < maxModalIndex) {
        if (typeof sFeatures == "undefined" || sFeatures.length == 0) {
            sFeatures = "dummy=1";
        }

//        if ("NS" == _browser) {
//            width += 10;
//        }
        var screenOffset = getModalScreenOffset();
        // The width must be sum of width of "table.popup_mid td.left" and "table.popup_mid td.right"
//        sFeatures += ",paddingWidth=" + -screenOffset.width;
        // in case caller is null, use the latest modal window to open new modal
        if (null != caller) {
            __currentModalIndex++;
            __modalPopupMaxWindows[__currentModalIndex].setCaller(caller);
        } else {
            if (__currentModalIndex < 0) {
                __currentModalIndex = 0;
            }
            __modalPopupMaxWindows[__currentModalIndex].writeClear();
        }

        var closeButtonCell = document.getElementById("modalPopupMaxCell" + __currentModalIndex);
        closeButtonCell.style.display = "";

        setModalPopupSubTitle("");
        setModalPopupToolbar("");
        __modalPopupMaxWindows[__currentModalIndex].open(url, adjustModalWindowTitle(title), width, height, sFeatures);
        __modalPopupMaxWindows[__currentModalIndex].setLastFocusedElement(lastFocusedEl);

        return __modalPopupMaxWindows[__currentModalIndex];
    }
    else {
        _decreaseModalIndex();
        alert("There is no available modal popup window object.\nPlease increase maximum count of modal popup window.");
        return null;
    }
}

function closeModalPopupWindow(where, index) {
    initializeModalPopups();

    if ("undefined" == typeof(index) || null == index) {
        index = __currentModalIndex;
    }

    if (index >= 0) {
        try {
            if(__modalPopupMaxWindows[index].lastFocusedElement) __modalPopupMaxWindows[index].lastFocusedElement.focus();
        } catch(e) {}
        return __modalPopupMaxWindows[index].close(true, where);
    } else {
        return false;
    }
}

function resizeModalPopupWindow(width, height, sFeatures) {
    var _modal = getCurrentModalPopupWindow();

    if (null != _modal && _modal.closed == false) {
        _modal.resizeTo(width, height, sFeatures);
    }
}

function hideModalPopupWindow(index) {
    if ("undefined" == typeof(index)) {
        index = __currentModalIndex;
    }
    __modalPopupMaxWindows[index].hide(false);
}

function showModalPopupWindow(index) {
    if ("undefined" == typeof(index)) {
        index = __currentModalIndex;
    }
    __modalPopupMaxWindows[index].show();
}

function getModalPopupCaller() {
    if (__currentModalIndex >= 0) {
        return __modalPopupMaxWindows[__currentModalIndex].getCaller();
    }
    else {
        return null;
    }
}

function getCurrentModalPopupWindow() {
    initializeModalPopups();

    if (__currentModalIndex >= 0) {
        var _modal = __modalPopupMaxWindows[__currentModalIndex];
        if (_modal.closed == false) {
            return _modal;
        }
    }

    var singleWin = getSingleModalPopupWindow();
    if (null != singleWin && singleWin.closed == false) {
        return singleWin;
    }

    return null;
}

/* Single Modal Popup Window ****************************/
function openSingleModalPopupWindow(caller, url, title, width, height, sFeatures) {
    initializeModalPopups();

    var screenOffset = getModalScreenOffset();
    // The width must be sum of width of "table.popup_mid td.left" and "table.popup_mid td.right"
    sFeatures += ",paddingWidth=" + -screenOffset.width;
    // in case caller is null, use the latest modal window to open new modal

    __singleModalPopupWindows.setCaller(caller);
    __singleModalPopupWindows.open(url, adjustModalWindowTitle(title), width, height, sFeatures);
    return __singleModalPopupWindows;
}

function closeSingleModalPopupWindow(where) {
    initializeModalPopups();

    __singleModalPopupWindows.close(false, where);
}

function getSingleModalPopupCaller() {
    return __singleModalPopupWindows.getCaller();
}

function getSingleModalPopupWindow() {
    initializeModalPopups();
    return __singleModalPopupWindows;
}

/*
 DO NOT delete this function.
 JS files that call this function might not be updated along this jsp. So they still call this typo function and get a script error.
 */
function isSingleMdoalPopupWindowActive() {
    return isSingleModalPopupWindowActive();
}

function isSingleModalPopupWindowActive() {
    initializeModalPopups();
    return !__singleModalPopupWindows.closed;
}

/* title bar */
function setTitle(id, title) {
    var span = document.getElementById(id + "Title");
    if (null != span) {
//            div.style.width = div.parentNode.clientWidth;
        span.innerHTML = title;
        //div.parentNode.style.width = div.clientWidth;
	    var win = document.getElementById(id);
	    if(null != win && win.offsetWidth - 100 < span.offsetWidth)
	    {
	        span.style.width = (win.offsetWidth - 100) + "px";
	    }
    }
}

function getTitle(id) {
    var div = document.getElementById(id + "Title");
    var title = "" + div.innerHTML;
    return title;
}
function _callFunction(func, arg)
{
    if(typeof func == 'function')
    {
        return func.apply(null, arg);
    }
    else if(typeof func == 'string')
    {
        var fn = window[func];
        if(typeof fn == 'function')
        {
            return fn.apply(null, arg);
        }
    }
    else if(typeof func == 'object')
    {
        try{
            if(typeof func.callback == 'function')
            {
                return _callFunction(func.callback, func.params);
            }
        }catch(e)
        {
            //
        }
    }
    return undefined;
}

function _close() {
    var _closeWin = true;
    var _modal = getCurrentModalPopupWindow();
    var _handler = null;
    if (_modal && "undefined" != typeof(_modal.getCloseEventHandler)) {
        _handler = _modal.getCloseEventHandler();
    }
    try {
        if (typeof(_handler) != "undefined" && null != _handler) {
            var _rc = _callFunction(_handler);
            if (typeof(_rc) == 'boolean') {
                _closeWin = !_rc;
                _modal.setCloseEventHandler(null, null);// cs-26060
            } else {
                _closeWin = false;
            }
        }
    } catch (e) {
        _closeWin = true;
    }

    if (_closeWin) {
        var singleWindow = isSingleModalPopupWindowActive();
		var closeAfter = true;
		if (singleWindow) {
            closeAfter = closeSingleModalPopupWindow("toolbar");
        } else {
            closeAfter = closeModalPopupWindow("toolbar");
        }
		if(!closeAfter) { // Using "Kendo Modal Window UI"
			var openDialog = window.top.$("#topModalWindow").data("kendoWindow");
			openDialog.close();
		}
    }
}


function modalWindowOnResize() {
    try {
        var _modal = typeof(getCurrentModalPopupWindow) == 'undefined' ? null : getCurrentModalPopupWindow();
        if (null != _modal) {
            _modal.onresize();
        }
    } catch (e) {
    }
    return true;
}

function hideXButton() {
    var closeButtonCell = document.getElementById("modalPopupMaxCell" + __currentModalIndex);
    closeButtonCell.style.display = "none";
}

function displayXButton() {
    var closeButtonCell = document.getElementById("modalPopupMaxCell" + __currentModalIndex);
    closeButtonCell.style.display = "";
}

function setModalPopupCloseHandler(eventHandler, url, basicWihReadOnly) {
    var _modal = getCurrentModalPopupWindow();
    if (_modal) {
        if ("undefined" != typeof(url)) {
            var idx = url.indexOf("?");
            if (-1 != idx) {
                url = url.substring(0, idx);
            }

            var modal = null;

            for (var i = 0; i < __modalPopupMaxWindows.length; i++) {
                modal = __modalPopupMaxWindows[i];
                if (url == modal.getCloseEventUrl()) {
                    _modal = modal
                    break;
                }
            }
        }

        _modal.setCloseEventHandler(eventHandler, url, basicWihReadOnly);
    }
}
