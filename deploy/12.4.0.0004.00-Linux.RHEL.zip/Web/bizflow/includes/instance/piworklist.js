var passwordValue = "false";
var actionType;
var item_arr_viewapplication = new Array(2);
var item_arr_complete = new Array(2);
var item_arr_monitor;
var item_arr_detail = new Array(3);
var item_arr_actinfo = new Array(3);
var item_arr_repair = new Array(6);

var ProcessID = "";
var WorkitemSequence = "";
var UserID = "";
var type = "";
var selfuserid = "";

var wndPiWorkInfo;
function openWorkInfo(seq,id, auth_view, passwordflag, serverid)
{
	if(auth_view == 1)
	{
		if("F" == passwordflag)
		{
			wndPiWorkInfo = ShowWindow(contextPath +  "/instance/workinfo.jsp?PROCESSID=" + id + "&SEQUENCE=" + seq + "&TYPE=instance" + "&serverid=" + serverid, "piworkinfo", titleName, 500, 400, "yes");
		}
		else if("T" == passwordflag)
		{
			passwordValue = "false";
			actionType = "detail";

			item_arr_detail[0] = id;
			item_arr_detail[1] = seq;
			item_arr_detail[2] = serverid;

			var sUrl = contextPath +  "/common/passwordframe.jsp";
			wndPassword = ShowWindow(sUrl, "wndPassword", CHK_PASSWORD, 300, 140, "no");
		}
	}
	else
	{
		alert(MSG_CMM_VIEW_WORKITEM_INFO_AUHORITY);
		return;
	}
}

var wndPiActInfo;
function openPiActivityInfo(seq,id, auth_view, spasswordflag, serverid) 
{   
	if(auth_view == 1)
	{
		if("F" == spasswordflag || "null" == spasswordflag)
		{
			var sUrl = contextPath + "/instance/activityinfo.jsp?PROCESSID=" + id + "&ACTIVITYSEQUENCE=" + seq + "&TYPE=instance" + "&serverid=" + serverid;
			openPopup(sUrl, "", "piactivityinfo", 600, 540, true, false, true, false);
        }
		else if("T" == spasswordflag)
		{
			passwordValue = "false";
			actionType = "actinfo";

			item_arr_actinfo[0] = id;
			item_arr_actinfo[1] = seq;
			item_arr_actinfo[2] = serverid;
		
			var sUrl = contextPath + "/common/passwordframe.jsp";
			wndPassword = ShowWindow(sUrl, "wndPassword", CHK_PASSWORD, 300, 140, "no");
		}
	}
	else
	{
		alert(msg4);
		return;
	}
}


var wndPiAudit;
function openAudit(processid, authority)
{   
    if("F" == checkPassword)
    {
        var sUrl = contextPath + "/common/audit.jsp?pid=" + processid + "&type=instance" + "&passwordflag=F";
        sUrl += "&pnm=" + escapeUnicode(processName);
        var iWidth = window.screen.availWidth-100;
        var iHeight = window.screen.availHeight-200;
        wndPiAudit = openMonitorPopup(sUrl, "", "Monitor", iWidth, iHeight, true, true, true, true);
    }
    else if("T" == checkPassword)
    {
        passwordValue = "false";
        actionType = "monitor";
        item_arr = new Array();
        item_arr[0] = new Array();
        item_arr[0][0] = processid;
		item_arr[0][3] = processName;
        item_arr_monitor = authority;

        var sUrl = contextPath + "/common/passwordframe.jsp";
        wndPassword = ShowWindow(sUrl, "wndPassword", CHK_PASSWORD, 300, 140, "no");
    }
}

var participantid;	
var wndPiOrg;		
function openOrg(userid)
{
    var checkValue = "F";
	selfuserid = userid;
			
	if (item_arr.length == 0)
	{
		alert(MSG_CMM_SELECT_ITEM);
		return;
	}

	for (i = 0; i < item_arr.length; i++)
	{
		participantid = item_arr[i][6];
		if("T" == item_arr[i][5])
		{
			checkValue = "T";
			break;
		}
	}

	if("T" == checkValue)
	{
		passwordValue="false";
		actionType = "forward"; 

		var sUrl = contextPath + "/common/passwordframe.jsp";
		wndPassword = ShowWindow(sUrl, "wndPassword", CHK_PASSWORD, 300, 140, "no");
	}
	else if("F" == checkValue)
	{
        var pid = "";
        var actseq = "";
        var wseq = "";

		for(i = 0; i < item_arr.length; i++)
		{
			if(item_arr[i][4] == "C")
			{
				alert(MSG_NOT_STATE_FORWARD); 
				return;
			}
			else if((item_arr[i][4] == "L") || (item_arr[i][4] == "J"))
			{
				alert(MSG_NOT_FORWARD); 
				return;
			}

            if(pid != "") pid += ";";
            pid += item_arr[i][0];

            if(actseq != "") actseq += ";";
            actseq += item_arr[i][1];

            if(wseq != "") wseq += ";";
            wseq += item_arr[i][2];
		}

//		wndPiOrg = ShowWindow(contextPath + "/portal/common/selectuserbody.jsp?mode=instance&rf=y&chkabsent=y&participantid=" + participantid, "PiOptionChild", ORGANIZATION, 502, 510, "yes");
        var sUrl = contextPath + "/work/forwardworkitem.jsp?pid=" + pid + "&aseq=" + actseq + "&wseq=" + wseq;
        wndPiOrg = ShowWindow(sUrl, "OpenOrg",  ORGANIZATION, 530, 500, "yes");
	}
}

var selID="";
var selName = "";
var selType="";

function onorgselchange(selectedID, selectedName, selectedType, isAbsent)
{
	selID = selectedID;
	selName = selectedName;
//	selType = selectedType;

//	if("" != selectedID && "U" ==selectedType)
//	{
		forward();
//	}
//	else if("" != selectedID &&  ( "D" == selectedType  || "G" == selectedType) )
//	{
//		forward();
//	}
}
					
var item_arr = new Array();
function sel_item(processid, activitysequence, workitemsequence, processname, workstate, passwordflag,
				  participantid, priority, responseId, activityinfo, serverid, src)
{
	var i, j, k, inx;
	
	if (src.checked) 
	{
		inx = item_arr.length;
		
		item_arr[inx] = new Array(11);
		
		item_arr[inx][0] = processid;
		item_arr[inx][1] = activitysequence;
		item_arr[inx][2] = workitemsequence;
		item_arr[inx][3] = processname;
		item_arr[inx][4] = workstate;
		item_arr[inx][5] = passwordflag;
		item_arr[inx][6] = participantid;
		item_arr[inx][7] = priority;
		item_arr[inx][8] = responseId;
		item_arr[inx][9] = activityinfo;
		item_arr[inx][10] = serverid;
	}
	else
	{
		for (i=0; i < item_arr.length; i++)
		{
			if (item_arr[i][2]== workitemsequence)
			{
				for (j = i; j < item_arr.length-1; j++)
				{
					k = j + 1;
					item_arr[j][0] = item_arr[k][0];
					item_arr[j][1] = item_arr[k][1];
					item_arr[j][2] = item_arr[k][2];
					item_arr[j][3] = item_arr[k][3];
					item_arr[j][4] = item_arr[k][4];
					item_arr[j][5] = item_arr[k][5];
					item_arr[j][6] = item_arr[k][6];
					item_arr[j][7] = item_arr[k][7];
					item_arr[j][8] = item_arr[k][8];
					item_arr[j][9] = item_arr[k][9];
					item_arr[j][10] = item_arr[k][10];
				}
				//item_arr.pop();
				item_arr.length = item_arr.length-1;
				break;
			}
		}
	}
}
		
function forward()
{
	var i = 0;
	var PROCESSID = "";
	var ACTIVITYSEQUENCE = "";
	var WORKITEMSEQUENCE = "";
				
	type = "Forward";	
			
	document.frmPiworklist.hActionType.value = type;
	document.frmPiworklist.hUserID.value = selID;
	document.frmPiworklist.hUserName.value = selName;
	//document.frmPiworklist.hDeptName.value = DeptName;
	document.frmPiworklist.hCount.value = item_arr.length;
										
	for (i = 0; i < item_arr.length; i++)
	{
		PROCESSID = PROCESSID + item_arr[i][0] + ";";
		ACTIVITYSEQUENCE = ACTIVITYSEQUENCE + item_arr[i][1] + ";";
		WORKITEMSEQUENCE = WORKITEMSEQUENCE + item_arr[i][2] + ";"; 
	}
	document.frmPiworklist.hTagProcessID.value = PROCESSID;
	document.frmPiworklist.hTagATSequence.value = ACTIVITYSEQUENCE;
	document.frmPiworklist.hTagWISequence.value = WORKITEMSEQUENCE;
						
	document.frmPiworklist.submit();
}

function ReloadWorklist(processid, authority)
{
	var url = contextPath + "/instance/worklist.jsp?PROCESSID=" + processid + "&TYPE=instance" + "&authority=" + authority + "&openpage=INSTANCE";
	locationHref(parent.frameDown, url);
}

var wndExcel;
function openWorklistExcel(processid, sBrowser)
{
    var url =  contextPath + "/instance/worklistexcel.jsp?PROCESSID=" + processid + "&TYPE=instance";
    thisLocationHref(url);
}

var wndPrint;
function openWorklistPrint(processid)
{
	var sUrl = contextPath + "/instance/worklistprint.jsp?PROCESSID=" + processid + "&TYPE=instance";
	var iWidth = window.screen.availWidth-100;
	var iHeight = window.screen.availHeight-200;
	var iLeft = 50;
	var iTop = 50;
	var sFeatures = "status=yes,toolbar=yes,resizable=yes,left=" + iLeft + "," + "top=" + iTop + "," + "width=" + iWidth + "," + "height=" + iHeight;
	wndPrint = windowOpen(sUrl, "Print", sFeatures);
}

var wndPiViewApp;
function openViewApplication(serverid, pid, authority)
{
	if (item_arr.length > 1)
	{
		alert(MSG_CMM_ONLY_ONE_SELECT_ITEM);
		ReloadWorklist(pid, authority);
	}
	else if (item_arr.length == 0)
	{
		alert(MSG_CMM_SELECT_ITEM);
	}
	else 
	{
		if("F" == item_arr[0][5])
		{
			var iWidth = window.screen.availWidth-15;
			var iHeight = window.screen.availHeight-50;
			var processid = item_arr[0][0];
			var activityseq = item_arr[0][1];
			var wiseq = item_arr[0][2];
			
			//Modify by jspark on 2001/07/02
			//ReloadWorklist(processid, authority);
			
			getWIHInfoString();
			var sUrl = contextPath +  "/work/wih.jsp?sid=" + serverid + "&pid=" + processid + "&asq=" + activityseq + "&seq=" + wiseq + "&mode=" + "view" + "&authority=" + authority + "&open=y" + "&openpage=INSTANCE";
			if(isModalWIHMode())
            {
                iWidth = "100%";
                iHeight = "100%";
            }
            wndPiViewApp = openWIHPopup(sUrl, "", "ViewApplication", iWidth, iHeight, true, true, true, false);
		}
		else if("T" == item_arr[0][5])
		{
			passwordValue = "false";
			actionType = "viewapplication";

			item_arr_viewapplication[0] = serverid;
			item_arr_viewapplication[1] = authority;

			var sUrl = contextPath + "/common/passwordframe.jsp";
			wndPassword = ShowWindow(sUrl, "wndPassword", CHK_PASSWORD, 300, 140, "no");
		}
	}
}

function openViewApplication2(serverid, processid, activityseq, wiseq, checkPassword, authority)
{
    if("F" == checkPassword)
    {
        var iWidth = window.screen.availWidth-15;
        var iHeight = window.screen.availHeight-50;

        getWIHInfoString();
        var sUrl = contextPath + "/work/wih.jsp?sid=" + serverid + "&pid=" + processid + "&asq=" + activityseq + "&seq=" + wiseq + "&mode=" + "view" + "&authority=" + authority + "&open=y" + "&openpage=INSTANCE";
        wndPiViewApp = openWIHPopup(sUrl, "", "ViewApplication", iWidth, iHeight, true, true, true, false);
    }
    else if("T" == checkPassword)
    {
        passwordValue = "false";
        actionType = "viewapplication";

        item_arr = new Array();
        item_arr[0] = new Array();
        item_arr[0][0] = processid;
	    item_arr[0][1] = activityseq;
	    item_arr[0][2] = wiseq;

        item_arr_viewapplication[0] = serverid;
        item_arr_viewapplication[1] = authority;

        var sUrl = contextPath + "/common/passwordframe.jsp";
        var wndPassword = ShowWindow(sUrl, "wndPassword", CHK_PASSWORD, 300, 140, "no");
    }
}

var wndPiComplete;
function openComplete(serverid, pid, authority)
{
	if (item_arr.length > 1)
	{
		alert(MSG_CMM_ONLY_ONE_SELECT_ITEM);
		ReloadWorklist(pid, authority);
	}
	else if (item_arr.length == 0)
	{
		alert(MSG_CMM_SELECT_ITEM);
	}
	else 
	{
		if("F" == item_arr[0][5])
		{
			if (!checkWitemState(item_arr[0][4])) 
				return;
			
			var iWidth = window.screen.availWidth-15;
			var iHeight = window.screen.availHeight-50;
			var processid = item_arr[0][0];
			var activityseq = item_arr[0][1];
			var wiseq = item_arr[0][2];

			//Modify by jspark on 2001/07/02
			//ReloadWorklist(processid, authority);
			getWIHInfoString();
			var sUrl = contextPath + "/work/wih.jsp?sid=" + serverid + "&pid=" + processid + "&asq=" + activityseq + "&seq=" + wiseq + "&mode=" + "complete" + "&authority=" + authority + "&open=y" + "&openpage=INSTANCERELOAD";

            if(isModalWIHMode())
            {
                iWidth = "100%";
                iHeight = "100%";
            }
            wndPiComplete = openWIHPopup(sUrl, "", "Complete", iWidth, iHeight, true, true, true, false);
		}
		else if("T" == item_arr[0][5])
		{
			passwordValue = "false";
			actionType = "complete";

			item_arr_complete[0] = serverid;
			item_arr_complete[1] = authority;
			
			var sUrl = contextPath + "/common/passwordframe.jsp";
			wndPassword = ShowWindow(sUrl, "wndPassword", CHK_PASSWORD, 300, 140, "no");
		}
	}
}

function getCheckPasswordValue(value)
{
    passwordValue = value;
    //closeModal();
	moveAction();
}

function moveAction()
{
	if("true" == passwordValue)
	{
		if("viewapplication" == actionType)
		{
			var iWidth = window.screen.availWidth-15;
			var iHeight = window.screen.availHeight-50;
			var processid = item_arr[0][0];
			var activityseq = item_arr[0][1];
			var wiseq = item_arr[0][2];
			
			//Modify by jspark on 2001/07/02
			//ReloadWorklist(processid, item_arr_viewapplication[1]);
			
			getWIHInfoString();
			var sUrl = contextPath + "/work/wih.jsp?sid=" + item_arr_viewapplication[0] + "&pid=" + processid + "&asq=" + activityseq + "&seq=" + wiseq + "&mode=" + "view" + "&authority=" + item_arr_viewapplication[0] + "&open=y" + "&openpage=INSTANCE";
			if(isModalWIHMode())
            {
                iWidth = "100%";
                iHeight = "100%";
            }
            wndPiViewApp = openWIHPopup(sUrl, "", "ViewApplication", iWidth, iHeight, true, true, true, false);
		}
		else if("complete" == actionType)
		{
			if (!checkWitemState(item_arr[0][4]))
				return;
			
			var iWidth = window.screen.availWidth-15;
			var iHeight = window.screen.availHeight-50;
			var processid = item_arr[0][0];
			var activityseq = item_arr[0][1];
			var wiseq = item_arr[0][2];

			//Modify by jspark on 2001/07/02
			//ReloadWorklist(processid, item_arr_complete[1]);
			
			getWIHInfoString();
			var sUrl = contextPath + "/work/wih.jsp?sid=" + item_arr_complete[0] + "&pid=" + processid + "&asq=" + activityseq + "&seq=" + wiseq + "&mode=" + "complete" + "&authority=" + item_arr_complete[1] + "&open=y" + "&openpage=INSTANCERELOAD";

            if(isModalWIHMode())
            {
                iWidth = "100%";
                iHeight = "100%";
            }
            wndPiComplete = openWIHPopup(sUrl, "", "Complete", iWidth, iHeight, true, true, true, false);
		}
		else if("monitor" == actionType)
		{
			var processid = item_arr[0][0];
			var processname = item_arr[0][3];
			ReloadWorklist(processid, item_arr_monitor);
			
			var sUrl = contextPath + "/common/audit.jsp?pid=" + processid + "&type=instance" + "&passwordflag=T";
			sUrl += "&pnm=" + escapeUnicode(processname);
			var iWidth = window.screen.availWidth-100;
			var iHeight = window.screen.availHeight-200;
			var iLeft = 50;
			var iTop = 50;
			var sFeatures = "status=yes,resizable=yes,toolbar=yes,left=" + iLeft + "," + "top=" + iTop + "," + "width=" + iWidth + "," + "height=" + iHeight;

            if(isModalMonitorMode())
            {
                iWidth = "100%";
                iHeight = "100%";
            }
            
            wndPiAudit = openMonitorPopup(sUrl, "", "Monitor", iWidth, iHeight, true, true, true, true);
        }
		else if("forward" == actionType)
		{
            var pid = "";
            var actseq = "";
            var wseq = "";

			for(i = 0; i < item_arr.length; i++)
			{
				participantid = item_arr[i][6];
				if(item_arr[i][4] == "C")
				{
					alert(MSG_NOT_STATE_FORWARD);
					return;
				}
                               
                if (pid != "") pid += ";";
                pid += item_arr[i][0];

                if (actseq != "") actseq += ";";
                actseq += item_arr[i][1];

                if (wseq != "") wseq += ";";
                wseq += item_arr[i][2];
            }

//			wndPiOrg = ShowWindow(contextPath + "/portal/common/selectuserbody.jsp?divHeight=600&rf=y&chkabsent=y&mode=instance&participantid=" + participantid, "PiOptionChild", ORGANIZATION, 600, 500, "yes");
            var sUrl = contextPath + "/work/forwardworkitem.jsp?pid=" + pid + "&aseq=" + actseq + "&wseq=" + wseq;
            wndPiOrg = ShowWindow(sUrl, "OpenOrg",  ORGANIZATION, 530, 500, "yes");                
		}
		else if("detail" == actionType)
		{
			ndPiWorkInfo = ShowWindow(contextPath + "/instance/workinfo.jsp?PROCESSID=" + item_arr_detail[0] + "&SEQUENCE=" + item_arr_detail[1] + "&TYPE=instance" + "&serverid=" + item_arr_detail[2], "piworkinfo", titleName, 500, 400, "yes");
		}
		else if("actinfo" == actionType)
		{
			var sUrl = contextPath + "/instance/activityinfo.jsp?PROCESSID=" + item_arr_actinfo[0] + "&ACTIVITYSEQUENCE=" + item_arr_actinfo[1] + "&TYPE=instance" + "&serverid=" + item_arr_actinfo[2];
			openPopup(sUrl, "", "piactivityinfo", 600, 540, true, false, true, false);
        }
		else if("repair" == actionType)
		{
			if(nRestart != 1)
			{
				nRestart = 1;
				parent.frameHidden.location.href = 
											contextPath +  "/instance/repairworklist.jsp?PROCESSID="
										+ item_arr_repair[1] +"&ACTIVITYSEQUENCE=" + item_arr_repair[5] + "&SEQUENCE=" + item_arr_repair[2]
										+ "&authority=" + item_arr_repair[3] + "&passwordflag=" + item_arr_repair[4];			
			}
		}
		else if ("completeBatch" == actionType)
		{
		    completeBatch(batchPid, batchAuthority, false);
		}
		else if ("recallreject" == actionType)
		{
			recallReject();
		}
	}
	else
		return;
}
var ID_EWITEM_CREATE = "I";
var ID_EWITEM_START = "R";
var ID_EWITEM_SUSPEND = "S";
var ID_EWITEM_ABORT = "A";
var ID_EWITEM_TERMINATE = "T";
var ID_EWITEM_COMPLETE = "C";
var ID_EWITEM_FORWARD = "W";
var ID_EWITEM_DEAD = "D";
var ID_EWITEM_ERROR = "E";
var ID_EWITEM_PARTIAL = "P";
var ID_EWITEM_DELAY = "V";
var ID_EWITEM_SYNC = "Y";
function checkWitemState(state) {
	var canComplete = false;
	if (   state == ID_EWITEM_CREATE
		|| state == ID_EWITEM_PARTIAL
		|| state == ID_EWITEM_DELAY
		|| state == ID_EWITEM_SYNC )
		canComplete = true;
	else if (state == ID_EWITEM_COMPLETE)
        alert(MSG_WL_ID_EWITEM_COMPLETE);
    else if (state == ID_EWITEM_SUSPEND)
    	alert(MSG_WL_ID_EWITEM_SUSPEND);
	else if (state == ID_EWITEM_ABORT)
		alert(MSG_WL_ID_EWITEM_ABORT);
    else if (state == ID_EWITEM_FORWARD)
    	alert(MSG_WL_ID_EWITEM_FORWARD);
	else if (state == ID_EWITEM_DEAD)
		alert(MSG_WL_ID_EWITEM_DEAD);
    else if (state == ID_EWITEM_ERROR)
    	alert(MSG_WL_ID_EWITEM_ERROR);
    else if (state == ID_EWITEM_TERMINATE)
		alert(MSG_WL_ID_EWITEM_TERMINATE);
	else if (state == ID_EWITEM_START)
		alert(MSG_WL_ID_EWITEM_START);
	else
		alert(MSG_WL_ID_EWITEM_ANOTHER);
    return canComplete;
}
function getWIHInfoString()
{
	var strInfo = "";
	var oInfo = null;
	var strPasswordFlag = "";
	var oPasswordFlag = null;
	var count = 0;
	
	if(document.frmPiworklist)
	{
		count = document.frmPiworklist.hChkCount.value;
		
		for(var i=1 ; i<=count; i++)
		{
			eval("oInfo = document.frmPiworklist.wihinfo" + i);
			if(oInfo != null)
			{
				strInfo += oInfo.value;
				if (i != count)
				{
					strInfo += ";";
				}
			}	

			eval("oPasswordFlag = document.frmPiworklist.wihpasswordflag" + i);
			if(oPasswordFlag != null)
			{
				strPasswordFlag += oPasswordFlag.value;
				if (i != count)
				{
					strPasswordFlag += ";";
				}
			}	
		}	
	}

	document.frmPiworklist.hWIHInfo.value = strInfo;
	document.frmPiworklist.hWIHPasswordFlag.value = strPasswordFlag;
}

var batchPid = "";
var batchAuthority = "";
function completeBatch(processid, authority, passflag)
{
    if (item_arr.length == 0)
    {
        alert(MSG_CMM_SELECT_ITEM);
        return;
    }
    
    var i;
    var canCompleteBatch = true;
    for (i = 0; i != item_arr.length; ++i) {
    	if (!checkWitemState(item_arr[i][4])) {
    		canCompleteBatch = false;
    		break;
    	}
    }
    if (!canCompleteBatch)
    	return;

    var str = "";
    var checkpassword = false;
    
    for (i = 0; i < item_arr.length; i++)
    {
        // process id; activity seq id; workitem seq id; priority
        str += item_arr[i][0] + ";" + item_arr[i][1] + ";" + item_arr[i][2] + ";" + item_arr[i][7] + ";" + item_arr[i][8] + ";0;";
        
        if ("T" == item_arr[i][5])
            checkpassword = true;
    }

    if (checkpassword && passflag)
    {
		passwordValue = "false";
		actionType = "completeBatch";
		batchPid = processid;
		batchAuthority = authority;
		
		var sUrl = contextPath + "/common/passwordframe.jsp";
		wndPassword = ShowWindow(sUrl, "wndPassword", CHK_PASSWORD, 300, 140, "no");
    }
    else
    {
        var url = contextPath + "/instance/worklist.jsp?PROCESSID=" + processid + "&TYPE=instance" + "&authority=" + authority + "&openpage=INSTANCE&comstr=" + str;
        thisLocationHref(url);
    }
}

var nRestart = 0;
function Repair(seq, actSeq, id, sState, auth_repair, authority, spasswordflag)
{

	if(auth_repair == 1)
	{
		if("F" == spasswordflag)
		{	
	
			if(nRestart != 1)
			{
				nRestart = 1;

			   parent.frameHidden.location.href = contextPath + "/instance/repairworklist.jsp?PROCESSID="
																 + id +"&ACTIVITYSEQUENCE=" + actSeq  + "&SEQUENCE=" + seq
																 + "&authority=" + authority + "&passwordflag=" + spasswordflag;	
													
			}
		}
		else if("T" == spasswordflag)
		{
			passwordValue = "false";
			actionType = "repair";

			item_arr_repair[0] = sState;
			item_arr_repair[1] = id;
			item_arr_repair[2] = seq;
			item_arr_repair[3] = authority;
			item_arr_repair[4] = spasswordflag;
			item_arr_repair[5] = actSeq;
		
			var sUrl = contextPath + "/common/passwordframe.jsp";
			wndPassword = ShowWindow(sUrl, "wndPassword", CHK_PASSWORD, 300, 140, "no"); 
		}
	}
	else
	{
		alert(MSG_CMM_NOT_RESTART_AUTHORITY);
		return;
	}
}
//----------------------------------------------------------------------------------------------------------------------
function recallReject()
{
	var stateStr = item_arr[0][4];
	
	if (stateStr == 'C')
	{
		recall();
	}
	else if (stateStr == 'I' || stateStr == 'V' || stateStr == 'P')
	{
		reject();
	}
	else
	{
		alert(msgErrorCannotRejectWorkitem);
	}
}

function openRecallReject()
{
	if (item_arr.length > 1)
	{
		alert(MSG_CMM_ONLY_ONE_SELECT_ITEM);
	}
	else if (item_arr.length == 0)
	{
		alert(MSG_CMM_SELECT_ITEM);
	}
	else
	{		
		if("F" == item_arr[0][5])
		{
			recallReject();
		}
		else if("T" == item_arr[0][5])
		{
			passwordValue = "false";
			actionType = "recallreject";
			
			var sUrl = contextPath + "/common/passwordframe.jsp";
			wndPassword = ShowWindow(sUrl, "wndPassword", CHK_PASSWORD, 300, 140, "no");
		}
	}
}
function reject()
{
	var rsString ="rsCallBackSubmitReject";
	var ServerID, ProcessID, ActivityID, WorkItemSeq;
	var CommentCheck = "F";
	var ActivityInfo = 0;
	var serverURL =  contextPath + "/_scriptlibrary/submitreject.jsp";

	if (parseInt(eval(item_arr.length)) == 0)
		alert(msgSelectItem);
	else if (parseInt(item_arr.length) == 1)
	{
		ServerID = item_arr[0][10];
		ProcessID = item_arr[0][0];
		ActivityID = item_arr[0][1];
		WorkItemSeq = item_arr[0][2];
		ActivityInfo =  item_arr[0][9];

		if ((0x02 == (ActivityInfo & 0x02)) && (0x04 == (ActivityInfo & 0x04)))
		{
			CommentCheck = "T";
		}

		RSExecute(rsString, serverURL, "reject", ServerID, ProcessID, ActivityID, WorkItemSeq, CommentCheck);
	}
	else
		alert(msgOnlyOneItem);
}

function rsCallBackSubmitReject(ret)
{
	RSClearContext();
	getreturnSubmitRejectVal(ret.split(";"));
}

function getreturnSubmitRejectVal(arr)
{
	if (arr[0] != "0")
	{
		var errorNumber = arr[0];
		var errorDescription;

		if (errorNumber == 'MSG')
		{
			if (arr[1] == 'MSG_WIH_REQUIRE_COMMENT_RESPONSE')
				errorDescription = MSG_WIH_REQUIRE_COMMENT_RESPONSE;
			else
				errorDescription = arr[1];
			alert(errorDescription);
		}
		else
		{
			if (errorNumber == '4080')
				errorDescription = msgErrorCannotRejectWorkitem;
			else if (errorNumber == '4065')
				errorDescription = msgErrorCannotUseRejectAndRecall;
			else if (errorNumber == '4066')
				errorDescription = msgErrorNoTrackingInformationToRejectAndRecall;
			else if (errorNumber == '4085')
			{
				errorDescription = msgErrorNoPropertyToReject;
			}
			else
				errorDescription = msgRejectFailed;
			alert("[" + arr[0] + "] " + errorDescription);
		}
	}
	else
	{
        // set this.location.href with current url
        //bug18524: Clicking Recall/reject button occurs "4071 error", but some processes are successfully recalled!
        //Bug 18657: WebSphere Portal) Page not found error after recall/reject from instance details
        if(typeof(reloadThisPage) != "undefined")
        {
            reloadThisPage();
        }else
        {
            this.location.href = this.location.href;
        }
        //location.reload(true);
	}
}
function recall()
{
	var rsString ="rsCallBackSubmitRecall";
	var ServerID, ProcessID, ActivityID, WorkItemSeq;
	var serverURL =  contextPath + "/_scriptlibrary/submitrecall.jsp";

	if (parseInt(eval(item_arr.length)) == 0)
		alert(msgSelectItem);
	else if (parseInt(item_arr.length) == 1)
	{
		ServerID = item_arr[0][10];
		ProcessID = item_arr[0][0];
		ActivityID = item_arr[0][1];
		WorkItemSeq = item_arr[0][2];

		RSExecute(rsString, serverURL, "recall", ServerID, ProcessID, ActivityID, WorkItemSeq);
	}
	else
		alert(msgOnlyOneItem);
}
function rsCallBackSubmitRecall(ret)
{
	RSClearContext();
	getreturnSubmitRecallVal(ret.split(";"));
}
function getreturnSubmitRecallVal(arr)
{
	if (arr[0] != "0")
	{
		var errorNumber = arr[0];
		var errorDescription;
		if (errorNumber == '4065')
			errorDescription = msgErrorCannotUseRejectAndRecall;
		else if (errorNumber == '4066')
			errorDescription = msgErrorNoTrackingInformationToRejectAndRecall;
		else if (errorNumber == '4070')
			errorDescription = msgErrorCannotRecallWorkitem;
		else if (errorNumber == '4071')
			errorDescription = msgErrorCannotRecallUncompletedWorkitem;
		else
			errorDescription = msgErrorCannotRecallWorkitem;
		alert("[" + arr[0] + "] " + errorDescription);
	}
	else
	{
        // set this.location.href with current url
        //bug18524: Clicking Recall/reject button occurs "4071 error", but some processes are successfully recalled!
        //Bug 18657: WebSphere Portal) Page not found error after recall/reject from instance details
        if(typeof(reloadThisPage) != "undefined")
        {
            reloadThisPage();
        }else
        {
            this.location.href = this.location.href;
        }
        //location.reload(true);
	}
}

function openForward(userid, processType) // bug28009
{
	if (item_arr.length == 0)
	{
		alert(MSG_CMM_SELECT_ITEM);
	} else {
		ServerID = item_arr[0][10];
		ProcessID = item_arr[0][0];
		ActivityID = item_arr[0][1];
		WorkItemSeq = item_arr[0][2];

		if (processType == "OE") {
			var sUrl = contextPath + "/solutions/tasktracker117/action/forwardworkitemtask.jsp?sid=" + ServerID + "&pid=" + ProcessID + "&actseq=" + ActivityID;
			executeHiddenCall(sUrl, this);
		}
		else if (processType == "QP") {
			var sUrl = contextPath + "/webdesign/openapp?method=openForwardFromBizcove&procid=" + ProcessID + "&actseq=" + ActivityID + "&workseq=" + WorkItemSeq;
			executeHiddenCall(sUrl, this);
		} else {
			openOrg(userid);
		}
	}
}
