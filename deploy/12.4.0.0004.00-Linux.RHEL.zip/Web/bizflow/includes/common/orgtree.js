var _selectedData;
var _memberDataTable;
var _memberDataSource;
var useAccessibility = false;

var __rootDisplayName = "";
var __rootType = null;
var __rootID = null;

OrgTree = Class.create();
OrgTree.prototype =
{
	initialize: function(containerID, showRoot, rootType, rootID, disableGroupType, preSelectedID, showMemberList, rootDisplayName, accessibility)
	{
        this._loaded = false;
        this.containerID = containerID;
		this.tree = new YAHOO.widget.TreeView(containerID);
		this.tree.setDynamicLoad(_loadNodeData, 1);

		this.rootType = rootType;
		this.rootID = rootID;
		this.preSelectedID = preSelectedID;
		this.disableGroupType = disableGroupType;
		this.showRoot = ("0000000000" == this.rootID)?false:showRoot;
		this.showMemberList = showMemberList;
		useAccessibility = accessibility;

        __rootDisplayName = rootDisplayName;
        __rootType = rootType;
        __rootID = rootID;

        if(this.rootType == 'H')
		{
			if(!this.showRoot && "0000000000" != this.rootID)
			{
				this.rootType = "G";
				this.showRoot = ("9999999996" != this.rootID);
			}
		}

		_sendCommand(this.containerID, this.showRoot, this.rootType,  this.rootID);

		if(this.preSelectedID && 10<this.preSelectedID.length)
		{
			this._loadInitData(this.preSelectedID);
		}
	},
	_loadInitData: function(orgIDs)
	{
		var url = contextPath + '/common/orgtree_action.jsp';
		url += "?command=initData&orgID=" + orgIDs;
		var loadInitDataCallback =	{success:this._initData,	failure:_failureHandler, timeout: 300000};
		YAHOO.util.Connect.asyncRequest('GET', _markUrlRewrite(url), loadInitDataCallback);
	},
	_initData: function(o)
	{
		eval("var jo = " + o.responseText);
		if(0 == jo.length) return;
		var container = _selectedData.getContainer();
		for(var i=0; i<jo.length; i++)
		{
			var oNew = document.createElement('a');
			oNew.classname = jo[i].TYPE;
			oNew.id = "_sv_" + jo[i].ID;
			oNew.title = LBL_CMM_DELETE;
			oNew.innerHTML = jo[i].NAME;

			if(1<_selectedData.nMaxSelection)
			{
				oNew.className = "delete";
				oNew.href = "javascript:_delete('"+jo[i].ID+"')";
				container.appendChild(oNew);
				_selectedData.add(jo[i]);
			}
			else
			{
				if(0 < _selectedData.data.length)
				{
					var oChild = container.firstChild;
					container.replaceChild(oNew, oChild);
					_selectedData.removeAll();
					_selectedData.add(jo[i]);
				}
				else
				{
					container.appendChild(oNew);
					_selectedData.add(jo[i]);
				}
			}
		}
	}
}
function _failureHandler(o)
{
	alert(o.statusText);
}
var _callback ={containerID:"", success:_drawNodes, failure:_failureHandler, timeout: 300000};

function _sendCommand(containerID, showRoot, orgType, orgID)
{
	_callback.containerID = containerID;
	var url = contextPath + '/common/orgtree_action.jsp';
	url += "?orgType=" + orgType + "&orgID=" + orgID + "&showRoot=" + showRoot + "&_t=" + (new Date().getTime());
	YAHOO.util.Connect.asyncRequest('GET', _markUrlRewrite(url), _callback);
}
function _loadNodeData(parentNode, fnLoadComplete)
{
	_callback.argument = parentNode;
	var orgType = parentNode.data.info.TYPE;
	orgType = ("H"==orgType) ? "G" : orgType;
	_sendCommand("", false, orgType, parentNode.data.info.ID);
	fnLoadComplete();
}

function _drawNodes(o)
{
    eval("var jo = " + o.responseText);
	var parentNode = null;
	var ot;
	var cID;
	if(typeof o.argument == 'undefined')
	{
		cID = this.containerID
		eval(" ot = _"+cID);
		parentNode = ot.tree.getRoot();

         if(!this._loaded)
	    {
            if ("undefined" != typeof(__rootDisplayName) && "" != __rootDisplayName)
            {
                var info = new Object();
                info.NAME = __rootDisplayName;
                info.ID = __rootID;
                info.TYPE = __rootType;

                var tmpNode = new YAHOO.widget.HTMLNode({html: __rootDisplayName, info: info}, parentNode, false, true);
                tmpNode.index = -1;
                ot.tree.regNode(tmpNode);
                _setLink(cID,tmpNode, true);
                ot.tree.draw();
                return;
            }
        }
    }
	else
	{
		cID = o.argument.tree.id;
        eval(" ot = _"+cID);
		parentNode = o.argument;		
	}

	var recordCount = parseInt(jo.HWRECORDSET.RECORDCOUNT);
	if (0 < recordCount)
	{
		var tmpNode;
		var recordSetName = jo.HWRECORDSET.RECORD;
		eval("var r = jo.HWRECORDSET.HWRECBODY." + recordSetName);
		if (1 == recordCount)
		{
			tmpNode = new YAHOO.widget.HTMLNode({html: r.NAME, info: r}, parentNode, false, true);
			_setLink(cID,tmpNode);
		}
		else
		{
			for(var i=0; i<recordCount; i++)
			{
				var nodeData = {html: r[i].NAME, info: r[i]};
				tmpNode = new YAHOO.widget.HTMLNode(nodeData, parentNode, false, true);
				_setLink(cID,tmpNode);
			}
		}
		ot.tree.draw();
	}
    else if(!this._loaded)
	{
        if ("undefined" != typeof(__rootDisplayName) && "" != __rootDisplayName)
        {
            var html =   "<div class=\"ygtvitem\">";
            html += "<div class=\"ygtvchildren\">";
            html += "<div class=\"ygtvitem\">";
            html += "<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">";
            html += "<tr><td class=\"ygtvlm\" nowrap>"
            html += "</td><td nowrap=\"nowrap\">"
            html += "<img alt='' className='tree' src='" + _getImgSrc(__rootType, true) + "'>&nbsp;" + __rootDisplayName;
            html += "</td></tr></table>";
            html += "<div class=\"ygtvchildren\" id=\"ygtvc1\" style=\"display:none;\"></div>";
            html += "</div>"
            html += "</div>";
            html += "</div>";

            ot.tree.getEl().innerHTML = html;
        }
	}

    this._loaded = true;
}
function _setLink(containerID, node, disabled)
{
	node.nowrap = true;
    if("undefined" == typeof(disabled) || !disabled)
    {
        if(0 < _selectedData.nMaxSelection && -1==this.disableGroupType.indexOf(node.data.info.TYPE))
        {
            node.html = "<img alt='' className='tree' src='" + _getImgSrc(node.data.info.TYPE, false) + "'>&nbsp;"
                      + "<a href='javascript:_s(\""+containerID+"\"," + node.index + ")'>" + node.html + "</a>";
        }
        else
        {
			if(useAccessibility) {
				node.html = "<img className='tree' src='" + _getImgSrc(node.data.info.TYPE, true) + "'>&nbsp;"
				 +"<a href='javascript:YAHOO.widget.TreeView.getNode(\"treeContainerUG\"," + node.index + ").toggle()' onmouseover='this.style.textDecoration=\"none\";this.style.cursor=\"pointer\"' >" + node.html + "</a>";
			} else {
				node.html = "<img className='tree' src='" + _getImgSrc(node.data.info.TYPE, true) + "'>&nbsp;"+ node.html;
			}
        }
    }else
    {
        node.html = "<img className='tree' src='" + _getImgSrc(node.data.info.TYPE, true) + "'>&nbsp;"
                +  node.html;
    }
}

function _setDummyNode(containerID, node, type)
{
	node.nowrap = true;
    node.html = "<img className='tree' src='" + _getImgSrc(type, true) + "'>&nbsp;" + node.html;
}

function _s(orgTreeVarName, idx)
{
	eval("var ot = _"+orgTreeVarName);
	var node = ot.tree.getNodeByIndex(idx);

	if('undefined' != typeof onClickUserGroup)
	{
		onClickUserGroup(node.data.info);
	}

	_setSelectedData(node.data.info);

	if(ot.showMemberList)
	{
		_loadMember(node.data);
	}
}
function _delete(ID)
{
	var container = _selectedData.getContainer();
	container.removeChild(document.getElementById("_sv_" + ID));
	_selectedData.remove(ID);
}
SelectedData = Class.create();
SelectedData.prototype =
{
	initialize: function(containerID, showSelectedInputBox, nMaxSelection, selectableType)
	{
		this.showSelectedInputBox = showSelectedInputBox;
		this.containerID = containerID;
		this.nMaxSelection = nMaxSelection;
		this.selectableType = selectableType;
		this.data = new Array();
	},
	getContainer: function()
	{
		if (this.showSelectedInputBox)
			return document.getElementById(this.containerID);
		else
			return null;
	},
	indexOf: function(ID)
	{
		for (var i=0; i< this.data.length; i++) {
			if(ID == this.data[i].ID)
			{
				return i;
			}
		}
		return -1;
	},
	add: function(info)
	{
		if(this.nMaxSelection <= this.data.length)
		{
			return;
		}
		if(-1 < this.indexOf(info.ID)) return;
		this.data[this.data.length] = info;
	},
	removeAll: function()
	{
		this.data = new Array();
	},
	remove: function(ID)
	{
		for (var i=0; i< this.data.length; i++) {
			if(ID == this.data[i].ID)
			{
				this.data.remove(i);
				return;
			}
		}
	},
	length: function()
	{
		return this.data.length;
	},
	getData: function()
	{
		return this.data;
	},
	toJSONString: function()
	{
		if(0 == this.data.length)
		{
			return "";
		}
		if(1 == this.nMaxSelection)
		{
			return this.data[0].toJSONString();
		}
		return this.data.toJSONString();
	}
}
function getSelectedDataString()
{
	return _selectedData.toJSONString();
}
//---- Members -----------------------------------------------
function _loadMember(data)
{
	if('undefined' == typeof data)
	{
		return;
	}

	var orgType = data.info.TYPE;
	var orgID = data.info.ID;

	if(!(orgType == "D" || orgType == "G"))
	{
		return;
	}

	formatUrl = function(elCell, oRecord, oColumn, sData) {
		var tooltip = "";
		var href = "";
		var className = "U";

        if('string' == typeof(oRecord.getData("EMAIL")))
        {
            tooltip = oRecord.getData("EMAIL");
        }

		if(disableAbsentMember && null != oRecord.getData("ABSENCESTARTTIME"))
		{
            if( _isAbsent(oRecord.getData("ABSENCESTARTTIME"), oRecord.getData("ABSENCEENDTIME")))
			{
                className = "ABS";//absent
                tooltip = TIP_CMM_USERS_ABSENT;
                if (typeof(oRecord.getData("ABSENCEMESSAGE")) == "string")
                    tooltip += " : " + oRecord.getData("ABSENCEMESSAGE");
                tooltip = _encodeQuote(tooltip);
            }
		}

        // bug20651 we allow absent users can also be selected.
        //if(className == "ABS")
		//{
		//	href = "";
		//}
		//else
		{
			if('object' == typeof(disableMembers) && disableMembers.hasContain(oRecord.getData("ID")))
			{
				className = "DIS";//disabled
			}
			else
			{
				href = "href='javascript:_m(\"" + oRecord.getId() + "\")'";
			}
		}

		var lbl = sData;
		if(showMemberRadioButton)
		{
            // bug20651
            //if(className == "ABS" || className == "DIS")
            if (className == "DIS")
            {
				lbl = "<INPUT id='_r"+ oRecord.getId() +"' TYPE='RADIO' NAME='USER' disabled>&nbsp;" + sData;
			}
			else
			{
				lbl = "<INPUT id='_r"+ oRecord.getId() +"' TYPE='RADIO' NAME='USER' onclick='_m(\"" + oRecord.getId() + "\")'>&nbsp;" + sData;
			}
		}
		elCell.innerHTML = "<a class='"+className+ "' title='"+ tooltip +"' "+ href +">" + lbl + "</a>";
	};

	var columnDefs = [{key:"NAME", minWidth:160, label:LBL_ORG_USERS, sortable:true, formatter:formatUrl}];
	if(!_memberDataSource)
	{
		var url = new String(_markUrlRewrite(contextPath + '/common/orgtreemember_action.jsp'));
		url += (-1<url.indexOf('?')) ? '&' : '?';
		_memberDataSource = new YAHOO.util.DataSource(url);
		_memberDataSource.responseType = YAHOO.util.DataSource.TYPE_JSON;
		_memberDataSource.connXhrMode = "queueRequests";
		_memberDataSource.responseSchema = {	resultsList: "HWRECORDSET.HWRECBODY.DATA",	fields: ["NAME"]};
	}
	_memberDataTable = new YAHOO.widget.DataTable("memberContainer", columnDefs,
			_memberDataSource, {initialRequest:"orgType=" + orgType + "&orgID=" + orgID + "&_t=" + (new Date()).getTime()});
}
function _m(idx)
{
	if(showMemberRadioButton)
	{
		document.getElementById('_r' + idx).checked = true;
	}
	var rs = _memberDataTable.getRecordSet();
	var record = rs.getRecord(idx);
	var dataInfo = record._oData; // _oData is private variable(yui 2.5.0)

	_setSelectedData(dataInfo);

	if('undefined' != typeof onClickMember)
	{
		onClickMember(dataInfo);
	}
}
function _setSelectedData(dataInfo)
{
	if(-1 == _selectedData.selectableType.indexOf(dataInfo.TYPE))
	{
		return;
	}

	var container = _selectedData.getContainer();
	if(null == container)
	{
		_selectedData.add(dataInfo);
	}
	else
	{
		var oNew = document.createElement('a');
		oNew.classname = dataInfo.TYPE;
		oNew.id = "_sv_" + dataInfo.ID;
		oNew.innerHTML = dataInfo.NAME;
		if(1<nMaxSelection)
		{
			if(nMaxSelection <= _selectedData.data.length)
			{
				alert(MSG_SELECTION_CANNOT_EXCEED.replace("%s", nMaxSelection));
				return;
			}
			if(-1 == _selectedData.indexOf(dataInfo.ID))
			{
				oNew.title = LBL_CMM_DELETE;
				oNew.className = "delete";
				oNew.href = "javascript:_delete('"+dataInfo.ID+"')";
				container.appendChild(oNew);
				_selectedData.add(dataInfo);
			}
		}
		else
		{
			if(0 < _selectedData.data.length)
			{
				var oChild = container.firstChild;
				container.replaceChild(oNew, oChild);
				_selectedData.removeAll();
				_selectedData.add(dataInfo);
			}
			else
			{
				container.appendChild(oNew);
				_selectedData.add(dataInfo);
			}
		}
	}
}
//-------------------
function _encodeQuote(text)
{
	s = new String(text);
	s = s.replace(/\\/g,"&#92;");
	s = s.replace(/\'/g,"&#39;");
	s = s.replace(/\"/g,"&#34;");
	return s;
}
function _getGMToffset()
{
	var tz, s;

	tz = (new Date()).getTimezoneOffset();
	s = (tz == 0) ? 0 : tz / 60;

	s1 = eval(s);
	if(0 != s1)
	{
		s1 = ((-1) * s1);
	}

	return (s1 < 0) ? s1 : "+" + s1;
}

var GMToffset = _getGMToffset();

function _isAbsent(start, end)
{
	sD = new Date(start);
	sD.setHours(sD.getHours() + GMToffset);
	eD = new Date(end);
	eD.setHours(eD.getHours() + GMToffset);
	today = (new Date()).getTime();
	return (today >= sD.getTime() && today <= eD.getTime());
}
if (! Array.prototype.remove) {
	Array.prototype.remove = function(dx) {
		if (isNaN(dx) || dx > this.length)
			return false;

		for (var i = 0, n = 0; i < this.length; i++)
			if (i != dx)
				this[n++] = this[i];

		this.length -= 1;
	};
}
if (! Array.prototype.hasContain) {
	Array.prototype.hasContain = function(object) {
		for (var i = 0; i < this.length; i++)
			if (this[i] == object)
				return true;
		return false;
	};
}
