create or replace
procedure sp_move_archive
(
		i_link_to_archive in varchar2,
        i_svrid in varchar2,
        i_procid in number
)
        is
--
-- 12.4.0.4
--

l_procdefid		number;
l_instfolderid	number;
l_archfolderid	number;
l_cnt			number;
l_taskid        number;

begin

	-- MSSQL:
	-- Syntax for %ARCHIVE_DATABASE_LINK%: <server_name_for_bizflow_archive_database>.<db_name>.<owner>
	-- An example: servername.bizflowarchive.dbo

	-- Oracle:
	-- Syntax for %ARCHIVE_DATABASE_LINK%: <conn_string_for_bizflow_archive_database>
	-- An example: procs@bizflowarchive

	select preprocdefid into l_procdefid from procs where procid = i_procid;
	execute immediate 'select count(1) from procdef@' || i_link_to_archive || ' where procdefid = :1' into l_cnt using l_procdefid;
	if(l_cnt = 0) then
		execute immediate '
		insert into procdef@' || i_link_to_archive || ' (
			svrid, 
			procdefid, 
			verctrltype, 
			isfinal, 
			envtype, 
			deadlinetype, 
			subproctype,
			passwdflag, 
			publicationstate,
			pkitype, 
			caltype, 
			dmsaveflag, 
			dmidtype, 
			fldrsvrid, 
			fldrid, 
			prjfldrid,
			orgprocdefid, 
			ver, 
			procauth, 
			instfldrid, 
			archivefldrid, 
			orgmdtmpltid, 
			name, 
			deadline, 
			creationdtime,
			creator, 
			creatorname, 
			creatordeptname, 
			usrgrphid, 
			calmemberid, 
			presvrid, 
			preprocdefid, 
			checkoutusr,
			modifydtime, 
			modifier, 
			modifiername, 
			dmsvrid, 
			publishdtime, 
			publisher, 
			publishername, 
			dmfldrid, 
			dscpt, 
			chkincmnt)
		select 	svrid, 
			procdefid, 
			verctrltype, 
			isfinal, 
			envtype, 
			deadlinetype, 
			subproctype,
			passwdflag, 
			publicationstate,
			pkitype, 
			caltype, 
			dmsaveflag, 
			dmidtype, 
			fldrsvrid, 
			fldrid, 
			prjfldrid,
			orgprocdefid, 
			ver, 
			procauth, 
			instfldrid, 
			archivefldrid, 
			orgmdtmpltid, 
			name, 
			deadline, 
			creationdtime,
			creator, 
			creatorname, 
			creatordeptname, 
			usrgrphid, 
			calmemberid, 
			presvrid, 
			preprocdefid, 
			checkoutusr,
			modifydtime, 
			modifier, 
			modifiername, 
			dmsvrid, 
			publishdtime, 
			publisher, 
			publishername, 
			dmfldrid, 
			dscpt, 
			chkincmnt
		from procdef where svrid = :1 and procdefid = :2' using i_svrid, l_procdefid;
	end if;

	execute immediate 'select count(1) from mdatadef@' || i_link_to_archive || ' where procdefid = :1' into l_cnt using l_procdefid;
	if l_cnt = 0 then
		execute immediate '
		insert into mdatadef@' || i_link_to_archive || ' (
			svrid,
			procdefid,
			mdatadefseq,
			objtype,
			objsubtype,
			valuetype,
			objseq,
			mdinfo,
			orgmdtmpltid,
			mditemseq,
			name,
			dscpt,
			value)
		select	svrid,
			procdefid,
			mdatadefseq,
			objtype,
			objsubtype,
			valuetype,
			objseq,
			mdinfo,
			orgmdtmpltid,
			mditemseq,
			name,
			dscpt,
			value
		from mdatadef where svrid = :1 and procdefid = :2' using i_svrid, l_procdefid;
	end if;

	execute immediate '
	insert into procs@' || i_link_to_archive || ' (
		svrid, 
		procid, 
		urgent, 
		deadlinetype, 
		subproctype, 
		passwdflag,
		state, 
		dmsaveflag, 
		dmidtype, 
		caltype, 
		internalid, 
		cmntcnt, 
		attachcnt,
		orgprocdefid, 
		revisionid, 
		instfldrid, 
		ver, 
		archivefldrid, 
		name, 
		creationdtime, 
		creator, 
		creatorname, 
		deadline, 
		presvrid, 
		preprocdefid,
		preprocdefname, 
		usrgrphid, 
		calmemberid, 
		customid, 
		cmpltdtime, 
		deadlinedtime, 
		returnsvrid, 
		parentsvrid, 
		parentprocid, 
		parentactseq,
		parentacttype, 
		checkoutusr, 
		modifydtime, 
		modifier, 
		modifiername, 
		lastcorrespondence,
		dmsvrid, 
		dmfldrid, 
		dscpt )
	select	svrid, 
		procid, 
		urgent, 
		deadlinetype, 
		subproctype, 
		passwdflag,
		state, 
		dmsaveflag, 
		dmidtype, 
		caltype, 
		internalid, 
		cmntcnt, 
		attachcnt,
		orgprocdefid, 
		revisionid, 
		instfldrid, 
		ver, 
		archivefldrid, 
		name, 
		creationdtime, 
		creator, 
		creatorname, 
		deadline, 
		presvrid, 
		preprocdefid,
		preprocdefname, 
		usrgrphid, 
		calmemberid, 
		customid, 
		cmpltdtime, 
		deadlinedtime, 
		returnsvrid, 
		parentsvrid, 
		parentprocid, 
		parentactseq,
		parentacttype, 
		checkoutusr, 
		modifydtime, 
		modifier, 
		modifiername, 
		lastcorrespondence, 
		dmsvrid, 
		dmfldrid, 
		dscpt 
	from procs where svrid = :1 and procid = :2' using i_svrid, i_procid;

	execute immediate '
	insert into act@' || i_link_to_archive || ' (
		svrid, 
		procid, 
		actseq, 
		type, 
		jointype, 
		casetype, 
		deadlinetype, 
		transtype, 
		caltype, 
		existinfofile, 
		existcmntrans, 
		isrepsign, 
		subproctype, 
		sendapp, 
		sendattach, 
		sendcmnt, 
		state, 
		prestate, 
		checkpostcond, 
		cmpltopt, 
		rbackopt, 
		eventtype, 
		actlooptype, 
		defsvrid, 
		defprocdefid, 
		name,
		priority, 
		actauth, 
		actinfo, 
		deadline, 
		respgrpseq, 
		respseq, 
		capacity, 
		cost, 
		providerid, 
		loopcnt, 
		cmpltcnt, 
		spcfromnode, 
		attaddcnt, 
		waitingtime,
		workingtime, 
		planstarttime, 
		plancmplttime, 
		subsvrid, 
		subprocdefid, 
		suborgprocdefid, 
		postcondseq, 
		mergecondseq, 
		splitcondseq, 
		dscpt, 
		resplist, 
		deadlinedtime,
		planstartdtime, 
		plancmpltdtime, 
		startdtime, 
		cmpltdtime )
	select	svrid, 
		procid, 
		actseq, 
		type, 
		jointype, 
		casetype, 
		deadlinetype, 
		transtype, 
		caltype, 
		existinfofile, 
		existcmntrans, 
		isrepsign, 
		subproctype, 
		sendapp, 
		sendattach, 
		sendcmnt, 
		state, 
		prestate, 
		checkpostcond, 
		cmpltopt, 
		rbackopt, 
		eventtype, 
		actlooptype, 
		defsvrid, 
		defprocdefid, 
		name,
		priority, 
		actauth, 
		actinfo, 
		deadline, 
		respgrpseq, 
		respseq, 
		capacity, 
		cost, 
		providerid, 
		loopcnt, 
		cmpltcnt, 
		spcfromnode, 
		attaddcnt, 
		waitingtime,
		workingtime, 
		planstarttime, 
		plancmplttime, 
		subsvrid, 
		subprocdefid, 
		suborgprocdefid, 
		postcondseq, 
		mergecondseq, 
		splitcondseq, 
		dscpt, 
		resplist, 
		deadlinedtime,
		planstartdtime, 
		plancmpltdtime, 
		startdtime, 
		cmpltdtime
	from act where svrid = :1 and procid = :2' using i_svrid, i_procid;

	execute immediate '
	insert into trans@' || i_link_to_archive || ' (
		svrid, 
		procid, 
		transseq, 
		state, 
		type, 
		iscmntrans, 
		fromnode, 
		tonode, 
		condseq, 
		actioncondseq, 
		loopcnt, 
		evalorder, 
		name )
	select	svrid, 
		procid, 
		transseq, 
		state, 
		type, 
		iscmntrans, 
		fromnode, 
		tonode, 
		condseq, 
		actioncondseq, 
		loopcnt, 
		evalorder, 
		name 
	from trans where svrid = :1 and procid = :2' using i_svrid, i_procid;
	
	execute immediate '
	insert into rlvntdata@' || i_link_to_archive || ' (
		svrid, 
		procid, 
		rlvntdataseq, 
		ispublic, 
		scope, 
		valuetype, 
		parentinouttype, 
		rlvntdataname, 
		dscpt, 
		dispvalue, 
		indexvalue, 
		value)
	select	svrid, 
		procid, 
		rlvntdataseq, 
		ispublic, 
		scope, 
		valuetype, 
		parentinouttype, 
		rlvntdataname, 
		dscpt, 
		dispvalue, 
		indexvalue, 
		value
	from rlvntdata where svrid = :1 and procid = :2 and (scope = ''I'' or (scope = ''D'' and rlvntdataname not like ''#%''))' using i_svrid, i_procid;

	execute immediate '
	insert into cond@' || i_link_to_archive || ' (
		svrid, 
		procid, 
		condseq, 
		type, 
		dscpt, 
		expr)
	select	svrid, 
		procid, 
		condseq, 
		type, 
		dscpt, 
		expr 
	from cond where svrid = :1 and procid = :2' using i_svrid, i_procid;

	execute immediate '
	insert into procapp@' || i_link_to_archive || ' (
		svrid, 
		procid, 
		procappseq, 
		type, 
		sendtype, 
		keepingflag, 
		viewtype, 
		dmsaveflag, 
		dmidtype, 
		appsvrid, 
		appid, 
		orgappid, 
		appver, 
		disporder, 
		name, 
		rlvntdataseq, 
		invokedmethod, 
		extname, 
		dmsvrid, 
		dmfldrid, 
		dmdockind, 
		dscpt)
	select 	
		svrid, 
		procid, 
		procappseq, 
		type, 
		sendtype, 
		keepingflag, 
		viewtype, 
		dmsaveflag, 
		dmidtype, 
		appsvrid, 
		appid, 
		orgappid, 
		appver, 
		disporder, 
		name, 
		rlvntdataseq, 
		invokedmethod, 
		extname, 
		dmsvrid, 
		dmfldrid, 
		dmdockind, 
		dscpt
	from procapp where svrid = :1 and procid = :2' using i_svrid, i_procid;

	execute immediate '
	insert into actapp@' || i_link_to_archive || ' (
		svrid,
		procid,
		actseq,
		actappseq,
		updatable,
		initoption,
		viewtype,
		jobseq,
		procappseq,
		appsvrid,
		appid,
		appver,
		inrlvntdataseq,
		outrlvntdataseq,
		modifydtime)
	select	svrid,
		procid,
		actseq,
		actappseq,
		updatable,
		initoption,
		viewtype,
		jobseq,
		procappseq,
		appsvrid,
		appid,
		appver,
		inrlvntdataseq,
		outrlvntdataseq,
		modifydtime
	from actapp where svrid = :1 and procid = :2' using i_svrid, i_procid;

	execute immediate '
	insert into witemapp@' || i_link_to_archive || ' (
		svrid,
		procid,
		witemseq,
		witemappseq,
		state,
		pkitype,
		procappseq,
		actappseq,
		actseq,
		mapid,
		appver,
		appsvrid,
		appid,
		prtcp,
		prtcpname,
		modifydtime)
	select	svrid,
		procid,
		witemseq,
		witemappseq,
		state,
		pkitype,
		procappseq,
		actappseq,
		actseq,
		mapid,
		appver,
		appsvrid,
		appid,
		prtcp,
		prtcpname,
		modifydtime
	from witemapp where svrid = :1 and procid = :2' using i_svrid, i_procid;

	execute immediate '
	insert into param@' || i_link_to_archive || ' (
		svrid,
		procid,
		actseq,
		paramseq,
		inouttype,
		toscope,
		rlvntdataseq,
		disporder,
		todataname,
		const)
	select	svrid,
		procid,
		actseq,
		paramseq,
		inouttype,
		toscope,
		rlvntdataseq,
		disporder,
		todataname,
		const
	from param where svrid = :1 and procid = :2' using i_svrid, i_procid;
	
	execute immediate '
	insert into excpt@' || i_link_to_archive || ' (
		svrid,
		procid,
		excptseq,
		type,
		resptype,
		actseq,
		actappseq,
		incvalue,
		alertstarttime,
		alertduration,
		alertinterval,
		alertreceiver,
		email,
		exename,
		alertsubject,
		alertmsg)
	select	svrid,
		procid,
		excptseq,
		type,
		resptype,
		actseq,
		actappseq,
		incvalue,
		alertstarttime,
		alertduration,
		alertinterval,
		alertreceiver,
		email,
		exename,
		alertsubject,
		alertmsg
	from excpt where svrid = :1 and procid = :2' using i_svrid, i_procid;

	execute immediate '
	insert into cbdata@' || i_link_to_archive || ' (
		svrid,
		procid,
		actseq,
		providerid,
		mapid,
		callbackid)
	select	svrid,
		procid,
		actseq,
		providerid,
		mapid,
		callbackid
	from cbdata where svrid = :1 and procid = :2' using i_svrid, i_procid;

	execute immediate '
	insert into prtcp@' || i_link_to_archive || ' (
		svrid,
		procid,
		actseq,
		prtcpseq,
		kind,
		useflag,
		type,
		assignrule,
		existscriptfile,
		prtcpauth,
		prtcp,
		mapid,
		disporder,
		calmemberid,
		usrgrphid,
		deptname,
		jobtitlename,
		expr,
		prtcpname)
	select	svrid,
		procid,
		actseq,
		prtcpseq,
		kind,
		useflag,
		type,
		assignrule,
		existscriptfile,
		prtcpauth,
		prtcp,
		mapid,
		disporder,
		calmemberid,
		usrgrphid,
		deptname,
		jobtitlename,
		expr,
		prtcpname
	from prtcp where svrid = :1 and procid = :2' using i_svrid, i_procid;

	execute immediate '
	insert into witem@' || i_link_to_archive || ' (
		svrid,
		procid,
		witemseq,
		prtcptype,
		onasync,
		state,
		urgent,
		existinfofile,
		checkpostcond,
		actseq,
		priority,
		respgrpseq,
		respseq,
		deadline,
		prtcp,
		prtcpname,
		creationdtime,
		loopcnt,
		cmpltusr,
		calmemberid,
		startdtime,
		cmpltdtime,
		deadlinedtime,
		cmpltusrname,
		checkoutusr)
	select	svrid,
		procid,
		witemseq,
		prtcptype,
		onasync,
		state,
		urgent,
		existinfofile,
		checkpostcond,
		actseq,
		priority,
		respgrpseq,
		respseq,
		deadline,
		prtcp,
		prtcpname,
		creationdtime,
		loopcnt,
		cmpltusr,
		calmemberid,
		startdtime,
		cmpltdtime,
		deadlinedtime,
		cmpltusrname,
		checkoutusr
	from witem where svrid = :1 and procid = :2' using i_svrid, i_procid;

	execute immediate '
	insert into cmnt@' || i_link_to_archive || ' (
		svrid,
		procid,
		cmntseq,
		parentcmntseq,
		type,
		gettype,
		sendtype,
		witemseq,
		actseq,
		actname,
		creationdtime,
		creator,
		creatorname,
		modifydtime,
		jobtitleid,
		jobtitlename,
		deptid,
		deptname,
		contents)
	select	svrid,
		procid,
		cmntseq,
		parentcmntseq,
		type,
		gettype,
		sendtype,
		witemseq,
		actseq,
		actname,
		creationdtime,
		creator,
		creatorname,
		modifydtime,
		jobtitleid,
		jobtitlename,
		deptid,
		deptname,
		contents
	from cmnt where svrid = :1 and procid = :2' using i_svrid, i_procid;

	execute immediate '
	insert into attach@' || i_link_to_archive || ' (
		svrid,
		procid,
		attachseq,
		witemseq,
		correspondenceseq,
		type,
		sendtype,
		gettype,
		pkitype,
		dmdocrtype,
		actseq,
		mapid,
		creationdtime,
		creator,
		creatorname,
		attachsize,
		dispname,
		filename,
		actname,
		dmsvrid,
		dmdocid,
		dmdockind,
		dscpt,
		category,
		etcinfo)
	select	svrid,
		procid,
		attachseq,
		witemseq,
		correspondenceseq,
		type,
		sendtype,
		gettype,
		pkitype,
		dmdocrtype,
		actseq,
		mapid,
		creationdtime,
		creator,
		creatorname,
		attachsize,
		dispname,
		filename,
		actname,
		dmsvrid,
		dmdocid,
		dmdockind,
		dscpt,
		category,
		etcinfo
	from attach where svrid = :1 and procid = :2' using i_svrid, i_procid;

	execute immediate '
	insert into auditinfo@' || i_link_to_archive || ' (
		svrid,
		procid,
		execseq,
		event,
		objtype,
		objstate,
		execdtime,
		errno,
		actor,
		actorname,
		objname,
		objseq,
		witemappseq,
		respgrpseq,
		respseq,
		resp,
		appname,
		objdscpt)
	select	svrid,
		procid,
		execseq,
		event,
		objtype,
		objstate,
		execdtime,
		errno,
		actor,
		actorname,
		objname,
		objseq,
		witemappseq,
		respgrpseq,
		respseq,
		resp,
		appname,
		objdscpt
	from auditinfo where svrid = :1 and procid = :2' using i_svrid, i_procid;

	execute immediate '
	insert into grdauditinfo@' || i_link_to_archive || ' (
		svrid,
		grlvntdataid,
		execseq,
		procid,
		name,
		procname,
		modifydtime,
		modifier,
		modifiername,
		dispvalue,
		dscpt,
		value)
	select	svrid,
		grlvntdataid,
		execseq,
		procid,
		name,
		procname,
		modifydtime,
		modifier,
		modifiername,
		dispvalue,
		dscpt,
		value
	from grdauditinfo where svrid = :1 and procid = :2' using i_svrid, i_procid;

	execute immediate '
	insert into respgrp@' || i_link_to_archive || ' (
		svrid,
		procid,
		respgrpseq,
		name,
		dscpt)
	select	svrid,
		procid,
		respgrpseq,
		name,
		dscpt
	from respgrp where svrid = :1 and procid = :2' using i_svrid, i_procid;
	
	execute immediate '
	insert into resp@' || i_link_to_archive || ' (
		svrid,
		procid,
		respgrpseq,
		respseq,
		disporder,
		respinfo,
		name)
	select	svrid,
		procid,
		respgrpseq,
		respseq,
		disporder,
		respinfo,
		name
	from resp where svrid = :1 and procid = :2' using i_svrid, i_procid;

	execute immediate '
	insert into va_appmap@' || i_link_to_archive || ' (
		svrid,
		procid,
		appinstid,
		type,
		mapid,
		internalid,
		lastappverseq,
		dmver,
		dmsvrid,
		dmdocid,
		appsvrid,
		appid)
	select	svrid,
		procid,
		appinstid,
		type,
		mapid,
		internalid,
		lastappverseq,
		dmver,
		dmsvrid,
		dmdocid,
		appsvrid,
		appid
	from va_appmap where svrid = :1 and procid = :2' using i_svrid, i_procid;

	execute immediate '
	insert into va_appvermap@' || i_link_to_archive || ' (
		svrid,
		procid,
		appinstid,
		appverseq,
		actseq,
		actappseq,
		mapid,
		dmver,
		prtcp,
		dmsvrid,
		dmdocid,
		modifydtime,
		appsvrid,
		appid,
		dmverlabel,
		prtcpname)
	select	svrid,
		procid,
		appinstid,
		appverseq,
		actseq,
		actappseq,
		mapid,
		dmver,
		prtcp,
		dmsvrid,
		dmdocid,
		modifydtime,
		appsvrid,
		appid,
		dmverlabel,
		prtcpname
	from va_appvermap where svrid = :1 and procid = :2' using i_svrid, i_procid;

	execute immediate '
	insert into va_verlink@' || i_link_to_archive || ' (
		svrid,
		procid,
		appinstid,
		appverseqfrom,
		appverseqto)
	select	svrid,
		procid,
		appinstid,
		appverseqfrom,
		appverseqto
	from va_verlink where svrid = :1 and procid = :2' using i_svrid, i_procid;

	execute immediate '
	INSERT INTO Correspondence@' || i_link_to_archive || '(
		SvrID,ProcID,CorrespondenceSeq,ActSeq,TaskID,SubTaskID,CreationDTime,ParentTaskID,OrgProcID,OrgActSeq,Type,mediatype,state,creator,creatorname,readDTime,reader,readername,registerdtime,registrant,registrantname,FromUser,ToUser,CCUser,SentDate,Subject,BodyContent,TmpltID)
	SELECT SvrID,ProcID,CorrespondenceSeq,ActSeq,TaskID,SubTaskID,CreationDTime,ParentTaskID,OrgProcID,OrgActSeq,Type,mediatype,state,creator,creatorname,readDTime,reader,readername,registerdtime,registrant,registrantname,FromUser,ToUser,CCUser,SentDate,Subject,BodyContent,TmpltID
	  FROM Correspondence WHERE svrid = :1 AND procid = :2' using i_svrid, i_procid;

	execute immediate '
	INSERT INTO procslink@' || i_link_to_archive || '(
		svrid,procid,linkedprocid,creationdtime,creator,creatorname)
	SELECT svrid,procid,linkedprocid,creationdtime,creator,creatorname
	  FROM procslink WHERE svrid = :1 AND procid = :2' using i_svrid, i_procid;

	-- bug19726 OfficeEngine support for Archive database
	SELECT Count(1) INTO l_cnt FROM CompleteTasks WHERE ProcID = i_procid;
	If l_cnt > 0 Then
		SELECT TaskID INTO l_taskid FROM CompleteTasks WHERE ProcID = i_procid;

		execute immediate '
		INSERT INTO CompleteTasks@' || i_link_to_archive || '(TaskID,ProcID,ActSeq,finalrevieweractseq,AllActSeqs,originatortype,Originator,OriginatorName,finalreviewertype,FinalReviewer,FinalReviewerName,Source,taskinitiatortype,TaskInitiator,TaskInitiatorName,CreationDT,StartDate,DueDate,EndDate,Title,Description,Priority,Category1,Category2,State,AssignorText1,AssignorLookup1,ver,customid,TaskInfoID,emailSender,showcorrespondence)
			 SELECT TaskID,ProcID,ActSeq,finalrevieweractseq,AllActSeqs,originatortype,Originator,OriginatorName,finalreviewertype,FinalReviewer,FinalReviewerName,Source,taskinitiatortype,TaskInitiator,TaskInitiatorName,CreationDT,StartDate,DueDate,EndDate,Title,Description,Priority,Category1,Category2,State,AssignorText1,AssignorLookup1,ver,customid,TaskInfoID,emailSender,showcorrespondence
			   FROM CompleteTasks WHERE TaskID = :1' using l_taskid;

		execute immediate '
		INSERT INTO CompleteSubTasks@' || i_link_to_archive || '(TaskID,SubTaskID,ParentTaskID,ProcID,ActSeq,AllActSeqs,TransSeq,alttransseq,ConnectorSeq,RouteBack,groupoption,WBS,taskinitiatortype ,TaskInitiator,TaskInitiatorName,initiateuser,initiateusername,assigneetype ,Assignee,AssigneeName,ExternalUser,StartDate,DueDate,EndDate,Title,Description,AllParentActSeqs,InheritHistoryActSeqs,Priority,State,AssigneeText1,AssigneeLookup1,ver,customid,TaskInfoID,SubTaskInfoID,emailSender,showcorrespondence)
			 SELECT TaskID,SubTaskID,ParentTaskID,ProcID,ActSeq,AllActSeqs,TransSeq,alttransseq,ConnectorSeq,RouteBack,groupoption,WBS,taskinitiatortype ,TaskInitiator,TaskInitiatorName,initiateuser,initiateusername,assigneetype ,Assignee,AssigneeName,ExternalUser,StartDate,DueDate,EndDate,Title,Description,AllParentActSeqs,InheritHistoryActSeqs,Priority,State,AssigneeText1,AssigneeLookup1,ver,customid,TaskInfoID,SubTaskInfoID,emailSender,showcorrespondence
			   FROM CompleteSubTasks WHERE TaskID = :1' using l_taskid;

		execute immediate '
		INSERT INTO CompleteTasksAux@' || i_link_to_archive || '(TaskID,customNumber1,customNumber2,customNumber3,customNumber4,customNumber5,customNumber6,customNumber7,customNumber8,customNumber9,customNumber10,customNumber11,customNumber12,customNumber13,customNumber14,customNumber15,customNumber16,customNumber17,customNumber18,customNumber19,customNumber20,customDate1,customDate2,customDate3,customDate4,customDate5,customDate6,customDate7,customDate8,customDate9,customDate10,customDate11,customDate12,customDate13,customDate14,customDate15,customDate16,customDate17,customDate18,customDate19,customDate20,
					customString1,customString2,customString3,customString4,customString5,customString6,customString7,customString8,customString9,customString10,customString11,customString12,customString13,customString14,customString15,customString16,customString17,customString18,customString19,customString20,customString21,customString22,customString23,customString24,customString25,customString26,customString27,customString28,customString29,customString30)
			 SELECT TaskID,customNumber1,customNumber2,customNumber3,customNumber4,customNumber5,customNumber6,customNumber7,customNumber8,customNumber9,customNumber10,customNumber11,customNumber12,customNumber13,customNumber14,customNumber15,customNumber16,customNumber17,customNumber18,customNumber19,customNumber20,customDate1,customDate2,customDate3,customDate4,customDate5,customDate6,customDate7,customDate8,customDate9,customDate10,customDate11,customDate12,customDate13,customDate14,customDate15,customDate16,customDate17,customDate18,customDate19,customDate20,
					customString1,customString2,customString3,customString4,customString5,customString6,customString7,customString8,customString9,customString10,customString11,customString12,customString13,customString14,customString15,customString16,customString17,customString18,customString19,customString20,customString21,customString22,customString23,customString24,customString25,customString26,customString27,customString28,customString29,customString30 
			   FROM CompleteTasksAux 
			  WHERE TaskID = :1' using l_taskid;

		execute immediate '
		INSERT INTO CompleteSubTasksAux@' || i_link_to_archive || '(TaskID,SubTaskID,customNumber1,customNumber2,customNumber3,customNumber4,customNumber5,customNumber6,customNumber7,customNumber8,customNumber9,customNumber10,customNumber11,customNumber12,customNumber13,customNumber14,customNumber15,customNumber16,customNumber17,customNumber18,customNumber19,customNumber20,customDate1,customDate2,customDate3,customDate4,customDate5,customDate6,customDate7,customDate8,customDate9,customDate10,customDate11,customDate12,customDate13,customDate14,customDate15,customDate16,customDate17,customDate18,customDate19,customDate20,
					customString1,customString2,customString3,customString4,customString5,customString6,customString7,customString8,customString9,customString10,customString11,customString12,customString13,customString14,customString15,customString16,customString17,customString18,customString19,customString20,customString21,customString22,customString23,customString24,customString25,customString26,customString27,customString28,customString29,customString30)
			 SELECT TaskID,SubTaskID,customNumber1,customNumber2,customNumber3,customNumber4,customNumber5,customNumber6,customNumber7,customNumber8,customNumber9,customNumber10,customNumber11,customNumber12,customNumber13,customNumber14,customNumber15,customNumber16,customNumber17,customNumber18,customNumber19,customNumber20,customDate1,customDate2,customDate3,customDate4,customDate5,customDate6,customDate7,customDate8,customDate9,customDate10,customDate11,customDate12,customDate13,customDate14,customDate15,customDate16,customDate17,customDate18,customDate19,customDate20,
					customString1,customString2,customString3,customString4,customString5,customString6,customString7,customString8,customString9,customString10,customString11,customString12,customString13,customString14,customString15,customString16,customString17,customString18,customString19,customString20,customString21,customString22,customString23,customString24,customString25,customString26,customString27,customString28,customString29,customString30 
			   FROM CompleteSubTasksAux 
			  WHERE TaskID = :1' using l_taskid;

		execute immediate '
		INSERT INTO CompleteResponses@' || i_link_to_archive || '(TaskID,SubTaskID,AssigneeResponse,InitiatorResponse)
			 SELECT TaskID,SubTaskID,AssigneeResponse,InitiatorResponse
			   FROM CompleteResponses WHERE TaskID = :1' using l_taskid;

		execute immediate '
		INSERT INTO CompleteDTaskerAudit@' || i_link_to_archive || '(TaskID, SubTaskID,Seq,FromName,FromGroupName,ToName,FromID,FromGroupID,ToID,CreationDT,ValueType,Value)
			 SELECT TaskID, SubTaskID,Seq,FromName,FromGroupName,ToName,FromID,FromGroupID,ToID,CreationDT,ValueType,Value
			   FROM CompleteDTaskerAudit WHERE TaskID = :1' using l_taskid;

		execute immediate '
		INSERT INTO CompleteTaskAssociation@' || i_link_to_archive || '(TaskID,SubTaskID,ProcID,ActSeq,WitemSeq)
			 SELECT TaskID,SubTaskID,ProcID,ActSeq,WitemSeq
			   FROM CompleteTaskAssociation WHERE TaskID = :1' using l_taskid;

		execute immediate '
		INSERT INTO completetaskprtcp@' || i_link_to_archive || '(taskid,subtaskid,prtcp,type,kind,externaluser)
			 SELECT taskid,subtaskid,prtcp,type,kind,externaluser
			   FROM completetaskprtcp WHERE TaskID = :1' using l_taskid;

		execute immediate '
		INSERT INTO completetaskapprovers@' || i_link_to_archive || '(taskid,seq,type,prtcp,name)
			 SELECT taskid,seq,type,prtcp,name
			   FROM completetaskapprovers WHERE TaskID = :1' using l_taskid;
	End if;

	-- QuickProcess support for Archive database
	SELECT Count(1) INTO l_cnt FROM plantask WHERE procid = i_procid;
	If l_cnt > 0 Then
		execute immediate '
		INSERT INTO plantask@' || i_link_to_archive || '(procid, taskid, disporder, stepname, duedtime, deadlinetype, deadline, allowcollab, allowmoretask, allowreject, allowgoaladd, allowgoaldelete, allowgoalcheck, allowflowedit, allowprocend, dscpt, instruction, prtcptype, prtcp, prtcpname, category1, category2, selfnote, rate, ratecmnt, reminderdtime, reminderstate, actseq)
		SELECT procid, taskid, disporder, stepname, duedtime, deadlinetype, deadline, allowcollab, allowmoretask, allowreject, allowgoaladd, allowgoaldelete, allowgoalcheck, allowflowedit, allowprocend, dscpt, instruction, prtcptype, prtcp, prtcpname, category1, category2, selfnote, rate, ratecmnt, reminderdtime, reminderstate, actseq
		FROM plantask
		WHERE procid = :1' using i_procid;

		execute immediate '
		INSERT INTO plangoal@' || i_link_to_archive || '(goalid, name, disporder, state, creationdtime, creator, creatorname, modifydtime, modifier, modifiername, dscpt, procid, taskid)
		SELECT goalid, name, disporder, state, creationdtime, creator, creatorname, modifydtime, modifier, modifiername, dscpt, procid, taskid
		FROM plangoal
		WHERE procid = :1' using i_procid;

		execute immediate '
		INSERT INTO plantasklimitedassignee@' || i_link_to_archive || '(procid, taskid, taskassigneeid, assigneetype, assignee, assigneename)
		SELECT procid, taskid, taskassigneeid, assigneetype, assignee, assigneename
		FROM plantasklimitedassignee
		WHERE procid = :1' using i_procid;

		execute immediate '
		INSERT INTO planprtcp@' || i_link_to_archive || '(procid, prtcpkind, prtcpid, prtcptype, prtcp, prtcpname, cmnt)
		SELECT procid, prtcpkind, prtcpid, prtcptype, prtcp, prtcpname, cmnt
		FROM planprtcp
		WHERE procid = :1' using i_procid;

		execute immediate '
		INSERT INTO planreminder@' || i_link_to_archive || '(procid, prtcpkind, prtcpid, taskid, reminderid, name, value, resid, type, days, hours, mins)
		SELECT procid, prtcpkind, prtcpid, taskid, reminderid, name, value, resid, type, days, hours, mins
		FROM planreminder
		WHERE procid = :1' using i_procid;

		execute immediate '
		INSERT INTO plantaskaux@' || i_link_to_archive || '(procid, taskid, customnumber1, customnumber2, customnumber3, customnumber4, customnumber5, customnumber6, customnumber7, customnumber8, customdate1, customdate2, customdate3, customdate4, customdate5, customdate6, customdate7, customdate8, customstring1, customstring2, customstring3, customstring4, customstring5, customstring6, customstring7, customstring8, customstring9, customstring10, customstring11, customstring12)
		SELECT procid, taskid, customnumber1, customnumber2, customnumber3, customnumber4, customnumber5, customnumber6, customnumber7, customnumber8, customdate1, customdate2, customdate3, customdate4, customdate5, customdate6, customdate7, customdate8, customstring1, customstring2, customstring3, customstring4, customstring5, customstring6, customstring7, customstring8, customstring9, customstring10, customstring11, customstring12
		FROM plantaskaux
		WHERE procid = :1' using i_procid;

		execute immediate '
		INSERT INTO plansubtask@' || i_link_to_archive || '(procid, taskid, subtaskid, name, duedtime, guidance, priority, fyi, showhistory)
		SELECT procid, taskid, subtaskid, name, duedtime, guidance, priority, fyi, showhistory
		FROM plansubtask
		WHERE procid = :1' using i_procid;

		execute immediate '
		INSERT INTO plansubtaskaux@' || i_link_to_archive || '(procid, taskid, subtaskid, customnumber1, customnumber2, customnumber3, customnumber4, customnumber5, customnumber6, customnumber7, customnumber8, customdate1, customdate2, customdate3, customdate4, customdate5, customdate6, customdate7, customdate8, customstring1, customstring2, customstring3, customstring4, customstring5, customstring6, customstring7, customstring8, customstring9, customstring10, customstring11, customstring12)
		SELECT procid, taskid, subtaskid, customnumber1, customnumber2, customnumber3, customnumber4, customnumber5, customnumber6, customnumber7, customnumber8, customdate1, customdate2, customdate3, customdate4, customdate5, customdate6, customdate7, customdate8, customstring1, customstring2, customstring3, customstring4, customstring5, customstring6, customstring7, customstring8, customstring9, customstring10, customstring11, customstring12
		FROM plansubtaskaux
		WHERE procid = :1' using i_procid;

		execute immediate '
		INSERT INTO plansubtaskprtcp@' || i_link_to_archive || '(procid, taskid, subtaskid, subtaskprtcpid, prtcptype, prtcp, prtcpname, kind, externaluser)
		SELECT procid, taskid, subtaskid, subtaskprtcpid, prtcptype, prtcp, prtcpname, kind, externaluser
		FROM plansubtaskprtcp
		WHERE procid = :1' using i_procid;

	End if;

exception
        when others then
                raise_application_error(-20812, sqlerrm);
end; -- procedure
/
