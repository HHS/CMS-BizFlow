-- spool credb.log
-- 12.4.0.0
--
CREATE TABLE dmn (
       dmnid                VARCHAR2(7) NOT NULL,
       name                 VARCHAR2(100) NOT NULL,
       internetdmn          VARCHAR2(100) NOT NULL
)
/

CREATE UNIQUE INDEX xpkdmn ON dmn
(
       dmnid
)
/


ALTER TABLE dmn
       ADD ( PRIMARY KEY (dmnid) )
/


CREATE TABLE svr (
       svrid                VARCHAR2(10) NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       state                CHAR(1) DEFAULT '?' NOT NULL,
       dmnid                VARCHAR2(7) NOT NULL,
       name                 VARCHAR2(100) NOT NULL,
       ipaddr               VARCHAR2(40) DEFAULT '127.000.000.001' NOT NULL,
       svrport              NUMBER(10) DEFAULT 0 NOT NULL,
       iscport              NUMBER(10) DEFAULT 0 NOT NULL,
       uniquesvrid          VARCHAR2(10) NULL,
       loginid              VARCHAR2(100) NULL,
       passwd               VARCHAR2(150) NULL,
       uri                  VARCHAR2(255) NULL
)
/

CREATE UNIQUE INDEX xpksvr ON svr
(	
       svrid
)
/


ALTER TABLE svr
       ADD ( PRIMARY KEY (svrid) )
/


CREATE TABLE fldrlist (
       svrid                VARCHAR2(10) NOT NULL,
       fldrid               NUMBER(10) DEFAULT 0 NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       ispublic             CHAR(1) DEFAULT '?' NOT NULL,
       inherittype          CHAR(1) DEFAULT '?' NOT NULL,
       parentfldrid         NUMBER(10) DEFAULT 0 NOT NULL,
       disporder            NUMBER(10) DEFAULT 0 NOT NULL,
       prjid                NUMBER(10) DEFAULT 0 NOT NULL,
       ver                  NUMBER(10) DEFAULT 1 NOT NULL,
       name                 VARCHAR2(100) NOT NULL,
       creatorid            VARCHAR2(10) NOT NULL,
       creationdtime        DATE NULL,
       creatorname          VARCHAR2(100) NULL,
       dscpt                VARCHAR2(255) NULL,
       fldrpath             VARCHAR2(500) NULL
)
/

CREATE UNIQUE INDEX xpkfldrlist ON fldrlist
(
       fldrid
)
/

create index xie1fldrlist on fldrlist
(
       prjid
)
/

create index xie2fldrlist on fldrlist
(
       parentfldrid
)
/

create index xie3fldrlist on fldrlist
(
       type
)
/
ALTER TABLE fldrlist
       ADD ( PRIMARY KEY (fldrid) )
/


CREATE TABLE procdef (
       svrid                VARCHAR2(10) NOT NULL,
       procdefid            NUMBER(10) DEFAULT 0 NOT NULL,
       verctrltype          CHAR(1) DEFAULT '?' NOT NULL,
       isfinal              CHAR(1) DEFAULT '?' NOT NULL,
       envtype              CHAR(1) DEFAULT '?' NOT NULL,
       deadlinetype         CHAR(1) DEFAULT '?' NOT NULL,
       subproctype          CHAR(1) DEFAULT '?' NOT NULL,
       passwdflag           CHAR(1) DEFAULT '?' NOT NULL,
       publicationstate     CHAR(1) DEFAULT '?' NOT NULL,
       pkitype              CHAR(1) DEFAULT 'N' NOT NULL,
       caltype              CHAR(1) DEFAULT 'B' NOT NULL,
       dmsaveflag           CHAR(1) DEFAULT '?' NOT NULL,
       dmidtype             CHAR(1) DEFAULT '?' NOT NULL,
       customtab            CHAR(1) DEFAULT 'F' NOT NULL,
       fldrsvrid            VARCHAR2(10) NOT NULL,
       fldrid               NUMBER(10) DEFAULT 0 NOT NULL,
       prjfldrid            NUMBER(10) DEFAULT 0 NULL,
       orgprocdefid         NUMBER(10) DEFAULT 0 NOT NULL,
       ver                  NUMBER(10) DEFAULT 1 NOT NULL,
       procauth             NUMBER(10) DEFAULT 0 NOT NULL,
       instfldrid           NUMBER(10) DEFAULT 0 NOT NULL,
       archivefldrid        NUMBER(10) DEFAULT 0 NOT NULL,
       orgmdtmpltid         NUMBER(10) DEFAULT 0 NOT NULL,
       name                 VARCHAR2(100) NOT NULL,
       deadline             NUMBER(10) DEFAULT 0 NOT NULL,
       creationdtime        DATE NOT NULL,
       creator              VARCHAR2(10) NOT NULL,
       creatorname          VARCHAR2(100) NOT NULL,
       creatordeptname      VARCHAR2(100) NULL,
       usrgrphid            VARCHAR2(10) NULL,
       calmemberid          VARCHAR2(10) NULL,
       presvrid             VARCHAR2(10) NULL,
       preprocdefid         NUMBER(10) DEFAULT 0 NULL,
       checkoutusr          VARCHAR2(10) NULL,
       modifydtime          DATE NULL,
       modifier             VARCHAR2(10) NULL,
       modifiername         VARCHAR2(100) NULL,
       dmsvrid              VARCHAR2(10) NULL,
       publishdtime         DATE NULL,
       publisher            VARCHAR2(10) NULL,
       publishername        VARCHAR2(100) NULL,
       dmfldrid             VARCHAR2(500) NULL,
       dscpt                VARCHAR2(255) NULL,
       chkincmnt            VARCHAR2(500) NULL
)
/

CREATE UNIQUE INDEX xpkprocdef ON procdef
(
       procdefid
)
/

create index xie1procdef on procdef
(
       fldrid,
       creationdtime
)
/

create index xie2procdef on procdef
(
       prjfldrid,
       creationdtime                 
)
/

create index xie3procdef on procdef
(
       orgprocdefid,
       ver                           
)
/

create index xie4procdef on procdef
(
       checkoutusr
)
/

ALTER TABLE procdef
       ADD ( PRIMARY KEY (procdefid) )
/


CREATE TABLE procs (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       urgent               CHAR(1) DEFAULT '?' NOT NULL,
       deadlinetype         CHAR(1) DEFAULT '?' NOT NULL,
       subproctype          CHAR(1) DEFAULT '?' NOT NULL,
       passwdflag           CHAR(1) DEFAULT '?' NOT NULL,
       state                CHAR(1) DEFAULT '?' NOT NULL,
       dmsaveflag           CHAR(1) DEFAULT '?' NOT NULL,
       dmidtype             CHAR(1) DEFAULT '?' NOT NULL,
       caltype              CHAR(1) DEFAULT 'B' NOT NULL,
       internalid           NUMBER(10) DEFAULT 100 NOT NULL,
       cmntcnt              NUMBER(10) DEFAULT 0 NOT NULL,
       attachcnt            NUMBER(10) DEFAULT 0 NOT NULL,
       orgprocdefid         NUMBER(10) DEFAULT 0 NOT NULL,
       revisionid           NUMBER(10) DEFAULT 0 NOT NULL,
       instfldrid           NUMBER(10) DEFAULT 0 NOT NULL,
       ver                  NUMBER(10) DEFAULT 1 NOT NULL,
       archivefldrid        NUMBER(10) DEFAULT 0 NOT NULL,
       name                 VARCHAR2(100) NOT NULL,
       creationdtime        DATE NOT NULL,
       creator              VARCHAR2(10) NOT NULL,
       creatorname          VARCHAR2(100) NOT NULL,
       deadline             NUMBER(10) DEFAULT 0 NOT NULL,
       presvrid             VARCHAR2(10) NOT NULL,
       preprocdefid         NUMBER(10) DEFAULT 0 NOT NULL,
       preprocdefname       VARCHAR2(100) NOT NULL,
       usrgrphid            VARCHAR2(10) NULL,
       calmemberid          VARCHAR2(10) NULL,
       customid             VARCHAR2(255) NULL,
       cmpltdtime           DATE NULL,
       deadlinedtime        DATE NULL,
       returnsvrid          VARCHAR2(10) NULL,
       parentsvrid          VARCHAR2(10) NULL,
       parentprocid         NUMBER(10) DEFAULT 0 NULL,
       parentactseq         NUMBER(10) DEFAULT 0 NULL,
       parentacttype        CHAR(1) DEFAULT '?' NULL,
       checkoutusr          VARCHAR2(10) NULL,
       modifydtime          DATE NULL,
       modifier             VARCHAR2(10) NULL,
       modifiername         VARCHAR2(100) NULL,
       lastcorrespondence   VARCHAR2(100) NULL,
       dmsvrid              VARCHAR2(10) NULL,
       dmfldrid             VARCHAR2(500) NULL,
       dscpt                VARCHAR2(255) NULL
)
/

CREATE UNIQUE INDEX xpkprocs ON procs
(
       procid
)
/

CREATE UNIQUE INDEX xak1procs ON procs
(
       customid
)
/

CREATE INDEX xie1procs ON procs
(
       deadlinedtime,
       state
)
/

CREATE INDEX xie2procs ON procs
(
       instfldrid,
       creationdtime
)
/

CREATE INDEX xie3procs ON procs
(
       archivefldrid,
       cmpltdtime
)
/

CREATE INDEX xie4procs ON procs
(
       preprocdefid
)
/

CREATE INDEX xie5procs ON procs
(
       cmpltdtime
)
/

CREATE INDEX xie6procs ON procs
(
       parentprocid                   asc,
       parentactseq                   asc
)
/

CREATE INDEX xie7procs ON procs
(
       creator                        asc,
       state                          asc
)
/

CREATE INDEX xie8procs ON procs
(
       revisionid                     asc
)
/

CREATE INDEX xie9procs ON procs
(
       orgprocdefid                   asc
)
/

CREATE INDEX xie10procs ON procs
(
       checkoutusr
)
/

ALTER TABLE procs
       ADD ( PRIMARY KEY (procid) )
/


CREATE TABLE procfileinfo (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       filesize             NUMBER(10) DEFAULT 0 NULL,
       filecnt              NUMBER(10) DEFAULT 0 NULL
)
/

CREATE UNIQUE INDEX xpkprocfileinfo ON procfileinfo
(
       procid
)
/


ALTER TABLE procfileinfo
       ADD ( PRIMARY KEY (procid) )
/


CREATE TABLE auditinfo (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       execseq              NUMBER(10) DEFAULT 0 NOT NULL,
       event                CHAR(1) NOT NULL,
       objtype              CHAR(1) NOT NULL,
       objstate             CHAR(1) NOT NULL,
       execdtime            DATE NOT NULL,
       errno                NUMBER(10) DEFAULT 0 NOT NULL,
       actor                VARCHAR2(10) DEFAULT 0 NOT NULL,
       actorname            VARCHAR2(100) NOT NULL,
       objname              VARCHAR2(100) NOT NULL,
       objseq               NUMBER(10) DEFAULT 0 NULL,
       witemappseq          NUMBER(10) DEFAULT 0 NULL,
       respgrpseq           NUMBER(10) DEFAULT 0 NULL,
       respseq              NUMBER(10) DEFAULT 0 NULL,
       resp                 VARCHAR2(100) NULL,
       appname              VARCHAR2(100) NULL,
       objdscpt             VARCHAR2(255) NULL
)storage(initial 2m next 1m)
/

CREATE UNIQUE INDEX xpkauditinfo ON auditinfo
(	
       procid,
       execseq
)storage(initial 100k next 100k)
/

CREATE INDEX xie1auditinfo ON auditinfo
(	
       procid,
       objseq
)storage(initial 100k next 100k)
/

ALTER TABLE auditinfo
       ADD ( PRIMARY KEY (procid, execseq) )
/

CREATE TABLE auditinfoadm (
       seq                  NUMBER(10) DEFAULT 0 NOT NULL,
       actor                VARCHAR2(10) NOT NULL,
       actorname            VARCHAR2(100) NOT NULL,
       dtime                DATE NOT NULL,
       event                VARCHAR2(100) NOT NULL,
       objid                VARCHAR2(20) NULL,
       objtype              VARCHAR2(50) NULL,
       objname              VARCHAR2(100) NULL,
       ipaddr               VARCHAR2(40) NULL,
       detail               CLOB NULL
)
/

CREATE UNIQUE INDEX xpkauditinfoadm ON auditinfoadm
(	
       seq
)storage(initial 100k next 100k)
/

ALTER TABLE auditinfoadm
       ADD ( PRIMARY KEY (seq) )
/

CREATE TABLE checkout (
       svrid                VARCHAR2(10) NOT NULL,
       nodeid               VARCHAR2(10) NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       dtime                DATE NOT NULL,
       memberid             VARCHAR2(10) NOT NULL,
       membername           VARCHAR2(100) NULL
)
/

CREATE UNIQUE INDEX xpkcheckout ON checkout
(
       type,
       nodeid
)
/

CREATE INDEX xie1checkout ON checkout
(
       memberid
)
/

ALTER TABLE checkout
       ADD ( PRIMARY KEY (type, nodeid) )
/


CREATE TABLE jobtitle (
       jobtitleid           VARCHAR2(10) NOT NULL,
       name                 VARCHAR2(100) NOT NULL,
       disporder            NUMBER(10) DEFAULT 0 NOT NULL
)
/

CREATE UNIQUE INDEX xpkjobtitle ON jobtitle
(
       jobtitleid
)
/


ALTER TABLE jobtitle
       ADD ( PRIMARY KEY (jobtitleid) )
/


CREATE TABLE member (
       memberid             VARCHAR2(10) NOT NULL,
       type                 CHAR(1) NOT NULL,
       state                CHAR(1) DEFAULT 'N' NOT NULL,
       isabsent             CHAR(1) DEFAULT '?' NOT NULL,
       lictype              CHAR(1) DEFAULT 'N' NOT NULL,
       inherittype          CHAR(1) DEFAULT '?' NOT NULL,
       changepasswd         CHAR(1) DEFAULT '?' NOT NULL,
       passwdneverexpire    CHAR(1) DEFAULT 'F' NOT NULL,
       disporder            NUMBER(10) DEFAULT 0 NOT NULL,
       passwdfailcnt        NUMBER(10) DEFAULT 0 NOT NULL,
       etcinfo              NUMBER(10) DEFAULT 0 NOT NULL,
       memberinfoid         VARCHAR2(10) DEFAULT '0000000000' NOT NULL,
       name                 VARCHAR2(100) NOT NULL,
       passwddtime          DATE NULL,
       loginid              VARCHAR2(100) NULL,
       jobtitleid           VARCHAR2(10) NULL,
       svrid                VARCHAR2(10) NULL,
       deptid               VARCHAR2(10) NULL,
       deptcode             VARCHAR2(10) NULL,
       deptname             VARCHAR2(100) NULL,
       jobtitlename         VARCHAR2(100) NULL,
       shortname            VARCHAR2(30) NULL,
       parentdeptid         VARCHAR2(10) NULL,
       empno                VARCHAR2(10) NULL,
       alias                VARCHAR2(100) NULL,
       email                VARCHAR2(100) NULL,
       managerid            VARCHAR2(10) NULL,
       passwd               VARCHAR2(150) NULL,
       absstartdtime        DATE NULL,
       absenddtime          DATE NULL,
       abssurrogater        VARCHAR2(10) NULL,
       dscpt                VARCHAR2(100) NULL,
       guid                 VARCHAR2(128) NULL,
       absmsg               VARCHAR2(255) NULL,
       ldapdn               VARCHAR2(1500) NULL,
       carrier              VARCHAR2(100) NULL,
       reminderdelivery     VARCHAR2(10) NULL,
       cell                 VARCHAR2(20) NULL,
       t_checkoutuserid     VARCHAR2(10) NULL,
       t_name               VARCHAR2(100) NULL,
       t_deptid             VARCHAR2(10) NULL,
       t_delete             CHAR(1) NULL
)
/

CREATE UNIQUE INDEX xpkmember ON member
(
       memberid
)
/

CREATE UNIQUE INDEX xak1member ON member
(
       loginid
)
/

CREATE INDEX xie1member ON member
(
       abssurrogater
)
/

CREATE INDEX xie2member ON member
(
       deptid
)
/

CREATE INDEX xie3member ON member
(
       absstartdtime
)
/

CREATE INDEX xie4member ON member
(
       isabsent
)
/

create index xie5member on member (name asc)
/

create index xie6member on member (shortname asc)
/

create index xie7member on member (email asc)
/

create index xie8member on member (type asc)
/

ALTER TABLE member
       ADD ( PRIMARY KEY (memberid) )
/

CREATE TABLE membertemp ( 
       checkoutuserid       VARCHAR2(10) NOT NULL,
       memberid             VARCHAR2(10) NOT NULL,
       type                 CHAR(1) NOT NULL,
       name                 VARCHAR2(100) NOT NULL,
       deptid               VARCHAR2(10) NULL
)
/

CREATE UNIQUE INDEX xpkmembertemp ON membertemp
(
       checkoutuserid, memberid
)
/

ALTER TABLE membertemp
       ADD ( PRIMARY KEY (checkoutuserid, memberid) )
/

CREATE TABLE memberinfo (
       memberid             VARCHAR2(10) NOT NULL,
       dupusrflag           CHAR(1) DEFAULT '?' NOT NULL,
       dupnameflag          CHAR(1) DEFAULT '?' NOT NULL,
       headofregion      	CHAR(1) DEFAULT '?' NOT NULL,
       managerrule          NUMBER(10) DEFAULT 0 NOT NULL,
       ida                  VARCHAR2(10) NULL,
       idb                  VARCHAR2(10) NULL,
       namea                VARCHAR2(100) NULL,
       nameb                VARCHAR2(100) NULL,
       customa              VARCHAR2(100) NULL,
       customb              VARCHAR2(100) NULL,
       customc              VARCHAR2(100) NULL,
       customd              VARCHAR2(100) NULL,
       custome              VARCHAR2(100) NULL
)
/

CREATE UNIQUE INDEX xpkmemberinfo ON memberinfo
(
       memberid
)
/

create index xie1memberinfo on memberinfo
(
       customa                        asc
)
/

create index xie2memberinfo on memberinfo
(
       customb                        asc
)
/

create index xie3memberinfo on memberinfo
(
       customc                        asc
)
/

create index xie4memberinfo on memberinfo
(
       customd                        asc
)
/

create index xie5memberinfo on memberinfo
(
       custome                        asc
)
/

ALTER TABLE memberinfo
       ADD ( PRIMARY KEY (memberid) )
/


CREATE TABLE usrsession (
       memberid             VARCHAR2(10) NOT NULL,
       ipaddr               VARCHAR2(40) NOT NULL,
       device               VARCHAR2(50) DEFAULT 'DESKTOP' NOT NULL,
       logincnt             NUMBER(10) DEFAULT 0 NOT NULL,
       logindtime           DATE NULL,
       sessionkey           VARCHAR2(100) NULL
)
/

CREATE UNIQUE INDEX xpkusrsession ON usrsession
(
       memberid, device
)
/


ALTER TABLE usrsession
       ADD ( PRIMARY KEY (memberid, device) )
/


CREATE TABLE appcheckout (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       mapid                NUMBER(10) DEFAULT 0 NOT NULL,
       state                CHAR(1) DEFAULT '?' NOT NULL,
       dtime                DATE NOT NULL,
       prtcp                VARCHAR2(10) NULL,
       prtcpname            VARCHAR2(100) NULL
)
/

CREATE UNIQUE INDEX xpkappcheckout ON appcheckout
(
       procid,
       mapid
)
/

CREATE INDEX xie1appcheckout on appcheckout
(
       prtcp
)
/

ALTER TABLE appcheckout
       ADD ( PRIMARY KEY (procid, mapid) )
/


CREATE TABLE actdef (
       svrid                VARCHAR2(10) NOT NULL,
       procdefid            NUMBER(10) DEFAULT 0 NOT NULL,
       actdefseq            NUMBER(10) DEFAULT 0 NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       jointype             CHAR(1) DEFAULT '?' NOT NULL,
       casetype             CHAR(1) DEFAULT '?' NOT NULL,
       deadlinetype         CHAR(1) DEFAULT '?' NOT NULL,
       transtype            CHAR(1) DEFAULT '?' NOT NULL,
       caltype              CHAR(1) DEFAULT 'U' NOT NULL,
       existinfofile        CHAR(1) DEFAULT 'F' NOT NULL,
       existcmntrans        CHAR(1) DEFAULT 'F' NOT NULL,
       isrepsign            CHAR(1) DEFAULT 'F' NOT NULL,
       subproctype          CHAR(1) DEFAULT '?' NOT NULL,
       sendapp              CHAR(1) DEFAULT 'F' NOT NULL,
       sendattach           CHAR(1) DEFAULT 'F' NOT NULL,
       sendcmnt             CHAR(1) DEFAULT 'F' NOT NULL,
       checkpostcond        CHAR(1) DEFAULT 'F' NOT NULL,
       cmpltopt             CHAR(1) DEFAULT '?' NOT NULL,
       rbackopt             CHAR(1) DEFAULT '?' NOT NULL,
       subenvtype           CHAR(1) DEFAULT '?' NOT NULL,
       eventtype            CHAR(1) DEFAULT '?' NOT NULL,
       actlooptype          CHAR(1) DEFAULT '?' NOT NULL,
       attaddcnt            NUMBER(10) DEFAULT 0 NOT NULL,
       name                 VARCHAR2(100) NOT NULL,
       priority             NUMBER(10) DEFAULT 0 NOT NULL,
       actauth              NUMBER(10) DEFAULT 0 NOT NULL,
       actinfo              NUMBER(10) DEFAULT 0 NOT NULL,
       deadline             NUMBER(10) DEFAULT 0 NOT NULL,
       respgrpseq           NUMBER(10) DEFAULT 0 NOT NULL,
       respseq              NUMBER(10) DEFAULT 0 NOT NULL,
       capacity             NUMBER(10) DEFAULT 0 NOT NULL,
       cost                 NUMBER(10) DEFAULT 0 NOT NULL,
       providerid           NUMBER(10) DEFAULT 0 NOT NULL,
       subsvrid             VARCHAR2(10) NULL,
       subprocdefid         NUMBER(10) DEFAULT 0 NULL,
       suborgprocdefid      NUMBER(10) DEFAULT 0 NULL,
       postconddefseq       NUMBER(10) DEFAULT 0 NULL,
       mergeconddefseq      NUMBER(10) DEFAULT 0 NULL,
       splitconddefseq      NUMBER(10) DEFAULT 0 NULL,
       fldrsvrid            VARCHAR2(10) NULL,
       fldrid               NUMBER(10) DEFAULT 0 NULL,
       tmpltsvrid           VARCHAR2(10) NULL,
       tmpltactid           NUMBER(10) DEFAULT 0 NULL,
       waitingtime          NUMBER(10) DEFAULT 0 NULL,
       workingtime          NUMBER(10) DEFAULT 0 NULL,
       planstarttime        NUMBER(10) DEFAULT 0 NULL,
       plancmplttime        NUMBER(10) DEFAULT 0 NULL,
       dscpt                VARCHAR2(100) NULL
)
/

CREATE UNIQUE INDEX xpkactdef ON actdef
(
       procdefid,
       actdefseq
)
/


ALTER TABLE actdef
       ADD ( PRIMARY KEY (procdefid, actdefseq) )
/


CREATE TABLE act (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       actseq               NUMBER(10) DEFAULT 0 NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       jointype             CHAR(1) DEFAULT '?' NOT NULL,
       casetype             CHAR(1) DEFAULT '?' NOT NULL,
       deadlinetype         CHAR(1) DEFAULT '?' NOT NULL,
       transtype            CHAR(1) DEFAULT '?' NOT NULL,
       caltype              CHAR(1) DEFAULT 'U' NOT NULL,
       existinfofile        CHAR(1) DEFAULT 'F' NOT NULL,
       existcmntrans        CHAR(1) DEFAULT 'F' NOT NULL,
       isrepsign            CHAR(1) DEFAULT 'F' NOT NULL,
       subproctype          CHAR(1) DEFAULT '?' NOT NULL,
       sendapp              CHAR(1) DEFAULT 'F' NOT NULL,
       sendattach           CHAR(1) DEFAULT 'F' NOT NULL,
       sendcmnt             CHAR(1) DEFAULT 'F' NOT NULL,
       state                CHAR(1) DEFAULT 'N' NOT NULL,
       prestate             CHAR(1) DEFAULT 'N' NOT NULL,
       checkpostcond        CHAR(1) DEFAULT 'F' NOT NULL,
       cmpltopt             CHAR(1) DEFAULT '?' NOT NULL,
       rbackopt             CHAR(1) DEFAULT '?' NOT NULL,
       eventtype            CHAR(1) DEFAULT '?' NOT NULL,
       actlooptype          CHAR(1) DEFAULT '?' NOT NULL,
       defsvrid             VARCHAR2(10) DEFAULT '0000000000' NOT NULL,
       defprocdefid         NUMBER(10) DEFAULT 0 NOT NULL,
       name                 VARCHAR2(100) NOT NULL,
       priority             NUMBER(10) DEFAULT 0 NOT NULL,
       actauth              NUMBER(10) DEFAULT 0 NOT NULL,
       actinfo              NUMBER(10) DEFAULT 0 NOT NULL,
       deadline             NUMBER(10) DEFAULT 0 NOT NULL,
       respgrpseq           NUMBER(10) DEFAULT 0 NOT NULL,
       respseq              NUMBER(10) DEFAULT 0 NOT NULL,
       capacity             NUMBER(10) DEFAULT 0 NOT NULL,
       cost                 NUMBER(10) DEFAULT 0 NOT NULL,
       providerid           NUMBER(10) DEFAULT 0 NOT NULL,
       loopcnt              NUMBER(10) DEFAULT 0 NOT NULL,
       cmpltcnt             NUMBER(10) DEFAULT 0 NOT NULL,
       spcfromnode          NUMBER(10) DEFAULT 0 NOT NULL,
       attaddcnt            NUMBER(10) DEFAULT 0 NOT NULL,
       waitingtime          NUMBER(10) DEFAULT 0 NULL,
       workingtime          NUMBER(10) DEFAULT 0 NULL,
       planstarttime        NUMBER(10) DEFAULT 0 NULL,
       plancmplttime        NUMBER(10) DEFAULT 0 NULL,
       subsvrid             VARCHAR2(10) NULL,
       subprocdefid         NUMBER(10) DEFAULT 0 NULL,
       suborgprocdefid      NUMBER(10) DEFAULT 0 NULL,
       postcondseq          NUMBER(10) DEFAULT 0 NULL,
       mergecondseq         NUMBER(10) DEFAULT 0 NULL,
       splitcondseq         NUMBER(10) DEFAULT 0 NULL,
       dscpt                VARCHAR2(100) NULL,
       resplist             VARCHAR2(255) NULL,
       deadlinedtime        DATE NULL,
       planstartdtime       DATE NULL,
       plancmpltdtime       DATE NULL,
       startdtime           DATE NULL,
       cmpltdtime           DATE NULL
)storage(initial 1m next 1m)
/

CREATE UNIQUE INDEX xpkact ON act
(
       procid,
       actseq
)storage(initial 100k next 100k)
/

CREATE INDEX xie1act ON act
(
       deadlinedtime,
       state
)
/


ALTER TABLE act
       ADD ( PRIMARY KEY (procid, actseq) )
/


CREATE TABLE attach (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       attachseq            NUMBER(10) DEFAULT 0 NOT NULL,
       witemseq             NUMBER(10) DEFAULT 0 NOT NULL,
       correspondenceseq    NUMBER(10) DEFAULT 0 NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       sendtype             CHAR(1) DEFAULT '?' NOT NULL,
       gettype              CHAR(1) DEFAULT '?' NOT NULL,
       pkitype              CHAR(1) DEFAULT 'N' NOT NULL,
       dmdocrtype			CHAR(1) DEFAULT 'N' NOT NULL,
       actseq               NUMBER(10) DEFAULT 0 NOT NULL,
       mapid                NUMBER(10) DEFAULT 0 NOT NULL,
       creationdtime        DATE NOT NULL,
       creator              VARCHAR2(10) NOT NULL,
       creatorname          VARCHAR2(100) NOT NULL,
       attachsize           NUMBER(10) DEFAULT 0 NOT NULL,
       dispname             NVARCHAR2(256) NOT NULL,
       filename             NVARCHAR2(256) NOT NULL,
       actname              VARCHAR2(100) NULL,
       dmsvrid              VARCHAR2(10) NULL,
       dmdocid              VARCHAR2(500) NULL,
       dmdockind            VARCHAR2(30) NULL,
       dscpt                NVARCHAR2(100) NULL,
       category             VARCHAR2(256) NULL,
       etcinfo              NVARCHAR2(2000) NULL
)
/

CREATE UNIQUE INDEX xpkattach ON attach
(
       procid,
       attachseq
)
/


ALTER TABLE attach
       ADD ( PRIMARY KEY (procid, attachseq) )
/


CREATE TABLE excptdef (
       svrid                VARCHAR2(10) NOT NULL,
       procdefid            NUMBER(10) DEFAULT 0 NOT NULL,
       excptdefseq          NUMBER(10) DEFAULT 0 NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       resptype             CHAR(1) DEFAULT '?' NOT NULL,
       actdefseq            NUMBER(10) DEFAULT 0 NOT NULL,
       actappdefseq         NUMBER(10) DEFAULT 0 NOT NULL,
       incvalue             NUMBER(10) DEFAULT 0 NOT NULL,
       alertstarttime       NUMBER(10) DEFAULT 0 NOT NULL,
       alertduration        NUMBER(10) DEFAULT 0 NOT NULL,
       alertinterval        NUMBER(10) DEFAULT 0 NOT NULL,
       alertreceiver        VARCHAR2(10) NULL,
       email                VARCHAR2(100) NULL,
       exename              VARCHAR2(100) NULL,
       alertsubject         VARCHAR2(100) NULL,
       alertmsg             VARCHAR2(255) NULL
)
/

CREATE UNIQUE INDEX xpkexcptdef ON excptdef
(
       procdefid,
       excptdefseq
)
/


ALTER TABLE excptdef
       ADD ( PRIMARY KEY (procdefid, excptdefseq) )
/


CREATE TABLE fldrmemberlist (
       svrid                VARCHAR2(10) NOT NULL,
       fldrid               NUMBER(10) DEFAULT 0 NOT NULL,
       memberid             VARCHAR2(10) NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       isexclude            CHAR(1) DEFAULT '?' NOT NULL,
       checksub             CHAR(1) DEFAULT 'F' NOT NULL,
       disporder            NUMBER(10) DEFAULT 0 NOT NULL,
       auth                 NUMBER(10) DEFAULT 0 NOT NULL,
       name                 VARCHAR2(100) NULL
)
/

CREATE UNIQUE INDEX xpkfldrmemberlist ON fldrmemberlist
(
       fldrid,
       memberid
)
/

CREATE INDEX xie1fldrmemberlist ON fldrmemberlist
(
       memberid
)
/


ALTER TABLE fldrmemberlist
       ADD ( PRIMARY KEY (fldrid, memberid) )
/


CREATE TABLE rlvntdata (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       rlvntdataseq         NUMBER(10) DEFAULT 0 NOT NULL,
       ispublic             CHAR(1) DEFAULT '?' NOT NULL,
       scope	            CHAR(1) DEFAULT 'I' NOT NULL,
       valuetype            CHAR(1) DEFAULT '?' NOT NULL,
       parentinouttype      CHAR(1) DEFAULT '?' NOT NULL,
       rlvntdataname        VARCHAR2(100) NOT NULL,
       dscpt                VARCHAR2(100) NULL,
       dispvalue            VARCHAR2(100) NULL,
       indexvalue           NVARCHAR2(100) NULL,
       value                NVARCHAR2(2000) NULL
)
/

CREATE UNIQUE INDEX xpkrlvntdata ON rlvntdata
(
       procid,
       rlvntdataseq
)
/

CREATE UNIQUE INDEX xak1rlvntdata ON rlvntdata
(
       procid,
       rlvntdataname,
       scope
)
/

CREATE INDEX xie1rlvntdata ON rlvntdata
(
       indexvalue                      asc
)
/

ALTER TABLE rlvntdata
       ADD ( PRIMARY KEY (procid, rlvntdataseq) )
/


CREATE TABLE param (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       actseq               NUMBER(10) DEFAULT 0 NOT NULL,
       paramseq             NUMBER(10) DEFAULT 0 NOT NULL,
       inouttype            CHAR(1) DEFAULT '?' NOT NULL,
       toscope              CHAR(1) DEFAULT 'I' NOT NULL,
       rlvntdataseq         NUMBER(10) DEFAULT 0 NOT NULL,
       disporder            NUMBER(10) DEFAULT 0 NOT NULL,
       todataname           VARCHAR2(100) NULL,
       const                VARCHAR2(100) NULL
)
/

CREATE UNIQUE INDEX xpkparam ON param
(
       procid,
       actseq,
       paramseq
)
/


ALTER TABLE param
       ADD ( PRIMARY KEY (procid, actseq, paramseq) )
/


CREATE TABLE rlvntdatadef (
       svrid                VARCHAR2(10) NOT NULL,
       procdefid            NUMBER(10) DEFAULT 0 NOT NULL,
       rlvntdatadefseq      NUMBER(10) DEFAULT 0 NOT NULL,
       ispublic             CHAR(1) DEFAULT '?' NOT NULL,
       scope                CHAR(1) DEFAULT 'I' NOT NULL,
       valuetype            CHAR(1) DEFAULT '?' NOT NULL,
       grlvntdataid         NUMBER(10) DEFAULT 0 NOT NULL,
       rlvntdatadefname     VARCHAR2(100) NOT NULL,
       dscpt                VARCHAR2(100) NULL,
       dispvalue            VARCHAR2(100) NULL,
       value                NVARCHAR2(2000) NULL
)
/

CREATE UNIQUE INDEX xpkrlvntdatadef ON rlvntdatadef
(
       procdefid,
       rlvntdatadefseq
)
/

CREATE UNIQUE INDEX xak1rlvntdatadef ON rlvntdatadef
(
       procdefid,
       rlvntdatadefname,
       scope
)
/

CREATE INDEX xie1rlvntdatadef on rlvntdatadef
(
       grlvntdataid                   asc
)
/

ALTER TABLE rlvntdatadef
       ADD ( PRIMARY KEY (procdefid, rlvntdatadefseq) )
/


CREATE TABLE paramdef (
       svrid                VARCHAR2(10) NOT NULL,
       procdefid            NUMBER(10) DEFAULT 0 NOT NULL,
       actdefseq            NUMBER(10) DEFAULT 0 NOT NULL,
       paramdefseq          NUMBER(10) DEFAULT 0 NOT NULL,
       inouttype            CHAR(1) DEFAULT '?' NOT NULL,
       toscope              CHAR(1) DEFAULT 'I' NOT NULL,
       rlvntdatadefseq      NUMBER(10) DEFAULT 0 NOT NULL,
       disporder            NUMBER(10) DEFAULT 0 NOT NULL,
       todataname           VARCHAR2(100) NULL,
       const                VARCHAR2(100) NULL
)
/

CREATE UNIQUE INDEX xpkparamdef ON paramdef
(
       procdefid,
       actdefseq,
       paramdefseq
)
/


ALTER TABLE paramdef
       ADD ( PRIMARY KEY (procdefid, actdefseq, paramdefseq) )
/


CREATE TABLE usrgrpprtcp (
       usrgrpid             VARCHAR2(10) NOT NULL,
       prtcp                VARCHAR2(10) NOT NULL,
       prtcptype            CHAR(1) NOT NULL,
       disporder            NUMBER(10) DEFAULT 0 NOT NULL,
       usrgrphid            VARCHAR2(10) NULL
)
/

CREATE UNIQUE INDEX xpkusrgrpprtcp ON usrgrpprtcp
(
       usrgrpid,
       prtcp
)
/

CREATE INDEX xie1usrgrpprtcp ON usrgrpprtcp
(
       prtcp
)
/

CREATE INDEX xie2usrgrpprtcp ON usrgrpprtcp
( 
	prtcptype
)
/

ALTER TABLE usrgrpprtcp
       ADD ( PRIMARY KEY (usrgrpid, prtcp) )
/


CREATE TABLE id (
       svrid                VARCHAR2(10) NOT NULL,
       keystr               VARCHAR2(30) NOT NULL,
       value                NUMBER(10) DEFAULT 0 NOT NULL
) PCTFREE 40 INITRANS 40
/

CREATE UNIQUE INDEX xpkid ON id
(
       keystr
) INITRANS 40
/

ALTER TABLE id
       ADD ( PRIMARY KEY (keystr) )
/


CREATE TABLE apptmplt (
       svrid                VARCHAR2(10) NOT NULL,
       appid                NUMBER(10) DEFAULT 0 NOT NULL,
       isfinal              CHAR(1) DEFAULT '?' NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       envtype              CHAR(1) DEFAULT '?' NOT NULL,
       pkitype              CHAR(1) DEFAULT 'N' NOT NULL,
       dmdocrtype           CHAR(1) DEFAULT 'N' NOT NULL,
       dmsaveflag           CHAR(1) DEFAULT '?' NOT NULL,
       dmidtype             CHAR(1) DEFAULT '?' NOT NULL,
       keepingflag          CHAR(1) DEFAULT '?' NOT NULL,
       publicationstate     CHAR(1) DEFAULT '?' NOT NULL,
       fldrsvrid            VARCHAR2(10) NOT NULL,
       fldrid               NUMBER(10) DEFAULT 0 NOT NULL,
       prjfldrid            NUMBER(10) DEFAULT 0 NOT NULL,
       orgappid             NUMBER(10) DEFAULT 0 NOT NULL,
       appver               NUMBER(10) DEFAULT 0 NOT NULL,
       creationdtime        DATE NOT NULL,
       name                 VARCHAR2(100) NOT NULL,
       author               VARCHAR2(10) NOT NULL,
       authorname           VARCHAR2(100) NOT NULL,
       preappid             NUMBER(10) DEFAULT 0 NULL,
       extname              VARCHAR2(30) NULL,
       dmsvrid              VARCHAR2(10) NULL,
       dmdocid              VARCHAR2(500) NULL,
       dmfldrid             VARCHAR2(500) NULL,
       dscpt                VARCHAR2(100) NULL,
       invokedmethod        VARCHAR2(1000) NULL,
       dmfldrname           VARCHAR2(255) NULL,
       chkincmnt            VARCHAR2(500) NULL
)
/

CREATE UNIQUE INDEX xpkapptmplt ON apptmplt
(
       appid
)
/

create index xie1apptmplt on apptmplt
(
       orgappid,
       appver                        
)
/

ALTER TABLE apptmplt
       ADD ( PRIMARY KEY (appid) )
/


CREATE TABLE procappdef (
       svrid                VARCHAR2(10) NOT NULL,
       procdefid            NUMBER(10) DEFAULT 0 NOT NULL,
       procappdefseq        NUMBER(10) DEFAULT 0 NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       envtype              CHAR(1) DEFAULT '?' NOT NULL,
       sendtype             CHAR(1) DEFAULT '?' NOT NULL,
       keepingflag          CHAR(1) DEFAULT '?' NOT NULL,
       viewtype             CHAR(1) DEFAULT 'W' NOT NULL,
       dmsaveflag           CHAR(1) DEFAULT '?' NOT NULL,
       dmidtype             CHAR(1) DEFAULT '?' NOT NULL,
       appsvrid             VARCHAR2(10) DEFAULT '0000000000' NOT NULL,
       appid                NUMBER(10) DEFAULT 0 NOT NULL,
       orgappid             NUMBER(10) DEFAULT 0 NOT NULL,
       appver               NUMBER(10) DEFAULT 1 NOT NULL,
       disporder            NUMBER(10) DEFAULT 0 NOT NULL,
       name                 VARCHAR2(100) NOT NULL,
       rlvntdatadefseq      NUMBER(10) DEFAULT 0 NULL,
       invokedmethod        VARCHAR2(1000) NULL,
       extname              VARCHAR2(30) NULL,
       dmsvrid              VARCHAR2(10) NULL,
       dmfldrid             VARCHAR2(500) NULL,
       dmdockind            VARCHAR2(30) NULL,
       dscpt                VARCHAR2(100) NULL
)
/

CREATE UNIQUE INDEX xpkprocappdef ON procappdef
(
       procdefid,
       procappdefseq
)
/


ALTER TABLE procappdef
       ADD ( PRIMARY KEY (procdefid, procappdefseq) )
/


CREATE TABLE actappdef (
       svrid                VARCHAR2(10) NOT NULL,
       procdefid            NUMBER(10) DEFAULT 0 NOT NULL,
       actdefseq            NUMBER(10) DEFAULT 0 NOT NULL,
       actappdefseq         NUMBER(10) DEFAULT 0 NOT NULL,
       updatable            CHAR(1) DEFAULT '?' NOT NULL,
       initoption           CHAR(1) DEFAULT '?' NOT NULL,
       viewtype             CHAR(1) DEFAULT 'W' NOT NULL,
       jobseq               NUMBER(10) DEFAULT 0 NOT NULL,
       procappdefseq        NUMBER(10) DEFAULT 0 NOT NULL,
       appsvrid             VARCHAR2(10) NOT NULL,
       appid                NUMBER(10) DEFAULT 0 NOT NULL,
       appver               NUMBER(10) DEFAULT 1 NOT NULL,
       inrlvntdatadefseq    NUMBER(10) DEFAULT 0 NOT NULL,
       outrlvntdatadefseq   NUMBER(10) DEFAULT 0 NOT NULL
)
/

CREATE UNIQUE INDEX xpkactappdef ON actappdef
(
       procdefid,
       actdefseq,
       actappdefseq
)
/


ALTER TABLE actappdef
       ADD ( PRIMARY KEY (procdefid, actdefseq, actappdefseq) )
/

CREATE TABLE respgrpdef (
       svrid                VARCHAR2(10) NOT NULL,
       procdefid            NUMBER(10) DEFAULT 0 NOT NULL,
       respgrpdefseq        NUMBER(10) DEFAULT 0 NOT NULL,
       name                 VARCHAR2(100) NOT NULL,
       dscpt                VARCHAR2(100) NULL
)
/

CREATE UNIQUE INDEX xpkrespgrpdef ON respgrpdef
(
       procdefid,
       respgrpdefseq
)
/


ALTER TABLE respgrpdef
       ADD ( PRIMARY KEY (procdefid, respgrpdefseq) )
/


CREATE TABLE respdef (
       svrid                VARCHAR2(10) NOT NULL,
       procdefid            NUMBER(10) DEFAULT 0 NOT NULL,
       respgrpdefseq        NUMBER(10) DEFAULT 0 NOT NULL,
       respdefseq           NUMBER(10) DEFAULT 0 NOT NULL,
       disporder            NUMBER(10) DEFAULT 0 NOT NULL,
       respinfo             NUMBER(10) DEFAULT 0 NOT NULL,
       name                 VARCHAR2(100) NOT NULL
)
/

CREATE UNIQUE INDEX xpkrespdef ON respdef
(
       procdefid,
       respgrpdefseq,
       respdefseq
)
/


ALTER TABLE respdef
       ADD ( PRIMARY KEY (procdefid, respgrpdefseq, 
              respdefseq) )
/


CREATE TABLE respgrp (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       respgrpseq           NUMBER(10) DEFAULT 0 NOT NULL,
       name                 VARCHAR2(100) NOT NULL,
       dscpt                VARCHAR2(100) NULL
)
/

CREATE UNIQUE INDEX xpkrespgrp ON respgrp
(
       procid,
       respgrpseq
)
/


ALTER TABLE respgrp
       ADD ( PRIMARY KEY (procid, respgrpseq) )
/


CREATE TABLE resp (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       respgrpseq           NUMBER(10) DEFAULT 0 NOT NULL,
       respseq              NUMBER(10) DEFAULT 0 NOT NULL,
       disporder            NUMBER(10) DEFAULT 0 NOT NULL,
       respinfo             NUMBER(10) DEFAULT 0 NOT NULL,
       name                 VARCHAR2(100) NOT NULL
)
/

CREATE UNIQUE INDEX xpkresp ON resp
(
       procid,
       respgrpseq,
       respseq
)
/


ALTER TABLE resp
       ADD ( PRIMARY KEY (procid, respgrpseq, respseq) )
/


CREATE TABLE prtcp (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       actseq               NUMBER(10) DEFAULT 0 NOT NULL,
       prtcpseq             NUMBER(10) DEFAULT 0 NOT NULL,
       kind                 CHAR(1) DEFAULT 'P' NOT NULL,
       useflag              CHAR(1) DEFAULT 'F' NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       assignrule           CHAR(1) DEFAULT '?' NOT NULL,
       existscriptfile      CHAR(1) DEFAULT '?' NOT NULL,
       prtcpauth            NUMBER(10) DEFAULT 0 NOT NULL,
       prtcp                VARCHAR2(10) NOT NULL,
       mapid                NUMBER(10) DEFAULT 0 NOT NULL,
       disporder            NUMBER(10) DEFAULT 0 NOT NULL,
       calmemberid          VARCHAR2(10) NULL,
       usrgrphid            VARCHAR2(10) NULL,
       deptname             VARCHAR2(100) NULL,
       jobtitlename         VARCHAR2(100) NULL,
       expr                 VARCHAR2(100) NULL,
       prtcpname            VARCHAR2(400) NULL
)
/

CREATE UNIQUE INDEX xpkprtcp ON prtcp
(
       procid,
       actseq,
       prtcpseq
)
/


ALTER TABLE prtcp
       ADD ( PRIMARY KEY (procid, actseq, prtcpseq) )
/


CREATE TABLE prtcpdef (
       svrid                VARCHAR2(10) NOT NULL,
       procdefid            NUMBER(10) DEFAULT 0 NOT NULL,
       actdefseq            NUMBER(10) DEFAULT 0 NOT NULL,
       prtcpdefseq          NUMBER(10) DEFAULT 0 NOT NULL,
       kind                 CHAR(1) DEFAULT 'P' NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       assignrule           CHAR(1) DEFAULT '?' NOT NULL,
       existscriptfile      CHAR(1) DEFAULT '?' NOT NULL,
       prtcpauth            NUMBER(10) DEFAULT 0 NOT NULL,
       prtcp                VARCHAR2(10) NOT NULL,
       mapid                NUMBER(10) DEFAULT 0 NOT NULL,
       disporder            NUMBER(10) DEFAULT 0 NOT NULL,
       calmemberid          VARCHAR2(10) NULL,
       usrgrphid            VARCHAR2(10) NULL,
       expr                 VARCHAR2(100) NULL
)
/

CREATE UNIQUE INDEX xpkprtcpdef ON prtcpdef
(
       procdefid,
       actdefseq,
       prtcpdefseq
)
/


ALTER TABLE prtcpdef
       ADD ( PRIMARY KEY (procdefid, actdefseq, prtcpdefseq) )
/


CREATE TABLE transdef (
       svrid                VARCHAR2(10) NOT NULL,
       procdefid            NUMBER(10) DEFAULT 0 NOT NULL,
       transdefseq          NUMBER(10) DEFAULT 0 NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       iscmntrans           CHAR(1) DEFAULT '?' NOT NULL,
       fromnode             NUMBER(10) DEFAULT 0 NOT NULL,
       tonode               NUMBER(10) DEFAULT 0 NOT NULL,
       conddefseq           NUMBER(10) DEFAULT 0 NOT NULL,
       actionconddefseq     NUMBER(10) DEFAULT 0 NOT NULL,
       evalorder            NUMBER(10) DEFAULT 0 NOT NULL,
       name                 VARCHAR2(100) NULL
)
/

CREATE UNIQUE INDEX xpktransdef ON transdef
(
       procdefid,
       transdefseq
)
/


ALTER TABLE transdef
       ADD ( PRIMARY KEY (procdefid, transdefseq) )
/


CREATE TABLE witem (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       witemseq             NUMBER(10) DEFAULT 0 NOT NULL,
       prtcptype            CHAR(1) DEFAULT '?' NOT NULL,
       onasync              CHAR(1) DEFAULT '?' NOT NULL,
       state                CHAR(1) DEFAULT '?' NOT NULL,
       urgent               CHAR(1) DEFAULT '?' NOT NULL,
       existinfofile        CHAR(1) DEFAULT '?' NOT NULL,
       checkpostcond        CHAR(1) DEFAULT '?' NOT NULL,
       actseq               NUMBER(10) DEFAULT 0 NOT NULL,
       priority             NUMBER(10) DEFAULT 0 NOT NULL,
       respgrpseq           NUMBER(10) DEFAULT 0 NOT NULL,
       respseq              NUMBER(10) DEFAULT 0 NOT NULL,
       deadline             NUMBER(10) DEFAULT 0 NOT NULL,
       prtcp                VARCHAR2(10) NOT NULL,
       prtcpname            VARCHAR2(100) NOT NULL,
       creationdtime        DATE NOT NULL,
       loopcnt              NUMBER(10) DEFAULT 0 NOT NULL,
       cmpltusr             VARCHAR2(10) DEFAULT '0000000000' NOT NULL,
       fwdfromwitemseq      NUMBER(10) DEFAULT 0 NOT NULL,
       calmemberid          VARCHAR2(10) NULL,
       startdtime           DATE NULL,
       cmpltdtime           DATE NULL,
       deadlinedtime        DATE NULL,
       cmpltusrname         VARCHAR2(100) NULL,
       checkoutusr          VARCHAR2(10) NULL,
       checkoutdtime        DATE NULL
)storage(initial 1m next 1m)
/

CREATE UNIQUE INDEX xpkwitem ON witem
(
       procid,
       witemseq
) storage (initial 100k next 100k)
/

CREATE INDEX xie1witem ON witem
(
       prtcp,
       state
)
/

CREATE INDEX xie2witem ON witem
(
       cmpltdtime
)
/

CREATE INDEX xie3witem ON witem
(
       deadlinedtime,
       state
)
/

CREATE INDEX xie4witem ON witem
(
       procid,
       actseq
)
/

CREATE INDEX xie5witem ON witem
(
       cmpltusr,
       state
)
/

CREATE INDEX xie6witem ON witem
(
       checkoutusr                    ASC
)
/

ALTER TABLE witem
       ADD ( PRIMARY KEY (procid, witemseq) )
/


CREATE TABLE conddef (
       svrid                VARCHAR2(10) NOT NULL,
       procdefid            NUMBER(10) DEFAULT 0 NOT NULL,
       conddefseq           NUMBER(10) DEFAULT 0 NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       dscpt                VARCHAR2(100) NULL,
       expr                 VARCHAR2(2000) NULL
)
/

CREATE UNIQUE INDEX xpkconddef ON conddef
(
       procdefid,
       conddefseq
)
/


ALTER TABLE conddef
       ADD ( PRIMARY KEY (procdefid, conddefseq) )
/


CREATE TABLE cond (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       condseq              NUMBER(10) DEFAULT 0 NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       dscpt                VARCHAR2(100) NULL,
       expr                 VARCHAR2(2000) NULL
)
/

CREATE UNIQUE INDEX xpkcond ON cond
(
       procid,
       condseq
)
/


ALTER TABLE cond
       ADD ( PRIMARY KEY (procid, condseq) )
/


CREATE TABLE trans (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       transseq             NUMBER(10) DEFAULT 0 NOT NULL,
       state                CHAR(1) DEFAULT '?' NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       iscmntrans           CHAR(1) DEFAULT '?' NOT NULL,
       fromnode             NUMBER(10) DEFAULT 0 NOT NULL,
       tonode               NUMBER(10) DEFAULT 0 NOT NULL,
       condseq              NUMBER(10) DEFAULT 0 NOT NULL,
       actioncondseq        NUMBER(10) DEFAULT 0 NOT NULL,
       loopcnt              NUMBER(10) DEFAULT 0 NOT NULL,
       evalorder            NUMBER(10) DEFAULT 0 NOT NULL,
       name                 VARCHAR2(100) NULL,
       modifydtime          DATE NULL
)
/

CREATE UNIQUE INDEX xpktransition ON trans
(
       procid,
       transseq
)
/


ALTER TABLE trans
       ADD ( PRIMARY KEY (procid, transseq) )
/


CREATE TABLE procapp (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       procappseq           NUMBER(10) DEFAULT 0 NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       sendtype             CHAR(1) DEFAULT '?' NOT NULL,
       keepingflag          CHAR(1) DEFAULT '?' NOT NULL,
       viewtype             CHAR(1) DEFAULT 'W' NOT NULL,
       dmsaveflag           CHAR(1) DEFAULT '?' NOT NULL,
       dmidtype             CHAR(1) DEFAULT '?' NOT NULL,
       appsvrid             VARCHAR2(10) DEFAULT '0000000000' NOT NULL,
       appid                NUMBER(10) DEFAULT 0 NOT NULL,
       orgappid             NUMBER(10) DEFAULT 0 NOT NULL,
       appver               NUMBER(10) DEFAULT 1 NOT NULL,
       disporder            NUMBER(10) DEFAULT 0 NOT NULL,
       name                 VARCHAR2(100) NOT NULL,
       rlvntdataseq         NUMBER(10) DEFAULT 0 NULL,
       invokedmethod        VARCHAR2(1000) NULL,
       extname              VARCHAR2(30) NULL,
       dmsvrid              VARCHAR2(10) NULL,
       dmfldrid             VARCHAR2(500) NULL,
       dmdockind            VARCHAR2(30) NULL,
       dscpt                VARCHAR2(100) NULL
)
/

CREATE UNIQUE INDEX xpkprocapp ON procapp
(
       procid,
       procappseq
)
/


ALTER TABLE procapp
       ADD ( PRIMARY KEY (procid, procappseq) )
/


CREATE TABLE actapp (
       svrid             VARCHAR2(10) NOT NULL,
       procid            NUMBER(10) DEFAULT 0 NOT NULL,
       actseq            NUMBER(10) DEFAULT 0 NOT NULL,
       actappseq         NUMBER(10) DEFAULT 0 NOT NULL,
       updatable         CHAR(1) DEFAULT '?' NOT NULL,
       initoption        CHAR(1) DEFAULT '?' NOT NULL,
       viewtype          CHAR(1) DEFAULT 'W' NOT NULL,
       jobseq            NUMBER(10) DEFAULT 0 NOT NULL,
       procappseq        NUMBER(10) DEFAULT 0 NOT NULL,
       appsvrid          VARCHAR2(10) NOT NULL,
       appid             NUMBER(10) DEFAULT 0 NOT NULL,
       appver            NUMBER(10) DEFAULT 1 NOT NULL,
       inrlvntdataseq    NUMBER(10) DEFAULT 0 NOT NULL,
       outrlvntdataseq   NUMBER(10) DEFAULT 0 NOT NULL,
       modifydtime       DATE NULL
)
/

CREATE UNIQUE INDEX xpkactapp ON actapp
(
       procid,
       actseq,
       actappseq
)
/


ALTER TABLE actapp
       ADD ( PRIMARY KEY (procid, actseq, actappseq) )
/


CREATE TABLE excpt (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       excptseq             NUMBER(10) DEFAULT 0 NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       resptype             CHAR(1) DEFAULT '?' NOT NULL,
       actseq               NUMBER(10) DEFAULT 0 NOT NULL,
       actappseq            NUMBER(10) DEFAULT 0 NOT NULL,
       incvalue             NUMBER(10) DEFAULT 0 NOT NULL,
       alertstarttime       NUMBER(10) NOT NULL,
       alertduration        NUMBER(10) NOT NULL,
       alertinterval        NUMBER(10) NOT NULL,
       alertreceiver        VARCHAR2(10) NULL,
       email                VARCHAR2(100) NULL,
       exename              VARCHAR2(100) NULL,
       alertsubject         VARCHAR2(100) NULL,
       alertmsg             VARCHAR2(255) NULL
)
/

CREATE UNIQUE INDEX xpkexcpt ON excpt
(
       procid,
       excptseq
)
/


ALTER TABLE excpt
       ADD ( PRIMARY KEY (procid, excptseq) )
/


CREATE TABLE witemapp (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       witemseq             NUMBER(10) DEFAULT 0 NOT NULL,
       witemappseq          NUMBER(10) DEFAULT 0 NOT NULL,
       state                CHAR(1) DEFAULT '?' NOT NULL,
       pkitype              CHAR(1) DEFAULT 'N' NOT NULL,
       procappseq           NUMBER(10) DEFAULT 0 NOT NULL,
       actappseq            NUMBER(10) DEFAULT 0 NOT NULL,
       actseq               NUMBER(10) DEFAULT 0 NOT NULL,
       mapid                NUMBER(10) DEFAULT 0 NOT NULL,
       appver               NUMBER(10) DEFAULT 1 NOT NULL,  
       appsvrid             VARCHAR2(10) NOT NULL,    
       appid                NUMBER(10) DEFAULT 0 NOT NULL,  
       prtcp                VARCHAR2(10) NULL,
       prtcpname            VARCHAR2(100) NULL,
       modifydtime          DATE NULL
) storage (initial 1m next 1m)
/

CREATE UNIQUE INDEX xpkwitemapp ON witemapp
(
       procid,
       witemseq,
       witemappseq
) storage (initial 100k next 100k)
/


ALTER TABLE witemapp
       ADD ( PRIMARY KEY (procid, witemseq, witemappseq) )
/


CREATE TABLE condtmplt (
       svrid                VARCHAR2(10) NOT NULL,
       condtmpltid          NUMBER(10) DEFAULT 0 NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       expr                 VARCHAR2(2000) NULL,
       dscpt                VARCHAR2(100) NULL
)
/

CREATE UNIQUE INDEX xpkcondtmplt ON condtmplt
(
       condtmpltid
)
/


ALTER TABLE condtmplt
       ADD ( PRIMARY KEY (condtmpltid) )
/


CREATE TABLE deadline (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       deadlineseq          NUMBER(10) DEFAULT 0 NOT NULL,
       deadlinetype         CHAR(1) DEFAULT '?' NOT NULL,
       resptype             CHAR(1) DEFAULT '?' NOT NULL,
       chkoutid             NUMBER(10) DEFAULT 0 NOT NULL,
       actseq               NUMBER(10) DEFAULT 0 NOT NULL,
       actappseq            NUMBER(10) DEFAULT 0 NOT NULL,
       witemseq             NUMBER(10) DEFAULT 0 NOT NULL,
       excptseq             NUMBER(10) DEFAULT 0 NOT NULL,
       deadline             NUMBER(10) DEFAULT 0 NOT NULL,
       incvalue             NUMBER(10) DEFAULT 0 NOT NULL,
       startdtime           DATE NOT NULL,
       enddtime             DATE NOT NULL,
       nextdtime            DATE NOT NULL,
       interval             NUMBER(10) NOT NULL,
       errno                NUMBER(10) DEFAULT 0 NOT NULL,
       calmemberid          VARCHAR2(10) NOT NULL,
       receiver             VARCHAR2(10) NULL,
       email                VARCHAR2(100) NULL,
       exename              VARCHAR2(100) NULL,
       subject              VARCHAR2(100) NULL,
       msg                  VARCHAR2(255) NULL
)
/

CREATE UNIQUE INDEX xpkdeadline ON deadline
(
       procid,
       deadlineseq
)
/

CREATE INDEX xie1deadline ON deadline
(
       nextdtime
)
/

CREATE INDEX xie2deadline ON deadline
(
       enddtime
)
/

CREATE INDEX xie3deadline ON deadline
(
       procid                         asc,
       actseq                         asc
)
/

ALTER TABLE deadline
       ADD ( PRIMARY KEY (procid, deadlineseq) )
/


CREATE TABLE queueerrlog (
       svrid                VARCHAR2(10) NOT NULL,
       execdtime            DATE NOT NULL,
       filename             VARCHAR2(255) NOT NULL,
       state                CHAR(1) DEFAULT '?' NOT NULL,
       usrid                VARCHAR2(10) NOT NULL,
       command              NUMBER(10) DEFAULT 0 NOT NULL,
       ipaddr               VARCHAR2(40) NOT NULL,
       procdefid            NUMBER(10) DEFAULT 0 NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       witemseq             NUMBER(10) DEFAULT 0 NOT NULL,
       errno                NUMBER(10) DEFAULT 0 NOT NULL,
       dscpt                VARCHAR2(100) NULL,
       detailinfo           VARCHAR2(255) NULL
)
/

CREATE UNIQUE INDEX xpkqueueerrlog ON queueerrlog
(
       execdtime,
       filename
)
/


ALTER TABLE queueerrlog
       ADD ( PRIMARY KEY (execdtime, filename) )
/


CREATE TABLE cmnt (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       cmntseq              NUMBER(10) DEFAULT 0 NOT NULL,
       parentcmntseq        NUMBER(10) DEFAULT 0 NOT NULL,
       type                 VARCHAR2(10) DEFAULT 'COMMENT' NOT NULL,
       gettype              CHAR(1) DEFAULT '?' NOT NULL,
       sendtype             CHAR(1) DEFAULT '?' NOT NULL,
       witemseq             NUMBER(10) DEFAULT 0 NOT NULL,
       actseq               NUMBER(10) DEFAULT 0 NOT NULL,
       actname              VARCHAR2(100) NULL,
       creationdtime        DATE NOT NULL,
       creator              VARCHAR2(10) NOT NULL,
       creatorname          VARCHAR2(100) NOT NULL,
       modifydtime          DATE NULL,
       jobtitleid           VARCHAR2(10) NULL,
       jobtitlename         VARCHAR2(100) NULL,
       deptid               VARCHAR2(10) NULL,
       deptname             VARCHAR2(100) NULL,
       contents             VARCHAR2(4000) NULL
)
/

CREATE UNIQUE INDEX xpkcmnt ON cmnt
(
       procid,
       cmntseq
)
/

CREATE INDEX xie1cmnt ON cmnt
(
       procid,
       witemseq,
       actseq
)
/

ALTER TABLE cmnt
       ADD ( PRIMARY KEY (procid, cmntseq) )
/


CREATE TABLE cal (
       svrid                VARCHAR2(10) NOT NULL,
       caldtime             DATE NOT NULL,
       daytype              CHAR(1) DEFAULT '?' NOT NULL,
       dayofweek            CHAR(1) DEFAULT '?' NOT NULL
)
/

CREATE UNIQUE INDEX xpkcal ON cal
(
       caldtime
)
/


ALTER TABLE cal
       ADD ( PRIMARY KEY (caldtime) )
/


CREATE TABLE procdeffileinfo (
       svrid                VARCHAR2(10) NOT NULL,
       procdefid            NUMBER(10) DEFAULT 0 NOT NULL,
       filesize             NUMBER(10) DEFAULT 0 NULL,
       filecnt              NUMBER(10) DEFAULT 0 NULL
)
/

CREATE UNIQUE INDEX xpkprocdeffileinfo ON procdeffileinfo
(
       procdefid
)
/


ALTER TABLE procdeffileinfo
       ADD ( PRIMARY KEY (procdefid) )
/

CREATE TABLE parentmember (
       memberid             VARCHAR2(10) NOT NULL,
       parentid             VARCHAR2(10) NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       dirty                CHAR(1) DEFAULT '?' NOT NULL,
       usrinherit           CHAR(1) DEFAULT '?' NOT NULL,
       mnginherit           CHAR(1) DEFAULT '?' NOT NULL,
       descorder            NUMBER(10) DEFAULT 0 NOT NULL,
       memberpath           VARCHAR2(500) NULL
)
/

CREATE UNIQUE INDEX xpkparentmember ON parentmember
(
       memberid,
       parentid
)
/

CREATE INDEX xie1parentmember ON parentmember
(
       parentid
)
/


ALTER TABLE parentmember
       ADD ( PRIMARY KEY (memberid, parentid) )
/


CREATE TABLE parentfldr (
       parentfldrid         NUMBER(10) DEFAULT 0 NOT NULL,
       fldrid               NUMBER(10) DEFAULT 0 NOT NULL,
       dirty                CHAR(1) DEFAULT '?' NOT NULL,
       usrinherit			CHAR(1) DEFAULT '?' NOT NULL,
       mnginherit			CHAR(1) DEFAULT '?' NOT NULL
)
/

CREATE UNIQUE INDEX xpkparentfldr ON parentfldr
(
       parentfldrid,
       fldrid
)
/

CREATE INDEX xie1parentfldr ON parentfldr
(
       fldrid
)
/


ALTER TABLE parentfldr
       ADD ( PRIMARY KEY (parentfldrid, fldrid) )
/
       
CREATE TABLE ver (
       ver                  VARCHAR2(100) NOT NULL,
       modifydtime          DATE DEFAULT sysdate NOT NULL,
       product              VARCHAR2(64) NULL,
       ipaddr               VARCHAR2(64) NULL,
       transactionid        VARCHAR2(64) NULL,
       status               VARCHAR2(64) NULL,
       description          VARCHAR2(100) NULL
)
/


CREATE TABLE cbdata (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       actseq               NUMBER(10) DEFAULT 0 NOT NULL,
       providerid           NUMBER(10) DEFAULT 0 NOT NULL,
       mapid                NUMBER(10) DEFAULT 0 NOT NULL,
       callbackid           VARCHAR2(100) NOT NULL
)
/

CREATE UNIQUE INDEX xpkcbdata ON cbdata
(
       procid,
       actseq
)
/

CREATE UNIQUE INDEX xak1cbdata ON cbdata
(
       callbackid,
       providerid
)
/

ALTER TABLE cbdata
       ADD ( PRIMARY KEY (procid, actseq) )
/

CREATE TABLE sign (
       svrid                VARCHAR2(10) NOT NULL,
       signid               NUMBER(10) DEFAULT 0 NOT NULL,
       memberid             VARCHAR2(10) NOT NULL,
       extname              VARCHAR2(30) NOT NULL,
       dscpt                VARCHAR2(100) NULL
)
/

CREATE UNIQUE INDEX xpksign ON sign
(
       signid
)
/


ALTER TABLE sign
       ADD ( PRIMARY KEY (signid) )
/


CREATE TABLE witemcnt (
	   memberid             VARCHAR2(10) NOT NULL,
	   state                CHAR(1) DEFAULT '?' NOT NULL,
	   urgent               CHAR(1) DEFAULT '?' NOT NULL,
	   prtcptype            CHAR(1) NOT NULL,
	   cnt                  NUMBER(10) DEFAULT 0 NOT NULL
)
/

CREATE UNIQUE INDEX xpkwitemcnt ON witemcnt
(
	   memberid,
	   state,
	   urgent
)
/

CREATE INDEX xie1witemcnt ON witemcnt
(
       memberid
)
/

ALTER TABLE witemcnt
	   ADD ( PRIMARY KEY (memberid, state, urgent) )
/

CREATE TABLE va_svr (
       svrid                VARCHAR2(10) NOT NULL,
       name                 VARCHAR2(100) NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       ssoflag              CHAR(1) DEFAULT '?' NOT NULL,
       sslflag              CHAR(1) DEFAULT '?' NOT NULL,
       anonymousflag        CHAR(1) DEFAULT '?' NOT NULL,
       connpoolcnt          NUMBER(10) DEFAULT 0 NOT NULL,
       svrport              NUMBER(10) DEFAULT 0 NOT NULL,
       svctype              VARCHAR2(10) NOT NULL,
       ipaddr               VARCHAR2(40) NULL,
       loginid              VARCHAR2(1500) NULL,
       passwd               VARCHAR2(150) NULL,
       guid                 VARCHAR2(100) NULL,
       dscpt                VARCHAR2(100) NULL,
       url                  VARCHAR2(255) NULL,
       userdnsuffix         VARCHAR2(255) NULL
)
/

CREATE UNIQUE INDEX xpkva_svr ON va_svr
(	
       svrid
)
/


ALTER TABLE va_svr
       ADD ( PRIMARY KEY (svrid) )
/


CREATE TABLE va_appmap (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       appinstid            NUMBER(10) DEFAULT 0 NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       mapid                NUMBER(10) DEFAULT 0 NOT NULL,
       internalid           NUMBER(10) DEFAULT 0 NOT NULL,
       lastappverseq        NUMBER(10) DEFAULT 0 NOT NULL,
       dmver                VARCHAR2(30) NOT NULL,
       dmsvrid              VARCHAR2(10) NOT NULL,
       dmdocid              VARCHAR2(500) NOT NULL,
       appsvrid             VARCHAR2(10) NULL,
       appid                NUMBER(10) DEFAULT 0 NULL
)
/

CREATE UNIQUE INDEX xpkva_appmap ON va_appmap
(
       procid,
       appinstid
)
/


ALTER TABLE va_appmap
       ADD ( PRIMARY KEY (procid, appinstid) )
/


CREATE TABLE va_appvermap (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       appinstid            NUMBER(10) DEFAULT 0 NOT NULL,
       appverseq            NUMBER(10) DEFAULT 0 NOT NULL,
       actseq               NUMBER(10) DEFAULT 0 NOT NULL,
       actappseq            NUMBER(10) DEFAULT 0 NOT NULL,
       mapid                NUMBER(10) DEFAULT 0 NOT NULL,
       dmver                VARCHAR2(30) NOT NULL,
       prtcp                VARCHAR2(10) NOT NULL,
       dmsvrid              VARCHAR2(10) NOT NULL,
       dmdocid              VARCHAR2(500) NOT NULL,
       modifydtime          DATE NULL,
       appsvrid             VARCHAR2(10) NULL,
       appid                NUMBER(10) DEFAULT 0 NULL,
       dmverlabel           VARCHAR2(20) NULL,
       prtcpname            VARCHAR2(100) NULL
)
/

CREATE UNIQUE INDEX xpkva_appvermap ON va_appvermap
(
       procid,
       appinstid,
       appverseq
)
/


ALTER TABLE va_appvermap
       ADD ( PRIMARY KEY (procid, appinstid, appverseq) )
/

CREATE TABLE va_verlink (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       appinstid            NUMBER(10) DEFAULT 0 NOT NULL,
       appverseqfrom        NUMBER(10) DEFAULT 0 NOT NULL,
       appverseqto          NUMBER(10) DEFAULT 0 NOT NULL
)
/

CREATE UNIQUE INDEX xpkva_verlink ON va_verlink
(
       procid,
       appinstid,
       appverseqfrom,
       appverseqto
)
/


ALTER TABLE va_verlink
       ADD ( PRIMARY KEY (procid, appinstid, appverseqfrom, 
              appverseqto) )
/


CREATE TABLE sso (
       memberid             VARCHAR2(10) NOT NULL,
       svcsvrid             VARCHAR2(10) NOT NULL,
       svctype              VARCHAR2(10) NOT NULL,
       loginid              VARCHAR2(100) NULL,
       logininfo            VARCHAR2(1000) NULL,
       ipaddr               VARCHAR2(40) NULL,
       regdtime             DATE NULL
)
/

CREATE UNIQUE INDEX xpksso ON sso
(
       memberid,
       svcsvrid,
       svctype 
)
/


ALTER TABLE sso
       ADD ( PRIMARY KEY (memberid, svcsvrid, svctype) )
/

CREATE TABLE orgmanagerlist (
       svrid                VARCHAR2(10) NOT NULL,
       memberid             VARCHAR2(10) NOT NULL,
       managerid            VARCHAR2(10) NOT NULL,
       auth                 NUMBER(10) DEFAULT 0 NOT NULL,
       disporder            NUMBER(10) DEFAULT 0 NOT NULL,
       name                 VARCHAR2(100) NOT NULL
)
/

CREATE UNIQUE INDEX xpkorgmanagerlist ON orgmanagerlist
(
       memberid,
       managerid
)
/


ALTER TABLE orgmanagerlist
       ADD ( PRIMARY KEY (memberid, managerid) )
/


CREATE TABLE fldrmanagerlist (
       svrid                VARCHAR2(10) NOT NULL,
       fldrid               NUMBER(10) DEFAULT 0 NOT NULL,
       managerid            VARCHAR2(10) NOT NULL,
       auth                 NUMBER(10) DEFAULT 0 NOT NULL,
       disporder            NUMBER(10) DEFAULT 0 NOT NULL,
       name                 VARCHAR2(100) NOT NULL
)
/

CREATE UNIQUE INDEX xpkfldrmanagerlist ON fldrmanagerlist
(
       fldrid,
       managerid
)
/

CREATE INDEX xie1fldrmanagerlist ON fldrmanagerlist
(
       managerid
)
/

ALTER TABLE fldrmanagerlist
       ADD ( PRIMARY KEY (fldrid, managerid) )
/

CREATE TABLE covelist (
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       id                   VARCHAR2(20) NOT NULL,
       ispublished          CHAR(1) DEFAULT 'F' NOT NULL,
       authmethod           CHAR(1) DEFAULT '?' NOT NULL,
       creationdtime        DATE NOT NULL,
       creator              VARCHAR2(10) NOT NULL,
       creatorname          VARCHAR2(100) NOT NULL,
       name                 VARCHAR2(100) NOT NULL,
       subclass             VARCHAR2(2) NULL,
       modifydtime          DATE NULL,
       modifier             VARCHAR2(10) NULL,
       modifiername         VARCHAR2(100) NULL,
       dscpt                VARCHAR2(255) NULL,
       etcinfo              VARCHAR2(1000) NULL,
       portletname          VARCHAR2(100) NULL,
       identitymap          VARCHAR2(255) NULL
)
/

CREATE UNIQUE INDEX xpkcovelist ON covelist
(
       type,
       id
)
/


ALTER TABLE covelist
       ADD ( PRIMARY KEY (type, id) )
/

CREATE TABLE hwtemp (
        tmpkey  VARCHAR2(50),
        vara    VARCHAR2(10),
        varb    VARCHAR2(10),
        varc    VARCHAR2(10),
        vard    VARCHAR2(10),
        vare    VARCHAR2(10)
)
/

CREATE INDEX xie1hwtemp on hwtemp
(
       tmpkey
)
/

CREATE TABLE witemti (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       witemseq             NUMBER(10) DEFAULT 0 NOT NULL,
       fromseq              NUMBER(10) DEFAULT 0 NOT NULL,
       state                CHAR(1) DEFAULT '?' NOT NULL,
       actseq               NUMBER(10) DEFAULT 0 NOT NULL,
	   dtime				DATE NULL
)storage(initial 1m next 1m)
/

CREATE UNIQUE INDEX xpkwitemti ON witemti
(
       procid,
       witemseq,
       fromseq                       
)storage(initial 100k next 100k)
/

CREATE INDEX xie1witemti ON witemti
(
       procid,
       fromseq                       
)storage(initial 100k next 100k)
/

ALTER TABLE witemti
       ADD  (PRIMARY KEY (procid, witemseq, fromseq))
/

create table calhead (
       memberid             varchar2(10) not null,
       dayofweek            CHAR(1) DEFAULT '?' NOT NULL,
       isdefault            CHAR(1) default '?' not null,
       daytype              CHAR(1) default '?' not null,
       tzsign               CHAR(1) DEFAULT '?' NOT NULL,
       tzid                 number default 0 not null,
       dstid                number default 0 not null,
       timediff             number default 0 not null,
       totdaywtime          number(10) default 0 not null,
       sworktime1           number(10) default 0 not null,
       eworktime1           number(10) default 0 not null,
       sworktime2           number(10) default 0 null,
       eworktime2           number(10) default 0 null,
       sworktime3           number(10) default 0 null,
       eworktime3           number(10) default 0 null,
       sworktime4           number(10) default 0 null,
       eworktime4           number(10) default 0 null,
       sworktime5           number(10) default 0 null,
       eworktime5           number(10) default 0 null,
       dscpt                VARCHAR2(100) NULL
)
/

create unique index xpkcalhead on calhead
(
       memberid,
       dayofweek                     
)
/

alter table calhead
       add  ( primary key (memberid, dayofweek) )
/


create table dst (
       dstid                number(10) default 0 not null,
       year                 number(10) default 0 not null,
       sign                 CHAR(1) not null,
       timediff             number(10) default 0 not null,
       startdtime           date not null,
       enddtime             date not null
)
/

create unique index xpkdst on dst
(
       dstid,
       year                          
)
/

alter table dst
       add  ( primary key (dstid, year) )
/

create table membercal (
       memberid             varchar2(10) not null,
       caldtime             date not null,
       isdefault            CHAR(1) default '?' not null,
       daytype              CHAR(1) default '?' not null,
       dayofweek            CHAR(1) default '?' not null,
       totdaywtime          number(10) default 0 not null,
       sworktime1           number(10) default 0 null,
       eworktime1           number(10) default 0 null,
       sworktime2           number(10) default 0 null,
       eworktime2           number(10) default 0 null,
       sworktime3           number(10) default 0 null,
       eworktime3           number(10) default 0 null,
       sworktime4           number(10) default 0 null,
       eworktime4           number(10) default 0 null,
       sworktime5           number(10) default 0 null,
       eworktime5           number(10) default 0 null,
       dscpt                VARCHAR2(100) NULL
)
/

create unique index xpkmembercal on membercal
(
       memberid,
       caldtime                      
)
/

alter table membercal
       add  ( primary key (memberid, caldtime) )
/

create table drlvntdataval (
       svrid                varchar2(10) not null,
       orgprocdefid         number(10) default 0 not null,
       rlvntdatadefname     varchar2(100) not null,
       valuetype            CHAR(1) default '?' not null,
       xreftype             CHAR(1) default '?' not null,
       xtypeid              number(10) default 0 not null,
       orgxtypeid           number(10) default 0 not null,
       fileid				number(10) default 0 not null,
       dispvalue            varchar2(100) null,
       dscpt                varchar2(100) null,
       value                nvarchar2(2000) null
)
/

create unique index xpkdrlvntdataval on drlvntdataval
(
       orgprocdefid,
       rlvntdatadefname              
)
/

alter table drlvntdataval
       add  ( primary key (orgprocdefid, rlvntdatadefname) )
/

create table grlvntdata (
       svrid                VARCHAR2(10) NOT NULL,
       grlvntdataid         NUMBER(10) DEFAULT 0 NOT NULL,
       valuetype            CHAR(1) DEFAULT '?' NOT NULL,
       xreftype             CHAR(1) DEFAULT '?' NOT NULL,
       xtypeid              NUMBER(10) DEFAULT 0 NOT NULL,
       orgxtypeid           NUMBER(10) DEFAULT 0 NOT NULL,
       fldrid               NUMBER(10) DEFAULT 0 NULL,
       name                 VARCHAR2(100) NOT NULL,
       creationdtime        DATE NOT NULL,
       creator              VARCHAR2(10) NOT NULL,
       creatorname          VARCHAR2(100) NOT NULL,
       creatordeptname      VARCHAR2(100) NULL,
       modifydtime          DATE NULL,
       modifier             VARCHAR2(10) NULL,
       modifiername         VARCHAR2(100) NULL,
       dispvalue            VARCHAR2(100) NULL,
       dscpt                VARCHAR2(100) NULL,
       value                NVARCHAR2(2000) NULL
)
/

create unique index xpkgrlvntdata on grlvntdata
(
       grlvntdataid                  
)
/

create unique index xak1grlvntdata on grlvntdata
(
       name                          
)
/

alter table grlvntdata
       add  ( primary key (grlvntdataid) )
/

create table grdauditinfo (
       svrid                varchar2(10) not null,
       grlvntdataid         number(10) default 0 not null,
       execseq              number(10) default 0 not null,
       procid               number(10) default 0 not null,
       name                 varchar2(100) not null,
       procname             varchar2(100) null,
       modifydtime          date null,
       modifier             varchar2(10) null,
       modifiername         varchar2(100) null,
       dispvalue            varchar2(100) null,
       dscpt                varchar2(100) null,
       value                nvarchar2(2000) null
)storage(initial 2m next 1m)
/

create unique index xpkgrdauditinfo on grdauditinfo
(
       grlvntdataid,
       execseq                       
)storage(initial 100k next 100k)
/

create unique index xak1grdauditinfo on grdauditinfo
(
       procid,
       execseq						 
)storage(initial 100k next 100k)
/

alter table grdauditinfo
       add  ( primary key (grlvntdataid, execseq) )
/

create table mdtmplt (
       svrid                VARCHAR2(10) NOT NULL,
       mdtmpltid            NUMBER(10) DEFAULT 0 NOT NULL,
       isfinal              CHAR(1) DEFAULT '?' NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       parentmdtmpltid      NUMBER(10) DEFAULT 0 NOT NULL,
       orgmdtmpltid         NUMBER(10) DEFAULT 0 NOT NULL,
       mdtmpltver           NUMBER(10) DEFAULT 1 NOT NULL,
       fldrid               NUMBER(10) DEFAULT 0 NOT NULL,
       name                 VARCHAR2(100) NOT NULL,
       dscpt                VARCHAR2(100) NULL,
       chkincmnt            VARCHAR2(500) NULL
)
/

create unique index xpkmdtmplt on mdtmplt
(
       mdtmpltid                     
)
/

create unique index xak1mdtmplt on mdtmplt
(
       orgmdtmpltid,
       mdtmpltver                    
)
/

alter table mdtmplt
       add  ( primary key (mdtmpltid) )
/

create table mditem (
       svrid                VARCHAR2(10) NOT NULL,
       mdtmpltid            NUMBER(10) DEFAULT 0 NOT NULL,
       mditemseq            NUMBER(10) DEFAULT 0 NOT NULL,
       objtype              CHAR(1) DEFAULT '?' NOT NULL,
       objsubtype           CHAR(1) DEFAULT '?' NOT NULL,
       valuetype            CHAR(1) DEFAULT '?' NOT NULL,
       mdinfo               NUMBER(10) DEFAULT 0 NOT NULL,
       name                 VARCHAR2(100) NOT NULL,
       value                VARCHAR2(255) NULL,
       dscpt                VARCHAR2(100) NULL
)
/

create unique index xpkmditem on mditem
(
       mdtmpltid,
       mditemseq                     
)
/

alter table mditem
       add  ( primary key (mdtmpltid, mditemseq) )
/

create table parentmdtmplt (
       svrid                VARCHAR2(10) NOT NULL,
       parentmdtmpltid      NUMBER(10) DEFAULT 0 NOT NULL,
       mdtmpltid            NUMBER(10) DEFAULT 0 NOT NULL,
       dirty                CHAR(1) DEFAULT '?' NOT NULL
)
/

create unique index xpkparentmdtmplt on parentmdtmplt
(
       parentmdtmpltid,
       mdtmpltid                     
)
/

alter table parentmdtmplt
       add  ( primary key (parentmdtmpltid, mdtmpltid) )
/

create table mdatadef (
       svrid                VARCHAR2(10) NOT NULL,
       procdefid            NUMBER(10) DEFAULT 0 NOT NULL,
       mdatadefseq          NUMBER(10) DEFAULT 0 NOT NULL,
       objtype              CHAR(1) DEFAULT '?' NOT NULL,
       objsubtype           CHAR(1) DEFAULT '?' NOT NULL,
       valuetype            CHAR(1) DEFAULT '?' NOT NULL,
       objseq               NUMBER(10) DEFAULT 0 NOT NULL,
       mdinfo               NUMBER(10) DEFAULT 0 NOT NULL,
       orgmdtmpltid         NUMBER(10) DEFAULT 0 NOT NULL,
       mditemseq            NUMBER(10) DEFAULT 0 NOT NULL,
       name                 VARCHAR2(100) NULL,
       dscpt                VARCHAR2(100) NULL,
       value                VARCHAR2(255) NULL
)
/

create unique index xpkmdatadef on mdatadef
(
       procdefid,
       mdatadefseq                   
)
/

alter table mdatadef
       add  ( primary key (procdefid, mdatadefseq) )
/

create table mdata (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       mdataseq             NUMBER(10) DEFAULT 0 NOT NULL,
       objtype              CHAR(1) DEFAULT '?' NOT NULL,
       objsubtype           CHAR(1) DEFAULT '?' NOT NULL,
       valuetype            CHAR(1) DEFAULT '?' NOT NULL,
       objseq               NUMBER(10) DEFAULT 0 NOT NULL,
       mdinfo               NUMBER(10) DEFAULT 0 NOT NULL,
       orgmdtmpltid         NUMBER(10) DEFAULT 0 NOT NULL,
       mditemseq            NUMBER(10) DEFAULT 0 NOT NULL,
       name                 VARCHAR2(100) NULL,
       dscpt                VARCHAR2(100) NULL,
       indexvalue           VARCHAR2(100) NULL,
       value                VARCHAR2(2000) NULL
)
/

create unique index xpkmdata on mdata
(
       procid,
       mdataseq                      
)
/

create index xie1mdata on mdata
(
       objtype,
       indexvalue                         
)
/

alter table mdata
       add  ( primary key (procid, mdataseq) )
/

create table publishfldr (
       svrid                VARCHAR2(10) NOT NULL,
       fldrid               NUMBER(10) DEFAULT 0 NOT NULL,
       publishfldrid        NUMBER(10) DEFAULT 0 NOT NULL
)
/

create unique index xpkpublishfldr on publishfldr
(
    fldrid,
	publishfldrid
)
/

alter table publishfldr
       add  ( primary key (fldrid, publishfldrid) )
/

create table enumdata (
       svrid                VARCHAR2(10) NOT NULL,
       mdtmpltid            NUMBER(10) DEFAULT 0 NOT NULL,
       mditemseq            NUMBER(10) DEFAULT 0 NOT NULL,
       enumdataseq          NUMBER(10) DEFAULT 0 NOT NULL,
       value                VARCHAR2(255) NULL
)
/

create unique index xpkenumdata on enumdata
(
       mdtmpltid,
       mditemseq,
       enumdataseq                   
)
/

alter table enumdata
       add  ( primary key (mdtmpltid, mditemseq, enumdataseq) )
/

create table ldapauditinfo (
       packageid            NUMBER(10) DEFAULT 0 NOT NULL,
       execseq              NUMBER(10) DEFAULT 0 NOT NULL,
       state                CHAR(1) DEFAULT '?' NULL,
       importer             VARCHAR2(10) NOT NULL,
       importdtime          DATE NOT NULL,
       importername         VARCHAR2(100) NOT NULL
)
/

create unique index xpkldapauditinfo on ldapauditinfo
(
       packageid,
       execseq                       
)
/

alter table ldapauditinfo
       add  ( primary key (packageid, execseq) )
/

create table actloopdef (
       svrid                VARCHAR2(10) NOT NULL,
       procdefid            NUMBER(10) DEFAULT 0 NOT NULL,
       actdefseq            NUMBER(10) DEFAULT 0 NOT NULL,
       testtime             CHAR(1) DEFAULT '?' NOT NULL,
       miordering           CHAR(1) DEFAULT '?' NOT NULL,
       miflowtype           CHAR(1) DEFAULT '?' NOT NULL,
       loopcnt              NUMBER(10) DEFAULT 0 NOT NULL,
       loopmaxcnt           NUMBER(10) DEFAULT 0 NOT NULL,
       conddefseq           NUMBER(10) DEFAULT 0 NOT NULL,
       miflowconddefseq     NUMBER(10) DEFAULT 0 NOT NULL
)
/

create unique index xpkactloopdef on actloopdef
(
       procdefid                      asc,
       actdefseq                      asc
)
/


alter table actloopdef
       add  ( primary key (procdefid, actdefseq) ) 
/

create table actloop (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       actseq               NUMBER(10) DEFAULT 0 NOT NULL,
       testtime             CHAR(1) DEFAULT '?' NOT NULL,
       miordering           CHAR(1) DEFAULT '?' NOT NULL,
       miflowtype           CHAR(1) DEFAULT '?' NOT NULL,
       loopcnt              NUMBER(10) DEFAULT 0 NOT NULL,
       loopmaxcnt           NUMBER(10) DEFAULT 0 NOT NULL,
       condseq              NUMBER(10) DEFAULT 0 NOT NULL,
       miflowcondseq        NUMBER(10) DEFAULT 0 NOT NULL
)
/

create unique index xpkactloop on actloop
(
       procid                         asc,
       actseq                         asc
)
/


alter table actloop
       add  ( primary key (procid, actseq) ) 
/


create table eventdef (
       svrid                VARCHAR2(10) NOT NULL,
       procdefid            NUMBER(10) DEFAULT 0 NOT NULL,
       actdefseq            NUMBER(10) DEFAULT 0 NOT NULL,
       eventdefseq          NUMBER(10) DEFAULT 0 NOT NULL,
       triggerpoint         CHAR(1) DEFAULT '?' NOT NULL,
       eventtype            CHAR(1) DEFAULT '?' NOT NULL,
       msgimpltype          CHAR(1) DEFAULT '?' NOT NULL,
       sendapp              CHAR(1) DEFAULT 'F' NOT NULL,
       sendattach           CHAR(1) DEFAULT 'F' NOT NULL,
       sendcmnt             CHAR(1) DEFAULT 'F' NOT NULL,
       timertype            CHAR(1) DEFAULT '?' NOT NULL,
       tonode               NUMBER(10) DEFAULT 0 NULL,
       transdefseq          NUMBER(10) DEFAULT 0 NULL,
       startactdefseq       NUMBER(10) DEFAULT 0 NULL,
       timertime            NUMBER(10) DEFAULT 0 NULL,
       rlvntdatadefseq      NUMBER(10) DEFAULT 0 NULL,
       subsvrid             VARCHAR2(10) NULL,
       subprocdefid         NUMBER(10) DEFAULT 0 NULL,
       suborgprocdefid      NUMBER(10) DEFAULT 0 NULL,
       dscpt                VARCHAR2(100) NULL,
       linkid               VARCHAR2(20) NULL,
       eraid                VARCHAR2(20) NULL
)
/

create unique index xpkeventdef on eventdef
(
       procdefid                      asc,
	   actdefseq                      asc,
       eventdefseq                    asc
)
/


alter table eventdef
       add  ( primary key (procdefid, actdefseq, eventdefseq) )
/


create table event (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       actseq               NUMBER(10) DEFAULT 0 NOT NULL,
       eventseq             NUMBER(10) DEFAULT 0 NOT NULL,
       triggerpoint         CHAR(1) DEFAULT '?' NOT NULL,
       eventtype            CHAR(1) DEFAULT '?' NULL,
       msgimpltype          CHAR(1) DEFAULT '?' NULL,
       sendapp              CHAR(1) DEFAULT 'F' NOT NULL,
       sendattach           CHAR(1) DEFAULT 'F' NOT NULL,
       sendcmnt             CHAR(1) DEFAULT 'F' NOT NULL,
       timertype            CHAR(1) DEFAULT '?' NOT NULL,
       tonode               NUMBER(10) DEFAULT 0 NULL,
       transseq             NUMBER(10) DEFAULT 0 NULL,
       startactseq          NUMBER(10) DEFAULT 0 NULL,
       timertime            NUMBER(10) DEFAULT 0 NULL,
       rlvntdataseq         NUMBER(10) DEFAULT 0 NULL,
       subsvrid             VARCHAR2(10) NULL,
       subprocdefid         NUMBER(10) DEFAULT 0 NULL,
       suborgprocdefid      NUMBER(10) DEFAULT 0 NULL,
       dscpt                VARCHAR2(100) NULL,
       linkid               VARCHAR2(255) NULL,
       eraid                VARCHAR2(20) NULL
)
/

create unique index xpkevent on event
(
       procid                         asc,
       actseq                         asc,
       eventseq                       asc
)
/


alter table event
       add  ( primary key (procid, actseq, eventseq) )
/

create  table queueprocs
(
        qid					VARCHAR2(10) not null,
        queueseq			NUMBER(10) not null,
        urgent				CHAR(1) DEFAULT '?' NOT NULL,
        passwdflag			CHAR(1) DEFAULT '?' NOT NULL,
        parentacttype		CHAR(1) DEFAULT '?' NOT NULL,
        qstate				CHAR(1) DEFAULT '?' NOT NULL,
        orgprocdefid		NUMBER(10) DEFAULT 0 NULL,
        parentprocid		NUMBER(10) DEFAULT 0 NULL,
        parentactseq		NUMBER(10) DEFAULT 0 NULL,
        instfldrid			NUMBER(10) DEFAULT 0 NULL,
        archivefldrid		NUMBER(10) DEFAULT 0 NULL,
        sendwitemtoclient	NUMBER(10) DEFAULT 0 NULL,
        qattachcnt			NUMBER(10) DEFAULT 0 NULL,
        qrlvntdatafilecnt	NUMBER(10) DEFAULT 0 NULL,
        errno				NUMBER(10) DEFAULT 0 NULL,
        creationdtime		DATE not null,
        orgsvrid			VARCHAR2(10) null,
        clientip			VARCHAR2(40) null,
        userid				VARCHAR2(10) null,
        svrid				VARCHAR2(10) null,
        defsvrid			VARCHAR2(10) null,
        parentsvrid			VARCHAR2(10) null,
        creator				VARCHAR2(10) null,
        sessioninfo			VARCHAR2(100) null,
        name				VARCHAR2(100) null,
        dscpt				VARCHAR2(255) null,
        customid			VARCHAR2(255) null,
        qattach				VARCHAR2(512) null,
        qrlvntdatafile		VARCHAR2(512) null,
        errmsg				VARCHAR2(512) null
)
/
        
CREATE UNIQUE INDEX xpkqueueprocs ON queueprocs
(
        qid,
        queueseq
)
/

create  table queuewitem
(
        qid					VARCHAR2(10) not null,
        queueseq			NUMBER(10) not null,
        qstate				CHAR(1) DEFAULT '?' NOT NULL,
        procid				NUMBER(10) DEFAULT 0 NULL,
        actseq				NUMBER(10) DEFAULT 0 NULL,
        witemseq			NUMBER(10) DEFAULT 0 NULL,
        response			NUMBER(10) DEFAULT 0 NULL,
        cmpltmode			NUMBER(10) DEFAULT 0 NULL,
        witemappfilecnt		NUMBER(10) DEFAULT 0 NULL,
        attachfilecnt		NUMBER(10) DEFAULT 0 NULL,
        execsqllen			NUMBER(10) DEFAULT 0 NULL,
        wfilenamecnt		NUMBER(10) DEFAULT 0 NULL,
        errno				NUMBER(10) DEFAULT 0 NULL,
        creationdtime		DATE not null,
        clientip			VARCHAR2(40) null,
        userid				VARCHAR2(10) null,
        svrid				VARCHAR2(10) null,
        sessioninfo			VARCHAR2(100) null,
        witemappfile		VARCHAR2(256) null,
        attachfile			VARCHAR2(256) null,
        subprocfile			VARCHAR2(256) null,
        repsignfile			VARCHAR2(256) null,
        rscmntfile			VARCHAR2(256) null,
        wfilename			VARCHAR2(256) null,
        execsql				VARCHAR2(512) null,
        errmsg				VARCHAR2(512) null
)
/

CREATE UNIQUE INDEX xpkqueuewitem ON queuewitem
(
       qid,
       queueseq
)
/

CREATE TABLE cpdef (
       svrid                VARCHAR2(10) NOT NULL,
       procdefid            NUMBER(10) DEFAULT 0 NOT NULL,
       cpdefseq             NUMBER(10) DEFAULT 0 NOT NULL,
       value                VARCHAR2(2000) NOT NULL
)
/

CREATE UNIQUE INDEX xpkcpdef ON cpdef
(
       procdefid,
       cpdefseq
)
/

ALTER TABLE cpdef
       ADD ( PRIMARY KEY (procdefid, cpdefseq) )
/


CREATE TABLE cp (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       cpseq                NUMBER(10) DEFAULT 0 NOT NULL,
       value                VARCHAR2(2000) NOT NULL,
       day                  NUMBER(10) DEFAULT 0 NULL,       
       create_dt            DATE DEFAULT sysdate NULL
)
/

CREATE UNIQUE INDEX xpkcp ON cp
(
       procid,
       cpseq
)
/

ALTER TABLE cp
       ADD ( PRIMARY KEY (procid, cpseq) )
/

CREATE TABLE tabdef (
       svrid                VARCHAR2(10) NOT NULL,
       tabdefid             NUMBER(10) DEFAULT 0 NOT NULL,
       method               CHAR(1) DEFAULT '?' NOT NULL,
       name                 VARCHAR2(100) NOT NULL,
       dscpt                VARCHAR2(255) NULL,
       url                  VARCHAR2(500) NULL
)
/

CREATE UNIQUE INDEX xpktabdef ON tabdef
(
       tabdefid
)
/

ALTER TABLE tabdef
       ADD ( PRIMARY KEY (tabdefid) )
/

CREATE TABLE tabparamdef (
       svrid                VARCHAR2(10) NOT NULL,
       tabdefid             NUMBER(10) DEFAULT 0 NOT NULL,
       paramseq             NUMBER(10) DEFAULT 0 NOT NULL,
       name                 VARCHAR2(100) NOT NULL,
       value                VARCHAR2(100) NULL,
       dscpt                VARCHAR2(255) NULL
)
/

CREATE UNIQUE INDEX xpktabparamdef ON tabparamdef
(
       tabdefid,
	   paramseq
)
/

ALTER TABLE tabparamdef
       ADD ( PRIMARY KEY (tabdefid, paramseq) )
/

CREATE TABLE proctabdef (
       svrid                VARCHAR2(10) NOT NULL,
       orgprocdefid         NUMBER(10) DEFAULT 0 NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       tabdefid             NUMBER(10) DEFAULT 0 NOT NULL,
       disporder            NUMBER(10) DEFAULT 0 NOT NULL,
       show                 CHAR(1) DEFAULT '?' NOT NULL
)
/

CREATE UNIQUE INDEX xpkproctabdef ON proctabdef
(
       orgprocdefid,
	   type,
	   tabdefid
)
/

ALTER TABLE proctabdef
       ADD ( PRIMARY KEY (orgprocdefid, type, tabdefid) )
/

CREATE TABLE installstatus (
       ver                  VARCHAR2(50) NOT NULL,
       vara					VARCHAR2(50) NULL,
       modifydtime          DATE DEFAULT sysdate NOT NULL
)
/

CREATE UNIQUE INDEX xpkinstallstatus ON installstatus
(
	   ver
)
/

ALTER TABLE installstatus
       ADD ( PRIMARY KEY (ver) )
/

CREATE TABLE account (
       id                   NUMBER(10) NOT NULL,
       name                 VARCHAR2(100) NOT NULL,
       state                VARCHAR2(2) NOT NULL,
       phone                VARCHAR2(20) NOT NULL,
       account_number       VARCHAR2(50) NOT NULL,
       dob                  DATE NULL
)
/

CREATE UNIQUE INDEX xpkaccount ON account
(
       id
)
/

CREATE INDEX xie1account ON account
(
       name
)
/

ALTER TABLE account
       ADD ( PRIMARY KEY (id) )
/

CREATE TABLE states (
       state                VARCHAR2(2) NOT NULL
)
/

CREATE UNIQUE INDEX xpkstates ON states
(
       state
)
/

ALTER TABLE states
       ADD ( PRIMARY KEY (state) )
/

CREATE TABLE preference (
       memberid             VARCHAR2(10) NOT NULL,
       section              VARCHAR2(50) NOT NULL,
       param                VARCHAR2(50) NOT NULL,
       value                VARCHAR2(200) NULL,
       ressection           VARCHAR2(50) NULL,
       resid                VARCHAR2(50) NULL
)
/

CREATE UNIQUE INDEX xpkpreference ON preference
(
       memberid,
       section,
       param
)
/

ALTER TABLE preference
       ADD ( PRIMARY KEY (memberid, section, param) )
/

CREATE TABLE device (  
       memberid             VARCHAR2(10) NOT NULL,
       deviceuuid           VARCHAR2(50) NOT NULL,
       devicename           VARCHAR2(100) NOT NULL,
       devicecert           VARCHAR2(1000) NOT NULL,
       devicephonegap       VARCHAR2(50)  NULL,
       deviceplatform       VARCHAR2(50) NULL,
       deviceversion        VARCHAR2(10) NULL,
       registerkey          VARCHAR2(50) NOT NULL,
       registerdate         DATE DEFAULT sysdate NOT NULL,
       state                CHAR(1) DEFAULT 'A' NOT NULL
)
/

CREATE UNIQUE INDEX xpkdevice ON device
(
       memberid,
       deviceuuid
)
/

ALTER TABLE device
       ADD ( PRIMARY KEY (memberid, deviceuuid) )
/

CREATE TABLE map_app2wsa (
       svr_id               VARCHAR2(10) NOT NULL,
       app_id               INT NOT NULL,
       wsdl_desc            VARCHAR2(1024) NULL,
       wsdl_url             VARCHAR2(1024) NOT NULL,
       service              VARCHAR2(100) NOT NULL,
       port                 VARCHAR2(100) NOT NULL,
       operation            VARCHAR2(100) NOT NULL,
       soap_endpoint        VARCHAR2(1024),
       username             VARCHAR2(100),
       password             VARCHAR2(150)
)
/

CREATE UNIQUE INDEX xpkmap_app2wsa ON map_app2wsa
(
       svr_id,
       app_id
)
/

ALTER TABLE map_app2wsa
       ADD ( PRIMARY KEY (svr_id, app_id) )
/

CREATE TABLE reqlist (
       memberid             VARCHAR2(10) NOT NULL,
       reqtype              VARCHAR2(10) NOT NULL,
       reqsubtype           VARCHAR2(10) DEFAULT 'NONE' NOT NULL,
       ipaddr               VARCHAR2(40) DEFAULT '127.000.000.001' NOT NULL,
       reqkey               VARCHAR2(100) NULL,
       reqinfo              VARCHAR2(4000) NOT NULL,
       reqdtime             DATE DEFAULT sysdate NOT NULL
)
/

CREATE UNIQUE INDEX xpkreqlist ON reqlist
(
       memberid,
       reqtype
)
/

ALTER TABLE reqlist
       ADD ( PRIMARY KEY (memberid, reqtype, reqsubtype) )
/

CREATE INDEX xie1reqlist ON reqlist
(
       reqdtime
)
/

CREATE TABLE password (  
       memberid             VARCHAR2(10) NOT NULL,
	   seq                  NUMBER(10) DEFAULT 0 NOT NULL,
	   passwd               VARCHAR2(150) NOT NULL,
       lastuseddtime        DATE DEFAULT sysdate NOT NULL
)
/

CREATE UNIQUE INDEX xpkpassword ON password
(
       memberid,
       seq
)
/

ALTER TABLE password
       ADD ( PRIMARY KEY (memberid, seq) )
/

CREATE TABLE configuration (  
       section              VARCHAR2(100) NOT NULL,
	   entry                VARCHAR2(100) NOT NULL,
	   value                VARCHAR2(2000) NULL,
       description          VARCHAR2(2000) NULL
)
/

CREATE UNIQUE INDEX xpkconfiguration ON configuration
(
       section,
       entry
)
/

ALTER TABLE configuration
       ADD ( PRIMARY KEY (section, entry) )
/

CREATE TABLE templatefile (
       svrid                VARCHAR2(10) NOT NULL,
       tmpltid              NUMBER(10) DEFAULT 0 NOT NULL,
       mediatype            NVARCHAR2(100) NOT NULL,
       code                 NVARCHAR2(100) NOT NULL,
       name                 NVARCHAR2(256) NOT NULL,
       filename             NVARCHAR2(256) NOT NULL,
       creator              VARCHAR2(10) NOT NULL,
       creatorname          VARCHAR2(100) NULL,
       creationdtime        DATE NULL,
       modifier             VARCHAR2(10) NULL,
       modifiername         VARCHAR2(100) NULL,
       modifydtime          DATE NULL,
       dscpt                NVARCHAR2(100) NULL,
       content              BLOB NULL
)
/

CREATE UNIQUE INDEX xpktemplatefile ON templatefile
(
       tmpltid
)
/

create index xie1templatefile on templatefile
(
       name
)
/

ALTER TABLE templatefile
       ADD ( PRIMARY KEY (tmpltid) )
/

CREATE TABLE templatefiletag (
       tmpltid              NUMBER(10) DEFAULT 0 NOT NULL,
       tagseq               NUMBER(10) DEFAULT 0 NOT NULL,
       tag                  NVARCHAR2(100) NOT NULL
)
/

CREATE UNIQUE INDEX xpktemplatefiletag ON templatefiletag
(
       tmpltid, tagseq
)
/

create index xie1templatefiletag on templatefiletag
(
       tag
)
/

ALTER TABLE templatefiletag
       ADD ( PRIMARY KEY (tmpltid, tagseq) )
/

CREATE TABLE procslink (
       svrid                VARCHAR2(10) NOT NULL,
       procid               NUMBER(10) DEFAULT 0 NOT NULL,
       linkedprocid         NUMBER(10) DEFAULT 0 NOT NULL,
       creationdtime        DATE NOT NULL,
       creator              VARCHAR2(10) NOT NULL,
       creatorname          VARCHAR2(100) NOT NULL
)
/
CREATE UNIQUE INDEX xpkprocslink ON procslink
(
       procid,
       linkedprocid
)
/

CREATE INDEX xie1procslink ON procslink
(
       linkedprocid
)
/

ALTER TABLE procslink
       ADD ( PRIMARY KEY (procid, linkedprocid) )
/


@@sequence.sql

insert into ver(ver) values ('12.4.0.0000.00')
/

--spool off
exit
