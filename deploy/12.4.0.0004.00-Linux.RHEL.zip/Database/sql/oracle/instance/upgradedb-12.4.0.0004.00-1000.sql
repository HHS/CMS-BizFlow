SET SERVEROUTPUT ON SIZE 1000000;

DECLARE I_COUNT NUMBER;
		I_LENGTH NUMBER;
		I_SVRID VARCHAR2(10);
BEGIN

DBMS_OUTPUT.PUT_LINE('upgradedb-12.4.0.0004.00-1000.sql(8): usrgrpprtcp: Checking index xie2usrgrpprtcp');
SELECT COUNT(1) INTO I_COUNT FROM USER_OBJECTS WHERE UPPER(OBJECT_NAME) = 'XIE2USRGRPPRTCP';
IF I_COUNT > 0 THEN
	DBMS_OUTPUT.PUT_LINE('upgradedb-12.4.0.0004.00-1000.sql(11): usrgrpprtcp: Dropping index xie2usrgrpprtcp');
	EXECUTE IMMEDIATE '
	    DROP INDEX xie2usrgrpprtcp
	';
END IF;

DBMS_OUTPUT.PUT_LINE('upgradedb-12.4.0.0004.00-1000.sql(17): usrgrpprtcp: Creating index xie2usrgrpprtcp');
EXECUTE IMMEDIATE '
    CREATE INDEX xie2usrgrpprtcp ON usrgrpprtcp (prtcptype)
';

COMMIT;

END;
/