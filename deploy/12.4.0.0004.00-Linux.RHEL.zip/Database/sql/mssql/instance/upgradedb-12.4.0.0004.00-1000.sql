DECLARE @I_LENGTH INT
DECLARE @I_SVRID VARCHAR(10)
BEGIN

PRINT 'upgradedb-12.4.0.0004.00-1000.sql(5): usrgrpprtcp: Checking index xie2usrgrpprtcp'
IF EXISTS (SELECT 1 FROM dbo.sysindexes WHERE id = OBJECT_ID(N'usrgrpprtcp') AND name = N'xie2usrgrpprtcp')
BEGIN
	PRINT 'upgradedb-12.4.0.0004.00-1000.sql(8): usrgrpprtcp: Dropping index xie2usrgrpprtcp'
	DROP INDEX xie2usrgrpprtcp ON usrgrpprtcp
END

PRINT 'upgradedb-12.4.0.0004.00-1000.sql(12): usrgrpprtcp: Creating index xie2usrgrpprtcp'
CREATE INDEX xie2usrgrpprtcp ON usrgrpprtcp (prtcptype)

END
