-- 12.4.0.0

CREATE TABLE dmn (
       dmnid                VARCHAR(7) NOT NULL,
       name                 VARCHAR(100) NOT NULL,
       internetdmn          VARCHAR(100) NOT NULL
)
GO

ALTER TABLE dmn
ADD CONSTRAINT xpkdmn PRIMARY KEY CLUSTERED (dmnid)
GO


CREATE TABLE svr (
       svrid                VARCHAR(10) NOT NULL,
       type                 CHAR(1) NOT NULL DEFAULT '?',
       state                CHAR(1) NOT NULL DEFAULT '?',
       dmnid                VARCHAR(7) NOT NULL,
       name                 VARCHAR(100) NOT NULL,
       ipaddr               VARCHAR(40) NOT NULL DEFAULT '127.000.000.001',
       svrport              INT NOT NULL DEFAULT 0,
       iscport              INT NOT NULL DEFAULT 0,
       uniquesvrid          VARCHAR(10) NULL,
       loginid              VARCHAR(100) NULL,
       passwd               VARCHAR(150) NULL,
       uri                  VARCHAR(255) NULL
)
GO

ALTER TABLE svr
ADD CONSTRAINT xpksvr PRIMARY KEY CLUSTERED (svrid)
GO


CREATE TABLE cal (
       svrid                VARCHAR(10) NOT NULL,
       caldtime             DATETIME NOT NULL,
       dayofweek            CHAR(1) DEFAULT '?' NOT NULL
)
GO

ALTER TABLE cal
ADD CONSTRAINT xpkcal PRIMARY KEY CLUSTERED (caldtime)
GO


CREATE TABLE fldrlist (
       svrid                VARCHAR(10) NOT NULL,
       fldrid               INT NOT NULL DEFAULT 0,
       type                 CHAR(1) NOT NULL DEFAULT '?',
       ispublic             CHAR(1) NOT NULL DEFAULT '?',
       inherittype          CHAR(1) NOT NULL DEFAULT '?',
       parentfldrid         INT NOT NULL DEFAULT 0,
       disporder            INT NOT NULL DEFAULT 0,
       prjid                INT NOT NULL DEFAULT 0,
       ver                  INT NOT NULL DEFAULT 1,
       name                 VARCHAR(100) NOT NULL,
       creatorid            VARCHAR(10) NOT NULL,
       creationdtime        DATETIME NULL,
       creatorname          VARCHAR(100) NULL,
       dscpt                VARCHAR(255) NULL,
       fldrpath             VARCHAR(500) NULL
)
GO

ALTER TABLE fldrlist
ADD CONSTRAINT xpkfldrlist PRIMARY KEY CLUSTERED (fldrid)
GO

CREATE INDEX xie1fldrlist ON fldrlist (prjid)
GO

CREATE INDEX xie2fldrlist ON fldrlist (parentfldrid)
GO

CREATE INDEX xie3fldrlist ON fldrlist (type)
GO

CREATE TABLE procdef (
       svrid                VARCHAR(10) NOT NULL,
       procdefid            INT NOT NULL DEFAULT 0,
       verctrltype          CHAR(1) NOT NULL DEFAULT '?',
       isfinal              CHAR(1) DEFAULT '?' NOT NULL,
       envtype              CHAR(1) NOT NULL DEFAULT '?',
       deadlinetype         CHAR(1) NOT NULL DEFAULT '?',
       subproctype          CHAR(1) NOT NULL DEFAULT '?',
       passwdflag           CHAR(1) NOT NULL DEFAULT '?',
       publicationstate     CHAR(1) NOT NULL DEFAULT '?',
       pkitype              CHAR(1) NOT NULL DEFAULT 'N',
       caltype              CHAR(1) DEFAULT 'B' NOT NULL,
       dmsaveflag           CHAR(1) DEFAULT '?' NOT NULL,
       dmidtype             CHAR(1) DEFAULT '?' NOT NULL,
       customtab            CHAR(1) CONSTRAINT DF__procdef__customtab DEFAULT 'F' NOT NULL,
       fldrsvrid            VARCHAR(10) NOT NULL,
       fldrid               INT NOT NULL DEFAULT 0,
       prjfldrid            int DEFAULT 0 NULL,
       orgprocdefid         int DEFAULT 0 NOT NULL,
       ver                  int DEFAULT 1 NOT NULL,
       procauth             INT NOT NULL DEFAULT 0,
       instfldrid           INT NOT NULL DEFAULT 0,
       archivefldrid        INT NOT NULL DEFAULT 0,
       orgmdtmpltid         int DEFAULT 0 NOT NULL,
       name                 VARCHAR(100) NOT NULL,
       deadline             INT NOT NULL DEFAULT 0,
       creationdtime        DATETIME NOT NULL,
       creator              VARCHAR(10) NOT NULL,
       creatorname          VARCHAR(100) NOT NULL,
       creatordeptname      VARCHAR(100) NULL,
       usrgrphid            varchar(10) NULL,
       calmemberid          varchar(10) NULL,
       presvrid             VARCHAR(10) NULL,
       preprocdefid         INT NULL DEFAULT 0,
       checkoutusr          VARCHAR(10) NULL,
       modifydtime          DATETIME NULL,
       modifier             VARCHAR(10) NULL,
       modifiername         VARCHAR(100) NULL,
       dmsvrid              VARCHAR(10) NULL,
       publishdtime         datetime NULL,
       publisher            varchar(10) NULL,
       publishername        varchar(100) NULL,
       dmfldrid             VARCHAR(500) NULL,
       dscpt                VARCHAR(255) NULL,
       chkincmnt            varchar(500) NULL
)
GO

ALTER TABLE procdef
ADD CONSTRAINT xpkprocdef PRIMARY KEY CLUSTERED (procdefid)
GO

CREATE INDEX xie1procdef ON procdef (fldrid, creationdtime)
GO
CREATE INDEX xie2procdef ON procdef (prjfldrid, creationdtime)
GO
CREATE INDEX xie3procdef ON procdef (orgprocdefid, ver)
GO
CREATE INDEX xie4procdef ON procdef (checkoutusr)
GO


CREATE TABLE procdeffileinfo (
       svrid                VARCHAR(10) NOT NULL,
       procdefid            INT NOT NULL DEFAULT 0,
       filesize             INT NULL DEFAULT 0,
       filecnt              INT NULL DEFAULT 0
)
GO

ALTER TABLE procdeffileinfo
ADD CONSTRAINT xpkprocdeffileinfo PRIMARY KEY CLUSTERED (procdefid)
GO

CREATE TABLE procs (
       svrid                VARCHAR(10) NOT NULL,
       procid               INT NOT NULL DEFAULT 0,
       urgent               CHAR(1) NOT NULL DEFAULT '?',
       deadlinetype         CHAR(1) NOT NULL DEFAULT '?',
       subproctype          CHAR(1) NOT NULL DEFAULT '?',
       passwdflag           CHAR(1) NOT NULL DEFAULT '?',
       state                CHAR(1) NOT NULL DEFAULT '?',
       dmsaveflag           CHAR(1) NOT NULL DEFAULT '?',
       dmidtype             CHAR(1) NOT NULL DEFAULT '?',
       caltype              CHAR(1) DEFAULT 'B' NOT NULL,
	   internalid           INT NOT NULL DEFAULT 100,
       cmntcnt              INT NOT NULL DEFAULT 0,
       attachcnt            INT NOT NULL DEFAULT 0,
       orgprocdefid         int DEFAULT 0 NOT NULL,
       revisionid           int DEFAULT 0 NOT NULL,
       instfldrid           INT NOT NULL DEFAULT 0,
       ver                  INT NOT NULL DEFAULT 1,
       archivefldrid        INT NOT NULL DEFAULT 0,
       name                 VARCHAR(100) NOT NULL,
       creationdtime        DATETIME NOT NULL,
       creator              VARCHAR(10) NOT NULL,
       creatorname          VARCHAR(100) NOT NULL,
       deadline             INT NOT NULL DEFAULT 0,
       presvrid             VARCHAR(10) NOT NULL,
       preprocdefid         INT NOT NULL DEFAULT 0,
       preprocdefname       VARCHAR(100) NOT NULL,
       usrgrphid            varchar(10) NULL,
       calmemberid          varchar(10) NULL,
       customid             VARCHAR(255) NULL,
       cmpltdtime           DATETIME NULL,
       deadlinedtime        DATETIME NULL,
       returnsvrid          VARCHAR(10) NULL,
       parentsvrid          VARCHAR(10) NULL,
       parentprocid         INT NULL DEFAULT 0,
       parentactseq         INT NULL DEFAULT 0,
       parentacttype        CHAR(1) NULL DEFAULT '?',
       checkoutusr          VARCHAR(10) NULL,
       modifydtime          DATETIME NULL,
       modifier             VARCHAR(10) NULL,
       modifiername         VARCHAR(100) NULL,
       lastcorrespondence   VARCHAR(100) NULL,
       dmsvrid              VARCHAR(10) NULL,
       dmfldrid             VARCHAR(500) NULL,
       dscpt                VARCHAR(255) NULL
)
GO

ALTER TABLE procs
ADD CONSTRAINT xpkprocs PRIMARY KEY CLUSTERED (procid)
GO
CREATE INDEX xak1procs ON procs ( customid )
GO
CREATE INDEX xie1procs ON procs ( deadlinedtime, state )
GO
CREATE INDEX xie2procs ON procs ( instfldrid, creationdtime )
GO
CREATE INDEX xie3procs ON procs ( archivefldrid, cmpltdtime )
GO
CREATE INDEX xie4procs ON procs ( preprocdefid )
GO
CREATE INDEX xie5procs ON procs ( cmpltdtime )
GO
CREATE INDEX xie6procs ON procs ( parentprocid, parentactseq )
GO
CREATE INDEX xie7procs ON procs ( creator, state )
GO
CREATE INDEX xie8procs ON procs ( revisionid )
GO
CREATE INDEX xie9procs ON procs ( orgprocdefid )
GO
CREATE INDEX xie10procs ON procs ( checkoutusr )
GO

CREATE TABLE actdef (       
       svrid                VARCHAR(10) NOT NULL,
       procdefid            int DEFAULT 0 NOT NULL,
       actdefseq            int DEFAULT 0 NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       jointype             CHAR(1) DEFAULT '?' NOT NULL,
       casetype             CHAR(1) DEFAULT '?' NOT NULL,
       deadlinetype         CHAR(1) DEFAULT '?' NOT NULL,
       transtype            CHAR(1) DEFAULT '?' NOT NULL,
       caltype              CHAR(1) DEFAULT 'U' NOT NULL,
       existinfofile        CHAR(1) DEFAULT 'F' NOT NULL,
       existcmntrans        CHAR(1) DEFAULT 'F' NOT NULL,
       isrepsign            CHAR(1) DEFAULT 'F' NOT NULL,
       subproctype          CHAR(1) DEFAULT '?' NOT NULL,
       sendapp              CHAR(1) DEFAULT 'F' NOT NULL,
       sendattach           CHAR(1) DEFAULT 'F' NOT NULL,
       sendcmnt             CHAR(1) DEFAULT 'F' NOT NULL,
       checkpostcond        CHAR(1) DEFAULT 'F' NOT NULL,
       cmpltopt             CHAR(1) DEFAULT '?' NOT NULL,
       rbackopt             CHAR(1) DEFAULT '?' NOT NULL,
       subenvtype           CHAR(1) DEFAULT '?' NOT NULL,
       eventtype            CHAR(1) DEFAULT '?' NOT NULL,
       actlooptype          CHAR(1) DEFAULT '?' NOT NULL,
       attaddcnt            int DEFAULT 0 NOT NULL,
       name                 VARCHAR(100) NOT NULL,
       priority             int DEFAULT 0 NOT NULL,
       actauth              int DEFAULT 0 NOT NULL,
       actinfo              int DEFAULT 0 NOT NULL,
       deadline             int DEFAULT 0 NOT NULL,
       respgrpseq           int DEFAULT 0 NOT NULL,
       respseq              int DEFAULT 0 NOT NULL,
       capacity             int DEFAULT 0 NOT NULL,
       cost                 int DEFAULT 0 NOT NULL,
       providerid           int DEFAULT 0 NOT NULL,
       subsvrid             VARCHAR(10) NULL,
       subprocdefid         int DEFAULT 0 NULL,
       suborgprocdefid      int DEFAULT 0 NULL,
       postconddefseq       int DEFAULT 0 NULL,
       mergeconddefseq      int DEFAULT 0 NULL,
       splitconddefseq      int DEFAULT 0 NULL,
       fldrsvrid            VARCHAR(10) NULL,
       fldrid               int DEFAULT 0 NULL,
       tmpltsvrid           VARCHAR(10) NULL,
       tmpltactid           int DEFAULT 0 NULL,
       waitingtime          int DEFAULT 0 NULL,
       workingtime          int DEFAULT 0 NULL,
       planstarttime        int DEFAULT 0 NULL,
       plancmplttime        int DEFAULT 0 NULL,
       dscpt                VARCHAR(100) NULL
)
GO

ALTER TABLE actdef
ADD CONSTRAINT xpkactdef PRIMARY KEY CLUSTERED (procdefid, actdefseq)
GO


CREATE TABLE act (       
       svrid                VARCHAR(10) NOT NULL,
       procid               INT DEFAULT 0 NOT NULL,
       actseq               INT DEFAULT 0 NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       jointype             CHAR(1) DEFAULT '?' NOT NULL,
       casetype             CHAR(1) DEFAULT '?' NOT NULL,
       deadlinetype         CHAR(1) DEFAULT '?' NOT NULL,
       transtype            CHAR(1) DEFAULT '?' NOT NULL,
       caltype              CHAR(1) DEFAULT 'U' NOT NULL,
       existinfofile        CHAR(1) DEFAULT 'F' NOT NULL,
       existcmntrans        CHAR(1) DEFAULT 'F' NOT NULL,
       isrepsign            CHAR(1) DEFAULT 'F' NOT NULL,
       subproctype          CHAR(1) DEFAULT '?' NOT NULL,
       sendapp              CHAR(1) DEFAULT 'F' NOT NULL,
       sendattach           CHAR(1) DEFAULT 'F' NOT NULL,
       sendcmnt             CHAR(1) DEFAULT 'F' NOT NULL,
       state                CHAR(1) DEFAULT 'N' NOT NULL,
       prestate             CHAR(1) DEFAULT 'N' NOT NULL,
       checkpostcond        CHAR(1) DEFAULT 'F' NOT NULL,
       cmpltopt             CHAR(1) DEFAULT '?' NOT NULL,
       rbackopt             CHAR(1) DEFAULT '?' NOT NULL,
       eventtype            CHAR(1) DEFAULT '?' NOT NULL,
       actlooptype          CHAR(1) DEFAULT '?' NOT NULL,
       defsvrid             VARCHAR(10) DEFAULT '0000000000' NOT NULL,
       defprocdefid         INT DEFAULT 0 NOT NULL,
       name                 VARCHAR(100) NOT NULL,
       priority             INT DEFAULT 0 NOT NULL,
       actauth              INT DEFAULT 0 NOT NULL,
       actinfo              INT DEFAULT 0 NOT NULL,
       deadline             INT DEFAULT 0 NOT NULL,
       respgrpseq           INT DEFAULT 0 NOT NULL,
       respseq              INT DEFAULT 0 NOT NULL,
       capacity             INT DEFAULT 0 NOT NULL,
       cost                 INT DEFAULT 0 NOT NULL,
       providerid           INT DEFAULT 0 NOT NULL,
       loopcnt              INT DEFAULT 0 NOT NULL,
       cmpltcnt             INT DEFAULT 0 NOT NULL,
       spcfromnode          INT DEFAULT 0 NOT NULL,
       attaddcnt            INT DEFAULT 0 NOT NULL,
       waitingtime          INT DEFAULT 0 NULL,
       workingtime          INT DEFAULT 0 NULL,
       planstarttime        INT DEFAULT 0 NULL,
       plancmplttime        INT DEFAULT 0 NULL,
       subsvrid             VARCHAR(10) NULL,
       subprocdefid         INT DEFAULT 0 NULL,
       suborgprocdefid      INT DEFAULT 0 NULL,
       postcondseq          INT DEFAULT 0 NULL,
       mergecondseq         INT DEFAULT 0 NULL,
       splitcondseq         INT DEFAULT 0 NULL,
       dscpt                VARCHAR(100) NULL,
       resplist             VARCHAR(255) NULL,
       deadlinedtime        DATETIME NULL,
       planstartdtime       DATETIME NULL,
       plancmpltdtime       DATETIME NULL,
       startdtime           DATETIME NULL,
       cmpltdtime           DATETIME NULL
)
GO

ALTER TABLE act
ADD CONSTRAINT xpkact PRIMARY KEY CLUSTERED (procid, actseq)
GO

CREATE INDEX xie1act ON act ( deadlinedtime, state )
GO


CREATE TABLE witem (       
       svrid                VARCHAR(10) NOT NULL,
       procid               INT NOT NULL DEFAULT 0,
       witemseq             INT NOT NULL DEFAULT 0,
       prtcptype            CHAR(1) NOT NULL DEFAULT '?',
       onasync              CHAR(1) NOT NULL DEFAULT '?',
       state                CHAR(1) NOT NULL DEFAULT '?',
       urgent               CHAR(1) NOT NULL DEFAULT '?',
       existinfofile        CHAR(1) NOT NULL DEFAULT '?',
       checkpostcond        CHAR(1) NOT NULL DEFAULT '?',
       actseq               INT NOT NULL DEFAULT 0,
       priority             INT NOT NULL DEFAULT 0,
       respgrpseq           INT NOT NULL DEFAULT 0,
       respseq              INT NOT NULL DEFAULT 0,
       deadline             INT NOT NULL DEFAULT 0,
       prtcp                VARCHAR(10) NOT NULL,
       prtcpname            VARCHAR(100) NOT NULL,
       creationdtime        DATETIME NOT NULL,
       loopcnt              INT NOT NULL DEFAULT 0,
       cmpltusr             VARCHAR(10) NOT NULL DEFAULT '0000000000',
       fwdfromwitemseq      INT NOT NULL DEFAULT 0,
       calmemberid          VARCHAR(10) NULL,
       startdtime           DATETIME NULL,
       cmpltdtime           DATETIME NULL,
       deadlinedtime        DATETIME NULL,
       cmpltusrname         VARCHAR(100) NULL,
       checkoutusr          VARCHAR(10) NULL,
       checkoutdtime        DATETIME NULL
)
GO

ALTER TABLE witem
ADD CONSTRAINT xpkwitem PRIMARY KEY CLUSTERED (procid, witemseq)
GO

CREATE INDEX xie1witem ON witem (prtcp, state)
GO

CREATE INDEX xie2witem ON witem (cmpltdtime)
GO

CREATE INDEX xie3witem ON witem (deadlinedtime, state)
GO

CREATE INDEX xie4witem ON witem (procid, actseq)
GO

CREATE INDEX xie5witem ON witem (cmpltusr, state)
GO

CREATE INDEX xie6witem ON witem (checkoutusr)
GO

CREATE INDEX xie7witem ON witem (procid, state)
GO

CREATE TABLE witemcnt (	   
       memberid             VARCHAR(10) NOT NULL,
       state                CHAR(1) NOT NULL DEFAULT '?',
       urgent               CHAR(1) NOT NULL DEFAULT '?',
       prtcptype            CHAR(1) NOT NULL,
       cnt                  INT NOT NULL DEFAULT 0
)
GO

ALTER TABLE witemcnt 
ADD CONSTRAINT xpkwitemcnt PRIMARY KEY CLUSTERED (memberid, state, urgent)
GO


CREATE TABLE cmnt (
       svrid                VARCHAR(10) NOT NULL,
       procid               INT NOT NULL DEFAULT 0,
       cmntseq              INT NOT NULL DEFAULT 0,
       parentcmntseq        INT NOT NULL DEFAULT 0,
       type                 VARCHAR(10) NOT NULL DEFAULT 'COMMENT',
       gettype              CHAR(1) NOT NULL DEFAULT '?',
       sendtype             CHAR(1) NOT NULL DEFAULT '?',
       witemseq             INT NOT NULL DEFAULT 0,
       actseq               INT DEFAULT 0 NOT NULL,
       actname              VARCHAR(100) NULL,
       creationdtime        DATETIME NOT NULL DEFAULT (getdate()),
       creator              VARCHAR(10) NOT NULL DEFAULT '?',
       creatorname          VARCHAR(100) NULL DEFAULT '?',
       modifydtime          DATETIME NULL,
       jobtitleid           VARCHAR(10) NULL,
       jobtitlename         VARCHAR(100) NULL,
       deptid               VARCHAR(10) NULL,
       deptname             VARCHAR(100) NULL,
       contents             NVARCHAR(4000) NULL
)
GO

ALTER TABLE cmnt
ADD CONSTRAINT xpkcmnt PRIMARY KEY CLUSTERED (procid, cmntseq)
GO

CREATE INDEX xie1cmnt ON cmnt (procid, witemseq, actseq)
GO

CREATE TABLE queueerrlog (       
       svrid                VARCHAR(10) NOT NULL,
       execdtime            DATETIME NOT NULL,
       filename             VARCHAR(255) NOT NULL,
       state                CHAR(1) NOT NULL DEFAULT '?',
       usrid                VARCHAR(10) NOT NULL,
       command              INT NOT NULL DEFAULT 0,
       ipaddr               VARCHAR(40) NOT NULL,
       procdefid            INT NOT NULL DEFAULT 0,
       procid               INT NOT NULL DEFAULT 0,
       witemseq             INT NOT NULL DEFAULT 0,
       errno                INT NOT NULL DEFAULT 0,
       dscpt                VARCHAR(100) NULL,
       detailinfo           VARCHAR(255) NULL
)
GO

ALTER TABLE queueerrlog
ADD CONSTRAINT xpkqueueerrlog PRIMARY KEY CLUSTERED (execdtime, filename)
GO


CREATE TABLE excpt (       
       svrid                VARCHAR(10) NOT NULL,
       procid               INT NOT NULL DEFAULT 0,
       excptseq             INT NOT NULL DEFAULT 0,
       type                 CHAR(1) NOT NULL DEFAULT '?',
       resptype             CHAR(1) NOT NULL DEFAULT '?',
       actseq               INT NOT NULL DEFAULT 0,
       actappseq            INT NOT NULL DEFAULT 0,
       incvalue             INT NOT NULL DEFAULT 0,
       alertstarttime       INT NOT NULL,
       alertduration        INT NOT NULL,
       alertinterval        INT NOT NULL,
       alertreceiver        VARCHAR(10) NULL,
       email                VARCHAR(100) NULL,
       exename              VARCHAR(100) NULL,
       alertsubject         VARCHAR(100) NULL,
       alertmsg             VARCHAR(255) NULL
)
GO

ALTER TABLE excpt
ADD CONSTRAINT xpkexcpt PRIMARY KEY CLUSTERED (procid, excptseq)
GO


CREATE TABLE deadline (       
       svrid                VARCHAR(10) NOT NULL,
       procid               INT NOT NULL DEFAULT 0,
       deadlineseq          INT NOT NULL DEFAULT 0,
       deadlinetype         CHAR(1) NOT NULL DEFAULT '?',
       resptype             CHAR(1) NOT NULL DEFAULT '?',
       chkoutid             INT DEFAULT 0 NOT NULL,
       actseq               INT NOT NULL DEFAULT 0,
       actappseq            INT NOT NULL DEFAULT 0,
       witemseq             INT NOT NULL DEFAULT 0,
       excptseq             INT NOT NULL DEFAULT 0,
       deadline             INT NOT NULL DEFAULT 0,
       incvalue             INT NOT NULL DEFAULT 0,
       startdtime           DATETIME NOT NULL,
       enddtime             DATETIME NOT NULL,
       nextdtime            DATETIME NOT NULL,
       interval             INT NOT NULL,
       errno                INT NOT NULL DEFAULT 0,
       calmemberid          VARCHAR(10) NOT NULL,
       receiver             VARCHAR(10) NULL,
       email                VARCHAR(100) NULL,
       exename              VARCHAR(100) NULL,
       subject              VARCHAR(100) NULL,
       msg                  VARCHAR(255) NULL
)
GO
CREATE INDEX xie1deadline ON deadline (nextdtime)
GO
CREATE INDEX xie2deadline ON deadline (enddtime)
GO
CREATE  INDEX xie3deadline ON deadline (procid, actseq)
GO
ALTER TABLE deadline ADD CONSTRAINT xpkdeadline PRIMARY KEY CLUSTERED (procid, deadlineseq)
GO


CREATE TABLE condtmplt (       
       svrid                VARCHAR(10) NOT NULL,
       condtmpltid          INT NOT NULL DEFAULT 0,
       type                 CHAR(1) NOT NULL DEFAULT '?',
       expr                 VARCHAR(2000) NULL,
       dscpt                VARCHAR(100) NULL
)
GO

ALTER TABLE condtmplt
ADD CONSTRAINT xpkcondtmplt PRIMARY KEY CLUSTERED (condtmpltid)
GO

-- Q: Why indexvalue is NVARCHAR while value is still VARCHAR?
-- A: To avoid an overflow error when copying 2-byte language data (such as Japanese) from 'value' to 'indexvalue'.
CREATE TABLE rlvntdata (       
       svrid                VARCHAR(10) NOT NULL,
       procid               INT NOT NULL DEFAULT 0,
       rlvntdataseq         INT NOT NULL DEFAULT 0,
       ispublic             CHAR(1) NOT NULL DEFAULT '?',
       scope                CHAR(1) NOT NULL DEFAULT '?',
       valuetype            CHAR(1) NOT NULL DEFAULT '?',
       parentinouttype      CHAR(1) NOT NULL DEFAULT '?', 
       rlvntdataname        VARCHAR(100) NOT NULL,
       dscpt                VARCHAR(100) NULL,
       dispvalue            VARCHAR(100) NULL,
       indexvalue           NVARCHAR(100) NULL,
       value                NVARCHAR(2000) NULL
)
GO

ALTER TABLE rlvntdata
ADD CONSTRAINT xpkrlvntdata PRIMARY KEY CLUSTERED (procid, rlvntdataseq)
GO
CREATE UNIQUE nonclustered INDEX xak1rlvntdata ON rlvntdata(procid, rlvntdataname, scope)
GO
CREATE INDEX xie1rlvntdata ON rlvntdata (indexvalue)
GO

CREATE TABLE drlvntdataval (
       svrid                varchar(10) not null,
       orgprocdefid         int default 0 not null,
       rlvntdatadefname     varchar(100) not null,
       valuetype            char(1) default '?' not null,
       xreftype             char(1) default '?' not null,
       xtypeid              int default 0 not null,
       orgxtypeid           int default 0 not null,
       fileid               int default 0 not null,
       dispvalue            varchar(100) null,
       dscpt                varchar(100) null,
       value                nvarchar(2000) null
)
GO

ALTER TABLE drlvntdataval
ADD CONSTRAINT xpkdrlvntdataval PRIMARY KEY CLUSTERED (orgprocdefid, rlvntdatadefname)
GO

CREATE TABLE grlvntdata (
       svrid                varchar(10) NOT NULL,
       grlvntdataid         int DEFAULT 0 NOT NULL,
       valuetype            CHAR(1) DEFAULT '?' NOT NULL,
       xreftype             CHAR(1) DEFAULT '?' NOT NULL,
       xtypeid              int DEFAULT 0 NOT NULL,
       orgxtypeid           int DEFAULT 0 NOT NULL,
       fldrid               int DEFAULT 0 NULL,
       name                 varchar(100) NOT NULL,
       creationdtime        datetime not null,
       creator              varchar(10) NOT NULL,
       creatorname          varchar(100) NOT NULL,
       creatordeptname      varchar(100) NULL,
       modifydtime          datetime null,
       modifier             varchar(10) NULL,
       modifiername         varchar(100) NULL,
       dispvalue            varchar(100) NULL,
       dscpt                varchar(100) NULL,
       value                nvarchar(2000) NULL
)
GO

ALTER TABLE grlvntdata ADD CONSTRAINT xpkgrlvntdata PRIMARY KEY CLUSTERED (grlvntdataid)
GO

CREATE UNIQUE nonclustered INDEX xak1grlvntdata ON grlvntdata (name)
GO


CREATE TABLE grdauditinfo (
       svrid                varchar(10) not null,
       grlvntdataid         int default 0 not null,
       execseq              int not null identity (1, 1),
       procid               int default 0 not null,
       name                 varchar(100) not null,
       procname             varchar(100) null,
       modifydtime          datetime null,
       modifier             varchar(10) null,
       modifiername         varchar(100) null,
       dispvalue            varchar(100) null,
       dscpt                varchar(100) null,
       value                nvarchar(2000) null
)
GO

ALTER TABLE grdauditinfo
ADD CONSTRAINT xpkgrdauditinfo PRIMARY KEY CLUSTERED (grlvntdataid, execseq)
GO

CREATE UNIQUE nonclustered INDEX xak1grdauditinfo ON grdauditinfo (procid, execseq)
GO

CREATE TABLE procapp (       
       svrid                VARCHAR(10) NOT NULL,
       procid               INT NOT NULL DEFAULT 0,
       procappseq           INT NOT NULL DEFAULT 0,
       type                 CHAR(1) NOT NULL DEFAULT '?',
       sendtype             CHAR(1) NOT NULL DEFAULT '?',
       keepingflag          CHAR(1) NOT NULL DEFAULT '?',
       viewtype             CHAR(1) NOT NULL DEFAULT 'W',
       dmsaveflag           CHAR(1) NOT NULL DEFAULT '?',
       dmidtype             CHAR(1) NOT NULL DEFAULT '?',
       appsvrid             VARCHAR(10) NOT NULL DEFAULT '0000000000',
       appid                INT NOT NULL DEFAULT 0,
       orgappid             INT NOT NULL DEFAULT 0,
       appver               INT NOT NULL DEFAULT 1,
       disporder            INT NOT NULL DEFAULT 0,
       name                 VARCHAR(100) NOT NULL,
       rlvntdataseq         INT NULL DEFAULT 0,
       invokedmethod        VARCHAR(1000) NULL,
       extname              VARCHAR(30) NULL,
       dmsvrid              VARCHAR(10) NULL,
       dmfldrid             VARCHAR(500) NULL,
       dmdockind            VARCHAR(30) NULL,
       dscpt                VARCHAR(100) NULL
)
GO

ALTER TABLE procapp
ADD CONSTRAINT xpkprocapp PRIMARY KEY CLUSTERED (procid, procappseq)
GO


CREATE TABLE actapp (       
       svrid                VARCHAR(10) NOT NULL,
       procid               INT NOT NULL DEFAULT 0,
       actseq               INT NOT NULL DEFAULT 0,
       actappseq            INT NOT NULL DEFAULT 0,
       updatable            CHAR(1) NOT NULL DEFAULT '?',
       initoption           CHAR(1) NOT NULL DEFAULT '?',
       viewtype             CHAR(1) NOT NULL DEFAULT 'W',
       jobseq               INT NOT NULL DEFAULT 0,
       procappseq           INT NOT NULL DEFAULT 0,
       appsvrid             VARCHAR(10) NOT NULL,
       appid                INT NOT NULL DEFAULT 0,
       appver               INT NOT NULL DEFAULT 1,
       inrlvntdataseq       INT NOT NULL DEFAULT 0,
       outrlvntdataseq      INT NOT NULL DEFAULT 0,
       modifydtime          DATETIME NULL
)
GO

ALTER TABLE actapp
ADD CONSTRAINT xpkactapp PRIMARY KEY CLUSTERED (procid, actseq, actappseq)
GO


CREATE TABLE witemapp (       
       svrid                VARCHAR(10) NOT NULL,
       procid               INT NOT NULL DEFAULT 0,
       witemseq             INT NOT NULL DEFAULT 0,
       witemappseq          INT NOT NULL DEFAULT 0,
       state                CHAR(1) NOT NULL DEFAULT '?',
       pkitype              CHAR(1) NOT NULL DEFAULT 'N',
       procappseq           INT NOT NULL DEFAULT 0,
       actappseq            INT NOT NULL DEFAULT 0,
       actseq               INT NOT NULL DEFAULT 0,
       mapid                INT NOT NULL DEFAULT 0,
       appver               INT NOT NULL DEFAULT 1,
       appsvrid             VARCHAR(10) NOT NULL,
       appid                INT NOT NULL DEFAULT 0,
       prtcp                VARCHAR(10) NULL,
       prtcpname            VARCHAR(100) NULL,
       modifydtime          DATETIME NULL
)
GO

ALTER TABLE witemapp
ADD CONSTRAINT xpkwitemapp PRIMARY KEY CLUSTERED (procid, witemseq, witemappseq)
GO

CREATE TABLE respgrp (       
       svrid                VARCHAR(10) NOT NULL,
       procid               INT NOT NULL DEFAULT 0,
       respgrpseq           INT NOT NULL DEFAULT 0,
       name					VARCHAR(100) NOT NULL,
       dscpt                VARCHAR(100) NULL
)
GO

ALTER TABLE respgrp
ADD CONSTRAINT xpkrespgrp PRIMARY KEY CLUSTERED (procid, respgrpseq)
GO

CREATE TABLE trans (       
       svrid                VARCHAR(10) NOT NULL,
       procid               INT NOT NULL DEFAULT 0,
       transseq             INT NOT NULL DEFAULT 0,
       state                CHAR(1) NOT NULL DEFAULT '?',
       type                 CHAR(1) NOT NULL DEFAULT '?',
       iscmntrans           CHAR(1) NOT NULL DEFAULT '?',
       fromnode             INT NOT NULL DEFAULT 0,
       tonode               INT NOT NULL DEFAULT 0,
       condseq              INT NOT NULL DEFAULT 0,
       actioncondseq        INT NOT NULL DEFAULT 0,
       loopcnt              INT NOT NULL DEFAULT 0,
       evalorder            INT NOT NULL DEFAULT 0,
       name                 VARCHAR(100) NULL,
       modifydtime          DATETIME NULL
)
GO

ALTER TABLE trans
ADD CONSTRAINT xpktrans PRIMARY KEY CLUSTERED (procid, transseq)
GO


CREATE TABLE cond (       
       svrid                VARCHAR(10) NOT NULL,
       procid               INT NOT NULL DEFAULT 0,
       condseq              INT NOT NULL DEFAULT 0,
       type                 CHAR(1) NOT NULL DEFAULT '?',
       dscpt                VARCHAR(100) NULL,
       expr                 VARCHAR(2000) NULL
)
GO

ALTER TABLE cond
ADD CONSTRAINT xpkcond PRIMARY KEY CLUSTERED (procid, condseq)
GO


CREATE TABLE conddef (       
       svrid                VARCHAR(10) NOT NULL,
       procdefid            INT NOT NULL DEFAULT 0,
       conddefseq           INT NOT NULL DEFAULT 0,
       type                 CHAR(1) NOT NULL DEFAULT '?',
       dscpt                VARCHAR(100) NULL,
       expr                 VARCHAR(2000) NULL
)
GO

ALTER TABLE conddef
ADD CONSTRAINT xpkconddef PRIMARY KEY CLUSTERED (procdefid, conddefseq)
GO


CREATE TABLE rlvntdatadef (
       svrid                VARCHAR(10) NOT NULL,
       procdefid            INT NOT NULL DEFAULT 0,
       rlvntdatadefseq      INT NOT NULL DEFAULT 0,
       ispublic             CHAR(1) NOT NULL DEFAULT '?',
       scope                CHAR(1) DEFAULT 'I' NOT NULL,
       valuetype            CHAR(1) NOT NULL DEFAULT '?',
       grlvntdataid         int DEFAULT 0 NOT NULL,
       rlvntdatadefname     VARCHAR(100) NOT NULL,
       dscpt                VARCHAR(100) NULL,
       dispvalue            VARCHAR(100) NULL,
       value                NVARCHAR(2000) NULL
)
GO

ALTER TABLE rlvntdatadef
ADD CONSTRAINT xpkrlvntdatadef PRIMARY KEY CLUSTERED (procdefid, rlvntdatadefseq)
GO
CREATE UNIQUE NONCLUSTERED INDEX xak1rlvntdatadef ON rlvntdatadef(procdefid, rlvntdatadefname, scope)
GO
CREATE INDEX xie1rlvntdatadef ON rlvntdatadef (grlvntdataid)
GO


CREATE TABLE transdef (  
       svrid                VARCHAR(10) NOT NULL,
       procdefid            INT NOT NULL DEFAULT 0,
       transdefseq          INT NOT NULL DEFAULT 0,
       type                 CHAR(1) NOT NULL DEFAULT '?',
       iscmntrans           CHAR(1) NOT NULL DEFAULT '?',
       fromnode             INT NOT NULL DEFAULT 0,
       tonode               INT NOT NULL DEFAULT 0,
       conddefseq           INT NOT NULL DEFAULT 0,
       actionconddefseq     INT NOT NULL DEFAULT 0,
       evalorder            INT NOT NULL DEFAULT 0,
       name                 VARCHAR(100) NULL
)
GO

ALTER TABLE transdef
ADD CONSTRAINT xpktransdef PRIMARY KEY CLUSTERED (procdefid, transdefseq)
GO


CREATE TABLE apptmplt ( 
       svrid                VARCHAR(10) NOT NULL,
       appid                INT NOT NULL DEFAULT 0,
       isfinal              CHAR(1) NOT NULL DEFAULT '?',
       type                 CHAR(1) NOT NULL DEFAULT '?',
       envtype              CHAR(1) NOT NULL DEFAULT '?',
       pkitype              CHAR(1) NOT NULL DEFAULT 'N',
       dmdocrtype           CHAR(1) NOT NULL DEFAULT 'N',
       dmsaveflag           CHAR(1) NOT NULL DEFAULT '?',
       dmidtype             CHAR(1) NOT NULL DEFAULT '?',
       keepingflag          CHAR(1) NOT NULL DEFAULT '?',
       publicationstate     CHAR(1) DEFAULT '?' NOT NULL,
       fldrsvrid            VARCHAR(10) NOT NULL,
       fldrid               INT NOT NULL DEFAULT 0,
       prjfldrid            int DEFAULT 0 NOT NULL,
       orgappid             int DEFAULT 0 NOT NULL,
       appver               INT NOT NULL DEFAULT 0,
       creationdtime        DATETIME NOT NULL,
       name                 VARCHAR(100) NOT NULL,
       author               VARCHAR(10) NOT NULL,
       authorname           VARCHAR(100) NOT NULL DEFAULT '?',
       preappid             int DEFAULT 0 NULL,
       extname              VARCHAR(30) NULL,
       dmsvrid              VARCHAR(10) NULL,
       dmdocid              VARCHAR(500) NULL,
       dmfldrid             VARCHAR(500) NULL,
       dscpt                VARCHAR(100) NULL,
       invokedmethod        VARCHAR(1000) NULL,
       dmfldrname           VARCHAR(255) NULL,
       chkincmnt            varchar(500) NULL
)
GO

ALTER TABLE apptmplt
ADD CONSTRAINT xpkapptmplt PRIMARY KEY CLUSTERED (appid)
GO

CREATE INDEX xie1apptmplt ON apptmplt (orgappid, appver)
GO


CREATE TABLE procappdef (    
       svrid                VARCHAR(10) NOT NULL,
       procdefid            INT NOT NULL DEFAULT 0,
       procappdefseq        INT NOT NULL DEFAULT 0,
       type                 CHAR(1) NOT NULL DEFAULT '?',
       envtype              CHAR(1) NOT NULL DEFAULT '?',
       sendtype             CHAR(1) NOT NULL DEFAULT '?',
       keepingflag          CHAR(1) NOT NULL DEFAULT '?',
       viewtype             CHAR(1) NOT NULL DEFAULT 'W',
       dmsaveflag           CHAR(1) NOT NULL DEFAULT '?',
       dmidtype             CHAR(1) NOT NULL DEFAULT '?',
       appsvrid             VARCHAR(10) NOT NULL DEFAULT '0000000000',
       appid                INT NOT NULL DEFAULT 0,
       orgappid             INT NOT NULL DEFAULT 0,
       appver               INT NOT NULL DEFAULT 1,
       disporder            INT NOT NULL DEFAULT 0,
       name                 VARCHAR(100) NOT NULL,
       rlvntdatadefseq      INT NULL DEFAULT 0,
       invokedmethod        VARCHAR(1000) NULL,
       extname              VARCHAR(30) NULL,
       dmsvrid              VARCHAR(10) NULL,
       dmfldrid             VARCHAR(500) NULL,
       dmdockind            VARCHAR(30) NULL,
       dscpt                VARCHAR(100) NULL
)
GO

ALTER TABLE procappdef
ADD CONSTRAINT xpkprocappdef PRIMARY KEY CLUSTERED (procdefid, procappdefseq)
GO


CREATE TABLE prtcpdef (
       svrid                VARCHAR(10) NOT NULL,
       procdefid            INT NOT NULL DEFAULT 0,
       actdefseq            INT NOT NULL DEFAULT 0,
       prtcpdefseq          INT NOT NULL DEFAULT 0,
       kind                 CHAR(1) NOT NULL DEFAULT 'P',
       type                 CHAR(1) NOT NULL DEFAULT '?',
       assignrule           CHAR(1) NOT NULL DEFAULT '?',
       existscriptfile      CHAR(1) NOT NULL DEFAULT '?',
       prtcpauth            INT NOT NULL DEFAULT 0,
       prtcp                VARCHAR(10) NOT NULL,
       mapid                INT NOT NULL DEFAULT 0,
       disporder            INT NOT NULL DEFAULT 0,
       calmemberid          VARCHAR(10) NULL,
       usrgrphid            VARCHAR(10) NULL,
       expr                 VARCHAR(100) NULL
)
GO

ALTER TABLE prtcpdef
ADD CONSTRAINT xpkprtcpdef PRIMARY KEY CLUSTERED (procdefid, actdefseq, prtcpdefseq)
GO


CREATE TABLE prtcp (
       svrid                VARCHAR(10) NOT NULL,
       procid               INT NOT NULL DEFAULT 0,
       actseq               INT NOT NULL DEFAULT 0,
       prtcpseq             INT NOT NULL DEFAULT 0,
       kind                 CHAR(1) NOT NULL DEFAULT 'P',
       useflag              CHAR(1) NOT NULL DEFAULT 'F',
       type                 CHAR(1) NOT NULL DEFAULT '?',
       assignrule           CHAR(1) NOT NULL DEFAULT '?',
       existscriptfile      CHAR(1) NOT NULL DEFAULT '?',
       prtcpauth            INT NOT NULL DEFAULT 0,
       prtcp                VARCHAR(10) NOT NULL,
       mapid                INT NOT NULL DEFAULT 0,
       disporder            INT NOT NULL DEFAULT 0,
       calmemberid          VARCHAR(10) NULL,
       usrgrphid            VARCHAR(10) NULL,
       deptname             VARCHAR(100) NULL,
       jobtitlename         VARCHAR(100) NULL,
       expr                 VARCHAR(100) NULL,
       prtcpname            VARCHAR(400) NULL
)
GO

ALTER TABLE prtcp
ADD CONSTRAINT xpkprtcp PRIMARY KEY CLUSTERED (procid, actseq, prtcpseq)
GO


CREATE TABLE resp (
       svrid                VARCHAR(10) NOT NULL,
       procid               INT NOT NULL DEFAULT 0,
       respgrpseq           INT NOT NULL DEFAULT 0,
       respseq              INT NOT NULL DEFAULT 0,
       disporder            INT NOT NULL DEFAULT 0,
       respinfo             INT NOT NULL DEFAULT 0,
       name                 VARCHAR(100) NOT NULL,
)
GO

ALTER TABLE resp
ADD CONSTRAINT xpkresp PRIMARY KEY CLUSTERED (procid, respgrpseq, respseq)
GO

CREATE TABLE respgrpdef (
       svrid                VARCHAR(10) NOT NULL,
       procdefid            INT NOT NULL DEFAULT 0,
       respgrpdefseq        INT NOT NULL DEFAULT 0,
       name                 VARCHAR(100) NOT NULL,
       dscpt                VARCHAR(100) NULL
)
GO

ALTER TABLE respgrpdef
ADD CONSTRAINT xpkrespgrpdef PRIMARY KEY CLUSTERED (procdefid, respgrpdefseq)
GO

CREATE TABLE respdef (
       svrid                VARCHAR(10) NOT NULL,
       procdefid            INT NOT NULL DEFAULT 0,
       respgrpdefseq        INT NOT NULL DEFAULT 0,
       respdefseq           INT NOT NULL DEFAULT 0,
       disporder            INT NOT NULL DEFAULT 0,
       respinfo             INT NOT NULL DEFAULT 0,
       name                 VARCHAR(100) NOT NULL,
)
GO

ALTER TABLE respdef
ADD CONSTRAINT xpkrespdef PRIMARY KEY CLUSTERED (procdefid, respgrpdefseq, respdefseq)
GO

CREATE TABLE actappdef (
       svrid                VARCHAR(10) NOT NULL,
       procdefid            INT NOT NULL DEFAULT 0,
       actdefseq            INT NOT NULL DEFAULT 0,
       actappdefseq         INT NOT NULL DEFAULT 0,
       updatable            CHAR(1) NOT NULL DEFAULT '?',
       initoption           CHAR(1) NOT NULL DEFAULT '?',
       viewtype             CHAR(1) NOT NULL DEFAULT 'W',
       jobseq               INT NOT NULL DEFAULT 0,
       procappdefseq        INT NOT NULL DEFAULT 0,
       appsvrid             VARCHAR(10) NOT NULL,
       appid                INT NOT NULL DEFAULT 0,
       appver               INT NOT NULL DEFAULT 1,
       inrlvntdatadefseq    INT NOT NULL DEFAULT 0,
       outrlvntdatadefseq   INT NOT NULL DEFAULT 0

)
GO

ALTER TABLE actappdef
ADD CONSTRAINT xpkactappdef PRIMARY KEY CLUSTERED (procdefid, actdefseq, actappdefseq)
GO


CREATE TABLE id (
       svrid                VARCHAR(10) NOT NULL,
       keystr               VARCHAR(30) NOT NULL,
       value                INT NOT NULL DEFAULT 0
)
GO

ALTER TABLE id
ADD CONSTRAINT xpkid PRIMARY KEY CLUSTERED (keystr)  WITH FILLFACTOR = 60
GO

CREATE TABLE jobtitle ( 
       jobtitleid           VARCHAR(10) NOT NULL,
       name                 VARCHAR(100) NOT NULL,
       disporder            INT NOT NULL DEFAULT 0
)
GO

ALTER TABLE jobtitle
ADD CONSTRAINT xpkjobtitle PRIMARY KEY CLUSTERED (jobtitleid)
GO


CREATE TABLE member ( 
       memberid             VARCHAR(10) NOT NULL,
       type                 CHAR(1) NOT NULL,
       state                CHAR(1) NOT NULL DEFAULT 'N',
       isabsent             CHAR(1) NOT NULL DEFAULT '?',
       lictype              CHAR(1) NOT NULL DEFAULT 'N',
       inherittype          CHAR(1) NOT NULL DEFAULT '?',
       changepasswd         CHAR(1) NOT NULL DEFAULT '?',
       passwdneverexpire    CHAR(1) NOT NULL DEFAULT 'F',
       disporder            INT NOT NULL DEFAULT 0,
       passwdfailcnt        INT NOT NULL DEFAULT 0,
       etcinfo              INT NOT NULL DEFAULT 0,
       memberinfoid         VARCHAR(10) NOT NULL DEFAULT '0000000000',
       name                 VARCHAR(100) NOT NULL,
       passwddtime          DATETIME NULL,
       loginid              VARCHAR(100) NULL,
       jobtitleid           VARCHAR(10) NULL,
       svrid                VARCHAR(10) NULL,
       deptid               VARCHAR(10) NULL,
       deptcode             VARCHAR(10) NULL,
       deptname             VARCHAR(100) NULL,
       jobtitlename         VARCHAR(100) NULL,
       shortname            VARCHAR(30) NULL,
       parentdeptid         VARCHAR(10) NULL,
       empno                VARCHAR(10) NULL,
       alias                VARCHAR(100) NULL,
       email                VARCHAR(100) NULL,
       managerid            VARCHAR(10) NULL,
       passwd               VARCHAR(150) NULL,
       absstartdtime        DATETIME NULL,
       absenddtime          DATETIME NULL,
       abssurrogater        VARCHAR(10) NULL,
       dscpt                VARCHAR(100) NULL,
       guid                 VARCHAR(128) NULL,
       absmsg               VARCHAR(255) NULL,
       ldapdn               VARCHAR(1500) NULL,
       carrier              VARCHAR(100) NULL,
       reminderdelivery     VARCHAR(10) NULL,
       cell                 VARCHAR(20) NULL,
       t_checkoutuserid     VARCHAR(10) NULL,
       t_name               VARCHAR(100) NULL,
       t_deptid             VARCHAR(10) NULL,
       t_delete             CHAR(1) NULL
)
GO

ALTER TABLE member
ADD CONSTRAINT xpkmember PRIMARY KEY CLUSTERED (memberid)
GO
CREATE INDEX xak1member ON member (loginid)
GO
CREATE INDEX xie1member ON member (abssurrogater)
GO
CREATE INDEX xie2member ON member (deptid)
GO
CREATE INDEX xie3member ON member (absstartdtime)
GO
CREATE INDEX xie4member ON member (isabsent)
GO
CREATE INDEX xie5member ON member (name)
GO
CREATE INDEX xie6member ON member (shortname)
GO
CREATE INDEX xie7member ON member (email)
GO
CREATE INDEX xie8member ON member (type)
GO

CREATE TABLE membertemp ( 
       checkoutuserid       VARCHAR(10) NOT NULL,
       memberid             VARCHAR(10) NOT NULL,
       type                 CHAR(1) NOT NULL,
       name                 VARCHAR(100) NOT NULL,
       deptid               VARCHAR(10) NULL
)
GO

ALTER TABLE membertemp
ADD CONSTRAINT xpkmembertemp PRIMARY KEY CLUSTERED (checkoutuserid, memberid)
GO

CREATE TABLE memberinfo (
       memberid             VARCHAR(10) NOT NULL,
       dupusrflag           CHAR(1) NOT NULL DEFAULT '?',
       dupnameflag          CHAR(1) NOT NULL DEFAULT '?',
       headofregion      	CHAR(1) NOT NULL DEFAULT '?',
       managerrule          INT NOT NULL DEFAULT 0,
       ida                  VARCHAR(10) NULL,
       idb                  VARCHAR(10) NULL,
       namea                VARCHAR(100) NULL,
       nameb                VARCHAR(100) NULL,
       customa              VARCHAR(100) NULL,
       customb              VARCHAR(100) NULL,
       customc              VARCHAR(100) NULL,
       customd              VARCHAR(100) NULL,
       custome              VARCHAR(100) NULL
)
GO

ALTER TABLE memberinfo
ADD CONSTRAINT xpkmemberinfo PRIMARY KEY CLUSTERED (memberid)
GO
CREATE INDEX xie1memberinfo ON memberinfo (customa)
GO
CREATE INDEX xie2memberinfo ON memberinfo (customb)
GO
CREATE INDEX xie3memberinfo ON memberinfo (customc)
GO
CREATE INDEX xie4memberinfo ON memberinfo (customd)
GO
CREATE INDEX xie5memberinfo ON memberinfo (custome)
GO

CREATE TABLE usrgrpprtcp (
       usrgrpid             VARCHAR(10) NOT NULL,
       prtcp                VARCHAR(10) NOT NULL,
       prtcptype            CHAR(1) NOT NULL,
       disporder            INT NOT NULL DEFAULT 0,
       usrgrphid            VARCHAR(10) NULL
)
GO

ALTER TABLE usrgrpprtcp
ADD CONSTRAINT xpkusrgrpprtcp PRIMARY KEY CLUSTERED (usrgrpid, prtcp)
GO
CREATE INDEX xie1usrgrpprtcp ON usrgrpprtcp (prtcp)
GO
CREATE INDEX xie2usrgrpprtcp ON usrgrpprtcp (prtcptype)
GO

CREATE TABLE paramdef (
       svrid                VARCHAR(10) NOT NULL,
       procdefid            INT NOT NULL DEFAULT 0,
       actdefseq            INT NOT NULL DEFAULT 0,
       paramdefseq          INT NOT NULL DEFAULT 0,
       inouttype            CHAR(1) NOT NULL DEFAULT '?',
       toscope              CHAR(1) NOT NULL DEFAULT 'I',
       rlvntdatadefseq      INT NOT NULL DEFAULT 0,
       disporder            INT NOT NULL DEFAULT 0,
       todataname           VARCHAR(100) NULL,
       const                VARCHAR(100) NULL
)
GO

ALTER TABLE paramdef
ADD CONSTRAINT xpkparamdef PRIMARY KEY CLUSTERED (procdefid, actdefseq, paramdefseq)
GO


CREATE TABLE param (
       svrid                VARCHAR(10) NOT NULL,
       procid               INT NOT NULL DEFAULT 0,
       actseq               INT NOT NULL DEFAULT 0,
       paramseq             INT NOT NULL DEFAULT 0,
       inouttype            CHAR(1) NOT NULL DEFAULT '?',
       toscope              CHAR(1) NOT NULL DEFAULT 'I',
       rlvntdataseq         INT NOT NULL DEFAULT 0,
       disporder            INT NOT NULL DEFAULT 0,
       todataname           VARCHAR(100) NULL,
       const                VARCHAR(100) NULL
)
GO

ALTER TABLE param
ADD CONSTRAINT xpkparam PRIMARY KEY CLUSTERED (procid, actseq, paramseq)
GO

CREATE TABLE fldrmemberlist (
       svrid                VARCHAR(10) NOT NULL,
       fldrid               INT NOT NULL DEFAULT 0,
       memberid             VARCHAR(10) NOT NULL,
       type                 CHAR(1) NOT NULL DEFAULT '?',
       isexclude            CHAR(1) NOT NULL DEFAULT '?',
       checksub             CHAR(1) NOT NULL DEFAULT 'F',
       disporder            INT NOT NULL DEFAULT 0,
       auth                 INT NOT NULL DEFAULT 0,
       name                 VARCHAR(100) NULL
)
GO

ALTER TABLE fldrmemberlist
ADD CONSTRAINT xpkfldrmemberlist PRIMARY KEY CLUSTERED (fldrid, memberid)
GO

CREATE INDEX xie1fldrmemberlist ON fldrmemberlist ( memberid )
GO

CREATE TABLE excptdef (
       svrid                VARCHAR(10) NOT NULL,
       procdefid            INT NOT NULL DEFAULT 0,
       excptdefseq          INT NOT NULL DEFAULT 0,
       type                 CHAR(1) NOT NULL DEFAULT '?',
       resptype             CHAR(1) NOT NULL DEFAULT '?',
       actdefseq            INT NOT NULL DEFAULT 0,
       actappdefseq         INT NOT NULL DEFAULT 0,
       incvalue             INT NOT NULL DEFAULT 0,
       alertstarttime       INT NOT NULL DEFAULT 0,
       alertduration        INT NOT NULL DEFAULT 0,
       alertinterval        INT NOT NULL DEFAULT 0,
       alertreceiver        VARCHAR(10) NULL,
       email                VARCHAR(100) NULL,
       exename              VARCHAR(100) NULL,
       alertsubject         VARCHAR(100) NULL,
       alertmsg             VARCHAR(255) NULL
)
GO

ALTER TABLE excptdef
ADD CONSTRAINT xpkexcptdef PRIMARY KEY CLUSTERED (procdefid, excptdefseq)
GO


CREATE TABLE attach (
       svrid                VARCHAR(10) NOT NULL,
       procid               INT NOT NULL DEFAULT 0,
       attachseq            INT NOT NULL DEFAULT 0,
       witemseq             INT NOT NULL DEFAULT 0,
       correspondenceseq    INT NOT NULL DEFAULT 0,
       type                 CHAR(1) NOT NULL DEFAULT '?',
       sendtype             CHAR(1) NOT NULL DEFAULT '?',
       gettype              CHAR(1) NOT NULL DEFAULT '?',
       pkitype              CHAR(1) NOT NULL DEFAULT 'N',
       dmdocrtype           CHAR(1) NOT NULL DEFAULT 'N',
       actseq               INT NOT NULL DEFAULT 0,
       mapid                INT NOT NULL DEFAULT 0,
       creationdtime        DATETIME NOT NULL,
       creator              VARCHAR(10) NOT NULL,
       creatorname          VARCHAR(100) NULL DEFAULT '?',
       attachsize           INT NOT NULL DEFAULT 0,
       dispname             NVARCHAR(256) NOT NULL,
       filename             NVARCHAR(256) NOT NULL,
       actname              VARCHAR(100) NULL,
       dmsvrid              VARCHAR(10) NULL,
       dmdocid              VARCHAR(500) NULL,
       dmdockind            VARCHAR(30) NULL,
       dscpt                NVARCHAR(100) NULL,
       category             VARCHAR(256) NULL,
       etcinfo              NVARCHAR(2000) NULL
)
GO

ALTER TABLE attach
ADD CONSTRAINT xpkattach PRIMARY KEY CLUSTERED (procid, attachseq)
GO


CREATE TABLE appcheckout (
       svrid                VARCHAR(10) NOT NULL,
       procid               INT NOT NULL DEFAULT 0,
       mapid                INT NOT NULL DEFAULT 0,
       state                CHAR(1) NOT NULL DEFAULT '?',
       dtime                DATETIME NOT NULL,
       prtcp                VARCHAR(10) NULL,
       prtcpname            VARCHAR(100) NULL
)
GO

ALTER TABLE appcheckout
ADD CONSTRAINT xpkappcheckout PRIMARY KEY CLUSTERED (procid, mapid)
GO
CREATE INDEX xie1appcheckout ON appcheckout ( prtcp )
GO


CREATE TABLE usrsession (  
       memberid             VARCHAR(10) NOT NULL,
       ipaddr               VARCHAR(40) NOT NULL,
       device               VARCHAR(50) NOT NULL DEFAULT 'DESKTOP',
       logincnt             INT NOT NULL DEFAULT 0,
       logindtime           DATETIME NULL,
       sessionkey           VARCHAR(100) NULL
)
GO

ALTER TABLE usrsession
ADD CONSTRAINT xpkusrsession PRIMARY KEY CLUSTERED (memberid, device)
GO

CREATE TABLE checkout (
       svrid                VARCHAR(10) NOT NULL,
       nodeid               VARCHAR(10) NOT NULL,
       type                 CHAR(1) NOT NULL DEFAULT '?',
       dtime                DATETIME NOT NULL,
       memberid             VARCHAR(10) NOT NULL,
       membername           VARCHAR(100) NULL
)
GO

ALTER TABLE checkout
ADD CONSTRAINT xpkcheckout PRIMARY KEY CLUSTERED (type, nodeid)
GO
CREATE INDEX xie1checkout ON checkout ( memberid )
GO

CREATE TABLE auditinfo (
       svrid                VARCHAR(10) NOT NULL,
       procid               INT NOT NULL DEFAULT 0,
       execseq              INT NOT NULL IDENTITY (1, 1),
       event                CHAR(1) NOT NULL,
       objtype              CHAR(1) NOT NULL,
       objstate             CHAR(1) NOT NULL,
       execdtime            DATETIME NOT NULL,
       errno                INT NOT NULL DEFAULT 0,
       actor                VARCHAR(10) NOT NULL DEFAULT 0,
       actorname            VARCHAR(100) NOT NULL,
       objname              VARCHAR(100) NOT NULL,
       objseq               INT NULL DEFAULT 0,
       witemappseq          INT NULL DEFAULT 0,
       respgrpseq           INT NULL DEFAULT 0,
       respseq              INT NULL DEFAULT 0,
       resp                 VARCHAR(100) NULL,
       appname              VARCHAR(100) NULL,
       objdscpt             VARCHAR(255) NULL
)
GO

ALTER TABLE auditinfo
ADD CONSTRAINT xpkauditinfo PRIMARY KEY CLUSTERED (procid, execseq)
GO
CREATE INDEX xie1auditinfo ON auditinfo (procid, objseq)
GO

IF CAST(@@VERSION AS VARCHAR(26)) = 'Microsoft SQL Server  2000'
EXECUTE ('
CREATE TABLE auditinfoadm (
       seq                  INT NOT NULL IDENTITY(1,1),
       actor                VARCHAR(10) NOT NULL,
       actorname            VARCHAR(100) NOT NULL,
       dtime                DATETIME NOT NULL,
       event                VARCHAR(100) NOT NULL,
       objid                VARCHAR(20) NULL,
       objtype              VARCHAR(50) NULL,
       objname              VARCHAR(100) NULL,
       ipaddr               VARCHAR(40) NULL,
       detail               VARCHAR(7500) NULL
)
')
ELSE
EXECUTE ('
CREATE TABLE auditinfoadm (
       seq                  INT NOT NULL IDENTITY(1,1),
       actor                VARCHAR(10) NOT NULL,
       actorname            VARCHAR(100) NOT NULL,
       dtime                DATETIME NOT NULL,
       event                VARCHAR(100) NOT NULL,
       objid                VARCHAR(20) NULL,
       objtype              VARCHAR(50) NULL,
       objname              VARCHAR(100) NULL,
       ipaddr               VARCHAR(40) NULL,
       detail               VARCHAR(MAX) NULL
)
')
GO

ALTER TABLE auditinfoadm
ADD CONSTRAINT xpkauditinfoadm PRIMARY KEY CLUSTERED (seq)
GO

CREATE TABLE procfileinfo (
       svrid                VARCHAR(10) NOT NULL,
       procid               INT NOT NULL DEFAULT 0,
       filesize             INT NULL DEFAULT 0,
       filecnt              INT NULL DEFAULT 0 
)
GO

ALTER TABLE procfileinfo
ADD CONSTRAINT xpkprocfileinfo PRIMARY KEY CLUSTERED (procid)  
GO

CREATE TABLE parentmember (   
       memberid             VARCHAR(10) NOT NULL,
       parentid             VARCHAR(10) NOT NULL,
       type                 CHAR(1) NOT NULL DEFAULT '?',
       dirty                CHAR(1) NOT NULL DEFAULT '?',
       usrinherit           CHAR(1) NOT NULL DEFAULT '?',
       mnginherit           CHAR(1) NOT NULL DEFAULT '?',
       descorder            INT NOT NULL DEFAULT 0,
       memberpath           VARCHAR(500) NULL
)
GO

CREATE INDEX xie1parentmember ON parentmember (parentid)
GO

ALTER TABLE parentmember 
ADD CONSTRAINT xpkparentmember PRIMARY KEY CLUSTERED (memberid, parentid)
GO

CREATE TABLE parentfldr (       
       parentfldrid         INT NOT NULL,
       fldrid               INT NOT NULL,
       dirty                CHAR(1) NOT NULL DEFAULT '?',
       usrinherit           CHAR(1) NOT NULL DEFAULT '?',
       mnginherit           CHAR(1) NOT NULL DEFAULT '?'
)
GO

ALTER TABLE parentfldr
ADD CONSTRAINT xpkparentfldr PRIMARY KEY CLUSTERED (parentfldrid, fldrid)
GO

CREATE INDEX xie1parentfldr ON parentfldr (fldrid)
GO


CREATE TABLE ver(
 	ver                 VARCHAR(100) NOT NULL,
	modifydtime         DATETIME NOT NULL DEFAULT (Getdate()),
	product             VARCHAR(64) NULL,
	ipaddr              VARCHAR(64) NULL,
	transactionid       VARCHAR(64) NULL,
	status              VARCHAR(64) NULL,
	description         VARCHAR(100) NULL
)
GO

CREATE TABLE cbdata (
       svrid                VARCHAR(10) NOT NULL,
       procid               INT NOT NULL DEFAULT 0,
       actseq               INT NOT NULL DEFAULT 0,
       providerid           INT NOT NULL DEFAULT 0,
       mapid                INT NOT NULL DEFAULT 0,
       callbackid           VARCHAR(100) NOT NULL
)
GO

ALTER TABLE cbdata 
ADD CONSTRAINT xpkcbdata PRIMARY KEY CLUSTERED (procid, actseq)
GO

CREATE UNIQUE nonclustered INDEX xak1cbdata ON cbdata (callbackid, providerid)
GO

CREATE TABLE sign (
       svrid                VARCHAR(10) NOT NULL,
       signid               INT NOT NULL DEFAULT 0,
       memberid             VARCHAR(10) NOT NULL,
       extname              VARCHAR(30) NOT NULL,
       dscpt                VARCHAR(100) NULL
)
GO

ALTER TABLE sign 
ADD CONSTRAINT xpksign PRIMARY KEY CLUSTERED (signid)
GO

CREATE TABLE va_svr (
       svrid                VARCHAR(10) NOT NULL,
       name                 VARCHAR(100) NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       ssoflag              CHAR(1) DEFAULT '?' NOT NULL,
       sslflag              CHAR(1) DEFAULT '?' NOT NULL,
       anonymousflag        CHAR(1) DEFAULT '?' NOT NULL,
       connpoolcnt          INT DEFAULT 0 NOT NULL,
       svrport              INT DEFAULT 0 NOT NULL,
       svctype              VARCHAR(10) NOT NULL,
       ipaddr               VARCHAR(40) NULL,
       loginid              VARCHAR(1500) NULL,
       passwd               VARCHAR(150) NULL,
       guid                 VARCHAR(100) NULL,
       dscpt                VARCHAR(100) NULL,
       url                  VARCHAR(255) NULL,
       userdnsuffix         VARCHAR(255) NULL
)
GO

ALTER TABLE va_svr
ADD CONSTRAINT xpkva_svr PRIMARY KEY CLUSTERED (svrid)
GO

CREATE TABLE va_appmap (
       svrid                VARCHAR(10) NOT NULL,
       procid               INT NOT NULL DEFAULT 0,
       appinstid            INT NOT NULL DEFAULT 0,
       type                 CHAR(1) NOT NULL DEFAULT '?',
       mapid                INT NOT NULL DEFAULT 0,
       internalid           INT NOT NULL DEFAULT 0,
       lastappverseq        INT NOT NULL DEFAULT 0,
       dmver                VARCHAR(30) NOT NULL,
       dmsvrid              VARCHAR(10) NOT NULL,
       dmdocid              VARCHAR(500) NOT NULL,
       appsvrid             VARCHAR(10) NULL,
       appid                INT NULL DEFAULT 0
)
GO

ALTER TABLE va_appmap
ADD CONSTRAINT xpkva_appmap PRIMARY KEY CLUSTERED (procid, appinstid)
GO

CREATE TABLE va_appvermap (
       svrid                VARCHAR(10) NOT NULL,
       procid               INT NOT NULL DEFAULT 0,
       appinstid            INT NOT NULL DEFAULT 0,
       appverseq            INT NOT NULL DEFAULT 0,
       actseq               INT NOT NULL DEFAULT 0,
       actappseq            INT DEFAULT 0 NULL,
       mapid                INT NOT NULL DEFAULT 0,
       dmver                VARCHAR(30) NOT NULL,
       prtcp                VARCHAR(10) NOT NULL,
       dmsvrid              VARCHAR(10) NOT NULL,
       dmdocid              VARCHAR(500) NOT NULL,
       modifydtime          DATETIME NULL,
       appsvrid             VARCHAR(10) NULL,
       appid                INT NULL DEFAULT 0,
       dmverlabel           VARCHAR(100) NULL,
       prtcpname            VARCHAR(100) NULL
)
GO

ALTER TABLE va_appvermap
ADD CONSTRAINT xpkva_appvermap PRIMARY KEY CLUSTERED (procid, appinstid, appverseq)
GO

CREATE TABLE va_verlink (
       svrid                VARCHAR(10) NOT NULL,
       procid               INT NOT NULL DEFAULT 0,
       appinstid            INT NOT NULL DEFAULT 0,
       appverseqfrom        INT NOT NULL DEFAULT 0,
       appverseqto          INT NOT NULL DEFAULT 0
)
GO

ALTER TABLE va_verlink
ADD CONSTRAINT xpkva_verlink PRIMARY KEY CLUSTERED (procid, appinstid, appverseqfrom, 
              appverseqto)
GO


CREATE TABLE sso (  
       memberid             VARCHAR(10) NOT NULL,
       svcsvrid             VARCHAR(10) NOT NULL,
       svctype              VARCHAR(10) NOT NULL DEFAULT '?',
       loginid              VARCHAR(100) NULL,
       logininfo            VARCHAR(1000) NULL,
       ipaddr               VARCHAR(40) NULL,
       regdtime             DATETIME NULL
)
GO

ALTER TABLE sso
ADD CONSTRAINT xpksso PRIMARY KEY CLUSTERED (memberid, svcsvrid, svctype)
GO

CREATE TABLE orgmanagerlist (
       svrid                VARCHAR(10) NOT NULL,
       memberid             VARCHAR(10) NOT NULL,
       managerid            VARCHAR(10) NOT NULL,
       auth                 INT NOT NULL DEFAULT 0,
       disporder            INT NOT NULL DEFAULT 0,
       name                 VARCHAR(100) NOT NULL
)
GO

ALTER TABLE orgmanagerlist
ADD CONSTRAINT xpkorgmanagerlist PRIMARY KEY CLUSTERED (memberid, managerid ) 
GO

CREATE TABLE fldrmanagerlist (
       svrid                VARCHAR(10) NOT NULL,
       fldrid               INT NOT NULL DEFAULT 0,
       managerid            VARCHAR(10) NOT NULL,
       auth                 INT NOT NULL DEFAULT 0,
       disporder            INT NOT NULL DEFAULT 0,
       name                 VARCHAR(100) NOT NULL
)
GO

ALTER TABLE fldrmanagerlist
ADD CONSTRAINT xpkfldrmanagerlist PRIMARY KEY CLUSTERED (fldrid, managerid )
GO

CREATE INDEX xie1fldrmanagerlist ON fldrmanagerlist ( managerid )
GO

CREATE TABLE covelist (    
       type                 char(1) default '?' not null,
       id                   varchar(20) not null,
       ispublished          char(1) default 'F' not null,
       authmethod           char(1) default '?' not null,
       creationdtime        datetime not null,
       creator              varchar(10) not null,
       creatorname          varchar(100) not null,
       name                 varchar(100) not null,
       subclass             varchar(2) null,
       modifydtime          datetime null,
       modifier             varchar(10) null,
       modifiername         varchar(100) null,
       dscpt                varchar(255) null,
       etcinfo              varchar(1000) null,
       portletname          varchar(100) null,
       identitymap          varchar(255) null
)
GO

ALTER TABLE covelist ADD CONSTRAINT xpkcovelist PRIMARY KEY CLUSTERED (type, id )
GO

CREATE TABLE hwtemp
(
        tmpkey              VARCHAR(50),
        vara                VARCHAR(10),
        varb                VARCHAR(10),
        varc                VARCHAR(10),
        vard                VARCHAR(10),
        vare                VARCHAR(10)
)
GO

CREATE INDEX xie1hwtemp ON hwtemp (tmpkey)
GO

CREATE TABLE witemti (
       svrid                VARCHAR(10) NOT NULL,
       procid               INT NOT NULL DEFAULT 0,
       witemseq             INT NOT NULL DEFAULT 0,
       fromseq              INT NOT NULL DEFAULT 0,
       state                CHAR(1) NOT NULL DEFAULT '?',
       actseq               INT DEFAULT 0 NOT NULL,
	   dtime				DATETIME NULL
)
GO

ALTER TABLE witemti ADD CONSTRAINT xpkwitemti PRIMARY KEY CLUSTERED (procid, witemseq, fromseq)
GO

CREATE INDEX xie1witemti ON witemti (procid, fromseq)
GO

create table calhead (
       memberid             VARCHAR(10) NOT NULL,
       dayofweek            CHAR(1) DEFAULT '?' NOT NULL,
       isdefault            char(1) not null default '?',
       daytype              char(1) not null default '?',
       tzsign               CHAR(1) DEFAULT '?' NOT NULL,
       tzid                 INT NOT NULL DEFAULT 0,
       dstid	            INT NOT NULL DEFAULT 0,
       timediff             INT NOT NULL DEFAULT 0,
       totdaywtime          INT NOT NULL DEFAULT 0,
       sworktime1           INT NOT NULL DEFAULT 0,
       eworktime1           INT NOT NULL DEFAULT 0,
       sworktime2           INT NULL DEFAULT 0,
       eworktime2           INT NULL DEFAULT 0,
       sworktime3           INT NULL DEFAULT 0,
       eworktime3           INT NULL DEFAULT 0,
       sworktime4           INT NULL DEFAULT 0,
       eworktime4           INT NULL DEFAULT 0,
       sworktime5           INT NULL DEFAULT 0,
       eworktime5           INT NULL DEFAULT 0,
       dscpt                VARCHAR(100) NULL
)


ALTER TABLE calhead
ADD CONSTRAINT xpkcalhead PRIMARY KEY CLUSTERED (memberid, dayofweek)

CREATE TABLE dst (
       dstid                int default 0 not null,
       year                 int default 0 not null,
       sign                 char(1) not null,
       timediff             int default 0 not null,
       startdtime           datetime not null,
       enddtime             datetime not null
)

ALTER TABLE dst
ADD CONSTRAINT xpkdst PRIMARY KEY CLUSTERED (dstid, year)

CREATE TABLE membercal (
       memberid             varchar(10) not null,
       caldtime             datetime not null,
       isdefault            char(1) not null default '?',
       daytype              char(1) not null default '?',
       dayofweek            char(1) not null default '?',
       totdaywtime          INT NOT NULL DEFAULT 0,
       sworktime1           INT NULL DEFAULT 0,
       eworktime1           INT NULL DEFAULT 0,
       sworktime2           INT NULL DEFAULT 0,
       eworktime2           INT NULL DEFAULT 0,
       sworktime3           INT NULL DEFAULT 0,
       eworktime3           INT NULL DEFAULT 0,
       sworktime4           INT NULL DEFAULT 0,
       eworktime4           INT NULL DEFAULT 0,
       sworktime5           INT NULL DEFAULT 0,
       eworktime5           INT NULL DEFAULT 0,
       dscpt                VARCHAR(100) NULL
)


ALTER TABLE membercal
ADD CONSTRAINT xpkmembercal PRIMARY KEY CLUSTERED (memberid, caldtime)

CREATE TABLE mdtmplt (
       svrid                varchar(10) NOT NULL,
       mdtmpltid            int DEFAULT 0 NOT NULL,
       isfinal              CHAR(1) DEFAULT '?' NOT NULL,
       type                 CHAR(1) DEFAULT '?' NOT NULL,
       parentmdtmpltid      int DEFAULT 0 NOT NULL,
       orgmdtmpltid         int DEFAULT 0 NOT NULL,
       mdtmpltver           int DEFAULT 1 NOT NULL,
       fldrid               int DEFAULT 0 NOT NULL,
       name                 varchar(100) NOT NULL,
       dscpt                varchar(100) NULL,
       chkincmnt            varchar(500) NULL
)
GO

ALTER TABLE mdtmplt ADD CONSTRAINT xpkmdtmplt PRIMARY KEY CLUSTERED (mdtmpltid)
GO

CREATE UNIQUE nonclustered INDEX xak1mdtmplt ON mdtmplt (orgmdtmpltid, mdtmpltver)
GO

CREATE TABLE mditem (
       svrid                varchar(10) NOT NULL,
       mdtmpltid            int DEFAULT 0 NOT NULL,
       mditemseq            int DEFAULT 0 NOT NULL,
       objtype              CHAR(1) DEFAULT '?' NOT NULL,
       objsubtype           CHAR(1) DEFAULT '?' NOT NULL,
       valuetype            CHAR(1) DEFAULT '?' NOT NULL,
       mdinfo               int DEFAULT 0 NOT NULL,
       name                 varchar(100) NOT NULL,
       value                varchar(255) NULL,
       dscpt                varchar(100) NULL
)
GO

ALTER TABLE mditem ADD CONSTRAINT xpkmditem PRIMARY KEY clustered (mdtmpltid, mditemseq)
GO

CREATE TABLE parentmdtmplt (
       svrid                varchar(10) NOT NULL,
       parentmdtmpltid      int DEFAULT 0 NOT NULL,
       mdtmpltid            int DEFAULT 0 NOT NULL,
       dirty                CHAR(1) DEFAULT '?' NOT NULL
)
GO

ALTER TABLE parentmdtmplt ADD CONSTRAINT xpkparentmdtmplt PRIMARY KEY clustered (parentmdtmpltid, mdtmpltid)
GO

CREATE TABLE mdatadef (
       svrid                varchar(10) NOT NULL,
       procdefid            int DEFAULT 0 NOT NULL,
       mdatadefseq          int DEFAULT 0 NOT NULL,
       objtype              CHAR(1) DEFAULT '?' NOT NULL,
       objsubtype           CHAR(1) DEFAULT '?' NOT NULL,
       valuetype            CHAR(1) DEFAULT '?' NOT NULL,
       objseq               int DEFAULT 0 NOT NULL,
       mdinfo               int DEFAULT 0 NOT NULL,
       orgmdtmpltid         int DEFAULT 0 NOT NULL,
       mditemseq            int DEFAULT 0 NOT NULL,
       name                 varchar(100) NULL,
       dscpt                varchar(100) NULL,
       value                varchar(255) NULL
)
GO

ALTER TABLE mdatadef ADD CONSTRAINT xpkmdatadef PRIMARY KEY clustered (procdefid, mdatadefseq)
GO

CREATE TABLE mdata (
       svrid                varchar(10) NOT NULL,
       procid               int DEFAULT 0 NOT NULL,
       mdataseq             int DEFAULT 0 NOT NULL,
       objtype              CHAR(1) DEFAULT '?' NOT NULL,
       objsubtype           CHAR(1) DEFAULT '?' NOT NULL,
       valuetype            CHAR(1) DEFAULT '?' NOT NULL,
       objseq               int DEFAULT 0 NOT NULL,
       mdinfo               int DEFAULT 0 NOT NULL,
       orgmdtmpltid         int DEFAULT 0 NOT NULL,
       mditemseq            int DEFAULT 0 NOT NULL,
       name                 varchar(100) NULL,
       dscpt                varchar(100) NULL,
       indexvalue           NVARCHAR(100) NULL,
       value                varchar(2000) NULL
)
GO

ALTER TABLE mdata ADD CONSTRAINT xpkmdata PRIMARY KEY clustered (procid, mdataseq)
GO
CREATE INDEX xie1mdata ON mdata (objtype, indexvalue)
GO

CREATE TABLE publishfldr (
       svrid                varchar(10) NOT NULL,
       fldrid               int DEFAULT 0 NOT NULL,
       publishfldrid        int DEFAULT 0 NOT NULL
)
GO

ALTER TABLE publishfldr ADD CONSTRAINT xpkpublishfldr PRIMARY KEY CLUSTERED (fldrid, publishfldrid)
GO

CREATE TABLE enumdata (
       svrid                varchar(10) NOT NULL,
       mdtmpltid            int DEFAULT 0 NOT NULL,
       mditemseq            int DEFAULT 0 NOT NULL,
       enumdataseq          int DEFAULT 0 NOT NULL,
       value                varchar(255) NULL
)
GO

ALTER TABLE enumdata ADD CONSTRAINT xpkenumdata PRIMARY KEY CLUSTERED (mdtmpltid, mditemseq, enumdataseq)
GO

CREATE TABLE ldapauditinfo (
       packageid            int DEFAULT 0 NOT NULL,
       execseq              int DEFAULT 0 NOT NULL,
       state                CHAR(1) DEFAULT '?' NULL,
       importer             VARCHAR(10) NOT NULL,
       importdtime          DATETIME NOT NULL,
       importername         VARCHAR(100) NOT NULL
)
GO

ALTER TABLE ldapauditinfo ADD CONSTRAINT xpkldapauditinfo PRIMARY KEY CLUSTERED (packageid, execseq)
GO

CREATE TABLE actloopdef (
       svrid                VARCHAR(10) NOT NULL,
       procdefid            int DEFAULT 0 NOT NULL,
       actdefseq            int DEFAULT 0 NOT NULL,
       testtime             CHAR(1) DEFAULT '?' NOT NULL,
       miordering           CHAR(1) DEFAULT '?' NOT NULL,
       miflowtype           CHAR(1) DEFAULT '?' NOT NULL,
       loopcnt              int DEFAULT 0 NOT NULL,
       loopmaxcnt           int DEFAULT 0 NOT NULL,
       conddefseq           int DEFAULT 0 NOT NULL,
       miflowconddefseq     int DEFAULT 0 NOT NULL
)
GO

ALTER TABLE actloopdef ADD CONSTRAINT xpkactloopdef PRIMARY KEY CLUSTERED (procdefid, actdefseq)
GO

CREATE TABLE actloop (
       svrid                VARCHAR(10) NOT NULL,
       procid               int DEFAULT 0 NOT NULL,
       actseq               int DEFAULT 0 NOT NULL,
       testtime             CHAR(1) DEFAULT '?' NOT NULL,
       miordering           CHAR(1) DEFAULT '?' NOT NULL,
       miflowtype           CHAR(1) DEFAULT '?' NOT NULL,
       loopcnt              int DEFAULT 0 NOT NULL,
       loopmaxcnt           int DEFAULT 0 NOT NULL,
       condseq              int DEFAULT 0 NOT NULL,
       miflowcondseq        int DEFAULT 0 NOT NULL
)
GO

ALTER TABLE actloop ADD CONSTRAINT xpkactloop PRIMARY KEY CLUSTERED (procid, actseq)
GO

CREATE TABLE eventdef (
       svrid                VARCHAR(10) NOT NULL,
       procdefid            int DEFAULT 0 NOT NULL,
       actdefseq            int DEFAULT 0 NOT NULL,
       eventdefseq          int DEFAULT 0 NOT NULL,
       triggerpoint         CHAR(1) DEFAULT '?' NOT NULL,
       eventtype            CHAR(1) DEFAULT '?' NOT NULL,
       msgimpltype          CHAR(1) DEFAULT '?' NOT NULL,
       sendapp              CHAR(1) DEFAULT 'F' NOT NULL,
       sendattach           CHAR(1) DEFAULT 'F' NOT NULL,
       sendcmnt             CHAR(1) DEFAULT 'F' NOT NULL,
       timertype            CHAR(1) DEFAULT '?' NOT NULL,
       tonode               int DEFAULT 0 NULL,
       transdefseq          int DEFAULT 0 NULL,
       startactdefseq       int DEFAULT 0 NULL,
       timertime            int DEFAULT 0 NULL,
       rlvntdatadefseq      int DEFAULT 0 NULL,
       subsvrid             VARCHAR(10) NULL,
       subprocdefid         int DEFAULT 0 NULL,
       suborgprocdefid      int DEFAULT 0 NULL,
       dscpt                VARCHAR(100) NULL,
       linkid               VARCHAR(20) NULL,
       eraid                VARCHAR(20) NULL
)
GO

ALTER TABLE eventdef ADD CONSTRAINT xpkeventdef PRIMARY KEY CLUSTERED (procdefid, actdefseq, eventdefseq)
GO

CREATE TABLE event (
       svrid                VARCHAR(10) NOT NULL,
       procid               int DEFAULT 0 NOT NULL,
       actseq               int DEFAULT 0 NOT NULL,
       eventseq             int DEFAULT 0 NOT NULL,
       triggerpoint         CHAR(1) DEFAULT '?' NOT NULL,
       eventtype            CHAR(1) DEFAULT '?' NULL,
       msgimpltype          CHAR(1) DEFAULT '?' NULL,
       sendapp              CHAR(1) DEFAULT 'F' NOT NULL,
       sendattach           CHAR(1) DEFAULT 'F' NOT NULL,
       sendcmnt             CHAR(1) DEFAULT 'F' NOT NULL,
       timertype            CHAR(1) DEFAULT '?' NOT NULL,
       tonode               int DEFAULT 0 NULL,
       transseq             int DEFAULT 0 NULL,
       startactseq          int DEFAULT 0 NULL,
       timertime            int DEFAULT 0 NULL,
       rlvntdataseq         int DEFAULT 0 NULL,
       subsvrid             VARCHAR(10) NULL,
       subprocdefid         int DEFAULT 0 NULL,
       suborgprocdefid      int DEFAULT 0 NULL,
       dscpt                VARCHAR(100) NULL,
       linkid               VARCHAR(255) NULL,
       eraid                VARCHAR(20) NULL
)
GO

ALTER TABLE event ADD CONSTRAINT xpkevent PRIMARY KEY CLUSTERED (procid, actseq, eventseq)
GO


CREATE TABLE queueprocs
(
       qid                  varchar(10) not null,
       queueseq             int not null,
       urgent               char(1),
       passwdflag           char(1),
       parentacttype        char(1),
       qstate               char(1),
       orgprocdefid         int,
       parentprocid         int,
       parentactseq         int,
       instfldrid           int,
       archivefldrid        int,
       sendwitemtoclient    int,
       qattachcnt           int,
       qrlvntdatafilecnt    int,
       errno                int,
       creationdtime        datetime,
       orgsvrid             varchar(10),
       clientip             varchar(40),
       userid               varchar(10),
       svrid                varchar(10),
       defsvrid             varchar(10),
       parentsvrid          varchar(10),
       creator              varchar(10),
       sessioninfo          varchar(100),
       name                 varchar(100),
       dscpt                varchar(255),
       customid             varchar(255),
       qattach              varchar(512),
       qrlvntdatafile       varchar(512),
       errmsg               varchar(512)
)
GO
  
ALTER TABLE queueprocs ADD CONSTRAINT xpkqueueprocs PRIMARY KEY CLUSTERED (qid, queueseq)
GO

CREATE TABLE queuewitem
(
       qid                  varchar(10) not null,
       queueseq             int not null,
       qstate               char(1),
       procid               int,
       actseq               int,
       witemseq             int,
       response             int,
       cmpltmode            int,
       witemappfilecnt      int,
       attachfilecnt        int,
       execsqllen           int,
       wfilenamecnt         int,
       errno                int,
       creationdtime        datetime,
       clientip             varchar(40),
       userid               varchar(10),
       svrid                varchar(10),
       sessioninfo          varchar(100),
       witemappfile         varchar(256),
       attachfile           varchar(256),
       subprocfile          varchar(256),
       repsignfile          varchar(256),
       rscmntfile           varchar(256),
       wfilename            varchar(256),
       execsql              varchar(512),
       errmsg               varchar(512)
)
GO

ALTER TABLE queuewitem ADD CONSTRAINT xpkqueuewitem PRIMARY KEY CLUSTERED (qid, queueseq)
GO

CREATE TABLE cpdef (       
       svrid                VARCHAR(10) NOT NULL,
       procdefid            INT DEFAULT 0 NOT NULL,
       cpdefseq             INT DEFAULT 0 NOT NULL,
       value                VARCHAR(2000) NOT NULL
)
GO

ALTER TABLE cpdef
ADD CONSTRAINT xpkcpdef PRIMARY KEY CLUSTERED (procdefid, cpdefseq)
GO


CREATE TABLE cp (
       svrid                VARCHAR(10) NOT NULL,
       procid               INT DEFAULT 0 NOT NULL,
       cpseq                INT DEFAULT 0 NOT NULL,
       value                VARCHAR(2000) NOT NULL,
       day                  INT DEFAULT 0 NULL,
       create_dt            DATETIME NULL DEFAULT (getdate())
)
GO

ALTER TABLE cp
ADD CONSTRAINT xpkcp PRIMARY KEY CLUSTERED (procid, cpseq)
GO

CREATE TABLE tabdef (
       svrid                VARCHAR(10) NOT NULL,
       tabdefid             INT DEFAULT 0 NOT NULL,
       method               CHAR(1) NOT NULL DEFAULT '?',
       name                 VARCHAR(100) NOT NULL,
       dscpt                VARCHAR(255) NULL,
       url                  VARCHAR(500) NULL
)
GO

ALTER TABLE tabdef
ADD CONSTRAINT xpktabdef PRIMARY KEY CLUSTERED (tabdefid)
GO

CREATE TABLE tabparamdef (
       svrid                VARCHAR(10) NOT NULL,
       tabdefid             INT DEFAULT 0 NOT NULL,
       paramseq             INT DEFAULT 0 NOT NULL,
       name                 VARCHAR(100) NOT NULL,
       value                VARCHAR(100) NULL,
       dscpt                VARCHAR(255) NULL
)
GO

ALTER TABLE tabparamdef
ADD CONSTRAINT xpktabparamdef PRIMARY KEY CLUSTERED (tabdefid, paramseq)
GO

CREATE TABLE proctabdef (
       svrid                VARCHAR(10) NOT NULL,
       orgprocdefid         INT DEFAULT 0 NOT NULL,
       type                 CHAR(1) NOT NULL DEFAULT '?',
       tabdefid             INT DEFAULT 0 NOT NULL,
       disporder            INT DEFAULT 0 NOT NULL,
       show                 CHAR(1) NOT NULL DEFAULT '?'
)
GO

ALTER TABLE proctabdef
ADD CONSTRAINT xpkproctabdef PRIMARY KEY CLUSTERED (orgprocdefid, type, tabdefid)
GO

CREATE TABLE installstatus (
       ver                  VARCHAR(50) NOT NULL,
       vara					VARCHAR(50) NULL,
       modifydtime          DATETIME NOT NULL DEFAULT (getdate())
)
GO

ALTER TABLE installstatus
ADD CONSTRAINT xpkinstallstatus PRIMARY KEY CLUSTERED (ver)
GO

CREATE TABLE account (
       id                   INT NOT NULL IDENTITY (1, 1),
       name                 VARCHAR(100) NOT NULL,
       state                VARCHAR(2) NOT NULL,
       phone                VARCHAR(20) NOT NULL,
       account_number       VARCHAR(50) NOT NULL,
       dob                  DATETIME NULL
)
GO

ALTER TABLE account
ADD CONSTRAINT xpkaccount PRIMARY KEY CLUSTERED (id)
GO

CREATE INDEX xie1account ON account (name)
GO

CREATE TABLE states (
        state               VARCHAR(2) NOT NULL
)
GO

ALTER TABLE states
ADD CONSTRAINT xpkstates PRIMARY KEY CLUSTERED (state)
GO

CREATE TABLE preference (
       memberid             VARCHAR(10) NOT NULL,
       section              VARCHAR(50) NOT NULL,
       param                VARCHAR(50) NOT NULL,
       value                VARCHAR(200) NULL,
       ressection           VARCHAR(50) NULL,
       resid                VARCHAR(50) NULL
)
GO
ALTER TABLE preference
ADD CONSTRAINT xpkprefrence PRIMARY KEY CLUSTERED (memberid, section, param)
GO

CREATE TABLE device (
       memberid             VARCHAR(10) NOT NULL,
       deviceuuid           VARCHAR(50) NOT NULL,
       devicename           VARCHAR(100) NOT NULL,
       devicecert	        VARCHAR(1000) NOT NULL,
       devicephonegap       VARCHAR(50)  NULL,
       deviceplatform       VARCHAR(50) NULL,
       deviceversion        VARCHAR(10) NULL,
       registerkey          VARCHAR(50) NOT NULL,
       registerdate         DATETIME NOT NULL DEFAULT (getdate()),
       state                CHAR(1)NOT NULL DEFAULT 'A'
)
GO

ALTER TABLE device
ADD CONSTRAINT xpkdevice PRIMARY KEY CLUSTERED (memberid, deviceuuid)
GO

CREATE TABLE map_app2wsa (
       svr_id               VARCHAR(10) NOT NULL,
       app_id               INT NOT NULL,
       wsdl_desc            VARCHAR(1024) NULL,
       wsdl_url             VARCHAR(1024) NOT NULL,
       service              VARCHAR(100) NOT NULL,
       port                 VARCHAR(100) NOT NULL,
       operation            VARCHAR(100) NOT NULL,
       soap_endpoint        VARCHAR(1024),
       username             VARCHAR(100),
       password             VARCHAR(150)
)
GO

ALTER TABLE map_app2wsa
ADD CONSTRAINT xpkmap_app2wsa PRIMARY KEY CLUSTERED (svr_id, app_id)
GO

CREATE TABLE reqlist (
       memberid             VARCHAR(10) NOT NULL,
       reqtype              VARCHAR(10) NOT NULL,
       reqsubtype           VARCHAR(10) NOT NULL DEFAULT 'NONE',
       ipaddr               VARCHAR(40) NOT NULL DEFAULT '127.000.000.001',
       reqkey               VARCHAR(100) NULL,
       reqinfo              VARCHAR(4000) NOT NULL,
       reqdtime             DATETIME NOT NULL DEFAULT (getdate())
)
GO

ALTER TABLE reqlist
ADD CONSTRAINT xpkreqlist PRIMARY KEY CLUSTERED (memberid, reqtype, reqsubtype)
GO

CREATE INDEX xie1reqlist ON reqlist (reqdtime)
GO

CREATE TABLE password (
       memberid             VARCHAR(10) NOT NULL,
       seq                  INT NOT NULL IDENTITY(1,1),
       passwd               VARCHAR(150) NOT NULL,
       lastuseddtime        DATETIME NOT NULL DEFAULT (getdate())
)
GO

ALTER TABLE password
ADD CONSTRAINT xpkpassword PRIMARY KEY CLUSTERED (memberid, seq)
GO

CREATE TABLE configuration (
       section              VARCHAR(100) NOT NULL,
       entry                VARCHAR(100) NOT NULL,
       value                VARCHAR(2000) NULL,
       description          VARCHAR(2000) NULL
)
GO

ALTER TABLE configuration
ADD CONSTRAINT xpkconfiguration PRIMARY KEY CLUSTERED (section, entry)
GO

CREATE TABLE templatefile (
       svrid                VARCHAR(10) NOT NULL,
       tmpltid              INT NOT NULL IDENTITY(1,1),
       mediatype            NVARCHAR(100) NOT NULL,
       code                 NVARCHAR(100) NOT NULL,
       name                 NVARCHAR(256) NOT NULL,
       filename             NVARCHAR(256) NOT NULL,
       creator              VARCHAR(10) NOT NULL,
       creatorname          VARCHAR(100) NULL,
       creationdtime        DATETIME NULL,
       modifier             VARCHAR(10) NULL,
       modifiername         VARCHAR(100) NULL,
       modifydtime          DATETIME NULL,
       dscpt                NVARCHAR(100) NULL,
       content              VARBINARY(MAX) NULL
)
GO

ALTER TABLE templatefile
ADD CONSTRAINT xpktemplatefile PRIMARY KEY CLUSTERED (tmpltid)
GO

CREATE INDEX xie1templatefile ON templatefile (name)
GO

CREATE TABLE templatefiletag (
       tmpltid              INT NOT NULL,
       tagseq               INT NOT NULL,
       tag                  NVARCHAR(100) NOT NULL
)
GO

ALTER TABLE templatefiletag
ADD CONSTRAINT xpktemplatefiletag PRIMARY KEY CLUSTERED (tmpltid, tagseq)
GO

CREATE INDEX xie1templatefiletag ON templatefiletag (tag)
GO

CREATE TABLE procslink (
       svrid                VARCHAR(10) NOT NULL,
       procid               INT NOT NULL DEFAULT 0,
       linkedprocid         INT NOT NULL DEFAULT 0,
       creationdtime        DATETIME NOT NULL,
       creator              VARCHAR(10) NOT NULL,
       creatorname          VARCHAR(100) NOT NULL
)
go

ALTER TABLE procslink
ADD CONSTRAINT xpkprocslink PRIMARY KEY CLUSTERED (procid, linkedprocid)
go
create index xie1procslink on procslink ( linkedprocid )
go

insert into ver(ver) values ('12.4.0.0000.00')
GO
