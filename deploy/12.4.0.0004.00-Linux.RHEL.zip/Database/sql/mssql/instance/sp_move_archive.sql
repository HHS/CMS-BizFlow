if exists (select * from dbo.sysobjects where id = object_id(N'[dbo].[sp_move_archive]'))
drop procedure [dbo].[sp_move_archive]
go

create procedure sp_move_archive
(
	@i_link_to_archive varchar(100),
	@i_svrid varchar(10),
	@i_procid int
)
as
--
-- 12.4.0.4
--
begin
    set nocount on 
	
	-- MSSQL:
	-- Syntax for %ARCHIVE_DATABASE_LINK%: <server_name_for_bizflow_archive_database>.<db_name>.<owner>
	-- An example: servername.bizflowarchive.dbo

	-- Oracle:
	-- Syntax for %ARCHIVE_DATABASE_LINK%: <conn_string_for_bizflow_archive_database>
	-- An example: procs@bizflowarchive

	declare @l_procdefid	integer
	declare @l_cnt			integer
	declare @taskid			int
	declare @l_sql			nvarchar(4000)

	select @l_procdefid = preprocdefid from procs where procid = @i_procid;

	set @l_sql = 'select @_count = count(1) from ' + @i_link_to_archive + '.procdef where procdefid = @_procdefid'
	exec sp_executesql @l_sql, N'@_procdefid int, @_count int output', @_procdefid = @l_procdefid, @_count = @l_cnt output

	if(@l_cnt = 0)
	begin
		set @l_sql =
		'insert into ' + @i_link_to_archive + '.procdef (
			svrid, 
			procdefid, 
			verctrltype, 
			isfinal, 
			envtype, 
			deadlinetype, 
			subproctype,
			passwdflag, 
			publicationstate,
			pkitype, 
			caltype, 
			dmsaveflag, 
			dmidtype, 
			fldrsvrid, 
			fldrid, 
			prjfldrid,
			orgprocdefid, 
			ver, 
			procauth, 
			instfldrid, 
			archivefldrid, 
			orgmdtmpltid, 
			name, 
			deadline, 
			creationdtime,
			creator, 
			creatorname, 
			creatordeptname, 
			usrgrphid, 
			calmemberid, 
			presvrid, 
			preprocdefid, 
			checkoutusr,
			modifydtime, 
			modifier, 
			modifiername, 
			dmsvrid, 
			publishdtime, 
			publisher, 
			publishername, 
			dmfldrid, 
			dscpt, 
			chkincmnt)
		select 	svrid, 
			procdefid, 
			verctrltype, 
			isfinal, 
			envtype, 
			deadlinetype, 
			subproctype,
			passwdflag, 
			publicationstate,
			pkitype, 
			caltype, 
			dmsaveflag, 
			dmidtype, 
			fldrsvrid, 
			fldrid, 
			prjfldrid,
			orgprocdefid, 
			ver, 
			procauth, 
			instfldrid, 
			archivefldrid, 
			orgmdtmpltid, 
			name, 
			deadline, 
			creationdtime,
			creator, 
			creatorname, 
			creatordeptname, 
			usrgrphid, 
			calmemberid, 
			presvrid, 
			preprocdefid, 
			checkoutusr,
			modifydtime, 
			modifier, 
			modifiername, 
			dmsvrid, 
			publishdtime, 
			publisher, 
			publishername, 
			dmfldrid, 
			dscpt, 
			chkincmnt
		from procdef where svrid = @_svrid and procdefid = @_procdefid'
		exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procdefid int', @_svrid = @i_svrid, @_procdefid = @l_procdefid
	end

	set @l_sql = 'select @_count = count(1) from ' + @i_link_to_archive + '.mdatadef where procdefid = @_procdefid'
	exec sp_executesql @l_sql, N'@_procdefid int, @_count int output', @_procdefid = @l_procdefid, @_count = @l_cnt output
	if(@l_cnt = 0)
	begin
		set @l_sql =
		'insert into ' + @i_link_to_archive + '.mdatadef (
			svrid,
			procdefid,
			mdatadefseq,
			objtype,
			objsubtype,
			valuetype,
			objseq,
			mdinfo,
			orgmdtmpltid,
			mditemseq,
			name,
			dscpt,
			value)
		select	svrid,
			procdefid,
			mdatadefseq,
			objtype,
			objsubtype,
			valuetype,
			objseq,
			mdinfo,
			orgmdtmpltid,
			mditemseq,
			name,
			dscpt,
			value
		 from mdatadef where svrid = @_svrid and procdefid = @_procdefid'
		exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procdefid int', @_svrid = @i_svrid, @_procdefid = @l_procdefid
	end

	set @l_sql =
	'insert into ' + @i_link_to_archive + '.procs (
		svrid, 
		procid, 
		urgent, 
		deadlinetype, 
		subproctype, 
		passwdflag,
		state, 
		dmsaveflag, 
		dmidtype, 
		caltype, 
		internalid, 
		cmntcnt, 
		attachcnt,
		orgprocdefid, 
		revisionid, 
		instfldrid, 
		ver, 
		archivefldrid, 
		name, 
		creationdtime, 
		creator, 
		creatorname, 
		deadline, 
		presvrid, 
		preprocdefid,
		preprocdefname, 
		usrgrphid, 
		calmemberid, 
		customid, 
		cmpltdtime, 
		deadlinedtime, 
		returnsvrid, 
		parentsvrid, 
		parentprocid, 
		parentactseq,
		parentacttype, 
		checkoutusr, 
		modifydtime, 
		modifier, 
		modifiername, 
		lastcorrespondence, 
		dmsvrid, 
		dmfldrid, 
		dscpt )
	select	svrid, 
		procid, 
		urgent, 
		deadlinetype, 
		subproctype, 
		passwdflag,
		state, 
		dmsaveflag, 
		dmidtype, 
		caltype, 
		internalid, 
		cmntcnt, 
		attachcnt,
		orgprocdefid, 
		revisionid, 
		instfldrid, 
		ver, 
		archivefldrid, 
		name, 
		creationdtime, 
		creator, 
		creatorname, 
		deadline, 
		presvrid, 
		preprocdefid,
		preprocdefname, 
		usrgrphid, 
		calmemberid, 
		customid, 
		cmpltdtime, 
		deadlinedtime, 
		returnsvrid, 
		parentsvrid, 
		parentprocid, 
		parentactseq,
		parentacttype, 
		checkoutusr, 
		modifydtime, 
		modifier, 
		modifiername, 
		lastcorrespondence, 
		dmsvrid, 
		dmfldrid, 
		dscpt 
	from procs where svrid = @_svrid and procid = @_procid'
	exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procid int', @_svrid = @i_svrid, @_procid = @i_procid

	set @l_sql =
	'insert into ' + @i_link_to_archive + '.act (
		svrid, 
		procid, 
		actseq, 
		type, 
		jointype, 
		casetype, 
		deadlinetype, 
		transtype, 
		caltype, 
		existinfofile, 
		existcmntrans, 
		isrepsign, 
		subproctype, 
		sendapp, 
		sendattach, 
		sendcmnt, 
		state, 
		prestate, 
		checkpostcond, 
		cmpltopt, 
		rbackopt, 
		eventtype, 
		actlooptype, 
		defsvrid, 
		defprocdefid, 
		name,
		priority, 
		actauth, 
		actinfo, 
		deadline, 
		respgrpseq, 
		respseq, 
		capacity, 
		cost, 
		providerid, 
		loopcnt, 
		cmpltcnt, 
		spcfromnode, 
		attaddcnt, 
		waitingtime,
		workingtime, 
		planstarttime, 
		plancmplttime, 
		subsvrid, 
		subprocdefid, 
		suborgprocdefid, 
		postcondseq, 
		mergecondseq, 
		splitcondseq, 
		dscpt, 
		resplist, 
		deadlinedtime,
		planstartdtime, 
		plancmpltdtime, 
		startdtime, 
		cmpltdtime )
	select	svrid, 
		procid, 
		actseq, 
		type, 
		jointype, 
		casetype, 
		deadlinetype, 
		transtype, 
		caltype, 
		existinfofile, 
		existcmntrans, 
		isrepsign, 
		subproctype, 
		sendapp, 
		sendattach, 
		sendcmnt, 
		state, 
		prestate, 
		checkpostcond, 
		cmpltopt, 
		rbackopt, 
		eventtype, 
		actlooptype, 
		defsvrid, 
		defprocdefid, 
		name,
		priority, 
		actauth, 
		actinfo, 
		deadline, 
		respgrpseq, 
		respseq, 
		capacity, 
		cost, 
		providerid, 
		loopcnt, 
		cmpltcnt, 
		spcfromnode, 
		attaddcnt, 
		waitingtime,
		workingtime, 
		planstarttime, 
		plancmplttime, 
		subsvrid, 
		subprocdefid, 
		suborgprocdefid, 
		postcondseq, 
		mergecondseq, 
		splitcondseq, 
		dscpt, 
		resplist, 
		deadlinedtime,
		planstartdtime, 
		plancmpltdtime, 
		startdtime, 
		cmpltdtime
	from act where svrid = @_svrid and procid = @_procid'
	exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procid int', @_svrid = @i_svrid, @_procid = @i_procid

	set @l_sql =
	'insert into ' + @i_link_to_archive + '.trans (
		svrid, 
		procid, 
		transseq, 
		state, 
		type, 
		iscmntrans, 
		fromnode, 
		tonode, 
		condseq, 
		actioncondseq, 
		loopcnt, 
		evalorder, 
		name )
	select	svrid, 
		procid, 
		transseq, 
		state, 
		type, 
		iscmntrans, 
		fromnode, 
		tonode, 
		condseq, 
		actioncondseq, 
		loopcnt, 
		evalorder, 
		name 
	from trans where svrid = @_svrid and procid = @_procid'
	exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procid int', @_svrid = @i_svrid, @_procid = @i_procid
	
	set @l_sql =
	'insert into ' + @i_link_to_archive + '.rlvntdata (
		svrid, 
		procid, 
		rlvntdataseq, 
		ispublic, 
		scope, 
		valuetype, 
		parentinouttype, 
		rlvntdataname, 
		dscpt, 
		dispvalue, 
		indexvalue, 
		value)
	select	svrid, 
		procid, 
		rlvntdataseq, 
		ispublic, 
		scope, 
		valuetype, 
		parentinouttype, 
		rlvntdataname, 
		dscpt, 
		dispvalue, 
		indexvalue, 
		value
	from rlvntdata where svrid = @_svrid and procid = @_procid and (scope = ''I'' or (scope = ''D'' and rlvntdataname not like ''#%''))'
	exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procid int', @_svrid = @i_svrid, @_procid = @i_procid

	set @l_sql =
	'insert into ' + @i_link_to_archive + '.cond (
		svrid, 
		procid, 
		condseq, 
		type, 
		dscpt, 
		expr)
	select	svrid, 
		procid, 
		condseq, 
		type, 
		dscpt, 
		expr 
	from cond where svrid = @_svrid and procid = @_procid'
	exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procid int', @_svrid = @i_svrid, @_procid = @i_procid

	set @l_sql =
	'insert into ' + @i_link_to_archive + '.procapp (
		svrid, 
		procid, 
		procappseq, 
		type, 
		sendtype, 
		keepingflag, 
		viewtype, 
		dmsaveflag, 
		dmidtype, 
		appsvrid, 
		appid, 
		orgappid, 
		appver, 
		disporder, 
		name, 
		rlvntdataseq, 
		invokedmethod, 
		extname, 
		dmsvrid, 
		dmfldrid, 
		dmdockind, 
		dscpt)
	select 	
		svrid, 
		procid, 
		procappseq, 
		type, 
		sendtype, 
		keepingflag, 
		viewtype, 
		dmsaveflag, 
		dmidtype, 
		appsvrid, 
		appid, 
		orgappid, 
		appver, 
		disporder, 
		name, 
		rlvntdataseq, 
		invokedmethod, 
		extname, 
		dmsvrid, 
		dmfldrid, 
		dmdockind, 
		dscpt
	from procapp where svrid = @_svrid and procid = @_procid'
	exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procid int', @_svrid = @i_svrid, @_procid = @i_procid

	set @l_sql =
	'insert into ' + @i_link_to_archive + '.actapp (
		svrid,
		procid,
		actseq,
		actappseq,
		updatable,
		initoption,
		viewtype,
		jobseq,
		procappseq,
		appsvrid,
		appid,
		appver,
		inrlvntdataseq,
		outrlvntdataseq,
		modifydtime)
	select	svrid,
		procid,
		actseq,
		actappseq,
		updatable,
		initoption,
		viewtype,
		jobseq,
		procappseq,
		appsvrid,
		appid,
		appver,
		inrlvntdataseq,
		outrlvntdataseq,
		modifydtime
	from actapp where svrid = @_svrid and procid = @_procid'
	exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procid int', @_svrid = @i_svrid, @_procid = @i_procid

	set @l_sql =
	'insert into ' + @i_link_to_archive + '.witemapp (
		svrid,
		procid,
		witemseq,
		witemappseq,
		state,
		pkitype,
		procappseq,
		actappseq,
		actseq,
		mapid,
		appver,
		appsvrid,
		appid,
		prtcp,
		prtcpname,
		modifydtime)
	select	svrid,
		procid,
		witemseq,
		witemappseq,
		state,
		pkitype,
		procappseq,
		actappseq,
		actseq,
		mapid,
		appver,
		appsvrid,
		appid,
		prtcp,
		prtcpname,
		modifydtime
	from witemapp where svrid = @_svrid and procid = @_procid'
	exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procid int', @_svrid = @i_svrid, @_procid = @i_procid

	set @l_sql =
	'insert into ' + @i_link_to_archive + '.param (
		svrid,
		procid,
		actseq,
		paramseq,
		inouttype,
		toscope,
		rlvntdataseq,
		disporder,
		todataname,
		const)
	select	svrid,
		procid,
		actseq,
		paramseq,
		inouttype,
		toscope,
		rlvntdataseq,
		disporder,
		todataname,
		const
	from param where svrid = @_svrid and procid = @_procid'
	exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procid int', @_svrid = @i_svrid, @_procid = @i_procid
	
	set @l_sql =
	'insert into ' + @i_link_to_archive + '.excpt (
		svrid,
		procid,
		excptseq,
		type,
		resptype,
		actseq,
		actappseq,
		incvalue,
		alertstarttime,
		alertduration,
		alertinterval,
		alertreceiver,
		email,
		exename,
		alertsubject,
		alertmsg)
	select	svrid,
		procid,
		excptseq,
		type,
		resptype,
		actseq,
		actappseq,
		incvalue,
		alertstarttime,
		alertduration,
		alertinterval,
		alertreceiver,
		email,
		exename,
		alertsubject,
		alertmsg
	from excpt where svrid = @_svrid and procid = @_procid'
	exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procid int', @_svrid = @i_svrid, @_procid = @i_procid

	set @l_sql =
	'insert into ' + @i_link_to_archive + '.cbdata (
		svrid,
		procid,
		actseq,
		providerid,
		mapid,
		callbackid)
	select	svrid,
		procid,
		actseq,
		providerid,
		mapid,
		callbackid
	from cbdata where svrid = @_svrid and procid = @_procid'
	exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procid int', @_svrid = @i_svrid, @_procid = @i_procid

	set @l_sql =
	'insert into ' + @i_link_to_archive + '.prtcp (
		svrid,
		procid,
		actseq,
		prtcpseq,
		kind,
		useflag,
		type,
		assignrule,
		existscriptfile,
		prtcpauth,
		prtcp,
		mapid,
		disporder,
		calmemberid,
		usrgrphid,
		deptname,
		jobtitlename,
		expr,
		prtcpname)
	select	svrid,
		procid,
		actseq,
		prtcpseq,
		kind,
		useflag,
		type,
		assignrule,
		existscriptfile,
		prtcpauth,
		prtcp,
		mapid,
		disporder,
		calmemberid,
		usrgrphid,
		deptname,
		jobtitlename,
		expr,
		prtcpname
	from prtcp where svrid = @_svrid and procid = @_procid'
	exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procid int', @_svrid = @i_svrid, @_procid = @i_procid

	set @l_sql =
	'insert into ' + @i_link_to_archive + '.witem (
		svrid,
		procid,
		witemseq,
		prtcptype,
		onasync,
		state,
		urgent,
		existinfofile,
		checkpostcond,
		actseq,
		priority,
		respgrpseq,
		respseq,
		deadline,
		prtcp,
		prtcpname,
		creationdtime,
		loopcnt,
		cmpltusr,
		calmemberid,
		startdtime,
		cmpltdtime,
		deadlinedtime,
		cmpltusrname,
		checkoutusr)
	select	svrid,
		procid,
		witemseq,
		prtcptype,
		onasync,
		state,
		urgent,
		existinfofile,
		checkpostcond,
		actseq,
		priority,
		respgrpseq,
		respseq,
		deadline,
		prtcp,
		prtcpname,
		creationdtime,
		loopcnt,
		cmpltusr,
		calmemberid,
		startdtime,
		cmpltdtime,
		deadlinedtime,
		cmpltusrname,
		checkoutusr
	from witem where svrid = @_svrid and procid = @_procid'
	exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procid int', @_svrid = @i_svrid, @_procid = @i_procid

	set @l_sql =
	'insert into ' + @i_link_to_archive + '.cmnt (
		svrid,
		procid,
		cmntseq,
		parentcmntseq,
		type,
		gettype,
		sendtype,
		witemseq,
		actseq,
		actname,
		creationdtime,
		creator,
		creatorname,
		modifydtime,
		jobtitleid,
		jobtitlename,
		deptid,
		deptname,
		contents)
	select	svrid,
		procid,
		cmntseq,
		parentcmntseq,
		type,
		gettype,
		sendtype,
		witemseq,
		actseq,
		actname,
		creationdtime,
		creator,
		creatorname,
		modifydtime,
		jobtitleid,
		jobtitlename,
		deptid,
		deptname,
		contents
	from cmnt where svrid = @_svrid and procid = @_procid'
	exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procid int', @_svrid = @i_svrid, @_procid = @i_procid

	set @l_sql =
	'insert into ' + @i_link_to_archive + '.attach (
		svrid,
		procid,
		attachseq,
		witemseq,
		correspondenceseq,
		type,
		sendtype,
		gettype,
		pkitype,
		dmdocrtype,
		actseq,
		mapid,
		creationdtime,
		creator,
		creatorname,
		attachsize,
		dispname,
		filename,
		actname,
		dmsvrid,
		dmdocid,
		dmdockind,
		dscpt,
		category,
		etcinfo)
	select	svrid,
		procid,
		attachseq,
		witemseq,
		correspondenceseq,
		type,
		sendtype,
		gettype,
		pkitype,
		dmdocrtype,
		actseq,
		mapid,
		creationdtime,
		creator,
		creatorname,
		attachsize,
		dispname,
		filename,
		actname,
		dmsvrid,
		dmdocid,
		dmdockind,
		dscpt,
		category,
		etcinfo
	from attach where svrid = @_svrid and procid = @_procid'
	exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procid int', @_svrid = @i_svrid, @_procid = @i_procid

	set @l_sql =
	'insert into ' + @i_link_to_archive + '.auditinfo (
		svrid,
		procid,
		execseq,
		event,
		objtype,
		objstate,
		execdtime,
		errno,
		actor,
		actorname,
		objname,
		objseq,
		witemappseq,
		respgrpseq,
		respseq,
		resp,
		appname,
		objdscpt)
	select	svrid,
		procid,
		execseq,
		event,
		objtype,
		objstate,
		execdtime,
		errno,
		actor,
		actorname,
		objname,
		objseq,
		witemappseq,
		respgrpseq,
		respseq,
		resp,
		appname,
		objdscpt
	from auditinfo where svrid = @_svrid and procid = @_procid'
	exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procid int', @_svrid = @i_svrid, @_procid = @i_procid

	set @l_sql =
	'insert into ' + @i_link_to_archive + '.grdauditinfo (
		svrid,
		grlvntdataid,
		execseq,
		procid,
		name,
		procname,
		modifydtime,
		modifier,
		modifiername,
		dispvalue,
		dscpt,
		value)
	select	svrid,
		grlvntdataid,
		execseq,
		procid,
		name,
		procname,
		modifydtime,
		modifier,
		modifiername,
		dispvalue,
		dscpt,
		value
	from grdauditinfo where svrid = @_svrid and procid = @_procid'
	exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procid int', @_svrid = @i_svrid, @_procid = @i_procid

	set @l_sql =
	'insert into ' + @i_link_to_archive + '.respgrp (
		svrid,
		procid,
		respgrpseq,
		name,
		dscpt)
	select	svrid,
		procid,
		respgrpseq,
		name,
		dscpt
	from respgrp where svrid = @_svrid and procid = @_procid'
	exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procid int', @_svrid = @i_svrid, @_procid = @i_procid
	
	set @l_sql =
	'insert into ' + @i_link_to_archive + '.resp (
		svrid,
		procid,
		respgrpseq,
		respseq,
		disporder,
		respinfo,
		name)
	select	svrid,
		procid,
		respgrpseq,
		respseq,
		disporder,
		respinfo,
		name
	from resp where svrid = @_svrid and procid = @_procid'
	exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procid int', @_svrid = @i_svrid, @_procid = @i_procid

	set @l_sql =
	'insert into ' + @i_link_to_archive + '.va_appmap (
		svrid,
		procid,
		appinstid,
		type,
		mapid,
		internalid,
		lastappverseq,
		dmver,
		dmsvrid,
		dmdocid,
		appsvrid,
		appid)
	select	svrid,
		procid,
		appinstid,
		type,
		mapid,
		internalid,
		lastappverseq,
		dmver,
		dmsvrid,
		dmdocid,
		appsvrid,
		appid
	from va_appmap where svrid = @_svrid and procid = @_procid'
	exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procid int', @_svrid = @i_svrid, @_procid = @i_procid

	set @l_sql =
	'insert into ' + @i_link_to_archive + '.va_appvermap (
		svrid,
		procid,
		appinstid,
		appverseq,
		actseq,
		actappseq,
		mapid,
		dmver,
		prtcp,
		dmsvrid,
		dmdocid,
		modifydtime,
		appsvrid,
		appid,
		dmverlabel,
		prtcpname)
	select	svrid,
		procid,
		appinstid,
		appverseq,
		actseq,
		actappseq,
		mapid,
		dmver,
		prtcp,
		dmsvrid,
		dmdocid,
		modifydtime,
		appsvrid,
		appid,
		dmverlabel,
		prtcpname
	from va_appvermap where svrid = @_svrid and procid = @_procid'
	exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procid int', @_svrid = @i_svrid, @_procid = @i_procid

	set @l_sql =
	'insert into ' + @i_link_to_archive + '.va_verlink (
		svrid,
		procid,
		appinstid,
		appverseqfrom,
		appverseqto)
	select	svrid,
		procid,
		appinstid,
		appverseqfrom,
		appverseqto
	from va_verlink where svrid = @_svrid and procid = @_procid'
	exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procid int', @_svrid = @i_svrid, @_procid = @i_procid

	set @l_sql =
	'INSERT INTO ' + @i_link_to_archive + '.Correspondence(SvrID,ProcID,CorrespondenceSeq,ActSeq,TaskID,SubTaskID,CreationDTime,ParentTaskID,OrgProcID,OrgActSeq,Type,mediatype,state,creator,creatorname,readDTime,reader,readername,registerdtime,registrant,registrantname,FromUser,ToUser,CCUser,SentDate,Subject,BodyContent, TmpltID)
	SELECT SvrID,ProcID,CorrespondenceSeq,ActSeq,TaskID,SubTaskID,CreationDTime,ParentTaskID,OrgProcID,OrgActSeq,Type,mediatype,state,creator,creatorname,readDTime,reader,readername,registerdtime,registrant,registrantname,FromUser,ToUser,CCUser,SentDate,Subject,BodyContent, TmpltID
	  FROM Correspondence 
	 WHERE svrid = @_svrid AND procid = @_procid'
	exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procid int', @_svrid = @i_svrid, @_procid = @i_procid

	set @l_sql =
	'INSERT INTO ' + @i_link_to_archive + '.procslink(svrid,procid,linkedprocid,creationdtime,creator,creatorname)
	SELECT svrid,procid,linkedprocid,creationdtime,creator,creatorname
	  FROM procslink 
	 WHERE svrid = @_svrid AND procid = @_procid'
	exec sp_executesql @l_sql, N'@_svrid varchar(10), @_procid int', @_svrid = @i_svrid, @_procid = @i_procid

	-- bug19726 OfficeEngine support for Archive database
	SELECT @l_cnt = Count(1) FROM CompleteTasks WHERE ProcID = @i_procid
	if (@l_cnt > 0)
		begin
			SELECT @taskid = TaskID FROM CompleteTasks WHERE ProcID = @i_procid

			set @l_sql =
			'INSERT INTO ' + @i_link_to_archive + '.CompleteTasks(TaskID,ProcID,ActSeq,finalrevieweractseq,AllActSeqs,
                   originatortype,Originator,OriginatorName,finalreviewertype,FinalReviewer,FinalReviewerName,Source,taskinitiatortype,
                   TaskInitiator,TaskInitiatorName,CreationDT,StartDate,DueDate,EndDate,Title,Description,Priority,Category1,Category2,
                   State,AssignorText1,AssignorLookup1,ver,customid,TaskInfoID,emailSender,showcorrespondence)
			SELECT TaskID,ProcID,ActSeq,finalrevieweractseq,AllActSeqs,originatortype,Originator,OriginatorName,finalreviewertype,FinalReviewer,
                   FinalReviewerName,Source,taskinitiatortype,TaskInitiator,TaskInitiatorName,CreationDT,StartDate,DueDate,EndDate,Title,
                   Description,Priority,Category1,Category2,State,AssignorText1,AssignorLookup1,ver,customid,TaskInfoID,emailSender,showcorrespondence
            FROM CompleteTasks 
            WHERE TaskID = @_taskid'
			exec sp_executesql @l_sql, N'@_taskid int', @_taskid = @taskid

			set @l_sql =
		    'INSERT INTO ' + @i_link_to_archive + '.CompleteSubTasks(TaskID,SubTaskID,ParentTaskID,ProcID,ActSeq,AllActSeqs,
                   TransSeq,alttransseq,ConnectorSeq,RouteBack,groupoption,WBS,taskinitiatortype ,TaskInitiator,TaskInitiatorName,initiateuser,
                   initiateusername,assigneetype,Assignee,AssigneeName,ExternalUser,StartDate,DueDate,EndDate,Title,Description,AllParentActSeqs,
                   InheritHistoryActSeqs,Priority,State,AssigneeText1,AssigneeLookup1,ver,customid,TaskInfoID,SubTaskInfoID,emailSender,showcorrespondence)
			SELECT TaskID,SubTaskID,ParentTaskID,ProcID,ActSeq,AllActSeqs,TransSeq,alttransseq,ConnectorSeq,RouteBack,groupoption,WBS,
                   taskinitiatortype,TaskInitiator,TaskInitiatorName,initiateuser,initiateusername,assigneetype,Assignee,AssigneeName,
                   ExternalUser,StartDate,DueDate,EndDate,Title,Description,AllParentActSeqs,InheritHistoryActSeqs,Priority,State,AssigneeText1,
                   AssigneeLookup1,ver,customid,TaskInfoID,SubTaskInfoID,emailSender,showcorrespondence
            FROM CompleteSubTasks 
            WHERE TaskID = @_taskid'
			exec sp_executesql @l_sql, N'@_taskid int', @_taskid = @taskid

			set @l_sql =
			'INSERT INTO ' + @i_link_to_archive + '.CompleteTasksAux(TaskID,customNumber1,customNumber2,customNumber3,customNumber4,customNumber5,customNumber6,customNumber7,customNumber8,customNumber9,customNumber10,customNumber11,customNumber12,customNumber13,customNumber14,customNumber15,customNumber16,customNumber17,customNumber18,customNumber19,customNumber20,customDate1,customDate2,customDate3,customDate4,customDate5,customDate6,customDate7,customDate8,customDate9,customDate10,customDate11,customDate12,customDate13,customDate14,customDate15,customDate16,customDate17,customDate18,customDate19,customDate20,customString1,customString2,customString3,customString4,customString5,customString6,customString7,customString8,customString9,customString10,customString11,customString12,customString13,customString14,customString15,customString16,customString17,customString18,customString19,customString20,customString21,customString22,customString23,customString24,customString25,customString26,customString27,customString28,customString29,customString30)
			SELECT TaskID,customNumber1,customNumber2,customNumber3,customNumber4,customNumber5,customNumber6,customNumber7,customNumber8,customNumber9,customNumber10,customNumber11,customNumber12,customNumber13,customNumber14,customNumber15,customNumber16,customNumber17,customNumber18,customNumber19,customNumber20,customDate1,customDate2,customDate3,customDate4,customDate5,customDate6,customDate7,customDate8,customDate9,customDate10,customDate11,customDate12,customDate13,customDate14,customDate15,customDate16,customDate17,customDate18,customDate19,customDate20,customString1,customString2,customString3,customString4,customString5,customString6,customString7,customString8,customString9,customString10,customString11,customString12,customString13,customString14,customString15,customString16,customString17,customString18,customString19,customString20,customString21,customString22,customString23,customString24,customString25,customString26,customString27,customString28,customString29,customString30
            FROM CompleteTasksAux 
            WHERE TaskID = @_taskid'
			exec sp_executesql @l_sql, N'@_taskid int', @_taskid = @taskid

			set @l_sql =
		    'INSERT INTO ' + @i_link_to_archive + '.CompleteSubTasksAux(TaskID,SubTaskID,customNumber1,customNumber2,customNumber3,customNumber4,customNumber5,customNumber6,customNumber7,customNumber8,customNumber9,customNumber10,customNumber11,customNumber12,customNumber13,customNumber14,customNumber15,customNumber16,customNumber17,customNumber18,customNumber19,customNumber20,customDate1,customDate2,customDate3,customDate4,customDate5,customDate6,customDate7,customDate8,customDate9,customDate10,customDate11,customDate12,customDate13,customDate14,customDate15,customDate16,customDate17,customDate18,customDate19,customDate20,customString1,customString2,customString3,customString4,customString5,customString6,customString7,customString8,customString9,customString10,customString11,customString12,customString13,customString14,customString15,customString16,customString17,customString18,customString19,customString20,customString21,customString22,customString23,customString24,customString25,customString26,customString27,customString28,customString29,customString30)
			SELECT TaskID,SubTaskID,customNumber1,customNumber2,customNumber3,customNumber4,customNumber5,customNumber6,customNumber7,customNumber8,customNumber9,customNumber10,customNumber11,customNumber12,customNumber13,customNumber14,customNumber15,customNumber16,customNumber17,customNumber18,customNumber19,customNumber20,customDate1,customDate2,customDate3,customDate4,customDate5,customDate6,customDate7,customDate8,customDate9,customDate10,customDate11,customDate12,customDate13,customDate14,customDate15,customDate16,customDate17,customDate18,customDate19,customDate20,customString1,customString2,customString3,customString4,customString5,customString6,customString7,customString8,customString9,customString10,customString11,customString12,customString13,customString14,customString15,customString16,customString17,customString18,customString19,customString20,customString21,customString22,customString23,customString24,customString25,customString26,customString27,customString28,customString29,customString30
            FROM CompleteSubTasksAux 
            WHERE TaskID = @_taskid'
			exec sp_executesql @l_sql, N'@_taskid int', @_taskid = @taskid

			set @l_sql =
			'INSERT INTO ' + @i_link_to_archive + '.CompleteResponses(TaskID,SubTaskID,AssigneeResponse,InitiatorResponse)
			SELECT TaskID,SubTaskID,AssigneeResponse,InitiatorResponse 
            FROM CompleteResponses 
            WHERE TaskID = @_taskid'
			exec sp_executesql @l_sql, N'@_taskid int', @_taskid = @taskid

			set @l_sql =
			'INSERT INTO ' + @i_link_to_archive + '.CompleteDTaskerAudit(TaskID,SubTaskID,Seq,FromName,FromGroupName,ToName,FromID,
                   FromGroupID,ToID,CreationDT,ValueType,Value)
			SELECT TaskID, SubTaskID,Seq,FromName,FromGroupName,ToName,FromID,FromGroupID,ToID,CreationDT,ValueType,Value 
            FROM CompleteDTaskerAudit 
            WHERE TaskID = @_taskid'
			exec sp_executesql @l_sql, N'@_taskid int', @_taskid = @taskid

			set @l_sql =
			'INSERT INTO ' + @i_link_to_archive + '.CompleteTaskAssociation(TaskID,SubTaskID,ProcID,ActSeq,WitemSeq)
			SELECT TaskID,SubTaskID,ProcID,ActSeq,WitemSeq 
            FROM CompleteTaskAssociation 
            WHERE TaskID = @_taskid'
			exec sp_executesql @l_sql, N'@_taskid int', @_taskid = @taskid

			set @l_sql =
			'INSERT INTO ' + @i_link_to_archive + '.completetaskprtcp(taskid,subtaskid,prtcp,type,kind,externaluser)
			SELECT taskid,subtaskid,prtcp,type,kind,externaluser
            FROM completetaskprtcp 
            WHERE TaskID = @_taskid'
			exec sp_executesql @l_sql, N'@_taskid int', @_taskid = @taskid

			set @l_sql =
			'INSERT INTO ' + @i_link_to_archive + '.completetaskapprovers(taskid,seq,type,prtcp,name)
			SELECT taskid,seq,type,prtcp,name
            FROM completetaskapprovers 
            WHERE TaskID = @_taskid'
			exec sp_executesql @l_sql, N'@_taskid int', @_taskid = @taskid
		end

	-- QuickProcess support for Archive database
	SELECT @l_cnt = Count(1) FROM plantask WHERE procid = @i_procid
	if (@l_cnt > 0)
		begin
			set @l_sql =
			'INSERT INTO ' + @i_link_to_archive + '.plantask(procid, taskid, disporder, stepname, duedtime, deadlinetype, deadline, allowcollab, allowmoretask, allowreject, allowgoaladd, allowgoaldelete, allowgoalcheck, allowflowedit, allowprocend, dscpt, instruction, prtcptype, prtcp, prtcpname, category1, category2, selfnote, rate, ratecmnt, reminderdtime, reminderstate, actseq)
			SELECT procid, taskid, disporder, stepname, duedtime, deadlinetype, deadline, allowcollab, allowmoretask, allowreject, allowgoaladd, allowgoaldelete, allowgoalcheck, allowflowedit, allowprocend, dscpt, instruction, prtcptype, prtcp, prtcpname, category1, category2, selfnote, rate, ratecmnt, reminderdtime, reminderstate, actseq
            FROM plantask 
            WHERE procid = @_procid'
			exec sp_executesql @l_sql, N'@_procid int', @_procid = @i_procid

			set @l_sql =
			'INSERT INTO ' + @i_link_to_archive + '.plangoal(goalid, name, disporder, state, creationdtime, creator, creatorname, modifydtime, modifier, modifiername, dscpt, procid, taskid)
			SELECT goalid, name, disporder, state, creationdtime, creator, creatorname, modifydtime, modifier, modifiername, dscpt, procid, taskid
            FROM plangoal 
            WHERE procid = @_procid'
			exec sp_executesql @l_sql, N'@_procid int', @_procid = @i_procid

			set @l_sql =
			'INSERT INTO ' + @i_link_to_archive + '.plantasklimitedassignee(procid, taskid, taskassigneeid, assigneetype, assignee, assigneename)
			SELECT procid, taskid, taskassigneeid, assigneetype, assignee, assigneename
            FROM plantasklimitedassignee 
            WHERE procid = @_procid'
			exec sp_executesql @l_sql, N'@_procid int', @_procid = @i_procid

			set @l_sql =
			'INSERT INTO ' + @i_link_to_archive + '.planprtcp(procid, prtcpkind, prtcpid, prtcptype, prtcp, prtcpname, cmnt)
			SELECT procid, prtcpkind, prtcpid, prtcptype, prtcp, prtcpname, cmnt
            FROM planprtcp 
            WHERE procid = @_procid'
			exec sp_executesql @l_sql, N'@_procid int', @_procid = @i_procid

			set @l_sql =
			'INSERT INTO ' + @i_link_to_archive + '.planreminder(procid, prtcpkind, prtcpid, taskid, reminderid, name, value, resid, type, days, hours, mins)
			SELECT procid, prtcpkind, prtcpid, taskid, reminderid, name, value, resid, type, days, hours, mins
            FROM planreminder 
            WHERE procid = @_procid'
			exec sp_executesql @l_sql, N'@_procid int', @_procid = @i_procid

			set @l_sql =
			'INSERT INTO ' + @i_link_to_archive + '.plantaskaux(procid, taskid, customnumber1, customnumber2, customnumber3, customnumber4, customnumber5, customnumber6, customnumber7, customnumber8, customdate1, customdate2, customdate3, customdate4, customdate5, customdate6, customdate7, customdate8, customstring1, customstring2, customstring3, customstring4, customstring5, customstring6, customstring7, customstring8, customstring9, customstring10, customstring11, customstring12)
			SELECT procid, taskid, customnumber1, customnumber2, customnumber3, customnumber4, customnumber5, customnumber6, customnumber7, customnumber8, customdate1, customdate2, customdate3, customdate4, customdate5, customdate6, customdate7, customdate8, customstring1, customstring2, customstring3, customstring4, customstring5, customstring6, customstring7, customstring8, customstring9, customstring10, customstring11, customstring12
            FROM plantaskaux 
            WHERE procid = @_procid'
			exec sp_executesql @l_sql, N'@_procid int', @_procid = @i_procid

			set @l_sql =
			'INSERT INTO ' + @i_link_to_archive + '.plansubtask(procid, taskid, subtaskid, name, duedtime, guidance, priority, fyi, showhistory)
			SELECT procid, taskid, subtaskid, name, duedtime, guidance, priority, fyi, showhistory
            FROM plansubtask 
            WHERE procid = @_procid'
			exec sp_executesql @l_sql, N'@_procid int', @_procid = @i_procid

			set @l_sql =
			'INSERT INTO ' + @i_link_to_archive + '.plansubtaskaux(procid, taskid, subtaskid, customnumber1, customnumber2, customnumber3, customnumber4, customnumber5, customnumber6, customnumber7, customnumber8, customdate1, customdate2, customdate3, customdate4, customdate5, customdate6, customdate7, customdate8, customstring1, customstring2, customstring3, customstring4, customstring5, customstring6, customstring7, customstring8, customstring9, customstring10, customstring11, customstring12)
			SELECT procid, taskid, subtaskid, customnumber1, customnumber2, customnumber3, customnumber4, customnumber5, customnumber6, customnumber7, customnumber8, customdate1, customdate2, customdate3, customdate4, customdate5, customdate6, customdate7, customdate8, customstring1, customstring2, customstring3, customstring4, customstring5, customstring6, customstring7, customstring8, customstring9, customstring10, customstring11, customstring12
            FROM plansubtaskaux 
            WHERE procid = @_procid'
			exec sp_executesql @l_sql, N'@_procid int', @_procid = @i_procid

			set @l_sql =
			'INSERT INTO ' + @i_link_to_archive + '.plansubtaskprtcp(procid, taskid, subtaskid, subtaskprtcpid, prtcptype, prtcp, prtcpname, kind, externaluser)
			SELECT procid, taskid, subtaskid, subtaskprtcpid, prtcptype, prtcp, prtcpname, kind, externaluser
            FROM plansubtaskprtcp 
            WHERE procid = @_procid'
			exec sp_executesql @l_sql, N'@_procid int', @_procid = @i_procid

		end

	return
	
error_return:
	raiserror ( 50817 , 16, 1) 
end

GO
