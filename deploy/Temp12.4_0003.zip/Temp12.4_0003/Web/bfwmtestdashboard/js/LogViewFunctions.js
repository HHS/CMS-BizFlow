var RUN_MODE = ((WinManager.connected == true) ? 'studio' : 'standalone');

dojo.require("dojo.cookie");

//associative array to map log types to their actual filenames
var logFiles = new Object();

/**
 * Calls the view log servlet to show the information for the specified log type.
 */
function loadLogType(type)
{
    var container = document.getElementById('mainContent');
    if (document.getElementById('morphyc_file_xml').value != '')
    {
        container.innerHTML = 'Loading Debugger trace...';

        var url = 'viewLogs?morphycFile='+URLencode(document.morphyc_dashboard.morphyc_file.value)+'&logType='+type;
        updateContentFromURI(url, container, null);

        var logFile = logFiles[type];
    }
    else
    {
        if (RUN_MODE=="studio")
            container.innerHTML = 'Debugger trace not yet available.<br/>Please perform a "<b>Run Test</b>" for your project and then press "<b>Refresh Debugger</b>" to view trace.';
        else
            container.innerHTML = 'Application Morphyc configuration file not found - Check the file exists.';
    }
}


/**
 * The sarissa updateContentFromURI method seems to only work correctly
 * cross browser if the xmlhttp responseXML property gets set.
 * I think this is reliant upon the content type of the server response being text/xml.
 * In our case, the platform sets text/html by default so this doesnt work.
 * This method just replicates some of the functionailty of the Sarissa one, but always tries to
 * parse the text response from the server, so should hopefully work correctly.
 */
function updateContentFromURI(url, container, transform, animate)
{
    var xmlhttp = new XMLHttpRequest();
    xmlhttp.open("GET", url, true);

    //prevent use of cache
    var oldage = "Sat, 1 Jan 2000 00:00:00 GMT";
    xmlhttp.setRequestHeader("If-Modified-Since", oldage);

    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4)
        {
            var xmlDoc = getXMLDocument(xmlhttp.responseText);
            if (animate)
                container.style.display = 'none';
            Sarissa.updateContentFromNode(xmlDoc, container, transform, null);
            if (animate)
                hyf.util.showComponent(container, true);
        }
    }

    xmlhttp.send();
}




/**
 * Shows the log entry tables for the specified node id
 */
function showLogs(nodeID)
{
    var num = 0;
    var elem = document.getElementById(nodeID + '_details' + num);
    while (elem != null)
    {
        hyf.util.toggleComponent(elem,null,true);
        hyf.util.toggleComponent(document.getElementById(nodeID + '_details' + num + '_placeholder'),null,true);
        ++num;
        elem = document.getElementById(nodeID + '_details' + num);
    }

    //check if we should add the border class to the last nested list
    var container = document.getElementById(nodeID + '_container');
    var lastIndex = -1;
    for (var i=0; i < container.childNodes.length; ++i)
    {
        if (container.childNodes.item(i).tagName == 'UL')
        {
            lastIndex = i;
        }
    }

    if (lastIndex != -1)
    {
        if ((container.childNodes.item(lastIndex).className == null) || (container.childNodes.item(lastIndex).className == ''))
        {
            container.childNodes.item(lastIndex).className = 'border';
        }
        else
        {
            container.childNodes.item(lastIndex).className = '';
        }
    }

    //update the button styling
    var button = document.getElementById(nodeID + '_expand_control');
    if (button.className == 'sectionCollapsed')
    {
        button.className = 'sectionExpanded';
        /*document.getElementById(nodeID).style.color = 'blue';*/
    }
    else
    {
        button.className = 'sectionCollapsed';
        /*document.getElementById(nodeID).style.color = 'black';*/
    }
}

function toggleDisplay(nodeID)
{
    hyf.util.toggleComponent(nodeID + '_container',null,true);

    var button = document.getElementById(nodeID + '_expand_control');
    var buttonSymbol = document.getElementById(nodeID + '_expand_control_symbol');
    if (buttonSymbol.innerHTML == '-')
    {
        buttonSymbol.innerHTML = '+';
        button.className = 'nodeCollapsed';
    }
    else
    {
        buttonSymbol.innerHTML = '-';
        button.className = 'nodeExpanded';
    }
}

function toggleLogTableDisplay(tableID)
{
    var button = document.getElementById(tableID + '_expand_control');
    if (button.className == 'sectionExpanded')
    {
        button.className = 'sectionCollapsed';
        button.innerHTML = 'Show Processing details';
        hyf.util.hideComponent(document.getElementById(tableID), true);
    }
    else
    {
        button.className = 'sectionExpanded';
        button.innerHTML = 'Hide Processing details';
        hyf.util.showComponent(document.getElementById(tableID), true);

    }
}


var morphycFile;
window.onload = function()
{
    if (document.getElementById('morphyc_file_xml').value != '')
    {
        morphycFile = getXMLIsland('morphyc_file_xml');
        Sarissa.setXpathNamespaces(morphycFile, 'xmlns:xfact="http://www.hyfinity.com/xfactory"');

        //initialise log file map
        var plog = getElementText(morphycFile.selectSingleNode("/xfact:morphyc/xfact:xplatform/xfact:platform_logging/xfact:log_destination"));
        logFiles['platform'] = plog.toLowerCase().replace(/\\/g, '/');
        var dlog = getElementText(morphycFile.selectSingleNode("/xfact:morphyc/xfact:xplatform/xfact:development_logging/xfact:log_destination"));
        logFiles['development'] = dlog.toLowerCase().replace(/\\/g, '/');
        var alog = getElementText(morphycFile.selectSingleNode("/xfact:morphyc/xfact:xplatform/xfact:administration_logging/xfact:log_destination"));
        logFiles['administration'] = alog.toLowerCase().replace(/\\/g, '/');

        if (logFiles['platform'] == logFiles['development'])
        {
            document.getElementById('development_log_selection').value = 'Show Development & Platform Logs';
            hyf.util.hideComponent(document.getElementById('platform_log_selection'), true);
        }
    }

    //hide the controls groups until a log type has been selected
    var container = document.getElementById('mainContent');
    if (RUN_MODE=="studio")
    {
        WinManager.setSupportedOps([{strId: "logs_refresh", bEnabled: true}]);

        WinManager.setScrollableContainers(['mainContent']);
    }

    if (document.getElementById('morphyc_file_xml').value != '')
    {

       loadLogType('development');

    }
    else
    {
        if (RUN_MODE=="studio")
            container.innerHTML = 'Debugger trace not yet available.<br/>Please perform a "<b>Run Test</b>" for your project and then press "<b>Refresh Debugger</b>" to view trace.';
        else
            container.innerHTML = 'Application Morphyc configuration file not found - Check the file exists.';
    }

   if (RUN_MODE=="standalone")
   {
       if (document.getElementById('log_file').value != '')
       {
           checkLogFile();
       }
       //else
       //{
       //    container.innerHTML = 'No Debugger trace available for display.';
       //}
   }



//    WinManager.setSupportedOps([{strId: "logs_refresh", bEnabled: true}, {strId: "logs_clear", bEnabled: true }]);
   restoreState();
}

/**
 * Implementation of the WinManager API for receiving notice of menu selections
 */
function handleMenuOp(op)
{
    switch (op.strId)
    {
        case 'logs_refresh' :   {
            if (document.getElementById('morphyc_file_xml').value != '')
                loadLogType('development');
            else
            {
                hyf.FMAction.handleFormSubmission( {name: 'Action', option: 'Static', value: 'dashboard'}, {name: 'Validate', option: 'Static', value: 'false'})
            }  break;
        }
        case 'logs_clear'  :   {
            var container = document.getElementById('mainContent');
            if (container)
                container.innerHTML = '';
            break;
        }
    }

}

function checkLogFile()
{
    if (document.getElementById('log_file').value != '')
    {
        hyf.util.showComponent(document.getElementById('layout_group_1'), true);

        var container = document.getElementById('mainContent');

        container.innerHTML = 'Loading Debugger trace...';

        var url = 'viewLogs?logFile='+URLencode(document.morphyc_dashboard.log_file.value);

        updateContentFromURI(url, container, null);

//        hyf.util.showComponent(document.getElementById('development_settings'), true);
//        hyf.util.showComponent(document.getElementById('platform_settings'), true);
    }
}

/**
 * Called when the details button is clicked on a particular log entry.
 *
 * If the details have already been retrieved, this just hides/shows the info
 * If not, then an AJAX call is made to retrieve the details from the server.
 */
function viewLogDetails(detailLogFile, timestamp, level, message, rowID, duplicateNumber, source)
{
    var currentDetails = document.getElementById(rowID + '_details')
    if (currentDetails)
    {
        if (currentDetails.style.display == 'none')
        {
            currentDetails.style.display = '';
            hyf.util.showComponent(rowID + '_details_content', true);
        }
        else
        {
            dojo.fx.wipeOut({node: rowID + '_details_content', duration: 250, onEnd: function() {currentDetails.style.display = 'none';}}).play();
        }
    }
    else
    {
        var row = document.getElementById(rowID);
        var table = row.parentNode.parentNode;

        var detailRow = table.insertRow(row.rowIndex+1);
        detailRow.setAttribute('id', rowID + '_details');
        detailRow.className = row.className;
        //detailRow.style = 'display: none; visibility: hidden;';
        //      detailRow.className = row.className.substring(0, row.className.indexOf(' ')); Removed as we need more thn one class
        var newCell = detailRow.insertCell(-1);
        newCell.colSpan = 3;

        if ((row.className.indexOf('agentMessage') != -1) || (row.className.indexOf('ruleMessage') != -1) || (row.className.indexOf('actionMessage') != -1))
        {
            newCell.innerHTML = '<DIV id="' + rowID + '_details_content" class="paper"><DIV id="' + rowID + '_details_content_xml' + '" class="foldtr"><SPAN>' + 'Loading...' + '</SPAN></DIV></DIV>';
        }
        else
        {
            newCell.innerHTML = '<DIV id="' + rowID + '_details_content" class=""><DIV id="' + rowID + '_details_content_xml' + '" class=""><SPAN>' + 'Loading...' + '</SPAN></DIV></DIV>';
        }

        var queryString = '?detailFile=' + URLencode(detailLogFile) + '&timestamp=' + URLencode(timestamp) + '&level=' + URLencode(level) + '&message=' + URLencode(message) + '&number=' + URLencode(duplicateNumber) + '&source=' + source;

        //Firefox doesnt support the namespace axis, so it is impossible for us to render the XML on the client side
        //as we cant determine which namespaces to show for each element.
        //Therefore we now have to render on the server.  We do this for all browsers to keep the code simple.
        var detailContent = document.getElementById(rowID + '_details_content_xml');
        //hyf.util.showComponent(rowID + '_details_content',true);
        updateContentFromURI('renderLogEntry.do' + queryString, detailContent, null, true);
        hyf.util.showComponent(rowID + '_details_content',false);
    }

    //update the button styling
    var button = document.getElementById(rowID + '_button');
    if (button.className == 'detailCollapsed')
    {
        button.className = 'detailExpanded';
        document.getElementById(rowID).className = document.getElementById(rowID).className.replace(/closedDetail/g, "openDetail");
    }
    else
    {
        button.className = 'detailCollapsed';
        document.getElementById(rowID).className = document.getElementById(rowID).className.replace(/openDetail/g, "closedDetail");
    }

}

/**
 * Copies the contents of the specified log to the clipboard.
 * Currently calls the sever again for each click, but probably should chaneg this.
 */
function copyXMLLog(detailLogFile, timestamp, level, message, rowID, duplicateNumber, source)
{
    var queryString = '?detailFile=' + URLencode(detailLogFile) + '&timestamp=' + URLencode(timestamp) + '&level=' + URLencode(level) + '&message=' + URLencode(message) + '&number=' + duplicateNumber + '&source=' + source;
    var url = 'retrieveLogEntry.do' + queryString;

    WinManager.status.showMessage({msg: 'Copying data...', level: 'in-progress', type: 'copy'});

    dojo.xhrGet({
            url: url,
            sync: true, //need to do a sync call so that copying is allowed. This is only enabled form user initiated code, which isnt the case for the async response handler.
            handleAs: 'text',
            load: function(data) {
                var xmldoc = getXMLDocument(data);
                WinManager.status.removeMessage({level: 'in-progress', type: 'copy'});
                copyToClipboard(xmlToString(xmldoc));
            },
            error: function(error) {
                alert('Unable to copy XML content.\n\n' + error);
            }
    });
}

/**
 * Attempts to copy the provided string to the users clipboard.
 * If this is not possible (due to security issues), then a textbox is displayed
 * containing the textfor the user to easily copy manually.
 */
function copyToClipboard(data)
{
    if (window.clipboardData)
    {
        try
        {
            window.clipboardData.setData('Text', data);
            alert('Content copied to the clipboard.');
        }
        catch (e)
        {
            copyToClipboardFallBack(data);
        }
    }
    else if (document.queryCommandSupported('copy')/* && document.queryCommandEnabled('copy')*/)  //chrome returns false from enabled check even if it will work
    {
        try
        {
            //use a temporary text area to copy the data from
            var copyBox = document.createElement("textarea");
            copyBox.setAttribute('id', 'copyBox');
            copyBox.setAttribute('style', 'position:absolute; left:-1000px');

            document.body.appendChild(copyBox);

            copyBox.value = data;
            copyBox.select();

            var success = document.execCommand('copy');

            copyBox.parentNode.removeChild(copyBox);

            if (success)
                WinManager.alert({strMsg:'Content copied to the clipboard.'});
            else
                copyToClipboardFallBack(data);
        }
        catch (e)
        {
            copyToClipboardFallBack(data);
        }
    }
    else
    {
        copyToClipboardFallBack(data);
    }
}


function copyToClipboardFallBack(data)
{
    var htmlString = '<div id="clipboard_copy_fallback" style="padding : 5px;">';
    htmlString += '<p>Unfortunately it was not possible to automatically copy the data to the clipboard.<br/>Please manually copy the text below, either by pressing <b>Ctrl + C</b> or by using the options provided by your browser.</p>';
    htmlString += '<textarea id="clipboard_copy_fallback_textarea" rows="7" style="width : 95%;"></textarea>'
    htmlString += '</div>';

    WinManager.displayMessageBox(htmlString, 'Copy XML');

    if (document.getElementById('clipboard_copy_fallback_textarea') != null)
    {
        document.getElementById('clipboard_copy_fallback_textarea').value = data;
        document.getElementById('clipboard_copy_fallback_textarea').select();
    }
}



/**
 * URL to use to call RuleMaker.
 * QUESTION: Should we hard code this here, or get it from somewhere else???
 */
var ruleMakerURL = "http://" + window.location.host + "/RuleMaker/RuleMaker";
var formMakerURL = "http://" + window.location.host + "/formmaker/FormMaker";


function showRules(nodeString, level, message, detailFile, timestamp, duplicateNumber, source,
    input_nodeString, input_level, input_message, input_detailFile, input_timestamp, input_duplicateNumber, input_source,
    output_nodeString, output_level, output_message, output_detailFile, output_timestamp, output_duplicateNumber, output_source)
// Passing in the current log details, input message for display on RuleMaker and the output message for display in RuleMaker. If the message is blank, then no Info is Displayed.
{
    if (RUN_MODE != 'studio')
    {
        alert('This functionality is only available when running the Test Dashboard within the WebMaker studio.');
        return;
    }

    if ((morphycFile == null) || (typeof(morphycFile) == 'undefined'))
    {
        alert("The 'View in RuleMaker' functionality is only available if a Morphyc file has been selected to view the logs from.");
        return
    }


    var splitID = nodeString.split('-');
    if (splitID.length < 4)
    {
    alert('Not enough details to view rules.');
    return;
    }


    var user = findUser(splitID);

    var projectDetails = '<project_details xmlns="http://www.hyfinity.com/xfactory">';
    projectDetails += '<user>' + user + '</user>';
    projectDetails += '<product>' + splitID[0] + '</product>';
    projectDetails += '<blueprint_location>' + user + '/' + splitID[0] + '</blueprint_location>';
    projectDetails += '<project>' + splitID[1] + '</project>';
    //QUESTION: where do we get the project name from???  What if the project has been renamed.
    projectDetails += '<project_name>' + splitID[1] + '</project_name>';
    projectDetails += '</project_details>';

    document.rm_form.xml_project_details.value = projectDetails;

    document.rm_form.pattern_id.value = splitID[2];
    document.rm_form.node_id.value = splitID[3];
    document.rm_form.action = ruleMakerURL;

    var stateDoc = '<rulebase_state xmlns="http://www.hyfinity.com/xengine">';

    stateDoc += '<instances><input visible="true" width="20%"/>';
    if (output_message != '')
    {
        stateDoc += '<output visible="true" width="20%"/>';
    }
    stateDoc += '</instances>';


    stateDoc += '<rules visible="true">';

    //check if we can show a particular rule/clause/result
    if (level.indexOf('Firing Rule') == 0)
    {
        //its a rule message, so make that rule visible
        var ruleID = level.substr(13);
        if (ruleID != 'Agent Processing Completed')
            stateDoc += '<rule id="'+ruleID+'" visible="true"/>';
    }
    else if (level.indexOf('Checking Rule') == 0)
    {
        //its a clause message, so make the rule and clause visible
        var ruleID = level.substr(15);
        var clauseID = message.substr(17);

        stateDoc += '<rule id="' + ruleID + '" visible="true"><clauses>';
        stateDoc += '<clause id="' + clauseID + '" visible="true"/>';
        stateDoc += '</clauses></rule>';
    }
    else if (level.indexOf('Result Message') == 0)
    {
        //its a result message, so make the rule and specified action visible
        var ruleIDEnd = level.indexOf(' after Result: ');
        var ruleID = level.substring(25, ruleIDEnd);
        var actionID = level.substr(ruleIDEnd + 15);

        stateDoc += '<rule id="' + ruleID + '" visible="true"><results>';
        stateDoc += '<result id="' + actionID + '" visible="true"/>';
        stateDoc += '</results></rule>';
    }

    stateDoc += '</rules><rulebase_settings visible="false"/>';
    stateDoc += '<namespace_settings visible="false"/>';
    stateDoc += '<workspace_settings visible="false"/>';
    stateDoc += '</rulebase_state>';

    //alert(stateDoc);
    document.rm_form.xml_state.value = stateDoc;

    //retrieve the XML content to show in the left and right sections
    inputRetrieved = false;
    outputRetrieved = false;

    document.rm_form.xml_input_document.value = '';
    document.rm_form.xml_output_document.value = '';

    var inputParams = new Object();
    inputParams.file = input_detailFile;
    inputParams.timestamp = input_timestamp;
    inputParams.level = input_level;
    inputParams.message = input_message;
    inputParams.duplicateNumber = input_duplicateNumber;
    inputParams.source = input_source;
    getInputDocument(inputParams);

    if (output_nodeString != '')
    {
        var outputParams = new Object();
        outputParams.file = output_detailFile;
        outputParams.timestamp = output_timestamp;
        outputParams.level = output_level;
        outputParams.message = output_message;
        outputParams.duplicateNumber = output_duplicateNumber;
        outputParams.source = output_source;
        getOutputDocument(outputParams);
    }
    else
    {
            outputRetrieved = true;
    }

    callRM(splitID[1]);

}

var inputRetrieved = false;
var outputRetrieved = false;

function getInputDocument(params)
{
    var queryString = '?detailFile=' + URLencode(params.file) + '&timestamp=' + URLencode(params.timestamp) + '&level=' + URLencode(params.level) + '&message=' + URLencode(params.message) + '&number=' + params.duplicateNumber + '&source=' + params.source;
    var url = 'retrieveLogEntry.do' + queryString;

    var xmlhttp = new XMLHttpRequest();

    if (dojo.isWebKit)
    {
        //newer webkit browsers seem to have issues using window.open calls from asynchronous
        //functions, so need to make a synchronous call here to be sure that the RM
        //window will eventaully open correctly.
        xmlhttp.open("GET", url, false);
        xmlhttp.send("");
        var xmldoc = getXMLDocument(xmlhttp.responseText);
        document.rm_form.xml_input_document.value = xmlToString(xmldoc);
        inputRetrieved = true;
    }
    else
    {
        xmlhttp.open("GET", url);

        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4) {
                var xmldoc = getXMLDocument(xmlhttp.responseText);
                document.rm_form.xml_input_document.value = xmlToString(xmldoc);
                inputRetrieved = true;
            }
        }
        xmlhttp.send("");
    }
}

function getOutputDocument(params)
{
    var queryString = '?detailFile=' + URLencode(params.file) + '&timestamp=' + URLencode(params.timestamp) + '&level=' + URLencode(params.level) + '&message=' + URLencode(params.message) + '&number=' + params.duplicateNumber + '&source=' + params.source;
    var url = 'retrieveLogEntry.do' + queryString;

    var xmlhttp = new XMLHttpRequest();

    if (dojo.isWebKit)
    {
        //newer webkit browsers seem to have issues using window.open calls from asynchronous
        //functions, so need to make a synchronous call here to be sure that the RM
        //window will eventaully open correctly.
        xmlhttp.open("GET", url, false);
        xmlhttp.send("");
        var xmldoc = getXMLDocument(xmlhttp.responseText);
        document.rm_form.xml_output_document.value = xmlToString(xmldoc);
        outputRetrieved = true;
    }
    else
    {
        xmlhttp.open("GET", url);

        xmlhttp.onreadystatechange = function() {
            if (xmlhttp.readyState == 4) {
                var xmldoc = getXMLDocument(xmlhttp.responseText);
                document.rm_form.xml_output_document.value = xmlToString(xmldoc);
                outputRetrieved = true;
            }
        }
        xmlhttp.send("");
    }
}

function callRM(projName)
{
    if (inputRetrieved && outputRetrieved)
    {
        //document.rm_form.submit();
        WinManager.resolveFormTargetStart(document.rm_form, 'RuleMaker', projName,
                        document.rm_form.pattern_id.value, document.rm_form.node_id.value);
    }
    else
    {
       window.setTimeout("callRM('"+projName+"')", 100);
    }
}


var serviceUrlRetrieved = false;

/**
 * Loads up the requested log entry in xclient to enable easy testing of the request.
 * This makes use of the list nodes service to find the URL of the specified node.
 *
 */
function testServiceCall(nodeString, level, message, detailFile, timestamp, duplicateNumber, source)
{
    var splitID = nodeString.split('-');
    if (splitID.length < 4)
    {
        alert('Not enough details to Run Service Tester.');
        return;
    }

    //retrieve the XML content to show
    inputRetrieved = false;
    serviceUrlRetrieved = false;
    var inputParams = new Object();
    inputParams.file = detailFile;
    inputParams.timestamp = timestamp;
    inputParams.level = level;
    inputParams.message = message;
    inputParams.duplicateNumber = duplicateNumber;
    inputParams.source = source;
    getInputDocument(inputParams);

    if (RUN_MODE == 'studio')
    {
        //retrieve the node details to get target URL
        var user = findUser(splitID);

        var projectDetails = '<project_details xmlns="http://www.hyfinity.com/xfactory">';
        projectDetails += '<user>' + user + '</user>';
        projectDetails += '<product>' + splitID[0] + '</product>';
        projectDetails += '<blueprint_location>' + user + '/' + splitID[0] + '</blueprint_location>';
        projectDetails += '<project>' + splitID[1] + '</project>';
        //QUESTION: where do we get the project name from???  What if the project has been renamed.
        projectDetails += '<project_name>' + splitID[1] + '</project_name>';
        projectDetails += '</project_details>';

        var listNodesRequest = '<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">'
                                + '<soap:Header>'
                                    + projectDetails
                                + '</soap:Header>'
                                + '<soap:Body>'
                                    + '<list_nodes xmlns="http://www.hyfinity.com/xfactory">'
                                        + '<request>'
                                            + '<list_criteria>'
                                                + '<pattern_id>' + splitID[2] + '</pattern_id>'
                                                + '<node_id>' + splitID[3] + '</node_id>'
                                            + '</list_criteria>'
                                        + '</request>'
                                    + '</list_nodes>'
                                + '</soap:Body>'
                            + '</soap:Envelope>';

        var xmlhttp = new XMLHttpRequest();
        if (dojo.isWebKit)
        {
            //newer webkit browsers seem to have issues using window.open calls from asynchronous
            //functions, so need to make a synchronous call here to be sure that the RM
            //window will eventaully open correctly.
            xmlhttp.open("POST", '../xde_services/ListNodes', false);
            xmlhttp.setRequestHeader('SOAPAction', 'ListNodes');
            xmlhttp.send(listNodesRequest);

            //probably shouldnt duplicate code here and below in the onreadystate function.
            var xmldoc = getXMLDocument(xmlhttp.responseText);
            Sarissa.setXpathNamespaces(xmldoc, 'xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xfact="http://www.hyfinity.com/xfactory"')

            if (xmldoc.selectSingleNode("/soap:Envelope/soap:Body/xfact:list_nodes/xfact:response/xfact:outcome/xfact:successful[. = 'true']") != null)
            {
                var node = xmldoc.selectSingleNode("/soap:Envelope/soap:Body/xfact:list_nodes/xfact:response/xfact:patterns/xfact:pattern/xfact:nodes/xfact:node");
                document.serviceTester_form.request_url.value = node.getAttribute('runtime_instance');

                document.serviceTester_form.request_action.value = '';
                var actions = node.selectNodes("xfact:actions/xfact:action");
                for (var i = 0; i < actions.length; ++i)
                {
                    if (i > 0)
                        document.serviceTester_form.request_action.value += '***';

                    document.serviceTester_form.request_action.value += actions.item(i).getAttribute('alias');
                }
            }
            serviceUrlRetrieved = true;
        }
        else
        {
            xmlhttp.open("POST", '../xde_services/ListNodes');
            xmlhttp.setRequestHeader('SOAPAction', 'ListNodes');
            xmlhttp.onreadystatechange = function() {
                if (xmlhttp.readyState == 4) {
                    var xmldoc = getXMLDocument(xmlhttp.responseText);
                    Sarissa.setXpathNamespaces(xmldoc, 'xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xfact="http://www.hyfinity.com/xfactory"')

                    if (xmldoc.selectSingleNode("/soap:Envelope/soap:Body/xfact:list_nodes/xfact:response/xfact:outcome/xfact:successful[. = 'true']") != null)
                    {
                        var node = xmldoc.selectSingleNode("/soap:Envelope/soap:Body/xfact:list_nodes/xfact:response/xfact:patterns/xfact:pattern/xfact:nodes/xfact:node");
                        document.serviceTester_form.request_url.value = node.getAttribute('runtime_instance');

                        document.serviceTester_form.request_action.value = '';
                        var actions = node.selectNodes("xfact:actions/xfact:action");
                        for (var i = 0; i < actions.length; ++i)
                        {
                            if (i > 0)
                                document.serviceTester_form.request_action.value += '***';

                            document.serviceTester_form.request_action.value += actions.item(i).getAttribute('alias');
                        }
                    }
                    serviceUrlRetrieved = true;
                }
            }

            xmlhttp.send(listNodesRequest);
        }
    }
    else
    {
        serviceUrlRetrieved = true;
    }

    callXClient(splitID[1]);
}

/**
 * Makes sure that the message document has been successfully loaded
 * and then actually makes the call to xclient.
 */
function callXClient(projName)
{
    //alert('checking for xclient call ' + inputRetrieved + ' ' + serviceUrlRetrieved);

    if (inputRetrieved && serviceUrlRetrieved)
    {
        document.serviceTester_form.xml_request_content.value = document.rm_form.xml_input_document.value;
        //WinManager.resolveFormTargetStart(document.serviceTester_form, 'Service Tester', projName);
        WinManager.resolveFormTargetStart(document.serviceTester_form, 'Service Tester');
    }
    else
    {
       window.setTimeout("callXClient('"+projName+"')", 100);
    }
}

function showServiceTester()
{
    document.serviceTester_form.xml_request_content.value = '';
    document.serviceTester_form.request_url.value = '';
    document.serviceTester_form.request_action.value = '';
    WinManager.resolveFormTargetStart(document.serviceTester_form, 'Service Tester');
}

/**
 * Loads the document from the requested log, and then tries to open up FormMaker, setting this document as the
 * Page Display bindings document for the page
 */
function viewFMBindings(nodeString, level, message, detailFile, timestamp, duplicateNumber, source)
{
    loadFMBindings(nodeString, level, message, detailFile, timestamp, duplicateNumber, source, 'view-page')
}

/**
 * Loads the document from the requested log, and then tries to open up FormMaker, setting this document as the
 * Action Subission bindings document for the page
 */
function viewASBindings(nodeString, level, message, detailFile, timestamp, duplicateNumber, source)
{
    loadFMBindings(nodeString, level, message, detailFile, timestamp, duplicateNumber, source, 'view-action');
}

/**
 * Loads the document from the requested log, and then tries to open up FormMaker, setting this document as the
 * Page Display bindings document for the page
 */
function updateFMBindings(nodeString, level, message, detailFile, timestamp, duplicateNumber, source)
{
    loadFMBindings(nodeString, level, message, detailFile, timestamp, duplicateNumber, source, 'update-page')
}


var viewFMActionName = null;
function loadFMBindings(nodeString, level, message, detailFile, timestamp, duplicateNumber, source, mode)
{
    if (RUN_MODE != 'studio')
    {
        alert('This functionality is only available when running the Debugger within the WebMaker Studio.');
        return;
    }

    if ((morphycFile == null) || (typeof(morphycFile) == 'undefined'))
    {
        alert("The View and Update Page Bindings functionality is only available if a Morphyc file has been selected to view the logs from.");
        return
    }


    var splitID = nodeString.split('-');
    if (splitID.length < 4)
    {
        alert('Not enough details to open WebMaker Page Design.');
        return;
    }

    var user = findUser(splitID);

    var projectDetails = '<project_details xmlns="http://www.hyfinity.com/xfactory">';
    projectDetails += '<user>' + user + '</user>';
    projectDetails += '<product>' + splitID[0] + '</product>';
    projectDetails += '<blueprint_location>' + user + '/' + splitID[0] + '</blueprint_location>';
    projectDetails += '<project>' + splitID[1] + '</project>';
    //QUESTION: where do we get the project name from???  What if the project has been renamed.
    projectDetails += '<project_name>' + splitID[1] + '</project_name>';
    projectDetails += '</project_details>';

    document.fm_form.xml_project_info.value = projectDetails;
    //clear out the current page name so we can be sure it has been set after loading the message document.
    document.fm_form.new_display_page.value = '';

    document.fm_form.attributes['action'].nodeValue = formMakerURL;

    //retrieve the XML content
    inputRetrieved = false;

    var inputParams = new Object();
    inputParams.file = detailFile;
    inputParams.timestamp = timestamp;
    inputParams.level = level;
    inputParams.message = message;
    inputParams.duplicateNumber = duplicateNumber;
    inputParams.source = source;
    getInputDocument(inputParams);

    document.fm_form.operation1.value = 'load_form_map';
    document.fm_form.operation2.value = 'switch_page';

    if (mode == 'update-page')
    {
        var tipMessage = 'These two options alter how the page display binding document for this page will be updated.';
        tipMessage += '<br/><br/>If you chose to <b>replace</b> the document then the contents of the current document will be discarded, and the details from this log entry will be used instead.<br/>As the log entry contains the actual data available at runtime to bind your fields to, this is likely to be the option used most of the time.<br/>In particular you should definitely use this option if you are trying to resolve binding errors.';
        tipMessage += '<br/><br/>Alternatively you can chose to <b>merge</b> the information.  This will attempt to update the structure of the existing document with the values from this log entry, adding in any additional fields contained in the log. This will not remove any details from the current document that are not in the log entry.<br/>This option is more often used during development when you may not yet have configured the rules to generate all the data that the fields are being bound to.';

        var methodChoiceHTML = '<div style="font-size : 110%;"><span style="float:right;" id="hintField_message_container" class="hintIcon" onmousemove="hyf.util.showTipMessage(arguments[0]);" onmouseout="hyf.util.hideTipMessage(arguments[0]);" _tipMessage="' + tipMessage + '">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>';
        methodChoiceHTML += '<p>Please select how you would like to update the page display binding document for the <span style="font-weight:bold;" id="pageNameContainer"><i>loading...</i></span> page:</p>';

        methodChoiceHTML += '<br/><br/><input type="radio" name="updateFMBindingsMethod" id="updateFMBindingsMethodReplace" value="replace" /><label style="padding-left : 5px;" for="updateFMBindingsMethodReplace">Completely <b>replace</b> the contents of the current document with this log entry.</label>';
        methodChoiceHTML += '<br/><br/><input type="radio" name="updateFMBindingsMethod" id="updateFMBindingsMethodMerge"value="merge" /><label style="padding-left : 5px;" for="updateFMBindingsMethodMerge"><b>Merge</b> the current document with the contents of this log entry.</label></div>';

        WinManager.displayMessageBox({content: methodChoiceHTML, title: 'Update Page Display Bindings', buttons:['ok', 'cancel'], onOk: function(){
                return updateFMBindingsMethodSelected(splitID[1]);
        }});

        //make sure the tip div is above the blur added by showing the message box
        document.body.appendChild(document.getElementById('tipDiv'));

        //we dont need the action name in this case
        viewFMActionName = null;

        document.fm_form.operation3.value = 'update_binding_structure_file';
        document.fm_form.operation4.value = 'load_form_structure';
        document.fm_form.operation5.value = 'load_bindings_file';

        findFMPageDetails(false, true);
    }
    else if (mode == 'view-action')
    {
        viewFMActionName = '';
        callFM(splitID[1]);

        document.fm_form.operation3.value = 'load_form_structure';
        document.fm_form.operation4.value = 'load_bindings_file';
        document.fm_form.operation5.value = '';

        findFMPageDetails(true, false);
    }
    else
    {
        //we dont need the action name in this case
        viewFMActionName = null;
        callFM(splitID[1]);

        document.fm_form.operation3.value = 'load_form_structure';
        document.fm_form.operation4.value = 'load_bindings_file';
        document.fm_form.operation5.value = '';

        findFMPageDetails(false, false);
    }



}

function updateFMBindingsMethodSelected(projName)
{
    var method = null;
    if (document.getElementById('updateFMBindingsMethodReplace').checked)
        method = document.getElementById('updateFMBindingsMethodReplace').value
    else if (document.getElementById('updateFMBindingsMethodMerge').checked)
        method = document.getElementById('updateFMBindingsMethodMerge').value

    if (method == null)
    {
        alert('Please select the method you would like to use.');
        return false;
    }

    document.fm_form.bindingStructureUpdateType.value = method;
    callFM(projName);

    return true;
}

var FMqualifiedNS = 'xmlns:fm="http://www.hyfinity.com/formmaker"';
var FMdefaultNS = 'http://www.hyfinity.com/formmaker';

function findFMPageDetails(findAction, storeContent)
{
    if (inputRetrieved)
    {
        //find the page name from the loaded document
        if (storeContent)
            document.fm_form.xml_binding_structure_document.value = document.rm_form.xml_input_document.value;
        else
            document.fm_form.xml_binding_structure_document.value = '';

        var tempDoc = getXMLDocument(document.rm_form.xml_input_document.value);
        Sarissa.setXpathNamespaces(tempDoc, 'xmlns:mvc="http://www.hyfinity.com/mvc"');

        var pageElem = tempDoc.selectSingleNode("/mvc:eForm/mvc:Control/mvc:Page");
        if (pageElem != null)
        {
            var pageName = getElementText(pageElem);
            //strip off the .xsl extension
            if (pageName.indexOf('.') != -1)
                pageName = pageName.substr(0, pageName.lastIndexOf('.'));
            document.fm_form.new_display_page.value = pageName;
            document.fm_form.bindingStructureFileManagerControlId.value = pageName;
            if (document.getElementById('pageNameContainer'))
                document.getElementById('pageNameContainer').innerHTML = pageName;
        }
        else
        {
            WinManager.status.showMessage({msg: 'We were unable to determine the page that this log applies to, so cannot launch WebMaker Page Design.\nPlease try a different log entry.', level: 'error'});
            document.fm_form.new_display_page.value = 'PAGE_LOAD_ERROR';
            WinManager.clearMessageBox();
            return;
        }


        if (findAction)
        {
            var actionElem = tempDoc.selectSingleNode("/mvc:eForm/mvc:Control/mvc:action");
            if (actionElem != null)
            {
                viewFMActionName = getElementText(actionElem);
            }
            else
            {
                WinManager.status.showMessage({msg: 'We were unable to determine the action that this log applies to, so cannot launch WebMaker Page Design.\nPlease try a different log entry.', level: 'error'});
                viewFMActionName = 'ACTION_LOAD_ERROR';
                WinManager.clearMessageBox();
                return;
            }
        }


    }
    else
    {
       window.setTimeout("findFMPageDetails("+findAction+", "+storeContent+")", 100);
    }
}


function callFM(projName)
{
    if ((inputRetrieved) && (document.fm_form.new_display_page.value != '') && (viewFMActionName != ''))
    {

        if ((document.fm_form.new_display_page.value == 'PAGE_LOAD_ERROR') || (viewFMActionName == 'ACTION_LOAD_ERROR'))
            return

        //check of there is an existing FM window open to get the state for
        //and make sure the bindings tab will be visible on the page structure screen when it loads up
        var initialState = '';
        if (WinManager.isWindowOpen('FormMaker', projName, 'PageDesign', document.fm_form.new_display_page.value))
        {
            var win = WinManager.getOpenWindows('FormMaker', projName, 'PageDesign', document.fm_form.new_display_page.value)[0];
            if (win.stateManager)
                initialState = xmlToString(win.stateManager.getStateDocument());
            else if (win.document.forms[0].xml_fm_state)
                initialState = win.document.forms[0].xml_fm_state.value;
        }

        //ensure that the events section will be open
        var stateManager = new FormMakerStateManager(initialState, null);

        //make sure the bindings tab is selected, with the correct bindings pane visible
        stateManager.setControlDetailsTab('bindings');
        if (viewFMActionName != null)
        {
            stateManager.setBindingCurrentAction(viewFMActionName);
        }
        else
        {
            stateManager.setBindingCurrentAction('handler-to-page');
        }

        //make sure the RHS panel is open
        var state = stateManager.getDividerState(FormMakerStateManager.DIVIDER_PS_CONTROL_DETAILS);
        state.hidden = false;
        stateManager.setDividerState(FormMakerStateManager.DIVIDER_PS_CONTROL_DETAILS, state);

        document.fm_form.xml_fm_state.value = xmlToString(stateManager.getStateDocument());


        WinManager.resolveFormTargetStart(document.fm_form, 'FormMaker', projName, 'PageDesign', document.fm_form.new_display_page.value);
    }
    else
    {
       window.setTimeout("callFM('"+projName+"')", 100);
    }
}




/**
 * Returns the username under which the given project was developed.
 * This assumes the username is specified in a user attribute in the morphyc file.
 *
 * @param splitID An array containing the four parts of the full node id.
 * @return the username string
 */
function findUser(splitID)
{
    var proj = morphycFile.selectSingleNode("/xfact:morphyc/xfact:blueprints/xfact:project[@name = '"+splitID[0]+"-"+splitID[1]+"']");
    //alert(proj);
    if (proj != null)
    {
        return proj.getAttribute('user');
    }
    return null;
}


/** Object to store the current display state of the log settings. */
var displayState = new Object();
displayState.agentMessages = true;
displayState.ruleMessages = false;
displayState.actionMessages = true;
displayState.checkFalseMessages = true;
displayState.proxyMessages = true;
displayState.timestamps = false;
displayState.platformLevel = 'warning';


/*
 * Functions for globably showing and hiding specific log types
 */
function toggleAgentMessages()
{
    displayState.agentMessages = toggleClassDisplay('.agentMessage');
    saveState();
}
function toggleRuleMessages()
{
    displayState.ruleMessages = toggleClassDisplay('.ruleMessage');
    saveState();
}
function toggleActionMessages()
{
    displayState.actionMessages = toggleClassDisplay('.actionMessage');
    saveState();
}
function toggleCheckingFalseMessages()
{
    displayState.checkFalseMessages = toggleClassDisplay('.check_no_actions_fired');
    saveState();
}
function toggleProxyMessages()
{
    displayState.proxyMessages = toggleClassDisplay('.proxy');
    saveState();
}

function toggleTimestamps()
{
    displayState.timestamps = toggleClassDisplay('.timestamp');
    saveState();
}

function changePlatformLogLevel(level)
{
    switch (level)
    {
        case 'debug' :  toggleClassDisplay('.debugMessage', true);
                        toggleClassDisplay('.infoMessage', true);
                        toggleClassDisplay('.warningMessage', true);
                        toggleClassDisplay('.errorMessage', true);
                        toggleClassDisplay('.fatalMessage', true);
                        toggleClassDisplay('.warningIcon', true);
                        toggleClassDisplay('.errorIcon', true);
                        toggleClassDisplay('.fatalIcon', true);
                        break;
        case 'info' :   toggleClassDisplay('.debugMessage', false);
                        toggleClassDisplay('.infoMessage', true);
                        toggleClassDisplay('.warningMessage', true);
                        toggleClassDisplay('.errorMessage', true);
                        toggleClassDisplay('.fatalMessage', true);
                        toggleClassDisplay('.warningIcon', true);
                        toggleClassDisplay('.errorIcon', true);
                        toggleClassDisplay('.fatalIcon', true);
                        break;
        case 'warning' :toggleClassDisplay('.debugMessage', false);
                        toggleClassDisplay('.infoMessage', false);
                        toggleClassDisplay('.warningMessage', true);
                        toggleClassDisplay('.errorMessage', true);
                        toggleClassDisplay('.fatalMessage', true);
                        toggleClassDisplay('.warningIcon', true);
                        toggleClassDisplay('.errorIcon', true);
                        toggleClassDisplay('.fatalIcon', true);
                        break;
        case 'error' :  toggleClassDisplay('.debugMessage', false);
                        toggleClassDisplay('.infoMessage', false);
                        toggleClassDisplay('.warningMessage', false);
                        toggleClassDisplay('.errorMessage', true);
                        toggleClassDisplay('.fatalMessage', true);
                        toggleClassDisplay('.warningIcon', false);
                        toggleClassDisplay('.errorIcon', true);
                        toggleClassDisplay('.fatalIcon', true);
                        break;
        case 'fatal' :  toggleClassDisplay('.debugMessage', false);
                        toggleClassDisplay('.infoMessage', false);
                        toggleClassDisplay('.warningMessage', false);
                        toggleClassDisplay('.errorMessage', false);
                        toggleClassDisplay('.fatalMessage', true);
                        toggleClassDisplay('.warningIcon', false);
                        toggleClassDisplay('.errorIcon', false);
                        toggleClassDisplay('.fatalIcon', true);
                        break;

    }
    displayState.platformLevel = level;
    saveState();
}

/**
 * updates the CSS to toggle the display of the selected class.
 *
 * If a class already exists with the specified class name, then its display attribute
 * is toggled between none and the default.
 * If not, a new class definition is added with a display value of none.
 * @param show An optional boolean parameter.  If this is supplied, rather than toggling the display,
 * the class will be adjusted to ensure that it is shown if set to true, or hidden if set to false.
 * @return a boolean value indicating whether or not the class is now displayed.
 */
function toggleClassDisplay(classname, show)
{
    var found = false;
    var ssheet;
    for (var si = 0; si < document.styleSheets.length; ++si)
    {
        ssheet = document.styleSheets[si];
        var rules;
        if(ssheet.cssRules)
            rules = ssheet.cssRules;
        else if (ssheet.rules)
            rules = ssheet.rules;

        for (var i = 0; i < rules.length; ++i)
        {
            if (rules.item(i).selectorText == classname)
            {
                found = true;
                if ((rules.item(i).style.display == 'none' && (typeof(show) == 'undefined')) || show)
                {
                    rules.item(i).style.display = '';
                    return true;
                }
                else
                {
                    rules.item(i).style.display = 'none';
                    return false;
                }
            }
        }
    }
    if (!found  && !show)
    {
        if (ssheet.addRule)
        {
            ssheet.addRule(classname, "display : none;");
            return false;
        }
        else if (ssheet.insertRule)
        {
            ssheet.insertRule(classname + " {display : none;}", ssheet.cssRules.length);
            return false;
        }
    }
}


function URLencode(sStr) {
    return escape(sStr).
             replace(/\+/g, '%2B').
                replace(/\"/g,'%22').
                   replace(/\'/g, '%27');/*.
                     .replace(/\//g,'%2F');*/
}


function restoreState()
{
    var displayStateCookie = dojo.cookie("DB_VIEW_STATE_2");
    if ((displayStateCookie != null) && (typeof(displayStateCookie) != 'undefined'))
    {
        var details = displayStateCookie.split("|");
        //the values in the details array will be strings, so need to convert to booleans
        displayState.agentMessages = (details[0] == 'true');
        displayState.ruleMessages = (details[1] == 'true');
        displayState.actionMessages = (details[2] == 'true');
        displayState.checkFalseMessages = (details[3] == 'true');
        displayState.proxyMessages = (details[4] == 'true');
        displayState.timestamps = (details[5] == 'true');
        displayState.platformLevel = details[6];
    }

    if (displayState != null)
    {
        if (!displayState.agentMessages)
        {
            toggleAgentMessages();
            document.getElementById('show_agent_control').checked = false;
        }
        if (!displayState.ruleMessages)
        {
            toggleRuleMessages();
            document.getElementById('show_rule_control').checked = false;
        }
        if (!displayState.actionMessages)
        {
            toggleActionMessages();
            document.getElementById('show_action_control').checked = false;
        }
        if (!displayState.checkFalseMessages)
        {
            toggleCheckingFalseMessages();
            document.getElementById('show_check_control_false').checked = false;
        }
        if (!displayState.proxyMessages)
        {
            toggleProxyMessages();
            document.getElementById('show_proxy').checked = false;
        }
        if (!displayState.timestamps)
        {
            toggleTimestamps();
            document.getElementById('show_timestamp_control').checked = false;
        }
        changePlatformLogLevel(displayState.platformLevel);
        document.getElementById('show_platform_level_control').value = displayState.platformLevel;

        //reset the cookie expiry
        saveState();
    }
}


function saveState()
{
    var cookieString = displayState.agentMessages + "|" +
                        displayState.ruleMessages + "|" +
                        displayState.actionMessages + "|" +
                        displayState.checkFalseMessages + "|" +
                        displayState.proxyMessages + "|" +
                        displayState.timestamps + "|" +
                        displayState.platformLevel;
    dojo.cookie("DB_VIEW_STATE_2", cookieString, {expires: 60});
}





dojo.addOnLoad(setTableHeight);
window.onresize = setTableHeight;
function setTableHeight()
{
    var logsDiv = document.getElementById('mainContent');
    if (RUN_MODE == 'studio')
    {
       var requiredHeight = (hyf.util.getViewportSize().height - 43) + 'px';
       document.getElementById('mainContent').style.height = requiredHeight;
    }
    else
    {
        if (document.getElementById('log_file').value != '')
        {
            var requiredHeight = (hyf.util.getViewportSize().height - 101) + 'px';
            document.getElementById('mainContent').style.height = requiredHeight;
        }
        else
        {
            var requiredHeight = (hyf.util.getViewportSize().height - 133) + 'px';
            document.getElementById('mainContent').style.height = requiredHeight;
        }
    }
}


function refreshFrame()
{
    if (document.getElementById('morphyc_file_xml').value != '')
        loadLogType('development');
    else
    {
        hyf.FMAction.handleFormSubmission( {name: 'Action', option: 'Static', value: 'dashboard'}, {name: 'Validate', option: 'Static', value: 'false'})
    } 
}