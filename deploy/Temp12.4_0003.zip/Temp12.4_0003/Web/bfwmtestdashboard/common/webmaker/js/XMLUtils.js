
//---------------------------------------------------------------------------------------------
//              Start of XML/DOM related util methods
//   (some of these functions require the Sarissa library to be available)
//---------------------------------------------------------------------------------------------


/**
 * Returns an XML document from the contents of a textarea with a given id
 * @param id The ID of the textarea containing the XML content
 */
function getXMLIsland(id)
{
    var island = document.getElementById(id);
    if ((island != null) && (island.value != ''))
    {
        return getXMLDocument(island.value);
    }
    return null;
}


/**
 * Returns a new DOM document, optionally created from the given content
 * @param docContent (optional) parameter indicating the content that should be placed in the new document
 *          This can be either a string containing the XML content, or an XML node.
 * @return The created document.
 */
function getXMLDocument(docContent)
{
    //alert('creating document ' + typeof(docContent));
    if (typeof(docContent) != 'undefined')
    {
        if (typeof(docContent) == 'string')
        {
            //alert('source string: ' + docContent);
            return (new DOMParser()).parseFromString(docContent, "text/xml");
        }
        else
            return (new DOMParser()).parseFromString(new XMLSerializer().serializeToString(docContent), "text/xml");
    }
    else
    {
        var doc = Sarissa.getDomDocument();
        doc.resolveExternals = false;
        doc.validateOnParse = false;
        doc.async = false;
        return doc;
    }
}

/**
 * Stores the WebMaker version number.
 * This is not the human readable version number, but instead is the
 * value that should be used to make script URLs distinct to prevent caching etc.
 * This value is now retrieved from the WinManager at runtime rather than set by the build process.
 */
var WM_VERSION_CODE = 'WM_BUILD_VERSION';

if (typeof(WinManager) != 'undefined')
{
    var vd = WinManager.getVersionDetail();
    if (vd != null)
    {
        var vc = getElementText(vd.selectSingleNode("/product_version/version_code"));
        if (vc != '')
            WM_VERSION_CODE = vc;
    }
}

/**
 * Returns an XML document created from the content at the specified URL.
 * This is a synchronous load, so should not be used if the URL call could take some time.
 * @param url The URL of the XML content to load.
 */
function getXMLDocumentFromURL(url, processedFiles)
{
    //add the build version number to thw end of each url to resolve issues
    //with the browsers caching older versions of the files.
    url = url + ((url.indexOf('?') != -1) ? '&' : '?') + 'v=' + WM_VERSION_CODE;
    var doc;
    try  //this should work in IE, FF, etc
    {
        doc = getXMLDocument();
        doc.load(url);
    }
    catch (e)
    { //this is needed for google chrome.  Edge will also fall in here
        var xmlhttp = new window.XMLHttpRequest();
        xmlhttp.open("GET", url, false);
        xmlhttp.send(null);

        var resp = xmlhttp.responseText

        //Edge doesent support the exslt:node-set function we use in some XSLs, and also doesnt support
        //the <msxsl:script> tag workaround we use for IE
        //It does however seem to support the msxsl:node-set function, so we try and adjust the XSL contents
        //here if appropriate
        if ((navigator.appVersion.indexOf("Edge/") != -1) && (url.toLowerCase().indexOf('.xsl') != -1))
        {
            //repalce any esxslt:node-set calls
            resp = resp.replace(/exslt:node-set/g, 'msxsl:node-set');
            //remove any msxml:script sections as these being present causes issues
            while (resp.indexOf('<msxsl:script') != -1)
            {
                var start = resp.indexOf('<msxsl:script');
                var end = resp.indexOf('</msxsl:script>', start);

                resp = resp.substring(0, start) + resp.substring(end + 15);
            }
        }


        doc = getXMLDocument(resp);

        //Google chrome does not support includes/imports in XSLs
        //Therefore we try and manually combine all these into one XSL
        //It is not possible to do this completely, but for simple template/variable overrides
        //this should work okay.
        //Once google fix the bug, we can probably remove this code
        //See http://code.google.com/p/chromium/issues/detail?id=8441
        if (typeof(processedFiles) == 'undefined')
            var processedFiles = new Object();

        var baseURL = '';
        if (url.indexOf('/') != -1)
        {
            baseURL = url.substring(0, url.lastIndexOf('/'));
        }

        processXSLIncludesInLoadedDoc(doc, baseURL, processedFiles);

    }
    return doc;
}


function processXSLIncludesInLoadedDoc(doc, baseURL, processedFiles)
{
    Sarissa.setXpathNamespaces(doc, 'xmlns:xsl="http://www.w3.org/1999/XSL/Transform"');
    var imports = doc.selectNodes("/xsl:stylesheet/xsl:import|/xsl:stylesheet/xsl:include");

    for (var i = 0; i < imports.length; ++i)
    {
        var fileName = imports.item(i).getAttribute('href');
        if (baseURL != '')
            fileName = baseURL + '/' + fileName;

        //remove the import form the document
        imports.item(i).parentNode.removeChild(imports.item(i));

        if (!processedFiles[fileName])
        {
            processedFiles[fileName] = true;
            //load up the new file
            var loadedFile = getXMLDocumentFromURL(fileName, processedFiles);
            Sarissa.setXpathNamespaces(loadedFile, 'xmlns:xsl="http://www.w3.org/1999/XSL/Transform"');
            //check for global variables to include
            var variables = loadedFile.selectNodes("/xsl:stylesheet/xsl:variable");
            for (var j = 0; j < variables.length; ++j)
            {
                var varName = variables.item(j).getAttribute('name');
                if (doc.selectSingleNode("/xsl:stylesheet/xsl:variable[@name = '"+varName+"']") == null)
                {
                    var imported = variables.item(j);
                    if (typeof(doc.importNode) == 'function')
                        imported = doc.importNode(imported, true);

                    doc.documentElement.appendChild(imported);
                }
            }

            //check for any template matches to include
            var templates = loadedFile.selectNodes("/xsl:stylesheet/xsl:template[@match]");
            for (var j = 0; j < templates.length; ++j)
            {
                var templateMatch = templates.item(j).getAttribute('match');
                var templateMode = templates.item(j).getAttribute('mode');
                if (templateMode == null)
                {
                    if (doc.selectSingleNode("/xsl:stylesheet/xsl:template[(@match = '"+templateMatch+"') and not(@mode)]") == null)
                    {
                        var imported = templates.item(j);
                        if (typeof(doc.importNode) == 'function')
                            imported = doc.importNode(imported, true);

                        doc.documentElement.appendChild(imported);
                    }
                }
                else
                {
                    if (doc.selectSingleNode("/xsl:stylesheet/xsl:template[(@match = '"+templateMatch+"') and @mode = '" + templateMode + "']") == null)
                    {
                        var imported = templates.item(j);
                        if (typeof(doc.importNode) == 'function')
                            imported = doc.importNode(imported, true);

                        doc.documentElement.appendChild(imported);
                    }
                }
            }

            //check for any named tempaltes to include
            templates = loadedFile.selectNodes("/xsl:stylesheet/xsl:template[@name and not(@match)]");
            for (var j = 0; j < templates.length; ++j)
            {
                var templateName = templates.item(j).getAttribute('name');
                if (doc.selectSingleNode("/xsl:stylesheet/xsl:template[@name = '"+templateName+"']") == null)
                {
                    var imported = templates.item(j);
                    if (typeof(doc.importNode) == 'function')
                        imported = doc.importNode(imported, true);

                    doc.documentElement.appendChild(imported);
                }
            }

            //check for any other non XSL content to include
            /*var others = loadedFile.selectNodes("/xsl:stylesheet/*[namespace-uri() != 'http://www.w3.org/1999/XSL/Transform']");
            for (var j = 0; j < others.length; ++j)
            {
                var oe = others.item(j);
                if (doc.selectSingleNode("/xsl:stylesheet/*[local-name() = '" + getBaseName(oe) + "' and namespace-uri() = '" + oe.namespaceURI + "']") == null)
                {
                    var imported = others.item(j);
                    if (typeof(doc.importNode) == 'function')
                        imported = doc.importNode(imported, true);

                    doc.documentElement.appendChild(imported);
                }
            }*/
        }
    }
}

/**
 * Serializes the provided node to an XML string
 * @param xmlNode the node to serialize.
 * @return The XML formatted string.
 */
function xmlToString(xmlNode)
{
    if (xmlNode == null)
        return '';

    var xmlString = new XMLSerializer().serializeToString(xmlNode);
    //remove the xml declaration if present
    if (xmlString.match(/^(\s*)(<\?xml)/))
    {
        xmlString = xmlString.substr(xmlString.indexOf('>') + 1);
    }
    return xmlString;
}

/**
 * Returns the text content of the given xml element.
 * This just handles the browser differences in how this data should be found
 * @param elem The DOM Element to get the text content for.
 * @return The text content.
 */
function getElementText(elem)
{
    if (elem == null)
        return '';

    //special handling for attribute nodes
    //generally you are better of using the element.getAttribute method
    //to get the value of an attribute, but this is here to handle the case
    //where an atttribute node has been passed in.
    //Firefox 14 stopped the ability to get child text nodes of an attribute
    //so the general handling below no longer works!
    if (elem.nodeType == 2)
    {
        if (typeof(elem.value) != 'undefined')
            return elem.value;
        else if (typeof(elem.nodeValue) != 'undefined')
            return elem.nodeValue
    }


    var contents = '';

    var childNodes = elem.childNodes;

    for (var i = 0; i < childNodes.length; ++i)
    {
        if ((childNodes.item(i).nodeType == 3) || (childNodes.item(i).nodeType == 4))  //text node
        {
            contents += childNodes.item(i).nodeValue;
        }
    }

    return contents;
}

/**
 * Sets the text content of the given element.
 * All existing child nodes of the element are removed.
 * @param elem The DOM element to set the text content of.
 * @param text The string specifying the text to use.
 */
function setElementText(elem, text)
{
    if (elem == null)
        return

    //special handling for attribute nodes
    //generally you are better of using the element.setAttribute method
    //to get the value of an attribute, but this is here to handle the case
    //where an atttribute node has been passed in.
    if (elem.nodeType == 2)
    {
        if (typeof(elem.value) != 'undefined')
        {
            elem.value = text;
            return;
        }
        else if (typeof(elem.nodeValue) != 'undefined')
        {
            elem.nodeValue = text;
            return;
        }
    }

    while(elem.hasChildNodes())
    {
        elem.removeChild(elem.firstChild);
    }

    elem.appendChild(elem.ownerDocument.createTextNode(text));
}


/**
 * Convenience function to return the base name (local name)
 * of the given element.  This just works out which property
 * to use to handle browser differences.
 */
function getBaseName(elem)
{
    if (elem == null) return null;
    if (elem.localName)
        return elem.localName;
    else if (elem.baseName) //MSXML
        return elem.baseName;
    else
        return elem.nodeName //fallback
}

/**
 * Returns a new element created with the given name, and namespace
 * by the provided document.
 * this just extracts away the browser specific issues of whether to use createElementNS
 * or createNode
 * @param doc The document to create the element in
 * @param name The name ot give the new element
 * @param ns The namespace URI to assign to the new element
 */
function createNamespaceElement(doc, name, ns)
{
    if (typeof(doc.createElementNS) != 'undefined') //W3C standard method
    {
        //alert('using w3c method');
        return doc.createElementNS(ns, name);
    }
    else if (typeof(doc.createNode) != 'undefined') //MSXML method
    {
        //alert('creating msxml element. ' + name + ', ' + ns);
        return doc.createNode('element', name, ns);
    }
    else
        return null;
}

/**
 * Returns the closest previous sibling to the given element
 * that is an element node. ie text nodes are ignored
 */
function getPreviousElementSibling(elem)
{
    var prev = elem.previousSibling;
    //make sure we return an element type node, not a text node
    while (prev && prev.nodeType != 1)
    {
        prev = prev.previousSibling;
    }

    return prev;
}

/**
 * Returns the closest folowing sibling to the given element
 * that is an element node. ie text nodes are ignored
 */
function getNextElementSibling(elem)
{
    var prev = elem.nextSibling;
    //make sure we return an element type node, not a text node
    while (prev && prev.nodeType != 1)
    {
        prev = prev.nextSibling;
    }

    return prev;
}

/**
 * Checks if the provided child node is actually a child
 * of the given parent (regardless of levels of nesting)
 * @param parent The parent node that may contain the child.
 * @param child The node that may be a descendant of parent.
 * @return true if child is a descendant of parent, false otherwise.
 */
function isDescendant(parent, child)
{
     var node = child.parentNode;
     while (node != null)
     {
         if (node == parent)
         {
             return true;
         }
         node = node.parentNode;
     }
     return false;
}

/**
 * Checks if the provided child node is equal to, or a child
 * of the given parent (regardless of levels of nesting).
 * This differs from isDescendant as will return true if both elements are the same.
 * @param parent The parent node that may contain the child.
 * @param child The node that may be a descendant of parent.
 * @return true if child is a descendant of parent, false otherwise.
 */
function isDescendantOrSelf(parent, child)
{
    if (parent == child)
        return true;
    else
        return isDescendant(parent, child);
}

/**
 * Compares the two provided XMl fragments, and returns true if they are the same,
 * or false otherwise.
 * This checks the actual XML content, so does not mind what namespace prefixes are being used etc.
 * The two passed in parameters must be element nodes.
 */
function compareXMLFragments(elem1, elem2)
{
    //check both elements provided
    if ((elem1 == null) || (elem2 == null))
        return false;

    //check name and namespace the same
    if ((getBaseName(elem1) != getBaseName(elem2)) || (elem1.namespaceURI != elem2.namespaceURI))
        return false;

    //check attributes
    var elem1Atts = elem1.selectNodes("@*");
    var elem2Atts = elem1.selectNodes("@*");
    if (elem1Atts.length == elem2Atts.length)
    {
        for (var i = 0; i < elem1Atts.length; ++i)
        {
            if (elem2.attributes.getNamedItem(elem1Atts.item(i).nodeName))
            {
                if (elem2.attributes.getNamedItem(elem1Atts.item(i).nodeName).nodeValue != elem1Atts.item(i).nodeValue)
                    return false;
            }
            else
                return false;
        }
    }
    else
    {
        return false;
    }

    //check child elements
    var elem1Children = elem1.selectNodes("*");
    var elem2Children = elem2.selectNodes("*");
    if (elem1Children.length == elem2Children.length)
    {
        for (var i = 0; i < elem1Children.length; ++i)
        {
            if (!compareXMLFragments(elem1Children.item(i), elem2Children.item(i)))
                return false;
        }
    }
    else
        return false

    //check text content
    var elem1Text = elem1.selectNodes("text()[normalize-space(.) != '']");
    var elem2Text = elem2.selectNodes("text()[normalize-space(.) != '']");
    if (elem1Text.length == elem2Text.length)
    {
        for (var i = 0; i < elem1Text.length; ++i)
        {
            if (elem1Text.item(i).nodeValue != elem2Text.item(i).nodeValue)
                return false;
        }
    }
    else
        return false

    //content the same so return true
    return true;
}

/**
 * Returns an XPath string that will select the given node.
 * The Xpath will be positional of the form '/*[1]/*[5]/*[3]'
 * @param node The DOM node to get the xpath for (must be either an element or attribute node)
 * @param nameBased (Optional) If true, the returned xpath will use elment names rather than *, eg /html[1]/body[1]/div[2]/span[1]
 *                      This option will currently have issues if the document uses namespaces.
 *                      Defautls to false.
 * @return The XPath string
 */
function getXPathForNode(node, nameBased)
{
    if ((node == null) || (node.nodeType == 9)) //document node
    {
        return "";
    }

    var section = ''
    var parent;
    if (node.nodeType == 2) //attribute
    {
        if (typeof(node.ownerElement) != 'undefined')
            parent = node.ownerElement; //Standard - FF,Chrome
        else
            parent = node.selectSingleNode('..'); //IE

        section = '/@' + getBaseName(node);
    }
    else
    {
        parent = node.parentNode;

        var baseName = getBaseName(node);


        var posCount = 1;
        var prev = node.previousSibling;
        while (prev != null)
        {
            if (prev.nodeType == 1)
            {
                if (!nameBased || (getBaseName(prev) == baseName))
                    posCount++;
            }
            prev = prev.previousSibling;
        }

        section = (nameBased) ? '/' + baseName : '/*';

        section += '[' + posCount + ']';
    }

    return getXPathForNode(parent, nameBased) + section;
}



/**
 * Converts any of the five XMl entities in the given string to
 * their escaped versions.
 * @param XMLString The string to check for the XML characters.
 */
function escapeXMLCharacters(XMLString)
{
    if ((typeof(XMLString) == 'undefined') || (XMLString == null))
    {
        return XMLString;
    }

    XMLString = XMLString.replace(/&/gi , "&amp;");
    XMLString = XMLString.replace(/</gi , "&lt;");
    XMLString = XMLString.replace(/>/gi , "&gt;");
    XMLString = XMLString.replace(/'/gi , "&apos;");
    XMLString = XMLString.replace(/"/gi , "&quot;");
    return XMLString;
}





/**
 * Processes the retrieved XML string from the server to create the correct
 * DOM document containing the requested instance XML.
 * This assumes the response was an XStore response message, and validates that this represents a
 * successful response.
 *
 * @pararm responseString The XML formatted string returned from the server.
 * @param targetDoc The DOM documetn object to update with the contents of the string.
 * @return a boolean indicating whether the document was successfully populated with the response.
 */
function stripXStoreResponse(responseString, targetDoc, logType)
{

    var tempDoc = getXMLDocument(responseString);
    Sarissa.setXpathNamespaces(tempDoc, 'xmlns:xstore="http://www.hyfinity.com/xstore"');

    //check the response can be parsed ok
    if (Sarissa.getParseErrorText(tempDoc) != Sarissa.PARSED_OK)
    {
        var msgOptions = {msg: 'Unable to read document.  It did not define a valid XML document.\nPlease try your request again.',
                        level: 'error',
                        detail: Sarissa.getParseErrorText(tempDoc)};
        if (logType)
            msgOptions.type = logType;
        WinManager.status.showMessage(msgOptions);
        //alert('Unable to read document.  It did not define a valid XML document.\nPlease try your request again.\n\n' + Sarissa.getParseErrorText(tempDoc));
        return false;
    }

    //now check it contains an xstore success message
    if (tempDoc.selectSingleNode("/xstore:xstore/xstore:response/xstore:outcome[. = 'success']") &&
              tempDoc.selectSingleNode("/xstore:xstore/xstore:content/*"))
    {
        var tempDoc2 = getXMLDocument(tempDoc.selectSingleNode("/xstore:xstore/xstore:content/*"));
        if (targetDoc.documentElement != null)
            targetDoc.removeChild(targetDoc.documentElement);

        var imported = tempDoc2.documentElement;
        if (typeof(targetDoc.importNode) == 'function')
            imported = targetDoc.importNode(imported, true);

        targetDoc.appendChild(imported);
        return true;
    }
    else
    {
        var detailMsg = xmlToString(tempDoc.selectSingleNode("/xstore:xstore/xstore:response/xstore:message"));
        if (detailMsg != '')
            detailMsg += '<br/><br/>';

        detailMsg += '<p>Response Received:</p><textarea rows="8" cols="100">' + responseString + '</textarea>';

        var msgOptions = {msg: 'There was a problem loading the document.',
                        level: 'error',
                        detail: detailMsg};
        if (logType)
            msgOptions.type = logType;
        WinManager.status.showMessage(msgOptions);
        /*alert('There was a problem loading the document.\n\n' +
                xmlToString(tempDoc.selectSingleNode("/xstore:xstore/xstore:response/xstore:message")));*/
        return false;
    }
}
