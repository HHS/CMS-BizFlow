/**
 * CMUI provides a UI interface on top of a codemirror based code editor.
 *
 * @author Hyfinity Ltd.
 * Copyright (c) 2014
 */


//ensure the hyf context is defined
if (typeof(hyf) == 'undefined')
{
    hyf = {};
}

if (typeof(hyf.util) == 'undefined')
{
    hyf.util = {};
}
/** Map the needed util functions for pages that are on the old style function names. */
if ((typeof(hyf.util.getComponentPosition) == 'undefined') && (getComponentPosition))
{
    hyf.util.getComponentPosition = getComponentPosition;
    hyf.util.getMouseCoords = getMouseCoords;
    hyf.util.getCurrentStyle = getCurrentStyle;
}

/**
 * The main cmui object manages the set of loaded editors, and is used to create and delete cmui editor instances.
 */
hyf.cmui =
{
    version: 1,
    urlBase: '',
    /** The config object to use for the dojo require calls to ensure it looks in the correct place for CM code.
     *  The path will be updatd correctly in the code below.
     */
    dojoConfig: {
        async: true,
        cacheBust: WM_VERSION_CODE,
        paths: {
            "cm": "/cm"
        }
    },
    /** The base set of CM js plugins/addons that should be used for all types of editors. */
    baseJsPlugins: ['cm/addon/fold/foldcode',
                    'cm/addon/fold/foldgutter',
                    'cm/addon/search/cmui_search',
                    'cm/addon/search/searchcursor',
                    'cm/addon/dialog/dialog',
                    'cm/addon/search/match-highlighter',
                    'cm/addon/comment/continuecomment'],
    baseCssPlugins: ['cm/addon/fold/foldgutter.css',
                     'cm/addon/dialog/dialog.css'],
    /** Contains the CMUI plugins that have been registered so far. */
    plugins: [],
    /** Stores the CSS files that have been loaded on the page. */
    loadedCss: {},
    /**Stores the editors loaded so far. */
    editors: {}
}

//initiliase the url base location for this cmui script file
//this is needed so that we can correctly load all the required codemirror files
var scripts = document.getElementsByTagName("script");
hyf.cmui.urlBase = scripts[scripts.length-1].src;
hyf.cmui.urlBase = hyf.cmui.urlBase.substring(0, hyf.cmui.urlBase.indexOf('/cmui/cmui.js'));
hyf.cmui.dojoConfig.paths['cm'] = hyf.cmui.urlBase + '/cm';

/** The default settings that will be used for editor display.
 *  This includes override settings for each editor mode.*/
hyf.cmui.defaults = {


    /** The Base set of options that will apply to all types of editors.
     *  The properties defined here will be replaced by any mode specific settings, with the exception
     *  of the cmOptions settings where the contents of both options objects will be merged. */
    'all': {
        toolbar: ['search', 'goto', 'undo', 'redo', 'fontsize', 'wordwrap', 'fullscreen'],
        statusbar: ['position', 'resize'],
        cmPlugins: {js: hyf.cmui.baseJsPlugins.concat(['cm/addon/fold/brace-fold',
                                                       'cm/addon/edit/matchbrackets']),
                    css: hyf.cmui.baseCssPlugins},
        cmOptions: {lineNumbers: true,
                    indentUnit: 4,
                    foldGutter: true,
                    matchBrackets: true,
                    highlightSelectionMatches: true,
                    continueComments: true,
                    gutters: ["CodeMirror-linenumbers", "CodeMirror-foldgutter"],
                    theme: 'hyf',
                    extraKeys: {"Ctrl-Space": "autocomplete", "F3" : "findNext"}},
        fireChangeOnBlur: false //If true any onchange event on the underlying textarea will be fired on 'blur' of the
                                //codemirror editor.  If false (default) will be fired on 'changes'
    },
    'javascript': {
        toolbar: ['search', 'goto', 'undo', 'redo', 'fontsize', 'wordwrap', 'fullscreen', 'lint-toggle'],
        modeRequire: "cm/mode/javascript/javascript",
        cmPlugins: {js: hyf.cmui.baseJsPlugins.concat(['cm/addon/fold/brace-fold',
                                                       'cm/addon/edit/matchbrackets',
                                                       'cm/addon/lint/lint',
                                                       'cm/addon/lint/javascript-lint',
                                                       'cm/addon/lint/jshint',
                                                       'cm/addon/hint/show-hint',
                                                       'cm/addon/hint/javascript-hint']),
                    css: hyf.cmui.baseCssPlugins.concat(['cm/addon/lint/lint.css',
                                                         'cm/addon/hint/show-hint.css'])
        },
        cmOptions: {lint: false,
                    gutters: ["CodeMirror-lint-markers", "CodeMirror-linenumbers", "CodeMirror-foldgutter"],
                    theme: 'hyf-js'}
    },
    'css': {
        toolbar: ['search', 'goto', 'undo', 'redo', 'fontsize', 'wordwrap', 'fullscreen', 'lint-toggle'],
        modeRequire: "cm/mode/css/css",
        cmPlugins: {js: hyf.cmui.baseJsPlugins.concat(['cm/addon/fold/brace-fold',
                                                       'cm/addon/edit/matchbrackets',
                                                       'cm/addon/lint/lint',
                                                       'cm/addon/lint/css-lint',
                                                       'cm/addon/lint/csslint',
                                                       'cm/addon/hint/show-hint',
                                                       'cm/addon/hint/css-hint']),
                    css: hyf.cmui.baseCssPlugins.concat(['cm/addon/lint/lint.css',
                                                         'cm/addon/hint/show-hint.css'])
        },
        cmOptions: {lint: false,
                    gutters: ["CodeMirror-lint-markers", "CodeMirror-linenumbers", "CodeMirror-foldgutter"],
                    lintOptions: {ignore: ['zero-units', 'ids', 'adjoining-classes', 'overqualified-elements']}
        }


    },
    'xml': {
        toolbar: ['search', 'goto', 'undo', 'redo', 'fontsize', 'wordwrap', 'fullscreen', 'xml-pretty-print'],
        modeRequire: "cm/mode/xml/xml",
        cmPlugins: {js: hyf.cmui.baseJsPlugins.concat(['cm/addon/fold/xml-fold',
                                                       'cm/addon/edit/matchtags',
                                                       'cm/addon/edit/closetag']),
                    css: hyf.cmui.baseCssPlugins
        },
        cmOptions: {matchTags: true,
                    autoCloseTags: true}
    },
    'sql': {
        modeRequire: "cm/mode/sql/sql",
        cmPlugins: {js: hyf.cmui.baseJsPlugins.concat(['cm/addon/fold/brace-fold',
                                                       'cm/addon/edit/matchbrackets',
                                                       'cm/addon/hint/show-hint',
                                                       'cm/addon/hint/sql-hint']),
                    css: hyf.cmui.baseCssPlugins.concat(['cm/addon/hint/show-hint.css'])
        },
        cmOptions: {mode: 'text/x-sql',
                    theme: 'hyf-js'}
    },
    'java': {
        modeRequire: "cm/mode/clike/clike",
        cmOptions: {mode: 'text/x-java'}
    },
    'html': {
        toolbar: ['search', 'goto', 'undo', 'redo', 'fontsize', 'wordwrap', 'fullscreen', 'xml-pretty-print'],
        modeRequire: "cm/mode/htmlmixed/htmlmixed",
        cmPlugins: {js: hyf.cmui.baseJsPlugins.concat(['cm/addon/fold/xml-fold',
                                                       'cm/addon/edit/matchtags',
                                                       'cm/addon/edit/closetag',
                                                       'cm/addon/hint/show-hint',
                                                       'cm/addon/hint/xml-hint',
                                                       'cm/addon/hint/html-hint']),
                    css: hyf.cmui.baseCssPlugins.concat(['cm/addon/hint/show-hint.css'])
        },
        cmOptions: {mode: 'text/html',
                    matchTags: true,
                    autoCloseTags: true}
    }

};


/** Loads and initialises a new CMUI editor instance for the given
 * textarea.
 * @param textareaId The ID of the textarea to replace with an editor instance.
 * @param mode String specifying the mode of the editor, eg 'javascript'
 * @param options (Optional) override the default display options for this editor instance.
 * @param state (Optional) XML DOM containing the state information to recreate in the new editor.
 *              This format of this must be that retured by getState()
 * @return the newly created hyf.cmui.editorInst object.
 */
hyf.cmui.loadEditor = function(textareaId, mode, options, state)
{
    if ((typeof(options) == 'undefined') || (options == null))
        options = {};

    //if it has already been loaded, then just return the existing instance.
    if (hyf.cmui.editors[textareaId])
    {
        return hyf.cmui.editors[textareaId];
    }
    else
    {
        hyf.cmui.initStyling();
        //combine all the different options.
        //Passed in options take priority over mode specific defaults, which themselves take priority over global defaults
        var allOpts;
        if (hyf.cmui.defaults[mode])
        {
            allOpts = dojo.mixin({}, hyf.cmui.defaults.all, hyf.cmui.defaults[mode], options);
            allOpts.cmOptions = dojo.mixin({}, hyf.cmui.defaults.all.cmOptions, hyf.cmui.defaults[mode].cmOptions, options.cmOptions);
        }
        else
        {
            allOpts = dojo.mixin({}, hyf.cmui.defaults.all, options);
            allOpts.cmOptions = dojo.mixin({}, hyf.cmui.defaults.all.cmOptions, options.cmOptions);
        }

        if (!allOpts.cmOptions.mode)
            allOpts.cmOptions.mode = mode;

        if (!allOpts.modeRequire)
            allOpts.modeRequire = "cm/mode/" + allOpts.cmOptions.mode + "/" + allOpts.cmOptions.mode;

        var ed = new hyf.cmui.editorInst(textareaId, allOpts);

        hyf.cmui.editors[textareaId] = ed;

        //draw the new editor on screen
        ed.draw(state);

        return ed;
    }
};


/** Destroys the editor with the given id. */
hyf.cmui.destroyEditor = function(textareaId)
{
    if (hyf.cmui.editors[textareaId])
    {
        var ed = hyf.cmui.editors[textareaId]
        hyf.cmui.editors[textareaId] = null;
        delete hyf.cmui.editors[textareaId];
        ed.destroy();

    }
};

/**
 * Gets the CMUI editorInst object for the given id, or null if a match wasnt found.
 * @param editorId The id of the editor instance to return
 * @return The hyf.cmui.editorInst object for the given editor, or null.
 */
hyf.cmui.get = function(editorId)
{
    if (hyf.cmui.editors[editorId])
        return hyf.cmui.editors[editorId];
    else
        return null;
};


/** Loads the needed css files on the page. */
hyf.cmui.initStyling = function()
{
    hyf.cmui.insertCssLink('cm/lib/codemirror.css');
    hyf.cmui.insertCssLink('cmui/cmui.css');
};

/**
 * Makes sure the provided CSS file has been loaded on the current page.
 * If it has already been loaded (by this method) this wont do anything.
 * Otherwise this will add a new link element ot the page to load in the required file.
 * @param cssPath The relative path to the CSS file to load.
 */
hyf.cmui.insertCssLink = function(cssPath)
{
    if (!hyf.cmui.loadedCss[cssPath])
    {
        var head = document.getElementsByTagName('head')[0];

        var link = document.createElement('link');
        link.rel = 'stylesheet';
        link.type = 'text/css';
        link.href = hyf.cmui.urlBase + '/' + cssPath;
        //Add version param
        if (WM_VERSION_CODE)
            link.href += '?v=' + WM_VERSION_CODE;
        head.appendChild(link);

        hyf.cmui.loadedCss[cssPath] = true;
    }
};



/**
 * Register a plugin for the cmui editor.
 * Plugins are used to provide custom toolbar or status bar functionality.
 * @param features An array of feature names that this plugin provides.
 * @param plugin The plugin instance.  This must have the following functions:
 *          renderFeature(featureName, editorId)
 *              Will be called during editor init, and should
 *              return the HTML to display for the given feature.
 *          handleFeature(featureName, editorId)
 *              Should perform the required functionality for the given feature.
 */
hyf.cmui.registerPlugin = function(features, plugin)
{
    hyf.cmui.plugins.push({'features': features, 'plugin': plugin});
};

/**
 * Global handler function for dealing with toolbar button clicks, which will
 * delegate it to the appropraite CMUI plugin.
 * @param featureName The name of the feature to handle.
 * @param editorId The ID of the CMUI editor that the feature has been requested for.
 */
hyf.cmui.handleFeature = function(featureName, editorId)
{
    //make sure the editor has this feature enabled
    if (!hyf.cmui.editors[editorId])
        return;

    if ((dojo.indexOf(hyf.cmui.editors[editorId].options.toolbar, featureName) == -1) &&
        (dojo.indexOf(hyf.cmui.editors[editorId].options.statusbar, featureName) == -1))
        return


    //find the plugin that provides this feature
    for (var i = 0; i < hyf.cmui.plugins.length; ++i)
    {
        if (dojo.indexOf(hyf.cmui.plugins[i].features, featureName) != -1)
        {
            hyf.cmui.plugins[i].plugin.handleFeature(featureName, editorId);
        }
    }
};

/**
 * Utility function to return the HTML content to use for a CMUI toolbar button.
 * This will generally be used from a plugin's renderFeature method.
 * @param featureName The name of the feature this button is for.
 * @param editorIf The ID of the editor instance this button is for.
 * @param tooltip A helper string to show to the user.
 */
hyf.cmui.getToolbarButtonHTML = function(featureName, editorId, tooltip)
{
    return '<a id="' + editorId + '_' + featureName + '" class="cmuiToolbarBtn ' + featureName +
                ' " onclick="hyf.cmui.handleFeature(\'' + featureName + '\', \'' + editorId +
                '\');" title="' + tooltip + '"></a>'

};


/**
 * The constructor for the main CMUI editor instance object.  There will be one of these created for every
 * editor displayed on the page,
 * This provides a wrapper around the actual codemirror editor instance, and manages
 * the required toolabr and status bar options.
 * @param textareaId The id of the textarea on the page to replace with
 *                   the custom codemirror editor.
 * @param opts An array of config options.
 */
hyf.cmui.editorInst = function(textareaId, opts)
{
    this.id = textareaId;
    this.textarea = dojo.byId(textareaId);

    if (this.textarea == null)
    {
        //should we throw an error here??
        throw new Error("Textarea can't be found.")
    }

    this.options = opts;

    this.active = true;
    this.started = false;

}

/**
 * The is the main rendering process for a CMUI editor.
 * @param state (Optional) XML DOM containing the state information to recreate in the new editor.
 *              This format of this must be that retured by getState()
 */
hyf.cmui.editorInst.prototype.draw = function(state)
{
    this.container = document.createElement('div');
    this.container.id = this.id + '_cmui_container';
    this.container.className = "cmuiContainer";

    //stop mouse down events from bubbling up to the container
    //as we use this event for drag drop etc
    var con = this.container;
    require(['dojo/on'], function(on) {
            on(con, 'mousedown', function (evt)
                    {
                        if (evt)
                        {
                            evt.cancelBubble = true;
                            if (evt.preventDefault)
                                evt.preventDefault();
                            if (evt.stopPropagation)
                                evt.stopPropagation();
                        }
                    });
    });

    if (state && state.selectSingleNode('/cmui_editor_state/size'))
    {
        var sizeElem = state.selectSingleNode('/cmui_editor_state/size');
        this.sizeContainer(sizeElem.getAttribute('width'), sizeElem.getAttribute('height'));
    }
    else
        this.sizeContainer();

    this.toolbarDiv = document.createElement('div');
    this.toolbarDiv.id = this.id + '_cmui_toolbar';
    this.toolbarDiv.className = "cmuiToolbar";

    this.editorDiv = document.createElement('div');
    this.editorDiv.id = this.id + '_cmui_editor';
    this.editorDiv.className = "cmuiEditor";

    this.statusDiv = document.createElement('div');
    this.statusDiv.id = this.id + '_cmui_status';
    this.statusDiv.className = "cmuiStatus";


    this.container.appendChild(this.toolbarDiv);
    this.container.appendChild(this.editorDiv);
    this.container.appendChild(this.statusDiv);

    this.textarea.parentNode.insertBefore(this.container, this.textarea);
    this.textarea.style.display = 'none';


    this.initEditor();


    this.initToolbar();


    this.initStatus();

    //give the editor the right size
    this.sizeEditor();

    if (state)
    {
        var thisObj = this;
        thisObj.whenEditorLoaded(function() {
                var features = state.selectNodes('/cmui_editor_state/active_features/feature');
                for (var i = 0; i < features.length; ++i)
                {
                    hyf.cmui.handleFeature(getElementText(features.item(i)), thisObj.id);
                }

                //now set the cursor position
                var cPos = state.selectSingleNode('/cmui_editor_state/cursor');
                if (cPos != null)
                {
                    thisObj.editor.getDoc().setCursor(Number(cPos.getAttribute('line')), Number(cPos.getAttribute('ch')));
                }

        });
    }

    this.started = true;

}

/**
 * Sizes the container DIV for this CMUI editor instance to be the same as the
 * textarea that it is replacing.
 * @param width (Optional) Explicit width override to use instead of the textarea width.
 * @param height (Optional) Explicit height override to use instead of the textarea height.
 */
hyf.cmui.editorInst.prototype.sizeContainer = function(width, height)
{
    var tWidth, tHeight;

    if (width && width != '')
    {
        tWidth = parseFloat(width);
    }
    else
    {
        tWidth = this.textarea.offsetWidth;
        tWidth -= parseInt(hyf.util.getCurrentStyle(this.textarea, 'border-left-width'));
        tWidth -= parseInt(hyf.util.getCurrentStyle(this.textarea, 'border-right-width'));
    }

    if (height && height != '')
    {
        tHeight = parseFloat(height);
    }
    else
    {
        tHeight = this.textarea.offsetHeight;
        tHeight -= parseInt(hyf.util.getCurrentStyle(this.textarea, 'border-top-width'));
        tHeight -= parseInt(hyf.util.getCurrentStyle(this.textarea, 'border-bottom-width'));
    }

    this.container.style.width = tWidth + 'px';
    this.container.style.height = tHeight + 'px';
}

/**
 * The actual codemirror initialisation is an async process, so this provides
 * a way of getting some code to run only when this loading has finished.
 * If the editor is loaded the function will run straight away.  Otherwise it will run
 * once the editor is fully loaded.
 * @param func The function to run when the editor is loaded.
 */
hyf.cmui.editorInst.prototype.whenEditorLoaded = function(func)
{
    //make sure this editor is still active
    if (!this.active)
    {
        return;
    }

    if ((this.editor != null) && (this.started))
    {
        func();
    }
    else
    {
        var thisObj = this;
        setTimeout(function() { thisObj.whenEditorLoaded(func); }, 100);
    }
}


/**
 * Initialises the codemirror editor for this CMUI editor instance.
 */
hyf.cmui.editorInst.prototype.initEditor = function()
{
    var editorInst = this;

    //insert all the needed css includes
    if (editorInst.options.cmPlugins && editorInst.options.cmPlugins.css)
    {
        for (var i = 0; i < editorInst.options.cmPlugins.css.length; ++i)
        {
            hyf.cmui.insertCssLink(editorInst.options.cmPlugins.css[i]);
        }
    }

    //check the theme css is loaded if required
    if (this.options.cmOptions.theme && this.options.cmOptions.theme != '')
    {
        hyf.cmui.insertCssLink('cm/theme/' + editorInst.options.cmOptions.theme + '.css');
    }

    this.editorDiv.innerHTML = '<span id="' + this.textarea.id + '_loading_message">Loading document...</span>';

    //ensure we require all the needed script files
    var requireScripts = ["cm/lib/codemirror", editorInst.options.modeRequire];
    if (editorInst.options.cmPlugins && editorInst.options.cmPlugins.js)
        requireScripts = requireScripts.concat(editorInst.options.cmPlugins.js);

    require(hyf.cmui.dojoConfig, requireScripts, function(CodeMirror) {

            if (!editorInst.active)
            {
                return;
            }

            //if CodeMirror is not globally defined then add it
            if (!window.CodeMirror)
                window.CodeMirror = CodeMirror;

            var cmOpts = editorInst.options.cmOptions;
            cmOpts.value = editorInst.textarea.value;
            editorInst.editor = CodeMirror(editorInst.editorDiv, cmOpts);

            //if the textarea had an onchange event defined, hook this up to the codemirror changes event
            if (editorInst.textarea.onchange)
            {
                var changeEvent = (editorInst.options.fireChangeOnBlur) ? 'blur' : 'changes';
                editorInst.editor.on(changeEvent, function(instance, changes) {

                        if (editorInst.ignoreChange)
                        {
                            return;
                        }
                        editorInst.textarea.value = instance.getValue();
                        editorInst.textarea.onchange();
                });
            }

            editorInst.editorDiv.removeChild(document.getElementById(editorInst.textarea.id + '_loading_message'));

            editorInst.sizeEditor();
    });
}

/**
 * Ensures that the codemirror editor instance this wraps is
 * correctly sized for this cmui editor.
 */
hyf.cmui.editorInst.prototype.sizeEditor = function()
{
    if (this.active)
    {
        var requiredWidth = this.container.clientWidth;
        var requiredHeight = this.container.clientHeight;
        var requiredHeight = requiredHeight - this.toolbarDiv.offsetHeight - this.statusDiv.offsetHeight;

        if (this.editor)
        {
            this.editor.setSize(requiredWidth, requiredHeight);
            this.editor.refresh();
        }
    }
}

/**
 * Renders the HTML for the toolbar for this CMUI editor.
 */
hyf.cmui.editorInst.prototype.initToolbar = function()
{
    this.renderFeaturesHTML(this.options.toolbar, this.toolbarDiv);
}

/**
 * Renders the HTML for the status bar for this CMUI editor.
 */
hyf.cmui.editorInst.prototype.initStatus = function()
{
    this.renderFeaturesHTML(this.options.statusbar, this.statusDiv);
}

/**
 * Generic function for rendering the HTML for the given set of features into the
 * provided container.
 * @param features An array of feature names to render in this container.
 * @param container The HTMl container to hold these features.
 */
hyf.cmui.editorInst.prototype.renderFeaturesHTML = function(features, container)
{
    //loop through and render all the toolbar options for this editor
    for (var i = 0; i < features.length; ++i)
    {
        //find out which plugin handles it
        var item = features[i];
        for (var j = 0; j < hyf.cmui.plugins.length; ++j)
        {
            if (dojo.indexOf(hyf.cmui.plugins[j].features, item) != -1)
            {
                container.innerHTML += hyf.cmui.plugins[j].plugin.renderFeature(item, this.textarea.id);
                break;
            }
        }

    }
}


/**
 * Returns details of the current state of this editor instance.
 * this currently includes its size, and any active CMUI plugin features
 * @param includeCursor (Optional) boolean indicating whether to include the cursor position
 *          in the returned information.  Defaults to true.
 * @return An XML DOM containing the state information
 */
hyf.cmui.editorInst.prototype.getState = function(includeCursor)
{
    var respString = '<cmui_editor_state xmlns=""><size width="' + this.container.style.width
                                                + '" height="' + this.container.style.height + '"/>';

    if ((typeof(includeCursor) == 'undefined') || (includeCursor == null) || (includeCursor))
    {
        var cPos = this.editor.getDoc().getCursor();
        respString += '<cursor line="' + cPos.line + '" ch="' + cPos.ch + '"/>';
    }


    var actives = dojo.query('.cmuiToolbarBtn.active', this.toolbarDiv);

    if (actives.length > 0)
    {
        respString += '<active_features>';

        var editorInst = this;

        actives.forEach(function(item) {

                if (item.id.indexOf(editorInst.id) == 0)
                    respString += '<feature>' + item.id.substring(editorInst.id.length + 1) + '</feature>';

        });

        respString += '</active_features>';
    }

    respString += '</cmui_editor_state>';

    return getXMLDocument(respString);
}

/**
 * Destroys this particular CMUI editor, by removing it from the page.
 */
hyf.cmui.editorInst.prototype.destroy = function()
{
    //QUESTION: Any codemirror delete code needed here???
    this.active = false;
    this.textarea.style.display = '';
    this.container.parentNode.removeChild(this.container);

}








//------------------------------------------------------------
//Plugin definitions
//------------------------------------------------------------

//QUESTION: Should these be moved out into separate files???
//Or only some, eg XML stuff???

//undo/redo
hyf.cmui.registerPlugin(['undo', 'redo'], {

        renderFeature: function(featureName, editorId) {
            var tooltip = (featureName == 'undo') ? 'Undo' : 'Redo';
            return hyf.cmui.getToolbarButtonHTML(featureName, editorId, tooltip);
        },
        handleFeature: function(featureName, editorId) {
            if (featureName == 'undo')
            {
                hyf.cmui.editors[editorId].editor.getDoc().undo();
            }
            else if (featureName == 'redo')
                hyf.cmui.editors[editorId].editor.getDoc().redo();
        }
});

hyf.cmui.registerPlugin(['wordwrap'], {

        renderFeature: function(featureName, editorId) {
            return hyf.cmui.getToolbarButtonHTML(featureName, editorId, "Toggle word wrap");
        },
        handleFeature: function(featureName, editorId) {
            var current = hyf.cmui.editors[editorId].editor.getOption('lineWrapping');
            hyf.cmui.editors[editorId].editor.setOption('lineWrapping', !current);
            if (current)
                dojo.removeClass(dojo.byId(editorId + '_' + featureName), 'active')
            else
                dojo.addClass(dojo.byId(editorId + '_' + featureName), 'active')
        }
});

/** The position plugin displays the current cursor position (line and col) details. */
hyf.cmui.registerPlugin(['position'], {

        renderFeature: function(featureName, editorId) {

            if (hyf.cmui.editors[editorId])
            {
                hyf.cmui.editors[editorId].whenEditorLoaded(function() {
                    var ed = hyf.cmui.editors[editorId].editor;
                    var doc = ed.getDoc();
                    ed.on('cursorActivity', function(inst) {
                            dojo.byId(editorId + '_positionCurrentLine').innerHTML = doc.getCursor().line + 1;
                            dojo.byId(editorId + '_positionCurrentCol').innerHTML = doc.getCursor().ch + 1;
                            dojo.byId(editorId + '_positionTotalLine').innerHTML = doc.lineCount();
                    });

                    if (dojo.byId(editorId + '_positionCurrentLine'))
                    {
                        dojo.byId(editorId + '_positionCurrentLine').innerHTML = doc.getCursor().line + 1;
                        dojo.byId(editorId + '_positionCurrentCol').innerHTML = doc.getCursor().ch + 1;
                        dojo.byId(editorId + '_positionTotalLine').innerHTML = doc.lineCount();
                    }
                });
            }

            return '<span class="cmuiPosition">Line <span id="' + editorId + '_positionCurrentLine">'
                    + '</span>, Col <span id="' + editorId + '_positionCurrentCol">'
                    + '</span>, Total lines ' + '<span id="' + editorId + '_positionTotalLine">' + '</span></span>';
        },
        handleFeature: function(featureName, editorId) {
        }
});

//resize plugin
require(['dojo/on'], function(on) {
    hyf.cmui.resizePlugin = {
            renderFeature: function(featureName, editorId) {
                return '<span class="cmuiResize" onmousedown="hyf.cmui.resizePlugin.startResize(\'' + editorId + '\', event)"></span>';
            },
            handleFeature: function(featureName, editorId) {
            },
            startResize: function(editorId, e) {

                hyf.cmui.resizePlugin.basePos = hyf.util.getComponentPosition(hyf.cmui.editors[editorId].container);
                hyf.cmui.resizePlugin.baseMousePos = hyf.util.getMouseCoords(e);
                hyf.cmui.resizePlugin.currentResizeEditorId = editorId;
                hyf.cmui.resizePlugin.resizeInProgress = true;

                hyf.cmui.editors[editorId].toolbarDiv.style.visibility = 'hidden';
                hyf.cmui.editors[editorId].editorDiv.style.visibility = 'hidden';
                hyf.cmui.editors[editorId].statusDiv.style.visibility = 'hidden';
                dojo.addClass(hyf.cmui.editors[editorId].container, 'cmuiResizing');

                hyf.cmui.resizePlugin.moveEvt = on(document, "mousemove", hyf.cmui.resizePlugin.mouseMove);
                hyf.cmui.resizePlugin.upEvt = on(document, "mouseup", hyf.cmui.resizePlugin.mouseUp);
            },

            mouseMove: function(e) {
                var mousePos = hyf.util.getMouseCoords(e);
                var newWidth = hyf.cmui.resizePlugin.basePos.width + (mousePos.x - hyf.cmui.resizePlugin.baseMousePos.x);
                var newHeight = hyf.cmui.resizePlugin.basePos.height + (mousePos.y - hyf.cmui.resizePlugin.baseMousePos.y);

                hyf.cmui.editors[hyf.cmui.resizePlugin.currentResizeEditorId].container.style.width = newWidth + 'px';
                hyf.cmui.editors[hyf.cmui.resizePlugin.currentResizeEditorId].container.style.height = newHeight + 'px';
            },
            mouseUp: function(e) {
                if (hyf.cmui.resizePlugin.resizeInProgress)
                {
                    hyf.cmui.resizePlugin.moveEvt.remove();
                    hyf.cmui.resizePlugin.upEvt.remove();

                    dojo.removeClass(hyf.cmui.editors[hyf.cmui.resizePlugin.currentResizeEditorId].container, 'cmuiResizing');

                    hyf.cmui.editors[hyf.cmui.resizePlugin.currentResizeEditorId].toolbarDiv.style.visibility = 'visible';
                    hyf.cmui.editors[hyf.cmui.resizePlugin.currentResizeEditorId].editorDiv.style.visibility = 'visible';
                    hyf.cmui.editors[hyf.cmui.resizePlugin.currentResizeEditorId].statusDiv.style.visibility = 'visible';

                    hyf.cmui.editors[hyf.cmui.resizePlugin.currentResizeEditorId].sizeEditor();

                    hyf.cmui.resizePlugin.resizeInProgress = false;
                    hyf.cmui.resizePlugin.currentResizeEditorId = null;
                    hyf.cmui.resizePlugin.basePos = null;
                    hyf.cmui.resizePlugin.baseMousePos = null;
                }
            }

    }

    hyf.cmui.registerPlugin(['resize'], hyf.cmui.resizePlugin);
});


//fullscreen plugin
hyf.cmui.fullscreenPlugin = {
        currentEditor: null,

        renderFeature: function(featureName, editorId) {
            return hyf.cmui.getToolbarButtonHTML(featureName, editorId, "Maximise editor");
        },
        handleFeature: function(featureName, editorId) {
            var tbBtn = dojo.byId(editorId + '_' + featureName);
            var active = dojo.hasClass(tbBtn, 'active');

            if (active)
            {
                tbBtn.title = 'Maximise editor';
                dojo.removeClass(hyf.cmui.editors[editorId].container, 'cmuiFullscreen');
                dojo.removeClass(tbBtn, 'active');
                hyf.cmui.fullscreenPlugin.currentEditor = null;
                WinManager.keys.detach(27, hyf.cmui.fullscreenPlugin.cancelFullscreen);
            }
            else
            {
                tbBtn.title = 'Restore editor';
                dojo.addClass(hyf.cmui.editors[editorId].container, 'cmuiFullscreen');
                dojo.addClass(tbBtn, 'active');
                hyf.cmui.fullscreenPlugin.currentEditor = editorId;
                WinManager.keys.attach(27, hyf.cmui.fullscreenPlugin.cancelFullscreen);
            }
            hyf.cmui.editors[editorId].sizeEditor();
        },

        cancelFullscreen: function()
        {
            if (hyf.cmui.fullscreenPlugin.currentEditor != null)
            {
                hyf.cmui.fullscreenPlugin.handleFeature('fullscreen', hyf.cmui.fullscreenPlugin.currentEditor);
            }
        }
}
hyf.cmui.registerPlugin(['fullscreen'], hyf.cmui.fullscreenPlugin);

hyf.cmui.registerPlugin(['search'], {

        renderFeature: function(featureName, editorId) {
            return hyf.cmui.getToolbarButtonHTML(featureName, editorId, "Search");
        },
        handleFeature: function(featureName, editorId) {
            hyf.cmui.editors[editorId].editor.execCommand('find');
        }
});

hyf.cmui.registerPlugin(['goto'], {

        renderFeature: function(featureName, editorId) {
            if (hyf.cmui.editors[editorId])
            {
                hyf.cmui.editors[editorId].whenEditorLoaded(function() {

                    var currentKeys = hyf.cmui.editors[editorId].editor.getOption('extraKeys');
                    currentKeys["Ctrl-L"] = function(cm) {
                        hyf.cmui.handleFeature(featureName, editorId);
                    }
                    hyf.cmui.editors[editorId].editor.setOption('extraKeys', currentKeys);
                });
            }
            return hyf.cmui.getToolbarButtonHTML(featureName, editorId, "Go to line");
        },
        handleFeature: function(featureName, editorId) {

            hyf.cmui.editors[editorId].editor.openDialog('Go to line: <input class="lineNumber"/>', function(lineNum) {
                    hyf.cmui.editors[editorId].editor.getDoc().setCursor(parseInt(lineNum) - 1, 0);
            });

        }
});

hyf.cmui.lintTogglePlugin = {

        gutterName: 'CodeMirror-lint-markers',

        renderFeature: function(featureName, editorId) {
            if (hyf.cmui.editors[editorId])
            {
                hyf.cmui.editors[editorId].whenEditorLoaded(function() {

                    var current = hyf.cmui.editors[editorId].editor.getOption('lint');
                    hyf.cmui.lintTogglePlugin.configureLint(featureName, editorId, current);
                });
            }

            return hyf.cmui.getToolbarButtonHTML(featureName, editorId, "Toggle validation");
        },
        handleFeature: function(featureName, editorId) {

            var current = hyf.cmui.editors[editorId].editor.getOption('lint');
            hyf.cmui.lintTogglePlugin.configureLint(featureName, editorId, !current);
        },

        configureLint: function(featureName, editorId, active) {

            //only want to show the lint gutter if the option is turned on
            var gutters = hyf.cmui.editors[editorId].editor.getOption('gutters').slice();;

            if (active)
            {
                dojo.addClass(dojo.byId(editorId + '_' + featureName), 'active')
                if (dojo.indexOf(gutters, hyf.cmui.lintTogglePlugin.gutterName) == -1)
                    gutters.unshift(hyf.cmui.lintTogglePlugin.gutterName);
            }
            else
            {
                dojo.removeClass(dojo.byId(editorId + '_' + featureName), 'active')
                if (dojo.indexOf(gutters, hyf.cmui.lintTogglePlugin.gutterName) != -1)
                    gutters.splice(dojo.indexOf(gutters, hyf.cmui.lintTogglePlugin.gutterName), 1);
            }

            hyf.cmui.editors[editorId].editor.setOption('gutters', gutters);

            hyf.cmui.editors[editorId].editor.setOption('lint', active);
        }
}
hyf.cmui.registerPlugin(['lint-toggle'], hyf.cmui.lintTogglePlugin);



//xml processing plugin
hyf.cmui.xmlPlugin = function()
{
    this._prettyPrintWIP = {};
};
hyf.cmui.xmlPlugin.prototype.renderFeature = function(featureName, editorId)
{
    //connect up the valdiation etc processing
    var plugin = this;

    if (hyf.cmui.editors[editorId])
    {

        hyf.cmui.editors[editorId].whenEditorLoaded(function() {
                if (typeof(validateXMLImpl) == 'function')
                {
                    //connect up validate on change
                    hyf.cmui.editors[editorId].editor.on('changes', function(instance, changes) {
                            plugin.validateStart(editorId);
                    });
                }


                //automatically pretty print on first render
                var ppOnLoad = hyf.cmui.editors[editorId].editor.getOption('xmlhelper_prettyprint_onload');
                if ((typeof(ppOnLoad) == 'undefined') || (ppOnLoad == null) || (ppOnLoad))
                {
                    //Stop this initial pretty printing from being marked as a change
                    hyf.cmui.editors[editorId].ignoreChange = true;
                    plugin.prettyPrint(editorId, function() {
                            hyf.cmui.editors[editorId].ignoreChange = false;
                    });
                }

                //connect up the check for auto inserting a namespace definition
                if ((typeof(hyf) != 'undefined') &&
                    (typeof(hyf.ns) != 'undefined'))
                {
                    hyf.cmui.editors[editorId].editor.on('change', function(instance, changeObj) {
                            plugin.checkForNamespaceInsertion(editorId, changeObj);
                    });
                }

                //check if we should handle onmouseup to store a dragged in fragment for example
                if (hyf.cmui.editors[editorId].textarea.onmouseup)
                {
                    require(['dojo/on'], function(on) {
                            on(hyf.cmui.editors[editorId].editorDiv, 'mouseup', function(instance, evt) {
                                    hyf.cmui.editors[editorId].textarea.onmouseup(hyf.cmui.editors[editorId].textarea);
                            })
                    });
                }
        });
    }


    if (featureName == 'xml-pretty-print')
    {
        return hyf.cmui.getToolbarButtonHTML(featureName, editorId, "Pretty print");
    }
}
hyf.cmui.xmlPlugin.prototype.handleFeature = function(featureName, editorId)
{
    if (featureName == 'xml-pretty-print')
    {
        this.prettyPrint(editorId);
    }
}

hyf.cmui.xmlPlugin.prototype.validateStart = function(editorId)
{
    if (this.validatorTimeoutId != null)
    {
        window.clearTimeout(this.validatorTimeoutId);
    }

    var delay = (ERROR_CHECK_DELAY) ? ERROR_CHECK_DELAY : 500;
    var plugin = this;
    this.validatorTimeoutId = window.setTimeout(function(){plugin.validate(editorId)}, delay);
}
/**
 * Validates the entered XML fragment using the validateXMLImpl function in the containing page.
 */
hyf.cmui.xmlPlugin.prototype.validate = function(editorId)
{
    //update the value in the original text box
    var ta = hyf.cmui.editors[editorId].textarea;
    ta.value = hyf.cmui.editors[editorId].editor.getValue();

    //call the existing validate function
    validateXMLImpl(ta.id);
}



/**
 * Pretty prints the contents of the editor.
 */
hyf.cmui.xmlPlugin.prototype.prettyPrint = function(editorId, callback)
{
    var currentXML = hyf.cmui.editors[editorId].editor.getValue();

    //make sure dojo is available
    if (!dojo)
        return;


    this._prettyPrintWIP[editorId] = {editorId : editorId, fragments: new Array()}

    if (callback)
        this._prettyPrintWIP[editorId].onEnd = callback;

    //remove the xml declaration etc from the front if present
    var pointer = currentXML.indexOf('<');
    var haveDec = false;
    while ((currentXML.charAt(pointer + 1) == '?') || (currentXML.charAt(pointer + 1) == '!'))
    {
        haveDec = true;
        pointer = currentXML.indexOf('<', pointer + 1);
    }
    if (haveDec)
    {
        this._prettyPrintWIP[editorId].header = currentXML.substr(0, pointer);
        currentXML = currentXML.substr(pointer);
    }


    //collpase any whitespace only text nodes
    currentXML = currentXML.replace(/>\s+</g, '><');
    //remove any whitespace from the end
    currentXML = currentXML.replace(/\s+$/g, '');
    //remove any whitespace from the start
    currentXML = currentXML.replace(/^\s+/g, '');

    var tempDoc = getXMLDocument("<test>" + currentXML + "</test>");

    if (Sarissa.getParseErrorText(tempDoc) != Sarissa.PARSED_OK)
    {
        if (WinManager.alert)
            WinManager.alert({strMsg: 'Please ensure the XML content is valid.<br/><Pre>' + Sarissa.getParseErrorText(tempDoc) + '</pre>', strTitle: 'Invalid XML'});
        else
            alert('Please ensure the XML content is valid./n/n/n' + Sarissa.getParseErrorText(tempDoc));
    }
    else
    {
        //loop through each root element
        var elems = tempDoc.documentElement.childNodes;


        for (var i = 0; i < elems.length; ++i)
        {
            var testString = xmlToString(elems.item(i));
            //store the non pretty printed string for now incase the pretty print fails
            this._prettyPrintWIP[editorId].fragments[i] = {string: testString, processed: false, needNewLine: false};

            //add a new line between each (non text) node
            if ((i > 0) && (elems.item(i - 1).nodeType != 3) && (elems.item(i).nodeType != 3))
                this._prettyPrintWIP[editorId].fragments[i].needNewLine = true;


            if (elems.item(i).nodeType == 1) //element node
            {
                //attempt to call the pretty print service on the server so that
                //we can correctly format the XML in all browsers
                var req = '<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body><xfact:pretty_print xmlns:xfact="http://www.hyfinity.com/xfactory"><xfact:request><xfact:xml_string>'
                            + this.escapeXMLCharacters(testString) + '</xfact:xml_string></xfact:request></xfact:pretty_print></soap:Body></soap:Envelope>';

                var plugin = this;
                dojo.xhrPost({
                        url:        'pretty_print.do',
                        postData:   req,
                        handleAs:   'text',
                        headers:    {SOAPAction: 'pretty_print'},
                        editorId: editorId,
                        fragmentIndex: i,
                        handle:     function(response, ioArgs) {
                                var fragmentIndex = ioArgs.args.fragmentIndex;

                                var respDoc = getXMLDocument(response);
                                if (Sarissa.getParseErrorText(respDoc) == Sarissa.PARSED_OK)
                                {
                                    Sarissa.setXpathNamespaces(respDoc, 'xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xfact="http://www.hyfinity.com/xfactory"');

                                    var ppNode = respDoc.selectSingleNode("/soap:Envelope/soap:Body/xfact:pretty_print/xfact:response[xfact:outcome/xfact:successful = 'true']/xfact:xml_string");
                                    if (ppNode != null)
                                    {
                                        plugin._prettyPrintWIP[ioArgs.args.editorId].fragments[fragmentIndex].string = getElementText(ppNode);
                                    }
                                }
                                plugin._prettyPrintWIP[ioArgs.args.editorId].fragments[fragmentIndex].processed = true;
                        }
                    });

            }
            else
            {
                this._prettyPrintWIP[editorId].fragments[i].processed = true;
            }
        }
        //initiate the checking for when all the fragments have been processed
        this.checkUpdateDisplayFollowingPrettyPrint(editorId);
    }
}

hyf.cmui.xmlPlugin.prototype.checkUpdateDisplayFollowingPrettyPrint = function(editorId)
{
    var finished = true;
    for (var i = 0; i < this._prettyPrintWIP[editorId].fragments.length; ++i)
    {
        if (this._prettyPrintWIP[editorId].fragments[i].processed == false)
        {
            finished = false;
            break;
        }
    }

    if (finished)
    {
        var finalString = '';

        if (this._prettyPrintWIP[editorId].header)
        {
            finalString += this._prettyPrintWIP[editorId].header;
        }

        for(var fragmentId = 0; fragmentId < this._prettyPrintWIP[editorId].fragments.length; ++fragmentId)
        {
            if (this._prettyPrintWIP[editorId].fragments[fragmentId].needNewLine == true)
                finalString += '\n';
            finalString += this._prettyPrintWIP[editorId].fragments[fragmentId].string;
        }


        //calling setValue seems to always scroll the display to the bottom,
        //so we determine the current scroll amount, and try and put it back
        //to this value after the value has been updated
        var cm = hyf.cmui.editors[editorId].editor;
        var currentPos = cm.getCursor();
        var currentScroll = cm.getScrollerElement().scrollTop;
        cm.setValue(finalString);
        cm.setCursor(currentPos);
        cm.scrollTo(null, currentScroll);

        if (typeof(this._prettyPrintWIP[editorId].onEnd) == 'function')
            this._prettyPrintWIP[editorId].onEnd();


        this._prettyPrintWIP[editorId] = null;
        delete this._prettyPrintWIP[editorId];
    }
    else
    {
        var plugin = this;
        window.setTimeout(function() {plugin.checkUpdateDisplayFollowingPrettyPrint(editorId)}, 5);
    }
}

/**
 * Checks if the lates chaneg defined a new prefixed element, and if so looks if we can autoamtically
 * add the namespace definition if needed.
 */
hyf.cmui.xmlPlugin.prototype.checkForNamespaceInsertion = function(editorId, changeObj)
{
    //now check for a space to see if a new element has been typed,
    //and so see if we can auto insert a namespace definition.
    if (changeObj.text && (changeObj.text.length == 1) && (changeObj.text[0] == ' '))
    {
        //take some of the previous text content. This gets the current line to stop the whole document being processed if it is big,
        //but still hopefully have the opening tag name.
        var textBefore = hyf.cmui.editors[editorId].editor.getRange({line: changeObj.from.line, ch: 0}, changeObj.from);

        var tagName = '';
        var valid = false;

        for (var i = textBefore.length; i >= 0; --i)
        {
            if (textBefore.charAt(i) == ' ')
            {
                valid = false;
                break;
            }

            if (textBefore.charAt(i) == '<')
            {
                valid = true;
                break;
            }
            tagName = textBefore.charAt(i) + tagName;
        }

        if (valid)
        {
            var nsDef = this.getNsDefInsertion(tagName, editorId, changeObj);
            if (nsDef.length > 0)
            {
                hyf.cmui.editors[editorId].editor.replaceRange(nsDef, changeObj.from);
            }
        }
    }
}

hyf.cmui.xmlPlugin.prototype.getNsDefInsertion = function(tagName, editorId, changeObj)
{
    //check for namespace prefix in the tag name
    var cPos = tagName.indexOf(':');
    if (cPos != -1)
    {
        var prefix = tagName.substr(0, cPos);

        //check if the prefix is defined already in the document
        //TODO: This is not a very good check, as it ignores the document structure. A namespace could
        //be defined on a preceding element that is not a parent of the current one!
        var previousContent = hyf.cmui.editors[editorId].editor.getRange({line: 0, ch: 0}, changeObj.from);
        if (previousContent.indexOf('xmlns:' + prefix + '=') != -1)
        {
            //already exists so return
            return '';
        }

        //check if the prefix is defined in the namespaces set
        if (hyf.ns.namespaces[prefix])
        {
            return ' xmlns:' + prefix + '="' + hyf.ns.namespaces[prefix] + '"';
        }
    }
    return '';
}



/**
 * Converts any of the five XML entities in the given string to
 * their escaped versions.
 * @param XMLString The string to check for the XML characters.
 */
hyf.cmui.xmlPlugin.prototype.escapeXMLCharacters = function(XMLString)
{
    if ((XMLString != null) || (typeof(XMLString) != 'undefined'))
    {
        XMLString = XMLString.replace(/&/gi , "&amp;");
        XMLString = XMLString.replace(/</gi , "&lt;");
        XMLString = XMLString.replace(/>/gi , "&gt;");
        XMLString = XMLString.replace(/'/gi , "&apos;");
        XMLString = XMLString.replace(/"/gi , "&quot;");
        return XMLString;
    }
}

hyf.cmui.registerPlugin(['xml-pretty-print'], new hyf.cmui.xmlPlugin());


/** Priovides the external edit button in the bottom right for the XSV and DRV screens. */
hyf.cmui.registerPlugin(['xsv-external-edit'], {

        renderFeature: function(featureName, editorId) {
            return '<span class="cmuiExternalEditBtn" id="' + editorId + 'cmuiExternalEditBtn_container">' +
                   '<a class="button" href="javascript: externalEditFromEditScreen();">Edit in External Editor</a></span>';
        },
        handleFeature: function(featureName, editorId) {
        }
});




/**
 * The file path plugin handles using a new DRV window to insert the relative path to a local file.
 * eg image locations in a CSS file.
 */
hyf.cmui.filePathPlugin = function()
{
    this.baseDir = '';
    this.subPath = '';
}


hyf.cmui.filePathPlugin.prototype.initPaths = function()
{
    if (document.getElementById('rootDir'))
    {
        this.baseDir = document.getElementById('rootDir').value;
        var currentDir = document.getElementById('currentDir').value;
        if (currentDir.indexOf(this.baseDir) == 0)
            this.subPath = currentDir.substr(this.baseDir.length + 1);
    }

}

hyf.cmui.filePathPlugin.prototype.renderFeature = function(featureName, editorId)
{
    if (this.baseDir == '')
    {
        this.initPaths();
    }

    if (featureName == 'insert_file_path')
    {
        return hyf.cmui.getToolbarButtonHTML(featureName, editorId, "Insert the relative path to another local file");
    }
    else if (featureName == 'insert_image_path')
    {
        return hyf.cmui.getToolbarButtonHTML(featureName, editorId, "Insert the relative path to a local image file");
    }
}

hyf.cmui.filePathPlugin.prototype.handleFeature = function(featureName, editorId)
{
    switch(featureName)
    {
        case "insert_file_path":
            this.insertFilePath('', editorId);
            break;
        case "insert_image_path":
            this.insertFilePath('images', editorId);
            break;
    }
}

hyf.cmui.filePathPlugin.prototype.insertFilePath = function(requestedSubPath, editorId)
{

    if (document.getElementById('cmuiFilePathSelectNonXStoreForm') == null)
    {
        var formHTML = '<form name="cmuiFilePathSelectNonXStoreForm" id="cmuiFilePathSelectNonXStoreForm" action="../directoryviewer/listDir.do" method="post">' +
        '<input type="hidden" name="dir" value=""/>' +
        '<input type="hidden" name="subpath" value=""/>' +
        '</form>';

        var formCont = document.createElement('div');
        formCont.setAttribute('id', 'cmuiFilePathSelectNonXStoreFormCont');
        formCont.innerHTML = formHTML;
        document.body.appendChild(formCont);
    }

    document.cmuiFilePathSelectNonXStoreForm.dir.value = this.baseDir;
    document.cmuiFilePathSelectNonXStoreForm.subpath.value = requestedSubPath;

    var plugin = this;

    window.directoryViewerSelectionCallback = function (fullPath, relativePath, fileName)
        {
            var newPath = '';
            var temp = plugin.subPath;

            while (temp != '')
            {
                newPath += '../';
                if (temp.indexOf('/') != -1)
                {
                    temp = temp.substr(temp.indexOf('/') + 1);
                }
                else
                {
                    temp = '';
                }
            }

            newPath += relativePath;

            //now insert it into the textarea at the current location
            hyf.cmui.get(editorId).editor.replaceRange(newPath, hyf.cmui.get(editorId).editor.getCursor());

        };

    WinManager.resolveFormTargetStartWithOptions(document.cmuiFilePathSelectNonXStoreForm,
                {
                    displayMode: 'dialog',
                    dialogOptions: {
                            title: 'Select File',
                            size: 'full',
                            maxWidth: 900,
                            minHeight: 450,
                            buttons: [{caption: 'Select File', title: 'Inserts the relative path to the selected file into the current document', disable: true, reason:'attach'}, 'cancel'],
                            onAttach: function()
                            {
                                var win = WinManager.getOpenWindows("DRV", WinManager.getProjectInformation().project_name, "DocumentSelection", "DRV")[0];
                                if (win)
                                {
                                    win.returnFileDetails();
                                }
                                //always return false, as if needed the message box will already have been closed
                                return false;
                            }
                    }
                },
                "DRV", WinManager.getProjectInformation().project_name, "DocumentSelection", "DRV");


}

hyf.cmui.registerPlugin(['insert_file_path', 'insert_image_path'], new hyf.cmui.filePathPlugin());
