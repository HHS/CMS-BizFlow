/*
* Copyright (c) 2008 Hyfinity Limited. All rights reserved.
*/

dojo.require("dojo/cookie");
dojo.require("dojo/io-query");

/**
 * Main Windows Manager that keeps track of main windows for each WebMaker application instance.
 */
WinManager = {
    name: 'WM' + new Date().getTime(),  //Timestamp used to ensure unique window names for each WebMaker instance.
    version: 1.0,
    arrWindows: new Array(),			//Collection of main active windows.
    arrReusableWindows: new Array(), 	//Collection of reusable windows. This is used to cater for involuntary unload and load events.
    ignoreChanges: false,               //flag indicating whether unsaved changes should be checked for when closing windows or not.

    currentTab: null,                   //stores a reference to the wmWindow object for the currently selected tab.

    projectInformation: null,           //Stores details about the currently open project
    projectDeployRequired: false,       //Indicates whether a project deployment is required for the current project before it can be run

    //this stores the list of menu operations that are not directly dependent on
    //tab specific functionality.
    //the enabled state here should be that when the screen is first loaded, before a project is selected
    defaultOperations: [{strId: "new_project", bEnabled: true},
                        {strId: "open_project", bEnabled: true},
                        {strId: "copy_project", bEnabled: false},
                        {strId: "delete_project", bEnabled: false},
                        {strId: "delete_workspace", bEnabled: true},
                        {strId: "import_project", bEnabled: true},
                        {strId: "export_project", bEnabled: false},
                        {strId: "export_project_template", bEnabled: false},
                        {strId: "project_settings", bEnabled: false},
                        {strId: "project_properties", bEnabled: false},
                        {strId: "save_all_tabs", bEnabled: false, bHidden : true},
                        {strId: "revert_project", bEnabled: false},
                        {strId: "close_tab", bEnabled: false},
                        {strId: "close_all_tabs", bEnabled: false},
                        {strId: "run_local", bEnabled: false},
                        {strId: "run_local_settings", bEnabled: false},
                        {strId: "debugger", bEnabled: false},
                        {strId: "logs_clear", bEnabled: false},
                        {strId: "service_tester", bEnabled: false},
                        {strId: "publish", bEnabled: false},
                        {strId: "publish_settings", bEnabled: false},
                        {strId: "documentation", bEnabled: true},
                        {strId: "getting_started", bEnabled: true},
                        {strId: "getting_started_tips", bEnabled: true},
                        {strId: "wmforum", bEnabled: true},
                        {strId: "about", bEnabled: true},
                        {strId: "preferences", bEnabled: true},
                        {strId: "check_in", bEnabled: false},
                        {strId: "check_out", bEnabled: false},
                        {strId: "cancel_check_out", bEnabled: false},
                        {strId: "view_history", bEnabled: false},
                        {strId: "share_project", bEnabled: false},
                        {strId: "download_project", bEnabled: false},
                        {strId: "remove_project", bEnabled: false},
                        {strId: "connect_server", bEnabled: true},
                        {strId: "disconnect_server", bEnabled: false}],
    bPromptOnClosure: false,
    /**
    *Window Objects to hold composite window information
    */
    wmWindow: function(strUrl, strWinName, objWin, arrWinDetails)
    {
        this.strUrl = strUrl; 			//Window URL
        this.strWinName = strWinName;	//Window Name
        this.arrWinDetails = arrWinDetails; //Array of strings describing what is shown in this window
        this.objWin = objWin;			//Window Handle
        this.bUnsaved = false;			//Determine if window has unsaved info
        this.suffix = '';				//Used to enable multiple named instances of the same window type
        this.strWinMode = '';           //indicates how this window has been opened - in a 'popup', 'dialog', or a 'tab'
        this.arrOperations = new Array();//List of operations that this window supports
    },
    /**
     * Object used for entries in the arrReusableWindows array.
     * this just wraps a wmWindow object and adds a timestamp;
     */
    reusableWindow: function (wmWin)
    {
        this.wmWin = wmWin;
        this.timestamp = new Date().getTime();
    },

    stylingOutput: true         //All the needed WinManager CSS will be included in the HTML for the base page
}

/**
 * Generic function for attaching events in a cross browser way
 * This deligates to the dojo functionality wherever possible.
 * @param obj The object to attach the event to
 * @param evt A string specifying the type of event, eg 'onclick'
 * @param fnction The function to call when the event occurrs
 * @return a handle that is needed if you ever want to detach the event later.
 */
WinManager.attachEvent = function(obj, evt, fnction)
{
    /*if ((typeof(dojo) != 'undefined') && (typeof(dojo.connect) != 'undefined'))
    {
        return dojo.connect(obj, evt, fnction);
    }
    else*/ if (typeof(obj.attachEvent) != 'undefined') //IE format
    {
        obj.attachEvent(evt, fnction);
    }
    else if (typeof(obj.addEventListener) != 'undefined') //W3C format
    {
        obj.addEventListener(evt.substring(2), fnction, false);
    }
    else
    {
        alert('could not attach event');
    }
}

/**
 * Generic function for detaching events in a cross browser way
 * This deligates to the dojo functionality wherever possible.
 * @param obj The object to detach the event from
 * @param evt A string specifying the type of event, eg 'onclick'
 * @param fnction The function that should no longer be called when the event occurrs
 * @param handle The handle returned from the attachEvent call.
 */
WinManager.detachEvent = function(obj, evt, fnction, handle)
{
    /*if ((typeof(dojo) != 'undefined') && (typeof(dojo.connect) != 'undefined') && (typeof(handle) != 'undefined'))
    {
        dojo.disconnect(handle);
    }
    else*/ if (typeof(obj.detachEvent) != 'undefined') //IE format
    {
        obj.detachEvent(evt, fnction);
    }
    else if (typeof(obj.removeEventListener) != 'undefined') //W3C format
    {
        obj.removeEventListener(evt.substring(2), fnction, false);
    }
    else
    {
        alert('could not detach event');
    }
}

/**
 * Sets the bUnsaved flag to true to indicate changes have occurred within the window objWin
 * @param objWin Window reference for which the unsaved flag should be set
 */
WinManager.setUnsaved = function(objWin)
{
    var iWinIndex = WinManager.getWindow(objWin);
    if (iWinIndex != -1)
    {
        var wmWin = WinManager.arrWindows[iWinIndex];
        if (!wmWin.bUnsaved)
        {
            wmWin.bUnsaved = true;
            if (wmWin.strWinMode == 'tab')
            {
                WinManager.tabs.setTabDirtyState(WinManager.tabs.getTabName(wmWin), true);
            }

            WinManager.setMenuOperationEnabledSetting('save_tab', true, wmWin.arrOperations);
            WinManager.setMenuOperationEnabledSetting('save_all_tabs', true);
            //Should only set revert all if this tab supports revert so we know at least one tab can be reverted
            if (WinManager.getMenuOperationSetting('revert_tab', wmWin.arrOperations) != null)
            {
                WinManager.setMenuOperationEnabledSetting('revert_tab', true, wmWin.arrOperations);
                WinManager.setMenuOperationEnabledSetting('revert_all_tabs', true);
            }
            WinManager.updateDisplayedMenuOptions();

            if (document.title.charAt(0) != "*")
            {
                //document.title = "* " + document.title + " (modified)";
                document.title = "* " + document.title;
            }
        }
    }
}

/**
 * Clears the bUnsaved flag (sets to false) to indicate there are no changes within the window objWin
 * @param objWin Window reference for which the unsaved flag should be cleared
 * @param dontCommit If true, even if the saveInProgress flag is true, we wont auto commit after clearing these changes.
 *                      Defaults to false if not provided.
 */
WinManager.clearUnsaved = function(objWin, dontCommit)
{
    var iWinIndex = WinManager.getWindow(objWin);
    if (iWinIndex != -1)
    {
        var wmWin = WinManager.arrWindows[iWinIndex];


        //check if we nee to do an auto commit following a save operation
        if ((wmWin.saveInProgress) && (!dontCommit))
        {
            wmWin.saveInProgress = false;
            var msg;
            if (wmWin.commitOnSaveMessage)
            {
                msg = wmWin.commitOnSaveMessage;
                delete wmWin.commitOnSaveMessage;
            }
            else
            {
                msg = WinManager.message.get("winmanager.save.commitMessage", WinManager.getDisplayName(wmWin, false, true))
            }
            WinManager.opHandler.handleCommitChanges(msg);
        }



        if (wmWin.bUnsaved)
        {
            wmWin.bUnsaved = false;
            if (wmWin.strWinMode == 'tab')
            {
                WinManager.tabs.setTabDirtyState(WinManager.tabs.getTabName(wmWin), false);
            }

            //WinManager.setMenuOperationEnabledSetting('save_tab', false, wmWin.arrOperations);
            //WinManager.setMenuOperationEnabledSetting('revert_tab', false, wmWin.arrOperations);

            var anyUnsaved = false;
            var anyRevertable = false
            for (var i = 0; i < WinManager.arrWindows.length; ++i)
            {
                if (WinManager.arrWindows[i].bUnsaved)
                {
                    anyUnsaved = true;

                    if (WinManager.getMenuOperationSetting('revert_tab', WinManager.arrWindows[i].arrOperations) != null)
                    {
                        anyRevertable = true;
                        break;
                    }
                }
            }

            if (!anyUnsaved)
            {
                WinManager.setMenuOperationEnabledSetting('save_all_tabs', false);
                if (document.title.charAt(0) == "*")
                {
                    //document.title = document.title.substring(2, (document.title.length - 11));
                    document.title = document.title.substring(2);
                }
            }
            if (!anyRevertable)
            {
                WinManager.setMenuOperationEnabledSetting('revert_all_tabs', false);
            }
            WinManager.updateDisplayedMenuOptions();
        }
    }
}

/**
 * Gets a new suffix number to use to ensure a unique combined name for a window of the given name
 * @param strWinName Name of the window for which the suffix is required
 * @return The unique suffix to use
 */
WinManager.getNewWinTypeSuffix = function(strWinName)
{
    var intNewSuffix = 0;
    var valid;
    do
    {
        intNewSuffix++;
        valid = true;
        for (i=0; i<WinManager.arrWindows.length; i++)
        {
            if (WinManager.arrWindows[i].strWinName == strWinName)
            {
                if (WinManager.arrWindows[i].suffix == intNewSuffix)
                {
                    valid = false;
                }
            }
        }
    }
    while (!valid)

    return intNewSuffix;
}

/**
 * Returns a boolean indicating whether a duplicate window name was found in the active windows collection
 * @param strWinName Name of the window for which a duplicate search is being made
 * @param partialMatch (Optional) If provided and true, then an existing window whose name starts with the
 *                      strWinName will be considered a match.
 * @return Boolean indicating whether a duplicate window was found with the same name
 */
WinManager.checkDuplicateWinName = function(strWinName, partialMatch)
{
    WinManager.cleanupWindowsArray();
    var bDuplicateFound = false;
    var bPartialFound = false
    for (i=0; i<WinManager.arrWindows.length; i++)
    {
        if (WinManager.arrWindows[i].strWinName == strWinName)
        {
            bDuplicateFound = true;
            break;
        }
        else if(WinManager.arrWindows[i].strWinName.indexOf(strWinName) == 0)
        {
            bPartialFound = true;
        }
    }
    if (bDuplicateFound)
        return true;
    else if ((typeof(partialMatch) != 'undefined') && partialMatch)
        return bPartialFound;
    else
        return false;
}

/**
 * Determines if a window with the same objWin handle already exists within the windows collection
 * @param objWin Reference of the window for which a duplicate search is being made
 * @return Boolean indicating whether a duplicate window was found with the same reference
 */
WinManager.checkDuplicateWinObj = function(objWin)
{
    WinManager.cleanupWindowsArray();
    var bDuplicateFound = false;
    for (i=0; i<WinManager.arrWindows.length; i++)
    {
        if (WinManager.arrWindows[i].objWin == objWin)
        {
            bDuplicateFound = true;
            break;
        }
    }
    return bDuplicateFound;
}

/**
 * removes any entries from the arrwindows array for which the window object
 * is closed or unaccessible.
 */
WinManager.cleanupWindowsArray = function()
{
    for (i=0; i<WinManager.arrWindows.length; i++)
    {
        try
        {
            if (WinManager.arrWindows[i].objWin.closed)
            {
                WinManager.shiftDownWindowsList(i, WinManager.arrWindows);
                --i;
            }

            if (WinManager.arrWindows[i].arrWinDetails[0] != 'Runtime')
            {
                //make sure we still have access to the window document
                WinManager.arrWindows[i].objWin.document;
        }



        }
        catch (e)
        {
            //if we have an error trying to access the window, then assume
            //it is no longer available, so remove it from the list.
            //This seems to happen in IE with closed sub tabs
            WinManager.shiftDownWindowsList(i, WinManager.arrWindows);

            //also try and force a close if not already
            try { WinManager.arrWindows[i].objWin.close() }
            catch (e) {}

            --i;
        }
    }
}

/**
 * Locates the index iWinIndex of window objWin within the windows list
 * @param objWin Reference of the window being searched
 * @return Index of the window if found, else return -1
 */
WinManager.getWindow = function(objWin)
{
    WinManager.cleanupWindowsArray();

    var iWinIndex = -1;
    for (i=0; i<WinManager.arrWindows.length; i++)
    {
        if (WinManager.arrWindows[i].objWin == objWin)
        {
            iWinIndex = i;
            break;
        }
    }
    return iWinIndex;
}

/**
 * Locates the index iWinIndex of window objWin within the reusable windows list
 * @param objWin Reference of the reusabe window being searched
 * @return Index of the reusable window if found, else return -1
 */
WinManager.getReusableWindow = function(objWin)
{
    var iWinIndex = -1;
    for (i=0; i<WinManager.arrReusableWindows.length; i++)
    {
        try
        {
            if (WinManager.arrReusableWindows[i].wmWin.objWin == objWin)
            {
                iWinIndex = i;
                break;
            }
        }
        catch (e)
        {
            //if we have an error trying to access the reusable window, then assume
            //it is no longer reusable, so remove it from the list.
            //This seems to happen in IE with closed sub tabs

            //We no longer do this, as in Edge, any comparison of window objects fails if
            //the window has been reloaded
            //Old entries will be cleared out by the cleanupReusableWindows call
            /*WinManager.shiftDownWindowsList(i, WinManager.arrReusableWindows);
            --i;*/
        }
    }

    //if we couldnt find a macth by comparing window objects, check if we have included
    //window infomraiton in the page URL, and if so try and use these
    if ((iWinIndex == -1) && (objWin.location.href.indexOf('WM_WIN_NAME') != -1))
    {
        //Process the incoming params
        var winParamsString = objWin.location.search.substr((objWin.location.search[0] === "?" ? 1 : 0));
        //Convert + to escaped spaces as dojo only handles the %20 (also check Run test for same processing)
        winParamsString = winParamsString.replace(/\+/g, '%20');
        var params = dojo.queryToObject(winParamsString);

        for (i=0; i<WinManager.arrReusableWindows.length; i++)
        {
            if (WinManager.arrReusableWindows[i].wmWin.strWinName == params['WM_WIN_NAME'])
            {
                if ((WinManager.arrReusableWindows[i].wmWin.suffix == '') ||
                    (WinManager.arrReusableWindows[i].wmWin.suffix == params['WM_WIN_SUFFIX']))
                {
                    iWinIndex = i;
                    //update the window reference in the wmWin object
                    WinManager.arrReusableWindows[i].wmWin.objWin = objWin;
                    break;
                }
            }
        }
    }

    return iWinIndex;
}

/**
 * Inserts an active window into the reusable windows collection.
 * This is used to ensure the window can be reused following involuntary unload of the active window.
 * For example when certain navigation operations are performed within main windows.
 * @param iMainWinIndex Index of the active window to be made reusable
 */
WinManager.makeWindowReusable = function(iMainWinIndex)
{
    //See if the main window is already present in the reusable list
    var iReusableWinIndex = WinManager.getReusableWindow(WinManager.arrWindows[iMainWinIndex].objWin);
    if (iReusableWinIndex == -1)
    {
        WinManager.arrReusableWindows[WinManager.arrReusableWindows.length] = new WinManager.reusableWindow(WinManager.arrWindows[iMainWinIndex]);

        //if this window was displayed as a tab, which is still present, mark it as loading in anticipation of this
        //window being reinstated in the near future
        if (WinManager.arrWindows[iMainWinIndex].strWinMode == 'tab')
        {
            WinManager.tabs.setTabBusyState(WinManager.tabs.getTabName(WinManager.arrWindows[iMainWinIndex]), true);
        }
    }
}

/**
 * Reinstates the window from the reusable list to the main list of windows.
 * This should be one of the main windows such as FM unloaded when navigating deeper
 * @param objWin Reference of main window being searched for in the reusable windows list
 */
WinManager.reinstateWindow = function(objWin)
{
    var wmWin = null;

    //first check the window is not already in the main list
    var activeIndex = WinManager.getWindow(objWin);
    if (activeIndex == -1)
    {
        //now try and reinstate it from the reusable list
        var iWinIndex = WinManager.getReusableWindow(objWin);
        if (iWinIndex != -1)
        {
            wmWin = WinManager.arrReusableWindows[iWinIndex].wmWin

            activeIndex = WinManager.arrWindows.length;

            WinManager.arrWindows[WinManager.arrWindows.length] = wmWin;
            //If a window has had to be reinstated, assume no changes have occurred
            WinManager.clearUnsaved(objWin);
            //remove from reusable windows list
            WinManager.shiftDownWindowsList(iWinIndex, WinManager.arrReusableWindows);

            //clean up stale windows
            WinManager.cleanupReusableWindows();
        }
    }
    else
    {
        wmWin = WinManager.arrWindows[activeIndex];
    }

    //make sure we have the needed styling for any future laoding mesasges etc
    WinManager.checkStylingOutput(objWin);


    if (wmWin != null)
    {
        WinManager.attachEvent(objWin, 'onload', new Function('WinManager.processWindowOnLoad(' + (activeIndex) + ')'));
    }

}

WinManager.processWindowOnLoad = function(winIndex)
{
    var wmWin = WinManager.arrWindows[winIndex];
    if (!wmWin)
        return;

    if (wmWin.strWinMode == 'tab')
    {
        //check if there is a page level loading message, and if not remove busy state
        if (wmWin.objWin.document.getElementById('winManagerLoadingMsgContainerpage') == null)
            WinManager.tabs.setTabBusyState(WinManager.tabs.getTabName(wmWin), false);
    }
    else if (wmWin.strWinMode == 'popup')
    {
        //if it is in a popup dialog, make sure it has the status bar
        WinManager.status.initDisplayInPopup(wmWin.objWin);
    }
    else if (wmWin.strWinMode == 'dialog')
    {
        //for an in page dialog, make sure we have removed the loading message
        WinManager.clearLoadingMessage(wmWin.objWin.parent.document.getElementById(wmWin.objWin.parent.name + 'MsgBoxFrame'), wmWin.objWin.parent)

        //add a key shortcut for escape to close the dialog
        WinManager.keys.attach(27, wmWin.objWin.parent.WinManager.clearMessageBox, false, false, false, false, wmWin.objWin);
    }

    dojo.addClass(wmWin.objWin.document.body, "wm_" + WinManager.productType);

    //make sure we show the correct tooltips
    WinManager.tooltips.attachTipsToPage(null, wmWin.objWin);

    //if this window is a new style app which has the insertContent method, then hook up to this
    //to automatically show new tooltips on ajax calls etc.
    if (wmWin.objWin.dojo && wmWin.objWin.hyf && wmWin.objWin.hyf.hooks && wmWin.objWin.hyf.hooks.contentInserted)
    {
        wmWin.objWin.dojo.connect(wmWin.objWin.hyf.hooks, 'contentInserted', function(container){
                WinManager.tooltips.attachTipsToPage(null, wmWin.objWin);
        })

    }



    //If this is Edge, then we will not be able to reinstate this window later after a page refresh
    //as this will cause Access Denied script errors.
    //Instead, we include detals of the window name in the URL so that these can be checked later.
    //This processing finds all forms on the page that has just been loaded, and adds a submit handler to them
    //that will update the URL on submit to include these extra details.
    if (getEdgeVersion() != null)
    {
        var forms = wmWin.objWin.document.getElementsByTagName('form');
        for (var i = 0; i < forms.length; ++i)
        {
            forms[i].oldSubmit = forms[i].submit;
            forms[i].submit = function() {
                this.action = WinManager.addWinDetailsToSubmitURL(this.getAttribute('action'), wmWin.objWin);
                this.oldSubmit();
            }
        }
    }

}

/**
 * Checks for any stale entries in the reusable windows array
 * and removes any found.
 * A window is considered to be stale if it has been in the list for more than 5 minutes.
 * This occurs when a tab is closed by the user, as we make it reusable incase they were just navigating around
 */
WinManager.cleanupReusableWindows = function()
{
    //assume a window is stale if it is still present after 5 minutes
    var timeCheck = new Date().getTime() - (1000 * 60 * 5);

    for (i=0; i<WinManager.arrReusableWindows.length; i++)
    {
        if (WinManager.arrReusableWindows[i].timestamp < timeCheck)
        {
            //alert('discarding stale window: ' + WinManager.arrReusableWindows[i].wmWin.strWinName + WinManager.arrReusableWindows[i].wmWin.suffix);
            WinManager.shiftDownWindowsList(i, WinManager.arrReusableWindows);
            --i;
        }
    }
}

/**
 * Returns the index of a windows using its name
 * @param strWin Name of window to be located in the main windows list
 * @return Index of named window
 */
WinManager.getWindowUsingName = function(strWin)
{
    //if the provided name includes this WinManager's name at the start, then strip it off first
    if (strWin.indexOf(WinManager.name) == 0)
        strWin = strWin.substr(WinManager.name.length);

    var iWinIndex = -1;
    for (i=0; i<WinManager.arrWindows.length; i++)
    {
        if (WinManager.arrWindows[i].strWinName == strWin)
        {
            iWinIndex = i;
            break;
        }
    }
    return iWinIndex;
}


/**
 * Compacts an individual, undefined, window entry by shifting subsequent entries 'down' by one. This is required when windows are removed causing fragmentation.
 * @param shiftPos Position where the shifting is to start. All items after this position will be shifted 'down'
 * @param arrayToCompact (optional) array to compact.  If not provided, the default arrWindows array will be used.
 */
WinManager.shiftDownWindowsList = function(shiftPos, arrayToCompact)
{
    if (typeof(arrayToCompact) == 'undefined')
    {
        arrayToCompact = WinManager.arrWindows;
    }

    // Shift all entries down by one from shiftPos. This should remove undefined and closed entries.
    for (i=shiftPos; i<arrayToCompact.length-1; i++)
    {
        arrayToCompact[i] = arrayToCompact[i+1];
    }
    // Reduce the list length by one since list has been shifted down by one position.
    arrayToCompact.length = arrayToCompact.length - 1;
}

/**
 * As windows are removed, the windows collection can become fragmented. This compacts the list to remove undefined or closed window handles.
 * Obsolete due to shiftDownWindowsList
 */
WinManager.compactWindowsList = function()
{
    //Walk the windows list
    for (i=0; i<WinManager.arrWindows.length-1; i++)
    {
        //Cater for the fact that some windows may have closed due to unknown errors or actions as well as controlled closure
        if (typeof(WinManager.arrWindows[i].objWin) == "undefined" || WinManager.arrWindows[i].objWin.closed)
        {
            //Everytime an unusable window entry is found, shift all subsequent entries by one - compacting
            WinManager.shiftDownWindowsList(i)
        }
    }
}

/**
 * Takes an array of detail strings for a new window request,
 * and returns the string that should be used as the name of the new window
 * @private
 */
WinManager.determineWindowName = function(arrWinDetails)
{
    var strWinName = '';
    for (var i = 0; i < arrWinDetails.length; ++i)
    {
        strWinName += arrWinDetails[i].replace(/[\s\/\.]/g, "");
    }
    return strWinName;
}

/**
 * Opens a new window, and submits the specified form into it.
 * @param objWin The window object that initiated the call.
 * @param objForm The form to be submitted
 * @param options An object specifiying any advanced options required.  This currently supports the following properties:
 *      windowSettings: String detailing the settings to apply to the new window, eg sizing. This is the third param to the window.open call
 *      duplicateApproach: What to do if the window is already open. Must be either: 'prompt' (the default), 'replace', 'new', 'show'
 *      retainOpener: Boolean indicating whether the new windows opener property must not be altered. By default this will be false, and the
 *                    new windows opener will be the main WinManager window.
 *      displayMode: String specifying how to open the window. supports 'tab', 'popup, 'dialog'. tab is default
 *      dialogOptions: if display mode is set to dialog, this can contain the additional options for the message dialog.
 *                      See createMessageBox for details.
 * @param arrWinDetails An array string parameters describing the window to open
 */
WinManager.resolveFormTarget = function(objWin, objForm, options, arrWinDetails)
{
    options = WinManager.getWindowRequestOptions(options);

    //convert the array of details to a string to generate a window name
    //to use for matching etc.
    var strWinName = WinManager.determineWindowName(arrWinDetails);

    //store the details of this request away for future use.
    WinManager.newWindowRequestDetails = new Object();
    WinManager.newWindowRequestDetails.strUrl = '';
    WinManager.newWindowRequestDetails.strWinName = strWinName;
    WinManager.newWindowRequestDetails.objForm = objForm;
    WinManager.newWindowRequestDetails.options = options;
    WinManager.newWindowRequestDetails.arrWinDetails = arrWinDetails;
    WinManager.newWindowRequestDetails.objWin = objWin;

    //Check if window with the same name already exists
    if ((options.displayMode != 'dialog') && WinManager.checkDuplicateWinName(strWinName))
    {
        var duplicateWin;
        for (i=0; i<WinManager.arrWindows.length; i++)
        {
            if (WinManager.arrWindows[i].strWinName == strWinName)
            {
                duplicateWin = WinManager.arrWindows[i];
                break;
            }
        }

        //if the matching window is not loaded then automatically load into it
        if ((typeof(duplicateWin.loaded) != 'undefined') && !duplicateWin.loaded)
            WinManager.replaceOptionChosen(objWin, 'replace');
        else if (options.duplicateApproach != 'prompt')
            WinManager.replaceOptionChosen(objWin, options.duplicateApproach);
        else
            WinManager.showExistingWindowChoicePopup(objWin, strWinName);
    }
    else
    {
        //No duplicate window name was found. Start a new tab and make a new entry into the windows list.
        WinManager.openRequestedWindow();
    }
}

/**
 * Updates the provided options object to make sure all the supported
 * window opening options are correctly defined.
 * @param options The object of optiosn to check.  If not provided, then the defaults will be returned.
 * @return An object containing the processed options.
 */
WinManager.getWindowRequestOptions = function(options)
{
    if ((options == null) || (typeof(options) == 'undefined'))
        options = {};

    if (!options.windowSettings)
        options.windowSettings = '';
    if (!options.duplicateApproach)
        options.duplicateApproach = 'prompt';
    if (typeof(options.retainOpener) == 'undefined')
        options.retainOpener = 'false';
    if (typeof(options.displayMode) == 'undefined')
        options.displayMode = '';

    return options;
}

/**
 * Shows a popup dialog on the source window so that the user can decide whether or not to replace the
 * existing window when they haven requested to open it again.
 * @param objWin The window object the the open request was made on.
 * @param strWinName The name of the window that has been requested and already exists
 */
WinManager.showExistingWindowChoicePopup = function(objWin, strWinName)
{
    var existingWin = WinManager.arrWindows[WinManager.getWindowUsingName(strWinName)];

    //Let user decide whether the existing window with the same name should be replaced or a new instance opened
    var msg = '<div style="padding : 15px;">You have requested to open the following window: <b>'
    msg += WinManager.getDisplayName(existingWin, false);
    msg += '</b><br/><br/>However, you already have this window open';
    if (existingWin.bUnsaved)
        msg += ', with <b>unsaved changes</b>';
    msg += '.  Please indicate what you would like to do:<br/><br/>';

    msg += '<input type="radio" name="ExitingWindowOption" id="ExistingWindowOptionSwitch" value="switch"';
    if (existingWin.bUnsaved)
        msg += 'checked="checked"';
    msg += '/><label style="padding-left : 5px;" for="ExistingWindowOptionSwitch"><b>Keep Existing Window</b> - Just keep the existing window with the current version.</label><br/><br/>';

    msg += '<input type="radio" name="ExitingWindowOption" id="ExistingWindowOptionReplace" value="replace"';
    if (!existingWin.bUnsaved)
        msg += 'checked="checked"';
    msg += '/><label style="padding-left : 5px;" for="ExistingWindowOptionReplace"><b>Replace Existing Window</b> - Replace the existing window with the latest version'

    if (existingWin.bUnsaved)
        msg += ', discarding any changes';
    msg += '.</label><br/><br/>';

    if (existingWin.arrWinDetails[0] == 'Runtime')
        msg += '<input type="radio" name="ExitingWindowOption" id="ExistingWindowOptionNew" value="new"/><label style="padding-left : 5px;" for="ExistingWindowOptionNew"><b>Open New Window</b> - Open another copy of the content in a new window.</label><br/><br/>';

    msg += '</div>';

    //use a timeout before showing the popup window, to make sure that the current event has bubled all the way up first
    //otherwise we could show the popup, and then the event would bubble up to the document and so close it!
    setTimeout(function(){ objWin.WinManager.displayMessageBox({content:msg, title:'Existing Window', buttons:['ok', 'cancel'], onOk: function(){
                WinManager.replaceOptionChosen(objWin);
                return false;
        }}); }, 1);
}

/**
 * Called when an option has been selected on the 'do you want to replace' popup
 * that is show when a request ahs been amde to open an already existing window.
 * @param objWin The window object the request originated from, and so showed the popup/
 * @param option The chosen option string - 'replace', 'new', or 'switch'
 */
WinManager.replaceOptionChosen = function(objWin, option)
{
    //make sure we are referencing the managed window, as when displaying the message box
    //initially we will find the managed win to display on.
    //eg even if called from bindings frame, will still be shown on whole page design window)
    if (!objWin.WinManager.managedWin)
        objWin = objWin.parent;

    if (typeof(option) == 'undefined')
    {
        option = null;
        if (objWin.document.getElementById('ExistingWindowOptionReplace').checked)
            option = objWin.document.getElementById('ExistingWindowOptionReplace').value;
        else if (objWin.document.getElementById('ExistingWindowOptionNew') && objWin.document.getElementById('ExistingWindowOptionNew').checked)
            option = objWin.document.getElementById('ExistingWindowOptionNew').value;
        else if (objWin.document.getElementById('ExistingWindowOptionSwitch').checked)
            option = objWin.document.getElementById('ExistingWindowOptionSwitch').value;

        if (option == null)
        {
            alert('Please select how you wish to handle the existing window.');
            return;
        }
    }

    objWin.WinManager.clearMessageBox();

    if (typeof(WinManager.newWindowRequestDetails) != 'object')
        return;

    var existingWmWin = WinManager.arrWindows[WinManager.getWindowUsingName(WinManager.newWindowRequestDetails.strWinName)];

    if (option == 'replace')
    {

        //Make a note of the window reference to be replaced because this will be unloaded
        var objReplacedWin = existingWmWin.objWin;


        var existingTargetName = WinManager.name + existingWmWin.strWinName;
        if (existingWmWin.suffix)
            existingTargetName += existingWmWin.suffix;

        //clear knowledge of any changes to stop the user being asked whether to continue, as this will have already been mentioned in the previous popup.
        WinManager.clearUnsaved(objReplacedWin);

        if (WinManager.newWindowRequestDetails.objForm != null)
        {
            //The default bowser behaviour should ensure reuse of the same tab. INFO: the replaced tab will raise an onunload event.
            WinManager.newWindowRequestDetails.objForm.target = existingTargetName;
            WinManager.newWindowRequestDetails.objForm.submit();
        }
        else
        {
            try
            {
                //check if the current URL of the window is the same, and if so just reload it
                //we actually check if the existing URL contains the new one, as the requested URL could be relative,
                //where as the existing one will always be absolute
                if (objReplacedWin.location.href.indexOf(WinManager.newWindowRequestDetails.strUrl) != -1)
                {
                    objReplacedWin.location.reload(true);
                }
                else
                {
                    //if the existing window's url has changed, then set it to the requested URL, as we are
                    //replacing the existing window with the requested one.
                    objReplacedWin.location.href = WinManager.newWindowRequestDetails.strUrl;
                }
            }
            catch (e)
            {
                //in some cases the above will fail, eg for runtime windows, as they are on a different domain,
                //and so we cant aceess the details of them
                //therefore as a fallback we use the window.open method
                window.open(WinManager.newWindowRequestDetails.strUrl, existingTargetName);
            }
        }

        if (existingWmWin.strWinMode == 'tab')
            WinManager.tabs.selectTab(WinManager.tabs.getTabName(existingWmWin));
        else
            objReplacedWin.focus();
    }
    else if (option == 'new')
    {
        //Open same window type with a slightly different name (suffix)
        WinManager.newWindowRequestDetails.intWinSuffix = WinManager.getNewWinTypeSuffix(WinManager.newWindowRequestDetails.strWinName);
        WinManager.openRequestedWindow();
    }
    else //just switch to existing one
    {
        if (existingWmWin.strWinMode == 'tab')
            WinManager.tabs.selectTab(WinManager.tabs.getTabName(existingWmWin));
        else
            existingWmWin.objWin.focus();
    }

    WinManager.newWindowRequestDetails = null;
}


/**
 * Opens a new window as requested in the WinManager.newWindowRequestDetails object.
 */
WinManager.openRequestedWindow = function()
{
    var newWmWindow = new WinManager.wmWindow(WinManager.newWindowRequestDetails.strUrl,
                                          WinManager.newWindowRequestDetails.strWinName,
                                          null,
                                          WinManager.newWindowRequestDetails.arrWinDetails);


    var newWinName = WinManager.name + WinManager.newWindowRequestDetails.strWinName;

    //check if a suffix has been specified to add to the name
    if (WinManager.newWindowRequestDetails.intWinSuffix)
    {
        newWinName += WinManager.newWindowRequestDetails.intWinSuffix;
        newWmWindow.suffix = WinManager.newWindowRequestDetails.intWinSuffix;
    }

    var startUrl = "about:blank";
    if (WinManager.newWindowRequestDetails.objForm == null)
    {
        startUrl = WinManager.newWindowRequestDetails.strUrl;
    }

    if (WinManager.newWindowRequestDetails.options.displayMode == 'dialog')
    {
        var dialogOptions = WinManager.newWindowRequestDetails.options.dialogOptions;
        if (!dialogOptions)
            dialogOptions = {};

        dialogOptions.objWin = WinManager.newWindowRequestDetails.objWin;
        //make sure this is a properly managed window
        while ((dialogOptions.objWin.WinManager) && (!dialogOptions.objWin.WinManager.managedWin) && (dialogOptions.objWin !== dialogOptions.objWin.parent))
            dialogOptions.objWin = dialogOptions.objWin.parent;

        dialogOptions.sourceURL = startUrl;
        if (typeof(dialogOptions.showStatusBar) == 'undefined')
            dialogOptions.showStatusBar = true;

        WinManager.loadIntoMessageBox(dialogOptions);

        newWinName = dialogOptions.objWin.name + 'MsgBoxFrame';

        newWmWindow.objWin = dialogOptions.objWin.document.getElementById(newWinName).contentWindow;

        newWmWindow.strWinMode = 'dialog';

        //add a loading message over the dialog.  This will be removed in the reinstate window process
        if ((typeof(dialogOptions.showLoadingMessage) == 'undefined') || dialogOptions.showLoadingMessage)
            WinManager.showLoadingMessage(dialogOptions.objWin.document.getElementById(newWinName), 'Loading...', dialogOptions.objWin);


    }
    //chck whether it is ok to open from the main winmanager window, or whether
    //we need to maintain the opener property for the new window
    else if ((WinManager.newWindowRequestDetails.options.retainOpener == true) &&
             ((WinManager.newWindowRequestDetails.options.displayMode == '') || (WinManager.newWindowRequestDetails.options.displayMode == 'popup')))
    {
        newWmWindow.objWin = WinManager.newWindowRequestDetails.objWin.open(startUrl,
                            newWinName,
                            WinManager.newWindowRequestDetails.options.windowSettings);

        newWmWindow.strWinMode = 'popup';
    }
    else if ((WinManager.newWindowRequestDetails.options.displayMode == 'popup') ||
             ((WinManager.newWindowRequestDetails.options.windowSettings != '') && (WinManager.newWindowRequestDetails.options.displayMode == '')))
    {
        newWmWindow.objWin = window.open(startUrl,
                            newWinName,
                            WinManager.newWindowRequestDetails.options.windowSettings);

        newWmWindow.strWinMode = 'popup';
    }
    else
    {
        var closable = true;
        if ((WinManager.newWindowRequestDetails.arrWinDetails[0] == 'FormMaker') && (WinManager.newWindowRequestDetails.arrWinDetails[2] == 'AM'))
        {
            closable = false;
        }

        var tabType = WinManager.getWindowTypeString(WinManager.newWindowRequestDetails);

        newWmWindow.objWin = WinManager.tabs.newTab(newWinName, startUrl, WinManager.getDisplayName(WinManager.newWindowRequestDetails, false, true),
                                                    tabType, closable);

        newWmWindow.strWinMode = 'tab';

        //when opening a new tab, it always becomes the selected tab
        WinManager.tabs.handleTabChange(newWmWindow);
    }


    newWmWindow.objWin.name = newWinName;

    if (WinManager.newWindowRequestDetails.objForm != null)
    {
        WinManager.newWindowRequestDetails.objForm.target = newWinName;
        WinManager.newWindowRequestDetails.objForm.submit();
    }

    //Insert the new window into the main windows list
    WinManager.arrWindows[WinManager.arrWindows.length] = newWmWindow

    //check if we have a function to call after openign the window.
    if (typeof(WinManager.newWindowRequestDetails.options.onOpen) == 'function')
        WinManager.newWindowRequestDetails.options.onOpen();

}


/**
 * Main funtion that manages the opening of new windows, resulting from links.
 * @param objWin The window object that initiated the call.
 * @param strURL URL of the new window
 * @param arrWinDetails An array of string parameters describing the window to open
 */
WinManager.openNewChildWindow = function(objWin, strUrl, arrWinDetails, objOptions)
{
    var strWinName = WinManager.determineWindowName(arrWinDetails);

    //store the details of this request away for future use.
    WinManager.newWindowRequestDetails = new Object();
    WinManager.newWindowRequestDetails.strUrl = strUrl;
    WinManager.newWindowRequestDetails.strWinName = strWinName;
    WinManager.newWindowRequestDetails.objForm = null;
    WinManager.newWindowRequestDetails.arrWinDetails = arrWinDetails;
    WinManager.newWindowRequestDetails.objWin = objWin;
    WinManager.newWindowRequestDetails.options = WinManager.getWindowRequestOptions(objOptions);

    //Check if window with the same name already exists
    if ((WinManager.newWindowRequestDetails.options.displayMode != 'dialog') && WinManager.checkDuplicateWinName(strWinName))
    {
        if (WinManager.newWindowRequestDetails.options.duplicateApproach != 'prompt')
            WinManager.replaceOptionChosen(objWin, WinManager.newWindowRequestDetails.options.duplicateApproach);
        else
            WinManager.showExistingWindowChoicePopup(objWin, strWinName);
    }
    else
    {
        //No duplicate window name was found. Start a new tab and make a new entry into the windows list.
        WinManager.openRequestedWindow()
    }
}

/**
 * Check if the given window is already open or not.
 * @param objWin The window object that initiated the call.
 * @param arrWinDetails Array of details for the window.
 * @return boolean indicating whether this window is open or not.
 */
WinManager.isWindowOpenActual = function(objWin, arrWinDetails)
{
    var strWinName = WinManager.determineWindowName(arrWinDetails);

    if (WinManager.checkDuplicateWinName(strWinName, true))
    {
        return true;
    }
    else
    {
        return false;
    }
}

/**
 * Returns an array of window objects for each open window matching the given params
 * @param objWin The window object that initiated the call.
 * @param arrWinDetails Array of details for the window.
 * @return array of found window objects
 */
WinManager.getOpenWindowsActual = function(objWin, arrWinDetails)
{
    var testName = WinManager.determineWindowName(arrWinDetails);
    var winArr = new Array();

    for (i=0; i<WinManager.arrWindows.length; i++)
    {
        if (WinManager.arrWindows[i].strWinName.indexOf(testName) == 0)
        {
            winArr[winArr.length] = WinManager.arrWindows[i].objWin;
        }
    }

    return winArr;
}



/**
 * Adds details about the window ot the given URL string, and returns the updated string.
 * This will add a WM_WIN_NAME parameter, and potentially a WM_WIN_SUFFIX one if required.
 * @param strUrl The original URL to add the details to.
 * @param objWin The window object to add the details from.
 * @return The updated URL string.
 */
WinManager.addWinDetailsToSubmitURL = function(strUrl, objWin)
{
    var iWinIndex = WinManager.getWindow(objWin);
    //Ensure window exists within the windows collection
    if (iWinIndex != -1)
    {
        var winDetails = WinManager.arrWindows[iWinIndex];

        if (strUrl.indexOf('?') == -1)
            strUrl += '?';
        else
            strUrl += '&';


        strUrl += 'WM_WIN_NAME=' + winDetails.strWinName;

        if (winDetails.suffix != '')
            strUrl += '&WM_WIN_SUFFIX=' + winDetails.suffix;

    }

    return strUrl;
}




/**
 * Allows time for each window to close in an orderly manner.
 */
WinManager.checkWinClosed = function ()
{
    if (!WinManager.objClosingWin.closed)
    {
        //Check to ensure latest window marked for closure has sufficient time to complete the closure process
        window.setTimeout("WinManager.checkWinClosed()", 100);
    }
    else
    {
        //Recursively look for the next closure candidate
        WinManager.closeAllWindows();
    }
}

/**
 * Recursive routine to close all windows.
 * This should be called when the WinManager is remaining, eg to switch to a new project.
 * It will close all tabs and popups, maintaining the integrity of the current windows lists.
 * @param windowCheckFunc (Optional) A function that will be called for each windwo to decide if it should be closed or not
 *                      This will be passed the wmWindow object for the window and must return true to close the window.
 *                      If not provided all windows will be closed.
 */
WinManager.closeAllWindows = function(windowCheckFunc)
{
    var iLastWinIndex = WinManager.arrWindows.length-1;

    //if we have a windowCheckFunc see if this window can be closed
    if (windowCheckFunc)
        WinManager.objClosingWindowCheckFunc = windowCheckFunc;
    if (typeof(WinManager.objClosingWindowCheckFunc) == 'function')
    {
        while ((iLastWinIndex >= 0) && (!WinManager.objClosingWindowCheckFunc(WinManager.arrWindows[iLastWinIndex])))
            --iLastWinIndex;
    }

    //Finished if no windows remain.
    if ((iLastWinIndex < 0))
    {
        WinManager.objClosingWin = null;
        WinManager.objClosingWindowCheckFunc = null;
        return;
    }

    if (WinManager.arrWindows[iLastWinIndex].strWinMode == 'tab')
    {
        WinManager.objClosingWin = WinManager.arrWindows[iLastWinIndex].objWin;
        WinManager.tabs.closeTab(WinManager.tabs.getTabName(WinManager.arrWindows[iLastWinIndex]));
        //closing a tab removes it from the list straight away, so can move on to the next window
        WinManager.closeAllWindows();
    }
    else if (WinManager.arrWindows[iLastWinIndex].strWinMode == 'dialog')
    {
        WinManager.objClosingWin = WinManager.arrWindows[iLastWinIndex].objWin;
        WinManager.handleDialogAction(WinManager.objClosingWin, null);
        //closing a tab removes it from the list straight away, so can move on to the next window
        WinManager.closeAllWindows();
    }
    else
    {
        //Check to make sure window handle actually yields a window
        if ((typeof(WinManager.arrWindows[iLastWinIndex].objWin) != 'undefined') && !WinManager.arrWindows[iLastWinIndex].objWin.closed)
        {
            WinManager.objClosingWin = WinManager.arrWindows[iLastWinIndex].objWin;
            //The window.close() call should invoke closeWindow() to perform cleanup
            WinManager.arrWindows[iLastWinIndex].objWin.close();
            //Allow time for the window to close before looking at the next window
            WinManager.checkWinClosed();
        }
        //This means the collection contains a window reference, but actual window has somehow disappeared - perform cleanup of collections only
        else
        {
            //Remember the closeWindow only performs cleanup of the windows collections.
            WinManager.closeWindow(WinManager.arrWindows[iLastWinIndex].objWin, true);
            //Recursively look for the next closure candidate
            WinManager.closeAllWindows();
        }
    }

}


/**
 * Closes all windows within the windows collection without exception.
 * Also, is not concerned with the integrity of the windows collection since full shutdown has been requested.
 * this should only be used when the WinManager browser tab is being closed.
 */
WinManager.hardCloseAllWindows = function()
{
    var arrWinsToBeClosed = new Array();
    for (var i = 0; i<=WinManager.arrWindows.length-1; i++)
    {
        //only need to worry about non tab windows.
        if (WinManager.arrWindows[i].strWinMode == 'popup')
            arrWinsToBeClosed[arrWinsToBeClosed.length] = WinManager.arrWindows[i].objWin;
    }

    //ignore any changes to stop further prompts from other windows
    WinManager.ignoreChanges = true;

    var numwins = arrWinsToBeClosed.length

    for (var i = 0; i < numwins; i++)
    {
        arrWinsToBeClosed[i].close();
    }
}

/**
* Checks status of individual windows to determine whether they require saving before closure
* @param returnHtml Boolean indicating whether or not to return HTML formatted string.  If true,
*             the response will contain br tags, otherwise (the default) it will have \n
* @return String detailing all unsaved windows
*/
WinManager.closeAllWindowsCheck = function(returnHtml)
{
    var strUnsavedWins = "";
    for (i=0; i<WinManager.arrWindows.length; i++)
    {
        if (WinManager.arrWindows[i].bUnsaved)
        {
            strUnsavedWins += WinManager.getDisplayName(WinManager.arrWindows[i], false);
            if (returnHtml)
                strUnsavedWins += "<br/>";
            else
                strUnsavedWins += "\n";
        }
    }

    return strUnsavedWins;
}

/**
 * Closes window using the supplied reference.
 * This just updates the current windows collection accordingly, it does not
 * actually handle the window closing. (ie this should be called onunload of a window)
 * @param objWin Reference of window that requires closure
 */
WinManager.closeWindow = function(objWin, dontReuse)
{
    var iWinIndex = WinManager.getWindow(objWin);
    //Ensure window exists within the windows collection
    if (iWinIndex != -1)
    {
        //check if this is actually displayed in a dialog, and if so
        //we remove any on close notification functions added from this window
        //as these will no longer be valid
        if (WinManager.arrWindows[iWinIndex].strWinMode == 'dialog')
        {
            var msgBoxWin = objWin.parent;
            if (msgBoxWin.WinManager.messageBoxOnClose)
            {
                for (var i = 0; i < msgBoxWin.WinManager.messageBoxOnClose.length; ++i)
                {
                    var obj = msgBoxWin.WinManager.messageBoxOnClose[i];
                    if ((obj.sourceWin) && (obj.sourceWin === objWin))
                    {
                        msgBoxWin.WinManager.messageBoxOnClose.splice(i, 1);
                        i--;
                    }
                }
            }


        }

        //If a window has been closed, assume no changes have occurred
        WinManager.clearUnsaved(objWin, true);

        if ((typeof(dontReuse) == 'undefined') || !dontReuse)
        {
            //Transfer window to the reusable windows list in case we have just navigated to a deeper level rather than closed
            WinManager.makeWindowReusable(iWinIndex);
        }

        //Remove the closed entry from the windows list
        WinManager.shiftDownWindowsList(iWinIndex);

    }
}

/**
* Performs a check during requested closure to ensure unsaved information is not lost
* @param objWin Reference of window that requires closure
*/
WinManager.confirmWinClosure = function(objWin)
{
    var iWinIndex = WinManager.getWindow(objWin);
    if (iWinIndex != -1)
    {
        //Ensure window does not have unsaved information
        if (!WinManager.ignoreChanges && WinManager.arrWindows[iWinIndex].bUnsaved)
        {
            return WinManager.message.get('winmanager.confirmUnsavedChanges');
        }
    }
}

/**
 * Actually force a close of the supplied window.
 */
WinManager.fullWindowClose = function(objWin)
{
    var iWinIndex = WinManager.getWindow(objWin);
    if (iWinIndex != -1)
    {
        if (WinManager.arrWindows[iWinIndex].strWinMode == 'tab')
            WinManager.tabs.closeTab(WinManager.tabs.getTabName(WinManager.arrWindows[iWinIndex]));
        else if (WinManager.arrWindows[iWinIndex].strWinMode == 'dialog')
            WinManager.handleDialogAction(objWin, null);
        else
            objWin.close();
    }
}


/**
* Performs a check during requested closure of master WebMaker window
* This also informs the user of the resulting closure of dependent windows
*/
WinManager.confirmWinManagerClosure = function()
{
    //alert('in beforeunload');
    //Check to see if dependent windows contain unsaved information
    if (WinManager.bPromptOnClosure)
    {
        var strUnsavedWins = WinManager.closeAllWindowsCheck();
        if (strUnsavedWins != "")
        {
            return WinManager.message.get('winmanager.confirmShutdownChanges', strUnsavedWins);
        }
        //If there is no unsaved info then confirm user definitely wants to shutdown since this will close dependent application windows
        else
        {
            return WinManager.message.get('winmanager.confirmShutdown');
        }
    }
}
/**
* Catch the event before the one that tries to unload the main WebMaker application window to ensure orderly shutdown
*/
//WinManager.attachEvent(window, "onbeforeunload", WinManager.confirmWinManagerClosure);
if (dojo.isIE)
    window.onbeforeunload = WinManager.confirmWinManagerClosure;
else
    parent.onbeforeunload = WinManager.confirmWinManagerClosure;


/**
 * Utility function for returning a config value stored in a cookie.
 * @param name The name of the value to return
 */
WinManager.getCookieValue = function(name)
{
    return dojo.cookie("WM_STUDIO_" + name);

}

/**
 * Utility function for storing a config value in a cookie.
 * @param name The name of the value to store
 * @param value The value to store.
 */
WinManager.setCookieValue = function(name, value)
{
    dojo.cookie("WM_STUDIO_" + name, value, {expires: 60});
}

/**
 * Utility function to retrieve a value stored under local storage.
 * @param key The key of the value to retrieve
 * @return the retrived value or null
 */
WinManager.getLocalStorage = function(key)
{
    if (localStorage)
    {
        return localStorage.getItem("WM_STUDIO_" + key);
    }
    return null;
}

/**
 * Utility function for storing a config value under local storage.
 * @param key The key to store the the value under
 * @param value The value to store.
 */
WinManager.setLocalStorage = function(key, value)
{
    if (localStorage)
    {
        if (value == null)
            localStorage.removeItem("WM_STUDIO_" + key)
        else
            localStorage.setItem("WM_STUDIO_" + key, value);
    }
}


/**
* This confirms whether the application servers should be shutdown.
* By this stage confirmation should have been received that no information is unsaved and WebMaker requires shutdown
*/
WinManager.closeWinManager = function()
{
    var stateString = '';
    //if we have an open project store the details to auto load next time
    if (WinManager.projectInformation != null)
    {
        stateString = '<wm_state>' + WinManager.projectInformation.xml + WinManager.getCurrentWindowStatus() + '</wm_state>';

    }
    WinManager.setLocalStorage('CP', stateString);



    //alert('about to shutdown');
    //tell the server that this session has finished
    dojo.xhrGet({
        url: "/webmaker/session_mgmt.jsp?mode=stop",
        preventCache: true,
        handle: function(type, data, evt) {
            //Do nothing
        },
        handleAs: 'text',
        sync: true
    });
    //alert('called server');
    //By this stage confirmation has been received to shutdown WebMaker. Close all dependent application windows.
    WinManager.hardCloseAllWindows();
}
/**
* Catch the event that performs shutdown. By this stage, unsaved data and open windows should have had orderly resolution
*/
WinManager.attachEvent(parent, "onunload", WinManager.closeWinManager);

/**
* Starts up WebMaker and inserts XDE as the first window in the active windows list
*/
WinManager.startWinManager = function()
{
    window.name = 'WebMakerWinManager';


    //tell the server that this session has started up
    dojo.xhrGet({
        url: "/webmaker/session_mgmt.jsp?mode=start",
        preventCache: true,
        handle: function(type, data, evt) {
            //Do nothing
        },
        handleAs: 'text'
    });

    //start loading the user preferences
    WinManager.loadPreferences();

    WinManager.menu = new hyf.menu();
    WinManager.menu.init();

    //setup the status bar
    WinManager.status.initDisplay();

    //startup the tab bar
    WinManager.tabs.init('tabContainer');

    //Setup the Server Information, which is used to display the Status Bar information
    WinManager.teamServerInformation = {
        teamServersExist: false,
        teamServerId: '',
        teamServerName: '',
        teamServerUserName: '',
        connectedToTS: false
    };
    //Needed to ensure that the User record has the ConnectedTS removed
    WinManager.opHandler.handleGetProjectStatus();
    //WinManager.opHandler.handleUpdateStatusDisplay();
    //WinManager.updateDisplayedMenuOptions();

    //load in the winmanager display messages
    WinManager.message.load('winmanager_messages.json');

    //check the licencing details
    WinManager.checkLicence();

    //Process the incoming params
    var incomingParamsString = window.location.search.substr((location.search[0] === "?" ? 1 : 0));
    //Convert + to escaped spaces as dojo only handles the %20 (also check Run test for same processing)
    incomingParamsString = incomingParamsString.replace(/\+/g, '%20');

    var incomingParams = dojo.queryToObject(incomingParamsString);

    //check if the mvc_project_base param has been provided, and if so map the old value of SingleFormBaseApp
    //to its new equivalent value of BaseTemplate
    if ((typeof(incomingParams.mvc_project_base) != 'undefined') && (incomingParams.mvc_project_base == 'SingleFormBaseApp'))
    {
        incomingParams.mvc_project_base = 'BaseTemplate';
    }

    if (incomingParams.workspace && incomingParams.project)
    {
        WinManager.status.showMessage({msg: WinManager.message.get('winmanager.project.loading'), level: 'in-progress', type: 'wmstartup'});
    }

    dojo.xhrGet({
        url: "/ProjectManagement/studio_startup.do?" + dojo.objectToQuery(incomingParams),
        preventCache: true,
        load: function(data, evt) {
            WinManager.status.removeMessage({level: 'in-progress', type: 'wmstartup'});
            var respDoc = getXMLDocument(data);
            Sarissa.setXpathNamespaces(respDoc, 'xmlns:xfact="http://www.hyfinity.com/xfactory"');
            var requestedProj = respDoc.selectSingleNode("/xfact:studio_startup/xfact:requested_project");
            if (requestedProj != null)
            {
                if (respDoc.selectSingleNode("/xfact:studio_startup[@project_created = 'true']"))
                {
                    WinManager.status.showMessage({msg: WinManager.message.get('winmanager.project.created', requestedProj.getAttribute('project_name'), requestedProj.getAttribute('workspace')), level:'info'});
                }

                WinManager.loadProject(requestedProj.getAttribute('workspace'),
                                       requestedProj.getAttribute('product'),
                                       requestedProj.getAttribute('blueprint_location'),
                                       requestedProj.getAttribute('project'),
                                       requestedProj.getAttribute('project_name'),
                                       true,
                                       //skip the exist check if we have just created the project, otherwise still want to make sure it exists and has valid metadata version
                                       (respDoc.selectSingleNode("/xfact:studio_startup[@project_created = 'true']") != null));
            }
        },
        error: function(error) {
            WinManager.status.removeMessage({level: 'in-progress', type: 'wmstartup'});
            WinManager.status.showMessage({msg: WinManager.message.get('winmanger.startupError'), detail: 'Error details: ' + error, level:'error'});
        },
        handleAs: 'text'
    });

    //check if we have a cookie value from last time indicating the project to open
    if (!(incomingParams.workspace && incomingParams.project))
    {
        var stateString = WinManager.getLocalStorage('CP');

        //if no local storage data, check for old format cookie value
        if (stateString == null)
        {
            var cp = WinManager.getCookieValue('CP');
            if ((cp != null) && (cp != ''))
            {
                var cpDetails = cp.split(',');
                WinManager.status.showMessage({msg:WinManager.message.get('winmanager.project.loadingLast'), level:'info', autohide: true});
                WinManager.loadProject(cpDetails[0],
                                       cpDetails[1],
                                       cpDetails[2],
                                       cpDetails[3],
                                       cpDetails[4],
                                       true);
            }
            else
            {
                WinManager.checkGettingStartedNeeded();
            }
        }
        else if (stateString != '')
        {
            var stateDoc = getXMLDocument(stateString)
            if (Sarissa.getParseErrorText(stateDoc) == Sarissa.PARSED_OK)
            {
                Sarissa.setXpathNamespaces(stateDoc, 'xmlns:xfact="http://www.hyfinity.com/xfactory"');

                var windowState = stateDoc.selectSingleNode('/wm_state/windows');
                if (windowState)
                    WinManager.windowStateToRestore = xmlToString(windowState);

                WinManager.status.showMessage({msg:WinManager.message.get('winmanager.project.loadingLast'), level:'info', autohide: true});
                WinManager.loadProject(getElementText(stateDoc.selectSingleNode('/wm_state/xfact:project_details/xfact:workspace')),
                                       getElementText(stateDoc.selectSingleNode('/wm_state/xfact:project_details/xfact:product')),
                                       getElementText(stateDoc.selectSingleNode('/wm_state/xfact:project_details/xfact:blueprint_location')),
                                       getElementText(stateDoc.selectSingleNode('/wm_state/xfact:project_details/xfact:project')),
                                       getElementText(stateDoc.selectSingleNode('/wm_state/xfact:project_details/xfact:project_name')),
                                       true);
            }
            else
            {
                WinManager.checkGettingStartedNeeded();
            }
        }
        else
        {
            //no state information to restore
            WinManager.checkGettingStartedNeeded();
        }
    }

    //Load the dynamic tooltips structure into memory for all pages of the Studio
    hyf.tooltips.loadTipsStructure();

    //Attach dynamic Tootlips to the main Studio page. This will be called on each page that is loaded in the Studio.
    WinManager.tooltips.attachTipsToPage('wm');

    WinManager.ConfigManager.objConfig = {};

    //get the runtime server starting up to speed up the first deploy
    setTimeout('WinManager.opHandler.startRuntimeServer(true);', 5000);

}

WinManager.ConfigManager = {};
WinManager.ConfigManager.getConfig = function(strConfig) {
    if (WinManager.ConfigManager.objConfig[strConfig])
        return WinManager.ConfigManager.objConfig[strConfig];
    else
        return null;
}

WinManager.ConfigManager.setConfig = function(strConfig, objConfig) {
    WinManager.ConfigManager.objConfig[strConfig] = objConfig;
}

//ensure startup called on page load.
//WinManager.attachEvent(window, "onload", WinManager.startWinManager);
dojo.ready(WinManager.startWinManager);

/**
 * Displays an error message to the user which will block all access to the studio.
 * This should be used for situations where there is a problem on startup which means the
 * studio should not be usable. eg invalid licence file.
 * @param data error status string, typically the response from calling a server process.
 *              This will be checked to see if it contains the 'Reason for error:' string as present in
 *              the generic error response page from our platform.  If present, the error details will
 *              be included in the message shown to the user.
 * @param force (Optional)  By default thsi method will wait for the version detaisl to have been retrieved before
 *              showing the error message to check whether to include a licence upgrade link.  If this is true then
 *              the message will be shown straight away, regardless of whether the information is available.
 */
WinManager.showStartupErrorMsg = function(data, force, count)
{
    if (data)
        WinManager.startupErrorData = data;
    else
        data = WinManager.startupErrorData;

    if (typeof(count) != 'number')
        count = 1;

    if (force || WinManager.versionDetail || count > 1000)
    {
        //check if we have an error reason
        var errorLoc = data.indexOf('Reason for error:');
        var errorMsg = 'Unable to start the studio, please correct the problem and try starting the studio again.<br/><br/>';
        if (errorLoc != -1)
        {
            errorMsg += data.substring(errorLoc, data.indexOf('</', errorLoc));

            if (WinManager.licenceUpgradeAllowed && ((errorMsg.indexOf('license') != -1) || (errorMsg.indexOf('licence') != -1)))
            {
                errorMsg += '<br/><br/><p style="font-size: 80%; text-align: center;">If you have a license key, please provide it using the <a style="font-size : inherit;" href="#" onclick="WinManager.processLicenceUpgrade(window, \'show\');WinManager.cancelPropagation(event);return false;" class="lic_upgrade">License Upgrade</a> option.</p>';
            }
        }
        else
        {
            errorMsg += 'Please check the Tomcat window and/or the platform logs (<install dir>/design/blueprints/xlog directory) to identify the cause of the problem.';
        }

        WinManager.showLoadingMessage(null, errorMsg, null, 'startupErrorMsg');
    }
    else
    {
        setTimeout("WinManager.showStartupErrorMsg(null, false, " + (count + 1) + ")", 50);
    }
}

/**
 * checks the cookie value to see if the getting started screen should be shown.
 * The cookie name includes the product version so that we will reshow the screen at least once
 * for each new product release.  This means that we have to first wait until the version
 * information is available.
 */
WinManager.checkGettingStartedNeeded = function()
{
    //make sure we know the product version
    if (WinManager.getVersionDetail())
    {
        var productVersion = getElementText(WinManager.getVersionDetail().selectSingleNode('/product_version/version_code'));

        var cv = WinManager.getCookieValue('GSDSA' + productVersion);
        if (cv != 'true')
            WinManager.opHandler.handleGettingStarted();
    }
    else
    {
        setTimeout(WinManager.checkGettingStartedNeeded, 100);
    }
}

/**
 * Sets up this WinManager to be working for the specified project.
 * @param dontClearStatus (Optional) If set to true then the existing status messages will not be cleared out.
 *                      Otherwise, or it not provided, then they will be.
 * @param skipExistCheck (Optional) By default, this function will first make sure that the requested project exists
 *                      for the suer, with valid metadata version before trying to open it.  If you already know that it exists, you
 *                      can skip this check by passing true as this parameter.
 * @param forceReplace (Optional) If true then any existing open project will be automatically replaced with the requested one. Defaults to false.
 */
WinManager.loadProject = function(workspace, product, blueprint_location, project, projectName, dontClearStatus, skipExistCheck, forceReplace)
{
    if (WinManager.projectInformation != null)
    {
        var hasChanges = (WinManager.closeAllWindowsCheck() != '');

        WinManager.requestedProjectOpen = {
                    workspace: workspace,
                    product: product,
                    blueprint_location: blueprint_location,
                    project: project,
                    project_name: projectName,
                    dontClearStatus: dontClearStatus,
                    skipExistCheck: skipExistCheck};

        if (forceReplace)
        {
            WinManager.closeProject(true);

            WinManager.waitForProjectCloseOnProjectOpen();
        }
        else
        {
            //ask the user whether to close the open project, or open in a new window
            var confirmMsg = '<div style="padding : 15px;">You have requested to open a new project, but you already have project \'<b>' + WinManager.projectInformation.project_name
                       + '</b>\' from workspace \'<b>' + WinManager.projectInformation.workspace + '</b>\' open';
            if (hasChanges)
                confirmMsg += ' <b>with unsaved changes</b>';

            confirmMsg += '.<br/><br/>Please indicate what you would like to do:<br/><br/>';

            confirmMsg += '<input type="radio" name="ExitingProjectOption" id="ExistingProjectOptionReplace" value="replace"';
            if (!hasChanges)
                confirmMsg += 'checked="checked"';
            confirmMsg += '/><label style="padding-left : 5px;" for="ExistingProjectOptionReplace"><b>Replace Existing Window</b> - Close the current project'

            if (hasChanges)
                confirmMsg += ', discarding any changes,';
            confirmMsg += ' and open project \'<b>' + projectName + '</b>\' in this window.</label><br/><br/>';

            confirmMsg += '<input type="radio" name="ExitingProjectOption" id="ExistingProjectOptionOpen" value="open"';
            if (hasChanges)
                confirmMsg += 'checked="checked"';
            confirmMsg += '/><label style="padding-left : 5px;" for="ExistingProjectOptionOpen"><b>Open New Window</b> - Open project \'<b>' + projectName + '</b>\' in a new browser window.</label><br/>';

            confirmMsg += '</div>';

            WinManager.displayMessageBox({content:confirmMsg, title:'Existing Project', buttons:['ok', 'cancel'], onOk: function(){
                        WinManager.existingProjectReplaceOptionChosen();
                        return false;
            }});
        }

        return;
    }

    WinManager.ignoreChanges = false;

    //set up the project info object
    WinManager.projectInformation = {
                    user: workspace,
                    workspace: workspace,
                    product: product,
                    blueprint_location: blueprint_location,
                    project: project,
                    project_name: projectName,
                    xml: '<project_details xmlns="http://www.hyfinity.com/xfactory"><user>' +
                            workspace + '</user><workspace>' + workspace + '</workspace><product>' +
                            product + '</product><blueprint_location>' +
                            blueprint_location + '</blueprint_location><project>' + project +
                            '</project><project_name>' + projectName + '</project_name></project_details>'
    };

    //assume we need to deploy first when opening a new project
    WinManager.projectDeployRequired = true;

    document.title = "WebMaker - " + workspace + ' : ' + projectName;

    //clear out any status messages
    if (!dontClearStatus)
    {
        WinManager.globalStatusMessages = new Array();
        WinManager.status.updateDisplay();
    }

    //check if this open is following a reload.  if so we wont output the opened project message
    var reloadingProject = (WinManager.requestedProjectOpen && WinManager.requestedProjectOpen.reloading);

    //Make sure the requested project actually exists
    if (skipExistCheck)
    {
        WinManager.openProjectExistConfirmed(reloadingProject);
    }
    else
    {
        dojo.xhrPost({
            url: '../ProjectManagement/checkProjectExists.do',
            preventCache: true,
            handleAs:   'text',
            content: {workspace: WinManager.projectInformation.workspace,
                      assetType: WinManager.projectInformation.product,
                      project: WinManager.projectInformation.project},
            load: function(data, ioargs) {
                    var responseDoc = getXMLDocument(data);
                    if (Sarissa.getParseErrorText(responseDoc) == Sarissa.PARSED_OK)
                    {
                        Sarissa.setXpathNamespaces(responseDoc, 'xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/" xmlns:xfact="http://www.hyfinity.com/xfactory"');

                        var success = responseDoc.selectSingleNode('/soap:Envelope/soap:Body/xfact:CheckProjectExists/xfact:response/xfact:outcome/xfact:successful');
                        if (getElementText(success) == 'true')
                        {
                            //call was successful, so check if project exists
                            var exists = responseDoc.selectSingleNode('/soap:Envelope/soap:Body/xfact:CheckProjectExists/xfact:response/xfact:Exists[. = "true"]');
                            if (exists != null)
                            {
                                //now check if metadata version is ok
                                var versionOk = responseDoc.selectSingleNode('/soap:Envelope/soap:Body/xfact:CheckProjectExists/xfact:response[(number(xfact:ProjectMetaDataVersion) >= number(xfact:MinMetaDataVersion)) and (number(xfact:ProjectMetaDataVersion) <= number(xfact:MaxMetaDataVersion))]');
                                if (versionOk != null)
                                {
                                    WinManager.openProjectExistConfirmed(reloadingProject);
                                }
                                else
                                {
                                    WinManager.alert({strTitle: WinManager.message.get('winmanager.project.notCompatableTitle'), strMsg: WinManager.message.get('winmanager.project.notCompatableMsg', WinManager.projectInformation.project_name)});
                                    WinManager.closeProject();
                                }
                            }
                            else
                            {
                                WinManager.status.showMessage({msg: WinManager.message.get('winmanager.project.missing', WinManager.projectInformation.project_name), level: 'error'});
                                WinManager.closeProject();
                                WinManager.checkGettingStartedNeeded();
                            }
                        }
                        else
                        {
                            WinManager.status.showMessage({msg: WinManager.message.get('winmanager.project.missing', WinManager.projectInformation.project_name), detail: getElementText(responseDoc.selectSingleNode('/soap:Envelope/soap:Body/xfact:CheckProjectExists/xfact:response/xfact:outcome/xfact:message')), level: 'error'});
                            WinManager.closeProject();
                            WinManager.checkGettingStartedNeeded();
                        }
                    }
                    else
                    {
                        WinManager.status.showMessage({msg: WinManager.message.get('winmanager.project.missing', WinManager.projectInformation.project_name), detail: WinManager.message.get('winmanager.errorParsingResponse') + Sarissa.getParseErrorText(getProjectStatusDoc), level: 'error'});
                        WinManager.closeProject();
                        WinManager.checkGettingStartedNeeded();
                    }
            },
            error: function(response){
                    WinManager.status.showMessage({msg: WinManager.message.get('winmanager.project.validCheckError'), level: 'error', detail: response + '<br/><br/>' + WinManager.message.get('winmanager.errorRetryOrContactSupport')});
                    WinManager.closeProject();
                    return response;
            }
        });

    }



    //enable all the menu options that only apply once a project is open
    WinManager.setMenuOperationEnabledSetting('copy_project', true);
    WinManager.setMenuOperationEnabledSetting('delete_project', true);
    WinManager.setMenuOperationEnabledSetting('delete_workspace', true);
    WinManager.setMenuOperationEnabledSetting('export_project', true);
    WinManager.setMenuOperationEnabledSetting('export_project_template', true);
    WinManager.setMenuOperationEnabledSetting('project_settings', true);
    WinManager.setMenuOperationEnabledSetting('revert_project', true);
    WinManager.setMenuOperationEnabledSetting('close_all_tabs', true);
    WinManager.setMenuOperationEnabledSetting('run_local', true);
    WinManager.setMenuOperationEnabledSetting('run_local_settings', true);
    WinManager.setMenuOperationEnabledSetting('debugger', true);
    WinManager.setMenuOperationEnabledSetting('service_tester', true);
    WinManager.setMenuOperationEnabledSetting('publish', true);
    WinManager.setMenuOperationEnabledSetting('publish_settings', true);
    WinManager.setMenuOperationEnabledSetting('logs_clear', true);
    WinManager.setMenuOperationEnabledSetting('project_properties', true);
    WinManager.setMenuOperationEnabledSetting('view_history', true);

    WinManager.updateDisplayedMenuOptions();

    //if we have opened a project store the details to auto load next time the studio is started or refreshed
    //cant sotre window state here, as at this point we have no windows open yet
    var stateString = '<wm_state>' + WinManager.projectInformation.xml + '</wm_state>';
    WinManager.setLocalStorage('CP', stateString);

    WinManager.bPromptOnClosure = true;
}

/**
 * Open the project once we have confirmed it exists.
 * @param reloadingProject boolean indicating whether this project is being opened following a reload call.
 * @private - always call openProject which will deligate to this when needed.
 */
WinManager.openProjectExistConfirmed = function(reloadingProject)
{
    if (WinManager.projectInformation.product == 'mvc')
    {
        //try and get the FM application file to make sure we can load app map
        var requestString = '<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Header>' +
                WinManager.projectInformation.xml +
                '</soap:Header><soap:Body>' +
                '<get_formmaker_application xmlns="http://www.hyfinity.com/xfactory"><request>' +
                '</request></get_formmaker_application></soap:Body></soap:Envelope>';

        dojo.xhrPost({
            url:        '../xde_services',
            headers:    {SOAPAction: 'GetFormmakerApplication'},
            postData:   requestString,
            handleAs:   'text',
            load:       function(data, ioargs) {
                var doc = getXMLDocument(data);
                if (Sarissa.getParseErrorText(doc) == Sarissa.PARSED_OK)
                {
                    Sarissa.setXpathNamespaces(doc, 'xmlns:fm="http://www.hyfinity.com/formmaker" xmlns:xfact="http://www.hyfinity.com/xfactory" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"');

                    if (doc.selectSingleNode('/soap:Envelope/soap:Body/xfact:get_formmaker_application/xfact:response/fm:application'))
                    {
                        WinManager.opHandler.showFMAppMap();
                        WinManager.opHandler.handleGetProjectStatus();
                        WinManager.projectInformation.hasFMMetaData = true;
                        WinManager.restoreWindowState();
                    }
                    else
                    {
                        //this is not a valid FM app so revert to XDE screen.
                        WinManager.status.showMessage({msg: WinManager.message.get('winmanager.project.notFM'), level: 'info', autohide: true});
                        WinManager.opHandler.showXDEProjectScreen();
                        WinManager.opHandler.handleGetProjectStatus();
                        WinManager.projectInformation.hasFMMetaData = false;
                        WinManager.restoreWindowState();
                    }
                    if (!reloadingProject)
                        WinManager.status.showMessage({msg: WinManager.message.get('winmanager.project.opened', WinManager.projectInformation.project_name, WinManager.projectInformation.workspace), autohide: true});
                }
                else
                {
                    WinManager.status.showMessage({msg: WinManager.message.get('winmanager.project.validCheckError'), level: 'error', detail: Sarissa.getParseErrorText(doc) + '<br/><br/>' + WinManager.message.get('winmanager.errorRetryOrContactSupport')});
                    WinManager.closeProject();
                }
            },
            error:      function(data){
                WinManager.status.showMessage({msg: WinManager.message.get('winmanager.project.validCheckError'), level: 'error', detail: data + '<br/><br/>' + WinManager.message.get('winmanager.errorRetryOrContactSupport')});
                WinManager.closeProject();
            }
        });

    }
    else
    {
        WinManager.opHandler.showXDEProjectScreen();
        WinManager.opHandler.handleGetProjectStatus();
        WinManager.restoreWindowState();
        if (!reloadingProject)
            WinManager.status.showMessage({msg: WinManager.message.get('winmanager.project.opened', WinManager.projectInformation.project_name, WinManager.projectInformation.workspace), autohide: true});
    }
}


/**
 * Called when an option has been selected on the popup that is shown when opening a
 * new project with one already open
 */
WinManager.existingProjectReplaceOptionChosen = function()
{
    var option = null;
    if (document.getElementById('ExistingProjectOptionReplace').checked)
        option = document.getElementById('ExistingProjectOptionReplace').value;
    else if (document.getElementById('ExistingProjectOptionOpen').checked)
        option = document.getElementById('ExistingProjectOptionOpen').value;

    if (option == null)
    {
        alert('Please select how you wish to open the new project.');
        return;
    }

    WinManager.clearMessageBox();

    if (option == 'replace')
    {
        WinManager.closeProject(true);

        WinManager.waitForProjectCloseOnProjectOpen();
    }
    else if (option == 'open')
    {
        var incomingParamsString = location.search.substr((location.search[0] === "?" ? 1 : 0));
        //Convert + to escaped spaces as dojo only handles the %20 (also check Run test for same processing)
        incomingParamsString = incomingParamsString.replace(/\+/g, '%20');

        var incomingParams = dojo.queryToObject(incomingParamsString);

        incomingParams.workspace = WinManager.requestedProjectOpen.workspace;
        incomingParams.project = WinManager.requestedProjectOpen.project;

        var newURL = window.location.pathname + '?' + dojo.objectToQuery(incomingParams);
        window.open(newURL);

        WinManager.requestedProjectOpen = null;
    }
}

/**
 * waits for all the current windows to have closed before opening the requested project.
 */
WinManager.waitForProjectCloseOnProjectOpen = function()
{
    if (WinManager.arrWindows.length > 0)
    {
        setTimeout(WinManager.waitForProjectCloseOnProjectOpen, 100)
    }
    else
    {
        WinManager.loadProject(WinManager.requestedProjectOpen.workspace,
                               WinManager.requestedProjectOpen.product,
                               WinManager.requestedProjectOpen.blueprint_location,
                               WinManager.requestedProjectOpen.project,
                               WinManager.requestedProjectOpen.project_name,
                               WinManager.requestedProjectOpen.dontClearStatus,
                               WinManager.requestedProjectOpen.skipExistCheck);

        WinManager.requestedProjectOpen = null;
    }
}




/**
 * Prompts for confirmation, and then closes all open windows/tabs and resets the
 * projectInformation details, to allow a new project to be opened.
 * @param force (Optional) If true, the project will be closed, even if unsaved changes.
 */
WinManager.closeProject = function(force)
{
    var strUnsavedWins = WinManager.closeAllWindowsCheck(true);
    if ((strUnsavedWins == "") || force )
    {
        WinManager.closeProjectImpl();
    }
    else
    {
        WinManager.userConfirmed({strMsg: WinManager.message.get('winmanager.project.confirmClose', strUnsavedWins),
                                 objConfirmHandler: function() {
                                     WinManager.closeProjectImpl();
                                 }
        });
    }
}

WinManager.closeProjectImpl = function()
{
    WinManager.ignoreChanges = true;
    //close all the windows that are project specific
    WinManager.closeAllWindows(function(wmWin){
            var projName = wmWin.arrWinDetails[1];
            if ((typeof(projName) != 'undefined') && (projName != null))
                return true;
            else
                return false;
    });
    WinManager.projectInformation = null;
    WinManager.currentTab = null;

    document.title = "WebMaker";

    //disable all the menu options that only apply once a project is open
    WinManager.setMenuOperationEnabledSetting('copy_project', false);
    WinManager.setMenuOperationEnabledSetting('delete_project', false);
    WinManager.setMenuOperationEnabledSetting('delete_workspace', true);
    WinManager.setMenuOperationEnabledSetting('export_project', false);
    WinManager.setMenuOperationEnabledSetting('export_project_template', false);
    WinManager.setMenuOperationEnabledSetting('project_settings', false);
    WinManager.setMenuOperationEnabledSetting('revert_project', false);
    WinManager.setMenuOperationEnabledSetting('close_all_tabs', false);
    WinManager.setMenuOperationEnabledSetting('run_local', false);
    WinManager.setMenuOperationEnabledSetting('run_local_settings', false);
    WinManager.setMenuOperationEnabledSetting('debugger', false);
    WinManager.setMenuOperationEnabledSetting('service_tester', false);
    WinManager.setMenuOperationEnabledSetting('publish', false);
    WinManager.setMenuOperationEnabledSetting('publish_settings', false);
    WinManager.setMenuOperationEnabledSetting('logs_clear', false);
    WinManager.setMenuOperationEnabledSetting('check_in', false);
    WinManager.setMenuOperationEnabledSetting('check_out', false);
    WinManager.setMenuOperationEnabledSetting('cancel_check_out', false);
    WinManager.setMenuOperationEnabledSetting('view_history', false);
    WinManager.setMenuOperationEnabledSetting('share_project', false);
    WinManager.setMenuOperationEnabledSetting('download_project', false);
    WinManager.setMenuOperationEnabledSetting('remove_project', false);
    WinManager.setMenuOperationEnabledSetting('project_properties', false);

    //clear out the info strip (including the status icons)
    WinManager.opHandler.handleUpdateStatusDisplay();
    WinManager.updateDisplayedMenuOptions();

    WinManager.bPromptOnClosure = false;

    //clear out the storage indicating which project is open
    //(This will also happen on window close, but also done here for completeness)
    WinManager.setLocalStorage('CP', '');

    //make sure we clear out any window state information if any
    //so we wont try and load the wrong set of tabs on next project load.
    //for example, if reopening the project on startup failed (eg if it doesnt exist)
    //then this state information will still be present otherwise
    var reloadingProject = (WinManager.requestedProjectOpen && WinManager.requestedProjectOpen.reloading);
    if (!reloadingProject)
        WinManager.windowStateToRestore = null;
}


/**
 * Reloads the currently open project, eg if switching to a different version.
 * This tries to ensure all the currently open tabs etc are maintained.
 */
WinManager.reloadProject = function()
{
    if (WinManager.projectInformation == null)
        return;

    WinManager.windowStateToRestore = WinManager.getCurrentWindowStatus();

    WinManager.requestedProjectOpen = {
                    workspace: WinManager.projectInformation.workspace,
                    product: WinManager.projectInformation.product,
                    blueprint_location: WinManager.projectInformation.blueprint_location,
                    project: WinManager.projectInformation.project,
                    project_name: WinManager.projectInformation.project_name,
                    dontClearStatus: true,
                    skipExistCheck: false,
                    reloading: true};

    WinManager.closeProject(true);

    WinManager.waitForProjectCloseOnProjectOpen();
}

/**
 * Attempts to restore an existing window state.
 * This function requires the winManager.windowStateToRestore property be set and
 * contain the XML string returned from the WinManager.getCurrentWindowStatus() function.
 */
WinManager.restoreWindowState = function()
{
    if (WinManager.windowStateToRestore != null)
    {
        var stateDoc = getXMLDocument(WinManager.windowStateToRestore);
        if (Sarissa.getParseErrorText(stateDoc) == Sarissa.PARSED_OK)
        {
            if (WinManager.preferences == null)
            {
                require(['dojo/aspect'], function(aspect) {
                        var aspectHandle = aspect.after(WinManager, "processPreferencesResponse", function() {
                                aspectHandle.remove();
                                WinManager.restoreWindowState()

                        });
                });
                return;
            }

            //when restoring tabs, the order in the state document is important, so temporarily set the tab
            //open mode to right to make sure they appear int he order requested
            var properTabOpenMode = WinManager.preferences.open_tab_mode;
            WinManager.preferences.open_tab_mode = 'end';


            var tabs = stateDoc.selectNodes('/windows/tabs/tab');
            for (var i = 0; i < tabs.length; ++i)
            {
                var t = tabs.item(i);

                //the app map will already have been loaded, so dont need to load again.
                if (t.getAttribute('type') == 'FMAppMap')
                    continue;

                //if this isnt a FormMaker project the we will autoamtically open the XDE project screen.
                //so dont want to load it again here
                if ((t.getAttribute('type') == 'XDE') && (!WinManager.projectInformation.hasFMMetaData))
                    continue;

                //cant restore run test tab so dont try and create it.
                if (t.getAttribute('type') == 'Runtime')
                    continue;

                var arrWinDetails = new Array();
                var details = t.selectNodes('detail');
                for (var j = 0; j < details.length; ++j)
                {
                    arrWinDetails.push(getElementText(details.item(j)))
                }

                var newWmWindow = new WinManager.wmWindow("",
                                              WinManager.determineWindowName(arrWinDetails),
                                              null,
                                              arrWinDetails);

                newWmWindow.strWinMode = 'tab';

                newWmWindow.objWin = WinManager.tabs.newTab(WinManager.tabs.getTabName(newWmWindow),
                                                            "about:blank",
                                                            WinManager.getDisplayName(newWmWindow, false, true),
                                                            t.getAttribute('type'),
                                                            true, false);

                newWmWindow.loaded = false;

                WinManager.arrWindows[WinManager.arrWindows.length] = newWmWindow;
            }


            //reset the tab mode
            WinManager.preferences.open_tab_mode = properTabOpenMode;


            //now wait for the app map tab to load before switching to the currect tab (and loading popups)
            WinManager.waitForInitialTabLoadOnRestoreWindows(stateDoc);
        }
        else
        {
            WinManager.windowStateToRestore = null;
        }
    }
}

WinManager.waitForInitialTabLoadOnRestoreWindows = function(stateDoc)
{
    if (WinManager.tabs.getTabBusyState(WinManager.tabs.getTabName(WinManager.currentTab)))
    {
        setTimeout(function() {WinManager.waitForInitialTabLoadOnRestoreWindows(stateDoc) }, 100);
    }
    else
    {
        var current = stateDoc.selectSingleNode('/windows/tabs/tab[@current = "true"]');
        if (current)
        {
            WinManager.tabs.selectTab(WinManager.name + current.getAttribute('name'));
        }

        //now restore any popup windows (eg file edits)
        var popups = stateDoc.selectNodes('/windows/popups/popup');
        for (var i = 0; i < popups.length; ++i)
        {
            var p = popups.item(i);

            //cant restore run test tab so dont try and create it.
            if (p.getAttribute('type') == 'Runtime')
                continue;

            var arrWinDetails = new Array();
            var details = p.selectNodes('detail');
            for (var j = 0; j < details.length; ++j)
            {
                arrWinDetails.push(getElementText(details.item(j)))
            }

            var newWmWindow = new WinManager.wmWindow("",
                                          WinManager.determineWindowName(arrWinDetails),
                                          null,
                                          arrWinDetails);

            newWmWindow.strWinMode = 'popup';

            newWmWindow.loaded = false;
            WinManager.handleRestoreWindow(newWmWindow);
        }


        WinManager.windowStateToRestore = null;
    }
}

/**
 * Returns an XML string detailing all the currently open tabs and popup windows.
 * The order of tabs returned should match that shown on screen.
 */
WinManager.getCurrentWindowStatus = function()
{
    var windowState = '<windows>';
    windowState += WinManager.tabs.getCurrentStatus();

    windowState += '<popups>';
    for (var i = 0; i < WinManager.arrWindows.length; ++i)
    {
        if (WinManager.arrWindows[i].strWinMode == 'popup')
        {
            windowState += '<popup name="' + WinManager.arrWindows[i].strWinName + '" type="' + WinManager.getWindowTypeString(WinManager.arrWindows[i]) + '">';

            for (var j = 0; j < WinManager.arrWindows[i].arrWinDetails.length; ++j)
            {
                windowState += '<detail>' + WinManager.arrWindows[i].arrWinDetails[j] + '</detail>';
            }

            windowState += '</popup>';
        }
    }
    windowState += '</popups>';

    windowState += '</windows>';

    return windowState;
}





WinManager.checkLicence = function()
{
    var requestString = '<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body>' +
            '<get_licence_details xmlns="http://www.hyfinity.com/xfactory"><request><include_product_version>true</include_product_version>' +
            '</request></get_licence_details></soap:Body></soap:Envelope>';

    dojo.xhrPost({
        url:        '../xde_services',
        headers:    {SOAPAction: 'GetLicenceDetails'},
        postData:   requestString,
        handleAs:   'text',
        load:       function(data, ioargs) {
            var doc = getXMLDocument(data);
            if (Sarissa.getParseErrorText(doc) == Sarissa.PARSED_OK)
            {
                Sarissa.setXpathNamespaces(doc, 'xmlns:xfact="http://www.hyfinity.com/xfactory" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"');

                //check if we got a successful response
                if (doc.selectSingleNode("/soap:Envelope/soap:Body/xfact:get_licence_details/xfact:response"))
                {
                    //check for product version information.
                    var versionDetail = doc.selectSingleNode("/soap:Envelope/soap:Body/xfact:get_licence_details/xfact:response/product_version");
                    if (versionDetail != null)
                    {
                        WinManager.versionDetail = getXMLDocument(xmlToString(versionDetail));
                    }

                    var licenceDetail = doc.selectSingleNode("/soap:Envelope/soap:Body/xfact:get_licence_details/xfact:response/licence_details");
                    if (licenceDetail != null)
                    {
                        //store the details about the licence for potential future use.
                        WinManager.licenceDetail = getXMLDocument(xmlToString(licenceDetail));

                        WinManager.createLicenceMessage();
                    }
                }
                else
                {
                    WinManager.status.showMessage({msg: WinManager.message.get('winmanager.licenceCheckError'), level:'error', type: 'licence-check-error'});
                    WinManager.showStartupErrorMsg(data, true);
                }
            }
            else
            {
                WinManager.status.showMessage({msg: WinManager.message.get('winmanager.licenceCheckError'), level:'error', detail: Sarissa.getParseErrorText(doc), type: 'licence-check-error'});
                WinManager.showStartupErrorMsg('Reason for error: ' + WinManager.message.get('winmanager.licenceCheckError')+ ' - ' + Sarissa.getParseErrorText(doc) + '</end>', true);
            }
        },
        error:      function(data){
            WinManager.showStartupErrorMsg('Reason for error: ' + data + '</end>', true);
        }
    });
}

/**
 * Returns the XML document detailing the licence in use.
 */
WinManager.getLicenceDetail = function()
{
    return WinManager.licenceDetail;
}
/**
 * Returns the XML document detailing the WebMaker version in use.
 */
WinManager.getVersionDetail = function()
{
    return WinManager.versionDetail;
}

/**
 * Creates the licence message HTML string that should be shown on every window.
 */
WinManager.createLicenceMessage = function()
{
    var edition = getElementText(WinManager.licenceDetail.selectSingleNode("/licence_details/edition"));
    var gracePeriod = WinManager.licenceDetail.selectSingleNode("/licence_details/expiry/in_grace_period[. = 'true']");

    //add in functionality for registering new licence
    //bizflow versions do not allow direct upgrading as this is handled by HSG
    WinManager.productType = 'hyfinity';
    WinManager.licenceUpgradeAllowed = true;

    if (WinManager.versionDetail.selectSingleNode("/product_version/extra"))
    {
        var versionExtra = getElementText(WinManager.versionDetail.selectSingleNode("/product_version/extra"));
        if (versionExtra.toLowerCase().indexOf('bizflow') != -1)
        {
            WinManager.licenceUpgradeAllowed = false;
            WinManager.productType = 'bizflow';
        }
    }

    if (edition == 'community' || edition == 'evaluation' || (gracePeriod != null))
    {
        var htmlStr = '<div id="licence_msg">';

        if (gracePeriod != null)
        {
            htmlStr += '<span class="lic_type" style="color:purple;font-weight:bold;">License Expired</span>';
            var summary = WinManager.licenceDetail.selectSingleNode('/licence_details/summary');
            htmlStr += '<span id="lic_expired_grace" data-lic-summary="' + getElementText(summary) + '"></span>';
        }
        else
        {
            htmlStr += '<span class="lic_type">';
            htmlStr += (edition == 'community') ? WinManager.message.get('winmanager.licence.typeCommunity') : WinManager.message.get('winmanager.licence.typeEvaluation');
            htmlStr += '</span>';

            //check for an existing licence
            if (edition == 'community')
            {
                var existing = WinManager.licenceDetail.selectSingleNode('/licence_details/user_details/previous/summary');
                if (existing != null)
                {
                    htmlStr += '<span id="lic_converted_community" data-lic-summary="' + getElementText(existing) + '"></span>';
                }
            }

            if (edition == 'evaluation')
            {
                var numDays= getElementText(WinManager.licenceDetail.selectSingleNode("/licence_details/expiry/days_remaining"))
                if (Number(numDays) <= 14)
                {
                    htmlStr += '<span class="lic_expiry" style="color : purple;">';
                    if (Number(numDays) != 1)
                        htmlStr += WinManager.message.get('winmanager.licence.expiringInMultipleDays', numDays)
                    else
                        htmlStr += WinManager.message.get('winmanager.licence.expiringInSingleDay', numDays)
                    htmlStr += '</span>';
                }
            }
        }

        if (WinManager.licenceUpgradeAllowed)
            htmlStr += '<a href="#" onclick="WinManager.processLicenceUpgrade(window, \'show\');WinManager.cancelPropagation(event);return false;" class="lic_upgrade">'
                        + WinManager.message.get('winmanager.licence.upgradeLink') + '</a>';

        htmlStr += '</div>';

        dojo.byId('licenceState').innerHTML = htmlStr;
    }

}

/**
 * Handles the user interaction for the licence upgrade process.
 * @param objWin the window object the user is dealing with.
 * @param mode Either 'show', 'activate', 'restart'
 */
WinManager.processLicenceUpgrade = function(objWin, mode)
{
    if (mode == 'show')
    {
        var messageHTML = WinManager.message.get('winmanager.licence.upgradeInst');

        messageHTML += '<textarea style="width : 95%" rows="6" id="licence_upgrade_key"></textarea><br />';

        WinManager.displayMessageBox({content: messageHTML, title: WinManager.message.get('winmanager.licence.upgradeTitle'), height: 290, buttons: [{caption: WinManager.message.get('winmanager.licence.upgradeActivateCaption'), reason: 'activate'}, 'cancel'], onActivate: function(){
            WinManager.processLicenceUpgrade(objWin, 'activate');
            return false;
        },
        msgBoxContainerOverrideStyle: {zIndex: 2000}});
    }
    else if (mode == 'activate')
    {
        var lic = objWin.document.getElementById('licence_upgrade_key').value;
        if (lic == '')
        {
            objWin.alert(WinManager.message.get('winmanager.licence.upgradeLicenceNotEntered'));
            return;
        }

        var requestString = '<soap:Envelope xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body>' +
            '<upgrade_licence xmlns="http://www.hyfinity.com/xfactory"><request><new_licence>' + lic +
            '</new_licence></request></upgrade_licence></soap:Body></soap:Envelope>';

        dojo.xhrPost({
            url:        '../xde_services',
            headers:    {SOAPAction: 'UpgradeLicence'},
            postData:   requestString,
            handleAs:   'text',
            load:       function(data, ioargs) {
                var doc = getXMLDocument(data);
                if (Sarissa.getParseErrorText(doc) == Sarissa.PARSED_OK)
                {
                    Sarissa.setXpathNamespaces(doc, 'xmlns:xfact="http://www.hyfinity.com/xfactory" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"');
                    var licenceStatus = doc.selectSingleNode("/soap:Envelope/soap:Body/xfact:upgrade_licence/xfact:response/licence_details/type[. = 'invalid']");

                    if (licenceStatus != null)
                    {
                        objWin.alert(WinManager.message.get('winmanager.licence.upgradeLicenceInvalid'));
                    }
                    else
                    {
                        var messageHTML = WinManager.message.get('winmanager.licence.upgradeSuccessMsg', getElementText(doc.selectSingleNode("/soap:Envelope/soap:Body/xfact:upgrade_licence/xfact:response/licence_details/summary")));
                        WinManager.displayMessageBox({content: messageHTML, title: WinManager.message.get('winmanager.licence.upgradeTitle'), height: 290, buttons: [{caption: WinManager.message.get('winmanager.licence.upgradeRestartCaption'), reason: 'restart'}], onRestart: function(){
                                WinManager.processLicenceUpgrade(window, 'restart');
                                return false;
                        },
                        msgBoxContainerOverrideStyle: {zIndex: 2000}});
                    }
                }
            },
            error:      function(data){
                objWin.alert('error ' + data);
            }
        });
    }
    else if (mode == 'restart')
    {
        var strUnsavedWins = WinManager.closeAllWindowsCheck(true);
        if (strUnsavedWins == "")
            WinManager.restartAfterLicenceUpgrade();
        else
            WinManager.userConfirmed({
                    strMsg: WinManager.message.get('winmanager.confirmRestartChanges', strUnsavedWins),
                    objConfirmHandler: function() {
                        WinManager.restartAfterLicenceUpgrade();
                    }
            })
    }
}

WinManager.restartAfterLicenceUpgrade = function()
{
    WinManager.ignoreChanges = true;

    WinManager.closeAllWindows();

    if (dojo.isIE)
        window.onbeforeunload = null;
    else
        parent.onbeforeunload = null;

    top.window.location.href = top.window.location.protocol + "//" + top.window.location.host + "/webmaker/restart.html" + top.window.location.search;
}

/**
 * Shows a popup dialog containing details of the product version.
 */
WinManager.showVersionInfo = function()
{
    var infoMsg = '<div id="about_wm">';
    if (WinManager.productType == 'bizflow')
        infoMsg += '<img alt="WebMaker logo" src="images/bi.png" width="161" height="20" /><p/>';
    infoMsg += '<h3 class="group_heading" style="padding-top: 5px;">' + WinManager.message.get('winmanager.about.heading') + '</h3>';
    infoMsg += '<table>';
    var version = getElementText(WinManager.versionDetail.selectSingleNode("/product_version/extra"));
    var version_start_pos = version.indexOf("BizFlow");
    version = version.substring(version_start_pos);

    if (WinManager.versionDetail.selectSingleNode("/product_version/extra") != null)
    {
        infoMsg += '<tr><th style="text-align:left;">Product Version: </th><td class="group_heading">' +
                version +
                '</td></tr>';
    }
    infoMsg += '<tr><th style="text-align:left; width: 140px;">' + WinManager.message.get('winmanager.about.versionLabel') + '</th><td>' +
                getElementText(WinManager.versionDetail.selectSingleNode("/product_version/version")) +
                '</td></tr>';
    infoMsg += '<tr><th style="text-align:left;">' + WinManager.message.get('winmanager.about.dateLabel') + '</th><td>' +
                getElementText(WinManager.versionDetail.selectSingleNode("/product_version/date")) +
                '</td></tr>';
    infoMsg += '<tr><th style="text-align:left;">' + WinManager.message.get('winmanager.about.buildLabel') + '</th><td>' +
                getElementText(WinManager.versionDetail.selectSingleNode("/product_version/build")) +
                '</td></tr>';
    infoMsg += '<tr><th style="text-align:left;">' + WinManager.message.get('winmanager.about.revisionLabel') + '</th><td>' +
                getElementText(WinManager.versionDetail.selectSingleNode("/product_version/revision")) +
                '</td></tr>';
    infoMsg += '</table>';

    var patches = WinManager.versionDetail.selectNodes("/product_version/patches/patch");
    if (patches.length > 0)
    {
        infoMsg += '<h3 class="group_heading" style="padding-top: 5px;">' + WinManager.message.get('winmanager.about.patchesHeading') + '</h3><ul style="list-style-type:disc;">';

        for (var i = 0; i < patches.length; ++i)
        {
            infoMsg += '<li>' + getElementText(patches.item(i)) + '</li>';
        }

        infoMsg += '</ul>';
    }

    infoMsg += '<h3 class="group_heading" style="padding-top: 5px;">' + WinManager.message.get('winmanager.about.licenceHeading') + '</h3><p>' + getElementText(WinManager.licenceDetail.selectSingleNode('/licence_details/summary'));
    infoMsg += '</p>';
    if (WinManager.licenceUpgradeAllowed)
        infoMsg += '<a href="#" onclick="WinManager.processLicenceUpgrade(window, \'show\');WinManager.cancelPropagation(event);return false;" class="lic_upgrade">' + WinManager.message.get('winmanager.about.licenceUpgradeLink') + '</a><br />';


    infoMsg += '<br /><p>' + WinManager.message.get('winmanager.about.copyright') + '</p>';

    WinManager.displayMessageBox({content: infoMsg, title: WinManager.message.get('winmanager.about.title'), height: 350, buttons:['ok']});
}

/**
 * Gets the display mode setting for the given window.
 * This indicates whether the window is in a tab or not.
 * @return current display mode - 'tab' or 'popup', or null
 */
WinManager.getWindowDisplayMode = function(objWin)
{
    var winIndex = WinManager.getWindow(objWin)
    if (winIndex != -1)
    {
        return WinManager.arrWindows[winIndex].strWinMode
    }
    return null;
}

/**
 * Get the details of the currently open project.
 * @return an object with properties:  user, workspace, product, blueprint_location, project, project_name, xml
 */
WinManager.getProjectInformation = function()
{
    return WinManager.projectInformation;
}
/**
 * Get the details of the currently connected Team Server.
 * @return an object with properties:  teamServerId, teamServerName, connectedToTS
 */
WinManager.getTeamServerInformation = function()
{
    return WinManager.teamServerInformation;
}


/**
 * Returns the string to display when showing the name of a given window.
 * @param wmWindow The wmwindow object to return the display name for
 * @param includeProject (Optional) boolean indicating whether or not the project name should be included.
 * @param forTab (Optional) boolean indicating whether the returned name will be used for a tab button
 */
WinManager.getDisplayName = function(wmWindow, includeProject, forTab)
{
    if (typeof(wmWindow.arrWinDetails) == 'undefined')
    {
        return wmWindow.strWinName;
    }
    else
    {
        var str;
        if (wmWindow.arrWinDetails[0] == 'FormMaker')
        {
            if (wmWindow.arrWinDetails[2] == 'PageDesign')
                str = WinManager.message.get('winmanager.windownames.pageDesign', wmWindow.arrWinDetails[3]);
            else
                str = WinManager.message.get('winmanager.windownames.appMap');
        }
        else if (wmWindow.arrWinDetails[0] == 'RuleMaker')
        {
            str = WinManager.message.get('winmanager.windownames.rules', wmWindow.arrWinDetails[2], wmWindow.arrWinDetails[3]);
        }
        else if (wmWindow.arrWinDetails[0] == 'Test Dashboard')
        {
            str = WinManager.message.get('winmanager.windownames.dashboard');
        }
        else if (wmWindow.arrWinDetails[0] == 'Page Preview')
        {
            str = WinManager.message.get('winmanager.windownames.preview', wmWindow.arrWinDetails[2]);
        }
        else if ((wmWindow.arrWinDetails[0] == 'XSV') || (wmWindow.arrWinDetails[0] == 'DRV'))
        {
            if (wmWindow.arrWinDetails[2] == 'DocumentEdit')
            {
                if (forTab)
                    str = WinManager.message.get('winmanager.windownames.docEditForTab', wmWindow.arrWinDetails[wmWindow.arrWinDetails.length - 1]);
                else
                    str = WinManager.message.get('winmanager.windownames.docEdit', wmWindow.arrWinDetails[wmWindow.arrWinDetails.length - 1]);
            }
            else
            {
                str = WinManager.message.get('winmanager.windownames.docSelect');
            }
        }
        else if (wmWindow.arrWinDetails[0] == 'XDE')
        {
            str = WinManager.message.get('winmanager.windownames.xde');
        }
        else if (wmWindow.arrWinDetails[0] == 'Runtime')
        {
            str = WinManager.message.get('winmanager.windownames.runtime');
        }
        else
        {
            str = wmWindow.arrWinDetails[0];
        }

        if ((includeProject) && (typeof(wmWindow.arrWinDetails[1]) != 'undefined') && (wmWindow.arrWinDetails[1] != ''))
            str += ' (' + WinManager.message.get('winmanager.windownames.project', wmWindow.arrWinDetails[1]) + ')';

        return str;
    }
}

/**
 * Returns a string containing the type name for the specified window.
 * This is a unique value for each type of window, eg app map, page design, RM, etc
 * but does not include any details about the specific instance information eg which project, page, etc.
 * which would be included in the getDisplayName() response
 *
 * @param wmWindow The wmwindow object for the window to get the type string for
 * @returns the determined type string.
 */
WinManager.getWindowTypeString = function(wmWindow)
{
    var winType = wmWindow.arrWinDetails[0].replace(/\s/g, '');
    if ((wmWindow.arrWinDetails[0] == 'FormMaker') && (wmWindow.arrWinDetails[2] == 'AM'))
    {
        winType = 'FMAppMap'
    }
    else if (wmWindow.arrWinDetails[0] == 'FormMaker')
    {
        winType = 'FMPageDesign'
    }

    return winType;
}



/**
 * Sets the specified function to be run when the current window is next focused.
 * If the window is already focused, then the fucntion will be run immediately,
 * unless runIfPossible is set to false.
 * @param func The function reference to run.
 * @param runIfPossible (Optional) Set to false to stop the function being run straight away if the
 *              window is already focused.  Instead it will be run when the window is blured and
 *              then refocused.  Defaults to true.
 * @param objWin The window object that should be focussed.
 */
WinManager.runWhenFocused = function(func, runIfPossible, objWin)
{
    if (typeof(runIfPossible) != 'boolean')
        runIfPossible = true;

    var winIndex = WinManager.getWindow(objWin)
    if (winIndex != -1)
    {
        var wmWin = WinManager.arrWindows[winIndex];
        if (wmWin.strWinMode == 'tab')
        {
            if ((WinManager.currentTab === wmWin) && (runIfPossible))
            {
                func();
            }
            else
            {
                if ((typeof(wmWin.runOnFocus) == 'undefined') || (wmWin.runOnFocus == null))
                    wmWin.runOnFocus = new Array();

                wmWin.runOnFocus.push(func);
            }
        }
        else
        {
            //for now we only really handle tabbed windows,
            //so just run the function straight away for the others
            func();
        }
    }
}

/**
 * Makes sure that the specified window is currently visible.
 * @param objWin The window object that should be focussed.
 */
WinManager.focusWindow = function(objWin)
{
    var winIndex = WinManager.getWindow(objWin)
    if (winIndex != -1)
    {
        var wmWin = WinManager.arrWindows[winIndex];

        if (wmWin.strWinMode == 'tab')
        {
            if (WinManager.currentTab !== wmWin)
            {
                WinManager.tabs.selectTab(WinManager.tabs.getTabName(wmWin));
            }
        }
        else if (wmWin.strWinMode == 'popup')
        {
            objWin.focus();
        }
        else if (wmWin.strWinMode == 'dialog')
        {
            //for dialogs, just try and make sure the containing window is focussed
            WinManager.focusWindow(objWin.parent);
        }

    }

}


/**
 * --------------------------------------------------------------------------------------
 * Start of message box functionailty.
 * This has all been moved from the Child win manager scripts to here
 * so that the WinManager can now show messages on the whole window, across all open tabs.
 */






/**
 * Check if the WinManager styling has been output to the given window,
 * and if not makes sure it is included.
 */
WinManager.checkStylingOutput = function(objWin)
{
    if (!objWin.WinManager.stylingOutput)
    {

        var versionString = '?v=';
        if (WinManager.versionDetail)
            versionString += getElementText(WinManager.versionDetail.selectSingleNode("/product_version/version_code"));

        //For newer IE, need to use a different URL for each frame to prevent it randomly ignoring
        //some style rules from these stylesheets
        if (getIEVersion() >= 10)
        {
            if (objWin.WinManager.managedWin)
            {
                //try and find the wmWindow object
                var winIndex = WinManager.getWindow(objWin);
                if (winIndex != -1)
                {
                    versionString += WinManager.arrWindows[winIndex].strWinName;
                }
            }
            else if (objWin.parent.WinManager && objWin.parent.WinManager.managedWin)
            {
                //try and find the wmWindow object
                var winIndex = WinManager.getWindow(objWin.parent);
                if (winIndex != -1)
                {
                    versionString += WinManager.arrWindows[winIndex].strWinName;
                }
                var winURL = objWin.location.pathname;
                if (winURL.indexOf('/') != -1)
                    winURL = winURL.substring(winURL.lastIndexOf('/') + 1);
                if (winURL.indexOf('.') != -1)
                    winURL = winURL.substring(0, winURL.indexOf('.'));

                versionString += winURL;

            }
        }

        var head = objWin.document.getElementsByTagName('head')[0];

        var link = objWin.document.createElement('link');
        link.rel = 'stylesheet';
        link.type = 'text/css';
        link.href = '/webmaker/css/webmakerChildWin.css' + versionString;
        head.appendChild(link);
        link = objWin.document.createElement('link');
        link.rel = 'stylesheet';
        link.type = 'text/css';
        link.href = '/webmaker/css/webmakerChildWin_colours.css' + versionString;
        head.appendChild(link);

        if (dojo.isIE < 9)
        {
            var link2 = objWin.document.createElement('link');
            link2.rel = 'stylesheet';
            link2.type = 'text/css';
            link2.href = '/webmaker/css/webmakerChildWin_IE6-8.css' + versionString;
            head.appendChild(link2);
            link2 = objWin.document.createElement('link');
            link2.rel = 'stylesheet';
            link2.type = 'text/css';
            link2.href = '/webmaker/css/webmakerChildWin_colours_IE6-8.css' + versionString;
            head.appendChild(link2);
        }
        objWin.WinManager.stylingOutput = true;
    }
}



/**
 * Displays a message box on the current window, containing the provided content.
 * @param options Array config array that can contain the following options:
 *        objWin (Optional) The window object to display the messsage on
 *        content A string containing the HTML content to display inside the message box
 *        + all options defined for createMessageBox
 */
WinManager.displayMessageBox = function(options)
{
    if ((typeof(options.objWin) == 'undefined') || (options.objWin == null))
        options.objWin = window;

    WinManager.checkStylingOutput(options.objWin);

    WinManager.createMessageBox(options);

    options.objWin.document.getElementById('winManagerMsgContainer').innerHTML = options.content;

    //make sure we show the correct tooltips in the message box
    WinManager.tooltips.attachTipsToPage(null, options.objWin);
}

/**
 * Submits the given form and sets up the response to be displayed in a message box
 * @param options A config object which can contain the following options:
 *        objWin (Optional) The window object to display the messsage on
 *        sourceForm The form object to submit (One of this or sourceURL required)
 *        sourceURL The URL to display in the message box (One of this or sourceForm required)
 *        + all options defined for createMessageBox
 */
WinManager.loadIntoMessageBox = function(options)
{
    if ((typeof(options.objWin) == 'undefined') || (options.objWin == null))
        options.objWin = window;

    WinManager.checkStylingOutput(options.objWin);

    options.msgContainerClass = 'scrollable';

    WinManager.createMessageBox(options);

    if (!options.sourceURL)
        options.sourceURL = 'about:blank';

    var frameName = options.objWin.name + 'MsgBoxFrame';

    options.objWin.document.getElementById('winManagerMsgContainer').innerHTML =
            '<iframe id="'+frameName+'" name="'+frameName+'" src="' + options.sourceURL + '" style="width :100%; height : 100%; border : none;" frameBorder="0" title="winManagerMsgFrame"></iframe>';

    if (options.sourceForm)
    {
        options.sourceForm.target = frameName;
        options.sourceForm.submit();
    }

}

//Constants for the size of the message box components
//These will need to be adjusted if CSS changes etc.
var STATUS_BAR_HEIGHT = 28;
var MESSAGE_BOX_BUTTON_HEIGHT = 44;
var MESSAGE_CONTAINER_PADDING = 10; //The CSS adds 5px padding to the #winManagerMsgContainer so we need to allow for this when computing height
var HEADER_STRIP_HEIGHT = 37; //37 pixels to allow for size of header strip plus padding/margin etc


/**
 * Creates an empty message box
 * @param options a config object that can have the following properties:
 *        objWin The window object to create the message box on.
 *        size (Optional) Indicates the size of box to create.  Options are 'normal' (the default), 'big', 'full'
 *                      Any specific min or max widths will then be applied on top of this setting.
 *        minWidth/maxWidth (Optional) The min/max width (in pixels) to use for the displayed box
 *        minHeight/maxHeight (Optional) The min/max height (in pixels) to use for the displayed box
 *        fadeIn (Optional) boolean indicating whether to fade in the box or not
 *        title (Optional) The title to show on the message window
 *        createBlur (Optional) boolean indicating whether to blur the background. Defaults to true.
 *        buttons (Optional) Array of buttons to include in a bar at the bottom of the message. See setMessageBoxButtons
 *                          for details on the format of this array.
 *        onClose (Optional) Function to call when the message is closed. (Regardless of reason)
 *        onXXXX (Optional) Function to call when a button with the given reason is called. eg onOk, or onCancel.
 * @private
 */
WinManager.createMessageBox = function(options)
{
    if (typeof(options.fadeIn) == 'undefined')
        options.fadeIn = true;
    if (typeof(options.createBlur) == 'undefined')
        options.createBlur = true;

    var doc = options.objWin.document;

    if (doc.getElementById('winManagerMsgBox') != null) //already present
    {
        WinManager.clearMessageBox(options.objWin);
        options.fadeIn = false;
    }

    var screenSize = getViewportSize(doc, true);

    //determine the initial size of the message window
    var boxWidth, boxHeight

    if ((typeof(options.size) == 'undefined') || (options.size == 'normal'))
    {
        boxWidth = screenSize.width / 2;
        boxHeight = screenSize.height / 3;
    }
    else if (options.size == 'big')
    {
        boxWidth = screenSize.width * 3/4;
        boxHeight = screenSize.height * 2/3;
    }
    else if (options.size == 'full')
    {
        boxWidth = screenSize.width - 30;
        boxHeight = screenSize.height - 30;
    }

    //handle old style size settings
    if (options.width)
    {
        switch (options.sizeType)
        {
            case 'min': options.minWidth = options.width; break;
            case 'max': options.maxWidth = options.width; break;
            default   : options.minWidth = options.width;
                        options.maxWidth = options.width;
        }
    }
    if (options.height)
    {
        switch (options.sizeType)
        {
            case 'min': options.minHeight = options.height; break;
            case 'max': options.maxHeight = options.height; break;
            default   : options.minHeight = options.height;
                        options.maxHeight = options.height;
        }
    }


    //make sure we have a built in minimum height
    if (boxHeight < 300)
        boxHeight = 300;

    //check for provided dimensions
    if ((options.minWidth) && (boxWidth < options.minWidth))
        boxWidth = options.minWidth;
    if ((options.maxWidth) && (boxWidth > options.maxWidth))
        boxWidth = options.maxWidth;

    if ((options.minHeight) && (boxHeight < options.minHeight))
        boxHeight = options.minHeight;
    if ((options.maxHeight) && (boxHeight > options.maxHeight))
        boxHeight = options.maxHeight;


    //create the message container and centre ont he screen
    var container = doc.createElement('div');
    container.setAttribute('id', 'winManagerMsgBox');

    if (options.msgBoxContainerOverrideClass)
    {
        container.className = options.msgBoxContainerOverrideClass;
    }
    if (options.msgBoxContainerOverrideStyle)
    {
        for (prop in options.msgBoxContainerOverrideStyle)
        {
            container.style[prop] = options.msgBoxContainerOverrideStyle[prop];
        }
    }

    container.style.position = 'absolute';
    container.style.top = (((screenSize.height - boxHeight) / 2) + screenSize.scrollTop) + 'px';
    container.style.height = boxHeight + 'px';
    container.style.left = (((screenSize.width - boxWidth) / 2) + screenSize.scrollLeft) + 'px';
    container.style.width = boxWidth + 'px';
    /*container.style.background = 'white';
    container.style.border = 'thin solid black';*/


    //create a div to blur all the current contents
    if (options.createBlur)
    {
        var blur = doc.createElement('div');
        blur.setAttribute('id', 'winManagerMsgBlur');
        blur.style.position = 'absolute';
        blur.style.top = screenSize.scrollTop + 'px';
        blur.style.left = screenSize.scrollLeft + 'px';
        blur.style.height = screenSize.height + 'px';
        blur.style.width = screenSize.width + 'px';

        doc.body.appendChild(blur);
        //WinManager.attachEvent(blur, 'onclick', WinManager.clearMessageBox);
    }

    doc.body.appendChild(container);


    //create the msg box content structure (title bar, ok/cancel buttons etc)
    containerHTML = '';
    //check if we need to apply a frame underneath to stop bleed through. This is only needed for older II browsers
    if ((typeof(dojo) == 'undefined') || (dojo.isIE < 9))
        containerHTML += '<iframe id="winManagerMsgFrame" name="winManagerMsgFrame" src="about:blank" style="width :100%; height : ' + (container.offsetHeight + 2) + 'px; border : none;" frameBorder="0" title="winManagerMsgFrame"></iframe>';

    containerHTML += '<div id="winManagerMsgDiv"><div id="winManagerMsgHeader">';

    containerHTML += '<a href="#" onclick="WinManager.clearMessageBox(null, \'cancel\');return false;" class="dialogCloseBtn" title="Close"><span>Close</span></a>';

    if (typeof(options.title) == 'string')
        containerHTML += '<h3>' + options.title + '</h3>';

    var msgContainerHeight = container.offsetHeight - HEADER_STRIP_HEIGHT;

    //The normal styling adds padding to the container so we need to allow for this,
    //but the scrollable style (used when loading an app into an iframe in the box) does not
    if (!(options.msgContainerClass == 'scrollable'))
        msgContainerHeight -= MESSAGE_CONTAINER_PADDING;

    if (options.buttons)
        msgContainerHeight -= MESSAGE_BOX_BUTTON_HEIGHT;

    if (options.showStatusBar)
        msgContainerHeight -= STATUS_BAR_HEIGHT;

    containerHTML += '</div><div id="winManagerMsgContainer" style="height: ' + msgContainerHeight + 'px"';
    if (options.msgContainerClass)
        containerHTML += ' class="' + options.msgContainerClass + '"';
    containerHTML += '></div>';

    //add the submit button bar if needed (this will also attach any event handler functions)
    containerHTML += WinManager.getControlButtonsHTML(options);

    containerHTML += '</div>';

    container.innerHTML = containerHTML;

    if (options.showStatusBar)
    {
        WinManager.status.initDisplayInDialog(options.objWin);
    }


    //fade it in if needed
    if ((typeof(dojo) != 'undefined') && options.fadeIn)
    {
        container.style.opacity = 0;
        dojo.fadeIn({node: container}).play();
    }


    if (typeof(options.objWin.WinManager.clickNotClosure) != 'undefined')
        options.objWin.WinManager.attachEvent(container, "onclick", options.objWin.WinManager.clickNotClosure);
    options.objWin.WinManager.attachEvent(container, 'onclick', options.objWin.WinManager.cancelPropagation);
    //WinManager.clearMessageBoxEventHandle = WinManager.attachEvent(doc, 'onclick', WinManager.clearMessageBox);

    WinManager.keys.attach(27, options.objWin.WinManager.clearMessageBox, false, false, false, false, options.objWin);

}

/**
 * Returns an HTML string containing the specified buttons,
 * and attaches onclose functions if provided.
 * @param options Config object containing a buttons property describing the required buttons
 *                If this object also contains onXXX functions (and an objWin property) these
 *                functions will be registered where appropriate.
 */
WinManager.getControlButtonsHTML = function(options)
{
    var clickHandler = 'WinManager.clearMessageBox';
    if (options.clickHandler)
        clickHandler = options.clickHandler;

    if (!options.type)
        options.type = 'MessageBox';

    var baseId = 'WinManagerSubmit' + options.type + 'Button'

    var containerHTML = '';
    if (options.buttons)
    {
        containerHTML += '<div class="WinManagerSubmitMsgButtonGroup" id="'+baseId+'Group">';
        for (var i = 0; i < options.buttons.length; ++i)
        {
            var btnReason = '';

            if (options.buttons[i] == 'ok')
            {
                containerHTML += '<input type="button" value="' + WinManager.message.get('winmanager.buttons.ok') + '" class="WinManagerSubmitMsgButton" onclick="' + clickHandler + '(null, \'ok\');" id="'+baseId+'ok"/>';
            }
            else if (options.buttons[i] == 'save')
            {
                containerHTML += '<input type="button" value="' + WinManager.message.get('winmanager.buttons.save') + '" class="WinManagerSubmitMsgButton" onclick="' + clickHandler + '(null, \'save\');" id="'+baseId+'save"/>';
            }
            else if (options.buttons[i] == 'cancel')
            {
                containerHTML += '<input type="button" value="' + WinManager.message.get('winmanager.buttons.cancel') + '" class="WinManagerSubmitMsgButton secondaryActionButton" onclick="' + clickHandler + '(null, \'cancel\');" id="'+baseId+'cancel"/>';
            }
            else if (options.buttons[i] == 'close')
            {
                containerHTML += '<input type="button" value="' + WinManager.message.get('winmanager.buttons.close') + '" class="WinManagerSubmitMsgButton secondaryActionButton" onclick="' + clickHandler + '(null, \'close\');" id="'+baseId+'close"/>';
            }
            else if (typeof(options.buttons[i]) == 'object')
            {
                //custom button
                containerHTML += '<input type="button" value="' + options.buttons[i].caption + '" class="WinManagerSubmitMsgButton';
                if (options.buttons[i].secondary)
                    containerHTML += ' secondaryActionButton';
                if (options.buttons[i].disabled)
                    containerHTML += ' disabledButton';
                containerHTML += '"';

                if (options.buttons[i].title)
                    containerHTML += ' title="' + options.buttons[i].title + '"';

                if (options.buttons[i].disabled)
                    containerHTML += ' disabled="disabled"';

                containerHTML += ' onclick="' + clickHandler + '(null, \'' + options.buttons[i].reason + '\');" id="' + baseId + options.buttons[i].reason +'"/>';
            }
        }
        containerHTML += '</div>';
    }

    //now attach any onXXX event handlers
    for (prop in options)
    {
        if ((prop.indexOf('on') == 0) && (typeof(options[prop]) == 'function'))
        {
            var eventReason = prop.charAt(2).toLowerCase() + prop.substr(3);
            //Make sure an onClose function is correctly linked to any reason
            if (eventReason == 'close')
                eventReason = null;
            WinManager.notifyMessageBoxClosure(options[prop], options.objWin, eventReason);
        }
    }

    return containerHTML;
}



/**
 * Clears a message box displayed on the given window.
 * @param objWin The window object to remove the message box from.
 * @param reason (Optional) The reason for removing the message box. Supports 'ok' or 'cancel' (default)
 */
WinManager.clearMessageBox = function(objWin, reason)
{
    if ((typeof(objWin) == 'undefined') || (objWin == null) || (!objWin.document))
        objWin = window;

    var doc = objWin.document;

    var msg = doc.getElementById('winManagerMsgBox');
    if (msg != null)
    {
        if (objWin.WinManager.messageBoxOnClose)
        {
            for (var i = 0; i < objWin.WinManager.messageBoxOnClose.length; ++i)
            {
                var fd = objWin.WinManager.messageBoxOnClose[i];
                if ((fd.reason == 'all') || (fd.reason == reason))
                {
                    var funcResp = fd.func(reason);
                    if ((typeof(funcResp) == 'boolean') && (funcResp == false))
                        return;
                }
            }
        }

        objWin.WinManager.destroyDojoWidgets(msg);

        //check if there was a page loaded into the message box (in an iframe) and if so
        //explicitly close this iframe window and remove it from windows collection
        var contentFrame = doc.getElementById(objWin.name + 'MsgBoxFrame');
        if (contentFrame)
        {
            //remove any loading messages for this message box
            WinManager.clearLoadingMessage(contentFrame, objWin)

            var contentWin = contentFrame.contentWindow;
            if (contentWin)
            {
                WinManager.closeWindow(contentWin, true);
                contentWin.close();
            }
        }

        if (msg.parentNode)
            msg.parentNode.removeChild(msg);
    }
    var blur = doc.getElementById('winManagerMsgBlur');
    if (blur != null)
    {
        if (blur.parentNode)
            blur.parentNode.removeChild(blur);
    }

    //WinManager.detachEvent(doc, 'onclick', WinManager.clearMessageBox, WinManager.clearMessageBoxEventHandle);
    //objWin.WinManager.detachEvent(doc, 'onkeyup', objWin.WinManager.checkKeyClearMessageBox, objWin.WinManager.clearMessageBoxKeyUpEventHandle);
    WinManager.keys.detach(27, objWin.WinManager.clearMessageBox, false, false, false, false, objWin);

    objWin.WinManager.messageBoxOnClose = new Array();

    objWin.focus();
}

/**
 * Checks if there is a message box currently displayed on the given window.
 * @return boolean true if there is, false otherwise.
 */
WinManager.isMessageBoxVisible = function(objWin)
{
    if ((typeof(objWin) == 'undefined') || (objWin == null))
        objWin = window;

    var msg = objWin.document.getElementById('winManagerMsgBox');
    if (msg != null)
        return true;
    else
        return false;
}

/**
 * Register the specified function to be called on close of the current message box
 * @param function The function to call.  Returning false from this function will stop the closure.
 * @param objWin The window object the message box is on.
 * @param reason (Optional) The closure reason that ths function should be called for.
 *          This can be either 'ok' or 'cancel', or some other custom reason.
 *          If not provided, the function will be called on closure regardless of the reason.
 * @param toFront (Optional) If true this new function will be called before any existing functions
 *          when the specified reason occurrs. If false (the default) this new function will be called
 *          after any already defined.
 */
WinManager.notifyMessageBoxClosure = function(func, objWin, reason, toFront, sourceWin)
{
    if ((typeof(objWin) == 'undefined') || (objWin == null))
        objWin = window;

    if (!objWin.WinManager.messageBoxOnClose)
        objWin.WinManager.messageBoxOnClose = new Array();

    if ((typeof(reason) == 'undefined') || (reason == null))
        reason = 'all';

    var obj = {func: func, reason: reason}
    if (sourceWin)
        obj.sourceWin = sourceWin

    if (toFront)
        objWin.WinManager.messageBoxOnClose.unshift(obj);
    else
        objWin.WinManager.messageBoxOnClose.push(obj);
}


/**
 * Sets the set of buttons that should appear on the current message box shown in the given window.
 * @param buttons Array of buttons to include in a bar at the bottom of the message. Each entry in the array can be either
 *                the string 'ok' or 'cancel', or an object with 'caption', and 'reason' properties.  In this case, the
 *                caption will be displayed on the button, and the reason used to indicate which button is pressed. eg if the
 *                reason is 'fred' you could pass in an 'onFred' function, or use notifyMessageBoxClosure(func, 'fred')
 *                at a later point to run code when the button is pressed.
 *                If the 'secondary' property is also included and true, the custom button will be given the secondary button styling.
 *                A 'title' property is also supported to provide text to show in a tooltip over the button
 *                If the 'disabled' property is true, then the button will be disabled.
 */
WinManager.setMessageBoxButtons = function(buttons, objWin)
{
    //make sure a message box is visible on the given window
    var msgDiv = objWin.document.getElementById('winManagerMsgDiv');
    if (msgDiv != null)
    {
        //check if there are already some buttons shown
        var existing = objWin.document.getElementById('WinManagerSubmitMessageBoxButtonGroup');

        var options = {buttons: buttons, objWin: objWin};
        var newBtnHTML = WinManager.getControlButtonsHTML(options);
        var temp = objWin.document.createElement('div');
        temp.innerHTML = newBtnHTML;
        var newElem = temp.firstChild;

        if (existing)
        {
            msgDiv.replaceChild(newElem, existing);
        }
        else
        {
            //check if there is a status bar
            var status = objWin.document.getElementById('statusbar-dialog');
            if (status)
            {
                msgDiv.insertBefore(newElem, status);
            }
            else
            {
                msgDiv.appendChild(newElem);
            }
            //adjust the hieght of the message container accordingly
            var msgContainer = objWin.document.getElementById('winManagerMsgContainer');
            msgContainer.style.height = (parseInt(msgContainer.style.height) - MESSAGE_BOX_BUTTON_HEIGHT) + 'px';
        }
    }

}


/**
 * Sets the action buttons that should appear in the provided dialog window.
 * @param buttons the array of button specs - See setMessageBoxButtons for details
 * @param objWin The window object for a managed window that must have a display method of either popup or dialog
 */
WinManager.setDialogButtons = function(buttons, objWin)
{
    var winIndex = WinManager.getWindow(objWin);
    if (winIndex != -1)
    {
        var wmWin = WinManager.arrWindows[winIndex];
        if (wmWin.strWinMode == 'dialog')
        {
            WinManager.setMessageBoxButtons(buttons, objWin.parent);
        }
        else if (wmWin.strWinMode == 'popup')
        {
            var options = {buttons: buttons, objWin: objWin, clickHandler:'WinManager.handleDialogAction', type: 'Dialog'};
            var newBtnHTML = WinManager.getControlButtonsHTML(options);

            //enusre the containers are present
            WinManager.createPopupWinManagerContent(objWin);
            //update the button content
            var btnContainer = objWin.document.getElementById('popupBtns');
            btnContainer.innerHTML = newBtnHTML;

            //add bottom padding to the body to make space for the buttons
            var currentpb = parseInt(objWin.document.body.style.paddingBottom)
            if (isNaN(currentpb))
                currentpb = 0;
            objWin.document.body.style.paddingBottom = (currentpb + btnContainer.offsetHeight) + 'px';
        }
    }
}



/**
 * Sets the disabled state of the specified message box button.
 * @param reason The reason string for the button to set the disabled state of
 * @param disabled Boolean indicating whether it should be disabled or not.
 */
WinManager.setMessageBoxButtonDisabled = function(reason, disabled, objWin)
{
    var btn = objWin.document.getElementById('WinManagerSubmitMessageBoxButton' + reason);
    if (btn)
    {
        btn.disabled = disabled;
        if (btn.disabled)
            dojo.addClass(btn, 'disabledButton');
        else
            dojo.removeClass(btn, 'disabledButton');
    }
}
/**
 * Sets the disabled state of the specified dialog button.
 * @param reason The reason string for the button to set the disabled state of
 * @param disabled Boolean indicating whether it should be disabled or not.
 */
WinManager.setDialogButtonDisabled = function(reason, disabled, objWin)
{
    var winIndex = WinManager.getWindow(objWin);
    if (winIndex != -1)
    {
        var wmWin = WinManager.arrWindows[winIndex];
        if (wmWin.strWinMode == 'dialog')
        {
            WinManager.setMessageBoxButtonDisabled(reason, disabled, objWin.parent);
        }
        else if (wmWin.strWinMode == 'popup')
        {
            var btn = objWin.document.getElementById('WinManagerSubmitDialogButton' + reason);
            if (btn)
            {
                btn.disabled = disabled;
                if (btn.disabled)
                    dojo.addClass(btn, 'disabledButton');
                else
                    dojo.removeClass(btn, 'disabledButton');
            }
        }
    }
}



/**
 * Set a function to be called when a dialog action button is pressed.
 * @param function The function to call.
 * @param objWin The window object that is either a dialog or popup
 * @param reason (Optional) The reason that ths function should be called for.
 *          This can be either 'ok' or 'cancel', or some other custom reason.
 *          If not provided, the function will be called on any button press regardless of the reason.
 * @param toFront (Optional) If true this new function will be called before any existing functions
 *          when the specified reason occurrs. If false (the default) this new function will be called
 *          after any already defined.
 */
WinManager.notifyDialogAction = function(func, objWin, reason, toFront)
{
    if ((typeof(objWin) == 'undefined') || (objWin == null))
        objWin = window;

    if ((typeof(reason) == 'undefined') || (reason == null))
        reason = 'all';

    var winIndex = WinManager.getWindow(objWin);
    if (winIndex != -1)
    {
        var wmWin = WinManager.arrWindows[winIndex];
        if (wmWin.strWinMode == 'dialog')
        {
            WinManager.notifyMessageBoxClosure(func, objWin.parent, reason, toFront, objWin);
        }
        else if (wmWin.strWinMode == 'popup')
        {
            if (!objWin.WinManager.dialogActions)
                objWin.WinManager.dialogActions = new Array();

            if (toFront)
                objWin.WinManager.dialogActions.unshift({func: func, reason: reason});
            else
                objWin.WinManager.dialogActions.push({func: func, reason: reason});
        }
    }
}

WinManager.handleDialogAction = function(objWin, reason)
{
    if ((typeof(objWin) == 'undefined') || (objWin == null))
        objWin = window;

    var winIndex = WinManager.getWindow(objWin);
    if (winIndex != -1)
    {
        var wmWin = WinManager.arrWindows[winIndex];
        if (wmWin.strWinMode == 'dialog')
        {
            WinManager.clearMessageBox(objWin.parent, reason);
        }
        else if (wmWin.strWinMode == 'popup')
        {
            if (objWin.WinManager.dialogActions)
            {
                for (var i = 0; i < objWin.WinManager.dialogActions.length; ++i)
                {
                    var fd = objWin.WinManager.dialogActions[i];
                    if ((fd.reason == 'all') || (fd.reason == reason))
                    {
                        var funcResp = fd.func(reason);
                    }
                }
            }
        }
    }
}



/*
 * These next 3 functions are duplicated here and in the child win manager scripts!
 */

/**
 * cancels propagation of the event
 * @private
 */
WinManager.cancelPropagation = function(e)
{
    if (!e) var e = window.event;
    e.cancelBubble = true;
    if (e.stopPropagation) e.stopPropagation();
}

/**
 * cancels the default functionality of the event
 * @private
 */
WinManager.eventPreventDefault = function(e)
{
    if (!e) var e = window.event;
    e.returnValue = false;
    if (e.preventDefault) e.preventDefault();
}


/**
 * Attempts to destroy any dojo widgets that are present in the specified container
 * @param container The HTML container to destroy dojo widgets within. If not provided then the
 *              document body will be used instead, to destroy any widgets on the page.
 */
WinManager.destroyDojoWidgets = function(container, dijitObj)
{
    if (typeof(container) == 'undefined')
        container = document.body;

    var d = (dijitObj) ? dijitObj : ((typeof(dijit) != 'undefined') ? dijit : undefined);

    if ((typeof(d) != 'undefined') && (typeof(d.findWidgets) == 'function'))
    {
        var widgets = d.findWidgets(container);
        for (var i = 0; i < widgets.length; ++i)
        {
            var widget = widgets[i];
            widget.destroyRecursive();
            delete widget;
        }
    }
}








/**
 * Shows a loading message over the given container.
 * @param container (Optional) The HTML container to show a loading message over.
 *                  If not provided, then the whole page will be assumed.
 *                  If provided, the container must have an id.
 * @param msg (Optional) Text message to display in addition to the loading image.
 * @param objWin (Optional) The window object to display on
 * @param msgStyleOverride (Optional) If provided this should be the name of a CSS class to apply to the message
 *                  in addition to the default styling.
 */
WinManager.showLoadingMessage = function(container, msg, objWin, msgStyleOverride)
{
    if ((typeof(objWin) == 'undefined') || (objWin == null) || ((typeof(objWin) == 'boolean') && (objWin)))
        objWin = window;

    WinManager.checkStylingOutput(objWin);

    var msgPos = {x:0, y:0, width:0, height : 0};
    var idEnd = '';

    if ((typeof(container) == 'string') && (typeof(msg) == 'undefined'))
    {
        msg = container;
        container = null;
    }

    if ((typeof(container) == 'undefined')  || (container == null))
    {
        //blur whole page.
        var screenSize = getViewportSize(objWin.document, true);
        msgPos.x = screenSize.scrollLeft;
        msgPos.y = screenSize.scrollTop;
        msgPos.width = screenSize.width;
        msgPos.height = screenSize.height;
        idEnd = 'page';
    }
    else
    {
        msgPos = getComponentPosition(container, true);
        idEnd = container.id;
    }

    var blur = objWin.document.createElement('div');
    blur.setAttribute('id', 'winManagerLoadingMsgBlur' + idEnd);
    blur.className = 'winManagerLoadingMsgBlur';
    blur.style.position = 'absolute';
    blur.style.top = msgPos.y + 'px'
    blur.style.left = msgPos.x + 'px';
    blur.style.height = msgPos.height + 'px';
    blur.style.width = msgPos.width + 'px';
    objWin.document.body.appendChild(blur);

    var msgContainer = objWin.document.createElement('div');
    msgContainer.setAttribute('id', 'winManagerLoadingMsgContainer' + idEnd);
    msgContainer.className = 'winManagerLoadingMsgContainer';
    msgContainer.style.position = 'absolute';
    msgContainer.style.top = msgPos.y + (msgPos.height / 2) + 'px'
    msgContainer.style.left = msgPos.x + 'px';
    msgContainer.style.width = msgPos.width + 'px';
    msgContainer.style.textAlign = 'center';

    var msgContent = objWin.document.createElement('span');
    msgContent.className = 'winManagerLoadingMsg';

    if (typeof(msgStyleOverride) == 'string')
    {
        msgContent.className += ' ' + msgStyleOverride;
    }

    if (msg)
    {
        msgContent.innerHTML = msg;
    }

    msgContainer.appendChild(msgContent);
    objWin.document.body.appendChild(msgContainer);

    //if we have added a message for the whole page, and it is on a sub tab
    //also make the tab indicate busy status
    if ((idEnd == 'page') && (objWin !== window))
    {
        var winIndex = WinManager.getWindow(objWin);
        if (winIndex != -1)
        {
            if (WinManager.arrWindows[winIndex].strWinMode == 'tab')
            {
                WinManager.tabs.setTabBusyState(WinManager.tabs.getTabName(WinManager.arrWindows[winIndex]), true);
            }
        }
    }

    //if we are on ie8 add a hidden iframe behind the message so it will always be visible, even if over the SVG
    if (dojo.isIE < 9)
    {
        var detailFrame = objWin.document.getElementById('WinManagerLoadingMsgFrame');
        if (detailFrame == null)
        {
            detailFrame = objWin.document.createElement('iframe');
            detailFrame.id = 'WinManagerLoadingMsgFrame';
            detailFrame.src = 'about:blank';
            detailFrame.frameBorder = 0;
            detailFrame.setAttribute('frameBorder', '0');
        }

        var left = getLeftPosition(msgContent)
        msgContent.style.position = 'absolute';
        msgContent.style.top = '0px';
        msgContent.style.left = (left - msgPos.x) + 'px';
        msgContent.style.backgroundColor = 'white';

        detailFrame.style.position = 'absolute';
        detailFrame.style.top = msgContent.style.top;
        detailFrame.style.left = msgContent.style.left;
        detailFrame.style.width = msgContent.offsetWidth;
        detailFrame.style.height = msgContent.offsetHeight;

        msgContent.parentNode.insertBefore(detailFrame, msgContent);
    }

}

/**
 * Clears the loading message curently being displayed for the given container
 * @param container (Optional) The HTML container to clear a loading message over.
 *                  If not provided, then the whole page will be assumed.
 *                  If provided, the container must have an id.
 * @param objWin (Optional) The window object to display on
 */
WinManager.clearLoadingMessage = function(container, objWin)
{
    if ((typeof(objWin) == 'undefined') || (objWin == null) || ((typeof(objWin) == 'boolean') && (objWin)))
        objWin = window;

    var idEnd = '';
    if ((typeof(container) == 'undefined')  || (container == null))
    {
        idEnd = 'page';
    }
    else
    {
        idEnd = container.id;
    }

    var blur = objWin.document.getElementById('winManagerLoadingMsgBlur' + idEnd)
    if (blur != null)
    {
        blur.parentNode.removeChild(blur);
        var msg = objWin.document.getElementById('winManagerLoadingMsgContainer' + idEnd)
        if (msg != null)
        {
            msg.parentNode.removeChild(msg);
        }
    }

    //if we have cleared a message for the whole page, and it is on a sub tab
    //then make sure we reove the tab busy indicater
    if ((idEnd == 'page') && (objWin !== window))
    {
        var winIndex = WinManager.getWindow(objWin);
        if (winIndex != -1)
        if (WinManager.arrWindows[winIndex].strWinMode == 'tab')
        {
            WinManager.tabs.setTabBusyState(WinManager.tabs.getTabName(WinManager.arrWindows[winIndex]), false);
        }
    }
}



/**
 * Loads up all the current preference settings.
 */
WinManager.loadPreferences = function()
{
    WinManager.preferences = null;

    //we call the preferences projects getPrefs action as this handles providing the correct defaults
    //if there are no details stored in the clipbaord.
    dojo.xhrGet({
            url: '../Preferences/getPrefs.do',
            preventCache: true,
            handleAs: 'text',
            load: function(data, ioargs) {
                    WinManager.processPreferencesResponse(data);
            },
            error: function(data){
                    WinManager.status.showMessage({msg: WinManager.message.get('winmanager.prefsLoadError'), detail: data.message, level: 'error', type: 'wm-prefs'})
            }
    });

}

/**
 * Called when the prefs load call has completed to actaully parse the response
 * and setup the WinManager.preferences object.
 */
WinManager.processPreferencesResponse = function(data)
{
    var prefsDoc = getXMLDocument(data);
    if (Sarissa.getParseErrorText(prefsDoc) == Sarissa.PARSED_OK)
    {
        Sarissa.setXpathNamespaces(prefsDoc, 'xmlns:xfact="http://www.hyfinity.com/xfactory"');
        if (prefsDoc.selectSingleNode('/xfact:preferences'))
        {
            var prefs = prefsDoc.selectNodes('/xfact:preferences/*');
            WinManager.preferences = {};
            for (var i = 0; i < prefs.length; ++i)
            {
                var p = prefs.item(i);
                WinManager.preferences[getBaseName(p)] = getElementText(p)
            }
        }
        else
        {
            //assume studio hasn't started, so display a message and stop them from using the studio
            WinManager.showStartupErrorMsg(data);
        }
    }
    else
    {
        WinManager.status.showMessage({msg:WinManager.message.get('winmanager.prefsLoadError'), detail: WinManager.message.get('winmanager.errorParsingResponse') + Sarissa.getParseErrorText(prefsDoc), level: 'error', type: 'wm-prefs'})
    }
}


/**
 * Gets the user/studio preferences.
 * If no parameter is provided this will return a map of all defined preferences (name to value)
 * If a preference name is provided, then this will return a string with that particular value.
 * @param prefName (Optional) The name of a specific preference to get the value for.
 * @return A map of all preferences, or a specific value, or null if not avaialble
 */
WinManager.getPreferences = function(prefName)
{
    if (!WinManager.preferences)
        return null;
    else if (typeof(prefName) == 'undefined')
        return WinManager.preferences
    else if (typeof(WinManager.preferences[prefName]) != 'undefined')
        return WinManager.preferences[prefName];
    else
        return null
}

/**
 * Gets a system property value from the server.
 * As this is a server call, this will be an async operation with the function returning immediately, and then
 * the callback function called when the value has been returned.  This is needed because the given propName
 * can be a combination of system properties and static text etc, so we can't cache the results of this.
 * @param propName a string containing one or more system property values to convert.
 *              System proeprties should be in the format ${property-name}
 * @callback A function that will be called when the value has been retrieved.  This will be passed one
 *              parameter which is the propName string with the property values converted. (Or null if
 *              an error occurred.)
 */
WinManager.getSystemProperty = function(propName, callback)
{

    var requestMessage = '<SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/">'
                            + '<SOAP-ENV:Body>'
                                + '<get_system_property xmlns="http://www.hyfinity.com/xfactory">'
                                    + '<request>'
                                        + '<name>' + propName + '</name>'
                                    + '</request>'
                                + '</get_system_property>'
                            + '</SOAP-ENV:Body>'
                        + '</SOAP-ENV:Envelope>';


    dojo.rawXhrPost({
        url:        '/xde_services',
        handleAs:   'text',
        postData:   requestMessage,
        headers:    { SOAPAction: "GetSystemProperty" },
        error:      function(response, ioArgs){
                        WinManager.status.showMessage({msg: WinManager.message.get('winmanager.systemPropLoadError') + ' ' + response.message, level: 'error', type: 'get_system_property'});
                        callback(null);

                        return response;
                    },
        load:       function(response, ioArgs) {
                        var responseDoc = getXMLDocument(response);


                        if (Sarissa.getParseErrorText(responseDoc) == Sarissa.PARSED_OK)
                        {
                            Sarissa.setXpathNamespaces(responseDoc, "xmlns:xfact='http://www.hyfinity.com/xfactory' xmlns:soap='http://schemas.xmlsoap.org/soap/envelope/'");
                            var value = getElementText(responseDoc.selectSingleNode("/soap:Envelope/soap:Body/xfact:get_system_property/xfact:response/xfact:value"));

                            callback(value);
                        }
                        else
                        {
                            WinManager.status.showMessage({msg:WinManager.message.get('winmanager.systemPropLoadError'), detail: WinManager.message.get('winmanager.errorParsingResponse') + Sarissa.getParseErrorText(responseDoc), level: 'error', type: 'get_system_property'})
                            callback(null);
                        }

                        return response;
                    }
    });


}

/**
 * Sets the list of container IDs on the page that are scrollable.
 * The WinManager will use this to make sure that the scroll state of these containers is
 * maintained when switching tabs, as otherwise these generally scroll to the top.
 * @param containers An array of container IDs, eg ['container1'. 'container2']
 *      For more complex scenarios you can pass an object for each array item.  This should have a value property
 *      and a type property.  If the type is 'id', the value is assumed to be the container ID.
 *      If the type is 'script_fragment', the value is assumed to be a script fragment that should be evaluated to get the container.
 * @param objWin The window the containers apply to.
 */
WinManager.setScrollableContainers = function(containers, objWin)
{
    var iWinIndex = WinManager.getWindow(objWin);
    if (iWinIndex != -1)
    {
        var wmWin = WinManager.arrWindows[iWinIndex];

        wmWin.scrollableContainers = new Array();
        for (var i = 0; i < containers.length; ++i)
        {
            var type = 'id';
            var value = containers[i];

            if (typeof(containers[i]) == 'object')
            {
                type = containers[i].type;
                value = containers[i].value;
            }

            wmWin.scrollableContainers.push({
                    type: type,
                    value: value,
                    scrollTop: 0,
                    scrollLeft: 0
            });
        }

    }
}

/**
 * Checks whether the current window is allowed to save any changes.
 * For example, if you dont have the project checked out then saving will not be allowed.
 * @param alertUser (Optional) If true, and save not allowed a message will be shown to the user.
 *                  Defaults to false.
 * @param objWin The window object to check for.
 * @return boolean indicating if save is possible.
 */
WinManager.isSaveAllowed = function(alertUser, objWin)
{
    if (WinManager.projectInformation && WinManager.projectInformation.status && WinManager.projectInformation.status.checkedout)
    {
        return true;
    }
    else
    {
        if (alertUser)
        {
            WinManager.alert({
                        strMsg: WinManager.message.get('winmanager.save.notCheckedOutMsg'),
                        strTitle: WinManager.message.get('winmanager.save.notCheckedOutTitle'),
                        objWin: objWin
            });
        }
        return false;
    }
}



/**
 * Sets the save in progress flag for the given window.
 * This is used to decide whether to autaomtically perform
 * a GIT commit operation when the changes are next cleared.
 * @param commitMsg (Optional)  The message to use for the auto commit.
 * @param objWin The window object that is saving
 */
WinManager.setSaveInProgress = function(commitMsg, objWin)
{
    var iWinIndex = WinManager.getWindow(objWin);
    if (iWinIndex != -1)
    {
        var wmWin = WinManager.arrWindows[iWinIndex];

        wmWin.saveInProgress = true;

        if (commitMsg)
            wmWin.commitOnSaveMessage = commitMsg;
    }
}




/**
 * --------------------------------------------------------------------------------------------------
 * Start of menu bar interaction functions.
 */

/**
 * Updates the display of the menu to show the approapriate options based on tghe current state of the
 * WinManager.defaultOperations array, plus the operations for the currently selected tab.
 */
WinManager.updateDisplayedMenuOptions = function()
{
    var combinedOps;
    if ((WinManager.currentTab != null) && (WinManager.currentTab.arrOperations))
        combinedOps = WinManager.defaultOperations.concat(WinManager.currentTab.arrOperations);
    else
        combinedOps = WinManager.defaultOperations;

    WinManager.menu.refresh(combinedOps);
}

/**
 * Returns the object in the operatinos array for the given operation name.
 * @param opName The name of the operaiton to check for.
 * @param opArray (Optional) The operation array to look in.  If this is not provided,
 *               this will look in the defaultOperations, and also the operations for the
 *               current tab.
 * @return The found object for the operation, or null if not found.
 */
WinManager.getMenuOperationSetting = function(opName, opArray)
{
    var checkArray;
    if (opArray)
    {
        checkArray = opArray;
    }
    else
    {
        if ((WinManager.currentTab != null) && (WinManager.currentTab.arrOperations))
            checkArray = WinManager.defaultOperations.concat(WinManager.currentTab.arrOperations);
        else
            checkArray = WinManager.defaultOperations;
    }

    for (var i = 0; i < checkArray.length; ++i)
    {
        if (checkArray[i].strId == opName)
            return checkArray[i];
    }
    return null;
}

/**
 * Tries to set the given menu operation to the provided enabled state.
 * @param opName The name of the operation to adjust.
 * @param enabled {boolean} The new enabled state.
 * @param opArray Optional operations array to look in.
 */
WinManager.setMenuOperationEnabledSetting = function(opName, enabled, opArray)
{
    var obj = WinManager.getMenuOperationSetting(opName, opArray);
    if (obj)
    {
        obj.bEnabled = enabled;
    }
}


/**
 * Function called by a sub tab/window to set what operations it supports.
 * @param objWin the window object the oeprations are for
 * @param operations The array of supported operations
 * @param update (Optional) boolean indicating whether this list should update (be merged with) the existing
 *          list of operations or replace it.  Thw default is to replace.
 */
WinManager.setSupportedOps = function(operations, update, objWin)
{
   var winIndex = WinManager.getWindow(objWin)
   if (winIndex != -1)
   {
       var wmWin = WinManager.arrWindows[winIndex];

       //always keep the save and revert operations enabled
       for (var i = 0; i < operations.length; ++i)
       {
           if ((operations[i].strId == 'save_tab') || (operations[i].strId == 'revert_tab'))
           {
               operations[i].bEnabled = true;
           }
       }



       if (update)
       {
           for (var i = 0; i < operations.length; ++i)
           {
               var existingOp = WinManager.getMenuOperationSetting(operations[i].strId, wmWin.arrOperations);
               if (existingOp)
               {
                   existingOp.bEnabled = operations[i].bEnabled;
                   existingOp.bHidden = operations[i].bHidden;
               }
               else
               {
                   wmWin.arrOperations.push(operations[i]);
               }
           }
       }
       else
       {
           wmWin.arrOperations = operations;
       }

       //if it is the current tab, then update the menu display
       if (WinManager.currentTab === wmWin)
       {
           WinManager.updateDisplayedMenuOptions();
       }

   }
}

/**
 * Handles the selection of an option from the menu.
 * This is responsible for determining which menu option was selected, and degating the functionality accordingly.
 * @param selection The details of the selected option.  This will actually be an arry in the same format as the
 *              operations lists, but with only 1 entry.
 */
WinManager.handleMenuItemSelection = function(selection)
{
    for (var i = 0; i < selection.length; ++i)
    {
        var op = selection[i];

        if ((op.strId == 'save_tab') || (op.strId == 'save_all_tabs'))
        {
            if (!WinManager.isSaveAllowed(true))
            {
                continue;
            }
        }

        //check for WinManager implemented operations
        switch (op.strId)
        {
            //design menu
            case 'open_project'     :   WinManager.opHandler.handleStartProject("open_project"); break;
            case 'new_project'      :   WinManager.opHandler.handleStartProject("new_project"); break;
            case 'copy_project'     :   WinManager.opHandler.handleStartProject("copy_project"); break;
            case 'import_project'   :   WinManager.opHandler.handleStartProject("import_project"); break;
            case 'export_project_template' : WinManager.opHandler.handleExportProjectTemplate("export_project_template"); break;
            case 'delete_project'   :   WinManager.opHandler.handleDeleteProject(); break;
            case 'delete_workspace' :   WinManager.opHandler.handleStartProject("delete_workspace"); break;
            case 'export_project'   :   WinManager.opHandler.handleExportProject(); break;
            case 'project_settings' :   WinManager.opHandler.showXDEProjectScreen(); break;
            case 'save_all_tabs'    :   WinManager.opHandler.saveAll(); break;
            case 'revert_all_tabs'  :   WinManager.opHandler.revertAll(); break;
            case 'revert_project'   :   WinManager.opHandler.handleViewCommitHistory(); break;
            case 'close_tab'        :   WinManager.tabs.closeTab(WinManager.tabs.getTabName(WinManager.currentTab)); break;
            case 'close_all_tabs'   :   WinManager.closeProject(); break;
            case 'project_properties':  WinManager.opHandler.openProjectProperties(); break;

            //edit menu
            case 'preferences'      :   WinManager.opHandler.handlePreferences(); break;

            //test menu
            case 'run_local'        :   WinManager.opHandler.handleRunLocal(); break;
            case 'debugger'         :   WinManager.opHandler.showDashboard(); break;
            case 'logs_clear'       :   WinManager.opHandler.clearLogSettings(); break;
            case 'service_tester'   :   WinManager.opHandler.showServiceTester(); break;
            case 'run_local_settings':  WinManager.opHandler.handleXGenSettings('deploy'); break;

            //publish menu
            case 'publish'          :   WinManager.opHandler.handlePublish(); break;
            case 'publish_settings' :   WinManager.opHandler.handleXGenSettings('publish'); break;

            //team menu
            case 'check_in'         :   WinManager.opHandler.handleCheckin(); break;
            case 'check_out'        :   WinManager.opHandler.handleCheckout(); break;
            case 'cancel_check_out' :   WinManager.opHandler.handleCancelCheckout(); break;
            case 'connect_server'   :   WinManager.opHandler.handleConnectServer(); break;
            case 'disconnect_server':   WinManager.opHandler.handleDisconnectServer(); break;
            case 'share_project'    :   WinManager.opHandler.handleShareProject(); break;
            case 'download_project' :   WinManager.opHandler.handleDownloadProject(); break;
            case 'remove_project'   :   WinManager.opHandler.handleRemoveSharedProject(); break;
            case 'view_history'     :   WinManager.opHandler.handleViewHistory(); break;


            //help menu
            case 'documentation'    :   WinManager.openNewChildWindow(window, '/documentation', ['Documentation'], {displayMode: 'popup'}); break;
            case 'getting_started'  :   WinManager.opHandler.handleGettingStarted(true); break;
            case 'getting_started_tips':WinManager.opHandler.handleGettingStartedTips(true); break;
            case 'wmforum'          :   if (WinManager.productType == 'bizflow')
                                            window.open('http://community.bizflow.com');
                                        else
                                            window.open('http://www.hyfinity.com/links/wmforum');
                                        break;
            case 'about'            :   WinManager.showVersionInfo(); break;
        }

        //check if the currentTab supports this operation
        if (WinManager.currentTab)
        {
            var tabOpSetting = WinManager.getMenuOperationSetting(op.strId, WinManager.currentTab.arrOperations)
            if (tabOpSetting && tabOpSetting.bEnabled)
            {
                //check if the window implements the handleMenuOp function
                if (typeof(WinManager.currentTab.objWin.handleMenuOp) == 'function')
                {
                    WinManager.currentTab.saveInProgress = false;
                    if (op.strId == 'save_tab')
                    {
                        //make sure we now deploy these changes first before testing
                        WinManager.projectDeployRequired = true;
                        WinManager.currentTab.saveInProgress = true;
                    }

                    WinManager.currentTab.objWin.handleMenuOp(op);
                }
            }
        }
    }
}





/**
 * --------------------------------------------------------------------------------------------------
 * Start of functionality related to displaying and managing the tab bar for all open windows
 *
 */


dojo.require('dijit.layout.TabContainer');
dojo.require('dijit.layout.ContentPane');
dojo.require('dojo.dnd.Source');

require(["dijit/focus", "dijit/registry", "dojo/_base/array", "dojo/topic"], function(focus, registry, array, topic) {

    /*
     * Extension to the default dojo tab controller so that we stop the ability to switch away from a busy tab.
     * this is because we currently have issues with pages not loading correctly if they are not active
     * Mainly due to trying to get dimensions of things etc within a hidden tab
     */
    dojo.extend(dijit.layout.TabController, {
        onButtonClick: function(/*dijit._Widget*/ page,evt) {
            // summary:
            //      Called whenever one of my child buttons is pressed in an attempt to select a page
            // tags:
            //      private

            //stop the ability to switch if the current tab is busy
            var currentBtn = this.pane2button[this._currentChild.id];
            if (currentBtn.get('iconClass').indexOf('busyTab') != -1)
                return;

            //the following is a copy of code for the oriignal onButtonClick function
            //from dojo 1.8.1 StackController.js.uncompressed.js

            var button = this.pane2button[page.id];

            // For TabContainer where the tabs are <span>, need to set focus explicitly when left/right arrow
            focus.focus(button.focusNode);

            if(this._currentChild && this._currentChild.id === page.id) {
                //In case the user clicked the checked button, keep it in the checked state because it remains to be the selected stack page.
                button.set('checked', true);
            }
            var container = registry.byId(this.containerId);
            container.selectChild(page);

        }
    });

    /**
     * Extends the StackContainer to change the removechild method, so that
     * we go to the tab to the left of the current one, rather than the first
     */
    dojo.extend(dijit.layout.StackContainer, {
        removeChild: function(/*dijit._Widget*/ page){
            // Overrides _Container.removeChild() to do layout and publish events

            //HYF addition from latest dojo SVN
            var idx = array.indexOf(this.getChildren(), page);

            this.inherited("removeChild", arguments);

            if(this._started){
                // this will notify any tablists to remove a button; do this first because it may affect sizing
                topic.publish(this.id + "-removeChild", page);	// publish
            }

            // If all our children are being destroyed than don't run the code below (to select another page),
            // because we are deleting every page one by one
            if(this._descendantsBeingDestroyed){ return; }

            // Select new page to display, also updating TabController to show the respective tab.
            // Do this before layout call because it can affect the height of the TabController.
            if(this.selectedChildWidget === page){
                this.selectedChildWidget = undefined;
                if(this._started){
                    var children = this.getChildren();
                    if(children.length){
                        //HYF change from latest dojo SVN
                        //this.selectChild(children[0]);
                        this.selectChild(children[Math.max(idx-1, 0)]);
                    }
                }
            }

            if(this._started){
                // In case the tab titles now take up one line instead of two lines
                // (note though that ScrollingTabController never overflows to multiple lines),
                // or the height has changed slightly because of addition/removal of tab which close icon
                this.layout();
            }
        }
    });

});




WinManager.tabs = {
    dojoTC: null, //The dojo tab container widget

    //indicates the ordering of tabs used when opening a new one.
    //this ensures that they all rules are grouped together for example
    //This maps tab type values to a position number
    ordering: {'FMAppMap'       : 1,
               'FMPageDesign'   : 2,
               'PagePreview'    : 3,
               'XDE'            : 4,
               'RuleMaker'      : 5,
               'XSV'            : 6,
               'DRV'            : 7,
               'TestDashboard'  : 8,
               'Runtime'        : 9 }
};

/**
 * Initialises the tab container.
 * @param containerId The ID of the HTML container to show the tabs in.
 */
WinManager.tabs.init = function(containerId)
{
    var tabHeight = WinManager.tabs.resize(true);

    var tabSizeMode = WinManager.getPreferences('tab_sizing_mode');

    var tabClass = (tabSizeMode == 'fixed-width') ? 'fixedWidthTabs' : '';

    WinManager.tabs.dojoTC = new dijit.layout.TabContainer({
            style: 'height: ' + tabHeight + 'px; width: 100%;',
            'class': tabClass,
            persist:false,
            tabStrip:true
        }, containerId);

    if (tabSizeMode == null) //prefs not yet loaded
    {
        require(['dojo/aspect'], function(aspect) {
                aspect.after(WinManager, "processPreferencesResponse", function() {
                        var newTabSizeMode = WinManager.getPreferences('tab_sizing_mode');
                        var newTabClass = (newTabSizeMode == 'fixed-width') ? 'fixedWidthTabs' : '';
                        WinManager.tabs.dojoTC.set('class', newTabClass);

                });
        });
    }


    WinManager.tabs.dojoDndSource = new dojo.dnd.Source(WinManager.tabs.dojoTC.tablist.containerNode, {
            withHandles: false,
            horizontal: true
    });



    //make sure handleTabChange is called after switching to a new tab
    WinManager.tabs.dojoTC.watch("selectedChildWidget", function(name, oval, nval){
        if (dojo.byId(nval.id + '_iframe'))
        {
            var tabWin = dojo.byId(nval.id + '_iframe').contentWindow;
            if (tabWin)
            {
                var wmWinNum = WinManager.getWindow(tabWin);
                if (wmWinNum != -1)
                {
                    WinManager.tabs.handleTabChange(WinManager.arrWindows[wmWinNum])
                }
            }
        }
    });



    //store any needed scroll offsets when switching away from a tab
    require(["dojo/aspect"], function(aspect) {

        aspect.before(WinManager.tabs.dojoTC, "selectChild", function(){

                try
                {
                    if ((WinManager.currentTab) && (WinManager.currentTab.objWin) && (!WinManager.currentTab.objWin.closed))
                    {
                        //store the current scroll amounts for any scrollable containers on the tab we are switching from
                        //this is so we can reset these when we switch back to this tab
                        if (WinManager.currentTab.scrollableContainers)
                        {
                            for (var i = 0; i < WinManager.currentTab.scrollableContainers.length; ++i)
                            {
                                var c = WinManager.currentTab.scrollableContainers[i];
                                var container;
                                if (c.type == 'id')
                                    container = WinManager.currentTab.objWin.document.getElementById(c.value);
                                else if (c.type == 'script_fragment')
                                {
                                    with (WinManager.currentTab.objWin)
                                    {
                                        container = eval(c.value);
                                    }
                                }

                                if (container)
                                {
                                    c.scrollTop = container.scrollTop;
                                    c.scrollLeft = container.scrollLeft;
                                }
                            }
                        }
                    }
                }
                catch (e)
                {
                    //error accessing scroll containers.
                    //This is probably because the window is no longer available so ignore
                }

        });
    });





    WinManager.tabs.dojoTC.startup();
    WinManager.attachEvent(window, 'onresize', WinManager.tabs.resize);

    WinManager.tabs.dojoTC.domNode.style.visibility = 'hidden';
}

/**
 * Works out the new height to apply to the tabs, and updates the container.
 * @param dontUpdate (Optional) If true, the tab container wont actually be updated,
 *          with just the new size returned.
 * @return the new height value in pixels.
 */
WinManager.tabs.resize = function(dontUpdate)
{
    vps = getViewportSize();
    //console.log(vps.height + ' : ' + vps.width);
    //var tabsHeight = document.documentElement.clientHeight -
    var tabsHeight = vps.height -
                            dojo.byId('infobar').offsetHeight -
                            dojo.byId('menubar').offsetHeight -
                            dojo.byId('toolbar').offsetHeight -
                            dojo.byId('statusbar').offsetHeight;

    if (((typeof(dontUpdate) != 'boolean') || !dontUpdate) && (WinManager.tabs.dojoTC))
    {
        WinManager.tabs.dojoTC.resize({h: tabsHeight});
    }

    return tabsHeight;
}

/**
 * Adds a new tab to the tab bar, and returns the window object for the
 * new tabs content.
 * @param tabName The name to use for the new tab.
 * @param startUrl The initial URL to display in the tab frame.
 * @param displayTitle The text to display in the tab button.
 * @param type The type of tab to open.  This will be used in the class name for the image icon for example.
 * @praram closable boolean indicating whetehr the user can close this tab.
 * @param selectNewTab (Optional) boolean indicating whether this new tab should be selected. defaults to true.
 * @return The window object for the iframe created in the new tab.
 */
WinManager.tabs.newTab = function(tabName, startUrl, displayTitle, type, closable, selectNewTab)
{
    WinManager.tabs.dojoTC.domNode.style.visibility = 'visible';
    var tabSetup = {
                        id: tabName,
                        title: displayTitle,
                        content: '<iframe id="'+tabName+'_iframe" name="'+tabName+'" src="' + startUrl + '" frameBorder="0" style="width:100%; height:100%"/>',
                        closable: closable,
                        onClose: WinManager.tabs.checkTabCanClose,
                        iconClass: 'hyfTab ' + type,
                        tabType: type
    };

    //work out where the tab should go
    var insertPos;

    var openTabMode = WinManager.getPreferences('open_tab_mode');

    if (openTabMode == 'group') //open tabs in groups
    {
        var currentTabs = WinManager.tabs.dojoTC.tablist.getChildren();
        insertPos = currentTabs.length;

        var newTypeNum = (WinManager.tabs.ordering[type]) ? WinManager.tabs.ordering[type] : 99;

        for (var i = 0; i < currentTabs.length; ++i)
        {
            var ct = dijit.byId(currentTabs[i].id.substring(WinManager.tabs.dojoTC.tablist.id.length + 1));
            var tabType = ct.get('tabType');
            var typeNum = (WinManager.tabs.ordering[tabType]) ? WinManager.tabs.ordering[tabType] : 100;
            if (typeNum <= newTypeNum)
            {
                insertPos = i;
            }
        }
    }
    else if ((openTabMode == 'right') && (WinManager.tabs.dojoTC.selectedChildWidget))//open to right of current
    {
        insertPos = WinManager.tabs.dojoTC.tablist.getIndexOfChild(WinManager.tabs.dojoTC.selectedChildWidget.controlButton);
    }
    else //open at end
    {
        insertPos = WinManager.tabs.dojoTC.getChildren().length;
    }

    var newTab = new dijit.layout.ContentPane(tabSetup);
    WinManager.tabs.dojoTC.addChild(newTab, insertPos + 1);

    if ((typeof(selectNewTab) == 'undefined') || (selectNewTab))
    {
        WinManager.tabs.dojoTC.selectChild(newTab);
        //add the busy icon to the tab while it is loading
        if (type != 'Runtime')
            WinManager.tabs.setTabBusyState(tabName, true);
    }

    dojo.addClass(newTab.controlButton.domNode, 'dojoDndItem');
    WinManager.tabs.dojoDndSource.sync();


    if (WinManager.getPreferences('tab_sizing_mode') == 'fixed-width')
    {
        var btn = newTab.controlButton;
        if (btn.containerNode.scrollWidth > btn.containerNode.offsetWidth)
            btn.containerNode.title = btn.get('label');
    }

    var iframe = dojo.byId(tabName + '_iframe');

    return iframe.contentWindow;
}

/**
 * function attached to onClose of each closable tab.
 * This will prompt the user whether to actually close if there are unsaved changes.
 * @return boolean Whether to close the tab.
 * @private
 */
WinManager.tabs.checkTabCanClose = function(container, tab)
{
    var canClose = true;
    if (dojo.byId(tab.id + '_iframe'))
    {
        var tabWin = dojo.byId(tab.id + '_iframe').contentWindow;
        if (tabWin)
        {
            if (!tab.wmForceClose)
            {
                var msg = WinManager.confirmWinClosure(tabWin);
                if ((typeof(msg) != 'undefined') && (msg != ''))
                {
                    WinManager.userConfirmed({strMsg: WinManager.message.get('winmanager.tabs.confirmClose', msg),
                                              objConfirmHandler : function() {
                                                  tab.wmForceClose = true;
                                                  WinManager.tabs.closeTab(tab.id);
                                              }
                    });
                    canClose = false;
                }
            }

            //check if we need to tell the window that the tab is closing
            if (canClose)
            {
                try
                {
                    //dont do this if we are reloading a project, as we dont want the tab to do any auto save processing
                    //as it is likely the files on teh file system have already been changed (eg reverted to a diff version)
                    //and so wont be in sync with what is on screen.
                    var reloadingProject = (WinManager.requestedProjectOpen && WinManager.requestedProjectOpen.reloading);
                    if (!reloadingProject)
                    {
                        if (typeof(tabWin.handleMenuOp) == 'function')
                            tabWin.handleMenuOp({strId: 'tab_closing'});
                    }
                }
                catch (e)
                {
                    //can get access denied errors accessing the window (eg for the runtime)
                    //which we just ignore as we still want to close the tab
                }


                //sometimes in IE just removing the iframe content does not cause the
                //window object to be closed, so we explicitly close it here
                //and remove the win reference
                WinManager.closeWindow(tabWin, true)
                tabWin.close();
            }
        }
    }
    return canClose;
}

/**
 * Switches to the specified tab.
 * @param tabName The name of the tab to switch to.
 */
WinManager.tabs.selectTab = function(tabName)
{
    var pane = dijit.byId(tabName);
    if (pane != null)
    {
        WinManager.tabs.dojoTC.selectChild(pane);
    }
}

/**
 * Updates the display of the given tab to inidcate its dirty status.
 * @param tabName The unique name of the tab to adjust.
 * @param dirty boolean indicating whether this tab is dirty or not.
 */
WinManager.tabs.setTabDirtyState = function(tabName, dirty)
{
    var pane = dijit.byId(tabName);
    if (pane != null)
    {
        var tabButton = pane.controlButton;

        if (tabButton != null)
        {
            if (dirty)
            {
                tabButton.set('class', tabButton.get('class') + ' unsavedTab');
                var currentLabel = tabButton.get('label')
                if (currentLabel.indexOf('*') != 0)
                    tabButton.set('label', '* ' + currentLabel);
            }
            else
            {
                tabButton.set('class', tabButton.get('class').replace(/unsavedTab/g, ''));
                var currentLabel = tabButton.get('label')
                if (currentLabel.indexOf('*') == 0)
                    tabButton.set('label', currentLabel.substr(2));
            }
        }
    }
}



/**
 * Checks if the specified tab is closable.
 * @param tabName The unique name of the tab to check.
 * @return {boolean} True if the tab can be closed, false otherwise.
 */
WinManager.tabs.isTabClosable = function(tabName)
{
    var tabPane = dijit.byId(tabName);
    if (tabPane != null)
    {
        return tabPane.get('closable');
    }
    return false;
}


/**
 * Closes the specified tab.
 * @param tabName The unique name of the tab to close.
 */
WinManager.tabs.closeTab = function(tabName)
{
    var pane = dijit.byId(tabName);
    if (pane != null)
    {
        WinManager.tabs.dojoTC.closeChild(pane);
    }

    if (WinManager.tabs.dojoTC.getChildren().length == 0)
    {
        WinManager.tabs.dojoTC.domNode.style.visibility = 'hidden';
    }
}

/**
 * Gets the unique tab name for the specified wmWindow object.
 * @param wmwin The wmWindow object to get the unique tab name for.
 * @return The tab name to use with other tabs functions, or null if not appropriate.
 */
WinManager.tabs.getTabName = function(wmWin)
{
    if (wmWin.strWinMode == 'tab')
    {
        return WinManager.name + wmWin.strWinName + wmWin.suffix;
    }
    return null;
}


/**
 * Should be called when a new tab is selected to perform any processing
 * needed because of the tab switch.
 * @param newWmWin The wmWindow object for the newly selected tab
 */
WinManager.tabs.handleTabChange = function(newWmWin)
{
    WinManager.currentTab = newWmWin;

    //check if close applies to the current tab
    if (WinManager.tabs.isTabClosable(WinManager.tabs.getTabName(newWmWin)))
        WinManager.setMenuOperationEnabledSetting('close_tab', true);
    else
        WinManager.setMenuOperationEnabledSetting('close_tab', false);

    WinManager.updateDisplayedMenuOptions(); //update menu for new tab

    //update status message display (in simple mode, only sticky message will be reshown)
    WinManager.status.updateDisplay(true);

    //reset the scroll offsets on any scrollable containers
    if (WinManager.currentTab.scrollableContainers)
    {
        for (var i = 0; i < WinManager.currentTab.scrollableContainers.length; ++i)
        {
            var c = WinManager.currentTab.scrollableContainers[i];
            var container;
            if (c.type == 'id')
                container = WinManager.currentTab.objWin.document.getElementById(c.value);
            else if (c.type == 'script_fragment')
            {
                with (WinManager.currentTab.objWin)
                {
                    container = eval(c.value);
                }
            }
            if (container)
            {
                container.scrollTop = c.scrollTop;
                container.scrollLeft = c.scrollLeft;
            }
        }
    }

    //check if there are any functions defined to run on focus
    if (newWmWin.runOnFocus)
    {
        for (var i = 0; i < newWmWin.runOnFocus.length; ++i)
        {
            newWmWin.runOnFocus[i]();
        }
        newWmWin.runOnFocus = null;
    }

    newWmWin.objWin.focus();

    //handle tabs that have not yet been loaded in.
    if ((typeof(newWmWin.loaded) != 'undefined') && !newWmWin.loaded)
    {
        WinManager.tabs.setTabBusyState(WinManager.tabs.getTabName(newWmWin), true);
        WinManager.handleRestoreWindow(newWmWin);
    }
}


/**
 * Updates the display of the given tab to inidcate whether it is busy or not
 * @param tabName The unique name of the tab to adjust.
 * @param busy boolean indicating whether this tab is busy or not.
 */
WinManager.tabs.setTabBusyState = function(tabName, busy)
{
    var pane = dijit.byId(tabName);
    if (pane != null)
    {
        var tabButton = pane.controlButton;

        if (tabButton != null)
        {
            if (busy)
            {
                tabButton.set('iconClass', tabButton.get('iconClass') + ' busyTab');
            }
            else
            {
                tabButton.set('iconClass', tabButton.get('iconClass').replace(/busyTab/g, ''));
            }
        }
    }
}

/**
 * Returns the current busy state of the given tab.
 * @param tabName The anme of the tab to get the busy state for.
 * @return boolean indicating whether this tab is busy or not.
 */
WinManager.tabs.getTabBusyState = function(tabName)
{
    var pane = dijit.byId(tabName);
    if (pane != null)
    {
        var tabButton = pane.controlButton;

        if (tabButton != null)
        {
            if (tabButton.get('iconClass').indexOf('busyTab') != -1)
                return true;
        }
    }
    return false;
}


/**
 * Returns details of all the tabs currently open.
 * @return an XML formatted string detailing the
 */
WinManager.tabs.getCurrentStatus = function()
{
    var tabs = WinManager.tabs.dojoTC.tablist.getChildren();

    var currentTabName = WinManager.tabs.getTabName(WinManager.currentTab);

    var retString = '<tabs>';
    for (var i = 0; i < tabs.length; ++i)
    {
        var tw = dijit.byId(tabs[i].id.substring(WinManager.tabs.dojoTC.tablist.id.length + 1));
        var tabName = tw.get('id');
        var tabType = tw.get('tabType');

        var frame = dojo.byId(tabName + '_iframe');
        var winIndex = WinManager.getWindow(frame.contentWindow)
        if (winIndex != -1)
        {
            var wmWin = WinManager.arrWindows[winIndex];

            retString += '<tab name="' + wmWin.strWinName + '" type="' + tabType + '"';

            if (tabName == currentTabName)
                retString += ' current="true"';

            retString += '>';



            for (var j = 0; j < wmWin.arrWinDetails.length; ++j)
            {
                retString += '<detail>' + wmWin.arrWinDetails[j] + '</detail>';
            }
        }



        retString += '</tab>';
    }

    retString += '</tabs>';

    return retString;
}

/**
 * Handles loading in a window that has been restored, but its contents not yet loaded.
 * @param newWmWin the wmwinodw object for the window to restore.
 */
WinManager.handleRestoreWindow = function(newWmWin)
{
    var openSuccess = false;
    switch (WinManager.getWindowTypeString(newWmWin))
    {
        case 'RuleMaker'   : openSuccess = WinManager.navigation.openRules(newWmWin.arrWinDetails[2], newWmWin.arrWinDetails[3]);
                             break;
        case 'FMPageDesign': openSuccess = WinManager.navigation.openPageDesign(newWmWin.arrWinDetails[3]);
                             break;
        case 'PagePreview' : openSuccess = WinManager.navigation.openPagePreview(newWmWin.arrWinDetails[2]);
                             break;
        case 'XDE'         : WinManager.opHandler.showXDEProjectScreen();
                             openSuccess = true;
                             break;
        case 'XSV'         : if (newWmWin.arrWinDetails[2] == 'DocumentEdit')
                             {
                                 openSuccess = WinManager.navigation.openXStoreDocument('blueprints', newWmWin.arrWinDetails[3], newWmWin.arrWinDetails[4]);
                             }
                             break;
        case 'DRV'         : if (newWmWin.arrWinDetails[2] == 'DocumentEdit')
                             {
                                 openSuccess = WinManager.navigation.openNonXStoreDocument(newWmWin.arrWinDetails[3]);
                             }
                             break;
        case 'TestDashboard': WinManager.opHandler.showDashboard();
                             openSuccess = true;
                             break;
        case 'Runtime'     :
        default            :
    }

    if (!openSuccess)
    {
        WinManager.alert({strMsg: WinManager.message.get('winmanager.tabs.restoreErrorMsg'), strTitle: WinManager.message.get('winmanager.tabs.restoreErrorTitle')});
        if (newWmWin.strWinMode == 'tab')
            WinManager.tabs.setTabBusyState(WinManager.tabs.getTabName(newWmWin), false);
    }

    newWmWin.loaded = true;

}


/**
 * -------------------------------------------------------------------------------------
 * Start of code relating to the status bar
 */



WinManager.status = {
    displayMode: 'simple',  //'simple' or 'advanced'
    maxNumMessages: 20      //the maximum number of messages that can be stored for each window
};

/**
 * Initialises the status message display.
 */
WinManager.status.initDisplay = function()
{
    var container = document.getElementById('statusbar');
    WinManager.destroyDojoWidgets(container);
    container.innerHTML = '';

    //simple mode HTML
    container.innerHTML = '<div id="WinManagerStatusSimple" class="WinManagerStatusSimple"><div id="WinManagerStatusSimpleMsg" class="WinManagerStatusSimpleMsg"></div>'
                            + '<a href="#" id="WinManagerStatusToggle" onclick="WinManager.status.changeDisplayMode(); return false;"><span class=""></span></a>'
                            + '<span id="WinManagerStatusIcon" class=""></span>'
                            + '</div>';

    //advanced mode HTML
    container.innerHTML += '<div id="WinManagerStatusAdvanced" class="claro"><div id="WinManagerStatusAdvancedContent"></div></div>';

    WinManager.status.changeDisplayMode('simple');
}

/**
 * Called to switch between simple and advanced display modes
 * for the status messages.
 * @param newMode either 'simple' or 'advanced'
 */
WinManager.status.changeDisplayMode = function(newMode)
{
    dojo.removeClass('statusbar', WinManager.status.displayMode);

    if (typeof(newMode) == 'undefined')
        newMode = (WinManager.status.displayMode == 'simple') ? 'advanced' : 'simple';

    WinManager.status.displayMode = newMode;

    dojo.addClass('statusbar', WinManager.status.displayMode);

    if (newMode == 'simple')
    {
        hideComponent(document.getElementById('WinManagerStatusAdvanced'), false);
        showComponent(document.getElementById('WinManagerStatusSimpleMsg'), false);
        //document.getElementById('WinManagerStatusToggle').firstChild.innerHTML = 'Expand';
        document.getElementById('WinManagerStatusToggle').title = 'Expand Detailed Status Information';
        dojo.addClass('WinManagerStatusToggle', 'expandStatus');
        dojo.removeClass('WinManagerStatusToggle', 'collapseStatus');
    }
    else
    {
        showComponent(document.getElementById('WinManagerStatusAdvanced'), false);
        hideComponent(document.getElementById('WinManagerStatusSimpleMsg'), false);
        //document.getElementById('WinManagerStatusToggle').firstChild.innerHTML = 'Collapse';
        document.getElementById('WinManagerStatusToggle').title = 'Collapse Detailed Status Information';
        dojo.addClass('WinManagerStatusToggle', 'collapseStatus');
        dojo.removeClass('WinManagerStatusToggle', 'expandStatus');
    }

    WinManager.status.updateDisplay();

    WinManager.tabs.resize();
}


/**
 * Generic function for showing status messages
 *
 * @param options A config object that supports the following options:
 *
 *        msg A string containing the message to display.  This can contain HTML markup.
 *        sticky (Optional) boolean flag indicating if this message should be set as the 'sticky' message
 *              If set, then this message will be reshown when the currently displayed message is hidden using
 *              the hideStatusMessage() method.  Only one message can be sticky, so setting this overrides
 *              any current sticky message
 *        autohide (Optional) boolean flag indicating if this message should be automatically hidden after a period
 *              of time.  This should not be used with the sticky option.  If there is already a sticky message, then
 *              it will be reshown when this one is hidden.
 *        detail (Optional) An HTML string to provide additional message details.  These will only be displayed when
 *              the user clicks a 'Details' link.
 *        level (Optional) The level for this message - 'info', 'error', 'warning', 'in-progress'.  Defaults to info
 *        type (Optional) String specifying the a type value for this message. (eg may use 'publish' for all messages related to publication.)
 *        highlight (Optional) boolean indicating whether we should draw attention to this new message.  Defaults to true for error level messages.
 *        objWin (Optional) The window object this message applies to.  If not provided the message applies to all windows.
 */
WinManager.status.showMessage = function(options)
{
    /*if (!options.objWin)
        options.objWin = window;*/
    if (!options.level)
        options.level = 'info';

    if (typeof(options.highlight) == 'undefined')
        options.highlight = (options.level == 'error');

    //add a timestamp to the message
    options.timestamp = new Date();

    var msgList;

    var winIndex = WinManager.getWindow(options.objWin)
    if (winIndex != -1)
    {
        //message is for a specific window
        var wmWin = WinManager.arrWindows[winIndex];
        if (!wmWin.statusMessages)
            wmWin.statusMessages = new Array();

        msgList = wmWin.statusMessages;
    }
    else
    {
        //message is global
        if (!WinManager.globalStatusMessages)
            WinManager.globalStatusMessages = new Array();

        msgList = WinManager.globalStatusMessages;
    }

    //add the new mesage to the front
    msgList.unshift(options);


    //if we now have too many stored messages, reomve the last one.
    if (msgList.length > WinManager.status.maxNumMessages)
        msgList.pop();

    //update the visible display
    WinManager.status.updateDisplay(false, options.highlight, options.objWin);

    if (options.autohide)
    {
        var tempWin = options.objWin;
        window.setTimeout(function() {
            var msgToShow = WinManager.status.getLatestMessageToShow(false, WinManager.arrWindows[WinManager.getWindow(tempWin)]);

            options.autohidden = true;
            if (msgToShow == options)
            {
                WinManager.status.updateDisplay(true, false, tempWin);
            }
            tempWin = null;
        }, 5000);
    }

    //dont want to maintain the reference to the window object
    delete options.objWin;
}

/**
 * Removes currently displayed status messages.
 * By default this will just remove the most recent message, but by providing additional options
 * you can be more specific about what gets removed.
 * @param options (Optional) A config object which supports the following properties:
 *      objWin (Optional) The window object to clear the message from.  If not provided, global messages will be processed.
 *      type (Optional) If provided, then only messages of the given type will be removed
 *      level (Optional) If provided, then only messages of the given level will be removed
 *      sticky (Optional) If specified and true only sticky messages will be removed, if false only non sticky messages will be removed
 *                   If not specified all messages (sticky or otherwise) can be removed.
 *      removeAll (Optional) If true then all matching messages will be removed, otherwise only the most recent match. (defaults to false)
 */
WinManager.status.removeMessage = function(options)
{
    if (typeof(options) == 'undefined')
        options = {};

    var msgList;
    if ((typeof(options.objWin) == 'undefined') || (options.objWin == null) || (WinManager.getWindow(options.objWin) == -1))
    {
        //message is global
        if (!WinManager.globalStatusMessages)
            WinManager.globalStatusMessages = new Array();

        msgList = WinManager.globalStatusMessages;
    }
    else
    {
        //message is for a specific window
        var wmWin = WinManager.arrWindows[WinManager.getWindow(options.objWin)];
        if (!wmWin.statusMessages)
            wmWin.statusMessages = new Array();

        msgList = wmWin.statusMessages;
    }

    if (msgList.length == 0)
        return;

    //work out which messages match the criteria
    var toRemove = new Array();
    for (var i = 0; i < msgList.length; ++i)
    {
        if (typeof(options.sticky) != 'undefined')
        {
            if (options.sticky && !msgList[i].sticky)
                continue;
            else if (!options.sticky && msgList[i].sticky)
                continue;
        }

        if (options.level && (msgList[i].level != options.level))
            continue

        if (options.type && (msgList[i].type != options.type))
            continue

        toRemove.push(i);
    }

    if (toRemove.length == 0)
        return;

    //work out whether to remove all matches or just the first one
    if (options.removeAll)
    {
        offset = 0;
        for (var i = 0; i < toRemove.length; ++i)
        {
            msgList.splice(toRemove[i] - offset, 1);
            ++offset;
        }
    }
    else
    {
        msgList.splice(toRemove[0], 1);
    }

    //update the display
    WinManager.status.updateDisplay(true, false, options.objWin);
}

/**
 * updates the display of the status bar to show the latest messages
 * @param stickyOnly If true, then in simple mode a message will only be displayed if it is sticky
 * @param highlight If true the latest message will be highlighted to alert the user to it
 * @param objWin Optional window object for which the display should be updated
 */
WinManager.status.updateDisplay = function(stickyOnly, highlight, objWin)
{
    var wmWin = null;
    var winIsDialog = false;
    if (objWin)
    {
        var winIndex = WinManager.getWindow(objWin);
        if (winIndex != -1)
        {
            wmWin = WinManager.arrWindows[winIndex]
            if ((wmWin.strWinMode == 'popup') || (wmWin.strWinMode == 'dialog'))
            {
                WinManager.status.updateDisplaySimple(stickyOnly, highlight, wmWin);
                winIsDialog = true;
            }
        }
    }

    if (!winIsDialog)
    {
        if (WinManager.status.displayMode == 'simple')
        {
            WinManager.status.updateDisplaySimple(stickyOnly, highlight);
        }
        else
        {
            WinManager.status.updateDisplayAdvanced(stickyOnly, highlight);
        }
    }
    else if (WinManager.status.displayMode == 'advanced')
    {
        //if we are updating a dialog message, and the main status bar is in advanced mode
        //then update this as well, just without any highlighting etc
        WinManager.status.updateDisplayAdvanced();
    }

    var dj = dojo;
    var context = 'statusbar';
    if (winIsDialog)
    {
        if (wmWin.strWinMode == 'popup')
        {
            dj = objWin.dojo;
        }
        else if (wmWin.strWinMode == 'dialog')
        {
            dj = objWin.parent.dojo;
            context = 'statusbar-dialog';
        }
    }

    dj.query('a.status-detail', context).forEach(function(item) {
            WinManager.attachEvent(item, 'onmouseover', WinManager.status.detail.show);
            WinManager.attachEvent(item, 'onmouseout', WinManager.status.detail.hide);
    });

}

/**
 * Updates the simple (single line) mode of status message display.
 * @param wmWin (Optional) If provided, this should be the WinManager window object
 *          for a popup or dialog window to update the status message in, instead of the main status bar.
 */
WinManager.status.updateDisplaySimple = function(stickyOnly, highlight, wmWin)
{
    var toShow = WinManager.status.getLatestMessageToShow(stickyOnly, wmWin);

    var html = '';

    var doc = document;
    var containerId = 'WinManagerStatusSimpleMsg';
    if (wmWin)
    {
        if (wmWin.strWinMode == 'popup')
        {
            doc = wmWin.objWin.document;
        }
        else if (wmWin.strWinMode == 'dialog')
        {
            doc = wmWin.objWin.parent.document;
            containerId = 'WinManagerDialogStatusSimpleMsg';
        }
    }

    var msgContainer = doc.getElementById(containerId);

    if (toShow != null)
    {
        //make sure the message fits in the available space.
        //If not then we move the extra content into the detail popup
        var availableWidth = msgContainer.parentNode.offsetWidth - 50;
        if ((typeof(toShow.detail) == 'string') && (toShow.detail != ''))
            availableWidth -= 40;

        var dispString = toShow.msg;
        var truncatedMsg = '';
        if ((availableWidth > 0) && (getStringVisualLength(dispString, 'statusMsgText ' + toShow.level) > availableWidth))
        {
            if (!((typeof(toShow.detail) == 'string') && (toShow.detail != '')))
                availableWidth -= 40;

            dispString = trimStringToPixelLength(dispString, availableWidth, false, 'statusMsgText ' + toShow.level);
            truncatedMsg = toShow.msg.substr(dispString.length - 3);
        }

        html += '<span class="' + toShow.level + '">' + dispString + '</span>';

        if ((truncatedMsg != '') || ((typeof(toShow.detail) == 'string') && (toShow.detail != '')))
        {
            html += '<a href="#" class="status-detail" data-hyf-messageid="' + toShow.id + '"';
            if (truncatedMsg != '')
            {
                html += ' data-hyf-msgremainder="'+truncatedMsg.replace(/"/g, '&quot;')+'"';
            }
            html += '>Details</a>';
        }

        html += '&nbsp;';

    }

    msgContainer.innerHTML = html;
    if ((html != '') && (highlight))
        drawAttentionToComponent(msgContainer);
}

/**
 * Returns the message object that should be shown when rendering the simple mode display.
 */
WinManager.status.getLatestMessageToShow = function(stickyOnly, wmWin)
{
    var latestGlobal, latestTab, toShow;
    if (!wmWin && WinManager.globalStatusMessages)
    {
        for (var i = 0; i < WinManager.globalStatusMessages.length; ++i)
        {
            if ((!stickyOnly) || (WinManager.globalStatusMessages[i].sticky))
            {
                //ignore auto hidden messages in simple mode
                if (!WinManager.globalStatusMessages[i].autohidden)
                {
                    latestGlobal = WinManager.globalStatusMessages[i];
                    latestGlobal.id = 'global,' + i;
                    break;
                }
            }
        }
    }

    var tabWmWin = (wmWin) ? wmWin : WinManager.currentTab;

    if (tabWmWin && tabWmWin.statusMessages)
    {
        var tabNum;
        for (var i = 0; i < WinManager.arrWindows.length; ++i)
        {
            if (WinManager.arrWindows[i] === tabWmWin)
            {
                tabNum = i;
                break;
            }
        }

        for (var i = 0; i < tabWmWin.statusMessages.length; ++i)
        {
            if ((!stickyOnly) || (tabWmWin.statusMessages[i].sticky))
            {
                if (!tabWmWin.statusMessages[i].autohidden)
                {
                    latestTab = tabWmWin.statusMessages[i];
                    latestTab.id = 'tab,' + tabNum + ',' + i;
                    break;
                }
            }
        }
    }

    if (latestGlobal == null)
        toShow = latestTab;
    else if (latestTab == null)
        toShow = latestGlobal;
    else if (latestTab.timestamp.getTime() > latestGlobal.timestamp.getTime())
        toShow = latestTab;
    else
        toShow = latestGlobal

    return toShow;
}

WinManager.status.updateDisplayAdvanced = function(stickyOnly, highlight)
{
    var mergedMessages = new Array();
    //add global messages
    if (WinManager.globalStatusMessages)
    {
        for (var i = 0; i < WinManager.globalStatusMessages.length; ++i)
        {
            WinManager.globalStatusMessages[i].id = 'global,' + i;
            mergedMessages.push(WinManager.globalStatusMessages[i]);
        }
    }

    //add current tab messages
    if (WinManager.currentTab && WinManager.currentTab.statusMessages)
    {
        var tabNum;
        for (var i = 0; i < WinManager.arrWindows.length; ++i)
        {
            if (WinManager.arrWindows[i] === WinManager.currentTab)
            {
                tabNum = i;
                break;
            }
        }

        for (var i = 0; i < WinManager.currentTab.statusMessages.length; ++i)
        {
            WinManager.currentTab.statusMessages[i].id = 'tab,' + tabNum + ',' + i;
            mergedMessages.push(WinManager.currentTab.statusMessages[i]);
        }
    }

    //create 'current tab' display content
    var currentTabContent = WinManager.status.getAdvancedMessageList(mergedMessages, false, 'current');


    //add all other tab messages
    for (var i = 0; i < WinManager.arrWindows.length; ++i)
    {
        if ((WinManager.arrWindows[i] !== WinManager.currentTab) && (WinManager.arrWindows[i].statusMessages))
        {
            for (var j = 0; j < WinManager.arrWindows[i].statusMessages.length; ++j)
            {
                WinManager.arrWindows[i].statusMessages[j].id = 'tab,' + i + ',' + j;
                mergedMessages.push(WinManager.arrWindows[i].statusMessages[j]);
            }
        }

    }

    //create 'all tabs' display content
    var allTabContent = WinManager.status.getAdvancedMessageList(mergedMessages, true, 'all');


    //create the display
    if (dijit.byId('StatusAdvancedCurrentTab'))
    {
        //update the current contents
        dijit.byId('StatusAdvancedCurrentTab').set('content', currentTabContent);
        dijit.byId('StatusAdvancedAllTabs').set('content', allTabContent);
    }
    else
    {
        //var cp = getComponentPosition(dojo.byId('WinManagerStatusAdvanced'));

        //create the tab controls
        var tc = new dijit.layout.TabContainer({
                //style: 'height: 100%; width: ' + cp.width + 'px;',
                style: 'height: 100%; width: 100%',
                persist: false,
                tabStrip: true,
                tabPosition: 'bottom'
            }, 'WinManagerStatusAdvancedContent');

        tc.addChild(new dijit.layout.ContentPane({
                 id: "StatusAdvancedCurrentTab",
                 title: "This Tab",
                 content: currentTabContent
            }));

        tc.addChild(new dijit.layout.ContentPane({
                 id: "StatusAdvancedAllTabs",
                 title: "All Tabs",
                 content: allTabContent
            }));

        tc.startup();

        window.setTimeout(function() { tc.resize(); }, 5);
    }

    if (highlight)
    {
        //find the most recent message
        var mr;
        for (var i = 0; i < mergedMessages.length; ++i)
        {
            if ((mr == null) || (mr.timestamp.getTime() < mergedMessages[i].timestamp.getTime()))
                mr = mergedMessages[i];

            if (!mergedMessages.sticky)
                break;
        }

        var highlightId;

        if (dijit.byId('StatusAdvancedAllTabs').selected)
        {
            highlightId = 'all' + mr.id.replace(/,/g, '_');
        }
        else
        {
            //check if the message is on the current tab tab, and if not first switch to all
            if ((mr.id.indexOf('global') == 0) || (WinManager.arrWindows[Number(mr.id.split(',')[1])] === WinManager.currentTab))
            {
                highlightId = 'current' + mr.id.replace(/,/g, '_');
            }
            else
            {
                dijit.byId('WinManagerStatusAdvancedContent').selectChild(dijit.byId('StatusAdvancedAllTabs'));
                highlightId = 'all' + mr.id.replace(/,/g, '_');
            }
        }

        drawAttentionToComponent(document.getElementById(highlightId));

    }
}

/*WinManager.status.handleBrowserResize = function()
{
    var tc = dijit.byId('WinManagerStatusAdvancedContent');
    if (tc)
    {
        //resize the tabs really small initially so we can then work out how much space is available
        tc.resize({w: 10});
        tc.resize({w: getComponentPosition(dojo.byId('WinManagerStatusAdvancedContentContainer')).width});
    }
}
WinManager.attachEvent(window, 'onresize', WinManager.status.handleBrowserResize);*/

/**
 * Returns the HTML for rendering the given list of messages.
 * @param messages The array of messages to render
 */
WinManager.status.getAdvancedMessageList = function(messages, showTabName, id)
{
    messages.sort(function(a, b){
            if (a.sticky && !b.sticky)
                return -1;
            else if (b.sticky && !a.sticky)
                return 1;
            else
                return b.timestamp.getTime() - a.timestamp.getTime();
    });

    var htmlStr = '<table id="'+id+'" border="0" cellspacing="0" cellpadding="0">';

    for (var i = 0; i < messages.length; ++i)
    {
        htmlStr += '<tr';

        if (messages[i].sticky)
            htmlStr += ' class="sticky"';

        htmlStr += '>';

        //time
        htmlStr += '<td class="timestamp">';
        htmlStr += messages[i].timestamp.toLocaleTimeString();
        htmlStr += '</td>';

        //message
        htmlStr += '<td class="msg" id="' + id + messages[i].id.replace(/,/g, '_') + '"><span class="' + messages[i].level + '">' + messages[i].msg + '</span>';

        if ((typeof(messages[i].detail) == 'string') && (messages[i].detail != ''))
        {
            htmlStr += '<a href="#" class="status-detail" data-hyf-messageid="' + messages[i].id + '">Details</a>';
        }
        htmlStr += '</td>';

        //tab name
        if (showTabName)
        {
            htmlStr += '<td class="tabName">';
            var idDetails = messages[i].id.split(',');

            if (idDetails[0] == 'tab')
                htmlStr += WinManager.getDisplayName(WinManager.arrWindows[Number(idDetails[1])]);

            htmlStr += '</td>';
        }

        htmlStr += '</tr>';
    }

    htmlStr += '</table>';
    return htmlStr;
}


/**
 * Initialises the display of the status message bar in a popup window.
 * These currently only get the simple display.
 * @param objWin The window object for the popup to show the bar in
 */
WinManager.status.initDisplayInPopup = function(objWin)
{
    WinManager.createPopupWinManagerContent(objWin);
    var container = objWin.document.getElementById('statusbar');

    //simple mode HTML
    container.innerHTML = '<div id="WinManagerStatusSimple" class="WinManagerStatusSimple"><div id="WinManagerStatusSimpleMsg" class="WinManagerStatusSimpleMsg"></div>'
                            + '</div>';

    WinManager.status.updateDisplay(false, false, objWin);

    //add bottom padding to the body to make space for the status row
    var currentpb = parseInt(objWin.document.body.style.paddingBottom)
    if (isNaN(currentpb))
        currentpb = 0;
    objWin.document.body.style.paddingBottom = (currentpb + container.offsetHeight) + 'px';
}

/**
 * Initialises the display of the status message bar in an in-page dialog
 * These currently only get the simple display.
 * @param objWin The window object that the dialog is being created in
 */
WinManager.status.initDisplayInDialog = function(objWin)
{
    var container = objWin.document.getElementById('statusbar-dialog');

    if (container == null)
    {
        container = objWin.document.createElement('div');
        container.id = 'statusbar-dialog';
        container.className = 'statusbar';
        var dialog = objWin.document.getElementById('winManagerMsgDiv');
        dialog.appendChild(container);
    }

    //simple mode HTML
    container.innerHTML = '<div id="WinManagerDialogStatusSimple" class="WinManagerStatusSimple"><div id="WinManagerDialogStatusSimpleMsg" class="WinManagerStatusSimpleMsg"></div>'
                            + '</div>';

    //WinManager.status.updateDisplay(false, false, objWin);
}


WinManager.createPopupWinManagerContent = function(objWin)
{
    var container = objWin.document.getElementById('WinManagerPopupContent');
    if (container == null)
    {
        var winmanagerDiv = objWin.document.createElement('div');
        winmanagerDiv.id = 'WinManagerPopupContent';
        objWin.document.body.appendChild(winmanagerDiv);
        winmanagerDiv.innerHTML = '<div id="popupBtns"></div><div id="statusbar" class="statusbar"></div>';
    }
}






/**
 * container for functions relating to showing and hiding the details for a status message, eg from a gen operation. */
WinManager.status.detail = {
    hideTimeout: false,
    msgDoc: null //document to display the detail message on
};
/**
 * mouse moved off the detail button.
 */
WinManager.status.detail.hide = function()
{
    if (WinManager.status.detail.hideTimeout != null)
    {
        clearTimeout(WinManager.status.detail.hideTimeout);
    }

    WinManager.status.detail.hideTimeout = setTimeout(WinManager.status.detail.hideActual, 500);
}

WinManager.status.detail.hideActual = function()
{
    if (WinManager.status.detail.msgDoc.getElementById('WinManagerStatusDetail'))
    {
        dojo.fadeOut({node: WinManager.status.detail.msgDoc.getElementById('WinManagerStatusDetail'), onEnd: function(){WinManager.status.detail.msgDoc.getElementById('WinManagerStatusDetail').style.display = 'none';}}).play();
    }
    if (WinManager.status.detail.msgDoc.getElementById('WinManagerStatusDetailFrame'))
    {
        var dtlFrame = WinManager.status.detail.msgDoc.getElementById('WinManagerStatusDetailFrame')
        dtlFrame.parentNode.removeChild(dtlFrame);
    }
}
/**
 * mouse moved over the detail button
 */
WinManager.status.detail.show = function(e)
{
    //stop any hide timeouts
    WinManager.status.detail.maintain();

    var evt = (e) ? e : window.event;

    var sourceComponent = (evt.target) ? evt.target : evt.srcElement;
    if ((sourceComponent != null) && (sourceComponent.nodeType == 3)) // defeat Safari bug
        sourceComponent = sourceComponent.parentNode;

    WinManager.status.detail.msgDoc = sourceComponent.ownerDocument;

    var msgId = sourceComponent.getAttribute('data-hyf-messageid')

    if (msgId != null)
    {
        var detailBox = WinManager.status.detail.msgDoc.getElementById('WinManagerStatusDetail');
        if (detailBox == null)
        {
            detailBox = WinManager.status.detail.msgDoc.createElement('div');
            detailBox.id = 'WinManagerStatusDetail';
            detailBox.onmouseover = WinManager.status.detail.maintain;
            detailBox.onmouseout = WinManager.status.detail.hide;
            WinManager.status.detail.msgDoc.body.appendChild(detailBox);
        }

        var idDetails = msgId.split(',');
        var selectedMsg;
        if (idDetails[0] == 'global')
        {
            selectedMsg = WinManager.globalStatusMessages[Number(idDetails[1])];
        }
        else
        {
            selectedMsg = WinManager.arrWindows[Number(idDetails[1])].statusMessages[Number(idDetails[2])];
        }

        var detailMsg = '';
        if (sourceComponent.getAttribute('data-hyf-msgremainder') != null)
            detailMsg += '...' + sourceComponent.getAttribute('data-hyf-msgremainder');

        if (selectedMsg && selectedMsg.detail && selectedMsg.detail != '')
        {
            if (detailMsg != '')
                 detailMsg += '<br/>'

            detailMsg += selectedMsg.detail;
        }

        if (detailMsg != '')
        {
            if (detailBox.style.display == 'none')
            {
                detailBox.style.display = 'block';
                if (dojo.isIE < 9)
                {
                    detailBox.style.opacity = 1;
                    detailBox.style.filter = '';
                }
                else
                {
                    detailBox.style.opacity = 0;
                    dojo.fadeIn({node: WinManager.status.detail.msgDoc.getElementById('WinManagerStatusDetail')}).play();
                }
            }
            detailBox.innerHTML = detailMsg;
            detailBox.style.height = 'auto';
            detailBox.style.width = 'auto';

            var sourceTop = getTopPosition(sourceComponent, true)

            //if we are on a status bar for a dialog window, then restrict the detail size to the dialog area, otherwise
            //we use the full window size.
            var detailBoundary;

            var isDialogBar = false;
            var temp = sourceComponent;
            while (!dojo.hasClass(temp, 'statusbar')) { temp = temp.parentNode; }
            if (temp && (temp.id == 'statusbar-dialog'))
                isDialogBar = true;

            if (isDialogBar)
            {
                var dialogBox = WinManager.status.detail.msgDoc.getElementById('winManagerMsgContainer');
                var bp = getComponentPosition(dialogBox);
                detailBoundary = {top : bp.y, right : bp.x + bp.width};
            }
            else
                detailBoundary = {top: 0, right : (WinManager.status.detail.msgDoc.documentElement) ? WinManager.status.detail.msgDoc.documentElement.clientWidth : WinManager.status.detail.msgDoc.body.clientWidth};

            var detailLeft = getLeftPosition(sourceComponent.parentNode);

            //check if it is going off the right of the screen
            if ((detailLeft + detailBox.offsetWidth) > detailBoundary.right)
            {
                var detailWidth = detailBoundary.right - 5 - detailLeft - parseInt(getCurrentStyle(detailBox, 'padding-left')) - parseInt(getCurrentStyle(detailBox, 'padding-right'))
                detailBox.style.width = detailWidth + 'px';
            }

            var detailTop = (sourceTop - detailBox.offsetHeight);

            //check if the detail window is going off the top of the screen
            if (detailTop < detailBoundary.top)
            {
                detailTop = detailBoundary.top + 5;
                var detailHeight = sourceTop - (detailBoundary.top + 5) - parseInt(getCurrentStyle(detailBox, 'padding-top')) - parseInt(getCurrentStyle(detailBox, 'padding-bottom'));
                detailBox.style.height = detailHeight + 'px';
            }

            detailBox.style.top = detailTop + 'px';
            detailBox.style.left = detailLeft + 'px';




            //if we are on older IE versions, then some content (most notably the app map diagram)
            //can appear over the top of this box so we need to put an iframe below the content
            if (dojo.isIE < 9)
            {
                var detailFrame = WinManager.status.detail.msgDoc.getElementById('WinManagerStatusDetailFrame');
                if (detailFrame == null)
                {
                    detailFrame = WinManager.status.detail.msgDoc.createElement('iframe');
                    detailFrame.id = 'WinManagerStatusDetailFrame';
                    detailFrame.src = 'about:blank';
                    detailFrame.frameBorder = 0;
                    detailFrame.setAttribute('frameBorder', '0');
                }

                detailFrame.style.top = detailBox.style.top;
                detailFrame.style.left = detailBox.style.left;
                detailFrame.style.width = detailBox.offsetWidth;
                detailFrame.style.height = detailBox.offsetHeight;

                WinManager.status.detail.msgDoc.body.insertBefore(detailFrame, detailBox);
            }
        }
    }
}

/**
 * mouse clicked on the detail button to lock it in place.
 */
WinManager.status.detail.maintain = function()
{
    if (WinManager.status.detail.hideTimeout != null)
    {
        clearTimeout(WinManager.status.detail.hideTimeout);
        WinManager.status.detail.hideTimeout = null;
    }
}














/**
 * This package contains a generic mechanism for handling keyboard shortcuts.
 * The containing page can use the attach and detach methods to setup the requried shortcuts.
 */
WinManager.keys = {
    managed: new Array(),
    eventHandle: null
};

WinManager.attachEvent(window, "onload", function(){
        WinManager.keys.eventHandle = WinManager.attachEvent(document, 'onkeydown', WinManager.keys.processKeyEvent);
});

/**
 * Attach the provided function to be called when the given key is pressed.
 * @param key The letter or keyCode of the key to detect.
 * @param func A reference tot he fucntion to call when the key is pressed.
 * @param ctrl (Optional) Boolean indicating whether the ctrl key needs to also be pressed.
 * @param alt (Optional) Boolean indicating whether the alt key needs to also be pressed.
 * @param shift (Optional) Boolean indicating whether the shift key needs to also be pressed.
 * @param ignoreInControls (Optional) Boolean indicating whether the key event should be ignored if triggered
 *                  on an editable control (eg text box, textarea etc). Default false.
 * @param eventType (Optional) String indicating which type of key event this is for.  Currently supports 'keydown' or 'keyup'
 *                  Defaults to keydown if not provided
 * @param objWin The window object that this key should be bound on, or null to apply globally
 */
WinManager.keys.attach = function(key, func, ctrl, alt, shift, ignoreInControls, eventType, objWin)
{
    if (typeof(objWin) == 'undefined')
    {
        objWin = window;
    }

    if (typeof(ctrl) != 'boolean')
        ctrl = false;
    if (typeof(alt) != 'boolean')
        alt = false;
    if (typeof(shift) != 'boolean')
        shift = false;
    if (typeof(ignoreInControls) != 'boolean')
        ignoreInControls = false;
    if (typeof(eventType) != 'string')
        eventType = 'keydown';

    objWin.WinManager.keys.managed.push({key: key,
                  func: func,
                  ctrl: ctrl,
                  alt: alt,
                  shift: shift,
                  ignoreInControls: ignoreInControls,
                  eventType: eventType});
}

/**
 * Detach the provided function from being called when the given key is pressed.
 * @param key The letter or keyCode of the key to detect.
 * @param func A reference tot he fucntion to call when the key is pressed.
 * @param ctrl (Optional) Boolean indicating whether the ctrl key needs to also be pressed.
 * @param alt (Optional) Boolean indicating whether the alt key needs to also be pressed.
 * @param shift (Optional) Boolean indicating whether the shift key needs to also be pressed.
 * @param ignoreInControls (Optional) Boolean indicating whether the key event should be ignored if triggered
 *                  on an editable control (eg text box, textarea etc). Default false.
 * @param eventType (Optional) String indicating which type of key event this is for.  Currently supports 'keydown' or 'keyup'
 *                  Defaults to keydown if not provided
 * @param objWin The window object that this key should be bound on, or null for global
 */
WinManager.keys.detach = function(key, func, ctrl, alt, shift, ignoreInControls, eventType, objWin)
{
    if (typeof(objWin) == 'undefined')
    {
        objWin = window;
    }

    if (typeof(ctrl) != 'boolean')
        ctrl = false;
    if (typeof(alt) != 'boolean')
        alt = false;
    if (typeof(shift) != 'boolean')
        shift = false;
    if (typeof(ignoreInControls) != 'boolean')
        ignoreInControls = false;
    if (typeof(eventType) != 'string')
        eventType = 'keydown';

    for (var i = 0; i < objWin.WinManager.keys.managed.length; ++i)
    {
        var obj = objWin.WinManager.keys.managed[i];
        if (obj.key == key && obj.func == func && obj.ctrl == ctrl && obj.alt == alt && obj.shift == shift && obj.ignoreInControls == ignoreInControls && obj.eventType == eventType)
        {
            objWin.WinManager.keys.managed.splice(i, 1);
            break;
        }
    }
}


/**
 * This gets called for the key event, and is responsible for seeing if it matches
 * any of the keys being managed, and if so calling the appropriate functions.
 * @return false If the event has been processed, and so shouldnt continue further, true otherwise
 * @private
 */
WinManager.keys.processKeyEvent = function(e, objWin)
{
    var evt = (e) ? e : window.event;

    var code = evt.keyCode;
    var character = String.fromCharCode(code);

    //console.log('code: ', code, ' character: ', character, ' event: ', evt.type);

    var toCheck;
    if (typeof(objWin) == 'undefined')
    {
        //just global
        toCheck = WinManager.keys.managed;
    }
    else
    {

        //check if the source window is a popup.  If so it is not within the menu structure etc,
        //so only specific shortcuts for that page should be available
        var iWinIndex = WinManager.getWindow(objWin);
        if ((iWinIndex != -1) && (WinManager.arrWindows[iWinIndex].strWinMode == 'popup'))
        {
            //just page specific
            toCheck = objWin.WinManager.keys.managed
        }
        else
        {
            //page specific and global
            toCheck = objWin.WinManager.keys.managed.concat(WinManager.keys.managed);
        }
    }

    //console.log('to check: ', toCheck);

    var matched = false;

    for (var i = 0; i < toCheck.length; ++i)
    {
        var obj = toCheck[i];

        //console.log('checking ', obj);
        if (obj.eventType != evt.type)
            continue;

        if (obj.key == code || obj.key == character)
        {
            //console.log('key matches');
            if ((!obj.ctrl || evt.ctrlKey) && (!obj.alt || evt.altKey) && (!obj.shift || evt.shiftKey))
            {
                //console.log('modifiers match');
                //check if we should ignore events that came from an editable control
                if (obj.ignoreInControls)
                {
                    var sourceComponent = (evt.target) ? evt.target : evt.srcElement;
                    if ((sourceComponent != null) && (sourceComponent.nodeType == 3)) // defeat Safari bug
                        sourceComponent = sourceComponent.parentNode;

                    var name = sourceComponent.tagName.toLowerCase();

                    if (name == 'input' || name == 'textarea' || name == 'select' || (name == 'body' && sourceComponent.isContentEditable))
                        continue;

                    //also ignore if we currently have some text selected, as the most common use for this ignoreInControls
                    //option is ctrl-c etc where the user would actually want this to copy their selected text
                    //not the control/rule etc
                    var selectedText = '';
                    var textWin = (typeof(objWin) != 'undefined') ? objWin : window;
                    if (textWin.getSelection)
                        selectedText = textWin.getSelection();
                    else if ((textWin.document.selection) && (textWin.document.selection.type == 'Text'))
                        selectedText = textWin.document.selection.createRange().text

                    if (selectedText != null && selectedText != '')
                        continue;

                }

                //console.log('matched');

                matched = true;
                //we actually call the function in a timeout, as otherwise any alerts or confirms
                //in the fucntion could stop this from overridding the browser default functionality
                //for some reason. eg for ctrl-s the browser save dialog would come up in RM if there were
                //errors because of the confirm message shown before this change.
                WinManager.keys.callFunction(obj, evt)
            }
        }
    }

    if (matched)
    {
        WinManager.cancelPropagation(evt);
        WinManager.eventPreventDefault(evt);
        return false;
    }

    return true;
}

/**
 * Actually calls the function defined for the managed key combination with the given index.
 * This is called from the processKeyEvent method above where needed, and has been separated out
 * so that we get a copy of the index value so that in the timeout call we can still reference the
 * correct managed key details even though the processing above has continued through the loop
 * to check other key combinations.
 * @private
 */
WinManager.keys.callFunction = function(managedObj, evt)
{
    if (typeof(managedObj.func) == 'function')
    {
        window.setTimeout(function(){
                //console.log('calling function');
                managedObj.func(evt);
        }, 1);
    }
}


WinManager.tooltips = {};
/**
 * Called to attach any dynamic Tips from the Structure page for the current page.
 * The page id is the link to the tip structure file data used to then attach tips where appropriate.
 */
WinManager.tooltips.attachTipsToPage = function(pageId,win)
{
    if (!win)
        win = window;

    if ((typeof(pageId) == 'undefined') || (pageId == null))
    {
        //make sure we are using a managed window to get the page name from
        var pageIdWin = win;
        while (pageIdWin.WinManager && !pageIdWin.WinManager.managedWin && (pageIdWin != pageIdWin.parent))
        {
            pageIdWin = pageIdWin.parent
        }
        var winIndex = WinManager.getWindow(pageIdWin);

        if (winIndex != -1)
            pageId = WinManager.getWindowTypeString(WinManager.arrWindows[winIndex]);
    }

    return hyf.tooltips.attachTipsToPage(pageId, win);
}
/**
 * Called when the mouse moves onto the trigger container.
 * Finds the coordinates of the mouse, and then initialises the tooltip
 */
WinManager.tooltips.showTipMessage = function(e,immediate,win)
{
    if (!win)
        win = window;

    return hyf.tooltips.showTipMessage(e,immediate,win);
}
/**
 * Called when the mouse moves off of the trigger container.
 * Initalise the timeout to hide the tooltip
 */
WinManager.tooltips.hideTipMessage = function(immediate)
{
    return hyf.tooltips.hideTipMessage(immediate);
}

/**
 * Presents a simple Ok/Cancel-type message box requesting user confirmation.
 * @param objOptions {
 *       strMsg: [optional] Message describing the context of the confirmation request
 *       strTitle: [optional] Title for the confirmation dialogue
 *       strConfirm: [optional] Caption for the OK(Confirmation) button
 *       strCancel: [optional] Caption for the Canel button
 *       objConfirmHandler: [optional, but should be supplied] Handler function when the confirmation button is clicked
 *       objCancelHandler: [optional] Handler function when the cancel button is clicked
 *       objWin: [auto] Usually managed by the WinManager
 *   }
 */
WinManager.userConfirmed = function(objOptions)
{
    if (typeof(objOptions.objWin) == 'undefined')
        objOptions.objWin = window;

    if (!objOptions.strTitle || objOptions.strTitle == "")
        objOptions.strTitle = WinManager.message.get('winmanager.userconfirm.title');

    if (!objOptions.strMsg || objOptions.strMsg == "")
        objOptions.strMsg = WinManager.message.get('winmanager.userconfirm.msg');;

    if (!objOptions.strConfirm || objOptions.strConfirm == "")
        objOptions.strConfirm = WinManager.message.get('winmanager.buttons.ok');

    if (!objOptions.strCancel || objOptions.strCancel == "")
        objOptions.strCancel = WinManager.message.get('winmanager.buttons.cancel');

    WinManager.displayMessageBox({
            objWin: objOptions.objWin,
            content:objOptions.strMsg, title:objOptions.strTitle, height: 150, width: 450,
            buttons: [{caption: objOptions.strConfirm, reason: 'ok'}, {caption: objOptions.strCancel, reason: 'cancel', secondary: true}],
            onOk: objOptions.objConfirmHandler,
            onCancel: objOptions.objCancelHandler
    });

    //now check if we need to make it bigger to fit the content
    WinManager.sizeMessageBoxToContent(objOptions.objWin);

    //focus the ok button
    objOptions.objWin.document.getElementById('WinManagerSubmitMessageBoxButtonok').focus();
}


/**
 * Generic function for showing an alert type message to the user.
 * This uses our WebMaker styling rather than relying on the standard browser functionality
 * that the users can choose to hide if they wish.
 *
 * @param objOptions {
 *       strMsg: [optional] Message describing the context of the confirmation request
 *       strTitle: [optional] Title for the alert dialogue
 *       strCaption: [optional] Caption for the OK(Confirmation) button
 *       objHandler: [optional] Handler function called when the alert dialog is closed
 *       objWin: [auto] Usually managed by the WinManager
 *   }
 *
 */
WinManager.alert = function(objOptions)
{
    if (typeof(objOptions.objWin) == 'undefined')
        objOptions.objWin = window;

    if ((typeof(objOptions.strCaption) == 'undefined') || (objOptions.strCaption == null))
        objOptions.strCaption = WinManager.message.get('winmanager.buttons.ok');

    var dialogOptions = {
            objWin: objOptions.objWin,
            content: objOptions.strMsg,
            height: 150,
            width: 450,
            buttons: [{caption: objOptions.strCaption, reason: 'ok'}]}

    if ((typeof(objOptions.strTitle) != 'undefined') && (objOptions.strTitle != null))
        dialogOptions.title = objOptions.strTitle;

    if (typeof(objOptions.objHandler) == 'function')
        dialogOptions.onClose = objOptions.objHandler;

    WinManager.displayMessageBox(dialogOptions);

    //now check if we need to make it bigger to fit the content
    WinManager.sizeMessageBoxToContent(objOptions.objWin);

    //focus the ok button
    objOptions.objWin.document.getElementById('WinManagerSubmitMessageBoxButtonok').focus();
}

/**
 * Presents a simple message box requesting a single value to be entered by the user.
 * This is a replacement for the standard window.prompt option.
 * @param objOptions {
 *       strMsg: [optional] Message describing the request
 *       strTitle: [optional] Title for the prompt dialogue
 *       strDefault: [optional] The default value to show in the text box
 *       strConfirm: [optional] Caption for the OK(Confirmation) button
 *       strCancel: [optional] Caption for the Cancel button
 *       objConfirmHandler: [optional, but should be supplied] Handler function when the confirmation button is clicked.  This will be passed a single param
 *                          containing the value entered into the prompt dialog.
 *       objCancelHandler: [optional] Handler function when the cancel button is clicked
 *       objWin: [auto] Usually managed by the WinManager
 *   }
 */
WinManager.prompt = function(objOptions)
{
    if (typeof(objOptions.objWin) == 'undefined')
        objOptions.objWin = window;

    if (!objOptions.strTitle || objOptions.strTitle == "")
        objOptions.strTitle = WinManager.message.get('winmanager.prompt.title');

    if (!objOptions.strMsg || objOptions.strMsg == "")
        objOptions.strMsg = WinManager.message.get('winmanager.prompt.msg');;

    if (!objOptions.strConfirm || objOptions.strConfirm == "")
        objOptions.strConfirm = WinManager.message.get('winmanager.buttons.ok');

    if (!objOptions.strCancel || objOptions.strCancel == "")
        objOptions.strCancel = WinManager.message.get('winmanager.buttons.cancel');

    if (!objOptions.strDefault)
        objOptions.strDefault = '';

    var handleFunction = null;
    if (objOptions.objConfirmHandler)
    {
        handleFunction = function(){

            var val = objOptions.objWin.document.getElementById('winManagerPromptInput').value;
            objOptions.objConfirmHandler(val);
        }
    }


    WinManager.displayMessageBox({
            objWin: objOptions.objWin,
            content: objOptions.strMsg + '<br/><input type="text" id="winManagerPromptInput" style="margin-top: 5px; width: 250px;" value="' + objOptions.strDefault + '"/>',
            title:objOptions.strTitle,
            height: 150,
            width: 400,
            buttons: [{caption: objOptions.strConfirm, reason: 'ok'}, {caption: objOptions.strCancel, reason: 'cancel', secondary: true}],
            onOk: handleFunction,
            onCancel: objOptions.objCancelHandler
    });

    //now check if we need to make it bigger to fit the content
    WinManager.sizeMessageBoxToContent(objOptions.objWin);

    //focus the input box
    objOptions.objWin.document.getElementById('winManagerPromptInput').focus();
    //connect enter key to ok button
    WinManager.attachEvent(objOptions.objWin.document.getElementById('winManagerPromptInput'), 'onkeydown', function (evt) {
            if (evt.keyCode == 13)
            {
                WinManager.clearMessageBox(objOptions.objWin, 'ok');
            }
    });
}

/**
 * Resizes the current message box on the provided window so that it fits its content
 * This will remove any scrollbars from the message unless the content is too big to fit in the window.
 *
 * @param objWin The window object currently displaying the message box to size.
 */
WinManager.sizeMessageBoxToContent = function(objWin)
{
    var scrollContainer = objWin.document.getElementById('winManagerMsgContainer');
    var msgBox = objWin.document.getElementById('winManagerMsgBox');
    var screenSize = getViewportSize(objWin.document);

    if ((scrollContainer == null) || (msgBox == null))
        return;

    //first check height
    if (scrollContainer.scrollHeight > scrollContainer.offsetHeight)
    {
        var diff = scrollContainer.scrollHeight - scrollContainer.offsetHeight;

        var newBoxHeight = (parseFloat(msgBox.style.height) + diff);

        //make sure this new height still fits on the screen
        if (newBoxHeight > (screenSize.height - 20))
        {
            diff = diff - (newBoxHeight - (screenSize.height - 20));
            newBoxHeight = (parseFloat(msgBox.style.height) + diff);
        }

        msgBox.style.height = newBoxHeight + 'px';
        scrollContainer.style.height = (parseFloat(scrollContainer.style.height) + diff) + 'px';

        //also change the top position to keep centered
        msgBox.style.top = (parseFloat(msgBox.style.top) - (diff/2)) + 'px';
    }

    //now check width
    if (scrollContainer.scrollWidth > scrollContainer.offsetWidth)
    {
        var diff = scrollContainer.scrollWidth - scrollContainer.offsetWidth;

        var newBoxWidth = (parseFloat(msgBox.style.width) + diff);

        //make sure this new width still fits on the screen
        if (newBoxWidth > (screenSize.width - 20))
        {
            diff = diff - (newBoxWidth - (screenSize.width - 20));
            newBoxWidth = (parseFloat(msgBox.style.width) + diff);
        }

        msgBox.style.width = newBoxWidth + 'px';
        scrollContainer.style.width = (parseFloat(scrollContainer.style.width) + diff) + 'px';

        //also change the top position to keep centered
        msgBox.style.left = (parseFloat(msgBox.style.left) - (diff/2)) + 'px';
    }

}




/**
 * --------------------------------------------------------------------------------------------------
 * Start of functionality related to separating out displayed message strings from the code
 *
 */

WinManager.message = {
    displayMessages: {},
    loadedUrls: {}
};

/**
 * Returns the message string to display to the user for the given message id.
 *
 * This supports replacements in the string.  For example, assuming msgId maps to
 * the message string: 'Hello $1 and $2!', then calling this function as
 * get('msgId', 'Mickey', 'Minnie') will give
 * 'Hello Mickey and Minnie!'
 *
 * @param msgId The id of the message to retrieve eg fm.appmap.invalidName
 * @param replacements Any number of string values to insert into the message string.
 * @return The message string found, or an empty string if a match couldn't be found.
 */
WinManager.message.get = function(msgId, replacements)
{
    var parts = msgId.split('.');
    var obj = WinManager.message.displayMessages;
    for (var i = 0; i < parts.length; ++i)
    {
        if (obj[parts[i]])
        {
            obj = obj[parts[i]];
        }
        else
        {
            obj = null;
            break;
        }
    }

    if ((obj == null) || (typeof(obj) != 'string'))
        return '';

    if (arguments.length > 1)
    {
        for (var j = 1; j < arguments.length; ++j)
        {
            var strToReplace = '$' + j;

            obj = obj.replace(strToReplace, arguments[j]);
        }
    }

    return obj;
}

/**
 * Loads up all the message definitions from the given URL.
 * If this URL has already been loaded then nothing will be done.
 * The URL call must return a JSON object structure.
 * eg to define a msgId of fm.appmap.invalidName, it must return a structure like:
 * {fm: { appmap: {invalidName: "message here" }}}
 *
 * @param url The URL to load the message definitions from
 */
WinManager.message.load = function(url)
{
    if (WinManager.message.loadedUrls[url])
        return;

    //add the current product version number to the end of the url
    //TODO: The WM_VERSION_CODE variable does not seem to get correctly set in the top window
    //so cant use it here.  Need to fix this as ideally we want the browser to be able to cache
    //these message files per WM version
    //url = url + ((url.indexOf('?') != -1) ? '&' : '?') + 'v=' + WM_VERSION_CODE;

    dojo.xhrGet({
        url: url,
        preventCache: true,
        handleAs: 'json',
        sync: true,
        load: function(data, evt) {

            WinManager.nestedObjectMixin(WinManager.message.displayMessages, data);

            WinManager.message.loadedUrls[url] = true;

        },
        error: function(error) {
            WinManager.status.showMessage({msg:'Error loading display messages', detail: 'Error details: ' + error, level:'error'});
        }
    });

}

/**
 * Mixes in all the properties from source object into current object.  The properties in
 * source will overwrite those already in current.
 * This handles nested structures so if both objects have the same named property
 * as an object, then these objects will then be mixed in.
 * @param current Current object to mix the new details into.
 * @param source New object containing the properties to add.
 */
WinManager.nestedObjectMixin = function(current, source)
{
    for (var prop in source)
    {
        if (typeof(source[prop]) == 'object')
        {
            if (typeof(current[prop]) == 'object')
                WinManager.nestedObjectMixin(current[prop], source[prop])
            else
                current[prop] = source[prop];
        }
        else
        {
            current[prop] = source[prop];
        }
    }
}

