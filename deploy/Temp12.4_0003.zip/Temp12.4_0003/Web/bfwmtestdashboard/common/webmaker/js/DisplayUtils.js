/*
 * DisplayUitls.js
 *
 * Utility functions for altering the display of HTML componenets from javascript
 *
 * Company: Hyfinity Ltd
 * Copyright (c) 2003
 */

/** create string trim function for older browsers. */
if(typeof String.prototype.trim !== 'function') {
  String.prototype.trim = function() {
    return this.replace(/^\s+|\s+$/g, '');
  }
}


/**
 * Root object to contain all hyfinity functions.
 * This should remove the chance of a name conflict with other functionality.
 *
 * TODO: At some point we need to update all existing functionality to use this namespace.
 */
if (typeof(hyf) == 'undefined')
    var hyf =
    {
        version : '1.0'
    };

/**
 * Generic function for toggling the display of a component.
 * @param targetComponent the HTML component (or its ID) to show/hide
 * @param method An optional string specifying the required visibility of the
 *               component ('show' or 'hide')
 */
function toggleComponent(targetComponent, method, animate)
{
    var component
    if (typeof(targetComponent) == 'string')
        component = document.getElementById(targetComponent);
    else
        component = targetComponent;
    if ((component != null) && (typeof(component) != 'undefined'))
    {
        if ((method == null) || (typeof(method) == 'undefined'))
        {
            if (getCurrentStyle(component, 'display') == 'none')
            {
                showComponent(component, animate);
            }
            else
            {
                hideComponent(component, animate);
            }
        }
        else
        {
            if (method == 'hide')
            {
                hideComponent(component, animate);
            }
            else
            {
                showComponent(component, animate);
            }
        }
    }
}

if (typeof(dojo) != 'undefined')
{
    try
    {
        dojo.require("dojo.fx");
    }
    catch (e)
    {}
}

/*generic utility function for hiding a specific component*/
function hideComponent(component, animate)
{
    if (component == null)
        return;

    if ((animate == true) && (typeof(dojo) != 'undefined'))
    {
        dojo.fx.wipeOut({node: component, duration: 250}).play();
    }
    else
    {
        if ((typeof(component._oldCSSDisplay) == 'undefined') && (component.style.display != 'none'))
            component._oldCSSDisplay = component.style.display;

        component.style.visibility = 'hidden';
        component.style.display = 'none';
    }
}
/*generic utility function for showing a particular component*/
function showComponent(component, animate)
{
    if (component == null)
        return;

    //If the component is being hidden by a display setting in an external
    //css file then just clearing the inline display setting, or using the dojo
    //wipeIn command does not work correctly
    //Therefore we need to remove the class that is hiding it, and switch it to using
    //inline styles to hide.
    //This assumes use of one of the specific hide classes in the provided CSS file,
    //and may not work correclty if a different class name is being used.
    //If the component being shown is within a display none container then this check
    //will throw an error.  We dont want to stop the processing though so we catch the
    //error and ignore.
    try
    {
        if ((getCurrentStyle(component, 'display') == 'none') && (typeof(dojo) != 'undefined'))
        {
            dojo.removeClass(component, 'hide');
            dojo.removeClass(component, 'hidden');
            component.style.display = 'none';
        }
    }
    catch (e)
    { }

    if ((animate == true) && (typeof(dojo) != 'undefined'))
    {
        dojo.fx.wipeIn({node: component, duration: 250}).play();
    }
    else
    {
        component.style.visibility = 'visible';
        if (component.style.display == 'none')
        {
            if (component._oldCSSDisplay != undefined)
                component.style.display= component._oldCSSDisplay;
            else
                component.style.display = '';
        }
    }
}

/* utility function for disabling a component
 * may want to extend this so children components are disabled as well, ie if a div component is passed in*/
function disableComponent(component, deep)
{
    if ((component == null) || (typeof(component) == 'undefined') || (typeof(component.tagName) == 'undefined'))
        return;

    if ((component.tagName == 'INPUT') || (component.tagName == 'TEXTAREA') || (component.tagName == 'SELECT'))
    {
        if (typeof(dojo) != 'undefined')
            dojo.addClass(component, 'readOnlyTxt');
        component.disabled=true;
    }
    else if (component.tagName == 'A')
    {
        if (component.getAttribute("_oldHref") == null)
        {
            component.setAttribute("_oldHref", component.href)
        }
        component.removeAttribute('href');
        component.disabled=true;
        if (typeof(dojo) != 'undefined')
            dojo.addClass(component, 'disabledText');
    }
    else
    {
        component.disabled=true;
        if (typeof(dojo) != 'undefined')
            dojo.addClass(component, 'disabledText');
    }

    if (deep && component.hasChildNodes())
    {
        for (var i = 0; i < component.childNodes.length; ++i)
        {
            disableComponent(component.childNodes.item(i), deep);
        }
    }
}

/* utility function for enabling a component*/
function enableComponent(component, deep)
{
    if ((component == null) || (typeof(component) == 'undefined') || (typeof(component.tagName) == 'undefined'))
        return;

    component.disabled=false;

    if ((component.tagName == 'INPUT') || (component.tagName == 'TEXTAREA') || (component.tagName == 'SELECT'))
    {
        if (typeof(dojo) != 'undefined')
            dojo.removeClass(component, 'readOnlyTxt');
    }
    else if (component.tagName == 'A')
    {
        if (component.getAttribute("_oldHref") != null)
        {
            var oldHref = component.getAttribute("_oldHref")
            component.removeAttribute("_oldHref");
            component.href = oldHref;
        }
        if (typeof(dojo) != 'undefined')
            dojo.removeClass(component, 'disabledText');
    }
    else
    {
        if (typeof(dojo) != 'undefined')
            dojo.removeClass(component, 'disabledText');
    }

    if (deep && component.hasChildNodes())
    {
        for (var i = 0; i < component.childNodes.length; ++i)
        {
            enableComponent(component.childNodes.item(i), deep);
        }
    }
}

/**
 * Returns the current value for the given style property on the given object
 * @param object The element to get the current style for
 * @param property The name of the property to retrieve.  This should be hypenated where
 *              needed, eg 'padding-top'
 * @private
 * @author Hyfinity Limited
 */
function getCurrentStyle(object, property)
{
    var currentDisplay;
    if (window.getComputedStyle)
        currentDisplay = document.defaultView.getComputedStyle(object,null).getPropertyValue(property);
    else if (object.currentStyle)
    {
        //convert hypenanted values to camel case
        var camelCased = property.replace(/-([a-z])/g, function (g) { return g[1].toUpperCase() })
        currentDisplay = object.currentStyle[camelCased];
    }
    return currentDisplay;
}

/**
 * Sets the specified property in the definition of the given CSS class/rule.
 * @param classname The name of the class to apply the rpoperty to. eg '.myclass'
 *          This is actually the CSS selector for the CSS rule, so could be more complicated,
 *          eg '#abd #def .xyz'
 * @param property The name of the CSS property to defined for this rule.
 * @param value The value to give the specified property, or null if you want the property removed.
 *          Alternatively set the property param to null, and provide the full CSS string to apply for this classname here.
 * @param doc (Optional) document object to look for stylesheets in
 * @param important (Optional) boolean indicating whether to apply the !important flag to the new setting
 * NOTE: The order of the doc and important params is not imporatant
 */
function setClassSetting(classname, property, value, important, doc)
{
    var importantflag = false;
    var d = document;
    if (typeof(important) == 'boolean')
    {
        importantflag = important;
        if (typeof(doc) == 'object')
            d = doc;
    }
    else if (typeof(important) == 'object')
    {
        d = important;
        if (typeof(doc) == 'boolean')
            importantflag = doc;
    }

    var d = (doc) ? doc : document;
    var found = false;
    var ssheet;
    for (var si = 0; si < d.styleSheets.length; ++si)
    {
        try
        {
            ssheet = d.styleSheets[si];
            var rules;
            if(ssheet.cssRules)
                rules = ssheet.cssRules;
            else if (ssheet.rules)
                rules = ssheet.rules;

            for (var i = 0; i < rules.length; ++i)
            {
                if (rules.item(i).selectorText == classname)
                {
                    //if property has not been defined then we are setting the full
                    //CSS for ths rule.  Therefore always delete any match, and the correct content
                    //will be readded below if needed.
                    if (property == null)
                    {
                        if (ssheet.deleteRule)
                            ssheet.deleteRule(i);
                        else if (ssheet.removeRule)
                            ssheet.removeRule(i);
                        break;
                    }
                    found = true;
                    if (value == null)
                    {
                        if (rules.item(i).style.removeProperty)
                            rules.item(i).style.removeProperty(property);
                        else
                            rules.item(i).style.removeAttribute(property);
                    }
                    else
                    {
                        if (typeof(rules.item(i).style.setProperty) == 'function')
                        {
                            if (importantflag)
                                rules.item(i).style.setProperty(property, value, 'important');
                            else
                                rules.item(i).style.setProperty(property, value, '');
                        }
                        else
                            rules.item(i).style[property] = value;
                    }
                    break;
                }
            }
        }
        catch (e)
        {
            //couldnt access that stylesheet for some reason, so just try the next one
        }
    }
    if (!found && value != null)
    {
        var cssString = (property == null) ? value : property + " : " + value;
        if (importantflag)
            cssString += '!important';
        cssString += ";";

        try
        {
            if (ssheet.insertRule)
            {
                ssheet.insertRule(classname + " {" + cssString + "}", ssheet.cssRules.length);
            }
            else if (ssheet.addRule)
            {
                ssheet.addRule(classname, cssString);
            }
        }
        catch (e)
        {
            //error inserting new rule
            return false;
        }
    }
    return true;

}

/**
 * Moves the given object to the specified location
 * @param obj the HTML component to position - the 'top' and 'left' style properties
 *              of this object will be adjusted, so it should have absolute positioning
 * @param coords An object indicating where to position the component.
 *              This must have x and y properties.  For ease of use with the getMouseCoords
 *              method, a 10px offset will be applied to the x value.
 * @param keepInViewport (optional) a boolean value indicating whether the supplied coords
 *              should be adjusted to make sure that the object will be fully visible.
 *              If not provided, true will be assumed.
 */
function moveObjToCoords(obj, coords, keepInViewport)
{
    obj.style.top = coords.y + 'px';
    obj.style.left = (Number(coords.x) + Number(10)) + 'px';

    if ((typeof(keepInViewport) == 'undefined') || keepInViewport)
    {
        var newCoords = getComponentPosition(obj);
        var viewportSize = getViewportSize(obj.ownerDocument, true);

        //allow 10 px extra gap for shadows etc on right/bottom edges
        //check for top edge
        if (newCoords.y <  viewportSize.scrollTop)
        {
            obj.style.top = (viewportSize.scrollTop + 3) + 'px';
        }
        //check for bottom edge
        else if ((newCoords.y + newCoords.height + 10) > viewportSize.height + viewportSize.scrollTop)
        {
            obj.style.top = (viewportSize.height + viewportSize.scrollTop - newCoords.height - 10) + 'px';
        }

        //check for left edge
        if (newCoords.x <  viewportSize.scrollLeft)
        {
            obj.style.left = (viewportSize.scrollLeft + 3) + 'px';
        }
        //check for right edge
        else if ((newCoords.x + newCoords.width + 10) > viewportSize.width + viewportSize.scrollLeft)
        {
            obj.style.left = (viewportSize.width + viewportSize.scrollLeft - newCoords.width - 10) + 'px';
        }
    }
}

/**
 * Relative version of moveObjToCoords. See moveObjToRelativeCoords for doc
 * Moves the given object to the specified location
 * @param obj the HTML component to position - the 'top' and 'left' style properties
 *              of this object will be adjusted, relative to its container.
 * @param coords An object indicating where to position the component.
 *              This must have x and y properties.  For ease of use with the getMouseCoords
 *              method, a 10px offset will be applied to the x value.
 * @param keepInViewport (optional) a boolean value indicating whether the supplied coords
 *              should be adjusted to make sure that the object will be fully visible.
 *              If not provided, true will be assumed.
 */
function moveObjToRelativeCoords(obj, coords, keepInViewport)
{
    obj.style.top = coords.y + 'px';
    obj.style.left = (Number(coords.x) + Number(10)) + 'px';

    if ((typeof(keepInViewport) == 'undefined') || keepInViewport)
    {
        var newCoords = getComponentPosition(obj);
        var viewportSize = getViewportSize(obj.ownerDocument, true);

        //allow 10 px extra gap for shadows etc on right/bottom edges
        //check for top edge
        if (newCoords.y <  viewportSize.scrollTop)
        {
            obj.style.top = parseFloat(obj.style.top) + (viewportSize.scrollTop - Number(newCoords.y)) + 3 + 'px';
        }
        //check for bottom edge
        else if ((newCoords.y + newCoords.height + 10) > viewportSize.height + viewportSize.scrollTop)
        {
            obj.style.top = parseFloat(obj.style.top) + ((viewportSize.height + viewportSize.scrollTop) - (Number(newCoords.y) + newCoords.height)) - 10 + 'px';
        }

        //check for left edge
        if (newCoords.x <  viewportSize.scrollLeft)
        {
            obj.style.left = parseFloat(obj.style.left) + (viewportSize.scrollLeft - Number(newCoords.x)) + 3 + 'px';
        }
        //check for right edge
        else if ((newCoords.x + newCoords.width + 10) > viewportSize.width + viewportSize.scrollLeft)
        {
            obj.style.left = parseFloat(obj.style.left) + ((viewportSize.width + viewportSize.scrollLeft) - (Number(newCoords.x) + newCoords.width)) - 10 + 'px';
        }
    }
}

/**
 * Functions for adjustable dividers, which supports either one or two dividers on a page
 * This requires the page to be constructed with a single top level
 * table that only contains one row.  It should also have a TD for each divider required.
 * To set up the dividers, call the init emthod for each TD.
 * TODO: Support min and max options
 */
hyf.divider = {
    dividerMode: 'stop',
    dividers: new Object(), //id to details collection for all the dividers
    current: null,      //the Id of the current divider being adjusted
    moveDivider: null  //reference to the temporary div to use when adjusting a divider
}

hyf.divider.DIVIDER_MODE_LEFT = 'left';
hyf.divider.DIVIDER_MODE_RIGHT = 'right';

hyf.divider.DIVIDER_CLASS = 'divider';
hyf.divider.TOGGLE_CLASS_LEFT = 'divider_toggle_left';
hyf.divider.TOGGLE_CLASS_RIGHT = 'divider_toggle_right';
hyf.divider.TOGGLE_CLASS_CLOSED = 'closed';

hyf.divider.TOGGLE_TITLE_OPEN = "Close this panel";
hyf.divider.TOGGLE_TITLE_CLOSED = "Open this panel";

/**
 * Initialises a new divider
 * @param options A collection of options to detail which divider to init.
 *      This must contain the following properties:
 *          dividerTD: The TD object that should be converted into a divider.
 *          mode: One of the two mode constants that sets whetehr the divider will adjust the TD to the left or right of it.
 *
 *      The following are optional properties that can be provided:
 *          id: The ID to use for this divider (If not provided, the ID of the TD will be used instead)
 *          minWidth: Sets the minimum width the divider should allow
 *          maxWidth: Sets the maximum width the divider should allow
 *          canClose: Sets whether it should be possible to completely close this divider (default true)
 *
 * @param initialState (Optional) If provided the divider will be initialied to this state, which must be an
 *          object of the form used by the getState and restoreState methods
 */
hyf.divider.init = function(options, initialState)
{
    var id = (options.id) ? options.id : options.dividerTD.id;
    options.id = id;
    if (typeof(options.canClose) == 'undefined')
        options.canClose = true;
    if (typeof(options.minWidth) == 'undefined')
        options.minWidth = 0;
    if (typeof(options.maxWidth) == 'undefined')
        options.maxWidth = Number.MAX_VALUE;

    //work out which TD this divider should actually be adjusting
    if (options.mode == hyf.divider.DIVIDER_MODE_LEFT)
        options.target = getPreviousElementSibling(options.dividerTD)
    else
        options.target = getNextElementSibling(options.dividerTD)

    hyf.divider.dividers[id] = options;

    var dividerDiv = document.createElement('div');
    dividerDiv.className = hyf.divider.DIVIDER_CLASS;
    dividerDiv.setAttribute('id', 'hyfdivider-' + id);

    if (options.canClose)
    {
        var toggleContainer = document.createElement('div');
        toggleContainer.setAttribute('id', 'hyfdividertogglecontainer-' + id);


        var toggleButton = document.createElement('a');
        toggleButton.setAttribute('id', 'hyfdividertoggle-' + id);
        toggleButton.setAttribute('href', '#');
        toggleButton.onclick = new Function('hyf.divider.toggle("'+id+'", true);return false');
        toggleButton.onmousedown = function(e){cancelEvent((e) ? e : window.event);};

        //in older IE versions the SVG diagram etc can appear over the top of the
        //toggle button, so need to place an iframe behind it to force the correct z index
        if (dojo.isIE < 9)
        {
            var toggleFrame = document.createElement('iframe');
            toggleFrame.setAttribute('src', 'about:blank');
            toggleFrame.setAttribute('width', '100%');
            toggleFrame.setAttribute('height', '100%');
            toggleContainer.appendChild(toggleFrame);
        }


        toggleContainer.appendChild(toggleButton);
        dividerDiv.appendChild(toggleContainer);

        if (options.mode == hyf.divider.DIVIDER_MODE_LEFT)
        {
            toggleButton.className = hyf.divider.TOGGLE_CLASS_LEFT;
            toggleContainer.className = hyf.divider.TOGGLE_CLASS_LEFT + '_container';
        }
        else
        {
            toggleButton.className = hyf.divider.TOGGLE_CLASS_RIGHT;
            toggleContainer.className = hyf.divider.TOGGLE_CLASS_RIGHT + '_container';
        }

        toggleButton.title = hyf.divider.TOGGLE_TITLE_OPEN;
    }

    dividerDiv.onmousedown = hyf.divider.mouseDown;

    options.dividerTD.innerHTML = '';
    options.dividerTD.appendChild(dividerDiv);


    if (typeof(initialState) != 'undefined')
    {
        hyf.divider.restoreState(id, initialState, false);
    }


    //make sure the move node has been initialised
    //this doesnt really belong here, as only needs to be done once per page,
    //not per divider
    hyf.divider.moveDivider = document.getElementById('temp_divider');
    if (hyf.divider.moveDivider == null)
    {
        hyf.divider.moveDivider = document.createElement('div');
        hyf.divider.moveDivider.id = 'temp_divider';
        hyf.divider.moveDivider.className = 'temp_divider';
        hyf.divider.moveDivider.setAttribute('onselectstart', 'return false;');
        document.body.appendChild(hyf.divider.moveDivider);
    }
}

/**
 * Handles mouse dowm on a divder to start an adjustment operation.
 */
hyf.divider.mouseDown = function(e)
{
    var evt = (e) ? e : window.event;
    var evtSource = (evt.srcElement) ? evt.srcElement : evt.target;
    if (evtSource.nodeType == 3) // defeat Safari bug
        evtSource = evtSource.parentNode;

    //find the divider
    while ((evtSource != null) && (evtSource.className != hyf.divider.DIVIDER_CLASS))
    {
        evtSource = evtSource.parentNode;
    }

    if (evtSource == null)
        return;

    //remove the hyfdivider- prefix from the ID to get the actual divider id
    var dividerID = evtSource.id.replace('hyfdivider-', '')

    if (hyf.divider.isHidden(dividerID))
        return;

    hyf.divider.dividerMode = 'mousedown';
    hyf.divider.current = dividerID;

    hyf.divider.moveDivider.style.top = getTopPosition(hyf.divider.dividers[dividerID].target) + 'px';
    hyf.divider.moveDivider.style.height = evtSource.offsetHeight + 'px';

    var pos = getMouseCoords(evt);

    var tdLeft = getLeftPosition(hyf.divider.dividers[hyf.divider.current].dividerTD);

    hyf.divider.moveOffset = pos.x - tdLeft;

    hyf.divider.moveDivider.style.left = (pos.x - hyf.divider.moveOffset) + 'px';
    hyf.divider.moveDivider.style.display = 'block';

    if (hyf.divider.dividers[hyf.divider.current].mode == hyf.divider.DIVIDER_MODE_LEFT)
    {
        hyf.divider.fixedPoint = getLeftPosition(hyf.divider.dividers[hyf.divider.current].target);
    }
    else
    {
        hyf.divider.fixedPoint = getRightPosition(hyf.divider.dividers[hyf.divider.current].target);
    }

    if(evt.preventDefault){
        evt.preventDefault();
    }
    evt.cancelBubble=true;
    evt.returnValue = false;
}
/**
 * Mouse move handler to check if a divider move is in process,
 * and update the position of the temporary move marker accordingly
 */
hyf.divider.mouseMove = function(e, base)
{
    if ((hyf.divider.dividerMode == 'move') || (hyf.divider.dividerMode == 'mousedown'))
    {
        var evt = (e) ? e : window.event;

        var pos = getMouseCoords(evt, base);

        if(evt.preventDefault){
            evt.preventDefault();
        }
        evt.cancelBubble=true;
        evt.returnValue = false;

        var xPos = (pos.x - hyf.divider.moveOffset);


        var newWidth = -1;
        if (hyf.divider.dividers[hyf.divider.current].mode == hyf.divider.DIVIDER_MODE_LEFT)
            newWidth = xPos - hyf.divider.fixedPoint;
        else
            newWidth = hyf.divider.fixedPoint - xPos - hyf.divider.moveDivider.offsetWidth;

        //make sure this is an allowed width
        var changed = false;
        if (newWidth > hyf.divider.dividers[hyf.divider.current].maxWidth)
        {
            newWidth = hyf.divider.dividers[hyf.divider.current].maxWidth;
            changed = true;
        }
        if (newWidth < hyf.divider.dividers[hyf.divider.current].minWidth)
        {
            newWidth = hyf.divider.dividers[hyf.divider.current].minWidth;
            changed = true;
        }

        if (changed)
        {
            if (hyf.divider.dividers[hyf.divider.current].mode == hyf.divider.DIVIDER_MODE_LEFT)
                xPos = newWidth + hyf.divider.fixedPoint;
            else
                xPos = hyf.divider.fixedPoint - newWidth - hyf.divider.moveDivider.offsetWidth;
        }

        hyf.divider.moveDivider.style.left = xPos + 'px';


        hyf.divider.dividerMode = 'move'
    }
}

/**
 * Mouse up handler for dividers.  This checks if a divider adjustment
 * is in progress, and if so stores the results.
 */
hyf.divider.mouseUp = function(e, base)
{
    if (hyf.divider.dividerMode == 'move')
    {
        var evt = (e) ? e : window.event;
        var pos = getMouseCoords(evt, base);

        var newWidth = -1;
        if (hyf.divider.dividers[hyf.divider.current].mode == hyf.divider.DIVIDER_MODE_LEFT)
        {
            newWidth = (pos.x - hyf.divider.moveOffset) - hyf.divider.fixedPoint;
        }
        else
        {
            newWidth = hyf.divider.fixedPoint - (pos.x - hyf.divider.moveOffset) - hyf.divider.moveDivider.offsetWidth;
        }

        //make sure this is an allowed width
        if (newWidth > hyf.divider.dividers[hyf.divider.current].maxWidth)
            newWidth = hyf.divider.dividers[hyf.divider.current].maxWidth;
        if (newWidth < hyf.divider.dividers[hyf.divider.current].minWidth)
            newWidth = hyf.divider.dividers[hyf.divider.current].minWidth;

        if (newWidth > 0)
        {
            hyf.divider.updateSize(hyf.divider.current, newWidth);
        }
    }

    hyf.divider.dividerMode = 'stop';
    hyf.divider.current = null;

    if (hyf.divider.moveDivider != null)
    {
        hyf.divider.moveDivider.style.display = 'none';
    }
}

/**
 * Updates the width of the specified divider.
 * @param id The ID of the divider to update
 * @param size The width to give the divider
 * @param animate (Optional) if true the change to the divider will be animated rather than instant
 * @param afterChange (Optional) Function to call after the change has been made.
 * @private
 */
hyf.divider.updateSize = function(id, size, animate, afterChange)
{
    var currentWidth = "" + size;

    if ((typeof(animate) != 'undefined') && (animate))
    {
        var animProps = {
                    node: hyf.divider.dividers[id].target,
                    properties: {
                        width: currentWidth
                    }
                };
        if (typeof(afterChange) == 'function')
        {
            animProps.onEnd = function(){
                afterChange();
                hyf.divider.adjusted(id);
            };
        }
        else
            animProps.onEnd = function(){
                hyf.divider.adjusted(id);
            };

        dojo.animateProperty(animProps).play();
    }
    else
    {
        //make sure we have a unit definition
        if ((currentWidth.indexOf('%') != currentWidth.length - 1) && (currentWidth.indexOf('px') != currentWidth.length - 2))
            currentWidth = parseInt(currentWidth) + 'px';

        hyf.divider.dividers[id].target.style.width = currentWidth;
        if (typeof(afterChange) == 'function')
        {
            afterChange();
        }
        hyf.divider.adjusted(id);
    }
}

/**
 * Noop function called whenever a divider has been adjusted.
 * you should connect to this function if you need to beaware of thses changes.
 * @param id The Id of the divider that has been changed
 */
hyf.divider.adjusted = function(id)
{

}

/**
 * Toggles the visible or hidden state of the specified divider
 * @param id The ID of the divider to toggle
 * @param animate (Optional) if true the change to the divider will be animated rather than instant
 */
hyf.divider.toggle = function(id, animate)
{
    var ops = hyf.divider.dividers[id];
    if (ops.canClose)
    {
        var toggle = document.getElementById('hyfdividertoggle-' + id);

        if (hyf.divider.isHidden(id))
        {
            if (dojo.isIE == 8)
            {   //IE8 doesnt seem to like setting display none on a td for some reason
                //causes lots of empty space
                ops.target.style.visibility = 'visible';
                if (ops.target._originalOverflow)
                    ops.target.style.overflow = ops.target._originalOverflow
                else
                    ops.target.style.overflow = 'auto';
            }
            else
                ops.target.style.display = '';
            var newWidth;
            if (ops.target.hiddenDividerWidth)
                newWidth = ops.target.hiddenDividerWidth;
            else
                newWidth = '200'; //fallback
            hyf.divider.updateSize(id, newWidth, animate);
            document.getElementById('hyfdivider-' + id).style.cursor = 'e-resize';

            toggle.title = hyf.divider.TOGGLE_TITLE_OPEN;

            dojo.removeClass(toggle, hyf.divider.TOGGLE_CLASS_CLOSED)

        }
        else
        {
            ops.target.hiddenDividerWidth = parseInt(getComputedWidth(ops.target));
            hyf.divider.updateSize(id, 0, animate, function() {
                    if (dojo.isIE == 8)
                    {   //IE8 doesnt seem to like setting display none on a td for some reason
                        //causes lots of empty space
                        ops.target.style.visibility = 'hidden';
                        ops.target._originalOverflow = getCurrentStyle(ops.target, 'overflow');
                        ops.target.style.overflow = 'hidden';
                    }
                    else
                        ops.target.style.display = 'none';
                    document.getElementById('hyfdivider-' + id).style.cursor = 'auto';

                    toggle.title = hyf.divider.TOGGLE_TITLE_CLOSED;
                    dojo.addClass(toggle, hyf.divider.TOGGLE_CLASS_CLOSED)
            });
        }
    }
}

/**
 * checks if the section controlled by the given divider is hidden.
 * @param id The ID of the divider to check
 * @return boolean, true if hidden.
 */
hyf.divider.isHidden = function(id)
{
    if (hyf.divider.dividers[id])
    {
        if (hyf.divider.dividers[id].target.display == 'none')
            return true;

        var tempWidth = parseInt(getComputedWidth(hyf.divider.dividers[id].target));
        if (tempWidth <= 2)  //ie sometimes reports a width of 1 when hidden so allow some leway
            return true;
        else
            return false;
    }
}

/**
 * Returns an object detailing the current state of the specified adjustable container.
 * The returned object will have two properties, hidden and width.
 * @param id The ID of the divider
 */
hyf.divider.getState = function(id)
{
    var retObj = new Object();
    retObj.hidden = hyf.divider.isHidden(id);

    if (retObj.hidden)
        retObj.width = hyf.divider.dividers[id].target.hiddenDividerWidth
    else
        retObj.width = parseInt(getComputedWidth(hyf.divider.dividers[id].target));

    return retObj
}

/**
 * Restores the current visibility state of the given divider section to the provided details.
 * @param id The ID of the divider to restore the state for
 * @param state Object containing hidden and width properties, eg as returned from getState
 * @param animate (Optional) If true then the change in width will be animated, rather than happening straight away.
 */
hyf.divider.restoreState = function(id, state, animate)
{
    if (state.width == '' || isNaN(state.width))
    {
        state.width = hyf.divider.getState(id).width;
    }

    var currentHidden = hyf.divider.isHidden(id);
    if (currentHidden)
    {
        hyf.divider.dividers[id].target.hiddenDividerWidth = state.width;
        if (!state.hidden)
        {
            hyf.divider.toggle(id, animate);
        }
    }
    else
    {
        if (state.hidden)
        {
            hyf.divider.toggle(id, animate);
            hyf.divider.dividers[id].target.hiddenDividerWidth = state.width;
        }
        else
        {
            hyf.divider.updateSize(id, state.width, animate)
        }
    }
}



/**
 * Returns an object containing the coordinates of the mouse from the given event.
 * The returned object will have two properties, 'x' and 'y'
 */
function getMouseCoords(e, base)
{
    var coords = new Object();

    var evt = (e) ? e : window.event;

    //get the mouse coords
    if (evt.pageX || evt.pageY)
    {
        //Gecko based
        coords.x = evt.pageX;
        coords.y = evt.pageY;
    }
    else if (evt.clientX || evt.clientY)
    {
        coords.x = evt.clientX
        coords.y = evt.clientY

        var t = (evt.srcElement) ? evt.srcElement : evt.target;
        var doc = (t) ? t.ownerDocument : document;

        if ((doc.body) && (doc.body.scrollLeft || doc.body.scrollTop))
        {
            //IE 4, 5, and 6 (Non standards compliant mode)
            coords.x += doc.body.scrollLeft;
            coords.y += doc.body.scrollTop;
        }
        else if ((doc.documentElement) &&
                 ((doc.documentElement.scrollLeft) ||
                 (doc.documentElement.scrollTop)))
        {
            //IE 6 (Standards compliant mode)
            coords.x += doc.documentElement.scrollLeft;
            coords.y += doc.documentElement.scrollTop;
        }
    }

    if ((typeof(base) != 'undefined') && (typeof(base.x) != 'undefined') && (typeof(base.y) != 'undefined'))
    {
        coords.x += base.x;
        coords.y += base.y;
    }

    return coords;

}

/**
 * Returns the location of the left of the given object.
 * If the screen parameter is set to true, then the returned value will be in screen coords.
 * ie it adjusts for scrollable regions, to allow comparison with mouse coordinates
 * returned from getMouseCoords method
 */
function getLeftPosition(obj, screen)
{
    return getLeft(obj, screen);
    /*var ol=obj.offsetLeft;
    while ((obj=obj.offsetParent) != null)
    {
        ol += obj.offsetLeft;
        if (screen)
        {
            if (obj.scrollLeft != 0)
            {
                ot -= obj.scrollLeft;
            }
        }
    }
    return ol;*/
}

function getRightPosition(obj, screen)
{
    return getLeftPosition(obj, screen) + obj.offsetWidth;
}

/**
 * Returns the location of the top of the given object.
 * If the screen parameter is set to true, then the returned value will be in screen coords.
 * ie it adjusts for scrollable regions, to allow comparison with mouse coordinates
 * returned from getMouseCoords method
 */
function getTopPosition(obj, screen)
{
    return getTop(obj, screen);

    /*var ot=obj.offsetTop;
    while ((obj=obj.offsetParent) != null)
    {
        ot += obj.offsetTop;
        if (screen)
        {
            if (obj.scrollTop != 0)
            {
                ot -= obj.scrollTop;
            }
        }
    }
    return ot;*/
}


function getLeft(element, screen) {
    var left = 0, absoluteAncestor = false, computedStyle = (document.defaultView && document.defaultView.getComputedStyle), currentStyle = (element.currentStyle);
//	so long as the element has an positioning context...
    while (element.offsetParent) {
//		add the left offset of the element
        left += element.offsetLeft

        if (screen)
        {
            if (element.scrollLeft != 0)
            {
                left -= element.scrollLeft;
            }
        }

//		set the element to the element which provided the positioning context
        element = element.offsetParent;
//		if the element hasLayout (IE-only property)
        if (currentStyle && element.currentStyle.hasLayout && element.nodeName.toLowerCase() != 'html') {
//			add the width of the left border
            left += element.clientLeft;
//			and if it's absolutely positioned, flag that we've got an absolutely positioned ancestor
            if (element.currentStyle['position'] == 'absolute') absoluteAncestor = true;
//		otherwise, if it's a browser that supports computedStyle & the element is absolutely positioned
        } else if (computedStyle && document.defaultView.getComputedStyle(element, "").getPropertyValue('position') == 'absolute') {
//			add the left border of the element
            left += parseInt(document.defaultView.getComputedStyle(element, "").getPropertyValue('border-left-width'));
//			and flag that we've got an absolutely positioned ancestor
            absoluteAncestor = true;
        }
    }
//	if the browser supports currentStyle (i.e. is IE) and we found an absolutely positioned ancestor, add any left margin on the BODY
    if (!absoluteAncestor && currentStyle) return left += document.getElementsByTagName('BODY')[0].offsetLeft;
//	otherwise, if we found an absolutely positioned ancestor and the browser supports computed style add any left border from the BODY
    else if (!absoluteAncestor && computedStyle) return left += parseInt(document.defaultView.getComputedStyle(document.getElementsByTagName('BODY')[0], "").getPropertyValue('border-left-width'));
    else return left;
}

function getTop(element, screen) {
    var top = 0, absoluteAncestor = false, computedStyle = (document.defaultView && document.defaultView.getComputedStyle), currentStyle = (element.currentStyle);
//	so long as the element has an positioning context...
    while (element.offsetParent) {
//		add the top offset of the element
        top += element.offsetTop

        if (screen)
        {
            if (element.scrollTop != 0)
            {
                top -= element.scrollTop;
            }
        }

//		set the element to the element which provided the positioning context
        element = element.offsetParent;
//		if the element hasLayout (IE-only property)
        if (currentStyle && element.currentStyle.hasLayout && (element.nodeName.toLowerCase() != 'html')) {
//			add the width of the top border
            top += element.clientTop;
//			and if it's absolutely positioned, flag that we've got an absolutely positioned ancestor
            if (element.currentStyle['position'] == 'absolute') absoluteAncestor = true;
//		otherwise, if it's a browser that supports computedStyle & the element is absolutely positioned
        } else if (computedStyle && document.defaultView.getComputedStyle(element, "").getPropertyValue('position') == 'absolute') {
//			add the top border of the element
            top += parseInt(document.defaultView.getComputedStyle(element, "").getPropertyValue('border-top-width'));
//			and flag that we've got an absolutely positioned ancestor
            absoluteAncestor = true;
        }
    }
//	if the browser supports currentStyle (i.e. is IE) and we found an absolutely positioned ancestor, add any top margin on the BODY
    if (!absoluteAncestor && currentStyle) return top += document.getElementsByTagName('BODY')[0].offsetTop;
//	otherwise, if we found an absolutely positioned ancestor and the browser supports computed style add any top border from the BODY
    else if (!absoluteAncestor && computedStyle) top += parseInt(document.defaultView.getComputedStyle(document.getElementsByTagName('BODY')[0], "").getPropertyValue('border-top-width'));
    return top;
}

/**
 * Returns the current height of the given source component
 * @param source The DOM component to return the current computed height for
 * @return a float containing the current height value (pixels)
 */
function getComputedHeight(source)
{
    var compHeight
    if (dojo.isIE)
    {
        compHeight = source.offsetHeight;
    }
    else
    {
        compHeight = getCurrentStyle(source,"height");
    }
    return parseFloat(compHeight);
}

/**
 * Returns the current width of the given source component
 * @param source The DOM component to return the current computed width for
 * @return a float containing the current width value (pixels)
 */
function getComputedWidth(source)
{
    var compWidth
    if (dojo.isIE < 9)
    {
        compWidth = source.offsetWidth;
    }
    else
    {
        compWidth = getCurrentStyle(source,"width");
    }
    //special handling for opera which seems to return 0 from getCurrentStyle for the width for some reason.
    if ((parseFloat(compWidth) == 0) && (source.offsetWidth) && (source.offsetWidth > 0))
        compWidth = source.offsetWidth;

    return parseFloat(compWidth);
}

/**
 * Returns the current location coordinates of the given object.
 * The returned object will have four properties, 'x' and 'y' which give
 * the position of the top left corner, and 'width' and 'height'
 * If the screen parameter is set to true, the returned values are in 'screen coords', ie they are
 * adjusted for scrollable regions, to allow comparison with the mouse corrdinates returned from
 * the getMouseCoords method.
 */
function getComponentPosition(obj, screen)
{
    var objCoords = new Object();
    objCoords.x = getLeftPosition(obj, screen);
    objCoords.y = getTopPosition(obj, screen);
    objCoords.width = obj.offsetWidth;
    objCoords.height = obj.offsetHeight;
    return objCoords;
}

/**
 * Returns the size of the available window viewport
 * @return an object containing two properties, width and height.
 * @param doc (Optional) The document object to get the viewport size for
 * @param includeScroll (Optional) If true the returned object will include scrollLeft and scrollTop properties.
 */
function getViewportSize(doc, includeScroll)
{
    var d = (doc ) ? doc : document;
    var size = new Object();
    if (!doc && window.innerWidth)
    {
        size.width = window.innerWidth;
        size.height = window.innerHeight;
    }
    else if (d.documentElement && d.documentElement.clientWidth)
    {
        size.width = d.documentElement.clientWidth;
        size.height = d.documentElement.clientHeight;
    }
    else if (d.body && d.body.clientWidth)
    {
        size.width = d.body.clientWidth;
        size.height = d.body.clientHeight;
    }

    if (includeScroll)
    {
        size.scrollLeft = (d.documentElement.scrollLeft || d.body.scrollLeft || 0);
        size.scrollTop = (d.documentElement.scrollTop || d.body.scrollTop || 0);
    }
    return size;
}



/**
 * Adjusts the scrollTop and scrollLeft properties of the given container
 * to try and make the entry visible on the screen.
 * @param container The HTML component that contains the entry, and has overflow set to scroll.
 * @param entry The HTML component within the container that should be shown.
 */
function scrollViewToShow(container, entry, offset)
{
    if ((container == null) || (typeof(container) == 'undefined') ||
        (entry == null) || (typeof(entry) == 'undefined'))
    {
        //not recieved the required details so can't continue
        return;
    }

    if (!offset)
        offset = {x:0, y:0};

    var cScrollTop = container.scrollTop;
    var cPos = getComponentPosition(container, false);
    var cClientHeight = container.clientHeight;
    var cScrollLeft = container.scrollLeft;
    var cClientWidth = container.clientWidth;

    var ePos = getComponentPosition(entry, false);
    var eClientWidth = entry.clientWidth;

    //if the element position values are all 0, then it is likley it is hidden, so cant make it visible
    if ((ePos.x == 0) && (ePos.y == 0) && (ePos.width == 0) && (ePos.height == 0))
        return

    if (((cScrollTop + cPos.y + cClientHeight) < (ePos.y + offset.y)) || ((ePos.y + offset.y) < (cScrollTop + cPos.y)))
    { //hidden off the top or bottom of the scrolling window, so need to adjust scroll top
        container.scrollTop = (ePos.y + offset.y - cPos.y - (cClientHeight/2));
    }

    if (eClientWidth < cClientWidth)
    {  //entry width less than window width so show in the middle
        if (((cScrollLeft + cPos.x + cClientWidth) < (ePos.x + offset.x + eClientWidth)) || ((ePos.x + offset.x) < (cScrollLeft + cPos.x)))
        {
            container.scrollLeft = ((ePos.x + offset.x) - cPos.x - ((cClientWidth - eClientWidth)/2));
        }
    }
    else
    { //entry width greater than window width so show left hand section
        if (((cScrollLeft + cPos.x + cClientWidth) < (ePos.x + offset.x + eClientWidth)) || ((ePos.x + offset.x) < (cScrollLeft + cPos.x)))
        {
            container.scrollLeft = ((ePos.x + offset.x) - cPos.x - 10);
        }
    }
}


/**
 * Calculate the offset of the given iframe relative to the top window.
 * - Walks up the iframe chain, checking the offset of each one till it reaches top
 * - Only works with friendly iframes.
 * - Takes into account scrolling, but comes up with a result relative to
 *   top iframe, regardless of being visibile withing intervening frames.
 *
 * @param win    the window object for the iframe we're interested in
 * @param dims   an object containing the offset so far:
 *                          { left: [x], top: [y] }
 *                          (optional - initializes with 0,0 if undefined)
 * @return dims object above
 */
function computeFrameOffset(win, dims)
{
    //check if there actually is a parent window, and if not just return the
    //position already determined.
    if (win === win.parent)
    {
        return (dims || {x:0, y:0});
    }
    else if (typeof(dims) == 'undefined')
    {
        //when first called we need to
        dims = {x: -(win.document.documentElement.scrollLeft || win.document.body.scrollLeft || 0),
                y: -(win.document.documentElement.scrollTop || win.document.body.scrollTop || 0)};
    }

    //if we still dont have a dims object defined, then intialise it to 0
    if (typeof(dims) == 'undefined')
    {
        var dims = { y: 0, x: 0 };
    }


    // find the <iframe> tag within the parent window.
    var frames = win.parent.document.getElementsByTagName('iframe');
    var frame = null;

    for (var i=0, len=frames.length; i<len; i++)
    {
        if (frames[i].contentWindow === win)
        {
            frame = frames[i];
            break;
        }
    }

    // add the offset & recur up the frame chain
    if (frame)
    {
        var rect = frame.getBoundingClientRect();
        dims.x += rect.left;
        dims.y += rect.top;

        computeFrameOffset(win.parent, dims);
    }
    return dims;
};


// set flags for whether we should use opacity or filter with
// this browser (or browser mode). we prefer opacity.
var useOpacity = (typeof document.createElement("div").style.opacity != 'undefined');
var useFilter = !useOpacity && (typeof document.createElement("div").style.filter != 'undefined');


/**
 * Sets the opacity of the given object.
 * @param obj The object to set the opactiry on.
 * @param opacity The opacity value to set - 0.0 = transparent, 1.0 = opaque.
 */
function setOpacity(obj, opacity)
{
    if (obj != null)
    {
        // ensure value is in [0-1] range
        opacity = Math.min(1, Math.max(opacity, 0));

        var oldVal = obj.style.cssText;

        if (useOpacity) //Standards
            obj.style.opacity = opacity;
        else if (useFilter) //IE
            obj.style.filter = "alpha(opacity=" + (opacity * 100) + ")";

        obj._oldOpacityValue = oldVal;
    }
}


/**
 * Clears the opacity setting on the given object.
 * This actually sets the cssText property of the given element
 * back to what it was before the setOpacity method was called,
 * and so will remove any other changes made inbetween.
 */
function clearOpacity(obj)
{
    if (obj != null)
    {
        var oldVal = obj._oldOpacityValue;
        if ((oldVal != null) && (typeof(oldVal) != 'undefined'))
        {
            obj.style.cssText = oldVal;
            obj._oldOpacityValue = null;
        }
        else
        {
            if (useOpacity) //Standards
                obj.style.opacity = 1;
            else if (useFilter) //IE
                obj.style.filter = "";
        }
    }
}

/**
 * The scrollable div manager is used to provide extra scrolling features
 * for divs with the overflow setting set to scroll.
 * It will enable automatic scrolling of the container when the user has the mouse button
 * pressed, and moves the mouse towards the top or bottom of the container.
 * ie when they are doing a drag and drop operation.
 */
scrollableDivManager =
{
    scrollEnabled : false,
    DETECTION_OFFSET : 20,
    SCROLL_AMOUNT : 10
}

/**
 * Adds a container to be managed by the scriollable div manager
 */
scrollableDivManager.attachContainer = function(cont)
{
    //check that the container is set to scroll
    /*if (getCurrentStyle(cont, 'overflow') == 'scroll')
    {*/
        WinManager.attachEvent(cont, 'onmousemove', scrollableDivManager.mouseMove);
        WinManager.attachEvent(cont, 'onmouseout', scrollableDivManager.mouseOut);
        cont.setAttribute('scrollableDivContainer', 'true');
    /*}*/
}


scrollableDivManager.mouseMove = function(e, base, srcElem)
{
    if (!e) { e = window.event; }

    window.clearTimeout(scrollableDivManager.timeoutID);

    var elem = (srcElem) ? srcElem : ((e.srcElement) ? e.srcElement : e.target);

    while ((elem != null) && (elem.getAttribute('scrollableDivContainer') == null))
    {
        elem = elem.parentNode;
    }

    if (elem == null)
        return;

    //check that the mouse button is pressed
    //if ((e.button == 1) || (e.which == 1))
    if (scrollableDivManager.scrollEnabled)
    {
        var mouseCoords = getMouseCoords(e, base);
        var elemCoords;

        //try and handle the case where this scrollable container is actually the
        //document body, and so we are trying to scroll the whole document.
        if (elem.tagName.toLowerCase() == 'body')
        {
            var t;
            if (dojo.isWebKit)
                t = elem;
            else
                t = elem.ownerDocument.documentElement;


            var elemCoords = getViewportSize(elem.ownerDocument);

            elemCoords.x = t.scrollLeft;
            elemCoords.y = t.scrollTop;

            scrollableDivManager.scrollContainer = t;
            scrollableDivManager.scrollType = 'document';
        }
        else
        {
            elemCoords = getComponentPosition(elem, false);
            scrollableDivManager.scrollContainer = elem;
            scrollableDivManager.scrollType = 'component';
        }

        scrollableDivManager.lastMouseCoords = mouseCoords;

        if (mouseCoords.y < (elemCoords.y + scrollableDivManager.DETECTION_OFFSET))
        {
            scrollableDivManager.mouseHeldVertical(-scrollableDivManager.SCROLL_AMOUNT);
        }
        else if (mouseCoords.y > ((elemCoords.y + elemCoords.height) - scrollableDivManager.DETECTION_OFFSET))
        {
            scrollableDivManager.mouseHeldVertical(scrollableDivManager.SCROLL_AMOUNT);
        }
        else if (mouseCoords.x < (elemCoords.x + scrollableDivManager.DETECTION_OFFSET))
        {
            scrollableDivManager.mouseHeldHorizontal(-scrollableDivManager.SCROLL_AMOUNT);
        }
        else if (mouseCoords.x > ((elemCoords.x + elemCoords.width) - scrollableDivManager.DETECTION_OFFSET))
        {
            scrollableDivManager.mouseHeldHorizontal(scrollableDivManager.SCROLL_AMOUNT);
        }



    }
}

scrollableDivManager.mouseOut = function(e, base)
{
    if (!e) { e = window.event; }
    var newCoords = getMouseCoords(e, base);
    //only stop the looping call if the mouse has been moved.
    //this is needed as sometimes mousout seems to get called as a result of our
    //changing the scroll setting.  If the user hasnt moved the mouse we want to
    //keep scrolling for them.
    if (differentMousePosition(scrollableDivManager.lastMouseCoords, newCoords))
        window.clearTimeout(scrollableDivManager.timeoutID);
}

scrollableDivManager.mouseHeldVertical = function(changeAmount)
{
    scrollableDivManager.scrollContainer.scrollTop = scrollableDivManager.scrollContainer.scrollTop + changeAmount;
    if (scrollableDivManager.scrollType == 'document')
        scrollableDivManager.lastMouseCoords.y += changeAmount;
    //TODO: Work out when no more scrolling is possible, and stop this call
    scrollableDivManager.timeoutID = window.setTimeout("scrollableDivManager.mouseHeldVertical("+changeAmount+")", 5);
}

scrollableDivManager.mouseHeldHorizontal = function(changeAmount)
{
    scrollableDivManager.scrollContainer.scrollLeft = scrollableDivManager.scrollContainer.scrollLeft + changeAmount;
    if (scrollableDivManager.scrollType == 'document')
        scrollableDivManager.lastMouseCoords.x += changeAmount;
    //TODO: Work out when no more scrolling is possible, and stop this call
    scrollableDivManager.timeoutID = window.setTimeout("scrollableDivManager.mouseHeldHorizontal("+changeAmount+")", 5);
}





//The number of pixels the mouse is allowed to be moved (in both x and y) to still be considered
//a click operation that shouldnt move the image
var allowedOffset = 2;

function differentMousePosition(firstPos, secondPos)
{
    if ((firstPos != null) && (secondPos != null) &&
        (Math.abs(secondPos.x - firstPos.x) < allowedOffset) &&
        (Math.abs(secondPos.y - firstPos.y) < allowedOffset))
    {
        return false;
    }
    else
    {
        return true;
    }
}


//-------------------------------------------------------------------------

/**
 * The ContextMenu package contians functionality for handling right click
 * context menu processing.  You should first create a div in your HTML
 * containing the menu structure you want before creating a new ContextMenu
 * object from it.  This will handle sub level menus, by adding the correct
 * markup and classes to the HTML. eg
 *
 *  <div id="myContextMenu">
 *      <a id="menuOption1" href="#">Menu Option 1</a>
 *      <a id="sub_menu_label" href="#" class="sub_menu_label">More Options...</a>
 *      <div id="sub_menu" class="sub_menu">
 *          <a id="subMenuOption1" href="#">Sub Menu Option 1</a>
 *          <a id="subMenuOption2" href="#">Sub Menu Option 2</a>
 *      </div>
 *      <a id="menuOption2" href="#">Menu Option 2</a>
 *  </div>
 *
 * var cm = new hyf.ContextMenu(dojo.byId('myContextMenu'));
 * cm.showAt(evt);
 * cm.showAt(coords);
 * cm.hide();
 *
 */
hyf.ContextMenu = function(menuDiv)
{
    this.subMenus = {};

    this.subMenus['root'] = {name: 'root', elem: menuDiv, visible: false, parent: null, children: []};

    this.hide();

    var menuObj = this;

    //look for any sub menus in this menu to initiate the events on
    this.findSubMenus(menuDiv, 'root');
    require(["dojo/on"], function(on){
            on(menuDiv, 'mouseover', function(evt){
                    menuObj.subMenuMaintain('root', evt);
            });
    });

}

hyf.ContextMenu.prototype.findSubMenus = function(menuDiv, parentMenuId)
{
    var menuObj = this;

    require(["dojo/query", "dojo/on"], function(query, on){
            query('.sub_menu_label', menuDiv).forEach(function(item){

                    //find the matching submenu div
                    var subMenuId = item.id.substring(0, item.id.indexOf('_label'));
                    if (!menuObj.subMenus[subMenuId])
                    {
                        var subMenu = document.getElementById(subMenuId);
                        if (subMenu)
                        {
                            menuObj.subMenus[subMenuId] = {name: subMenuId, elem: subMenu, visible: false, parent: parentMenuId, children: []};
                            menuObj.subMenus[parentMenuId].children.push(subMenuId);

                            hideComponent(subMenu);

                            on(item, 'mouseover', function(evt){
                                    menuObj.startSubMenuShow(subMenuId, evt);
                            });

                            on(subMenu, 'mouseover', function(evt){
                                    menuObj.subMenuMaintain(subMenuId, evt);
                            });

                            menuObj.findSubMenus(subMenu, subMenuId);


                        }
                    }
            });
    });
}

/**
 * Displays this menu at the specified location.
 * This location will be adjusted if needed to make sure the menu is visible on screen.
 * @param locationObj Either a mouse event object whose coordinates will be used as the display location
 *                    or a simple coords object with x and y properties.
 */
hyf.ContextMenu.prototype.showAt = function(locationObj)
{
    showComponent(this.subMenus['root'].elem);
    this.subMenus['root'].elem.style.visibility = 'hidden';

    if (locationObj.x && locationObj.y)
        moveObjToCoords(this.subMenus['root'].elem, locationObj, true);
    else
        moveObjToCoords(this.subMenus['root'].elem, getMouseCoords(locationObj), true);

    this.subMenus['root'].visible = true;
    this.subMenus['root'].elem.style.visibility = 'visible';
}

/**
 * Hides the visibility of this menu
 */
hyf.ContextMenu.prototype.hide = function()
{
    this.subMenuHide('root');
}


hyf.ContextMenu.prototype.startSubMenuShow = function(subMenuId, evt)
{
    var parentMenu = this.subMenus[subMenuId].parent;
    if (this.subMenus[parentMenu].visible)
    {
        if (this.subMenuTimeout)
        {
            clearTimeout(this.subMenuTimeout);
            this.subMenuTimeout = null;
        }

        //hide any other sibling submenus

        for (var i = 0; i < this.subMenus[parentMenu].children.length; ++i)
        {
            if (this.subMenus[parentMenu].children[i] != subMenuId)
                this.subMenuHide(this.subMenus[parentMenu].children[i]);
        }

        cancelEvent(evt);

        var menuObj = this;
        this.subMenuTimeout = setTimeout(function(){

                var subMenu = document.getElementById(subMenuId);
                var subMenuLabel = document.getElementById(subMenuId + '_label');
                var labelPos = getComponentPosition(subMenuLabel);

                var subMenuCoords = {x: labelPos.width - 10, y: labelPos.y - getTopPosition(menuObj.subMenus[parentMenu].elem) - 5};

                showComponent(subMenu);
                moveObjToCoords(subMenu, subMenuCoords, true);
                dojo.addClass(subMenuLabel, 'active_menu_option');
                menuObj.subMenus[subMenuId].visible = true;

        }, 200);

    }

}
/*

hyf.ContextMenu.prototype.startSubMenuHide = function(subMenuId)
{
    if ((this.visible) && (this.subMenuVisible == subMenuId))
    {
        if (this.subMenuTimeout)
        {
            clearTimeout(this.subMenuTimeout);
            this.subMenuTimeout = null;
        }

        var menuObj = this;
        this.subMenuTimeout = setTimeout(function(){
                menuObj.subMenuHide(subMenuId);
        }, 100);

    }
}*/
hyf.ContextMenu.prototype.subMenuHide = function(subMenuId)
{
    if (this.subMenus[subMenuId].visible)
    {
        if (this.subMenuTimeout)
        {
            clearTimeout(this.subMenuTimeout);
            this.subMenuTimeout = null;
        }

        hideComponent(this.subMenus[subMenuId].elem);
        if (document.getElementById(subMenuId + '_label'))
            dojo.removeClass(document.getElementById(subMenuId + '_label'), 'active_menu_option');

        for (var i = 0; i < this.subMenus[subMenuId].children.length; ++i)
        {
            this.subMenuHide(this.subMenus[subMenuId].children[i]);
        }

        this.subMenus[subMenuId].visible = false;
    }
}

hyf.ContextMenu.prototype.subMenuMaintain = function(subMenuId, evt)
{
    if (this.subMenus[subMenuId].visible)
    {
        if (this.subMenuTimeout)
        {
            clearTimeout(this.subMenuTimeout);
            this.subMenuTimeout = null;
        }
        //hide any children sub menus of this one
        for (var i = 0; i < this.subMenus[subMenuId].children.length; ++i)
        {
            this.subMenuHide(this.subMenus[subMenuId].children[i]);
        }
        cancelEvent(evt);
    }

}


//-------------------------------------------------------------------------


// This stuff is copied from the runtime displayUtils file that is used within the FM generated apps
// should probably look at reusing the existing file rather than having another copy here!!!


/**
 * The hyf.textarea namespace contains all functionality relating to textarea field controls.
 */
hyf.textarea =
{
    desc : "Handles functionality relating to textareas, eg auto expanding fields."
};

/**
 * Handles automatically updating the size of the supplied textarea to support the current content.
 *
 * @param evt The event object that triggered the call.
 * @param field The textarea object to adjust
 * @param min The minim number of rows to show in the textarea.
 * @param max The maximum number of rows to expand the textarea to.
 */
hyf.textarea.adjustHeight = function(evt, field, min, max)
{
    if ((evt != null) && (typeof(evt) != 'undefined'))
        var charCode = (evt.which) ? evt.which : event.keyCode;

    //ignore the arrow keys and shift/ctrl key
    if ((charCode >= 37 && charCode <= 40) || (charCode == 16) || (charCode == 17) || (evt && evt.ctrlKey))
    {
        return;
    }

    if ((max == null) || typeof(max) == 'undefined')
        max = Number.MAX_VALUE;
    if ((min == null) || typeof(min) == 'undefined')
        min = 1;

    //ensure the textarea has been correctly initiated
    if (!field._clone)
        hyf.textarea.initTextarea(field);
    else if (field._lineHeightUpdateRequired == true)
    {
        hyf.textarea.determineLineHeight(field);
        field._lineHeightUpdateRequired = false;
    }

    //out the current text into the clone field to see how big it is
    field._clone.value = field.value;

    var newHeight = field._clone.scrollHeight;
    var minHeight = field._lineHeight * min;
    var maxHeight = field._lineHeight * max;

    //only make any changes if the new height is different to the last one we found
    if (newHeight != field._lastHeight)
    {
        field._lastHeight = newHeight;
        if (newHeight > maxHeight)
        {
            //stop resizing, and allow the vertical scrollbar to appear
            field.style.overflowY = 'auto';
            field.style.height = maxHeight + 'px';
        }
        else if (newHeight < minHeight)
        {
            //dont resize
            field.style.overflowY = 'hidden';
            field.style.height = minHeight + 'px';
        }
        else
        {
            field.style.overflowY = 'hidden';
            field.style.height = newHeight + 'px';
        }
    }
};



/**
 * Initialises the given textarea so that the expanding functionality
 * will work correctly.
 * @param ta The textarea to initialise.
 * @private
 */
hyf.textarea.initTextarea = function(ta)
{
    //remove any current rows setting, as we will instead be adjusting the
    //height of the control
    ta.removeAttribute('rows');

    //make a clone of the textarea that we can use to determine what height
    //the main textarea should be
    var clone = ta.cloneNode(true);
    ta._clone = clone;

    //ensure the clone doesnt appear or affect the working of the page
    clone.removeAttribute('id');
    clone.removeAttribute('name');
    clone.disabled = true;
    dojo.style(clone, {overflowY : 'auto', position: 'absolute', top: '0px', left : '-99999px'});
    ta.parentNode.appendChild(clone);

    //try and guestimate the line height of the field, as there is no cross browser way to get this easily
    hyf.textarea.determineLineHeight(ta);
    //in IE the first guess of the line height doesnt always come out correctly,
    //so we try again at a later point
    if (dojo.isIE)
    {
        ta._lineHeightUpdateRequired = true;
        window.setTimeout(function(){ta.onkeyup()}, 5);
    }
    ta._lastHeight = 0;

    //just to be sure, add another call to update the size, on focus of the field.
    dojo.connect(ta, 'onfocus', ta, new Function('this.onkeyup()'));
}

/**
 * Makes a guess at the line height value for the provided
 * textarea by putting temporary content into the clone
 * and seeing how big it gets.
 * This value is then stored against the textarea
 * @private
 */
hyf.textarea.determineLineHeight = function(ta)
{
    ta._clone.value = 'a\nb\nc\nd\ne';
    ta._lineHeight = (ta._clone.scrollHeight / 5);
}



/**
 * Collapses all the whitespace in the given string, and then converts any remaining
 * spaces to underscores.
 * This can be used to make the users entered value a valid id string.
 */
function spacesToUnderscores(value)
{
    value = String(value);
    //remove whitespace characters from the start of the string
    value = value.replace(/^\s+/g,'');
    //remove whitespace characters from the end of the string
    value = value.replace(/\s+$/g, '');
    //collapse whitespace in the middle
    value = value.replace(/\s+/g, ' ');

    //convert any remaining whitespace to underscores
    value = value.replace(/\s/g, '_');

    return value;
}

/**
 * Returns the size in pixels that the given string takes up on the screen.
 * This makes use of a hidden container with id 'textSizer' that will be created
 * directly under the body if not already found.  You need to ensure that the
 * font and size etc styles applied to this container match what you want to measure.
 * @param value The string value to get the visual length for.
 * @param className Optional string specifying the CSS classes to apply to the container before determining the size
 * @return The number of pixels
 */
function getStringVisualLength(value, className)
{
    var sizer = document.getElementById('textSizer');
    if (!sizer)
    {
        sizer = document.createElement('span');
        sizer.id = 'textSizer';
        sizer.style.visibility = 'hidden';
        sizer.style.whiteSpace = 'nowrap';
        sizer.style.position = 'absolute';
        sizer.style.top = 0;
        sizer.style.left = -9999;
        document.body.appendChild(sizer);
    }

    if (className)
        sizer.className = className;
    else
        sizer.className = '';

    sizer.innerHTML = value;
    //sizer.innerHTML = '<table><tr><td>' + value + '</td></tr></table>';
    return sizer.offsetWidth;
}

/**
 * Trims the provided string so that it will have the specified
 * pixel width when displayed on screen.
 * @param value The string value to trim.
 * @param size The size in pixels to trim to.
 * @param trimFromFront Optional boolean indicating that the trim process should remove characters
 *                      from the front of the string rather than the end as usual.
 * @param className Optional string specifying the CSS classes to apply to the container before determining the size
 */
function trimStringToPixelLength(value, size, trimFromFront, className)
{
    if (typeof(trimFromFront) == 'undefined')
        trimFromFront = false;

    var returnVal = value;
    var trimmedVal = value;
    if (size > 0)
    {
        while ((trimmedVal.length > 0) && (getStringVisualLength(returnVal, className) > size))
        {
            if (trimFromFront)
            {
                trimmedVal = trimmedVal.substring(1);
                returnVal = '...' + trimmedVal;
            }
            else
            {
                trimmedVal = trimmedVal.substring(0, trimmedVal.length-1);
                returnVal = trimmedVal + '...';
            }
        }
    }

    return returnVal;
}

/**
 * Generic method that cancels propagation of the provided event object.
 * This should hopefully handle all browsers
 */
function cancelEvent(evt)
{
    if (evt)
    {
        evt.cancelBubble = true;
        if (evt.preventDefault)
            evt.preventDefault();
        if (evt.stopPropagation)
            evt.stopPropagation();
    }
}





/**
 * Temporarily adds html to the page to try and draw the users attention to
 * the provided component.
 * This draws a box bigger than but centered on the component, whose size is then
 * reduced until it is the same size as the provided component.
 * @param c The component to draw attention to.
 *
 */
function drawAttentionToComponent(c)
{
    if (typeof(c) == 'string')
        c = dojo.byId(c);

    var cPos = getComponentPosition(c);

    var d = c.ownerDocument;

    var docSize = {width : 0, height : 0};
    if (d.documentElement && d.documentElement.clientWidth)
    {
        docSize.width = d.documentElement.clientWidth;
        docSize.height = d.documentElement.clientHeight;
    }
    else if (d.body && d.body.clientWidth)
    {
        docSize.width = d.body.clientWidth;
        docSize.height = d.body.clientHeight;
    }

    var startOffset = 150;
    var endOffset = 3;
    var lineWidth = 2;

    var marker = d.createElement('div');
    marker.style.border = lineWidth + 'px solid black';
    marker.style.background = 'transparent';
    marker.style.position = 'absolute';

    var markerSize = {
        top: cPos.y - startOffset,
        left: cPos.x - startOffset,
        width: cPos.width + (2 * startOffset),
        height: cPos.height + (2 * startOffset)
    };

    //make sure the marker wont go off the screen
    if (markerSize.top < 0)
        markerSize.top = 0;
    if (markerSize.left < 0)
        markerSize.left = 0;
    if ((docSize.height != 0) && ((markerSize.top  + markerSize.height + (2 * lineWidth)) > docSize.height))
        markerSize.height = docSize.height - markerSize.top - (2 * lineWidth);
    if ((docSize.width != 0) && ((markerSize.left  + markerSize.width + (2 * lineWidth)) > docSize.width))
        markerSize.width = docSize.width - markerSize.left - (2 * lineWidth);

    marker.style.top = markerSize.top + 'px';
    marker.style.left = markerSize.left + 'px';
    marker.style.width = markerSize.width + 'px';
    marker.style.height = markerSize.height + 'px';

    marker.style.zIndex = 9999;

    d.body.appendChild(marker);

    dojo.animateProperty({
                node: marker,
                properties: {
                    left: Math.max((cPos.x - endOffset - lineWidth), 0),
                    top: Math.max((cPos.y - endOffset - lineWidth), 0),
                    //add explicit start points for height and width as otherwise these seemed to
                    //sometimes get bigger at the start, which can cause scrollbars to appear
                    //if we are near the edge of the screen
                    width: {start: markerSize.width, end: (cPos.width + (2 * endOffset))},
                    height: {start: markerSize.height, end: (cPos.height + (2 * endOffset))}
                },
                onEnd: function(){
                    //remove the marker after a slight delay to make sure the user sees what it is marking
                    window.setTimeout(function(){
                            marker.parentNode.removeChild(marker);
                    }, 500);
                }
    }).play();
}






/**
 * checks whether the provided event object represents a double click on the given object.
 * This is needed to resolve issues with IE10 (on windows 8) where the 'detail' property
 * indicating how many times the button has been clicked in the same place never seems to get
 * reset!
 * Instead for IE10 we have to manully track the number of times clicked on each object and when.
 * This has so far only been needed for tracking double clicks on the SVG diagrams, but could
 * be used elsewhere if required.
 *
 * @param evt The event object
 * @param the object (Page, Handler, Link) to check for clicks on.
 */
function isDoubleClick(evt, obj)
{
    if (getIEVersion() >= 10)
    {
        var dblClick = false;

        if (obj._ieClickCount == 1)
        {
            obj._ieClickCount = 2;
        }
        else
        {
            obj._ieClickCount = 1;
        }

        var dblClick = (obj._ieClickCount == 2);

        setTimeout(function() {
            obj._ieClickCount = null;
        }, 500);

        return dblClick;
    }
    else
    {
        return (evt.detail == 2)
    }
}

/**
 * Returns the version number of the internet explorer
 * version in use, or null if the current browser is not IE.
 * This is needed because with IE11, microsoft changed the user agent etc to not be
 * identified as IE, so dojo.isIE returns false.  Instead you can check the version of
 * the trident rendering engine being used.
 * This function is a wrapper around these different options, and so will return the IE version number
 * regardless of whetehr it is the new or old type.
 * @return The IE version number in use, or null if not IE
 */
function getIEVersion()
{
    if (dojo.isIE)
        return dojo.isIE
    else
    {
        //check for the trident token.
        //See http://msdn.microsoft.com/en-us/library/ie/ms537503.aspx
        var tridentVersion = parseFloat(navigator.appVersion.split("Trident/")[1]);
        if (!isNaN(tridentVersion))
        {
            //this seems to give a value 4 less than the IE version
            //eg trident 7 is IE11, 6 IE10, etc
            //not sure if we can rely on this going forward, but we will for now.
            return (tridentVersion + 4);
        }
    }
    return null;
}

/**
 * Returns the edge version in use if the current browser is Edge, otherwise
 * returns null.
 * This actually returns the EdgeHTML version, not the Edge App version.
 */
function getEdgeVersion()
{
    //check for the edge token in the user agent string.
    //This is actually the EdgeHTML version
    //See https://blogs.windows.com/msedgedev/2015/09/21/understanding-versions-in-an-evergreen-browser/
    var edgeVersion = parseFloat(navigator.appVersion.split("Edge/")[1]);
    if (!isNaN(edgeVersion))
    {
        return edgeVersion;
    }
    return null;
}


var WMDisplayUtilsLoaded = true;
