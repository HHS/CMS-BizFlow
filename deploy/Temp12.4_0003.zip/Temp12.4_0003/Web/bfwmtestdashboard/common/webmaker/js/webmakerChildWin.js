/*
* Copyright (c) 2008 Hyfinity Limited. All rights reserved.
*/

/**
 * Main Windows Manager resides within the top-level 'main' window. See webmakerWinManager.js
 */
WinManager = {
    version: 1.0,
    bGenuineClose: true,	//Used to detect whether a genuine request was made to close a window or an involuntary unload event was received

    //Check if this script is included in a window that should actually be managed properly.
    //for sub frames the config option can be set to false before loading theis script file so that the
    //managedWin flag gets set to false.
    //this will mean that all the events to detect window closing/opening/clicks etc will not be attached
    //but the calls to the main window manager to open new windows, check status etc can still be used.
    managedWin: (typeof(WinManagerConfig_Managed) != 'undefined') ? WinManagerConfig_Managed : true,

    //By default the winmanager will pusgh the common CSS files into each page as the page loads.
    //if you dont want that (eg have already added them directly) set teh WinManagerConfig_stylingOutput flag to true;
    stylingOutput: (typeof(WinManagerConfig_OutputStyling) != 'undefined') ? !WinManagerConfig_OutputStyling : false
}

/**
 * Generic function for attaching events in a cross browser way
 * This deligates to the dojo functionality wherever possible.
 * @param obj The object to attach the event to
 * @param evt A string specifying the type of event, eg 'onclick'
 * @param fnction The function to call when the event occurrs
 * @return a handle that is needed if you ever want to detach the event later.
 */
WinManager.attachEvent = function(obj, evt, fnction)
{
    if (obj == null)
        return;

    /*if ((typeof(dojo) != 'undefined') && (typeof(dojo.connect) != 'undefined'))
    {
        return dojo.connect(obj, evt, fnction);
    }
    else*/ if (typeof(obj.attachEvent) != 'undefined') //IE format
    {
        obj.attachEvent(evt, fnction);
    }
    else if (typeof(obj.addEventListener) != 'undefined') //W3C format
    {
        obj.addEventListener(evt.substring(2), fnction, false);
    }
    else
    {
        alert('could not attach event');
    }
}

/**
 * Generic function for detaching events in a cross browser way
 * This deligates to the dojo functionality wherever possible.
 * @param obj The object to detach the event from
 * @param evt A string specifying the type of event, eg 'onclick'
 * @param fnction The function that should no longer be called when the event occurrs
 * @param handle The handle returned from the attachEvent call.
 */
WinManager.detachEvent = function(obj, evt, fnction, handle)
{
    if (obj == null)
        return;

    /*if ((typeof(dojo) != 'undefined') && (typeof(dojo.connect) != 'undefined') && (typeof(handle) != 'undefined'))
    {
        dojo.disconnect(handle);
    }
    else*/ if (typeof(obj.detachEvent) != 'undefined') //IE format
    {
        obj.detachEvent(evt, fnction);
    }
    else if (typeof(obj.removeEventListener) != 'undefined') //W3C format
    {
        obj.removeEventListener(evt.substring(2), fnction, false);
    }
    else
    {
        alert('could not detach event');
    }
}


/**
 * Returns the WinManager object that all requests should be delegated to
 * @private
 */
WinManager.getParentWinManager = function()
{
    if ((typeof(WinManager.pwm) == 'undefined') || (WinManager.pwm == null))
    {
        if (window.opener && window.opener.WinManager)
        {
            WinManager.pwm = window.opener.WinManager;
        }
        else if ((parent != window) && (parent.WinManager))
        {
            WinManager.pwm = parent.WinManager;
        }
        else if(top.frames["main"] && top.frames["main"].WinManager)
        {
            WinManager.pwm = top.frames["main"].WinManager;
        }
        else
        {
            //cant access the WinManager, so just return a blank object to prevent script errors
            WinManager.pwm = {
                mockWM: true,
                reinstateWindow: function(){},
                checkStylingOutput: function(){},
                resolveFormTarget: function(objWin, objForm, options, arrWinDetails){objForm.target = '_blank'; objForm.submit()},
                replaceOptionChosen: function(){},
                openNewChildWindow: function(objWin, strUrl, arrWinDetails){objWin.open(strUrl);},
                setUnsaved: function(){},
                clearUnsaved: function(){},
                confirmWinClosure: function(){},
                closeWindow: function(){},
                confirmLogout: function(){},
                processLicenceUpgrade: function(){},
                isWindowOpenActual: function(){ return false; },
                getOpenWindowsActual: function(){ return new Array(); },
                getVersionDetail: function() { return null; },
                getLicenceDetail: function() { return null; },
                displayMessageBox: function(options) {

                    var HEADER_STRIP_HEIGHT = 37;

                    if (typeof(options.fadeIn) == 'undefined')
                        options.fadeIn = true;
                    var doc = options.objWin.document;

                    if (doc.getElementById('winManagerMsgBox') != null) //already present
                    {
                        WinManager.clearMessageBox(options.objWin);
                        options.fadeIn = false;
                    }

                    var gvs = (typeof(getViewportSize) == 'function') ? getViewportSize : ((typeof(hyf.util.getViewportSize) == 'function') ? hyf.util.getViewportSize : null);

                    if (gvs == null)
                        return;

                    var screenSize = gvs(doc, true);

                    if (typeof(screenSize.scrollTop) == 'undefined')
                    {
                        screenSize.scrollTop = 0;
                        screenSize.scrollLeft = 0;
                    }

                    //determine the initial size of the message window
                    var boxWidth = screenSize.width / 2;
                    var boxHeight = screenSize.height / 3;

                    //create the message container and centre ont he screen
                    var container = doc.createElement('div');
                    container.setAttribute('id', 'winManagerMsgBox');
                    container.style.position = 'absolute';
                    container.style.top = (((screenSize.height - boxHeight) / 2) + screenSize.scrollTop) + 'px';
                    container.style.height = boxHeight + 'px';
                    container.style.left = (((screenSize.width - boxWidth) / 2) + screenSize.scrollLeft) + 'px';
                    container.style.width = boxWidth + 'px';

                    //create a div to blur all the current contents
                    var blur = doc.createElement('div');
                    blur.setAttribute('id', 'winManagerMsgBlur');
                    blur.style.position = 'absolute';
                    blur.style.top = screenSize.scrollTop + 'px';
                    blur.style.left = screenSize.scrollLeft + 'px';
                    blur.style.height = screenSize.height + 'px';
                    blur.style.width = screenSize.width + 'px';

                    doc.body.appendChild(blur);
                    doc.body.appendChild(container);


                    //create the msg box content structure (title bar, ok/cancel buttons etc)
                    containerHTML = '';
                    //check if we need to apply a frame underneath to stop bleed through. This is only needed for older II browsers
                    if ((typeof(dojo) == 'undefined') || (dojo.isIE < 9))
                        containerHTML += '<iframe id="winManagerMsgFrame" name="winManagerMsgFrame" src="about:blank" style="width :100%; height : ' + (container.offsetHeight + 2) + 'px; border : none;" frameBorder="0" title="winManagerMsgFrame"></iframe>';

                    containerHTML += '<div id="winManagerMsgDiv"><div id="winManagerMsgHeader">';
                    containerHTML += '<a href="#" onclick="WinManager.clearMessageBox(null, \'cancel\');return false;" class="dialogCloseBtn" title="Close"><span>Close</span></a>';

                    if (typeof(options.title) == 'string')
                        containerHTML += '<h3>' + options.title + '</h3>';

                    var msgContainerHeight = container.offsetHeight - HEADER_STRIP_HEIGHT;

                    containerHTML += '</div><div id="winManagerMsgContainer" style="height: ' + msgContainerHeight + 'px">';
                    containerHTML += options.content + '</div>';
                    containerHTML += '</div>';

                    container.innerHTML = containerHTML;

                    //fade it in if needed
                    if ((typeof(dojo) != 'undefined') && options.fadeIn)
                    {
                        container.style.opacity = 0;
                        dojo.fadeIn({node: container}).play();
                    }

                    if (typeof(options.objWin.WinManager.clickNotClosure) != 'undefined')
                        options.objWin.WinManager.attachEvent(container, "onclick", options.objWin.WinManager.clickNotClosure);
                    options.objWin.WinManager.attachEvent(container, 'onclick', options.objWin.WinManager.cancelPropagation);

                },
                loadIntoMessageBox: function() {},
                clearMessageBox: function(objWin) {

                    if ((typeof(objWin) == 'undefined') || (objWin == null) || (!objWin.document))
                        objWin = window;

                    var doc = objWin.document;

                    var msg = doc.getElementById('winManagerMsgBox');
                    if (msg != null)
                    {
                        objWin.WinManager.destroyDojoWidgets(msg);
                        doc.body.removeChild(msg);
                    }
                    var blur = doc.getElementById('winManagerMsgBlur');
                    if (blur != null)
                    {
                        doc.body.removeChild(blur);
                    }
                },
                isMessageBoxVisible: function() { return false; },
                notifyMessageBoxClosure: function() {},
                setMessageBoxButtons: function() {},
                setDialogButtons: function() {},
                setMessageBoxButtonDisabled: function() {},
                setDialogButtonDisabled: function() {},
                notifyDialogAction: function() {},
                handleDialogAction: function() {},
                showLoadingMessage: function() {},
                clearLoadingMessage: function() {},
                setSupportedOps: function() {},
                getWindowDisplayMode: function() {return 'popup';},
                getProjectInformation: function() {return 'null';},
                status: { showMessage: function() {}, removeMessage: function(){}},
                fullWindowClose: function(objWin) {objWin.close();},
                runWhenFocused: function(func) {func();},
                focusWindow: function() {},
                getPreferences: function() { return null; },
                getSystemProperty: function(prop, callback) {callback(prop)},
                keys: { attach: function() {}, detach: function() {}, processKeyEvent: function() {}},
                setScrollableContainers: function() {},
                isSaveAllowed: function() { return true; },
                alert: function(objOptions) { alert(objOptions.strMsg); },
                userConfirmed: function(objOptions) { if (confirm(objOptions.strMsg)) objOptions.objConfirmHandler(); else if (objOptions.objCancelHandler) objOptions.objCancelHandler(); },
                prmopt: function(objOptions) { var val = prompt(objOptions.strMsg, objOptions.strDefault); objOptions.objConfirmHandler(val);},
                navigation: { openRules: function(){}, openPageDesign: function(){}, openPagePreview: function(){}, openXStoreDocument: function(){}, openNonXStoreDocument: function(){}, },
                message: { get: function(a) {return a;}, load: function(){}}
            };
        }
    }

    return WinManager.pwm;
}

/** Set a simple flag to indicate whether we are successfully connected to the main WinManager. */
WinManager.connected = !WinManager.getParentWinManager().mockWM;

/**
 * Gets the display mode setting for the given window.
 * This indicates whether the window is in a tab or not.
 * @return current display mode - 'tab' or 'popup', or null
 */
WinManager.getWindowDisplayMode = function(objWin)
{
    if (typeof(objWin) == 'undefined')
        objWin = window;

    return WinManager.getParentWinManager().getWindowDisplayMode(objWin);
}

/**
 * Get the details of the currently open project.
 * @return an object with properties:  user, workspace, product, blueprint_location, project, project_name, xml
 */
WinManager.getProjectInformation = function()
{
    return WinManager.getParentWinManager().getProjectInformation();
}

/**
 * Reinstates the window from the reusable list to the main list of windows.
 * This should be one of the main windows such as FM unloaded when navigating deeper
 * @param objWin Reference of main window being searched for in the reusable windows list
 * Delegates this to the top-level window.
 */
WinManager.reinstateWindow = function(objWin)
{
    //Delegate call to the parent window or the top level main window to ensure central management via the win manager
    WinManager.getParentWinManager().reinstateWindow(objWin);
}
/** makes sure the winamanger child styling has been ouput in the given window. */
WinManager.checkStylingOutput = function(objWin)
{
    WinManager.getParentWinManager().checkStylingOutput(objWin);
}

/**
* Every time a new window opens attempt to recover it from the reusable list just in case there was a preceeding involuntary unload
*/
if (WinManager.managedWin)
    WinManager.reinstateWindow(window);
else
    WinManager.checkStylingOutput(window);

/**
 * Obtains/parses the necessary information in order to conduct a controlled post
 * @param objForm The form to be submitted
 * @param strWinDetails One or more string parameters describing the window to open
 * eg resolveFormTargetStart(myForm, 'FormMaker', 'MyProject');
 *    resolveFormTargetStart(myForm, 'RuleMaker', 'MyProject', 'MyPattern', 'MyNode');
 * Delegates this to the top-level window.
 */
WinManager.resolveFormTargetStart = function(objForm, strWinDetails)
{
    var details = new Array();
    for (var i = 1; i < arguments.length; i++)
    {
        details[details.length] = arguments[i];
    }

    WinManager.resolveFormTarget(window, objForm, null, details);
}

/**
 * Obtains/parses the necessary information in order to conduct a controlled post
 * @param objForm The form to be submitted
 * @param options An object specifiying any advanced options required.  This currently supports the following properties:
 *      windowSettings: String detailing the settings to apply to the new window, eg sizing. This is the third param to the window.open call
 *      duplicateApproach: What to do if the window is already open. Must be either: 'prompt' (the default), 'replace', 'new', 'show'
 *      retainOpener: Boolean indicating whether the new windows opener property must not be altered. By default this will be false, and the
 *                    new windows opener will be the main WinManager window.
 *      displayMode: 'tab' or 'popup' to set how the window should be displayed.
 *      onOpen: function to be called once the window has been opened.
 * @param strWinDetails One or more string parameters describing the window to open
 * eg resolveFormTargetStart(myForm, options, 'FormMaker', 'MyProject');
 *    resolveFormTargetStart(myForm, options, 'RuleMaker', 'MyProject', 'MyPattern', 'MyNode');
 * Delegates this to the top-level window.
 */
WinManager.resolveFormTargetStartWithOptions = function(objForm, options, strWinDetails)
{
    var details = new Array();
    for (var i = 2; i < arguments.length; i++)
    {
        details[details.length] = arguments[i];
    }

    WinManager.resolveFormTarget(window, objForm, options, details);
}


/**
 * Obtains/parses the necessary information in order to conduct a controlled post
 * Delegates this to the top-level window.
 * @param objWin The window object that initiated the call.
 * @param objForm The form to be submitted
 * @param arrWinDetails An array string parameters describing the window to open
 * @private - resolveFormTargetStart should always be called instead
 */
WinManager.resolveFormTarget = function(objWin, objForm, options, arrWinDetails)
{
    WinManager.getParentWinManager().resolveFormTarget(objWin, objForm, options, arrWinDetails);
}

WinManager.replaceOptionChosen = function(objWin, option)
{
    WinManager.getParentWinManager().replaceOptionChosen(objWin, option);
}

/**
 * Main funtion that manages the opening of new windows, resulting from links.
 * @param strURL URL of the new window
 * @param strWinDetails One or more string parameters describing the window to open
 * eg openNewChildWindowStart(url, 'FormMaker', 'MyProject');
 *    openNewChildWindowStart(url, 'RuleMaker', 'MyProject', 'MyPattern', 'MyNode');
 */
WinManager.openNewChildWindowStart = function(strUrl, strWinDetails)
{
    var details = new Array();
    for (var i = 1; i < arguments.length; i++)
    {
        details[details.length] = arguments[i];
    }

    WinManager.openNewChildWindow(window, strUrl, details);
}

/**
 * Main funtion that manages the opening of new windows, resulting from links.
 * @param strURL URL of the new window
 * @param options An object specifiying any advanced options required.  This currently supports the following properties:
 *      windowSettings: String detailing the settings to apply to the new window, eg sizing. This is the third param to the window.open call
 *      duplicateApproach: What to do if the window is already open. Must be either: 'prompt' (the default), 'replace', 'new', 'show'
 *      retainOpener: Boolean indicating whether the new windows opener property must not be altered. By default this will be false, and the
 *                    new windows opener will be the main WinManager window.
 *      displayMode: 'tab' or 'popup' to set how the window should be displayed.
 * @param strWinDetails One or more string parameters describing the window to open
 * eg openNewChildWindowStartWithOptions(myForm, options, 'FormMaker', 'MyProject');
 *    openNewChildWindowStartWithOptions(myForm, options, 'RuleMaker', 'MyProject', 'MyPattern', 'MyNode');
 * Delegates this to the top-level window.
 */
WinManager.openNewChildWindowStartWithOptions = function(strUrl, options, strWinDetails)
{
    var details = new Array();
    for (var i = 2; i < arguments.length; i++)
    {
        details[details.length] = arguments[i];
    }

    WinManager.openNewChildWindow(window, strUrl, details, options);
}

/**
 * Main funtion that manages the opening of new windows, resulting from links.
 * Delegates this to the top-level window.
 * @param objWin The window object that initiated the call.
 * @param strURL URL of the new window
 * @param arrWinDetails An array of string parameters describing the window to open
 * @private - openNewChildWindowStart should always be called instead
 */
WinManager.openNewChildWindow = function(objWin, strUrl, arrWinDetails, objOptions)
{
    WinManager.getParentWinManager().openNewChildWindow(objWin, strUrl, arrWinDetails, objOptions);
}


/**
 * Check if the given window is already open or not.
 * @param strWinDetails One or more string parameters describing the window to check for.
 * eg isWindowOpen('FormMaker', 'MyProject');
 *    isWindowOpen('RuleMaker', 'MyProject', 'MyPattern', 'MyNode');
 * @return boolean indicating whether this window is open or not.
 */
WinManager.isWindowOpen = function(strWinDetails)
{
    var details = new Array();
    for (var i = 0; i < arguments.length; i++)
    {
        details[details.length] = arguments[i];
    }

    return WinManager.isWindowOpenActual(window, details);
}

/**
 * Check if the given window is already open or not.
 * @param objWin The window object that initiated the call.
 * @param arrWinDetails Array of details for the window.
 * @return boolean indicating whether this window is open or not.
 * @private - use isWindowOpen instead.
 */
WinManager.isWindowOpenActual = function(objWin, arrWinDetails)
{
    return WinManager.getParentWinManager().isWindowOpenActual(objWin, arrWinDetails);
}


/**
 * Returns an array of window objects for each open window matching the given params
 * Use isWindowOpen to just check if there is a window open.
 * @param strWinDetails One or more string parameters describing the window to check for.
 * eg getOpenWindows('FormMaker', 'MyProject');
 *    getOpenWindows('RuleMaker', 'MyProject', 'MyPattern', 'MyNode');
 * @return array of window objects.
 */
WinManager.getOpenWindows = function(strWinDetails)
{
    var details = new Array();
    for (var i = 0; i < arguments.length; i++)
    {
        details[details.length] = arguments[i];
    }

    return WinManager.getOpenWindowsActual(window, details);
}

/**
 * Returns an array of window objects for each open window matching the given params
 * @param objWin The window object that initiated the call.
 * @param arrWinDetails Array of details for the window.
 * @return array of window objects.
 * @private - use getOpenWindows instead.
 */
WinManager.getOpenWindowsActual = function(objWin, arrWinDetails)
{
    return WinManager.getParentWinManager().getOpenWindowsActual(objWin, arrWinDetails);
}

/**
 * Adds details about the window ot the given URL string, and returns the updated string.
 * This will add a WM_WIN_NAME parameter, and potentially a WM_WIN_SUFFIX one if required.
 * @param strUrl The original URL to add the details to.
 * @param objWin The window object to add the details from. (Not normally needed to be passed in)
 * @return The updated URL string.
 */
WinManager.addWinDetailsToSubmitURL = function(strUrl, objWin)
{
    if ((WinManager.managedWin) && ((typeof(objWin) == 'undefined') || (objWin == null)))
        objWin = window;

    return WinManager.getParentWinManager().addWinDetailsToSubmitURL(strUrl, objWin);

}



/**
 * Sets the bUnsaved flag to true to indicate changes have occurred within the window objWin
 * @param objWin Window reference for which the unsaved flag should be set
 * Call is cascaded up to parent windows
 */
WinManager.setUnsaved = function(objWin)
{
    WinManager.getParentWinManager().setUnsaved(objWin);
}

/**
 * Clears the bUnsaved flag (sets to false) to indicate there are no changes within the window objWin
 * @param objWin Window reference for which the unsaved flag should be cleared
 */
WinManager.clearUnsaved = function(objWin)
{
    WinManager.getParentWinManager().clearUnsaved(objWin);
}

/**
 * Flag to indicate whether a close of the window was requested or whether an involuntary event was raised
 * @param bClose Boolean to indicate genuine closure request or not
 */
WinManager.setGenuineCloseFlag = function(bClose)
{
    WinManager.bGenuineClose = bClose;
}

/**
 * Determines whether a closure request originated due to navigation activity within the same window.
 * Primarily resulting from click on anchors. Where anchors call javascript code, without navigating away
 * this should result in a click rather than a closure request
 * @param e Event raised by the element that was clicked
 */
WinManager.clickNotClosure = function(e)
{
    //Identify the source of the click
    var eTarget;
    if (!e)
    {
        var e = window.event;
    }
    if (e.target)
    {
        eTarget = e.target;
    }
    else if (e.srcElement)
    {
        eTarget = e.srcElement;
    }

    //This only needs to apply to IE as other browsers do not seem
    //to treat anchor javascript hrefs as going to a different page
    if (navigator.appName == 'Microsoft Internet Explorer')
    {

        //check if the target has a parent anchor
        var anchor = eTarget;
        while ((anchor != null) &&
               (anchor != document.body) &&
               (anchor != document.documentElement) &&
               (anchor.tagName != null) &&
               (anchor.tagName.toLowerCase() != 'a'))
        {
            anchor = anchor.parentNode;
        }

        //Only interested in anchor element with href attributes containing javascript
        if (anchor != null &&
            anchor != document.body &&
            anchor.getAttribute("href") &&
            anchor.href.substring(0, 10).toLowerCase() == "javascript")
        {
            //This is not genuine closure request
            WinManager.setGenuineCloseFlag(false);
        }
    }
}

/**
* Performs a check during requested closure to ensure unsaved information is not lost
* @param objWin Reference of window that requires closure
* Delegated to parent windows
*/
WinManager.confirmWinClosure = function(objWin)
{
    var msg = WinManager.getParentWinManager().confirmWinClosure(objWin);
    return msg;
}

/**
* Start of the recursive step to ensure a genuine closure was requested.
* If a genuine closure was requested, ensure orderly closure by checking for unsaved data
*/
WinManager.confirmWinClosureStart = function()
{
    var msg;
    if (WinManager.bGenuineClose)
    {
        msg = WinManager.confirmWinClosure(window);
        //alert(msg);
        if ((typeof(msg) != 'undefined') && window.event)
            window.event.returnValue = msg;

    }
    WinManager.bGenuineClose = true;

    return msg;
}

if (WinManager.managedWin)
{
    var mode = WinManager.getWindowDisplayMode();
    //Only attach these events if this window is not in 'tab' mode
    if (mode != 'tab')
    {
        WinManager.attachEvent(document, "onclick", WinManager.clickNotClosure);
        //WinManager.attachEvent(window, "onbeforeunload", WinManager.confirmWinClosureStart);
        window.onbeforeunload = WinManager.confirmWinClosureStart;
    }
}

/**
* Closes window using the supplied reference
* @param objWin Reference of window that requires closure
* Call is delegated to parent windows
*/
WinManager.closeWindow = function(objWin)
{
    WinManager.getParentWinManager().closeWindow(objWin);
}

/**
* Start of the resursive step to handle window closure request
*/
WinManager.closeWindowStart = function()
{
    WinManager.closeWindow(window);
}
if (WinManager.managedWin)
{
    WinManager.attachEvent(window, "onunload", WinManager.closeWindowStart);
}



/**
 * This function will actually close the specified window.
 * This will close the window (and remove the tab if needed), which will cause
 * the above closeWindow method to fire to update the metadata accordingly.
 * @param objwin (Optional) window object to close.  Will default to the current window
 */
WinManager.fullWindowClose = function(objWin)
{
    if (typeof(objWin) == 'undefined')
        objWin = window;

    WinManager.getParentWinManager().fullWindowClose(objWin);
}



/**
 * Returns the XML document detailing the licence in use.
 */
WinManager.getLicenceDetail = function()
{
    return WinManager.getParentWinManager().getLicenceDetail();
}
/**
 * Returns the XML document detailing the WebMaker version in use.
 */
WinManager.getVersionDetail = function()
{
    return WinManager.getParentWinManager().getVersionDetail();
}





/**
 * Displays a message box on the current window, containing the provided content.
 * Params can either be passed in in order, or by using a single config object with just the required settings.
 * The full list of options that can be provided in a config object is:
 *
 *        content A string containing the HTML content to display inside the message box
 *        size (Optional) Indicates the size of box to create.  Options are 'normal' (the default), 'big', 'full'
 *                      Any specific min or max widths will then be applied on top of this setting.
 *        minWidth/maxWidth (Optional) The min/max width (in pixels) to use for the displayed box
 *        minHeight/maxHeight (Optional) The min/max height (in pixels) to use for the displayed box
 *        fadeIn (Optional) boolean indicating whether to fade in the box or not
 *        title (Optional) The title to show on the message window
 *        buttons (Optional) Array of buttons to include in a bar at the bottom of the message. See WinManager.setMessageBoxButtons
 *                          for details on the format of this array.
 *        onClose (Optional) Function to call when the message is closed. (Regardless of reason)
 *        onXXXX (Optional) Function to call when a button with the given reason is called. eg onOk, or onCancel.
 *        objWin (Optional)The window object to create the message box on.
 *
 */
WinManager.displayMessageBox = function(content, title, width, height, sizeType, onClose)
{
    var options;
    if ((arguments.length == 1) && (typeof(content) == 'object'))
        options = content;
    else
        options = {content: content, title: title, width : width, height: height, sizeType: sizeType, onClose: onClose};

    if ((WinManager.managedWin) && ((typeof(options.objWin) == 'undefined') || (options.objWin == null)))
        options.objWin = window;

    WinManager.getParentWinManager().displayMessageBox(options);
}

/**
 * Submits the given form and sets up the response to be displayed in a message box
 * Params can either be passed in in order, or by using a single config object with just the required settings.
 * The full list of options that can be provided in a config object is:
 *      sourceForm The form object to submit
 *      + all properties (except content) listed under displayMessageBox
 */
WinManager.loadIntoMessageBox = function(sourceForm, title, width, height, sizeType, onClose)
{
    var options;
    if ((arguments.length == 1) && (typeof(sourceForm) == 'object'))
        options = sourceForm;
    else
        options = {sourceForm: sourceForm, title: title, width : width, height: height, sizeType: sizeType, onClose: onClose};

    if ((WinManager.managedWin) && ((typeof(options.objWin) == 'undefined') || (options.objWin == null)))
        options.objWin = window;

    WinManager.getParentWinManager().loadIntoMessageBox(options);
}


/**
 * Clears a message box displayed on the current window.
 */
WinManager.clearMessageBox = function(objWin, reason)
{
    if ((WinManager.managedWin) && ((typeof(objWin) == 'undefined') || (objWin == null) || (!objWin.document)))
        objWin = window;

    WinManager.getParentWinManager().clearMessageBox(objWin, reason);
}

/**
 * Checks if there is a message window currently displayed.
 * @return boolean true if there is, false otherwise.
 */
WinManager.isMessageBoxVisible = function(objWin)
{
    if ((WinManager.managedWin) && ((typeof(objWin) == 'undefined') || (objWin == null)))
        objWin = window;

    return WinManager.getParentWinManager().isMessageBoxVisible(objWin);
}

/**
 * Register the specified function to be called on close of the current message box.
 * You can return false from your function to stop the message box from closing.
 * Normally you will not want to specify a window object, so if you need to specify a reason
 * you can call this function as notifyMessageBoxClosure(func, reason)
 * @param function The function to call.
 * @param objWin (Optional) window object the message box is on
 * @param reason (Optional) The closure reason that ths function should be called for.
 *          This can be either 'ok' or 'cancel'.  If not provided, the function will be called
 *          on closure regardless of the reason.
 * @param toFront (Optional) If true this new function will be called before any existing functions
 *          when the specified reason occurrs. If false (the default) this new function will be called
 *          after any already defined.
 */
WinManager.notifyMessageBoxClosure = function(func, objWin, reason, toFront)
{
    if ((typeof(objWin) == 'string') && (typeof(reason) == 'undefined'))
    {
        reason = objWin;
        objWin = null;
        toFront = false;
    }
    else if ((typeof(objWin) == 'string') && (typeof(reason) == 'boolean') && (typeof(toFront) == 'undefined'))
    {
        toFront = reason;
        reason = objWin;
        objWin = null;
    }

    if ((WinManager.managedWin) && ((typeof(objWin) == 'undefined') || (objWin == null)))
        objWin = window;

    WinManager.getParentWinManager().notifyMessageBoxClosure(func, objWin, reason, toFront);
}


/**
 * Sets the set of buttons that should appear on the current message box shown in this window.
 * @param buttons Array of buttons to include in a bar at the bottom of the message. Each entry in the array can be either
 *                the string 'ok' or 'cancel', or an object with 'caption', and 'reason' properties.  In this case, the
 *                caption will be displayed on the button, and the reason used to indicate which button is pressed. eg if the
 *                reason is 'fred' you could pass in an 'onFred' function, or use notifyMessageBoxClosure(func, 'fred')
 *                at a later point to run code when the button is pressed.
 *                If the 'secondary' property is also included and true, the custom button will be given the secondary button styling.
 *                A 'title' property is also supported to provide text to show in a tooltip over the button
 *                If the 'disabled' property is true, then the button will be disabled.
 */
WinManager.setMessageBoxButtons = function(buttons, objWin)
{
    if ((WinManager.managedWin) && ((typeof(objWin) == 'undefined') || (objWin == null)))
        objWin = window;
    WinManager.getParentWinManager().setMessageBoxButtons(buttons, objWin);
}
/**
 * sets the set of dialog/popup buttons that should appear for this window.
 * Depending on whether this window is abstract dialog or a popup, these buttons will appear
 * at the bottom of the screen, or the bottom of the dialog area.
 * @param buttons Array of buttons to show. See setMessageBoxButtons for details.
 */
WinManager.setDialogButtons = function(buttons, objWin)
{
    if ((WinManager.managedWin) && ((typeof(objWin) == 'undefined') || (objWin == null)))
        objWin = window;
    WinManager.getParentWinManager().setDialogButtons(buttons, objWin);
}

/**
 * Sets the disabled state of the specified message box button.
 * @param reason The reason string for the button to set the disabled state of
 * @param disabled Boolean indicating whether it should be disabled or not.
 */
WinManager.setMessageBoxButtonDisabled = function(reason, disabled, objWin)
{
    if ((WinManager.managedWin) && ((typeof(objWin) == 'undefined') || (objWin == null)))
        objWin = window;
    WinManager.getParentWinManager().setMessageBoxButtonDisabled(reason, disabled, objWin);
}
/**
 * Sets the disabled state of the specified dialog button.
 * @param reason The reason string for the button to set the disabled state of
 * @param disabled Boolean indicating whether it should be disabled or not.
 */
WinManager.setDialogButtonDisabled = function(reason, disabled, objWin)
{
    if ((WinManager.managedWin) && ((typeof(objWin) == 'undefined') || (objWin == null)))
        objWin = window;
    WinManager.getParentWinManager().setDialogButtonDisabled(reason, disabled, objWin);
}




/**
 * register a function to be called when a particular dialog button is clicked.
 * See notifyMessageBoxClosure for details as the params are the same
 */
WinManager.notifyDialogAction = function(func, objWin, reason, toFront)
{
    if ((typeof(objWin) == 'string') && (typeof(reason) == 'undefined'))
    {
        reason = objWin;
        objWin = null;
        toFront = false;
    }
    else if ((typeof(objWin) == 'string') && (typeof(reason) == 'boolean') && (typeof(toFront) == 'undefined'))
    {
        toFront = reason;
        reason = objWin;
        objWin = null;
    }

    if ((WinManager.managedWin) && ((typeof(objWin) == 'undefined') || (objWin == null)))
        objWin = window;

    WinManager.getParentWinManager().notifyDialogAction(func, objWin, reason, toFront);
}
/**
 * Handles a specific dialog button action.
 */
WinManager.handleDialogAction = function(objWin, reason)
{
    if ((WinManager.managedWin) && ((typeof(objWin) == 'undefined') || (objWin == null)))
        objWin = window;

    WinManager.getParentWinManager().handleDialogAction(objWin, reason);
}




/**
 * cancels propagation of the event
 * @private
 */
WinManager.cancelPropagation = function(e)
{
    if (!e) var e = window.event;
    e.cancelBubble = true;
    if (e.stopPropagation) e.stopPropagation();
}

/**
 * cancels the default functionality of the event
 * @private
 */
WinManager.eventPreventDefault = function(e)
{
    if (!e) var e = window.event;
    e.returnValue = false;
    if (e.preventDefault) e.preventDefault();
}


/**
 * Attempts to destroy any dojo widgets that are present in the specified container
 * @param container The HTML container to destroy dojo widgets within. If not provided then the
 *              document body will be used instead, to destroy any widgets on the page.
 */
WinManager.destroyDojoWidgets = function(container, dijitObj)
{
    if (typeof(container) == 'undefined')
        container = document.body;

    var d = (dijitObj) ? dijitObj : ((typeof(dijit) != 'undefined') ? dijit : undefined);

    if ((typeof(d) != 'undefined') && (typeof(d.findWidgets) == 'function'))
    {
        var widgets = d.findWidgets(container);
        for (var i = 0; i < widgets.length; ++i)
        {
            var widget = widgets[i];
            widget.destroyRecursive();
            delete widget;
        }
    }
}




/**
 * Shows a loading message over the given container.
 * @param container (Optional) The HTML container to show a loading message over.
 *                  If not provided, then the whole page will be assumed.
 *                  If provided, the container must have an id.
 * @param msg (Optional) Text message to display in addition to the loading image.
 * @param blockFullUI (Optional) boolean.  If set to true (and container null), then the loading message
 *           will be shown across the whole WebMaker UI, rather than just this sub tab
 */
WinManager.showLoadingMessage = function(container, msg, blockFullUI)
{
    if ((typeof(container) == 'string') && (typeof(msg) == 'undefined'))
    {
        msg = container;
        container = null;
    }

    if ((typeof(blockFullUI) == 'boolean') && (blockFullUI))
        WinManager.getParentWinManager().showLoadingMessage(container, msg, true);
    else if (typeof(blockFullUI) != 'undefined')
        WinManager.getParentWinManager().showLoadingMessage(container, msg, blockFullUI);
    else
        WinManager.getParentWinManager().showLoadingMessage(container, msg, window);
}

/**
 * Clears the loading message curently being displayed for the given container
 * @param container (Optional) The HTML container to clear a loading message over.
 *                  If not provided, then the whole page will be assumed.
 *                  If provided, the container must have an id.
 * @param blockFullUI (Optional) boolean.  If set to true (and container null), then the loading message
 *           will be shown across the whole WebMaker UI, rather than just this sub tab
 */
WinManager.clearLoadingMessage = function(container, blockFullUI)
{
    if ((typeof(blockFullUI) == 'boolean') && (blockFullUI))
        WinManager.getParentWinManager().clearLoadingMessage(container, true);
    else if (typeof(blockFullUI) != 'undefined')
        WinManager.getParentWinManager().clearLoadingMessage(container, blockFullUI);
    else
        WinManager.getParentWinManager().clearLoadingMessage(container, window);
}


/**
 * Sets the set of operations that this current window supports.
 * this is used by the WinManager to configure the menus etc.
 * @param operations An array of operations supported, eg
 *          [{strId: "save_tab", bEnabled: true}, {strId: "preview", bEnabled: false }]
 * @param update (Optional) boolean indicating whether this list should update (be merged with) the existing
 *          list of operations or replace it.  Thw default is to replace.
 */
WinManager.setSupportedOps = function(operations, update, objWin)
{
    if (typeof(objWin) == 'undefined')
        objWin = window;

    WinManager.getParentWinManager().setSupportedOps(operations, update, objWin);
}



/**
 * Sets the specified function to be run when the current window is next focused.
 * If the window is already focused, then the fucntion will be run immediately,
 * unless runIfPossible is set to false.
 * @param func The function reference to run.
 * @param runIfPossible (Optional) Set to false to stop the function being run straight away if the
 *              window is already focused.  Instead it will be run when the window is blured and
 *              then refocused.  Defaults to true.
 */
WinManager.runWhenFocused = function(func, runIfPossible, objWin)
{
    if ((WinManager.managedWin) && (typeof(objWin) == 'undefined'))
        objWin = window;

    WinManager.getParentWinManager().runWhenFocused(func, runIfPossible, objWin);
}

/**
 * Makes sure that the current window is currently visible.
 */
WinManager.focusWindow = function(objWin)
{
    if ((WinManager.managedWin) && (typeof(objWin) == 'undefined'))
        objWin = window;

    WinManager.getParentWinManager().focusWindow(objWin);
}

/**
 * Gets the user/studio preferences.
 * If no parameter is provided this will return a map of all defined preferences (name to value)
 * If a preference name is provided, then this will return a string with that particular value.
 * @param prefName (Optional) The name of a specific preference to get the value for.
 * @return A map of all preferences, or a specific value, or null if not avaialble
 */
WinManager.getPreferences = function(prefName)
{
    return WinManager.getParentWinManager().getPreferences(prefName);
}


/**
 * Gets a system property value from the server.
 * As this is a server call, this will be an async operation with the function returning immediately, and then
 * the callback function called when the value has been returned.  This is needed because the given propName
 * can be a combination of system properties and static text etc, so we can't cache the results of this.
 * @param propName a string containing one or more system property values to convert.
 *              System proeprties should be in the format ${property-name}
 * @callback A function that will be called when the value has been retrieved.  This will be passed one
 *              parameter which is the propName string with the property values converted.
 */
WinManager.getSystemProperty = function(propName, callback)
{
    return WinManager.getParentWinManager().getSystemProperty(propName, callback);
}


/**
 * Sets the list of container IDs on the page that are scrollable.
 * The WinManager will use this to make sure that the scroll state of these containers is
 * maintained when switching tabs, as otherwise these generally scroll to the top.
 * @param containers An array of container IDs, eg ['container1'. 'container2']
 *      For more complex scenarios you can pass an object for each array item.  This should have a value property
 *      and a type property.  If the type is 'id', the value is assumed to be the container ID.
 *      If the type is 'script_fragment', the value is assumed to be a script fragment that should be evaluated to get the container.
 */
WinManager.setScrollableContainers = function(containers, objWin)
{
    if (typeof(objWin) == 'undefined')
        objWin = window;

    WinManager.getParentWinManager().setScrollableContainers(containers, objWin);
}

/**
 * Checks whether the current window is allowed to save any changes.
 * For example, if you dont have the project checked out then saving will not be allowed.
 * @param alertUser (Optional) If true, and save not allowed a message will be shown to the user.
 *                  Defaults to false.
 * @param objWin (Optional) The window object to check for.  Should not normally be provided.
 * @return boolean indicating if save is possible
 */
WinManager.isSaveAllowed = function(alertUser, objWin)
{
    if (typeof(objWin) == 'undefined')
        objWin = window;

    return WinManager.getParentWinManager().isSaveAllowed(alertUser, objWin);
}

/**
 * Sets the save in progress flag for the given window.
 * This is used to decide whether to autaomtically perform
 * a GIT commit operation when the changes are next cleared.
 * @param commitMsg (Optional)  The message to use for the auto commit.
 * @param objWin (Optional) The window object that is saving.  Should not normally be provided.
 */
WinManager.setSaveInProgress = function(commitMsg, objWin)
{
    if (typeof(objWin) == 'undefined')
        objWin = window;

    return WinManager.getParentWinManager().setSaveInProgress(commitMsg, objWin);
}





WinManager.status = {};
/**
 * Generic function for showing status messages
 *
 * The params can be provided as below, or by using a config object.
 *
 * @param msg A string containing the message to display.  This can contain HTML markup.
 * @param sticky (Optional) boolean flag indicating if this message should be set as the 'sticky' message
 *              If set, then this message will be reshown when the currently displayed message is hidden using
 *              the hideStatusMessage() method.  Only one message can be sticky, so setting this overrides
 *              any current sticky message
 * @param autohide (Optional) boolean flag indicating if this message should be automatically hidden after a period
 *              of time.  This should not be used with the sticky option.  If there is already a sticky message, then
 *              it will be reshown when this one is hidden.
 * @param detail (Optional) An HTML string to provide additional message details.  These will only be displayed when
 *              the user clicks a 'Details' link.
 * @param level (Optional) The level for this message - 'info', 'error', 'warning', 'in-progress'.  Defaults to info
 * @param highlight (Optional) boolean indicating whether we should draw attention to this new message.  Defaults to true for error level messages.
 * @param type (Optional) String specifying a type value for this message. (eg may use 'publish' for all messages related to publication.)
 */
WinManager.status.showMessage = function(msg, sticky, autohide, detail, level, highlight, type)
{
    var options;
    if ((arguments.length == 1) && (typeof(msg) == 'object'))
        options = msg;
    else
        options = {msg: msg, sticky: sticky, autohide: autohide, detail: detail, level: level, type: type, highlight: highlight};

    if ((WinManager.managedWin) && (!options.objWin))
        options.objWin = window;

    WinManager.getParentWinManager().status.showMessage(options);
}

/**
 * Removes currently displayed status messages.
 * By default this will just remove the current (most recent) message, but by providing additional options
 * you can be more specific about what gets removed.
 *
 * The params can be provided as below, or by using a config object.
 *
 * @param type (Optional) If provided, then only messages of the given type will be removed
 * @param level (Optional) If provided, then only messages of the given level will be removed
 * @param sticky (Optional) If specified and true only sticky messages will be removed, if false only non sticky messages will be removed.
 *                   If not specified all messages (sticky or otherwise) can be removed.
 * @param removeAll (Optional) If true then all matching messages will be removed, otherwise only the most recent match. (defaults to false)
 * @param objWin (Optional) The window object to clear the message from.  If not provided will default to messages for the current window.
 */
WinManager.status.removeMessage = function(type, level, sticky, removeAll, objWin)
{
    var options;
    if ((arguments.length == 1) && (typeof(type) == 'object'))
        options = type;
    else
        options = {sticky: sticky, level: level, type: type, removeAll: removeAll, objWin: objWin};

    if ((WinManager.managedWin) && (!options.objWin))
        options.objWin = window;

    WinManager.getParentWinManager().status.removeMessage(options);
}










/**
 * This package contains a generic mechanism for handling keyboard shortcuts.
 * The containing page can use the attach and detach methods to setup the requried shortcuts.
 */
WinManager.keys = {
    managed: new Array(),
    eventHandle: null
};

WinManager.attachEvent(window, "onload", function(){
        WinManager.keys.eventHandle = WinManager.attachEvent(document, 'onkeydown', WinManager.keys.processKeyEvent);
        WinManager.keys.eventHandle = WinManager.attachEvent(document, 'onkeyup', WinManager.keys.processKeyEvent);
});

/**
 * Attach the provided function to be called when the given key is pressed.
 * @param key The letter or keyCode of the key to detect.
 * @param func A reference to the fucntion to call when the key is pressed.
 * @param ctrl (Optional) Boolean indicating whether the ctrl key needs to also be pressed.
 * @param alt (Optional) Boolean indicating whether the alt key needs to also be pressed.
 * @param shift (Optional) Boolean indicating whether the shift key needs to also be pressed.
 * @param ignoreInControls (Optional) Boolean indicating whether the key event should be ignored if triggered
 *                  on an editable control (eg text box, textarea etc). Default false.
 * @param eventType (Optional) String indicating which type of key event this is for.  Currently supports 'keydown' or 'keyup'
 *                  Defaults to keydown if not provided
 */
WinManager.keys.attach = function(key, func, ctrl, alt, shift, ignoreInControls, eventType, objWin)
{

    if ((typeof(objWin) == 'undefined') && (WinManager.managedWin))
        objWin = window;

    WinManager.getParentWinManager().keys.attach(key, func, ctrl, alt, shift, ignoreInControls, eventType, objWin);
}

/**
 * Detach the provided function from being called when the given key is pressed.
 * @param key The letter or keyCode of the key to detect.
 * @param func A reference to the fucntion to call when the key is pressed.
 * @param ctrl (Optional) Boolean indicating whether the ctrl key needs to also be pressed.
 * @param alt (Optional) Boolean indicating whether the alt key needs to also be pressed.
 * @param shift (Optional) Boolean indicating whether the shift key needs to also be pressed.
 * @param ignoreInControls (Optional) Boolean indicating whether the key event should be ignored if triggered
 *                  on an editable control (eg text box, textarea etc). Default false.
 * @param eventType (Optional) String indicating which type of key event this is for.  Currently supports 'keydown' or 'keyup'
 *                  Defaults to keydown if not provided
 */
WinManager.keys.detach = function(key, func, ctrl, alt, shift, ignoreInControls, eventType, objWin)
{

    if ((typeof(objWin) == 'undefined') && (WinManager.managedWin))
        objWin = window;

    WinManager.getParentWinManager().keys.detach(key, func, ctrl, alt, shift, ignoreInControls, eventType, objWin);
}

/**
 * This gets called for the key event, and is responsible for seeing if it matches
 * any of the keys being managed, and if so calling the appropriate functions.
 * @return false If the event has been processed, and so shouldnt continue further, true otherwise
 * @private
 */
WinManager.keys.processKeyEvent = function(e, objWin)
{
    if ((typeof(objWin) == 'undefined') && (WinManager.managedWin))
        objWin = window;

    return WinManager.getParentWinManager().keys.processKeyEvent(e, objWin);
}


WinManager.tooltips = {};
/**
 * Called to attach any dynamic Tips from the Structure page for the current page.
 * The page id is the link to the tip structure file data used to then attach tips where appropriate.
 */
WinManager.tooltips.attachTipsToPage = function(pageId,win)
{
    if (!win)
        win = window;
    return WinManager.getParentWinManager().tooltips.attachTipsToPage(pageId,win);
}
/**
 * Called when the mouse moves onto the trigger container.
 * Finds the coordinates of the mouse, and then initialises the tooltip
 */
WinManager.tooltips.showTipMessage = function(e,immediate,win)
{
    if (!win)
        win = window;
    return WinManager.getParentWinManager().tooltips.showTipMessage(e,immediate,win);
}
/**
 * Called when the mouse moves off of the trigger container.
 * Initalise the timeout to hide the tooltip
 */
WinManager.tooltips.hideTipMessage = function(immediate)
{
    return WinManager.getParentWinManager().tooltips.hideTipMessage(immediate);
}


/**
 * Presents a simple Ok/Cancel-type message box requesting user confirmation.
 * @param objOptions {
 *       strMsg: [optional] Message describing the context of the confirmation request
 *       strTitle: [optional] Title for the confirmation dialogue
 *       strConfirm: [optional] Caption for the OK(Confirmation) button
 *       strCancel: [optional] Caption for the Canel button
 *       objConfirmHandler: [optional, but should be supplied] Handler function when the confirmation button is clicked
 *       objCancelHandler: [optional] Handler function when the cancel button is clicked
 *       objWin: [auto] Usually managed by the WinManager
 *   }
 */
WinManager.userConfirmed = function(objOptions)
{
    if ((typeof(objOptions.objWin) == 'undefined') && (WinManager.managedWin))
        objOptions.objWin = window;

    return WinManager.getParentWinManager().userConfirmed(objOptions);
}


/**
 * Generic function for showing an alert type message to the user.
 * This uses our WebMaker styling rather than relying on the standard browser functionality
 * that the users can choose to hide if they wish.
 *
 * @param objOptions {
 *       strMsg: [optional] Message describing the context of the confirmation request
 *       strTitle: [optional] Title for the alert dialogue
 *       strCaption: [optional] Caption for the OK(Confirmation) button
 *       objHandler: [optional] Handler function called when the alert dialog is closed
 *       objWin: [auto] Usually managed by the WinManager
 *   }
 *
 */
WinManager.alert = function(objOptions)
{
    if ((typeof(objOptions.objWin) == 'undefined') && (WinManager.managedWin))
        objOptions.objWin = window;

    WinManager.getParentWinManager().alert(objOptions);

}

/**
 * Presents a simple message box requesting a single value to be entered by the user.
 * This is a replacement for the standard window.prompt option.
 * @param objOptions {
 *       strMsg: [optional] Message describing the request
 *       strTitle: [optional] Title for the prompt dialogue
 *       strDefault: [optional] The default value to show in the text box
 *       strConfirm: [optional] Caption for the OK(Confirmation) button
 *       strCancel: [optional] Caption for the Cancel button
 *       objConfirmHandler: [optional, but should be supplied] Handler function when the confirmation button is clicked.  This will be passed a single param
 *                          containing the value entered into the prompt dialog.
 *       objCancelHandler: [optional] Handler function when the cancel button is clicked
 *       objWin: [auto] Usually managed by the WinManager
 *   }
 */
WinManager.prompt = function(objOptions)
{
    if ((typeof(objOptions.objWin) == 'undefined') && (WinManager.managedWin))
        objOptions.objWin = window;

    WinManager.getParentWinManager().prompt(objOptions);

}





/**
 * package for helper functions to open certain types of windows from anywhere in the studio.
 */
WinManager.navigation = {}

/**
 * Opens up the RuleMaker window for the specified node in the current project.
 *
 * @param patternId the ID of the pattern containing the node to open.
 * @param nodeId the ID of the node to open.
 * @param stateXML (Optional) An XML String defining the state document to pass to the opened window.
 */
WinManager.navigation.openRules = function(patternId, nodeId, stateXML, objWin)
{
    if (typeof(objWin) == 'undefined')
        objWin = window;

    WinManager.getParentWinManager().navigation.openRules(patternId, nodeId, stateXML, objWin);
}

/**
 * Opens up the FM Page Design window for the specified page in the current project.
 *
 * @param pageName the name of the page to open.
 */
WinManager.navigation.openPageDesign = function(pageName, objWin)
{
    if (typeof(objWin) == 'undefined')
        objWin = window;

    WinManager.getParentWinManager().navigation.openPageDesign(pageName, objWin);
}

/**
 * Opens up the FM Preview window for the specified page in the current project.
 *
 * @param pageName the name of the page to preview.
 */
WinManager.navigation.openPagePreview = function(pageName, objWin)
{
    if (typeof(objWin) == 'undefined')
        objWin = window;

    WinManager.getParentWinManager().navigation.openPagePreview(pageName, objWin);
}

/**
 * Opens the requested XStore document up for editing within a browser window.
 * This will use the preference setting to determine whether to use a tab or a dialog,
 * but it will ignore the external editor option - this will be treated as if popup was selected.
 *
 * @param xstoreName The name of the xstore containing the document to edit. (Should be 'blueprints')
 * @param collectionName The name of the collection containing the document to edit.
 * @param documentName The name of the document to edit.
 */
WinManager.navigation.openXStoreDocument = function(xstoreName, collectionName, documentName, objWin)
{
    if (typeof(objWin) == 'undefined')
        objWin = window;

    WinManager.getParentWinManager().navigation.openXStoreDocument(xstoreName, collectionName, documentName, objWin);
}

/**
 * Opens the requesting NON XStore document up for editing within a browser window.
 * This will use the preference setting to determine whether to use a tab or a dialog,
 * but it will ignore the external editor option - this will be treated as if popup was selected.
 *
 * @param docName The name of the file to edit.  This must be relative to the preview location defined for this project
 * @param changeCallback (Optional) The name of the function (in the calling window) that should be called whenever any
 *                      changes are saved to the opened document.
 */
WinManager.navigation.openNonXStoreDocument = function(docName, changeCallback, objWin)
{
    if (typeof(objWin) == 'undefined')
        objWin = window;

    WinManager.getParentWinManager().navigation.openNonXStoreDocument(docName, changeCallback, objWin);
}



WinManager.message = {}

/**
 * Returns the message string to display to the user for the given message id.
 *
 * This supports replacements in the string.  For example, assuming msgId maps to
 * the message string: 'Hello $1 and $2!', then calling this function as
 * get('msgId', 'Mickey', 'Minnie') will give
 * 'Hello Mickey and Minnie!'
 *
 * @param msgId The id of the message to retrieve eg fm.appmap.invalidName
 * @param replacements Any number of string values to insert into the message string.
 * @return The message string found, or an empty string if a match couldn't be found.
 */
WinManager.message.get = function(msgId, replacements)
{
    return WinManager.getParentWinManager().message.get.apply(null, arguments);
}

/**
 * Loads up all the message definitions from the given URL.
 * If this URL has already been loaded then nothing will be done.
 * The URL call must return a JSON object structure.
 * eg to define a msgId of fm.appmap.invalidName, it must return a structure like:
 * {fm: { appmap: {invalidName: "message here" }}}
 *
 * @param url The URL to load the message defintions from
 */
WinManager.message.load = function(url)
{
    WinManager.getParentWinManager().message.load(url);
}

WinManager.ConfigManager = {};
WinManager.ConfigManager.getConfig = function(strConfig) {
    return WinManager.getParentWinManager().ConfigManager.getConfig(strConfig);
}

WinManager.ConfigManager.setConfig = function(strConfig, objConfig) {
    return WinManager.getParentWinManager().ConfigManager.setConfig(strConfig, objConfig);
}


