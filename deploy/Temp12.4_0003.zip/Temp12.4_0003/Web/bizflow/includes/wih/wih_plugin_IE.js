var m_Session = null;
var m_Workitem;
var ReadOnly = 0;
var rtnCheckPassword = "false";
var wndPassword = null;
var wihCompleteOption = null;

function EnableButton()
{
	var bEnableTrue;
	var bEnableFalse;
	if (webStyleWihPlugin == "true")
	{
		bEnableTrue = true;
		bEnableFalse = false;
	}
	else
	{
		bEnableTrue = -1;
		bEnableFalse = 0;
	}

	var showPrevBtn = bEnableFalse;
	var showNextBtn = bEnableFalse;

	if (workitemCount > 0)
	{
		if (currentRow > 0)
		{
			showPrevBtn = bEnableTrue;
		}

		if (currentRow >= 0 && currentRow != workitemCount - 1)
		{
			showNextBtn = bEnableTrue;
		}

		if ((openPage == "INSTANCE" || openPage == "INSTANCERELOAD") && ReadOnly == 0)
		{
			showPrevBtn = bEnableFalse;
			showNextBtn = bEnableFalse;
		}
		else
		{
			// If whether there is any previous workitems that are not completed yet.
			// completedRows may have duplicate numbers (ex. 0:2:3:2), we need to check every numbers. Just counting is not enough.
			var completedRowIdArray = completedRows.split(":");
			if (completedRowIdArray.length > 0 && currentRow > 0)
			{
				var hasPrevWitem = false;
				for (var i = 0; i < currentRow; i++)
				{
					if (!isExist(completedRowIdArray, i))
					{
						hasPrevWitem = true;
						break;
					}
				}
				showPrevBtn = hasPrevWitem ? bEnableTrue : bEnableFalse;
			}
		}

		if (webStyleWihPlugin == "true")
		{
			ActionEnableButton("PrevWorkitem", showPrevBtn);
			ActionEnableButton("NextWorkitem", showNextBtn)
		}
		else
		{
			WorkitemHandler.EnableButton(5, showPrevBtn);
			WorkitemHandler.EnableButton(6, showNextBtn);
		}
	}
	else
	{
		if (webStyleWihPlugin == "true")
		{
			ActionEnableButton("PrevWorkitem", showPrevBtn);
			ActionEnableButton("NextWorkitem", showNextBtn)
		}
		else
		{
			WorkitemHandler.EnableButton(5, showPrevBtn);
			WorkitemHandler.EnableButton(6, showNextBtn);
		}
	}
}

function isWIHInstalled()
{
	if ('undefined' != typeof(HWAUCtrl) && null != HWAUCtrl && 'undefined' != typeof(HWAUCtrl.GetRV))
	{
		var wihVersion = HWAUCtrl.GetRV(ROOT_KEY, BIZFLOW_KEY, WORKITEM_HANDLER_VERSION_KEY, 80);
		if ("" == wihVersion || null == wihVersion)
		{
			newInstall = 1;
			wihVersion = "";
		}
		var arrVersion = wihVersion.split(";");

		if ("" != wihVersion)
		{
			if (arrVersion.length > 2)
			{
				wihVersion = arrVersion[0];
			}
		}

		return (compareVersion(WORKITEM_HANDLER_VERSION, wihVersion) >= 0);
	}
	return true;
}
function executeClientApp(appName, appParams)
{
	var au = null;

	if (BrowserDetect.isExplorer())
	{
		au = document.getElementById("HWAUCtrl");
		au.Run("open", "\%BIZFLOW_BIN\%\\" + appName,  appParams , -1, 0);
	}
	else
	{
		au = document.HWAUCtrl;
		params = "open," + "\%BIZFLOW_BIN\%\\" + appName + "," + appParams + ",-1,0";
		au.InvokeN("Run", "8,8,8,3,3", params);
	}
}

function executeUpgrd()
{
	var url = this.location.href;
	var idx = url.lastIndexOf(contextPath);
	if(-1 != idx)
	{
		url = url.substr(0, idx + contextPath.length);
	}

	executeClientApp("upgrd.exe", "/p /package WorkitemHandlerVersion /url " + url);
}

function window_onload()
{
	var currentOS = window.navigator.userAgent; // bug20596: vista support
	if (null != soapEndPoint && 1 < soapEndPoint.length)
	{
		var idx = soapEndPoint.lastIndexOf("/");
		if (-1 != idx)
		{
			WorkitemHandler.DefaultHtmlPath = soapEndPoint.substring(0, idx) + "/work";
		}
	}

   if("undefined" == typeof(useClientModuleInstallation) || useClientModuleInstallation) 
   {
		if (!isWIHInstalled())
		{
			openInstallWindow();
			_close();
			return;
		}
		else
		{
			var obj = document.getElementById("WorkitemHandler");
			if (obj.object == null)
			{
				// Sometime, workitem handler is installed but IE cannot create active x control due to some reason(?).
				// To avoid annoyance, prompt to user.
				if (currentOS.indexOf("MSIE 7") < 0)
				{ // bug20596:	vista support
					var answer = confirm(MSG_PLUGIN_WIH_INSTALL);
					if (answer)
					{
						openInstallWindow();
					}
					_close();
					return;
				} // bug20596: vista support
			}
			if(existCMVersionFile)
			{

				if (!isUpdateInstalled(WORKITEM_HANDLER_VERSION_KEY, patchWihVersion, patchCommonVersion))
				{
					installPatch(WORKITEM_HANDLER_VERSION_KEY, CMVersionInfoXMLPath);
					_close();
					return;
				}

				executeUpgrd();
			}
		}
   }

    try
	{
		WorkitemHandler.focus();

		var curLoc = location.href;
		var offset = curLoc.indexOf("/work/");
		var soapURI = curLoc.substring(0, offset) + "/rpcrouter";

		m_Session = new ActiveXObject("HWOX.HWSession");

		if(protocol == "SOAP")
		{
			if (null != soapEndPoint && 1 < soapEndPoint.length)
			{
				m_Session.URI = soapEndPoint;
			}
			else
			{
				m_Session.URI = soapURI;
			}

            m_Session.Protocol = 1;
		}
		else // protocol = TCP
		{
			m_Session.ServerIP = serverIP;
			m_Session.ServerPort = serverPort;
			m_Session.Protocol = 2;
		}

        m_Session.ForceProtocol = true;
		m_Session.SessionInfo = strSessionInfo;

		if (PKIEnabled != "")
		{
			m_Session.EnablePKI = ("TRUE" == PKIEnabled) ? true : false;
		}

		//Single-Request
		var bIsArchive = false;
		if (openPage == "ARCHIVE")
		{
			bIsArchive = true;
		}
		m_Workitem = m_Session.GetWorkitemByID(sid, pid, seq, bIsArchive);

		if (readonly == "-1")
		{
			ReadOnly = -1;
			WorkitemHandler.ReadOnlyMode = ReadOnly;
			m_Workitem.PrepareData(true)
		}
		else
		{
			ReadOnly = 0;
			WorkitemHandler.ReadOnlyMode = ReadOnly;
			m_Workitem.PrepareData(false)
		}

		if (webStyleWihPlugin == "true")
		{
			WorkitemHandler.UseToolBar = "0";
			WorkitemHandler.UseApplicationTab = "0";
		}
		else
		{
			WorkitemHandler.UseToolBar = "-1";
			WorkitemHandler.UseApplicationTab = "-1";
		}

        // bug20816 If UIStyle=Web is specified, it will display web ui for next app, user selection.  Otherwise, it display old c UI.
		// cs#7313 (cs#6841)
		WorkitemHandler.Platform = "Product=BizFlowJSP;Platform=Win32;Browser=IE;UIStyle=Web;OpenPage=" + openPageOfPlatform + ";Language=" + language + ";Timezone=" + timezone + ";TimeFormat=" + timeFormat + makeInitString() + ";FormContextPath=" + formContextPath + sBuffOpenWay

		WorkitemHandler.MDI = "CloseAnother";
		WorkitemHandler.Workitem = m_Workitem;

		if (webStyleWihPlugin == "true")
		{
			var bPKIEngineRegistered, bEnablePKI;
			bPKIEngineRegistered = m_Session.PKIEngineRegistered;
			bEnablePKI = m_Session.EnablePKI;
			if (bEnablePKI == true && bPKIEngineRegistered == true)
			{
				document.frmApplication.IsVisiblePKI.value = "1";
			}
			else
			{
				document.frmApplication.IsVisiblePKI.value = "0";
			}

			GetResponse();
			GetApplication();
		}

		EnableButton();

		processName = m_Workitem.ProcessName;
		activityName = m_Workitem.ActivityName;

		set_title();

		if (webStyleWihPlugin == "true")
		{
			window.setTimeout(function(){ActionReload()}, 1000);
			window.setTimeout(function(){ResAppReload()}, 1000);
		}
	}
	catch(e)
	{
		var errnum = "" + e.number;

		// check wih_plugin module - for IE
		if (errnum.indexOf("-2146827859") >= 0) // automation server - can't create object : wih not installed
		{
			if (currentOS.indexOf("MSIE 7") < 0)
			{ // bug20596:	vista support
				openInstallWindow();
				_close();
				return;
			} // bug20596: vista support
		}
		else if (errnum.indexOf("-2147217474") < 0)	// Already CheckOut Workitem
		{
			alert(e.description);
		}
		if (currentOS.indexOf("MSIE 7") < 0)
		{ // bug20596:	vista support
			onExit(true);
		} // bug20596: vista support
	}
}

function onExit(bExit)
{
	var wihOpener = getOpenerWindow();
	try
	{
		WorkitemHandler.DeleteContents();

		if (openPage == "WORK" || openPage == "page")
		{
			if (!bExit && currentRow >= 0)
			{
				if(typeof(wihOpener.getNextWorkItem) != 'undefined')
				{
					var wihOpener = getOpenerWindow();
					if(wihOpener && 0<=currentRow)
					{
						var wi = wihOpener.getNextWorkItem(bizcoveid);
						if(wi)
						{
							var nextUrl = contextPath + "/work/wih.jsp?sid="+wi.svrid;
							nextUrl += "&pid="+wi.procid;
							nextUrl += "&seq="+wi.witemseq;
							nextUrl += "&asq="+wi.actseq;
							nextUrl += "&bizcoveid=" + bizcoveid;
							nextUrl += "&openpage=" + openPage;
							nextUrl += "&currow=" + currentRow;
							nextUrl += "&bizcovecall=" + bizcovecall;
							parent.location.href = nextUrl;
							return;
						}
						else
						{
							if (wihOpener.reloadData)
							{
								wihOpener.reloadData();
							}
							else if (wihOpener.reloadPage)
							{
								wihOpener.reloadPage();
							}
							_close();
						}
					}
					else
					{
						if (wihOpener.reloadData)
						{
							wihOpener.reloadData();
						}
						else if (wihOpener.reloadPage)
						{
							wihOpener.reloadPage();
						}
						_close();
					}
				}
				else if(currentRow != workitemCount - 1)
				{
					delCurrentWIHInfo(oWIHInfo);
					window.setTimeout(function(){NavigateWorkitem('N')}, 100);
				}
			}
			else
			{
				var loc = wihOpener.location.href;
				if (loc.indexOf("sortcolset=y") > 0)
				{
					loc = loc.replace("sortcolset=y", "");
				}

				if (wihOpener.reloadData)
				{
					wihOpener.reloadData();
				}
				else if (wihOpener.reloadPage)
				{
					wihOpener.reloadPage();
				}
				else
				{
					if (loc.indexOf("action=refresh") > 0)
					{
						wihOpener.location.reload();
					}
					else
					{
						// Bug 17519 WIH is not getting closed after completing the work item :Firefox Browser
						// The following function does not exist in any bizflow web sources.
						//                            refreshOpener(loc+ "&action=refresh", "top.opener.location.reload()");
					}
				}
				_close();
			}
		}
		else if (openPage == "INSTANCERELOAD")
		{
			wihOpener.parent.frameDown.location.reload();
			_close();
		}
		else if (openPage == "INSTANCE" || openPage == "DEFINITION" || openPage == "ARCHIVE")
		{
			_close();
		}
		else if (openPage == "WORKLEFT")
		{
			wihOpener.location.reload();
			wihOpener.parent.parent.fralist.location.reload();
			_close();
		}
		else
		{
			_close();
		}
	}
	catch(e)
	{
		_close();
	}
}

function CheckPasswordForOpen()
{
	rtnCheckPassword = "false";
	var sUrl = contextPath + "/common/passwordframe.jsp";
	wndPassword = ShowWindow(sUrl, "wndPassword", TTL_CMM_CHECK_PASSWORD, 300, 140, "no", false);
}

function getCheckPasswordValue(value)
{
	if ("PORTAL" == __CALLER)
	{
		wndPassword.close();
	}
	else
	{
		closeModal(false);
	}
	if ("true" == value)
	{
		rtnCheckPassword = "true";

		if ("PORTAL" == __CALLER)
		{
			WorkitemHandler.CompleteOption = wihCompleteOption;
			if (wihCompleteOption == "Partial")
			{
				WorkitemHandler.RunActionCommandEx("SaveToServer", "", "async");
			}
			else
			{
				WorkitemHandler.RunActionCommandEx("Complete", "", "async");
			}
		}
	}
	else
	{
		rtnCheckPassword = "false";
	}
}

function NavigateWorkitem(flag)
{
	if (!callBackFlag)
	{
		window.setTimeout(function(){NavigateWorkitem(flag)}, 100);
		return;
	}

	oWIHInfo = new WorkitemInfo(nextServerID, nextProcessID, nextSequence, nextActivitySequence, nextPasswordFlag);

	if (oWIHInfo.PasswordFlag == "T")
	{
		CheckPasswordForOpen();

		if (rtnCheckPassword == "false")
		{
			if (actionID == "SaveToServer" || actionID == "Complete")
				onExit(true);
			else
				return;
		}
	}

	try
	{
		var bIsArchive = false;
		if (openPage == "ARCHIVE")
			bIsArchive = true;

		m_Workitem = m_Session.GetWorkitemByID(oWIHInfo.ServerID, oWIHInfo.ProcessID, oWIHInfo.Sequence, bIsArchive);

		if (m_Workitem.State != hwWorkitemComplete || WorkitemHandler.ReadOnlyMode == true)
		{
			WorkitemHandler.Workitem = m_Workitem;

			if (webStyleWihPlugin == "true")
			{
				GetResponse();
				GetApplication();
			}

			EnableButton();

			processName = m_Workitem.ProcessName;
			activityName = m_Workitem.ActivityName;

			set_title();

			if (webStyleWihPlugin == "true")
			{
				ActionReload();
				ResAppReload();
			}
		}
		else
		{
			if (flag == "P")
				oWIHInfo.Next();
			else
				oWIHInfo.Prev();
		}
	}
	catch(e)
	{
		var errnum = "" + e.number;
		var nIndex = errnum.indexOf("-2147217474", 0); // Already CheckOut Workitem

		if (nIndex < 0)
			alert(e.description);

		onExit(true);
	}
}

function RunActionCommand(ID)
{
	if (ID == "Complete" || ID == "SaveToServer")
	{
		WorkitemHandler.bContinue = "wait";
		WorkitemHandler.RunActionCommandEx(ID, "", "async");
	}
	else
	{
		WorkitemHandler.RunActionCommandEx(ID);
	}

	if (ID == "Comment")
	{
		ActionReload();
	}

	if (ID == "Attach")
	{
		if (WorkitemHandler)
			WorkitemHandler.focus();
	}
}

function AddAttachEDMS(DocList, MetaFileURL)
{
	WorkitemHandler.AddAttachEDMS(DocList, MetaFileURL);
}

function SetProcessVariableValue(name, value, displayValue)
{
	WorkitemHandler.SetProcessVariableValue(name, value, displayValue);
}

function GetProcessVariableString(type)
{
	return WorkitemHandler.GetProcessVariablesAsString(type);
}

function GetResponse()
{
	var ResponseString = "";
	var Responses;
	var ResCount;
	var i;
	Responses = m_Workitem.Responses;
	ResCount = Responses.Count;
	for (i = 1; i <= ResCount; i++)
	{
		ResponseString += Responses.Item(i).ID;
		ResponseString += delim1;
		ResponseString += Responses.Item(i).Name;
		ResponseString += delim2;
	}
	document.frmResponse.Responses.value = ResponseString;
	document.frmResponse.ResponseID.value = m_Workitem.ResponseID;
}

function GetApplication()
{
	var AppString = "";
	var Applications;
	var AppCount;
	var i;

	// AppName Or SubProc
	if (m_Workitem.ParentActivity.SubProcessType == hwSubProcessManualAsync || m_Workitem.ParentActivity.SubProcessType == hwSubProcessManualSync)
	{
		document.frmApplication.IsSubProcess.value = "true";
	}
	else
	{
		Applications = m_Workitem.Applications;
		AppCount = Applications.Count;
		for (i = 1; i <= AppCount; i++)
		{
			AppString += i;
			AppString += delim1;
			AppString += Applications.Item(i).Name;
			AppString += delim2;
		}
		document.frmApplication.AppList.value = AppString;
		document.frmApplication.IsSubProcess.value = "false";
	}
}

function ChangeResponse(ID)
{
	document.frmResponse.ResponseID.value = ID;
	m_Workitem.ResponseID = ID;
}

function ApplicationTabClick(TabIndex)
{
	WorkitemHandler.bContinue = "wait";
	WorkitemHandler.ApplicationTabClick(TabIndex);
}

var wndInstall = null;
function openInstallWindow()
{
	var url = contextPath + "/portal/common/installmodule.jsp";
	url += "?mxuri=";
	url += "/setup/wihsetup.xml".replace(/\//g, '%2F');
	url += "&cburi=";
	url += contextPath + "/checkmdls.jsp".replace(/\//g, '%2F');
	url + "&instnew=y";
	var width = 550;
	var height = 400;
	var left = (window.screen.availWidth - width) / 2;
	var top = (window.screen.availHeight - height) / 2;
	var features = "status=yes,toolbar=no,resizable=yes,scrollbars=no,left=" + left + "," + "top=" + top + "," + "width=" + width + "," + "height=" + height;
	wndInstall = window.open(url, "Install", features);
	wndInstall.focus();
}
