var timeOut = 0;
var apptimeOut = 0;
var callBackFlag = true;
var oArr;
var nextServerID;
var nextProcessID;
var nextSequence;
var nextActivitySequence;
var nextPasswordFlag;
var completedRows = "";

function getOpenerWindow()
{
	var opener;
	if (isModalWIHMode())
		opener = getModalCaller();
	else
		opener = top.opener;

	return opener;
}

function _close()
{
	if (isModalWIHMode())
	{
		closeWindow();
	}
	else
	{
		top.close();
	}
}

function delCurrentWIHInfo(oldWIHInfo)
{
	// remote script call
	callBackFlag = false;
	var serverURL = contextPath + "/_scriptlibrary/getworkitem.jsp";
	completedRows += currentRow + ":";
	currentRow++;
	RSExecute("setNextWorkItem", serverURL, "getWorkItem", currentRow, bizcoveid);
}

function reloadWIH() {
    var url = contextPath + "/work/wih.jsp?sid=" + nextServerID;
    url += "&pid=" + nextProcessID;
    url += "&seq=" + nextSequence;
    url += "&asq=" + nextActivitySequence;
    url += "&bizcoveid=" + bizcoveid;
    url += "&openpage=page";
    url += "&currow=" + currentRow;
    parent.location = url;
}

function setNextWorkItem(ret)
{
	RSClearContext();
	var arrRet = ret.split(":");
	nextServerID = (typeof arrRet[0] != 'undefined')?arrRet[0]:'';
	nextProcessID = (typeof arrRet[1] != 'undefined')?arrRet[1]:'';
	nextSequence = (typeof arrRet[2] != 'undefined')?arrRet[2]:'';
	nextActivitySequence = (typeof arrRet[3] != 'undefined')?arrRet[3]:'';
	nextPasswordFlag = (typeof arrRet[4] != 'undefined')?arrRet[4]:'';
//	callBackFlag = true;
    reloadWIH();
}

function makeInitString()
{
	var initData = "";

	initData = initData + ";FORCE_ENCRYPTION=";
	if (bForceEncryption)
		initData = initData + "T";
	else
		initData = initData + "F";

	initData = initData + ";PKI_INHERITANCE=";
	if (bPKIInterface)
		initData = initData + "T";
	else
		initData = initData + "F";

	initData = initData + ";HASH_ALGORITHMS=" + hashalgorithms;
	// alert('wih_plugin.js(74): bug26256, initData=' + initData);

	initData = initData + ";FORCE_DESCRIPTION=";
	if (bForceDescription)
		initData = initData + "T";
	else
		initData = initData + "F";

	initData = initData + ";EDMS_ENABLED=";
	if (bEDMSEnabled)
		initData = initData + "T";
	else
		initData = initData + "F";

	initData = initData + ";MONITOR_ENABLED=";
	if (monitorEnabled)
		initData = initData + "T";
	else
		initData = initData + "F";

	initData = initData + ";SAVE_ENABLED=";
	if (saveEnabled)
		initData = initData + "T";
	else
		initData = initData + "F";

	// bug25959
	initData = initData + ";FORM_STYLE=plugin";
//	initData = initData + FormStyle;

	return initData;
}

var delim1 = ":";
var delim2 = ";";

var wndEDMSList;
function openEDMSList()
{
	var sUrl = contextPath + "/edms/edmsframe.jsp?multi=true";

	var iWidth = 740;
	var iHeight = 550;
	ShowWindow(sUrl, "wndEDMSList", LBL_WIHP_ATTACH_EDMS, iWidth, iHeight, "no", false);
}

function onDocumentsSelected(myarray)
{
	if (1 == myarray.length)
	{
		if ("FOLDER" == myarray[0][9])
		{
			alert(MSG_CMM_INVALID_EDMS_FILE);
			return;
		}
	}

	var DocList = "";
	for (var i = 0; i < myarray.length; i++)
	{
		for (var j = 0; j < 11; j++)
		{
			if (myarray[i][j] == "")
				DocList += " " + String.fromCharCode(11);
			else
				DocList += myarray[i][j] + String.fromCharCode(11);
		}
	}

	AddAttachEDMS(DocList, "");
	top.parent.focus();
	if (BrowserDetect.isExplorer())
	{
		if (WorkitemHandler)
			WorkitemHandler.focus();
	}
}

var wndEDMSMeta;
function openMetaData(dmServerID)
{
	var sUrl = contextPath + "/edms/edmsmdonly.jsp?dmserverid=" + dmServerID;

	var iWidth = 560;
	var iHeight = 510;
	ShowWindow(sUrl, "wndEDMSMeta", TTL_EDMS_METADATA, iWidth, iHeight, "no", false);
}

function onMetaDataSend(myarray)
{
	var filePath = myarray[0];
	var curLoc = location.href;
	var offset = curLoc.indexOf("/work/");

	var r, re;
	re = /\//g;
	r = filePath.replace(re, "\\");
	filePath = r;

	var arrToken = filePath.split("\\");
	var metaURL = curLoc.substring(0, offset);
	for (var i = 4; i > 0; i--)
	{
		metaURL = metaURL + "/" + arrToken[arrToken.length - i];
	}
	AddAttachEDMS("", metaURL);
	top.parent.focus();
	if (BrowserDetect.isExplorer())
	{
		if (WorkitemHandler)
			WorkitemHandler.focus();
	}
}

var wndAdHoc;
function openAdHocRouting()
{
	var url = contextPath + "/adhoc/adhocframe.jsp?sid=" + nextServerID + "&pid=" + nextProcessID + "&asq=" + nextActivitySequence;
	var iWidth = 830;
	var iHeight;
	if (language == "en")
		iHeight = 555;
	else
		iHeight = 572;

	ShowWindow(url, "AdHocRouting", LBL_WIHP_ADHOCROUTING, iWidth, iHeight, "no", false);
}

function openSelectNextUser()
{
	// It needs to send current pv value to UI. Because it may not yet completed (not saved) but changed.
	var varStr = GetProcessVariableString(80);
	var url = contextPath + "/bizcoves/wih/processvariable_plugin.jsp?sid=" + nextServerID + "&pid=" + nextProcessID
			+ "&provType=user&readonly=" + readOnlyFlag + "&pv=" + escape(varStr);
	ShowWindow(url, "wndSelectNextUser", TTL_SELECT_PARTICIPANT_FOR_NEXT_ACTIVITY, 730, 250, "no", false);
}

function openSelectNextApp()
{
	var varStr = GetProcessVariableString(65);
	var url = contextPath + "/bizcoves/wih/processvariable_plugin.jsp?sid=" + nextServerID + "&pid=" + nextProcessID
			+ "&provType=application&readonly=" + readOnlyFlag + "&pv=" + escape(varStr);
	ShowWindow(url, "wndSelectNextUser", TTL_SELECT_APPLICATION_FOR_NEXT_ACTIVITY, 730, 250, "no", false);
}

function onProcessVariableChanged(pvList)
{
	if (typeof(pvList) == undefined || pvList == null)
		return;
	var pvArray = pvList.split("~|_");
	for (var i = 0; i < pvArray.length; i += 3)
	{
		SetProcessVariableValue(pvArray[i], pvArray[i + 1], pvArray[i + 2]);
	}
}


function WIH_OnKeyDown(KeyID)
{
	if (parent.WIH_action)
	{
		var a = parent.WIH_action.document.getElementsByTag('A');
		if(a)
		{
			a[0].focus();
		}
	}

}

function ActionEnableButton(ID, bEnable)
{
	var frmAction;
	var actionValue;

	eval("frmAction = document.frmActionEnableHideStateHighLight." + ID + ";");
	actionValue = frmAction.value;

	if (bEnable == false)
		frmAction.value = "0" + actionValue.substr(1, 3);
	else
		frmAction.value = "1" + actionValue.substr(1, 3);
	if (timeOut == 0)
	{
		window.setTimeout(function(){ActionReload()}, 1000);
		timeOut = 1;
	}
}

function ActionHideButton(ID, bHide)
{
	var frmAction;
	var actionValue;

	eval("frmAction = document.frmActionEnableHideStateHighLight." + ID + ";");
	actionValue = frmAction.value;

	if (bHide == false)
		frmAction.value = actionValue.substr(0, 1) + "0" + actionValue.substr(2, 2);
	else
		frmAction.value = actionValue.substr(0, 1) + "1" + actionValue.substr(2, 2);

	if (timeOut == 0)
	{
		window.setTimeout(function(){ActionReload()}, 1000);
		timeOut = 1;
	}
}

function ActionSetButtonState(ID, State)
{
	var frmAction;
	var actionValue;

	eval("frmAction = document.frmActionEnableHideStateHighLight." + ID + ";");
	actionValue = frmAction.value;

	if (State == 0)
		frmAction.value = actionValue.substr(0, 2) + "0" + actionValue.substr(3, 1);
	else
		frmAction.value = actionValue.substr(0, 2) + "1" + actionValue.substr(3, 1);

	if (timeOut == 0)
	{
		window.setTimeout(function(){ActionReload()}, 1000);
		timeOut = 1;
	}
}

function ActionHighLightButton(ID, bHighLight)
{
	var frmAction;
	var actionValue;

	eval("frmAction = document.frmActionEnableHideStateHighLight." + ID + ";");
	actionValue = frmAction.value;

	if (bHighLight == false)
		frmAction.value = actionValue.substr(0, 3) + "0";
	else
		frmAction.value = actionValue.substr(0, 3) + "1";
	if (timeOut == 0)
	{
		window.setTimeout(function(){ActionReload()}, 1000);
		timeOut = 1;
	}
}

function ApplicationTabSelected(SelectedTab)
{
	if (document.frmApplication.SelectedTab.value == SelectedTab)
		return;
	if (SelectedTab == "-1")
		return;

	document.frmApplication.SelectedTab.value = SelectedTab;
	if (apptimeOut == 0)
	{
		window.setTimeout(function(){ResAppReload()}, 1000);
		apptimeOut = 1;
	}
}

//Bug 19920.  OfficeEngine 2.0 only supports IE.
function continueComplete()
{
	if (actionID == "Complete")
	{
		var url = contextPath + "/_scriptlibrary/custom_wih_action.jsp";
		RSExecute("getCustomCompleteActionResultCallBack",
				url,
				"getCustomCompleteActionResult",
				pid, asq, seq);
		return false;
	}
	else
	{
		return true;
	}
}

function getCustomCompleteActionResultCallBack(ret)
{
	RSClearContext();
	if (isIE)
	{
		if (ret == "success")
		{
			WorkitemHandler.bContinue = "complete";
		}
		else
		{
			WorkitemHandler.bContinue = "stop";
			alert(ret);
		}
	}
}

var oReadOnlyStateInfo = null;
var oCheckOutUserNameInfo = null;
var oViewStateInfo = null;
var oPKIStateInfo = null;
var oPrevPKIStateInfo = null;
function ApplicationTabStateChanged(StateType, CurrentTab, State, CheckOutUserName)
{
	if (StateType == "AppState")
	{
		if (!oReadOnlyStateInfo)
		{
			oReadOnlyStateInfo = new AppStateInfo(document.frmApplication.AppStateReadOnlyList.value);
		}
		oReadOnlyStateInfo.SetAppState("ReadOnly", CurrentTab, State);
		document.frmApplication.AppStateReadOnlyList.value = oReadOnlyStateInfo.AppStateInfo;

		if (!oCheckOutUserNameInfo)
		{
			oCheckOutUserNameInfo = new AppStateInfo(document.frmApplication.AppCheckOutUserNameList.value);
		}
		oCheckOutUserNameInfo.SetAppState("CheckOutUserName", CurrentTab, CheckOutUserName);
		document.frmApplication.AppCheckOutUserNameList.value = oCheckOutUserNameInfo.AppStateInfo;

		if (!oViewStateInfo)
		{
			oViewStateInfo = new AppStateInfo(document.frmApplication.AppStateViewList.value);
		}
		oViewStateInfo.SetAppState("View", CurrentTab, State);
		document.frmApplication.AppStateViewList.value = oViewStateInfo.AppStateInfo;
	}
	else if (StateType == "PKIState")
	{
		// PKI State
		if (State % 2 == 1)
		{
			if (!oPKIStateInfo)
			{
				oPKIStateInfo = new AppStateInfo(document.frmApplication.AppPKIList.value);
			}
			oPKIStateInfo.SetAppState("PKI", CurrentTab, State);
			document.frmApplication.AppPKIList.value = oPKIStateInfo.AppStateInfo;
		}
			// Prev PKI State
		else
		{
			if (!oPrevPKIStateInfo)
			{
				oPrevPKIStateInfo = new AppStateInfo(document.frmApplication.AppPrevPKIList.value);
			}
			oPrevPKIStateInfo.SetAppState("PKI", CurrentTab, State);
			document.frmApplication.AppPrevPKIList.value = oPrevPKIStateInfo.AppStateInfo;
		}
	}
	else
	{
		return;
	}
	if (apptimeOut == 0)
	{
		window.setTimeout(function(){ResAppReload()}, 1000);
		apptimeOut = 1;
	}
}

function ActionReload()
{
	if (parent.WIH_action)
	{
		if (parent.WIH_action.window_reload)
		{
			parent.WIH_action.window_reload();
		}
	}
	timeOut = 0;
}

function ResAppReload()
{
	if (parent.WIH_application)
	{
		if (parent.WIH_application.window_reload)
		{
			parent.WIH_application.window_reload();
		}
	}
	apptimeOut = 0;
}

function set_title()
{
	parent.document.title = processName + " - " + activityName;
	if (webStyleWihPlugin == "true")
	{
		document.frmTitle.Title.value = processName + " - " + activityName;
	}
	if (isModalWIHMode())
	{
		setWindowTitle("<xmp>" + processName + " - " + activityName + "</xmp>");
	}
}

var javaEnabled = navigator.javaEnabled();

function win_monitor()
{
	var _pid = oWIHInfo.ProcessID
	if (isNaN(parseInt(_pid)) || 0 == parseInt(_pid))
	{
		_pid = pid;
	}

	if (openPage == "ARCHIVE")
	{
		type = "archive";
	}
	else
	{
		type = "instance";
	}

	var sUrl = "";
	var sProcName = escapeUnicode(processName);
	document.frmAudit.procName.value = processName;
	if (openPage == "WORKLEFT" || openPage == "DEFINITION")// || openPage == "page")     bug20488
	{
		sUrl = contextPath + "/common/audit.jsp?pid=" + pid + "&type=" + type + "&pnm=" + sProcName;
	}
	else
	{
		sUrl = contextPath + "/common/audit.jsp?pid=" + _pid + "&type=" + type + "&pnm=" + sProcName;
	}
	var iWidth = window.screen.availWidth - 100;
	var iHeight = window.screen.availHeight - 200;
	var iLeft = 50;
	var iTop = 50;
	var sFeatures = "scrollbars=yes,status=yes,toolbar=yes,resizable=no,left=" + iLeft + "," + "top=" + iTop + "," + "width=" + iWidth + "," + "height=" + iHeight;
	if (isIE)
	{
		sFeatures = "scrollbars=yes,status=yes,toolbar=yes,resizable=yes,left=" + iLeft + "," + "top=" + iTop + "," + "width=" + iWidth + "," + "height=" + iHeight;
	}
	window.open(sUrl, 'Monitor', sFeatures);
}

function setReadComment()
{
	try
	{		
		WorkitemHandler.ReadComment = true;
	}
	catch (e)
	{
		if(console && console.error) console.error("setReadComment: " + e);
	}
}
function setAddedComment(myComment)
{
	try
	{
		WorkitemHandler.AddedComment = myComment;
	}
	catch (e)
	{
		if(console && console.error) console.error("setAddedComment: " + e);
	}
}
function setNumberOfComments(cnt)
{
	try
	{
		WorkitemHandler.NumberOfComments = cnt;
	}
	catch (e)
	{
		if(console && console.error) console.error("setNumberOfComments: " + e);
	}	
}
function openComment()
{
	setReadComment();
	var url = contextPath + "/bizcoves/wih/commentall.jsp?sid=" + nextServerID + "&pid=" + nextProcessID + "&seq=" + nextSequence + "&asq=" + nextActivitySequence + "&basicWihReadOnly=" + readOnlyFlag + "&_t=" + (new Date()).getTime();
	var iWidth = (readOnlyFlag == "y") ? 430:840;
	var iHeight = 360;
	ShowWindow(url, "openComment", TTL_PCOMM, iWidth, iHeight, "no", false);
}
function canSetUIStyleForComment()
{
	var canSet = false;

	if (WorkitemHandler)
	{
		try {
			//alert("wih_plugin.js: canSetUIStyleForComment(): WorkitemHandler.UseWebUIForComment = " + WorkitemHandler.UseWebUIForComment);
			if (WorkitemHandler.UseWebUIForComment != undefined) {
				canSet = true;
			} else {
			}
		} catch (e) {
		}
	}
	else
	{
	}
	return canSet;
}