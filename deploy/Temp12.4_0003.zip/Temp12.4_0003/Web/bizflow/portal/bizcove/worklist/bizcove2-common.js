function accessibleTop() {
    var w = parent;
    for(var i=0; i<10; i++) {
        try {
            if (w.document) w = parent;
            else break
        } catch (e) {
            break;
        }
    }
    return w;
}
function sortObjectData(data, key, dir) {
    if(data == null || data.length < 2) {
        return data;
    }
    return data.sort(function(a, b) {
        var x = a[key]; var y = b[key];
        if (dir === 'asc' ) {
            return ((x < y) ? -1 : ((x > y) ? 1 : 0));
        }
        else {
            return ((x > y) ? -1 : ((x < y) ? 1 : 0));
        }
    });
}
function removeDupJSONData(data, field) {
    if(data == null || data.length < 2) {
        return data;
    }
    var arr = [],
        collection = [];
    $.each(data, function (index, value) {
        value[field] = value[field]==null ? "" : value[field];
        if ($.inArray(value[field], arr) == -1) {
            arr.push(value[field]);
            collection.push(value);
        }
    });
    return collection;
}