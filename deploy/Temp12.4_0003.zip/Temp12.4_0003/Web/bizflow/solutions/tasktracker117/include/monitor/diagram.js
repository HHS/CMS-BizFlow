/**
 * Get the absolute position of an element
 * @param oElement an element object
 */
function _getElementPosition(oElement)
{
    var position = new Object();
    position.x = 0;
    position.y = 0;

    while (oElement != null)
    {
        position.x += oElement.offsetLeft;
        position.y += oElement.offsetTop;

        oElement = oElement.offsetParent;
    }

    return position;
}

/**
 * Draw a arrow line
 * @param fromId the id of a from object
 * @param toId the id of a to object
 * @param color line color
 * @dashstyle dash style, this value is one of  "solid", "dot" "dash", "dashdot", "longdash" or "longdashdot"
 */
function getDrawArrowLine(fromId, toId, color, dashstyle)
{
    if ("undefined" == typeof(color))
    {
        color = "#000000";
    }

    var div = "";
    var fromObj = document.getElementById(fromId);
    var toObj = document.getElementById(toId);

    if (fromObj && toObj)
    {

        var from = _getElementPosition(fromObj);
        var to = _getElementPosition(toObj);

        var x1 = from.x + (fromObj.offsetWidth / 2);
        var y1 = from.y + fromObj.offsetHeight;

        var x2 = to.x + (toObj.offsetWidth / 2);
        var y2 = to.y - 4;

        var radian = Math.atan((y2 - y1) / (x2 - x1));
        var deg = ((radian * 180.00) / Math.PI);

        if (deg < 0)
        {
            deg += 180;
            x2 += 8;
        }
        else if (deg > 90)
        {
            x2 -= 8;
        }

        div = "<div style=\"z-index:100\">";
        div += "<v:shape strokeweight=\"1pt\" strokecolor=\"" + color + "\" fillcolor=\"" + color
                + "\" style=\"position:absolute; left: " + x2 + "px; top: " + y2
                + "px; width:1px; height:1px; rotation:" + deg + "deg\" type=\"#Triangle\"/>";
        div += "<v:line style=\"position:absolute\" strokeweight=\"2pt\" strokecolor=\"" + color
                + "\" from=\"" + x1 + "px," + y1 + "px\" to=\"" + x2 + "px," + y2 + "px\">";
        if ("undefined" != typeof(dashstyle))
        {
            div += "<v:stroke dashstyle=\"" + dashstyle + "\" />";
        }
        div += "</v:line>";
        div += "</div>";
    }

    return div;
}

/**
 * Draw a arrow line
 * @param fromId the id of a from object
 * @param toId the id of a to object
 */
function drawArrowLine(fromId, toId, color)
{
    var div = getDrawArrowLine(fromId, toId, color);

    document.write(div);
}

function getDrawArrowLineFromParentToChild3(parentId, childId, siblingCount, siblingIndex, color, dashstyle)
{
    return getDrawArrowLine(parentId, childId, color, dashstyle);
}

var _triangleHeight = 8;


function _drawLineIE(x1, y1, x2, y2, color, dashstyle, deg)
{
    var xPad = 0;
    var yPad = 0;
    if((x2+100) < x1) {
        xPad = 30;
    }
    if((x1+100) < x2) {
        xPad = -30;
    }
    if(y2 < y1) {
        yPad = 5;
    }
    var div = "<div style=\"z-index:100\">";
    div += "<svg style='position:absolute; left:0; top:0'>";
    div += "<defs><marker id='triangle1' viewBox='0 0 10 20' refX='0' refY='10' markerUnits='userSpaceOnUse' markerWidth='10' markerHeight='10' fill-opacity='1' fill='" + color + "' orient='auto' class='arrowhead'><path d='M 0 0 L 10 10 L 0 20 z' /></marker></defs>";
    div += "<line x1='" + x1 +"' y1='" + y1 + "' x2='" + (x2+xPad) + "' y2='" + (y2+yPad) + "' marker-end='url(#triangle1)' ";
    if ("undefined" != typeof(dashstyle))
    {
        div += "stroke-dasharray='" + dashstyle + "' ";
    }
    div += " style='stroke:" + color + ";stroke-width:1' />";
    div += "</svg>";
    div += "</div>";

    return div;
}

function _drawLine(x1, y1, x2, y2, color, dashstyle, deg)
{
    return _drawLineIE(x1, y1, x2, y2, color, dashstyle, deg);
}

/**
 * Draw a arrow line
 * @param parentId a parent id
 * @param childId a child id
 * @param siblingCount sibling count
 * @param siblingIndex sibling index
 * @param color line color
 * @dashstyle dash style, this value is one of  "solid", "dot" "dash", "dashdot", "longdash" or "longdashdot"
 */
function getDrawArrowLineFromParentToChild(parentId, childId, siblingCount, siblingIndex, color, dashstyle)
{
    if ("undefined" == typeof(color))
    {
        color = "#000000";
    }

    var div = "";
    var fromObj = document.getElementById(parentId);
    var toObj = document.getElementById(childId);

    if (fromObj && toObj)
    {
        var from = _getElementPosition(fromObj);
        var to = _getElementPosition(toObj);

        var unitP = fromObj.offsetWidth / siblingCount;
        var x1 = from.x + (unitP / 2) + (unitP * siblingIndex);
        var y1 = from.y + fromObj.offsetHeight;

        var unitC = toObj.offsetWidth / 2;
        var x2 = to.x;
        var y2 = to.y - _triangleHeight;

        if (siblingCount == 1)
        {
            x2 += (toObj.offsetWidth / 2);
            x1 = x2;

        }
        else if (x2 < x1)
        {
            x2 += unitC;
        }
        else
        {
            x2 += unitC / 2;
        }

        var radian = Math.atan((y2 - y1) / (x2 - x1));
        var deg = ((radian * 180.00) / Math.PI);

        if (deg < 0)
        {
            if (deg < -80 && deg > -100)
            {
                deg = -deg;
            }
            else
            {
                deg += 180;
            }
            //x2 += (unitC * 2);
        }
        else if (deg > 90)
        {
        }
        else if (deg < 20)
        {
            //x2 -= unitC;
            //y2 += unitC;
        }

        div = _drawLine(x1, y1, x2-1, y2, color, dashstyle, deg);
    }

    return div;
}

/**
 * Draw a arrow line
 * @param fromId the id of a from object
 * @param toId the id of a to object
 */
function drawArrowLineFromParentToChild(parentId, childId, siblingCount, siblingIndex, color)
{
    var div = getDrawArrowLineFromParentToChild(parentId, childId, siblingCount, siblingIndex, color);

    document.write(div);
}

/**
 * Draw a arrow line
 * @param parentId a parent id
 * @param childId a child id
 * @param siblingCount sibling count
 * @param siblingIndex sibling index
 * @param color line color
 * @dashstyle dash style, this value is one of  "solid", "dot" "dash", "dashdot", "longdash" or "longdashdot"
 */
function getDrawArrowLineFromChildToParent(parentId, childId, siblingCount, siblingIndex, color, dashstyle)
{
    if ("undefined" == typeof(color))
    {
        color = "#000000";
    }

    var div = "";
    var fromObj = document.getElementById(childId);
    var toObj = document.getElementById(parentId);

    if (fromObj && toObj)
    {

        var from = _getElementPosition(fromObj);
        var to = _getElementPosition(toObj);

        var x1 = from.x;
        var y1 = from.y;

        var unitP = toObj.offsetWidth / (siblingCount);

        var x2 = to.x + (unitP / 2) + (unitP * siblingIndex);
        var y2 = to.y + toObj.offsetHeight;

        if (siblingCount == 1)
        {
            x1 += (fromObj.offsetWidth / 2) - 2;
            x2 = x1;
        }
        else
        {
            x1 += (fromObj.offsetWidth / 2) - 9;
        }

        if (x1 < x2)
        {
            x1 += (fromObj.offsetWidth / 2);
        }

        var radian = Math.atan((y2 - y1) / (x2 - x1));
        var deg = ((radian * 180.00) / Math.PI);

        if (deg > 0)
        {
            deg -= 180;
            //x1 -= fromObj.offsetWidth;
        }
        else
        {
        }

        div = _drawLine(x1, y1, x2,  y2, color, dashstyle, deg);
    }

    return div;
}

/**
 * Draw a arrow line
 * @param fromId the id of a from object
 * @param toId the id of a to object
 */
function drawArrowLineFromChildToParent(parentId, childId, siblingCount, siblingIndex, color)
{
    var div = getDrawArrowLineFromChildToParent(parentId, childId, siblingCount, siblingIndex, color);
    document.write(div);
}

/**
 * Get position offset
 * @param overlayObj current target object to overlay
 * @param offsetType offset type
 */
function getPositionOffset(overlayObj, offsetType)
{
    var totaloffset = (offsetType == "left") ? overlayObj.offsetLeft : overlayObj.offsetTop;
    var parentEl = overlayObj.offsetParent;

    while (parentEl != null)
    {
        totaloffset = (offsetType == "left") ? totaloffset + parentEl.offsetLeft : totaloffset + parentEl.offsetTop;
        parentEl = parentEl.offsetParent;
    }
    return totaloffset;
}

/**
 * Overlay a block
 * @param curObj current object
 * @param subObjId a sub object id to overlay
 * @param positionOption position option, left, top, right or bottom
 */
function overlayBlock(curObj, objId, positionOption)
{
    if (document.getElementById)
    {
        var subobj = document.getElementById(objId);
        subobj.style.display = (subobj.style.display != "block") ? "block" : "none";
        var xpos = getPositionOffset(curObj, "left") + ((typeof positionOption != "undefined" && positionOption.indexOf("right") != -1) ? -(subobj.offsetWidth - curObj.offsetWidth) : 0);
        var ypos = getPositionOffset(curObj, "top") + ((typeof positionOption != "undefined" && positionOption.indexOf("bottom") != -1) ? curObj.offsetHeight : 0);

        if (xpos < 0) xpos = 0;
        if (ypos < 0) ypos = 0;

        subobj.style.left = xpos + "px";
        subobj.style.top = ypos + "px";

        return false;
    }
    else
    {
        return true;
    }
}

/**
 * Close a overlayed block
 * @param objId a object id to close
 */
function overlayBlockClose(objId)
{
    document.getElementById(objId).style.display = "none";
}