var _addAttachmentWin = null;
var __attachmentIndex = 0;
function openAttachmentModal(sDMServerID, sSaveToEDMSFlag, dmIDType, processID, relDataSequence, nextFocusObjId, subTaskSeq, useIndexID) {
    if ("undefined" == typeof(subTaskSeq)) {
        subTaskSeq = 0;
    }
    if ("undefined" == typeof(useIndexID)) {
        useIndexID = false;
    }
    var indexID = -1;
    if(useIndexID == true) {
        indexID = __attachmentIndex;
    }
    var init = "false";
    if(__attachmentIndex == 0) {
        init = "true";
    }
    var url = basePath + "/common/attach/attachment.jsp?dmServerID=" + sDMServerID + "&saveToEDMS=" + sSaveToEDMSFlag + "&dmIDType=" + dmIDType +
        "&processID=" + processID + "&relDataSequence=" + relDataSequence + "&init=" + init + "&subTaskSeq=" + subTaskSeq+ "&indexID=" + indexID
        + "&rtime=" + new Date().getMilliseconds();

    var clientWidth = parseInt(document.body.clientWidth);
    var clientHeight = parseInt(document.body.clientHeight);

    var width = 450;
    var height = 220;

    if (width > clientWidth) {
        width = clientWidth;
    }

    if (height > clientHeight) {
        height = clientHeight;
    }

    _addAttachmentWin = dhtmlwindow.open("AddAttachment", "iframe", url,
        ADD_ATTACHMENT, "width=" + width + "px,height=" + height + "px,center=1,resize=0,scrolling=0");
}

function closeAttachmentModal() {
    if (null != _addAttachmentWin) {
        _addAttachmentWin.close();
        _addAttachmentWin = null;
    }
}

function openAttachment(sDMServerID, sSaveToEDMSFlag, dmIDType, processID, relDataSequence, nextFocusObjId, subTaskSeq, useIndexID) {
    if ("undefined" == typeof(subTaskSeq)) {
        subTaskSeq = 0;
    }
    if ("undefined" == typeof(useIndexID)) {
        useIndexID = false;
    }
    var indexID = -1;
    if(useIndexID == true) {
        indexID = __attachmentIndex;
    }
    setNextFocusObject(nextFocusObjId);
    var init = "false";
    if(subTaskSeq > 0) {
        if (document.taskForm.selAttachSubTask.options.length == 0)
            init = "true";
    } else {
        if (document.taskForm.selAttach.options.length == 0)
            init = "true";
    }
    var sUrl = basePath + "/common/attach/attachment.jsp?dmServerID=" + sDMServerID + "&saveToEDMS=" + sSaveToEDMSFlag + "&dmIDType=" + dmIDType +
        "&processID=" + processID + "&relDataSequence=" + relDataSequence + "&init=" + init + "&subTaskSeq=" + subTaskSeq + "&indexID=" + indexID
        + "&rtime=" + new Date().getMilliseconds();

    var iWidth = 420;
    var iHeight = 220; // Bug 27743
//	var iLeft = (window.screen.availWidth - iWidth) / 2;
//	var iTop = (window.screen.availHeight - iHeight) / 2;
//    var sFeatures = "scrollbars=no,status=no,toolbar=no,resizable=yes";
//    openNonPopup(sUrl, trim(ADD_ATTACHMENT), iWidth, iHeight, true, true, false, false)
    openPopup(sUrl, ADD_ATTACHMENT, "Attachment", iWidth, iHeight, true, false, false, false)
}


//add an option to select element
function addOption(oSelect, optName, optValue, k) {
    var oOption = new Option(optName, optValue, false);
    oSelect.options[k] = oOption;
    if (oSelect.options.length >= 2)
        oSelect.setAttribute('size', oSelect.options.length);
}


function getAttachmentIndex(id, subTaskSeq) {
    if ("undefined" == typeof(subTaskSeq)) {
        subTaskSeq = 0;
    }
    var index = -1;
    var container;
    if(subTaskSeq > 0) {
        container = $('#attachmentDisplayContainerSubTask');
    } else {
        container = $('#attachmentDisplayContainer');
    }
    var children = container.children();
    var index = -1;
    var attIndex = 0;
    for (var i = 0; i < children.length; i++) {
        var c = children[i];
        var _type = c.getAttribute("_type");
        if (_type == "attachment") {
            if (id == c.id) {
                index = attIndex;
                break;
            }

            attIndex++;
        }
    }

    return index;
}

function displayAttachment(fileName,attId, callerName, subTaskSeq) {
    if ("undefined" == typeof(subTaskSeq)) {
        subTaskSeq = 0;
    }

    var idx1 = fileName.lastIndexOf("\\");
    if (-1 != idx1) {
        fileName = fileName.substring(idx1 + 1);
    }
    var index = __attachmentIndex++;
    var ext = "";
    var idx = fileName.lastIndexOf(".");
    if (-1 != idx) {
        ext = fileName.substring(idx + 1);
    }

    var deleteIcon = imageBasePath + "/delete2.png";
    var imgPath = imageBasePath + "/attachicons/generic.png";
    var supportExts = "bff,bmp,doc,docm,docx,dotm,dotx,gif,html,jpg,other,pdf,potm,potx,ppsx,ppt,pptm,pptx,text,tif,url,xlam,xls,xlsb,xlsm,xlsx,xltm,xltx,zip,";
    if (ext != "" && supportExts.indexOf(ext + ",") != -1) {
        imgPath = imageBasePath + "/attachicons/" + ext + ".png";
    }

    var divObj;
    if(subTaskSeq > 0) {
        divObj = $('<div _type="attachment" id="attSubTask' + index + '" subTaskSeq="'+ subTaskSeq +'"></div>').addClass("attachment-box");
    } else {
        divObj = $('<div _type="attachment" id="att' + index + '"></div>').addClass("attachment-box");
    }
    var iconObj = $('<img class="fileType" src="' + imgPath + '">');
    var spanObj = $('<span></span>').addClass("attachment-name").html(getDisplayFileName(fileName));
    var deleteIconObj = $('<img border="0" class="deleteIcon" style="cursor:pointer" src="' + deleteIcon + '">').click(function () {
        if(subTaskSeq > 0) {
            var attIndex = getAttachmentIndex("attSubTask" + index, subTaskSeq);
            var selFrm = document.taskForm.selAttachSubTask;
            selFrm.selectedIndex = attIndex;
            if(deleteAttachment(fileName,callerName,attId, subTaskSeq, index)) {
                $('#attSubTask' + index).remove();
                var len = selFrm.options.length;
                if (len == 0) {
                    $('#selAttachmentsSubTask').hide();
                }
            }
        }
        else
        {
            var attIndex = getAttachmentIndex("att" + index);
            var selFrm = document.taskForm.selAttach;
            selFrm.selectedIndex = attIndex;
            if(deleteAttachment(fileName,callerName,attId, 0, index)) {
                $('#att' + index).remove();
                if (typeof(deleteAttachmentForSubTasks) != "undefined") {
                    deleteAttachmentForSubTasks(index);
                }
                var len = selFrm.options.length;
                if (len == 0) {
                    $('#selAttachments').hide();
                }
            }
        }
    });

    divObj.append(iconObj).append(spanObj).append(deleteIconObj);

    var container;
    if(subTaskSeq > 0) {
        container = $('#attachmentDisplayContainerSubTask');
        container.append(divObj);
        $('#selAttachmentsSubTask').show();
    } else {
        container = $('#attachmentDisplayContainer');
        container.append(divObj);
        $('#selAttachments').show();
    }
	
	//try {
	//	winReplyAllForm.doLayout();
	//} catch (e) {}
}

function addAttachment(sName, subTaskSeq) {

    if ("undefined" == typeof(subTaskSeq)) {
        subTaskSeq = 0;
    }
    var len;
    if(subTaskSeq > 0) {
        len = document.taskForm.selAttachSubTask.options.length;
    } else {
        len = document.taskForm.selAttach.options.length;
    }
    var sValue = sName.replace(/&#34;/g, "\"");
    var oText = sValue;
    var oValue = len;
    var selFrm;
    if(subTaskSeq > 0) {
        selFrm = document.taskForm.selAttachSubTask;
    } else {
        selFrm = document.taskForm.selAttach;
    }
    addOption(selFrm, oText, oValue, len);
    try { setFocus(); } catch(e) {};
    displayAttachment(sName, 0,"initiateform", subTaskSeq);
}

function addDraftAttachment(sName,attId, subTaskSeq) {
    if ("undefined" == typeof(subTaskSeq)) {
        subTaskSeq = 0;
    }

    var len;
    if(subTaskSeq > 0) {
        len = document.taskForm.selAttachSubTask.options.length;
    } else {
        len = document.taskForm.selAttach.options.length;
    }
    var sValue = sName.replace(/&#34;/g, "\"");
    var oText = sValue;
    var oValue = len;
    var selFrm;
    if(subTaskSeq > 0) {
        selFrm = document.taskForm.selAttachSubTask;
    } else {
        selFrm = document.taskForm.selAttach;
    }
    addOption(selFrm, oText, oValue, len);
    setFocus();
    displayAttachment(sName, attId,'assigneeReply', subTaskSeq);
}

//function deleteAttachment(nextFocusObjId,callerName) {
function deleteAttachment(filename,callerName,attId, subTaskSeq, indexList) {
    if ("undefined" == typeof(indexList)) {
        indexList = "";
    }
    if ("undefined" == typeof(subTaskSeq)) {
        subTaskSeq = 0;
    }
    //setNextFocusObject(nextFocusObjId);

    var selFrm;
    if(subTaskSeq > 0) {
        selFrm = document.taskForm.selAttachSubTask;
    } else {
        selFrm = document.taskForm.selAttach;
    }
    var o_sl = selFrm.selectedIndex;

    if (-1 != o_sl) {
        if (typeof(WantToDeleteFiles) == "undefined" ||confirm(WantToDeleteFiles)) {
            if (o_sl != -1 && selFrm.options[o_sl].value > "") {
                selFrm.options[o_sl] = null;
            }
            var len;
            if(subTaskSeq > 0) {
                len = document.taskForm.selAttachSubTask.options.length;
            } else {
                len = document.taskForm.selAttach.options.length;
            }
            for (var i = 0; i < len; i++) {
                selFrm.options[i].value = i;
            }
            if(callerName=='initiateformForLink') {
                // no action
            } else if(callerName=='assigneeReply')    {
                 hiddenFrame.location.href = basePath + "/task/action/deleteattachment.jsp?index=" + o_sl + "&ids="+indexList + "&subTaskSeq="+subTaskSeq + "&attId="+attId + "&rtime=" + new Date().getMilliseconds();
            }
            else {
                hiddenFrame.location.href = basePath + "/common/attach/deleteattachment.jsp?index=" + o_sl + "&ids="+indexList + "&subTaskSeq=" + subTaskSeq + "&fileName=" + filename + "&rtime=" + new Date().getMilliseconds();
            }

            //if(oSelect.options.length >= 2)
            //    selFrm.setAttribute('size', selFrm.options.length);
            return true;
        }
        else {
            return false;
        }
    }
    setFocus();
}


function viewURLAttachment(url) {
    var iWidth = window.screen.availWidth - 100;
    var iHeight = window.screen.availHeight - 200;
    if (iWidth > 800) iWidth = 800;
    if (iHeight > 600) iHeight = 600;
    var sFeatures = "menubar=yes,status=no,resizable=yes,toolbar=yes,scrollbars=yes";
    newCenterWin(url, "Attachment_View", iWidth, iHeight, sFeatures);
}
function viewAttachment(serverid, procid, attachid, fileName) {
    var sUrl = basePath + "/attach/attachopen.jsp?PROCESSID=" + procid + "&IID=" + attachid + "&FILENAME=" + fileName + "&serverid=" + serverid;
    var iWidth = window.screen.availWidth - 100;
    var iHeight = window.screen.availHeight - 200;
    if (iWidth > 800) iWidth = 800;
    if (iHeight > 600) iHeight = 600;
    var sFeatures = "menubar=yes,status=no,resizable=yes,toolbar=yes,scrollbars=yes";
    newCenterWin(sUrl, "Attachment_View", iWidth, iHeight, sFeatures);
}

function getDisplayFileName(dispName)
{
    var displayFileName = dispName;
    var nameDisplayLength = 30;
    if (displayFileName.length > nameDisplayLength)
    {
        displayFileName = displayFileName.substring(0, nameDisplayLength);
        displayFileName += "...";
    }
    return displayFileName;
}

function deleteAttachments(indexList) {
    if ("undefined" == typeof(indexList)) {
        indexList = "";
    }
    hiddenFrame.location.href = basePath + "/common/attach/deleteattachment.jsp?ids="+indexList + "&rtime=" + new Date().getMilliseconds();
    return true;
}
