var base_url = '/bizflowwebmaker/StratCon_AUT/';

var generalBind = function(){
    CMSUtility.debugLog('STRATCON_GEN - generalBind START');

    var isSelectingOfficial = StratConMAIN.isCurrentUserMemberOf('Selecting Officials');
    $('#SG_SO_ID').on('change', function(e) {
        $('#selecting_official_titleorg').val($(this).val())
        var titleOrg = $('#selecting_official_titleorg option:selected').text().split('~/_');
        $('#SG_SO_TITLE').val('');
        $('#SG_SO_ORG').val('');
        $('#selecting_official_detail').html('');
        if (titleOrg.length > 1) {
			$('#selecting_official_detail_container').show();
            $('#selecting_official_detail_label').show();
            $('#SG_SO_TITLE').val(titleOrg[0]);
            $('#SG_SO_ORG').val(titleOrg[1]);
            $('#selecting_official_detail').html(titleOrg[0] + '/' + titleOrg[1]);
        } else {
			$('#selecting_official_detail_container').hide();
            $('#selecting_official_detail_label').hide();
		}
    });

    $('#SG_XO_ID').on('change',function(e) {
        $('#executive_office_titleorg').val($(this).val())
        var titleOrg = $('#executive_office_titleorg option:selected').text().split('~/_');
        $('#SG_XO_TITLE').val('');
        $('#SG_XO_ORG').val('');
        $('#executive_office_detail').html('');
        if (titleOrg.length > 1) {
			$('#executive_office_detail_container').show();
            $('#executive_office_detail_label').show();
            $('#SG_XO_TITLE').val(titleOrg[0]);
            $('#SG_XO_ORG').val(titleOrg[1]);
            $('#executive_office_detail').html(titleOrg[0] + '/' + titleOrg[1]);
        } else {
			$('#executive_office_detail_container').hide();
            $('#executive_office_detail_label').hide();
		}
    });

	$('#SG_HRL_ID').append($('<option/>', {
		value: '',
		text: 'N/A'
	}));

    $('#SG_HRL_ID').on('change',function(e) {
        $('#hr_liaison_titleorg').val($(this).val());
        var titleOrg = $('#hr_liaison_titleorg option:selected').text().split('~/_');
        $('#SG_HRL_TITLE').val('');
        $('#SG_HRL_ORG').val('');
        $('#hr_liaison_detail').html('');
        if(titleOrg.length > 1){
			$('#hr_liaison_detail_container').show();
            $('#hr_liaison_detail_label').show();

            $('#SG_HRL_TITLE').val(titleOrg[0]);
            $('#SG_HRL_ORG').val(titleOrg[1]);
            $('#hr_liaison_detail').html(titleOrg[0] + '/' + titleOrg[1]);
        } else {
			$('#hr_liaison_detail_container').hide();
            $('#hr_liaison_detail_label').hide();
		}
    });

    $('#SG_SS_ID').on('change',function(e) {
        $('#hr_staffing_specialist_titleorg').val($(this).val())
        $('#hr_staffing_specialist_detail').html($('#hr_staffing_specialist_titleorg option:selected').text());
    });

    $('#SG_CS_ID').on('change',function(e) {
        $('#hr_classification_specialist_titleorg').val($(this).val());
        $('#hr_classification_specialist_detail').html($('#hr_classification_specialist_titleorg option:selected').text());
    });

    $('#SG_AT_ID').on('change', function() {
        CMSUtility.debugLog('STRATCON_GEN - SG_AT_ID.onChange START');
        var requestType = $('#SG_RT_ID :selected').text();
        var appointmentType = $('#SG_AT_ID :selected').text();

        if (requestType == 'Appointment' && appointmentType == 'Schedule A') {
            $('#SG_VT_ID').val('');
            hyf.util.showComponent('layout_group_SAT', null, null, null);
            hyf.util.hideComponent('layout_group_VOL', null, null, null);
        } else if (requestType == 'Appointment' && appointmentType == 'Volunteer') {
            $('#SG_SAT_ID').val('');
            hyf.util.hideComponent('layout_group_SAT', null, null, null);
            hyf.util.showComponent('layout_group_VOL', null, null, null);
        } else {
            $('#SG_VT_ID').val('');
            $('#SG_SAT_ID').val('');
            hyf.util.hideComponent('layout_group_SAT', null, null, null);
            hyf.util.hideComponent('layout_group_VOL', null, null, null);
        }

        showHideClassificationType();
        showHideStaffSpecialistGroup();
        stratConPOS.showHideFieldsBasedOnContext();
        StratConMAIN.showHideTabsUponRequestType();
        setNotifyMeetingButtonLabel();

        // Notify document tab so that it can retrieve new document types and mandatory documents.
        $(document).trigger('ON_DOCUMENT_CHANGE');

        CMSUtility.debugLog('STRATCON_GEN - SG_AT_ID.onChange END');
    });

    $('#SG_CT_ID').on('change', function() {
        CMSUtility.debugLog('STRATCON_GEN - SG_CT_ID.onChange START');

        // Notify document tab so that it can retrieve new document types and mandatory documents.
        $(document).trigger('ON_DOCUMENT_CHANGE');

        StratConMAIN.showHideTabsUponRequestType();
        setNotifyMeetingButtonLabel();

        CMSUtility.debugLog('STRATCON_GEN - SG_CT_ID.onChange END');
    });

    $('#SG_RT_ID').on('change',function(e) {
        CMSUtility.debugLog('STRATCON_GEN - SG_RT_ID.onChange START');
        var preselect = $('#SG_CT_ID').val();
        $('#SG_CT_ID').empty();
        $('#classification_type_parent').val($(this).val());
        $('#classification_type_parent :selected').each(function(){
            var $tmp = $('#classification_type_data option[value="' + $(this).text() + '"]');
            $('#SG_CT_ID').append('<option value=' + $tmp.val() + '>' + $tmp.text() + '</option>');
        });
        if (preselect !== undefined) {
            $('#SG_CT_ID').val(preselect);
        }
        hyf.util.hideComponent('layout_group_so_agree', null, null, null);

        var requestType = $('#SG_RT_ID :selected').text();
        if (requestType != null && requestType.length > 0) {
            requestType = requestType.toLowerCase();
        }

        if (requestType != 'recruitment') {
            hyf.util.hideComponent('COMMISSIONED_NOTE', null, null, null);
            $('#OTHER_CERT_DIV').addClass('hidden');
            $('#certSearch_display').empty();
            $('#SG_OTHER_CERT').val('');
        } else {
            $('#OTHER_CERT_DIV').removeClass('hidden');

            if (isSelectingOfficial == true) {
                hyf.util.showComponent('layout_group_so_agree', null, null, null);
            }
            hyf.util.showComponent('COMMISSIONED_NOTE', null, null, null);
        }
        showHideClassificationType();
        showHideAppointmentType();
        showHideStaffSpecialistGroup();

        stratConPOS.showHideAppointmentFields();
        stratConPOS.showHideFieldsBasedOnContext();

        // Notify document tab so that it can retrieve new document types and mandatory documents.
        $(document).trigger('ON_DOCUMENT_CHANGE');

        StratConMAIN.showHideTabsUponRequestType(); // Function from StratConMain.js
        setNotifyMeetingButtonLabel();

        CMSUtility.debugLog('STRATCON_GEN - SG_RT_ID.onChange END');
    });

    $('#SG_VT_ID').on('change', function() {
        CMSUtility.debugLog('STRATCON_GEN - SG_VT_ID.onChange START');

        // Notify document tab so that it can retrieve new document types and mandatory documents.
        $(document).trigger('ON_DOCUMENT_CHANGE');

        CMSUtility.debugLog('STRATCON_GEN - SG_VT_ID.onChange END');
    });

    $('#SG_SO_ID').trigger('change');
    $('#SG_XO_ID').trigger('change');
    $('#SG_HRL_ID').trigger('change');
    $('#SG_RT_ID').trigger('change');
    $('#SG_AT_ID').trigger('change');

    setCertAutoComplete();
    setACAutoComplete();

    if ($("#AC_ADMIN_CD_DESCR").val() != "") {
        var li_org_name = "<li id=\"" + $("#AC_ADMIN_CD").val() + "_dscr\">";
        var li_admin_cd = "<li id=\"" + $("#AC_ADMIN_CD").val() + "\">";
        if ($('#h_readOnly').val() != 'y') {
            li_org_name += getAutoCompRemoveIconElement($('#AC_ADMIN_CD').val() + "_dscr", $('#AC_ADMIN_CD_DESCR').val(), '35');
            li_admin_cd += getAutoCompRemoveIconElement($('#AC_ADMIN_CD').val(), $('#AC_ADMIN_CD').val(), '25');
        }
        li_admin_cd += $("#AC_ADMIN_CD").val() + "</li>";
        li_org_name += $("#AC_ADMIN_CD_DESCR").val() + "</li>";

        $("#SG_AC_DISP").append(li_admin_cd).removeClass('hidden');
        $("#SG_ON_DISP").append(li_org_name).removeClass('hidden');
        $("#SG_ADMIN_CD_INPUT_container").addClass('hidden');
        $("#SG_ORG_NAME_container").addClass('hidden');
        $("#SG_ORG_NAME").attr('_required', 'false');
        $("#SG_ADMIN_CD_INPUT").attr('_required', 'false');
    }

    if ($('#OTHER_CERT_DATA option').length != 0) {
        $('#OTHER_CERT_DATA option').each(function(){
            var li = "<li id=\"" + $(this).val() + "\">";
            if($('#h_readOnly').val() != 'y'){
                li += getAutoCompRemoveIconElement($(this).val(), $(this).text(), '205');
            }
            li +=  $(this).text() + "</li>";
            $("#certSearch_display").append(li);

        });
    }
    $("#certSearch_display").delegate("img", "click keyup", function (e) {
        if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
            $("#" + $(this).attr("deleteid")).remove();
            $('#SG_OTHER_CERT').val($('#SG_OTHER_CERT').val().replace($(this).attr("deleteid"),'')).replace(',,',',');
        }
    });
    $("#SG_AC_DISP").delegate("img", "click keyup", function (e) {
        if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
            $("#SG_AC_DISP").addClass('hidden').empty();
            $("#SG_ADMIN_CD_INPUT_container").removeClass('hidden');
            $("#SG_ADMIN_CD_INPUT").attr('_required', 'true');
            $("#SG_ON_DISP").addClass('hidden').empty();
            $("#SG_ORG_NAME_container").removeClass('hidden');
            $("#SG_ORG_NAME").attr('_required', 'true');
        }
    });

    $("#SG_ON_DISP").delegate("img", "click keyup", function (e) {
        if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
            $("#SG_AC_DISP").addClass('hidden').empty();
            $("#SG_ADMIN_CD_INPUT_container").removeClass('hidden');
            $("#SG_ADMIN_CD_INPUT").attr('_required', 'true');
            $("#SG_ON_DISP").addClass('hidden').empty();
            $("#SG_ORG_NAME_container").removeClass('hidden');
            $("#SG_ORG_NAME").attr('_required', 'true');
        }
    });

    CMSUtility.debugLog('STRATCON_GEN - generalBind END');
}

var showHideAppointmentType = function() {
    var requestType = $('#SG_RT_ID :selected').text();
    if (requestType == 'Appointment') {
        // SHOW
        hyf.util.showComponent('layout_group_AT', null, null, null);
        $('#SG_AT_ID').trigger('change');
    } else {
        // HIDE
        $('#SG_AT_ID').val('');
        //$('#').val('');
        $('#SG_SAT_ID').val('');
        hyf.util.hideComponent('layout_group_AT', null, null, null);
    }
}

var showHideClassificationType = function() {
    var requestType = $('#SG_RT_ID :selected').text();
    var appointmentType = $('#SG_AT_ID :selected').text();

    if (requestType != 'Appointment'
        || (appointmentType != 'Volunteer'
            && appointmentType != 'Intergovernmental Personnel Act (IPA)')
            && appointmentType != 'Expert/Consultant') {
        hyf.util.showComponent('layout_group_CT', null, null, null);
        hyf.util.showComponent('layout_group_classSpecialist', null, null, null);
    } else {
        $('#SG_CT_ID').val('');
        $('#SG_CS_ID').val('');
        hyf.util.hideComponent('layout_group_CT', null, null, null);
        hyf.util.hideComponent('layout_group_classSpecialist', null, null, null);
    }
}

var showHideStaffSpecialistGroup = function() {
    var isSpecial = StratConMAIN.isSpecialProgram();
    if (isSpecial == true) {
        var targetActivities = ['Hold Strategic Consultation Meeting', 'Acknowledge Strat Cons Meeting', 'Approve Strat Cons Meeting'];
        var activityName = BFActivityOption.getActivityName();
        var foundActivity = CMSUtility.existInArray(targetActivities, activityName);

        hyf.util.disableComponent('SG_SS_ID');
        $('#SG_SS_ID').attr('donotsubmit', 'true');

        hyf.util.enableComponent('SG_SP_ID');
        $('#SG_SP_ID').removeAttr('donotsubmit');

        hyf.util.hideComponent('layout_group_staffspecialist', null, null, null);
        if (foundActivity == true) {
            hyf.util.showComponent('layout_group_specialProgram', null, null, null);
        } else {
            var specialUserGroupMemberID = StratConMAIN.getUserGroupMemberID('HR Special Programs');

            var alreadyAddedSpecialPrograms = false;
            $.each($('#SG_SP_ID option'), function(index, component) {
                var value = $(this).attr('value');
                if (value == specialUserGroupMemberID) {
                    alreadyAddedSpecialPrograms = true;
                }
            });

            if (alreadyAddedSpecialPrograms == false) {
                $('#SG_SP_ID').append('<option value="' + specialUserGroupMemberID + '">HR Special Programs</option>');
            }
            $('#SG_SP_ID').val(specialUserGroupMemberID);
            hyf.util.hideComponent('layout_group_specialProgram', null, null, null);
        }
        $('#pv_specialProgram').val('Yes');
    } else {
        hyf.util.disableComponent('SG_SP_ID');
        $('#SG_SP_ID').attr('donotsubmit', 'true');

        hyf.util.enableComponent('SG_SS_ID');
        $('#SG_SS_ID').removeAttr('donotsubmit');

        var requestType = $('#SG_RT_ID :selected').text();
        if (requestType == 'Classification Only') {
            $('#SG_SS_ID').val('');
            hyf.util.hideComponent('layout_group_staffspecialist', null, null, null);
        } else if (requestType == 'Recruitment') {
            hyf.util.showComponent('layout_group_staffspecialist', null, null, null);
        } else if (requestType == 'Appointment') {
            var appointmentType = $('#SG_AT_ID :selected').text(); // HRB-1654
            if (appointmentType == 'Intergovernmental Personnel Act (IPA)') {
                $('#SG_SS_ID').val('');
                hyf.util.hideComponent('layout_group_staffspecialist', null, null, null);
            } else {
                hyf.util.showComponent('layout_group_staffspecialist', null, null, null);
            }
        } else {
            hyf.util.showComponent('layout_group_staffspecialist', null, null, null);
        }
        hyf.util.hideComponent('layout_group_specialProgram', null, null, null);
        $('#pv_specialProgram').val('No');
    }

    $(document).trigger('SG_SPECIAL_PROGRAM_CHANGED');
}

// Change button label (Default - Notify Meeting Attendees) based on Request Type & Classification Type
var setNotifyMeetingButtonLabel = function() {
    var buttonIDs = ['button_cr_notify_2', 'button_rr_notify_2', 'button_mr_notify_2', 'button_escr_notify_2'];
    var requestType = $('#SG_RT_ID :selected').text();

    if (requestType == 'Appointment') {
        var appointmentType = $('#SG_AT_ID :selected').text();
        if (appointmentType == 'Volunteer') {
            buttonIDs.forEach(function(id) {
                $('#' + id).val('Notify Special Programs');
                CMSUtility.enableComponents(buttonIDs);
            });
        } else {
            var targetClassificationTypes = ['Conduct 5-year Recertification', 'Update Coversheet', 'Review Existing Position Description'];
            var classificationType = $('#SG_CT_ID :selected').text();
            var foundClassificationType = CMSUtility.existInArray(targetClassificationTypes, classificationType);

            var targetAppointmentTypes = ['Intergovernmental Personnel Act (IPA)', 'Expert/Consultant'];
            var foundAppointmentType = CMSUtility.existInArray(targetAppointmentTypes, appointmentType);


            if (foundClassificationType == true || foundAppointmentType == true) {
                buttonIDs.forEach(function(id) {
                    $('#' + id).val('Notify HR');
                    $('#pv_meetingRequired').val('No');
                    $('#pv_meetingResched').val('No');
                    CMSUtility.enableComponents(buttonIDs);

                    var activityName = BFActivityOption.getActivityName();
                    if (activityName == 'Hold Strategic Consultation Meeting') {
                        CMSUtility.disableComponents(['button_escr_send_2']);
                    }
                });
            } else {
                buttonIDs.forEach(function(id) {
                    $('#' + id).val('Notify Meeting Attendees');
                    $('#pv_meetingRequired').val('Yes');
                    TabManager.tabList[2].eventHandler.changeOnSSHMeetingSchedDT();

                    var activityName = BFActivityOption.getActivityName();
                    if (activityName == 'Hold Strategic Consultation Meeting') {
                        CMSUtility.enableComponents(['button_escr_send_2']);
                    }
                });
            }
        }
    } else {
        buttonIDs.forEach(function(id) {
            $('#' + id).val('Notify Meeting Attendees');
            TabManager.tabList[2].eventHandler.changeOnSSHMeetingSchedDT();
        });
    }
}

var setCertAutoComplete = function () {
    $("#certSearch").autocomplete({
        source: function (request, response) {
            $.ajax({
                url: base_url + "SearchPeople.do?searchString=" + $('#certSearch').val(),
                dataType: "xml",
                cache: false,
                success: function (xmlResponse) {
                    var data = $("record", xmlResponse ).map(function() {
                        return {
                            value: "",
                            name: $( "DSPNAME", this ).text() + ' (' + $( "DEPTNAME", this ).text() + ')' ,
                            id: $( "MID", this ).text(),
                            email: $( "EMAIL", this ).text()
                        };
                    }).get();
                    response(data);
                }

            })
        },
        minLength: 1,
        change: function (e, u) {
            var pos = $(this).position();
            if (u.item == null) {
                //Clear the AutoComplete TextBox.
                $('#certSearch_noMatch').remove();
                $(this).after("<span id='certSearch_noMatch' class='acNoMatch'>Invalid Selection:<br />Item must be selected from the available options.</span>");
                $('#certSearch_noMatch').css({top: pos.top + 20, left: pos.left + 30, position:'absolute'});
                setTimeout(function() {
            		$('#certSearch_noMatch').remove();
          		}, 2000);
                $(this).val("");
                return false;
            }
        },
        select: function (event, ui) {
            var sep = ',';
            if ($("#certSearch_display li[id='" + ui.item.id + "']").length == 0) {
                var li = "<li id=\"" + ui.item.id + "\">";
                li += getAutoCompRemoveIconElement(ui.item.id, ui.item.name, '205');
                li += ui.item.name + " " + ui.item.email + "</li>";

                $("#certSearch_display").append(li);
                if($('#SG_OTHER_CERT').val() == ''){sep = '';}
                $('#SG_OTHER_CERT').val($('#SG_OTHER_CERT').val() + sep + ui.item.id);
            }
        },
        open: function(){
             $(".ui-autocomplete").css("z-index", 5000);
        },
        close: function(){
             $(".ui-autocomplete").css("z-index", 1);
        }
    })
    .autocomplete().data("ui-autocomplete")._renderItem = function (ul, item) {
        return $("<li>")
        .append("<a>" + item.name + "</a>")
        .appendTo(ul);
    };
}
var setACAutoComplete = function () {
    $("#SG_ADMIN_CD_INPUT").autocomplete({
        source: function (request, response) {
            $.ajax({
                url: base_url + "SearchAdmOffOrg.do?searchAdmOff=" + $('#SG_ADMIN_CD_INPUT').val(),
                dataType: "xml",
                cache: false,
                success: function (xmlResponse) {
                    var data = $("record", xmlResponse ).map(function() {
                        return {
                            //ac_id: $( "AC_ID", this ).text(),
                            admin_cd: $( "AC_ADMIN_CD", this ).text(),
                            admin_desc: $( "AC_ADMIN_CD_DESCR", this ).text()
                        };
                    }).get();
                    response(data);
                }
            })
        },
        minLength: 2,
        change: function (e, u) {
            //If the No match found" u.item will return null, clear the TextBox.
            if (u.item == null) {
                //Clear the AutoComplete TextBox.
                var pos = $(this).position();
                $('#SG_ADMIN_CD_INPUT_noMatch').remove();
                $(this).after("<span id='SG_ADMIN_CD_INPUT_noMatch' class='acNoMatch'>Invalid Selection:<br />Item must be selected from the available options.</span>");
                $('#SG_ADMIN_CD_INPUT_noMatch').css({top: pos.top + 20, left: pos.left + 30, position:'absolute'});
                setTimeout(function() {
            		$('#SG_ADMIN_CD_INPUT_noMatch').remove();
          		}, 2000);
                $(this).val("");
                return false;
            }
        },
        select: function (event, ui) {
            var li_admin_cd = "<li id=\"" + ui.item.admin_cd + "\" >";
            li_admin_cd += getAutoCompRemoveIconElement(ui.item.admin_cd, ui.item.admin_cd, '25');
            li_admin_cd += ui.item.admin_cd + "</li>";

            var li_org_name = "<li id=\"" + ui.item.admin_cd + "_dscr\" >";
            li_org_name += getAutoCompRemoveIconElement(ui.item.admin_cd + "_dscr", ui.item.admin_desc, '35');
            li_org_name += ui.item.admin_desc + "</li>";

            $("#SG_AC_DISP").append(li_admin_cd).removeClass('hidden');
            $("#SG_ADMIN_CD_INPUT_container").addClass('hidden');
        	$("#SG_ADMIN_CD_INPUT").attr('_required', 'false');
            $("#SG_ON_DISP").append(li_org_name).removeClass('hidden');
            $("#SG_ORG_NAME_container").addClass('hidden');
			$("#SG_ORG_NAME").attr('_required', 'false');
            $("#SG_ADMIN_CD").val(ui.item.admin_cd);
        },
        open: function() {
             $(".ui-autocomplete").css("z-index", 5000);
        },
        close: function() {
             $(".ui-autocomplete").css("z-index", 1);
        }
    })
    .autocomplete().data("ui-autocomplete")._renderItem = function (ul, item) {
        return $("<li>")
	        .append("<a>" + item.admin_cd + " - "  + item.admin_desc + "</a>")
	        .appendTo(ul);
    };

    $("#SG_ORG_NAME").autocomplete({
        source: function (request, response) {
            $.ajax({
                url: base_url + "SearchAdmOffOrg.do?searchOrg=" + $('#SG_ORG_NAME').val(),
                dataType: "xml",
                cache: false,
                success: function (xmlResponse) {
                    var data = $("record", xmlResponse ).map(function() {
                        return {
                            //ac_id: $( "AC_ID", this ).text(),
                            admin_cd: $( "AC_ADMIN_CD", this ).text(),
                            admin_desc: $( "AC_ADMIN_CD_DESCR", this ).text()
                        };
                    }).get();
                    response(data);
                }

            })
        },
        change: function (e, u) {
            //If the No match found" u.item will return null, clear the TextBox.
            if (u.item == null) {
                //Clear the AutoComplete TextBox.
                var pos = $(this).position();
                $('#SG_ORG_NAME_noMatch').remove();
                $(this).after("<span id='SG_ORG_NAME_noMatch' class='acNoMatch'>Invalid Selection:<br />Item must be selected from the available options.</span>");
                $('#SG_ORG_NAME_noMatch').css({top: pos.top + 20, left: pos.left + 30, position:'absolute'});
                setTimeout(function() {
            		$('#SG_ORG_NAME_noMatch').remove();
          		}, 2000);
                $(this).val("");
                return false;
            }
        },
        select: function (event, ui) {
            var li_admin_cd = "<li id=\"" + ui.item.admin_cd + "\" >";
            li_admin_cd += getAutoCompRemoveIconElement(ui.item.admin_cd, ui.item.admin_cd, '25');
            li_admin_cd += ui.item.admin_cd + "</li>";

            var li_org_name = "<li id=\"" + ui.item.admin_cd + "_dscr\" >";
            li_org_name += getAutoCompRemoveIconElement(ui.item.admin_cd + "_dscr", ui.item.admin_desc, '35');
            li_org_name += ui.item.admin_desc + "</li>";

            $("#SG_AC_DISP").append(li_admin_cd).removeClass('hidden');
            $("#SG_ADMIN_CD_INPUT_container").addClass('hidden');
        	$("#SG_ADMIN_CD_INPUT").attr('_required', 'false');
            $("#SG_ON_DISP").append(li_org_name).removeClass('hidden');
            $("#SG_ORG_NAME_container").addClass('hidden');
            $("#SG_ORG_NAME").attr('_required', 'false');
            $("#SG_ADMIN_CD").val(ui.item.admin_cd);
        },
        open: function() {
             $(".ui-autocomplete").css("z-index", 5000);
        },
        close: function() {
             $(".ui-autocomplete").css("z-index", 1);
        }
    })
    .autocomplete().data("ui-autocomplete")._renderItem = function (ul, item) {
        return $("<li>")
        .append("<a>" + item.admin_desc + " - " + item.admin_cd + "</a>")
        .appendTo(ul);
    };
}
