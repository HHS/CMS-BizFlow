/**
 * Global Object which consists for properties and methods used by this project
 *
 */
var stratConPOS = {
	// Field used to store base URL used by AutoComplete
    baseURL: '/bizflowwebmaker/StratCon_AUT/',

	// Field used to store indicator whether currently a restricted Grade is selected or not
    prevRestricatedGrade: false,

	// Array of objects used throughout the grade related functions
    grades: [
        {
            id: '#POS_GRADE_1', lbl: '#POS_GRADE_1_label', pdn: '#POS_DESC_NUMBER_1', cdt: '#POS_CLASSIFICATION_DT_1',
            cdtl: '#POS_CLASSIFICATION_DT_1_label', cdta: '#POS_CLASSIFICATION_DT_1_calendar_anchor'
        },{
            id: '#POS_GRADE_2', lbl: '#POS_GRADE_2_label', pdn: '#POS_DESC_NUMBER_2', cdt: '#POS_CLASSIFICATION_DT_2',
            cdtl: '#POS_CLASSIFICATION_DT_2_label', cdta: '#POS_CLASSIFICATION_DT_2_calendar_anchor'
        },{
            id: '#POS_GRADE_3', lbl: '#POS_GRADE_3_label', pdn: '#POS_DESC_NUMBER_3', cdt: '#POS_CLASSIFICATION_DT_3',
            cdtl: '#POS_CLASSIFICATION_DT_3_label', cdta: '#POS_CLASSIFICATION_DT_3_calendar_anchor'
        },{
            id: '#POS_GRADE_4', lbl: '#POS_GRADE_4_label', pdn: '#POS_DESC_NUMBER_4', cdt: '#POS_CLASSIFICATION_DT_4',
            cdtl: '#POS_CLASSIFICATION_DT_4_label', cdta: '#POS_CLASSIFICATION_DT_4_calendar_anchor'
        },{
            id: '#POS_GRADE_5', lbl: '#POS_GRADE_5_label', pdn: '#POS_DESC_NUMBER_5', cdt: '#POS_CLASSIFICATION_DT_5',
            cdtl: '#POS_CLASSIFICATION_DT_5_label', cdta: '#POS_CLASSIFICATION_DT_5_calendar_anchor'
        }
    ],

	// Object Containing properties to store Pay Plan Details; contents are refreshed
	// using the method setPayPlanDetails when Pay Plan is changed by the user
    payPlanDetails: {
        payPlan: "",
        gradeRequired: 0,
        minGrade: 0,
        maxGrade: 0,
        restrictGradeAt: 0
    },

    eventHandler: {
        onKeyChange_RequestType: function() {
            stratConPOS.showHideFieldsBasedOnContext();
            if ($('#SG_RT_ID :selected').text() == 'Recruitment') {
                stratConPOS.showGLASection();
                stratConPOS.eventHandler.onChange_WorkSchedule();
            } else {
                stratConPOS.hideGLASection();
            }
        },
        // This can be removed. Max limit is handled globally.
        onKeyChange_pdn: function ($object) {
            if ($object.val().length == 10) {
                stratConPOS.showAlert($object,'PD_max',"10 Character Max Reached");
            }
        },
        onChange_cdt: function($object) {
            var now = new Date();
            if (Date.parse(now) < Date.parse($object.val())) {
                stratConPOS.showAlert($object,'DT_err',"Date must be in the past.");
                $object.val('');
            }
        },
    	// This method/function shows and hides the Skill Required fields
    	// based on the Classifiction Type
        onChange_ClassificationType: function() {
            var sgCtText = $('#SG_CT_ID :selected').text()
            $("#POS_SKILL_label").attr('_required', 'false');
            $("#POS_SKILL_marker").addClass('hidden');
            $("#POS_SKILL").attr('_required', 'false');
            if (sgCtText == 'Create New Position Description'
                || sgCtText == 'Update Major Duties'
                || sgCtText == 'Reorganization for New Position') {
                $("#POS_SKILL_label").attr('_required', 'true');
                $("#POS_SKILL_marker").removeClass('hidden');
                $("#POS_SKILL").attr('_required', 'true');
            }
        },
        onChange_SponsoringFundPercentage: function() {
            var requestType = $("#SG_RT_ID option:selected").text();
            var appointmentType = $("#SG_AT_ID option:selected").text();
            var percentage = $('#POS_SPNSR_ORG_FUND_PC').val();

            if (requestType == 'Appointment' && appointmentType == 'Intergovernmental Personnel Act (IPA)') {
                if (percentage == '100') {
                    hyf.util.hideComponent('can_group');
                } else {
                    hyf.util.showComponent('can_group');
                }
            }
        },
        onChange_TypeOfAppointment: function() {
            var typeOfAppointment = $('#POS_AT_ID option:selected').text();

            if (typeOfAppointment == 'Permanent' || typeOfAppointment == 'Select One' || typeOfAppointment == '') {
                stratConPOS.hideElement('NTE_group');
            } else {
                $('#NTE_group').show();
            }
        },
        onChange_WorkSchedule: function() {
            if ($('#POS_WORK_SCHED_ID').val() != '') {
                var workSchedule = $('#POS_WORK_SCHED_ID option:selected').text();
                if (workSchedule == 'Part-Time') {
                    $('#hr_wk_group_full_int').parent().hide();
                    $('#hr_wk_group_part').parent().show();
                    $('#POS_HOURS_PER_WEEK').val('');
                    $('#POS_HOURS_PER_WEEK').attr('donotsubmit', 'true');
                    $('#POS_HOURS_PER_WEEK').attr('disabled', 'disabled');

                    $('#POS_HOURS_PER_WEEK_PART').removeAttr('donotsubmit');
                    $('#POS_HOURS_PER_WEEK_PART').removeAttr('disabled');
                    $('input[name="POS_HOURS_PER_WEEK_PART"]').removeAttr('donotsubmit');
                    $('input[name="POS_HOURS_PER_WEEK_PART"]').removeAttr('disabled');

                } else {
                    $('#hr_wk_group_full_int').parent().show();
                    $('#hr_wk_group_part').parent().hide();
                    $('#POS_HOURS_PER_WEEK').val('');
                    $('#POS_HOURS_PER_WEEK_PART').val('');

                    hyf.validation.validateField('POS_HOURS_PER_WEEK_PART', true);

                    $('#POS_HOURS_PER_WEEK').removeAttr('donotsubmit');
                    $('#POS_HOURS_PER_WEEK').attr('disabled', 'disabled');

                    $('#POS_HOURS_PER_WEEK_PART').attr('donotsubmit','true');
                    $('#POS_HOURS_PER_WEEK_PART').attr('disabled', 'disabled');
                    $('input[name="POS_HOURS_PER_WEEK_PART"]').attr('donotsubmit', 'true');
                    $('input[name="POS_HOURS_PER_WEEK_PART"]').attr('disabled', 'disabled');

                    if (workSchedule == 'Full-Time') {
                        $('#POS_HOURS_PER_WEEK').val('40');
                    } else if (workSchedule == 'Intermittent') {
                        $('#hr_wk_group_full_int').parent().hide();
                    }
                }
            } else {
                $('#POS_HOURS_PER_WEEK').val('');
                $('#POS_HOURS_PER_WEEK_PART').val('');

                $('#hr_wk_group_full_int').parent().hide();
                $('#hr_wk_group_part').parent().hide();
            }
        },
        onChange_Vice: function() {
            if ($('#POS_VICE').val() == 1) {
                $('#vice_name_group').show();
            } else {
                $('#vice_name_group').hide();
            }
        },
        onClick_LicenseCheckBox: function() {
            if ($('#POS_CE_LIC').prop('checked')) {
                $('#POS_CE_LIC_INFO_label').removeClass('hidden').attr('_required', 'true');
                $('#POS_CE_LIC_INFO').removeClass('hidden').attr('_required', 'true');
            } else {
                $('#POS_CE_LIC_INFO_label').addClass('hidden').attr('_required', 'false');
                $('#POS_CE_LIC_INFO').addClass('hidden').attr('_required', 'false');
            }
        },
        onClick_Travel: function() {
            if ($('#POS_CE_TRAVEL').prop('checked')) {
                hyf.util.showComponent('layout_group_travel_per');
            } else {
                $('#POS_CE_TRAVEL_PER').val('');
                hyf.util.hideComponent('layout_group_travel_per');
            }
        },
        onClick_FinancialStatement: function() {
            if ($('#POS_CE_FINANCIAL_DISC').prop('checked')) {
                $('#POS_CE_FINANCIAL_TYPE_ID').removeClass('hidden').attr('_required', 'true');
            } else {
                $('#POS_CE_FINANCIAL_TYPE_ID').addClass('hidden').attr('_required', 'false');
            }
        }
    },

	// This method/function sets payPlanDetails object (above)
	// @param: selectedPlay - pay plan (GS, ES, WG, etc.) selected by the user
    setPayPlanDetails: function (selectedPayPlan) {
        this.payPlanDetails.payPlan = "",
        this.payPlanDetails.gradeRequired = 0;
        this.payPlanDetails.minGrade = 0;
        this.payPlanDetails.maxGrade = 0;
        this.payPlanDetails.restrictGradeAt = 0;

        if (selectedPayPlan != "") {
            var ppDetail = $('#GRADE_SOURCE option[value="' + selectedPayPlan + '"]').attr('selected',true).text().split(',');
            this.payPlanDetails.payPlan = selectedPayPlan,
            this.payPlanDetails.gradeRequired = parseInt(ppDetail[0])
            this.payPlanDetails.minGrade = parseInt(ppDetail[1]);
            this.payPlanDetails.maxGrade = parseInt(ppDetail[2]);
            this.payPlanDetails.restrictGradeAt = parseInt(ppDetail[3]);
        }
    },
	// This method/function shows an alert and clears the
	// text due to invalid values
    showAlert: function($this, id, msg) {
        var pos = $this.position();
        $("#" + id).remove();
        $this.after("<span id='" + id + "' class='limitAlert' role='alert'>" + msg + "</span>");
        $("#" + id).css({top: pos.top + 20, left: pos.left + 30, position:'absolute'});
        setTimeout(function() {
            $("#" + id).remove();
        }, 2000);
    },
	// This method/function sets auto complete for Duty Station
	// and Report to Supervisor
    setAutoComplete: function () {
        $("#POS_LOCATION_SEARCH").autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: stratConPOS.baseURL + "SearchDutyStation.do?searchString=" + $('#POS_LOCATION_SEARCH').val(),
                    dataType: "xml",
                    cache: false,
                    success: function (xmlResponse) {
                        var data = $("record", xmlResponse ).map(function() {
                            return {
                                loc_id: $( "LOC_ID", this ).text(),
                                loc_state: $( "LOC_STATE", this ).text(),
                                loc_city: $( "LOC_CITY", this ).text()
                            };
                        }).get();
                        response(data);
                    }
                })
            },
            minLength: 2,
            change: function (e, u) {
                var pos = $(this).position();
                if (u.item == null) {
                    stratConPOS.showAlert($(this),'POS_nomatch',"Invalid Selection:<br />Item must be selected from the available options.");
                    $(this).val("");
                    return false;
                }
            },

            select: function (event, ui) {
                var li = "<li id=\"" + ui.item.loc_id + "\">";
                li += getAutoCompRemoveIconElement(ui.item.loc_id, ui.item.loc_city, '305');

                li += ui.item.loc_city + ', ' + ui.item.loc_state +  "</li>";
                $("#POS_LOC_DISP").append(li).removeClass('hidden');
                $("#POS_LOCATION_SEARCH_container").addClass('hidden');
                $("#POS_LOCATION_SEARCH").attr('_required', 'false')
                $('#POS_LOCATION').val(ui.item.loc_id);
            },
            open: function() {
                $(".ui-autocomplete").css("z-index", 5000);
            },
            close: function() {
                $(".ui-autocomplete").css("z-index", 1);
            }
        })
        .autocomplete().data("ui-autocomplete")._renderItem = function (ul, item) {
            return $("<li>")
            .append("<a>" + item.loc_city + ", "  + item.loc_state + "</a>")
            .appendTo(ul);
        };

        $("#SUPERVISOR_SEARCH").autocomplete({
            source: function (request, response) {
                $.ajax({
                    url: stratConPOS.baseURL + "SearchPeople.do?searchString=" + $('#SUPERVISOR_SEARCH').val(),
                    dataType: "xml",
                    cache: false,
                    success: function (xmlResponse) {
                        var data = $("record", xmlResponse ).map(function() {
                            return {
                                mid: $( "MID", this ).text(),
                                dspname: $( "DSPNAME", this ).text(),
                                deptname: $( "DEPTNAME", this ).text(),
                                email: $( "EMAIL", this ).text()
                            };
                        }).get();
                        response(data);
                    }
                })
            },
            minLength: 2,
            change: function (e, u) {
                var pos = $(this).position();
                if (u.item == null) {
                    stratConPOS.showAlert($(this),'SUPERVISOR_nomatch',"Invalid Selection:<br />Item must be selected from the available options.");
                    $(this).val("");
                    return false;
                }
            },
            select: function (event, ui) {
                var li = "<li id=\"ss" + ui.item.mid + "\">";
                li += getAutoCompRemoveIconElement('ss' + ui.item.mid, ui.item.dspname, '505');
                li += ui.item.dspname + '/' + ui.item.email +  "</li>";
                $("#POS_REPORT_SUPERVISOR_DSP").append(li).removeClass('hidden');
                $("#SUPERVISOR_SEARCH_container").addClass('hidden');
                $("#SUPERVISOR_SEARCH").attr('_required', 'false')
                $('#POS_REPORT_SUPERVISOR').val(ui.item.mid);
            },
            open: function() {
                $(".ui-autocomplete").css("z-index", 5000);
            },
            close: function() {
                $(".ui-autocomplete").css("z-index", 1);
            }
        })
        .autocomplete().data("ui-autocomplete")._renderItem = function (ul, item) {
            return $("<li>")
            .append("<a>"  + item.dspname + '/' + item.email +  "</a>")
            .appendTo(ul);
        };
    },

	// This method/function displays the grades based on them having a value
	// this is needed to display data returned from the DB.  If no
	// grades are displayed, a default empty grade is displayed.
    manageGrades: function() {
        var numOfGrades = 0;
        for(var i = 1; i < stratConPOS.grades.length; i++) {
            stratConPOS.hideGradeRow(i);
            $(stratConPOS.grades[i].id).attr('_required', 'false');
            if($(stratConPOS.grades[i].id).val() > 0) {
                numOfGrades++;
                $(stratConPOS.grades[i].id).attr('_required', 'true');
                stratConPOS.showGradeRow(i);
                $(stratConPOS.grades[i].pdn).on('change', function(){
                    stratConPOS.toggleClassDate($(this));
                }).trigger('change');

                $(stratConPOS.grades[i].pdn).on('keyup keypress blur change', function() {
                    stratConPOS.eventHandler.onKeyChange_pdn($(this));
                });

                $(stratConPOS.grades[i].cdt).on('change', function() {
                    stratConPOS.eventHandler.onChange_cdt($(this));
                });
            }
        }
        if (numOfGrades == 4) {
            stratConPOS.hideAddGradeButton();
        }
    },

    evaluateGLASection: function() {
        var checkboxes = $('#GLA input.checkbox');
        $.each(checkboxes, function(index, checkbox) {
            var checkboxID = $(checkbox).attr('id');
            var grade = checkboxID.substring(7, checkboxID.length);
            var found = false;

            for (var index = 0; index < stratConPOS.grades.length; index++) {
                var curGrade = $(stratConPOS.grades[index].id).val();
                if (curGrade == grade) {
                    found = true;
                    break;
                }
            }

            if (found == false) {
                $(checkbox).prop('checked', false);
                $(checkbox).attr('disabled', true);
            } else {
                $(checkbox).attr('disabled', false);
            }

            if (grade > stratConPOS.payPlanDetails.maxGrade) {
                $('#POS_GA_' + grade + "_label").addClass('hidden');
                $('#POS_GA_' + grade).addClass('hidden').attr('checked', false);
            } else {
                $('#POS_GA_' + grade + "_label").removeClass('hidden');
                $('#POS_GA_' + grade).removeClass('hidden');
            }
        });
        //console.log("evaluateGLASection is finished.");
    },
	// This method/function sets the available options in each of the Grade dropdowns
	// The function removes selected values and uses the restrict
	// value to detirmine the available options
    setGradeOptions: function() {
        var minFPL = 1;
        for (var i = 0; i < stratConPOS.grades.length; i++) {
            var gradeCurrentValue = $(stratConPOS.grades[i].id).val();
            var maxgrade = i == 0 ? stratConPOS.payPlanDetails.maxGrade : (stratConPOS.payPlanDetails.restrictGradeAt - 1);
            var options = "<option value selected>Select One</option>";
            for (var g = stratConPOS.payPlanDetails.minGrade; g <= maxgrade; g++) {
                var gLabel = g < 10 ? ("0" + g) : ('' + g);
                options += "<option value=\"" + g + "\">" + gLabel + "</option>"
            }
            $(stratConPOS.grades[i].id)
                .find('option')
                .remove()
                .end()
                .append(options);
            if ($.isNumeric(gradeCurrentValue)) {
                $(stratConPOS.grades[i].id).val(gradeCurrentValue);
            }
        }
        for (var i = 0; i < stratConPOS.grades.length; i++) {
            var checkValue = $(stratConPOS.grades[i].id).val();
            if ($.isNumeric(checkValue)) {
                if (parseInt(minFPL) < parseInt(checkValue)) {
                    minFPL = parseInt(checkValue);
                }
                for(var j = 0; j < stratConPOS.grades.length; j++) {
                    if (i != j) {
                        $(stratConPOS.grades[j].id + " option").each( function() {
                            var gradeValue = $(this).val();
                            if ($.isNumeric(gradeValue) && checkValue == gradeValue) {
                                $(stratConPOS.grades[j].id + " option[value='" + gradeValue +"']").remove();
                            }
                        })
                    }
                }
            }
        }
        if (parseInt(minFPL) < parseInt(stratConPOS.payPlanDetails.restrictGradeAt)) {
            var fplValue = $("#POS_PERFORMANCE_LEVEL").val();
            var options = "<option value selected>Select One</option>";

            for (var g = minFPL; g < stratConPOS.payPlanDetails.restrictGradeAt; g++) {
                var gLabel = g < 10 ? ("0" + g) : ('' + g);
                options += "<option value=\"" + g + "\">" + gLabel + "</option>"
            }

            $("#POS_PERFORMANCE_LEVEL")
                .find('option')
                .remove()
                .end()
                .append(options);

            if ($.isNumeric(fplValue) && parseInt(minFPL) <= parseInt(fplValue)
                && parseInt(fplValue) < stratConPOS.payPlanDetails.restrictGradeAt) {
                $("#POS_PERFORMANCE_LEVEL").val(fplValue);
            }
            if (stratConPOS.prevRestricatedGrade) {
                stratConPOS.showAddGradeButton();
                stratConPOS.prevRestricatedGrade = false;
            }
        } else {
            for (var i = 1; i < stratConPOS.grades.length; i++) {
                stratConPOS.clearGrade(i);
                stratConPOS.hideGradeRow(i);
            }
            $("#POS_PERFORMANCE_LEVEL")
                .find('option')
                .remove()
                .end()
                .append('<option selected value="' + minFPL + '">' + minFPL + '</option>');
            stratConPOS.prevRestricatedGrade = true;
            stratConPOS.hideAddGradeButton();
        }

        stratConPOS.evaluateGLASection();
    },

    showFullPerformanceLevel: function() {
        hyf.util.showComponent('layout_fpl_group');
        stratConPOS.showAddGradeButton();
        stratConPOS.showGLASection();
        stratConPOS.manageGrades();
    },
    hideFullPerformanceLevel: function() {
        stratConPOS.removeGrade(); // Full Performance will be reset here.
        stratConPOS.hideAddGradeButton();
        stratConPOS.hideGLASection();
        $('#POS_PERFORMANCE_LEVEL option').remove();
        hyf.util.hideComponent('layout_fpl_group');
    },
	// This method/function uses the value from the POS_PAY_PLAN field to
	// manage grade options.
    payPlanChange: function() {
        stratConPOS.toggleMedOfficer();
        stratConPOS.setPayPlanDetails($('#POS_PAY_PLAN').val());
        $(stratConPOS.grades[0].lbl).removeClass('hidden');
        $(stratConPOS.grades[0].id).attr('_required', true).removeClass('hidden');
        $(stratConPOS.grades[0].pdn).on('keyup keypress blur change', function() {
            stratConPOS.eventHandler.onKeyChange_pdn($(this));
        });
        $(stratConPOS.grades[0].cdt).on('change', function() {
            stratConPOS.eventHandler.onChange_cdt($(this));
        });
        $(stratConPOS.grades[0].id).attr('_required', true).on('change', stratConPOS.setGradeOptions);
        for (var i = 1; i < stratConPOS.grades.length; i++) {
            $(stratConPOS.grades[i].id).on('change', stratConPOS.setGradeOptions);
        }
        stratConPOS.setGradeOptions();

        $(stratConPOS.grades[0].pdn).on('change', function() {
            stratConPOS.toggleClassDate($(this));
        });
        stratConPOS.toggleClassDate($(stratConPOS.grades[0].pdn));

        var requestType = $("#SG_RT_ID option:selected").text();
        var appointmentType = $("#SG_AT_ID option:selected").text();

        if (stratConPOS.payPlanDetails.payPlan != '' ) {
            if (stratConPOS.payPlanDetails.gradeRequired == 1) {
                if (requestType == 'Appointment' && appointmentType == 'Expert/Consultant') {
                    stratConPOS.hideFullPerformanceLevel();
                } else {
                    stratConPOS.showFullPerformanceLevel();
                }
            } else {
                stratConPOS.hideFullPerformanceLevel();
            }
        } else {
            stratConPOS.hideFullPerformanceLevel();
        }

    },

	// This method/function removes grade from the screen and clears all values
	// If no argumments are passed all rows are removed
	// otherwise the idx value passed is removed.
    removeGrade: function(idx) {
        if (idx) {
            stratConPOS.clearGrade(idx);
            stratConPOS.hideGradeRow(idx);
        } else {
            $(stratConPOS.grades[0].lbl).addClass('hidden');
            $(stratConPOS.grades[0].id).attr('_required', false).addClass('hidden');
            for(var i = 1; i < stratConPOS.grades.length; i++) {
                stratConPOS.clearGrade(i);
                stratConPOS.hideGradeRow(i);
            }
        }
        stratConPOS.setGradeOptions();
        stratConPOS.showAddGradeButton();

		// Reset error display because adding or removing new fields makes existing error bubble location invalid.
		// WARING: This implementation assumes that the addGrade() method is only called by user's clicking the Add Grade button, not
		// programatically.  In other words, Position tab is currently visible, the button is visible, and user manually clicks on the button.
		var errorDisp = hyf.FMAction.getErrorDisplay();
		errorDisp.resetDisplay(document.getElementById("stratcon_pos_group"));
    },

	// This method/function adds the first available grade row to the screen.
    addGrade: function() {
        var added = false;
        for (var i = 0; i < stratConPOS.grades.length && !added; i++) {
            if ($(stratConPOS.grades[i].id).attr('_required') != 'true') {
                $(stratConPOS.grades[i].id).attr('_required', 'true');
                stratConPOS.showGradeRow(i);
                added = true;
                $(stratConPOS.grades[i].pdn).on('change', function() {
                    stratConPOS.toggleClassDate($(this));
                }).trigger('change');
                $(stratConPOS.grades[i].pdn).on('keyup keypress blur change', function() {
                    stratConPOS.eventHandler.onKeyChange_pdn($(this));
                });
                $(stratConPOS.grades[i].cdt).on('change', function() {
                    stratConPOS.eventHandler.onChange_cdt($(this));
                });
            }
        }
        if (i == stratConPOS.grades.length) {
            stratConPOS.hideAddGradeButton();
        }

		// Reset error display because adding or removing new fields makes existing error bubble location invalid.
		// WARING: This implementation assumes that the addGrade() method is only called by user's clicking the Add Grade button, not
		// programatically.  In other words, Position tab is currently visible, the button is visible, and user manually clicks on the button.
		var errorDisp = hyf.FMAction.getErrorDisplay();
		errorDisp.resetDisplay(document.getElementById("stratcon_pos_group"));
    },

	// This method/function sets all the values related to grade to null based on the index
	// @param idx - index value of the grade to clear
    clearGrade: function(idx){
        var selectedGrade = $(stratConPOS.grades[idx].id + ' option:selected').text();

        $(stratConPOS.grades[idx].id).val('').attr('_required', false);
        $(stratConPOS.grades[idx].id + 'option[text="Select One"]').attr('selected', true);
        $(stratConPOS.grades[idx].cdt).val('').attr('_required', false);
        $(stratConPOS.grades[idx].pdn).val('').attr('_required', false);
        $('#POS_GA_' + selectedGrade).prop('checked', false);
        $('#POS_GA_' + selectedGrade).attr('disabled', true);
    },

    // Shows Add Grade button
    showAddGradeButton: function() {
        stratConPOS._toggleAddGrade(true);
    },
    // Hides Add Grade button
    hideAddGradeButton: function() {
        stratConPOS._toggleAddGrade(false);
    },
    _toggleAddGrade: function(show) {
        $('#POSITION_GRADE_GRID input.addGrade').addClass('hidden');
        if (show) {
            $('#POSITION_GRADE_GRID input.addGrade').removeClass('hidden');
        }
    },

    // Shows grade rows
    showGradeRow: function(idx) {
        stratConPOS._toggleGradeRow(idx, true);
    },
    // Hides grade rows
    hideGradeRow: function(idx) {
        stratConPOS._toggleGradeRow(idx, false);
    },
    _toggleGradeRow: function(idx,show) {
        var $lblRow = $(stratConPOS.grades[idx].lbl).closest('tr');
        var $fldRow = $lblRow.next('tr');
        if (show) {
            var sel = $(stratConPOS.grades[idx].id).val();
            $lblRow.removeClass('hidden');
            $fldRow.removeClass('hidden');
            $(stratConPOS.grades[idx].id).attr('_required', true).trigger('change');
        } else {
            $lblRow.addClass('hidden');
            $fldRow.addClass('hidden');
        }
    },

	// This method/function shows and hides the Classification date based on the
	// PD Number/Job Code having a value
	// @param $fld - Changed PDNumber/JobCode Field that triggered this method
    toggleClassDate: function($fld) {
		if (typeof $fld == "undefined" || $fld == null || typeof $fld.attr('id') == "undefined" || $fld.attr('id') == null) return;
		var idx = $fld.attr('id').slice(-1) - 1;
        if ($(stratConPOS.grades[idx].pdn).val().length > 0) {
            $(stratConPOS.grades[idx].cdtl).removeClass('hidden');
            $(stratConPOS.grades[idx].cdta).removeClass('hidden');
            $(stratConPOS.grades[idx].cdt).removeClass('hidden').attr('_required',true);
        } else {
            $(stratConPOS.grades[idx].cdtl).addClass('hidden');
            $(stratConPOS.grades[idx].cdta).addClass('hidden');
            $(stratConPOS.grades[idx].cdt).addClass('hidden').attr('_required',false).val('');
        }
    },

	// This method/function shows and hides the medical officer fields
	// based on the pay plan and series
    toggleMedOfficer: function() {
        $('#POS_MED_OFFICERS_ID_label_container').addClass('hidden');
        $('#POS_MED_OFFICERS_ID_container').addClass('hidden');
        $('#POS_MED_OFFICERS_ID').attr('_required', 'false');
        $('#MED_NOTE_TEXT').addClass('hidden');

        if ($('#POS_PAY_PLAN').val() == 'GS') {
            if($('#POS_SERIES').val() == '0602') {
                $('#POS_MED_OFFICERS_ID_label_container').removeClass('hidden');
                $('#POS_MED_OFFICERS_ID_container').removeClass('hidden');
                $('#POS_MED_OFFICERS_ID').attr('_required', 'true');
                $('#MED_NOTE_TEXT').removeClass('hidden').text('');
            } else if($('#POS_SERIES').val() == '0680') {
                $('#MED_NOTE_TEXT').removeClass('hidden').html('<strong>NOTE: For Dental Officer, GS-0680, Positions, Physician and Dentist Pay (PDP) is authorized.</strong>');
            }
        }
    },

    // Shows GLA section
    showGLASection: function() {
        if ($('#SG_RT_ID :selected').text() == 'Recruitment' && this.payPlanDetails.payPlan != '' ) {
            stratConPOS._toggleGLA(true);
        } else {
            stratConPOS._toggleGLA(false);
        }
    },
    // Hides GLA section
    hideGLASection: function() {
        stratConPOS._toggleGLA(false);
    },
    _toggleGLA: function(show) {
        if (show) {
            if ($('#GLA').hasClass('hidden') == true) {
                $("#GLA").removeClass('hidden');
                stratConPOS.evaluateGLASection();
            }
        } else {
            if ($('#GLA').hasClass('hidden') == false) {
                $("#GLA").addClass('hidden');
                for (var i = 0; i <= 15; i++) {
                    $('#POS_GA_' + i).attr('checked', false);
                }
            }
        }
    },

	// Show or hide fields that are dependent on Request Type of "Appointment"
	showHideAppointmentFields: function(){
		var requestType = $("#SG_RT_ID option:selected").text();
		if (requestType == "Appointment"){
			$("#appt_depend_group").show();
			$("#POS_VACANCIES").val("");
		} else {
            $("#appt_depend_group").hide();

			// clear values when hidden
			$("#POS_CNDT_LAST_NM").val("");
			$("#POS_CNDT_FIRST_NM").val("");
		}
	},

    hideElement: function(id) {
        var targetElement = $('#' + id);
        var nonGroupElements = ['input', 'select', 'textarea', 'INPUT', 'SELECT', 'TEXTAREA'];

        if (targetElement.length > 0) {
            var tagName = targetElement[0].tagName;

            if (CMSUtility.existInArray(nonGroupElements, tagName) == true) {
                $(targetElement).val('');
            } else {
                var childElements = $('input.checkbox, input.textbox, input.dijitInputInner, select.select, textarea.textbox', $('#' + id));
                $.each(childElements, function(index, component) {
                    var childID = $(this).attr('id');
                    $(this).val('');
                });
            }
        }

        $(targetElement).hide();
    },
    showHideFieldsBasedOnContext: function() {
        CMSUtility.debugLog('STRATCON_POS - showHideFieldsBasedOnContext START');

        var recruitmentRule = {
            'layout_noso':'hide',
            'payplan_series_group': 'show',
            'POSITION_GRADE_GRID': 'show',
            'senstv_desig_group': 'show',
            'suprv_med_group': 'show',
            'layout_group_pos_skill': 'show',
            'GLA_group': 'show',
            'condition_employment_group':'show',
            'remark_section_group':'show',
            'suprv_grid': 'show',
            'vice_group': 'show',
            'vice_name_group': 'show',
            'scPosGrid_label_container': 'show',
            'budget_ofm_group': 'show',
            'can_group' : 'show',
            'layout_pos_spacer_1': 'show',
            'days_advts_group': 'show',
            'pos_appttp_group': 'show',
            'NTE_group':'',
            'layout_pos_spacer_2': 'show',
            'wrk_sched_group': 'show',
            'hr_wk_group': 'show',
            'num_vac_group': 'show',
            'layout_dual_employment':'hide',
            'layout_group_pos_skill': 'show'};
        var classificationRule = {
            'layout_noso':'hide',
            'payplan_series_group': 'show',
            'POSITION_GRADE_GRID': 'show',
            'senstv_desig_group': 'show',
            'suprv_med_group': 'show',
            'layout_group_pos_skill': 'show',
            'GLA_group': 'show',
            'condition_employment_group':'show',
            'remark_section_group':'show',
            'suprv_grid': 'show',
            'vice_group': 'show',
            'vice_name_group': 'show',
            'scPosGrid_label_container': 'show',
            'budget_ofm_group': 'hide',
            'can_group' : 'hide',
            'layout_pos_spacer_1': 'hide',
            'days_advts_group': 'hide',
            'pos_appttp_group': 'hide',
            'NTE_group':'hide',
            'layout_pos_spacer_2': 'hide',
            'wrk_sched_group': 'hide',
            'hr_wk_group': 'hide',
            'num_vac_group': 'hide',
            'layout_dual_employment':'hide',
            'layout_group_pos_skill': 'show' };
        var appointmentRule = {
            'layout_noso':'hide',
            'payplan_series_group': 'show',
            'POSITION_GRADE_GRID': 'show',
            'senstv_desig_group': 'show',
            'suprv_med_group': 'show',
            'layout_group_pos_skill': 'show',
            'GLA_group': 'show',
            'condition_employment_group':'show',
            'remark_section_group':'show',
            'suprv_grid': 'show',
            'vice_group': 'show',
            'vice_name_group': 'show',
            'scPosGrid_label_container': 'show',
            'budget_ofm_group': 'show',
            'can_group' : 'show',
            'layout_pos_spacer_1': 'show',
            'days_advts_group': 'hide',
            'pos_appttp_group': 'show',
            'NTE_group':'',
            'layout_pos_spacer_2': 'show',
            'wrk_sched_group': 'show',
            'hr_wk_group': 'show',
            'num_vac_group': 'hide',
            'layout_dual_employment':'hide',
            'layout_group_pos_skill': 'hide'};
        var appointmentExpertConsultantRule = {
            'layout_noso':'hide',
            'payplan_series_group': 'show',
            'POSITION_GRADE_GRID': 'hide',
            'senstv_desig_group': 'show',
            'suprv_med_group': 'show',
            'layout_group_pos_skill': 'show',
            'GLA_group': 'show',
            'condition_employment_group':'show',
            'remark_section_group':'show',
            'suprv_grid': 'show',
            'vice_group': 'show',
            'vice_name_group': 'show',
            'scPosGrid_label_container': 'show',
            'budget_ofm_group': 'show',
            'can_group' : 'show',
            'layout_pos_spacer_1': 'show',
            'days_advts_group': 'hide',
            'pos_appttp_group': 'show',
            'NTE_group':'',
            'layout_pos_spacer_2': 'show',
            'wrk_sched_group': 'show',
            'hr_wk_group': 'show',
            'num_vac_group': 'hide',
            'layout_dual_employment':'show',
            'layout_group_pos_skill': 'hide'};
        var appointmentVolunteerRule = {
            'layout_noso':'hide',
            'payplan_series_group': 'hide',
            'POSITION_GRADE_GRID': 'hide',
            'senstv_desig_group': 'hide',
            'suprv_med_group': 'hide',
            'layout_group_pos_skill': 'hide',
            'GLA_group': 'hide',
            'condition_employment_group':'hide',
            'remark_section_group':'hide',
            'suprv_grid': 'hide',
            'vice_group': 'hide',
            'vice_name_group': 'hide',
            'scPosGrid_label_container': 'hide',
            'budget_ofm_group': 'hide',
            'can_group' : 'hide',
            'layout_pos_spacer_1': 'hide',
            'days_advts_group': 'hide',
            'pos_appttp_group': 'hide',
            'NTE_group':'hide',
            'layout_pos_spacer_2': 'hide',
            'wrk_sched_group': 'hide',
            'hr_wk_group': 'hide',
            'num_vac_group': 'hide',
            'layout_dual_employment':'hide',
            'layout_group_pos_skill': 'hide'};
        var appointmentIPARule = {
            'layout_noso':'show',
            'payplan_series_group': 'hide',
            'POSITION_GRADE_GRID': 'hide',
            'senstv_desig_group': 'show',
            'suprv_med_group': 'true',
            'layout_group_pos_skill': 'hide',
            'GLA_group': 'hide',
            'condition_employment_group':'true',
            'remark_section_group':'true',
            'suprv_grid': 'show',
            'vice_group': 'show',
            'vice_name_group': 'show',
            'scPosGrid_label_container': 'hide',
            'budget_ofm_group': 'show',
            'can_group' : 'show',
            'layout_pos_spacer_1': 'show',
            'days_advts_group': 'hide',
            'pos_appttp_group': 'show',
            'NTE_group':'show',
            'layout_pos_spacer_2': 'show',
            'wrk_sched_group': 'show',
            'hr_wk_group': 'show',
            'num_vac_group': 'hide',
            'layout_dual_employment':'hide',
            'layout_group_pos_skill': 'hide'
        };

        var targetRule = {};
        var requestType = $('#SG_RT_ID option:selected').text();
        var appointmentType = $('#SG_AT_ID option:selected').text();

        if (requestType == 'Recruitment') {
            CMSUtility.debugLog('STRATCON_POS - showHideFieldsBasedOnContext - Request Type is Recruitment');
            targetRule = recruitmentRule
        } else if (requestType == 'Classification Only') {
            CMSUtility.debugLog('STRATCON_POS - showHideFieldsBasedOnContext - Request Type is Classification Only');
            targetRule = classificationRule;
        } else if (requestType == 'Appointment') {
            if (appointmentType == 'Volunteer') {
                CMSUtility.debugLog('STRATCON_POS - showHideFieldsBasedOnContext - Request Type is Appointment with Volunteer');
                targetRule = appointmentVolunteerRule;
            } else if (appointmentType == 'Intergovernmental Personnel Act (IPA)') {
                CMSUtility.debugLog('STRATCON_POS - showHideFieldsBasedOnContext - Request Type is Appointment with IPA');
                targetRule = appointmentIPARule;
            } else if (appointmentType == 'Expert/Consultant') {
                CMSUtility.debugLog('STRATCON_POS - showHideFieldsBasedOnContext - Request Type is Appointment with Expert/Consultant');
                targetRule = appointmentExpertConsultantRule;
            } else {
                CMSUtility.debugLog('STRATCON_POS - showHideFieldsBasedOnContext - Request Type is Appointment');
                targetRule = appointmentRule;
            }
        }

        if (requestType == 'Appointment' && appointmentType == 'Intergovernmental Personnel Act (IPA)') {
            var targetOption = $('#POS_WORK_SCHED_ID option:contains("Intermittent")');
            var value = $(targetOption).attr('value');
            $(targetOption).replaceWith('<hiddenOption value="' + value + '">' + $(targetOption).html() + '</hiddenOption>');
        } else {
            var targetOption = $('#POS_WORK_SCHED_ID hiddenOption:contains("Intermittent")');
            var value = $(targetOption).attr('value');
            $(targetOption).replaceWith('<option value="' + value + '">' + $(targetOption).html() + '</option>');
        }

        if (requestType == 'Appointment' && (appointmentType == 'Expert/Consultant' || appointmentType == 'Intergovernmental Personnel Act (IPA)')) {
            // Type of Appointment
            $.each($('#POS_AT_ID option'), function(index, component) {
                var label = $(this).text();
                if (label == 'Temporary') {
                    var value = $(this).attr('value');
                    $('#POS_AT_ID').val(value);
                } else {
                    var value = $(this).attr('value');
                    $(this).replaceWith('<hiddenOption value="' + value + '">' + $(this).html() + '</hiddenOption>');
                }
            });

            // Pay plan
            var plansForExpert = ['', 'ED', 'EE', 'EF', 'EG'];
            $.each($('#POS_PAY_PLAN option'), function(index, component) {
                var value = $(this).attr('value');
                if (false == CMSUtility.existInArray(plansForExpert, value)) {
                    $(this).replaceWith('<hiddenOption value="' + value + '">' + $(this).html() + '</hiddenOption>');
                }
            });
        } else {
            // Type of Appointment
            $.each($('#POS_AT_ID hiddenOption'), function(index, component) {
                var value = $(this).attr('value');
                $(this).replaceWith('<option value="' + value + '">' + $(this).html() + '</option>');
            });

            // Pay plan
            $.each($('#POS_PAY_PLAN hiddenOption'), function(index, component) {
                var value = $(this).attr('value');
                $(this).replaceWith('<option value="' + value + '">' + $(this).html() + '</option>');
            });
        }

        if (requestType == 'Appointment' && (appointmentType == 'Expert/Consultant' || appointmentType == 'Intergovernmental Personnel Act (IPA)')) {
            // Position Is
            $.each($('#POS_SUPERVISORY option'), function(index, component) {
                var label = $(this).text();
                if (label == 'Non-Supervisor (Code 8)') {
                    var value = $(this).attr('value');
                    $('#POS_SUPERVISORY').val(value);
                } else {
                    var value = $(this).attr('value');
                    $(this).replaceWith('<hiddenOption value="' + value + '">' + $(this).html() + '</hiddenOption>');
                }
            });
        } else {
            // Position Is
            $.each($('#POS_SUPERVISORY hiddenOption'), function(index, component) {
                var value = $(this).attr('value');
                $(this).replaceWith('<option value="' + value + '">' + $(this).html() + '</option>');
            });
        }

        for (var item in targetRule) {
            var showHide = targetRule[item];
            if (showHide == 'show') {
                $('#' + item).css('visibility', '');
                $('#' + item).show();
            } else if (showHide == 'hide') {
                stratConPOS.hideElement(item); // Hide and Reset
            }
        }

        var dualEmployment = $('#POS_DUAL_EMPLMT').val();
        if (dualEmployment == null || dualEmployment == '') {
            $('#POS_DUAL_EMPLMT').val("0");
        }

        stratConPOS.payPlanChange();
        stratConPOS.eventHandler.onChange_WorkSchedule();
        stratConPOS.eventHandler.onChange_TypeOfAppointment();
        stratConPOS.eventHandler.onChange_Vice();
        stratConPOS.eventHandler.onChange_SponsoringFundPercentage();

        CMSUtility.debugLog('STRATCON_POS - showHideFieldsBasedOnContext START');
    },

	// Init function/method called from On PageLoad; performs
	// various activities to setup the page UI, hide/show fields
    init: function() {
        CMSUtility.debugLog('STRATCON_POS - init START');
        stratConPOS.setAutoComplete();

        var selectedPayPlan = $('POS_PAY_PLAN').val();
        stratConPOS.setPayPlanDetails(selectedPayPlan);

        $('#POS_PAY_PLAN').on('change',stratConPOS.payPlanChange);
        $('#POSITION_GRADE_GRID').on('click', 'input.removeGrade', function() {
            stratConPOS.removeGrade($(this).attr('id').slice(-1) -1);
        });
        $('#POSITION_GRADE_GRID').on('click', 'input.addGrade', stratConPOS.addGrade);
        $('#POS_AT_ID').on('change', stratConPOS.eventHandler.onChange_TypeOfAppointment);
        $('#POS_WORK_SCHED_ID').on('change', stratConPOS.eventHandler.onChange_WorkSchedule);

        $('#POS_CE_FINANCIAL_DISC').on('click', stratConPOS.eventHandler.onClick_FinancialStatement);
        stratConPOS.eventHandler.onClick_FinancialStatement();

        $('#POS_CE_TRAVEL').on('click', stratConPOS.eventHandler.onClick_Travel);
        stratConPOS.eventHandler.onClick_Travel();

        $('#POS_CE_LIC').on('click', stratConPOS.eventHandler.onClick_LicenseCheckBox);
        stratConPOS.eventHandler.onClick_LicenseCheckBox();

        $('#POS_VICE').on('change', stratConPOS.eventHandler.onChange_Vice);
        $('#POS_SERIES').on('change', stratConPOS.toggleMedOfficer);
        $('#SG_CT_ID').on('change', stratConPOS.eventHandler.onChange_ClassificationType);
        stratConPOS.eventHandler.onChange_ClassificationType();

        $("#POS_LOC_DISP").on("click keyup", "img", function (e) {
            if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
                $("#POS_LOC_DISP").addClass('hidden').empty();
                $("#POS_LOCATION_SEARCH_container").removeClass('hidden');
                $("#POS_LOCATION_SEARCH").attr('_required', 'true');
                $('#POS_LOCATION').val('');
            }
        });

        if ($('#POS_LOCATION').val() != "") {
            var li = "<li id=\"" + $('#POS_LOCATION').val() + "\">";
            if ($('#h_readOnly').val() != 'y') {
                li += getAutoCompRemoveIconElement($('#POS_LOCATION').val(), $('#LOC_DISPLAY').val(), '305');
            }
            li += $('#LOC_DISPLAY').val() +  "</li>";
            $("#POS_LOC_DISP").append(li).removeClass('hidden');
            $("#POS_LOCATION_SEARCH_container").addClass('hidden');
            $("#POS_LOCATION_SEARCH").attr('_required', 'false');
        }

        $("#POS_REPORT_SUPERVISOR_DSP").on("click keyup", "img", function () {
            if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
                $("#POS_REPORT_SUPERVISOR_DSP").addClass('hidden').empty();
                $("#SUPERVISOR_SEARCH_container").removeClass('hidden');
                $("#SUPERVISOR_SEARCH").attr('_required', 'true');
                $('#POS_REPORT_SUPERVISOR').val('');
            }
        });
        if ($('#POS_REPORT_SUPERVISOR').val() != '') {
            var li = "<li id=\"ss" + $('#POS_REPORT_SUPERVISOR').val()+ "\">";
            if ($('#h_readOnly').val() != 'y') {
                li += getAutoCompRemoveIconElement('ss' + $('#POS_REPORT_SUPERVISOR').val(), $('#SUPERVISOR_DISPLAY_DATA').val(), '505');
            }
            li += $('#SUPERVISOR_DISPLAY_DATA').val() +  "</li>";
            $("#POS_REPORT_SUPERVISOR_DSP").append(li).removeClass('hidden');
            $("#SUPERVISOR_SEARCH_container").addClass('hidden');
            $("#SUPERVISOR_SEARCH").attr('_required', 'false')
        }

        $('#SG_RT_ID').on('keyup keypress blur change', stratConPOS.eventHandler.onKeyChange_RequestType);

        $('#POS_SPNSR_ORG_FUND_PC').on('keyup keypress blur change', stratConPOS.eventHandler.onChange_SponsoringFundPercentage);

        $(document).on("CMS_ALL_TAB_LOADED", function() {
            $('#SG_CT_ID').on('change', stratConPOS.eventHandler.onChange_ClassificationType);
            stratConPOS.eventHandler.onChange_ClassificationType();
            stratConPOS.eventHandler.onKeyChange_RequestType();
            stratConPOS.payPlanChange();
			stratConPOS.showHideAppointmentFields();
            stratConPOS.showHideFieldsBasedOnContext();
        });

        StratConMAIN.setAlwaysDisabled('POS_HOURS_PER_WEEK');

        CMSUtility.debugLog('STRATCON_POS - init END');
    }
}

function validateStratconPOSCustom() {
    var GLACheckBoxes = $('#GLA input:checkbox:visible');
    var requestType = $('#SG_RT_ID :selected').text();
    var anyGLACheckBoxChecked = false;

    if (requestType == 'Recruitment' && GLACheckBoxes.length > 0) {
        $.each(GLACheckBoxes, function(index, checkbox) {
            var checked = $(checkbox).prop('checked');
            if (checked == true) {
                anyGLACheckBoxChecked = true;
            }
        });
    } else {
        anyGLACheckBoxChecked = true;
    }

    if (anyGLACheckBoxChecked == true) {
        $("#GLA i.fiError").remove();
    } else {
        $("#GLA i.fiError").remove();
        $("#GLA_Title_marker").after('<i class="feedbackIcon fiError" style="position: relative; font-size: 13px; font-weight: normal;"></i>');
    }

    return anyGLACheckBoxChecked;
}
