var CMSUtility = {
    getAnchorID: function(tabID) {
        return "tab_control_tab_" + tabID;
    },
    getTabIDFromAnchor: function(node) {
        if (node != null && node.id != null) {
            var lastIndex = node.id.lastIndexOf("_");
            if (lastIndex >= 0) {
                return node.id.substring(lastIndex + 1);
            }
        }
        return null;
    },
    getTabIDFromAnchorID: function(node) {
        if (node != null && node.length > 0) {
            var lastIndex = node.lastIndexOf("_");
            if (lastIndex >= 0) {
                return node.substring(lastIndex + 1);
            }
        }
        return null;
    },
    // dateFormat can include yyyy mm dd hh MM ss pattern and these pattern will be replaced by real values.
    // yyyy - 4 digit year, mm - month, dd - day, hh - hours, MM - minutes, ss - seconds
    formatDateString: function(dateFormat, yyyy, mm, dd, hh, MM, ss) {
        if (dateFormat == null || dateFormat.length == 0) {
            dateFormat = "mm/dd/yyyy";
        }
        var dateString = dateFormat;
        if (yyyy != null && yyyy.length > 0) {
            dateString = dateString.replace(/yyyy/, yyyy);
        }
        if (mm != null && mm.length > 0) {
            dateString = dateString.replace(/mm/, mm);
        }
        if (dd != null && dd.length > 0) {
            dateString = dateString.replace(/dd/, dd);
        }
        if (hh != null && hh.length > 0) {
            var amPM = 'AM';
            dateString = dateString.replace(/HH/, hh);

            var hh12 = hh;
            if (hh12 >= 12) {
                amPM = 'PM';
                hh12 = (hh12 > 12) ? (hh12 - 12) : hh12;
                hh12 = '' + hh12;
                hh12 = (hh12.length == 1) ? ('0' + hh12) : hh12;
            }
            dateString = dateString.replace(/hh/, hh12);
            dateString = dateString.replace(/a/, amPM);
        }

        if (MM != null && MM.length > 0) {
            dateString = dateString.replace(/MM/, MM);
        }
        if (ss != null && ss.length > 0) {
            dateString = dateString.replace(/ss/, ss);
        }

        dateString = dateString.replace(/yyyy/, '');
        dateString = dateString.replace(/mm/, '');
        dateString = dateString.replace(/dd/, '');
        dateString = dateString.replace(/hh/, '');
        dateString = dateString.replace(/MM/, '');
        dateString = dateString.replace(/ss/, '');

        return dateString;
    },
    //
    // option : {
    //     isUTC: true // true or false
    //     dateFormat: "yyyy/mm/dd"    // The patterns yyyy mm dd hh MM ss can will be replaced with real values.
    // }
    //
    getDateString: function(option, when) {
        var year, month, day, hours, minutes, seconds;
        if (option.isUTC == true) {
            year = when.getUTCFullYear();
            month = when.getUTCMonth() + 1;
            day = when.getUTCDate();
            hours = when.getUTCHours();
            minutes = when.getUTCMinutes();
            seconds = when.getUTCSeconds();
        } else {
            year = when.getFullYear();
            month = when.getMonth() + 1;
            day = when.getDate();
            hours = when.getHours();
            minutes = when.getMinutes();
            seconds = when.getSeconds();
        }

        if (month < 10) {
            month = "0" + month;
        }
        if (day < 10) {
            day = "0" + day;
        }
        if (hours < 10) {
            hours = "0" + hours;
        }
        if (minutes < 10) {
            minutes = "0" + minutes;
        }
        if (seconds < 10) {
            seconds = "0" + seconds;
        }
        year = "" + year;
        month = "" + month;
        day = "" + day;
        hours = "" + hours;
        minutes = "" + minutes;
        seconds = "" + seconds;

        return this.formatDateString(option.dateFormat, year, month, day, hours, minutes, seconds);
    },
    getNowUTCString: function() {
        var now = new Date();
        return this.getDateString({isUTC: true, dateFormat: 'yyyy/mm/dd hh:MM:ss'}, now);
    },
    // The parameter "components" is array of component IDs.
    enableComponents: function(components) {
        if (components != null && components.length > 0) {
            components.forEach(function(component) {
                hyf.util.enableComponent(component);
            });
        }
    },
    // The parameter "components" is array of component IDs.
    disableComponents: function(components) {
        if (components != null && components.length > 0) {
            components.forEach(function(component) {
                hyf.util.disableComponent(component);
            });
        }
    },
    existInArray: function(array, targetItem) {
        var found = false;
        if (array) {
            var foundItems = array.filter(function(item) {
                return item == targetItem;
            });

            if (foundItems && foundItems.length > 0) {
                found = true;
            }
        }
        return found;
    },
    showDebugLog: true,
    showErrorLog: true,
    showInfoLog: true,
    debugLog: function(message) {
        if (this.showDebugLog == true) {
            if (console && console.log) {
                console.log('DEBUG: ' + message);
            }
        }
    },
    errorLog: function(message) {
        if (this.showErrorLog == true) {
            if (console && console.log) {
                console.log('ERROR: ' + message);
            }
        }
    },
    infoLog: function(message) {
        if (this.showInfoLog == true) {
            if (console && console.log) {
                console.log('INFO: ' + message);
            }
        }
    }
};