/**
 * Container object for all FLSA Exempt and Non-Exempt variables (properties) and functions (methods)
 */
var classificationFLSA = {
	/**
	 * Field used to store Prefix of Exempt/Non-exempt control on FLSA-General Tabs
	 */
	exNoexSelectorPrefix: 'CS_FLSA_DETERM_ID',
	
	/**
	 * Field used to store Prefix of PDNumber/JobCode control on FLSA-General Tabs
	 */
	jobCodePrefix: 'CS_PD_NUMBER_JOBCD',
    
	/**
	 * Field used to store maximum allowed charaters in Remarks Field
	 */
    remarksMaxChars: 500,
	
	/**
	 * Field used to store Group Name of HR Classification Specialists
	 */
	hrClassiSpcRoleName : 'HR Classification Specialists',

	/**
     * Function that is called for initial setups of FLSA Exempt tab
     * It recursively calls itself, every second, until FLSA Codes Tabs is initialized and DOM is populated 
     */
    setFLSAExPDCodes: function() {
        if ($("select[id^=" + this.exNoexSelectorPrefix + "]").length <= 0) {
            setTimeout(this.setFLSAExPDCodes, 1000);
        }
        else {
            $("#flsa_ex_main_lg").trigger('FLSAUpdate');
        }
    },

    /**
     * Function that is called for initial setups of FLSA Non-exempt tab
     * It recursively calls itself, every second, until FLSA Codes Tabs is initialized and DOM is populated 
     */
    setFLSANoexPDCodes: function() {
        if ($("select[id^=" + this.exNoexSelectorPrefix + "]").length <= 0) {
            setTimeout(this.setFLSANoexPDCodes, 1000);
        }
        else {
            $("#flsa_noex_main_lg").trigger('FLSAUpdate');
        }
    },

	/**
     * Sets ups events, event handlers when the FLSA Exempt Tab is initialized.
     * 
     * Bound to page_load event of flsa_ex page
     * 
     * Return nothing;
     */
    initExempt: function () {
		
		var docWidth = $(document).width(); // returns width of HTML document (same as pageWidth in screenshot)

		//debug
		//console.log("initExempt()"
		//	+ "\n winHeight = " + $(window).height() + "\n winWidth = " + $(window).width()
		//	+ "\n docHeight = " + $(document).height() + "\n docWidth = " + $(document).width()
		//);

		$("#ex_lg").css("width", docWidth - 70);
		
        $("#flsa_ex_main_lg").on('FLSAUpdate', function (evt) {
            var displayText = "";
            $("select[id^=" + classificationFLSA.exNoexSelectorPrefix + "]").each( function() {
                if ($(this).val() == 'Exempt') {
	   				var element = '#' + $(this).attr('id').replace(classificationFLSA.exNoexSelectorPrefix, classificationFLSA.jobCodePrefix);
                    if ($(element).length > 0) {
                        if ($(element).val().trim() != '') {
                            displayText += "; " + $(element).val().trim();
                        }
                    }
                }
 			});
            if (displayText.length != 0) {
                displayText = displayText.substring(2);
            }
            $("#EX_PD_NUMBERS").text(displayText);
        });
		//Allow All Classification Specialist readwrite access to the Remarks field (JIRA Ticket 1141)
		if (isCurrentUserMemberOf(this.hrClassiSpcRoleName)) {
			$("#FLSA_EX_REMARKS").attr('readonly', false);
			$("#FLSA_EX_REMARKS").attr('disabled', false);
		}
		$("#FLSA_EX_REMARKS").on('keyup keypress blur change', function() {
			if ($(this).val().length > classificationFLSA.remarksMaxChars) {
				$(this).val($(this).val().substring(0, classificationFLSA.remarksMaxChars));
			}
		});
        this.setFLSAExPDCodes();
    },
	
    /**
     * Sets ups events, event handlers when the FLSA Non-Exempt Tab is initialized.
     * 
     * Bound to page_load event of flsa_noex page
     * 
     * Return nothing;
     */
    initNonExempt: function () {
        $("#flsa_noex_main_lg").on('FLSAUpdate', function (evt) {
            var displayText = "";
            $("select[id^=" + classificationFLSA.exNoexSelectorPrefix + "]").each( function() {
                if ($(this).val() == 'Non-exempt') {
	   				var element = '#' + $(this).attr('id').replace(classificationFLSA.exNoexSelectorPrefix, classificationFLSA.jobCodePrefix);
                    if ($(element).length > 0) {
                        if ($(element).val().trim() != '') {
                            displayText += "; " + $(element).val().trim();
                        }
                    }
                }
 			});
            if (displayText.length != 0) {
                displayText = displayText.substring(2);
            }
            $("#NOEX_PD_NUMBERS").text(displayText);
        });
		//Allow All Classification Specialist readwrite access to the Remarks field (JIRA Ticket 1141)
		if (isCurrentUserMemberOf(this.hrClassiSpcRoleName)) {
			$("#FLSA_NOEX_REMARKS").attr('readonly', false);
			$("#FLSA_NOEX_REMARKS").attr('disabled', false);
		}
		$("#FLSA_NOEX_REMARKS").on('keyup keypress blur change', function() {
			if ($(this).val().length > classificationFLSA.remarksMaxChars) {
				$(this).val($(this).val().substring(0, classificationFLSA.remarksMaxChars));
			}
		});
        this.setFLSANoexPDCodes();
    }
}



/**
 * Custom validation function for FLSA Exempt tab
 */
function validateFlsaExCustom(){
	if ($("#ex_lg").filter(function(){ return $(this).find("input[type=checkbox]:checked").length > 0; }).length > 0 ) {
		console.log("at least one FLSA ex checkbox is checked");
		return true;
	} else {
		console.log("no FLSA ex checkbox is checked");
		return false;
	}
}
