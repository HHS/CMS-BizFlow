function getBasicWIHActionObject()
{
	return basicWIHAction;
}

function BasicWIHAction()
{
	this.version = 12.3;
	this.minorVersion = 3;
	/* constants for option */
	this.OPTION_CONTINUE = "continue";
	this.OPTION_WAIT = "wait";
	this.OPTION_STOP = "stop";

	/* constants for ACTION */
	this.ACTION_COMPLETE = "complete";
	this.ACTION_SAVE = "save";
	this.ACTION_MONITOR = "monitor";
	this.ACTION_COMMENT = "comment";
	this.ACTION_ATTACH = "attach";
	this.ACTION_EDMSATTACH = "edmsattach";
	this.ACTION_ADHOC = "adhoc";
	this.ACTION_EXIT = "exit";
	this.ACTION_GENERALINFO="generalinfo";
	this.ACTION_SELECT_NEXT_USER ="selectnextuser";
	this.ACTION_SELECT_NEXT_APPLICATION="selectnextapplication";
	this.ACTION_CHANGE_RESPONSE ="changeresponse";
	this.ACTION_REPLY = "reply";
	this.ACTION_FORWARD = "forward";
	this.ACTION_RESPOND = "respond";

	this.ACTION_SAVE_TO_SERVER = "SaveToServer";
    this.ACTION_TABCHANGE = "tabChange";
	this.ACTION_ONCHANGEWORKITEMATTACHMENT = "onchangeWorkitemAttachment";
	this.ACTION_ONCLOSEWORKITEMCOMMENTWINDOW = "onCloseWorkitemCommentWindow";

    this.continueOption = this.OPTION_CONTINUE;
	this.lastAction = "";
	this.lastEvent = "";
	this.skipEvent = false;
	this.passedRequiredAction = false;

	this.targetFrame = null;
	try
	{
		if(parent.WIH_information)
		{
			this.targetFrame = parent.WIH_information;
		}
		else if(parent.WIH_application)
		{
			if(parent.WIH_application.WIH_information)
			{
				this.targetFrame = parent.WIH_application.WIH_information;
			}else
			{
				this.targetFrame = parent.WIH_application;
			}
		}

	}catch(e)
	{
		this.targetFrame = null;
	}

	this.setContinueOption = function (option){this.continueOption =  option;};
	this.getContinueOption = function (){return this.continueOption;};
	this.setContinue = function (){this.continueOption = this.OPTION_CONTINUE;};
	this.setStop = function (){this.continueOption = this.OPTION_STOP;
		this.passedRequiredAction = false;
		this.lastEvent = '';
		this.setSkipEvent(false);
	};
	this.setWait = function (){this.continueOption = this.OPTION_WAIT;};
	this.isContinue = function (){return (this.continueOption == this.OPTION_CONTINUE);};
	this.isWait = function (){return (this.continueOption == this.OPTION_WAIT);};
	this.isStop = function (){return (this.continueOption == this.OPTION_STOP);};
	this.doesItNeedToSendEvent = function (){return (this.isContinue() || this.isStop());};
	this.setLastEvent = function(lastEvent){
							if(this.isSkipEvent())
							{
								this.setSkipEvent(false);
								return false;
							}
							else
							{
								this.setSkipEvent(true);
								this.lastEvent = lastEvent;
								return true;
							}};
	this.getLastEvent = function(){return this.lastEvent;};
	this.setLastAction = function(lastAction){this.lastAction = lastAction;};
	this.getLastAction = function(){return this.lastAction;};
	this.setSkipEvent = function(flag){this.skipEvent = flag;};
	this.isSkipEvent = function (){return this.isContinue() && this.skipEvent;};

	this.complete	= function(){this.setLastAction(this.ACTION_COMPLETE);if(this.isStop())this.setContinue();save(true);};
	this.save		= function(){this.setLastAction(this.ACTION_SAVE);if(this.isStop())this.setContinue();save(false);};
	this.exit		= function(config){this.setLastAction(this.ACTION_EXIT);if(this.isStop())this.setContinue();if(exit) return exit(config);};
	this.reply		= function(){this.setLastAction(this.ACTION_REPLY);if(this.isStop())this.setContinue();reply();};
	this.forward	= function(){this.setLastAction(this.ACTION_FORWARD);if(this.isStop())this.setContinue();forward();};
	this.respond	= function(responseName){this.setLastAction(this.ACTION_RESPOND);if(this.isStop())this.setContinue();respondByName(responseName);};
	this.monitor	= function(){this.setLastAction(this.ACTION_MONITOR);if(monitor) return monitor();};
	this.comment	= function(){this.setLastAction(this.ACTION_COMMENT);if(comment) return comment();};
	/**
	 * Open the attachment window
	 * @param config    Object.
	 *          partialPage: String. Partial page location. ex: sample/attachadd_partialpage.jsp
	 *          width: Number. Window width. Defaults to 500.
	 *          height: Number. Window height. Defaults to 300.
	 */
	this.attach = function (config){this.setLastAction(this.ACTION_ATTACH);if(attach) return attach(config);};
	this.edmsAttach = function(){this.setLastAction(this.ACTION_EDMSATTACH);if(attachEdms) return attachEdms();};
	this.adHoc		= function(){this.setLastAction(this.ACTION_ADHOC);if(adhoc) return adhoc();};
	this.generalInfo = function(){this.setLastAction(this.ACTION_GENERALINFO);if(generalInfo) return generalInfo();};
	this.selectNextUser = function(){this.setLastAction(this.ACTION_SELECT_NEXT_USER);if(selectNextUser) return selectNextUser();};
	this.selectNextApplication = function(){this.setLastAction(this.ACTION_SELECT_NEXT_APPLICATION);if(selectNextApp) return selectNextApp();};
	this.tabChange = function(){this.setLastAction(this.ACTION_TABCHANGE);if(tabChange) return tabChange();};

    this.onWorkitemComplete			= function(){return this._event(this.ACTION_COMPLETE);};
	this.onWorkitemSave				= function(){return this._event(this.ACTION_SAVE);};
	this.onWorkitemReply			= function(){return this._event(this.ACTION_REPLY);};
	this.onWorkitemForward			= function(){return this._event(this.ACTION_FORWARD);};
	this.onWorkitemMonitor			= function(){return this._event(this.ACTION_MONITOR);};
	this.onWorkitemComment			= function(){return this._event(this.ACTION_COMMENT);};
	this.onWorkitemAttach			= function(){return this._event(this.ACTION_ATTACH);};
	this.onWorkitemEdmsAttach		= function(){return this._event(this.ACTION_EDMSATTACH);};
	this.onWorkitemAdHoc			= function(){return this._event(this.ACTION_ADHOC);};
	this.onWorkitemExit				= function(){return this._event(this.ACTION_EXIT);};
	this.onWorkitemGeneralInfo		= function(){return this._event(this.ACTION_GENERALINFO);};
	this.onWorkitemChangeResponse	= function(){return this._event(this.ACTION_CHANGE_RESPONSE);};
	this.onWorkitemSelectNextUser	= function(){return this._event(this.ACTION_SELECT_NEXT_USER);};
    this.onWorkitemTabChange		= function(appId, appType){return this._event(this.ACTION_TABCHANGE, appId, appType);};
	this.onChangeWorkitemAttachment = function(operation, updatedAttachmentsInfo){return this._event(this.ACTION_ONCHANGEWORKITEMATTACHMENT, operation, updatedAttachmentsInfo);};
	this.onWorkitemSelectNextApplication = function(){return this._event(this.ACTION_SELECT_NEXT_APPLICATION);};
	this.onCloseWorkitemCommentWindow = function(){return this._event(this.ACTION_ONCLOSEWORKITEMCOMMENTWINDOW);};
	this.onAction = BasicWIHAction_onAction;
	this.OnAction = BasicWIHAction_OnAction;//This is for compatibility with Bizflow 10. OnAction() is used in Bizflow 10

	//this.getResponsesInfo = function(){if(getResponsesInfo) return getResponsesInfo();};
	//this.setResponseByName = function(name){if(setResponseByName) return setResponseByName(name);};
	//this.getSelectedResponse = function (){if(getSelectedResponse) return getSelectedResponse();} ;
	//this.setCommentRequired = function (require){if(setCommentRequired) return setCommentRequired(require);} ;
	//this.setReadCommentRequired = function (require){if(setReadCommentRequired) return setReadCommentRequired(require);} ;
	//this.setAttachmentRequired = function (require, count){if(setAttachmentRequired) return setAttachmentRequired(require, count);} ;
	//this.getWIHOption = function (key, defaultVal){if(getWIHOption) return getWIHOption(key, defaultVal);};
	//this.setWIHOption = function (key, value){if(setWIHOption) return setWIHOption(key, value);};
	//this.enabledCompleteWindow = function(){return this.getWIHOption("completionWindow", true)};
	//this.getCommentCount = function (){if(getCommentCount) return getCommentCount();} ;
	//this.getAttachmentInfo = function (){if(getAttachments) return getAttachments();} ;
	//this.getAttachments = function (){if(getAttachments) return getAttachments();} ;
	//this.getComments = function (){if(getComments) return getComments();} ;
	//this.getWorkitemContext = function (){if(getWorkitemContext) return getWorkitemContext();} ;
	//this.reloadWorkitemContext = function (callback) { if(reloadWorkitemContext) reloadWorkitemContext(callback)};
	//this.removeAttachment = function (attachmentId){if(parent.removeAttachment)return parent.removeAttachment(attachmentId, arguments[1]);};
	//this.updateAttachments = function (attachments){if(parent.updateAttachments)return parent.updateAttachments(attachments);};
	//this.reloadAttachments = function (){if(parent.reloadAttachments)return parent.reloadAttachments();};
	//this.getUI = function (){if(parent.getUI) return parent.getUI();} ;
	//this.notify = function (msg, opt){if(parent.notify) return parent.notify(msg, opt);} ;
	//this.loadFormData = function(config){return loadFormData(config);};
	//this.saveFormData = function(formData, config){return saveFormData(formData, config);};
	//this.getDocumentURL = function(processId, attachmentId, metadata){if(getDocumentURL) return getDocumentURL(processId, attachmentId, metadata);};

	this._event = function()
	{
		try
		{
			var action = arguments[0];
			var eventFn = this.getEventName(action);
			if(eventFn == null) return;

			if(eventFn != 'onChangeWorkitemAttachment' && this.setLastEvent(action) == false) return true;

			var evnt = eval('this.targetFrame.'+eventFn);
			if (this.targetFrame && evnt)
			{
				if (this.doesItNeedToSendEvent())
				{
					var _rc;
					if(eventFn == 'onWorkitemTabChange')
					{
						_rc = evnt(this, arguments[1], arguments[2]);
					}
					else if(eventFn == 'onChangeWorkitemAttachment')
					{
						_rc = evnt(this, arguments[1], arguments[2]);
					}
					else
					{
						_rc = evnt(this);
					}

					if (this.isStop() || ('undefined' != typeof(_rc) && _rc == false)
						|| !(this.ACTION_COMPLETE == action || this.ACTION_SAVE == action || this.ACTION_EXIT == action || this.ACTION_REPLY == action || this.ACTION_FORWARD == action))
					{
						this.setSkipEvent(false)
					}

					return _rc;
				}
			}
			else
			{
				this.setSkipEvent(false);
			}
			//else this.onAction(action, "");
		}catch(e)
		{
		}
		return this.continueOption;
	};

	this.getEventName = function(action)
	{
		if(this.ACTION_COMPLETE == action) return 'onWorkitemComplete';
		else if(this.ACTION_SAVE == action) return 'onWorkitemSave';
		else if(this.ACTION_EXIT == action) return 'onWorkitemExit';
		else if(this.ACTION_REPLY == action) return 'onWorkitemReply';
		else if(this.ACTION_FORWARD == action) return 'onWorkitemForward';
		else if(this.ACTION_MONITOR == action) return 'onWorkitemMonitor';
		else if(this.ACTION_COMMENT == action) return 'onWorkitemComment';
		else if(this.ACTION_ATTACH == action) return 'onWorkitemAttach';
		else if(this.ACTION_EDMSATTACH == action) return 'onWorkitemEdmsAttach';
		else if(this.ACTION_ADHOC == action) return 'onWorkitemAdHoc';
		else if(this.ACTION_GENERALINFO == action) return 'onWorkitemGeneralInfo';
		else if(this.ACTION_SELECT_NEXT_USER == action) return 'onWorkitemSelectNextUser';
		else if(this.ACTION_SELECT_NEXT_APPLICATION == action) return 'onWorkitemSelectNextApplication';
		else if(this.ACTION_CHANGE_RESPONSE == action) return 'onWorkitemChangeResponse';
		else if(this.ACTION_SELECT_NEXT_APPLICATION == action) return 'onWorkitemSelectNextApplication';
		else if(this.ACTION_TABCHANGE == action) return 'onWorkitemTabChange';
		else if(this.ACTION_SELECT_NEXT_APPLICATION == action) return 'onWorkitemSelectNextApplication';
		else if(this.ACTION_ONCHANGEWORKITEMATTACHMENT == action) return 'onChangeWorkitemAttachment';
		else if(this.ACTION_ONCLOSEWORKITEMCOMMENTWINDOW == action) return 'onCloseWorkitemCommentWindow';
		else return null;
	}

};

/**
 * @param actionName action name, this name must be one of constants defined BasicWIHAction, which start with ACTION_
 */
function BasicWIHAction_onAction(actionName, opt)
{
	if(this.setLastEvent(actionName) == false) return true;

	try
	{
		if (this.targetFrame && this.targetFrame.onAction)
		{
			if (this.doesItNeedToSendEvent())
			{
				return this.targetFrame.onAction(this, actionName, opt);
			}
		}
        else this.setContinue();
	}catch(e)
	{
	}

	return this.continueOption;
}

/**
 * This is for compatibility with Bizflow 10. OnAction() is used in Bizflow 10
 * @param actionName action name, this name must be one of constants defined BasicWIHAction, which start with ACTION_
 */
function BasicWIHAction_OnAction(actionName, opt)
{
	try
	{
		if (this.targetFrame && this.targetFrame.OnAction)
		{
			return this.targetFrame.OnAction(actionName, opt);
		}
	}catch(e)
	{
	}

	return true;
}

//Global Object for BasicWIHAction
var basicWIHAction = new BasicWIHAction();

var ID_EWITEM_CREATE = "I";
var ID_EWITEM_START = "R";
var ID_EWITEM_SUSPEND = "S";
var ID_EWITEM_ABORT = "A";
var ID_EWITEM_TERMINATE = "T";
var ID_EWITEM_COMPLETE = "C";
var ID_EWITEM_FORWARD = "W";
var ID_EWITEM_DEAD = "D";
var ID_EWITEM_ERROR = "E";
var ID_EWITEM_PARTIAL = "P";
var ID_EWITEM_DELAY = "V";
var ID_EWITEM_SYNC = "Y";
var ID_EWITEM_RECALL = "L";

function checkWorkState(state, readOnly) {
    var canBeOpened = false;
    if (   state == ID_EWITEM_CREATE
        || state == ID_EWITEM_PARTIAL
        || state == ID_EWITEM_DELAY
        || state == ID_EWITEM_RECALL
        || state == ID_EWITEM_SYNC )
        canBeOpened = true;
    else if (state == ID_EWITEM_COMPLETE)
        if (readOnly)
            canBeOpened = true;
        else
            alert(MSG_WL_ID_EWITEM_COMPLETE);
    else if (state == ID_EWITEM_SUSPEND)
        alert(MSG_WL_ID_EWITEM_SUSPEND);
    else if (state == ID_EWITEM_ABORT)
        alert(MSG_WL_ID_EWITEM_ABORT);
    else if (state == ID_EWITEM_FORWARD)
        alert(MSG_WL_ID_EWITEM_FORWARD);
    else if (state == ID_EWITEM_DEAD)
        alert(MSG_WL_ID_EWITEM_DEAD);
    else if (state == ID_EWITEM_ERROR)
        alert(MSG_WL_ID_EWITEM_ERROR);
    else if (state == ID_EWITEM_TERMINATE)
        if (readOnly)
            canBeOpened = true;
        else
            alert(MSG_WL_ID_EWITEM_TERMINATE);
    else if (state == ID_EWITEM_START)
        alert(MSG_WL_ID_EWITEM_START);
    else
        alert(MSG_WL_ID_EWITEM_ANOTHER);
    return canBeOpened
}

var wndCompleteOptionSelection = null;
var completeOptionParamByUser = -1;
function onSelectCompleteOption(completeOption) {
    completeOptionParamByUser = completeOption;
    save(true);
}

function checkwihtimeout()
{
    if (wihtimeout > 0)
    {
        var currentTime = new Date();
        var newMinutes = currentTime.getMinutes() - new Number(wihtimeout);
        currentTime.setMinutes(newMinutes, currentTime.getSeconds());

        if (currentTime > startTime)
        {
            alert(MSG_WIH_TIMEOUT);
            return	true;
        }
    }

    return	false;
}

function checkPasswordWindow()
{
    if (checkwihtimeout()) { _close(); return; }
    if (passFlag)
    {
        if ((null == wndPassword) || wndPassword.closed)
        {
            parent.close();
        }
        else
        {
            wndPassword.focus();
            window.setTimeout(function(){checkPasswordWindow()}, 500, "javascript");
        }
    }
}

function getCheckPasswordValue(value)
{
    if (checkwihtimeout()) { _close(); return; }
    passFlag = false;

    if (!BrowserDetect.isExplorer())
        closeModal();

    parent.location.href = nextUrl;
}

function disableMenu(id)
{
    try
    {
        var menu = document.getElementById(id);
        if(menu)
        {
            menu.style.disabled = true;
        }
    }catch (e)
    {
    }
}
function validateSubprocessForm()
{
	if (isSubprocessActivity())
	{
	    try
	    {
		    if (typeof (parent.WIH_information.validateForm) != "undefined")
		    {
		        return parent.WIH_information.validateForm();
		    }
	    }
	    catch (e) {
	        // ignore.  If application is from different domain, security exception can be thrown.
	    }
	}
	return true;
}
function save(completeNow, mobileResponseId)
{
	if("y" == basicWihReadOnly)
	{
		return;
	}

	if(!parent.isActionReady())
	{
		alert(MSG_WIH_APPLICATION_IS_LOADING);
		return;
	}

	completeNow = (typeof(completeNow) == 'undefined' || typeof(completeNow) != 'boolean') ? false : completeNow;

    if (checkwihtimeout()) {
        _close();
        return;
    }

	responseId = parent.getCurrentResponseId();
    if (typeof(mobileResponseId) != 'undefined') {
        responseId = mobileResponseId;
    }
	if(responseId == null)
	{
		responseId = 0;
	}


	// todo: disable menu
	//parent.blockUI();

	if (completeNow)
    {
		if(basicWIHAction.passedRequiredAction && basicWIHAction.isSkipEvent() && basicWIHAction.isContinue())
		{
			updateToServer(__wihaction, __option);
		}
	    else
		{
            var asyncCall = !jQuery.browser.webkit; /* for iPad safari */
			$.ajax({
				type: "GET",
				url: contextPath + "/bizcoves/wih/checkRequiredAction.jsp",
				data: {wihaction: 'complete', resid: responseId, compopt: completeOptionParamByUser},
				dataType: "json",
				cache: false,
				async: asyncCall,
				success: function(data) {
					if(data.isError)
					{
						if(0<data.errorMsg.length)
						{
							alert(data.errorMsg);
							//parent.unblockUI();
						}
						return;
					}
					else
					{
						var msg = "";
						if(data.subProcStatus == 0)
						{
							msg = MSG_CANNOT_COMPLETE_SUBPROC_ACT;
						}
						if(data.incompletedApp)
						{
							msg += ((msg!="")?"\n":"")+MSG_WL_COMPLETE_MANDATORY_APP;
						}
						if(!data.existsMyComment && parent.checkReadComment())
						{
							msg += ((msg!="")?"\n":"")+MSG_WIH_REQUIRE_COMMENT_READ;
							comment();
						}

						if(msg != "")
						{
							alert(msg);
							return;
						}

						if(!validateSubprocessForm())
						{
							return;
						}

						basicWIHAction.passedRequiredAction = true;
						if(parent.getWIHOption("completionWindow", true)
							|| data.needPassword
							|| data.needAddComment
							|| 0<data.needAddAttachmentCount
							|| data.needAdhocCompleteOption)
						{
							var windowTitle = LBL_WIH_COMPLETE;
							if(0 < data.responseId)
							{
								windowTitle = RESPONSE_WINDOW_TITLE.replace("{0}", data.responseName);
							}
							//for modal
							openModalPopup(contextPath+"/bizcoves/wih/completepopup.jsp", windowTitle, "completepopup", 620, 400, isForcedModal);
//							openPopup(contextPath+"/bizcoves/wih/completepopup.jsp", windowTitle, "completepopup", 620, 400);
						}
						else
						{
							updateToServer(basicWIHAction.ACTION_COMPLETE);
							if(basicWIHAction.passedRequiredAction == false)
							{
								recheckRequiredAction(data.responseId);
							}
						}
					}
					//parent.unblockUI();
				},
				error: function(e){
					//parent.unblockUI();
					alert('Error: ' + e.statusText);
				}
			});
		}
    }
    else {
        var _rc = basicWIHAction.onWorkitemSave();
        if ((basicWIHAction.isContinue() != true) || ('undefined' != typeof(_rc) && _rc == false)) return;

        //This is for compatibility with Bizflow 10. OnAction() is used in Bizflow 10
        var _rc = basicWIHAction.OnAction(basicWIHAction.ACTION_SAVE_TO_SERVER, "");
        if ((basicWIHAction.isContinue() != true) || ('undefined' != typeof(_rc) && _rc == false)) return;

	    if(!validateSubprocessForm())
	    {
		    return;
	    }

	    updateToServer(basicWIHAction.ACTION_SAVE);
    }
}
function recheckRequiredAction(responseId)
{
	var asyncCall = !jQuery.browser.webkit;
	$.ajax({
		type: "GET",
		url: contextPath + "/bizcoves/wih/checkRequiredAction.jsp",
		data: {wihaction: 'complete', resid: responseId, compopt: completeOptionParamByUser},
		dataType: "json",
		cache: false,
		async: asyncCall,
		success: function(data) {
			if(data.isError)
			{
				if(0<data.errorMsg.length)
				{
					alert(data.errorMsg);
					//parent.unblockUI();
				}
				return;
			}
			else
			{
				var msg = "";
				if(data.needAddComment)
				{
					alert(MSG_WIH_REQUIRE_COMMENT_ADD);
					comment();
					return;
				}
				if(!data.existsMyComment && parent.checkReadComment())
				{
					alert(MSG_WIH_REQUIRE_COMMENT_READ);
					comment();
					return;
				}
			}
			//parent.unblockUI();
		},
		error: function(e){
			//parent.unblockUI();
			alert('Error: ' + e.statusText);
		}
	});
}

var __wihaction;
var __option;
function updateToServer(wihaction, option)
{
	wihaction = (typeof(wihaction) == 'undefined')?basicWIHAction.ACTION_COMPLETE:wihaction;

	__wihaction = wihaction;

	if(typeof(option) == 'string')
	{
		option = jQuery.parseJSON(option);
	}
	__option = option;

	var _rc;
	if(basicWIHAction.ACTION_COMPLETE == wihaction)
	{
		basicWIHAction.passedRequiredAction = true;
		if (!basicWIHAction.isStop() && !basicWIHAction.isWait())
		{
			_rc = basicWIHAction.onWorkitemComplete();
		}
		else
		{
			basicWIHAction.setContinue();
		}
	}
	else if(basicWIHAction.ACTION_REPLY == wihaction)
	{
		_rc = basicWIHAction.onWorkitemReply();
	}
	else if(basicWIHAction.ACTION_FORWARD == wihaction)
	{
		_rc = basicWIHAction.onWorkitemForward();
	}
	if (basicWIHAction.isStop() || ('undefined' != typeof(_rc) && _rc == false)) {
//		console.log("updateToServer: continueOption=" + basicWIHAction.getContinueOption() + ", event result=" + _rc);
		basicWIHAction.passedRequiredAction = false;
		basicWIHAction.lastEvent = '';
		basicWIHAction.setSkipEvent(false);
		return;
	}
	else if(basicWIHAction.isWait())
    {
        return;
    }

    // gathering submit form data
    $('#wihaction').val(wihaction);
    $('#resid').val(responseId);

   	if (basicWIHAction.ACTION_COMPLETE == wihaction)
	{
		if(typeof(option) != 'undefined' && typeof(option.completeOption) != 'undefined')
		{
            $('#compopt').val(option.completeOption);
		}
		var closeWihOnComplete = parent.getWIHOption('closeWihOnComplete');
		if (typeof(closeWihOnComplete) != 'undefined') {
            $('#closeWihOnComplete').val(closeWihOnComplete);
		}
	}
	else if(basicWIHAction.ACTION_FORWARD == wihaction)
	{
		if(typeof(option) != 'undefined' && typeof(option.to) != 'undefined')
		{
            $('#forwardTo').val(option.to);
		}
	}

	if (iniGetNextWorkitem) {
        $('#currow').val(currow);
        $('#bizcoveid').val(bizcoveid);
	}

	if (wihaction == basicWIHAction.ACTION_COMPLETE && isSubprocessActivity()) {
		var subProcessFormExist = false;

		try {
			subProcessFormExist = (typeof (parent.WIH_information.document.frmSubprocess) != "undefined");
		}
		catch (e) {
			// ignore.  If application is from different domain, security exception can be thrown.
		}

		if (subProcessFormExist) {
			var fromForm = parent.WIH_information.document.frmSubprocess;
			$('#definitionName').val(fromForm.definitionName.value);
			$('#description').val(fromForm.description.value);
			$('#instanceFolderId').val(fromForm.instanceFolderId.value);
			$('#archiveFolderId').val(fromForm.archiveFolderId.value);
			$('#urgent').val((fromForm.urgent.checked ? "T" : "F"));
			$('#checkPassword').val((fromForm.checkPassword.checked ? "T" : "F"));
		}
	}

	parent.removeLocalCacheInfo();
	document.frmAction.submit();
}
function reject()
{
	reply();
}
function reply()
{
	if(basicWIHAction.isSkipEvent() && basicWIHAction.isContinue())
	{
		updateToServer(__wihaction, __option);
	}
	else
	{
		var asyncCall = !jQuery.browser.webkit; /* for iPad safari */
		$.ajax({
		type: "GET",
		url: contextPath + "/bizcoves/wih/checkRequiredAction.jsp",
		data: {wihaction: 'reply'},
		dataType: "json",
		cache:false,
		      async: asyncCall,
		success: function(data) {
			if(data.isError)
			{
				if(0<data.errorMsg.length)
				{
					alert(data.errorMsg);
					//parent.unblockUI();
				}
				return;
			}
			else
			{
				openPopup(contextPath+"/bizcoves/wih/replypopup.jsp", LBL_WIH_REJECT, "replypopup", 620, 450);
			}
		          //parent.unblockUI();
		},
		error: function(e){
			//parent.unblockUI();
			alert('Error: ' + e.statusText);
		      }
		});
	}
}
function generalInfo() {
    if (checkwihtimeout()) { _close(); return; }
    // fire event
	basicWIHAction.setContinue();
    var _rc = basicWIHAction.onWorkitemGeneralInfo();
	if(basicWIHAction.isStop() || ('undefined' != typeof(_rc) && _rc == false)) return;

    var url = contextPath + "/bizcoves/wih/workinfo.jsp?basicWihReadOnly="+basicWihReadOnly+"&ispopup=y";
    if(isArchived) {
        url += "&archive=y";
    }
    var width = 750;
    var height =  500;
    if(isModalWindowMode())
    {
        width = "80%";
        height = "80%";
    }
    openPopup(url, "", "generalInfo", width, height);
}
function monitor() {
    if (checkwihtimeout()) { _close(); return; }
    // fire event
	basicWIHAction.setContinue();
    var _rc = basicWIHAction.onWorkitemMonitor();
	if(basicWIHAction.isStop() || ('undefined' != typeof(_rc) && _rc == false)) return;

    var sUrl = contextPath+"/common/audit.jsp?sid="+serverID
        + "&pid=" + processID
        + "&type=" + (isArchived ? "archive" : "instance")
        + "&pnm=" + escapeUnicode(processName)
        + "&t=" + (new Date().getTime());
    var width = window.screen.availWidth - 100;
    var height = window.screen.availHeight - 200;
    var wndMonitor = openMonitorPopup(sUrl, "", "Monitor", width, height, true, true, true, true);
}

var wndAdhoc = null;
function adhoc() {
    if (checkwihtimeout()) { _close(); return; }
    // fire event
	basicWIHAction.setContinue();
    var _rc = basicWIHAction.onWorkitemAdHoc();
	if(basicWIHAction.isStop() || ('undefined' != typeof(_rc) && _rc == false)) return;

    var url = contextPath+"/adhoc/adhocframe.jsp?sid="+serverID+"&pid="+processID+"&asq="+activityID;
    var width = 880;
    var height = ("en" == language) ? 555 : 572;
    wndAdhoc = openPopup(url, "", "AdHocRouting", width, height);
}
var wndNextUser = null;
function selectNextUser() {
    if (checkwihtimeout()) { _close(); return; }
    // fire event
	basicWIHAction.setContinue();
    var _rc = basicWIHAction.onWorkitemSelectNextUser();
	if(basicWIHAction.isStop() || ('undefined' != typeof(_rc) && _rc == false)) return;

    var url = contextPath+"/bizcoves/wih/selectparticipant.jsp?provType=user&basicWihReadOnly="+basicWihReadOnly;
    wndNextUser = openPopup(url, "", "SelectNextUser", 730, 270);
}
var wndNextApp = null;
function selectNextApp() {
    if (checkwihtimeout()) { _close(); return; }
    // fire event
	basicWIHAction.setContinue();
    var _rc = basicWIHAction.onWorkitemSelectNextApplication();
	if(basicWIHAction.isStop() || ('undefined' != typeof(_rc) && _rc == false)) return;

    var url = contextPath+"/bizcoves/wih/processvariable.jsp?provType=application&basicWihReadOnly="+basicWihReadOnly;
    wndNextApp = openPopup(url, "", "SelectNextApp", 730, 250, true, true);
}
function comment() {
    if (checkwihtimeout()) { _close(); return; }
    // fire event
	basicWIHAction.setContinue();
    var _rc = basicWIHAction.onWorkitemComment();
    if(basicWIHAction.isStop() || ('undefined' != typeof(_rc) && _rc == false)) return;
	parent.showSupplementalTools('discussion');
}
// deprecated
function commentWindow() {
    if (checkwihtimeout()) { _close(); return; }
    // fire event
	basicWIHAction.setContinue();
    var _rc = basicWIHAction.onWorkitemComment();
    if((basicWIHAction.isStop() != true) || ('undefined' != typeof(_rc) && _rc == false)) return;

    parent.setReadComment(true);
    var sUrl = contextPath+"/bizcoves/wih/commentall.jsp?sid="+serverID+"&pid="+processID+"&seq="+workID+"&basicWihReadOnly="+basicWihReadOnly+"&archive="+isArchived;
    var nWidth = (basicWihReadOnly == "y") ? 430:840;
    openPopup(sUrl, "", "Comment_Add", nWidth, 340, false, false);
}
function attachmng()
{
	parent.showSupplementalTools('attachment');
}
function attach(config)
{
    if (checkwihtimeout()) { _close(); return; }
    // fire event
	basicWIHAction.setContinue();
    var _rc = basicWIHAction.onWorkitemAttach();
    if(basicWIHAction.isStop() || ('undefined' != typeof(_rc) && _rc == false)) return;

	var cfg = $.extend({width:500, height:300}, config);

    var sUrl = contextPath+"/bizcoves/wih/attachadd.jsp?basicWihReadOnly="+basicWihReadOnly;
	if(typeof(cfg.partialPage) != 'undefined')
	{
		sUrl += "&partialPage=" + encodeURIComponent(cfg.partialPage);
	}
	if(typeof(cfg.parameter) != 'undefined')
	{
		if(typeof(cfg.parameter) == 'object')
		{
			sUrl += "&parameter=" + encodeURIComponent(JSON.stringify(cfg.parameter));
		}
		else
		{
			alert("Error: The parameter property must be object. ex) {name1: 'value1', name2: 'value2'}");
			return;
		}
	}
	if(getMaxURLLength() < sUrl.length)
	{
		alert("Error: Entity too large. Please make a small configuration properties.");
		return;
	}
    return openPopup(sUrl, "", "Attachment_Add", cfg.width, cfg.height, true, true);
}
function attachEdms()
{
    if (checkwihtimeout()) { _close(); return; }
    // fire event
	basicWIHAction.setContinue();
    var _rc = basicWIHAction.onWorkitemEdmsAttach();
    if(basicWIHAction.isStop() || ('undefined' != typeof(_rc) && _rc == false)) return;

    var sUrl = contextPath+"/bizcoves/wih/attachedmsadd.jsp?basicWihReadOnly="+basicWihReadOnly;
    return openPopup(sUrl, "", "Attachment_Add", 460, 191, false, true);
}
function tabChange(appId, appType)
{
    if (checkwihtimeout()) { _close(); return; }
	basicWIHAction.setContinue();
    var _rc = basicWIHAction.onWorkitemTabChange(appId, appType);
    if(basicWIHAction.isStop() || ('undefined' != typeof(_rc) && _rc == false))
        return false;
    else
        return true;
}
function event_onCloseWorkitemCommentWindow()
{
    var _rc = basicWIHAction.onCloseWorkitemCommentWindow();
}
function event_onChangeWorkitemAttachment(operationType, attachmentInfo_json)
{
	if(operationType && attachmentInfo_json && attachmentInfo_json != "")
	{
		try
		{
			var _obj = jQuery.parseJSON(attachmentInfo_json);
			var data = typeof(_obj.data) != 'undefined'? _obj.data : _obj;
			if(typeof(data) != 'undefined')
			{
				var _rc = basicWIHAction.onChangeWorkitemAttachment(operationType, data);
			}
		}
		catch(e)
		{
			if(typeof(console) != 'undefined')
			{
				console.error("basicwihaction.js: event_onChangeWorkitemAttachment(): " + e);
			}
		}
	}
}
function exit(config) {

	if(!parent.isActionReady())
	{
		alert(MSG_WIH_APPLICATION_IS_LOADING);
		return;
	}

	var cfg =  $.extend({confirmMsg:MSG_WL_SURE_EXIT, eventFn:function(){return basicWIHAction.onWorkitemExit()}}, config);

	if (parent.displayCloseMessage == false)
	{
		if ("y" != basicWihReadOnly) {
			if(typeof(cfg.confirmMsg) != 'undefined' && cfg.confirmMsg != null) {
				if(!confirm(cfg.confirmMsg))
				{
					return;
				}
			}

			if(typeof(cfg.eventFn) == 'function')
			{
				// fire event
				basicWIHAction.setContinue();
				var _rc = cfg.eventFn();
				if(basicWIHAction.isStop() || ('undefined' != typeof(_rc) && _rc == false)) return;
			}
		}
		location.href = contextPath+servletPath+"?wihaction=exit&basicWihReadOnly="+basicWihReadOnly + "&bizcoveid="+bizcoveid;
		parent.displayCloseMessage = true;
	}
}

function _removeButton(html, fn) {
    var idx = html.indexOf(fn);
    if (-1 != idx) {
        var idx1 = html.lastIndexOf("<a ", idx);
        var idx2 = html.indexOf("</a>", idx);
        if (-1 != idx1 && -1 != idx2) {
            html = html.substring(0, idx1) + html.substring(idx2 + "</a>".length);
        }
    }

    return html;
}

function setAppTab() {
    var html = '<table class="tab" border="0" cellSpacing="0" cellPadding="0"><tr>' +
        '<td class="current-start">&nbsp;</td>' +
        '<td class="current"><span>$$NAME</span></td>' +
        '<td class="current-end">&nbsp;</td></tr></table>';
    var title = parent.WIH_application.getHighLightTabTitle();
    if (title) {
        html = html.replace(/\$\$NAME/g, title);
        setModalPopupSubTitle(html);
    }
}

function getToolbarHtml() {
    var wihToolbar = document.getElementById("wihToolbar");
    var html = "" + wihToolbar.innerHTML;
    html = _removeButton(html, "javascript:save(true)");
    html = _removeButton(html, "javascript:reject()");
    html = _removeButton(html, "javascript:exit()");

    return html;
}

function restoreWIH() {
    var wihToolbarBox = parent.document.getElementById("wihToolbarBox");
    wihToolbarBox.style.display = "";
    setModalPopupToolbar("");
    setModalPopupSubTitle("");
    var maxIcon = $object('LBL_WIH_MAXIMIZE_IMG');
    if (maxIcon) {
        maxIcon.setAttribute("title", TIP_WIH_MAXIMIZE);
    }
}

function maximizeWIH() {
    var maxIcon = $object('LBL_WIH_MAXIMIZE_IMG');
    if (maxIcon) {
        maxIcon.setAttribute("title", TIP_WIH_MAXIMIZE_RESTORE);
    }
    var html = getToolbarHtml();
    html = html.replace(/href\=\"javascript\:/g, "href=\"javascript:getModalPopupTargetFrame('WIH_action').");
    html = html.replace(/maximizeWIH/g, "restoreWIH");
    html = html.replace(/wih_max\.png/g, "wih_resotre.png");
    setModalPopupToolbar(html);
    setAppTab();

    var wihToolbarBox = parent.document.getElementById("wihToolbarBox");
    wihToolbarBox.style.display = "none";
}

function resizeToolbar() {
    var wihactionpane = $('wihactionpane');
    if (wihactionpane) {
	    $('wihToolbar').css("width",wihactionpane.clientWidth);
    }
}
function forward()
{
    if(basicWIHAction.isSkipEvent() && basicWIHAction.isContinue())
    {
        updateToServer(__wihaction, __option);
    }
    else
    {
        //for modal
        openModalPopup(contextPath+"/bizcoves/wih/forwardpopup.jsp", LBL_WIH_FORWARD, "forwardpopup", 630, 350, isForcedModal);
//      openPopup(contextPath+"/bizcoves/wih/forwardpopup.jsp", LBL_WIH_FORWARD, "forwardpopup", 630, 350);
    }
}
function suggest()
{
	//
}
function openHelp()
{
    executeHiddenCall(contextPath + "/help/index.jsp?hid=my_worklist.html");
}
function respondByName(responseName)
{
	var res;
	if(typeof(responseName) == 'undefined')
	{
		res = parent.getSelectedResponse();
	}
	else
	{
		res = parent.setResponseByName(responseName);
	}

	if(typeof(res)!='undefined')
	{
		respondById(res.ID);
	}
	else
	{
		alert('Undefined response name:' + responseName);
	}
}
function respondById(id)
{
//    console.log("respondById(" + id + ")");
	var resp = parent.setSelectedResponseById(id);
	if(resp != null)
	{
		var _rc = basicWIHAction.onWorkitemChangeResponse();
		if((basicWIHAction.isContinue() != true) || ('undefined' != typeof(_rc) && _rc == false))
		{
//            console.log("respondById: continueOption=" + basicWIHAction.getContinueOption() + ", event result=" + _rc);
//            console.log("return");
			return;
		}

		parent.WIH_application.setResponseId(resp.ID, resp.NAME, resp.INFO);
		save(true);
	}
}
function respond(responseId)
{
	if(typeof(responseId) == 'undefined')
	{
		var obj = parent.getSelectedResponse();
		if(typeof(obj) != 'undefined')
		{
			respondById(obj.ID);
		}
		else
		{
			alert('You have not selected a response.');
		}
	}
	else
	{
		respondById(responseId);
	}
}
function complete()
{
//    console.log("complete()");
	return save(true);
}
function getMaxURLLength()
{
	return ($.browser.msie) ? 2000 : 4000;
}

function _log()
{
	if(typeof(console) != 'undefined')
	{
		if(1 == arguments.length)
		{
			console.log(arguments[0]);
		}
		else
		{
			console.log(arguments);
		}
	}
}
