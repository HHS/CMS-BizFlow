# BizFlow Project template

## Build & development
* go to your project folder and run below commands
* npm install -g gulp bower  (if you are not admin account, sudo npm install -g gulp bower)
* npm install
* bower intall
* gulp serve2 (this command will open a browser to show form_template page. if it renders angular-form, all good to go)

## Testing
Running `gulp test` will run the unit tests with karma.

## Open source
The folder './licenses' contains open source license files which BizFlowProject is using. The license files are captured from bower_components folder.
