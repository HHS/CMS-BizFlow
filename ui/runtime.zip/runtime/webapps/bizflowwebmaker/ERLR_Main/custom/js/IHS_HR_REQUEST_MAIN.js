/* global $ TabManager BFUtility BFActivityOption BFLog FormState StateAction bootbox hyf LookupManager */
var globalVars = {
	general_activity : 'Submit Case',
	case_complete : 'Complete Case',
	tabId_general : 'tab1',
	tabId_case_complete : 'tab2',
	tabId_documents : 'tab9',
	caseType : ''
}
var MessageResource = {
    SELECT_ONE: 'Select one',
    SELECT_ALL_THAT_APPLY: 'Select all that apply'
};
var SYSTEM_ERROR_MESSAGE = "<h3 style='color:red'>Something went wrong</h3><p><h4>The system has encountered an error. Please try again, and if it still doesn't work, contact EWITS 2.0 help desk.</h4>";
var activityList = [{
    name: globalVars.general_activity,
    usergroup: [],
    tabs: [globalVars.tabId_general, globalVars.tabId_case_complete,globalVars.tabId_documents],
    readonly: []
}, {
    name: globalVars.case_complete,
    usergroup: [],
    tabs: [globalVars.tabId_general, globalVars.tabId_case_complete,globalVars.tabId_documents],
    readonly: []
}];

var cms_case_track_main = {
    allTabInfo: [{
            id: globalVars.tabId_general,
            targetUrl: '/erlr_initial_response/initial_response.do',//tab1
            targetGroup: 'partial_tab1',
            name: 'Submit Case',
            validationOnLoadNextTab: false,
            loaded: false,
            completed: false,
            disabledHeader: false,
            postEnableTab: function () {
            },
            postClearTabContents: function () {
            },
            renderer: function () {
                cms_main_tab1.render();
            },
            onInit: function () {
                cms_main_tab1.init();
            }
        },{
            id: globalVars.tabId_case_complete,
            targetUrl: '/case_completed/case_completed.do',//tab2
            targetGroup: 'partial_tab2',
            name: 'Case Completed',
            validationOnLoadNextTab: false,
            loaded: false,
            completed: false,
            disabledHeader: false,
            postEnableTab: function () {
            },
            postClearTabContents: function () {
            },
            renderer: function () {
                CaseComplete.render();
            },
            onInit: function () {
                CaseComplete.init();
            }
        },{
            id: globalVars.tabId_documents,
            targetUrl: '/erlr_common/showAttachment.do',//last tab
            targetGroup: 'partial_tab9',
            name: 'Documents',
            validationOnLoadNextTab: false,
            loaded: false,
            completed: false,
            disabledHeader: false
        }
    ],
    tabList: [],
    getTabInfo: function(id){
        var a = $.grep(cms_case_track_main.allTabInfo, function(v){return v.id === id;});
        return typeof a === 'undefined'? a : a[0];
    },
    initBasedOnActivity: function () {
		//based on the activity, control the visibility of elements on the page.
        var activityName = BFActivityOption.getActivityName();
        $.each(activityList, function(i,v){
            if(v.name === activityName){
                $.each(v.tabs, function(tabIndex,tabId){
                    cms_case_track_main.tabList.push(cms_case_track_main.getTabInfo(tabId));
                });
            }
        });
            hyf.util.showComponent('button_ExitWIH');
            hyf.util.showComponent('button_SaveWorkitem');
            hyf.util.showComponent('button_SubmitWorkitem');
    },
    loadForm: function (data) {
        FormState.initWithXML(cms_case_track_main.renderer, data);
        _.forEach(cms_case_track_main.tabList, function (tab) {
            if (typeof tab.renderer === 'function') {
                FormState.addRenderer(tab.renderer);
            }
        });
        FormState.doRender();
    },

    onAllTabLoaded: function () {
		if (!BFUtility.isReadOnly()) {
			hyf.util.showComponent('main_buttons_layout_group');
            hyf.util.showComponent('tab_container_group');
		
        var activityName = BFActivityOption.getActivityName();
        var tabs = BFActivityOption.getTabList(activityName);
        BFUtility.initMaxSize(tabs);
        BFUtility.setDateIconTabOrder(tabs);
        $(document).on('ON_TAB_CHANGE', cms_case_track_main.onTabChange);

        $('.datePickerIcon').each(function() {
            var refId = $(this).attr('id').slice(0, -16);
            var title = "Calendar icon used to select " + $('#' + refId + '_label').text() + " value";
            $(this).attr('title', title);
        });

        setTimeout(function () {
            var ui = basicWIHActionClient.getUI();
            ui.getPane(ui.PANE_TOOL).open();
            ui.getPane(ui.PANE_TOOL).close();
            ui.getPane(ui.PANE_ATTACHMENT).hide();
            ui.getPane(ui.PANE_INTERNAL_DISCUSSION).open();
        }, 100);
		}
	},
    onTabChange: function () {
        if (BFUtility.isReadOnly() === false) {
            var selectedTab = TabManager.getSelectedTabID();
			var xml = FormState.getFinalStateXML();
			$('#h_formData').val(xml);
            basicWIHActionClient.setWIHOption('requestAction', 'tabChange');
            ajaxSubmission("actionWorkitem.do");
        }
    },

    renderer: function () {
    },
      saveForm: function (requestAction) {
        $('#h_currentTabID').val(TabManager.getSelectedTabID()); // store current tabid to reset after page reload
        var xml = FormState.getFinalStateXML();

        $('#h_formData').val(xml);
        if(typeof requestAction === 'string'){
            basicWIHActionClient.setWIHOption('requestAction', requestAction);
        }
        ajaxSubmission("actionWorkitem.do");
    },
    init: function () {
        BFLog.setLogLevel('DEBUG');
       $('#main_buttons_layout_group').css('visibility', 'hidden');

        var xml = $('#h_formData').val();
        FormState.initWithXML(function(){}, xml);
        FormState.doRender();
        if ($('#WIH_exit_requested').val() == 'true') {
            basicWIHActionClient.exit({confirmMsg: null});
        }
        BFActivityOption.init(activityList);

        cms_case_track_main.initBasedOnActivity();
        $('#formTitle').text(BFActivityOption.getActivityName());

        if (BFUtility.isReadOnly() === true) {
            var activityName = BFActivityOption.getActivityName();
            var readonlyTabs = [globalVars.tabId_general, globalVars.tabId_case_complete, globalVars.tabId_documents];
            BFActivityOption.setReadOnlyTabList(activityName, readonlyTabs);
        }

        LookupManager.init();
		 TabManager.initTab(cms_case_track_main.tabList, function(){
				var data = $('#h_formData').val();
				cms_case_track_main.loadForm(data);
			});
		
        $(document).on('HHS_ALL_TAB_LOADED', cms_case_track_main.onAllTabLoaded);

        $('#button_SaveWorkitem').on('click', function(){cms_case_track_main.saveForm('saveDraft');});
      
        $('#button_PDF').off('click').click(function (e) {
            // Form validation
            var alertMsg = undefined;
            var isValidForm = true;
            var watchTabId = null;
            var activeTabs = BFActivityOption.getTabList(BFActivityOption.getActivityName());
            for (var tabIndex = 0; tabIndex < activeTabs.length; tabIndex++) {
                watchTabId = activeTabs[tabIndex];
                isValidForm = TabManager.validateTab(watchTabId);
                if (isValidForm === false) {
                    break;
                }
            }
            if (isValidForm) {
				completeWorkitem('Close', false);
            } else {
                if (alertMsg) {
                    bootbox.alert(alertMsg);
                }
                $('#' + TabManager.getAnchorID(watchTabId)).click();
            }
        });
        $('#button_SubmitWorkitem').off('click').click(function (e) {
            // Form validation
            var showAlertMsg = true;
            var isValidForm = true;
            var watchTabId = null;
            var activeTabs = BFActivityOption.getTabList(BFActivityOption.getActivityName());
            for (var tabIndex = 0; tabIndex < activeTabs.length; tabIndex++) {
                watchTabId = activeTabs[tabIndex];
                isValidForm = TabManager.validateTab(watchTabId);
                if (isValidForm === false) {
                    break;
                }
            }
            if (isValidForm) {
                completeWorkitem('Submit', false);
            } else {
                if (showAlertMsg) {
                    bootbox.alert('Please fill in all the required fields before submit.');
                }
                $('#' + TabManager.getAnchorID(watchTabId)).click();
            }
        });
        $('#button_ExitWIH').off('click').click(function (e) {
            cms_case_track_main.confirmClose();
        });
        // Request Date
        var requestedDateString = $('#h_creationdate').val();
        if (requestedDateString != null && requestedDateString.length > 0) {
            var requestedDate = new Date(requestedDateString); // requestedDateString is GMT
            var newDate = new Date(requestedDate.getTime() - requestedDate.getTimezoneOffset() * 60000); // Adjust to local time
            var requestedDateLabel = BFUtility.getDateString(false, 'mm/dd/yyyy', newDate);
            $('#initiatedDate').text(requestedDateLabel);
        }

        // // Request Number to process ID
        var requestNumber = $('#h_procid').val();
        $('#requestNumber').text(requestNumber);
        var requestStatus = 'Open';//cms_case_track_main.getStatus();
        if (requestStatus) {
            $('#output_caseStatus').text(requestStatus);
        }

        $('a.selectedTab').focus();
    },
    saveDraft: function () {
        var xml = FormState.getFinalStateXML();
        $('#h_formData').val(xml);
        basicWIHActionClient.setWIHOption('requestAction', 'saveDraft');
        ajaxSubmission("actionWorkitem.do");
    },
    confirmClose: function () {
        bootbox.dialog({
            message: '<p class="bootbox-body">Would you like to save your entries before closing?</p>',
            onEscape: true,
            buttons: [{
                    label: 'No',
                    callback: function () {
                        basicWIHActionClient.exit({confirmMsg: null});
                    }
                },
                {
                    label: 'Yes, save and close',
                    className: 'btn-primary',
                    callback: function () {
                        $('#WIH_exit_requested').val(true);
                        cms_case_track_main.saveForm('exit');
                    }
                }]
        });

    },
    confirmCancel: function () {
        var cancelReasons = LookupManager.findByLTYPE('CancellationReason');
        var selectHTML = '<select class="form-control" id="cancelReason" name="cancelReason"><option value="">Select one</option>';
        for (var i = 0; i < cancelReasons.length; i++) {
            selectHTML += '<option value="' + cancelReasons[i].NAME + '">' + cancelReasons[i].NAME + '</option>';
        }
        selectHTML += '</select>';

        //user must confirm closing
        bootbox.confirm({
            title: 'What is the reason for canceling this request?',
            message: selectHTML,
            buttons: {
                confirm: {
                    label: 'OK',
                    className: 'btn-success'
                }
            },
            callback: function (result) {
                if (result) {
                    if ('' === $('#cancelReason').val()) {
                        bootbox.alert('Please select a cancellation reason');
                    } else {
                        $('#pv_cancelReason').val($('#cancelReason').val());
                        completeWorkitem('Cancel', false);
                    }
                }
            }
        });
    },
    
    uuid: function () {
        return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        })
    },
    dialogSelectHRSpecialist: null,
    getTab: function () {
        var tabID = TabManager.getSelectedTabID();
        var selectedTabs = cms_case_track_main.tabList.filter(function (node, index) {
            return node.id === tabID;
        });
        var foundTab = null;
        if (selectedTabs.length === 1) {
            foundTab = selectedTabs[0];
        }
        return foundTab;
    }
};

$(document).ready(function(){
    try{
        cms_case_track_main.init();
    }catch(e){
        bootbox.alert({
            message: SYSTEM_ERROR_MESSAGE,
            callback: function(){
                basicWIHActionClient.exit({confirmMsg: null});
            }
        });
        BFLog.log('ERROR', e);
    }
});

/**
 * Adding options to a select tag
 * @param field field ID
 * @param items options
 * @param defaultValue default value
 * @param config {firstItem: {value:'', text:'Select one'} }
 */
function populateSelectOptions(field, items, defaultValue, config) {
    var $f = $('#' + field).html('');
    if (config.firstItem) {
        $f.append($('<option>', {value: config.firstItem.value, text: config.firstItem.text}));
    }
    $.each(items, function (i, item) {
        $f.append($('<option>', {value: item.value, text: item.text, selected: (defaultValue === item.value)}));
    });
    return $f;
}

/**
 * Submit form data and complete workitem. Workitem Handler closed when it completed successfully.
 * @param responseName (Optional) the response name should be one of the available response names on current activity.
 */
function completeWorkitem(responseName, formValidation){
    var xml = FormState.getFinalStateXML();
    $('#h_formData').val(xml);

    if(typeof responseName !== 'undefined'){
        basicWIHActionClient.setResponseByName(responseName);
    }
    basicWIHActionClient.setWIHOption('requestAction', 'complete');
    if(!basicWIHActionClient.getWIHOption('formSaved')){
        basicWIHActionClient.setWait();
        ajaxSubmission('actionWorkitem.do?requestAction='+responseName, 'all', undefined, formValidation);
    }
}

/**
 * This function to be called when the partial page is loaded.
 */
function onLoadResultActionWorkitem(){
    var errorMessage = $('#ResultActionWorkitemtErrorMessage').val();
    if(errorMessage && 0<errorMessage.length){
        BFLog.log('ERROR', errorMessage);
        bootbox.alert(SYSTEM_ERROR_MESSAGE);
    }else{
        basicWIHActionClient.setWIHOption('formSaved', true);
        var action = basicWIHActionClient.getWIHOption('requestAction');
        if(action === 'complete'){
            basicWIHActionClient.setContinue();
            basicWIHActionClient.setWIHOption('closeWihOnComplete', true);
            basicWIHActionClient.setWIHOption('completionWindow', false);
            basicWIHActionClient.complete();
        } else if(action === 'tabChange') {

        } else if(action === 'saveDraft') {
            basicWIHActionClient.notify('Your data has been successfully saved.', 3000);
        } else if(action === 'exit') {
            basicWIHActionClient.exit({confirmMsg: null});
        }

        basicWIHActionClient.setWIHOption('formSaved', undefined);
        basicWIHActionClient.setWIHOption('requestAction', undefined);
    }

    BFUtility.greyOutScreen(false);
}

/**
 * Submit form data via ajax
 * @param action WebMaker action name
 * @param sourceGroup (Optional) indicates whether to send all the data on the page or just the data within a particular group.
 * @param targetGroup (Optional) indicates which group to place the results into.
 * @param validate (Optional) indicates whether to validate first. default: false
 * @example
 * // Submit all data without form validation on the page, and result page is not showing.
 * ajaxSubmission('actionWorkitem.do');
 * // Form validation before submit all data on the page, and result page is not showing.
 * ajaxSubmission('actionWorkitem.do', 'all', undefined, true);
 * // Form validation before submit data within 'input_layout_group', and results showing to 'output_layout_group'.
 * ajaxSubmission('actionWorkitem.do', 'input_layout_group', 'output_layout_group', true);
 */
function ajaxSubmission(action, sourceGroup, targetGroup, validate) {
    if (window.location.pathname.indexOf('bizflowwebmaker') > -1 && action.indexOf('/') === 0) {
        action = '/bizflowwebmaker' + action;
    }
    var objAction = {
        name: 'Action',
        option: 'Action',
        value: action
    };
    var objSourceGroup = null;
    if (typeof sourceGroup === 'undefined' || null === sourceGroup || '' === sourceGroup
        || 'all' === sourceGroup || 'ALL' === sourceGroup) {
        objSourceGroup = {name: 'SourceGroup', option: 'AllFormData', value: ''};
    } else {
        objSourceGroup = {name: 'SourceGroup', option: 'PageGroup', value: sourceGroup};
    }

    var partialPageContainerId = '_hidden_partial_page_container_';
    if(typeof targetGroup === 'undefined'){
        var partialPageContainer = document.createElement('div');
        if(document.getElementById(partialPageContainerId) === null){
            partialPageContainer.id = partialPageContainerId;
            partialPageContainer.style.display = "none";
            document.getElementsByTagName('body')[0].appendChild(partialPageContainer);
        }
    }else{
        partialPageContainerId = targetGroup;
    }

    var objTargetGroup = {
        name: 'TargetGroup',
        option: 'PageGroup',
        value: partialPageContainerId
    };
    var objValidate = {
        name: 'Validate',
        option: 'Static',
        value: validate?validate:false
    };
    hyf.FMAction.handleAjaxSubmission(objAction, objSourceGroup, objTargetGroup, objValidate, {value: targetGroup});
}

function isTrue(val){
    if(typeof val === 'boolean'){
        return val;
    } else if(typeof val === 'string' && val.toLowerCase() === 'true') {
        return true;
    }
    return false;
}
function unique(array) {
    return $.grep(array, function(el, index) {
        return index == $.inArray(el, array);
    });
}

$( document ).ajaxError(function( event, request, settings, thrownError ) {
    bootbox.alert(SYSTEM_ERROR_MESSAGE);
    BFLog.log('ERROR', thrownError);
});