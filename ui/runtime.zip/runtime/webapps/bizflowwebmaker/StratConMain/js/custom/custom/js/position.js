var positionBind = function(){

    $('#POS_DESC_NUMBER').on('change', function(e){
        if($(this).val().length > 0){//Position Description Entered
            $('#POS_CLASSIFICATION_DT_label_container').removeClass('hidden');
            $('#POS_CLASSIFICATION_DT_container').removeClass('hidden');
            $('#POS_CLASSIFICATION_DT').attr('_required', 'true');
            $('#NEW_PD_GROUP').addClass('hidden');
            $('#POS_PAY_PLAN_label_container').removeClass('hidden');
            $('#POS_PAY_PLAN_container').removeClass('hidden');
            $('#POS_PAY_PLAN').attr('_required', 'true');
            $('#POS_SERIES_label_container').removeClass('hidden');
            $('#POS_SERIES_container').removeClass('hidden');
            $('#POS_SERIES').attr('_required', 'true');
            $('#POS_GRADE_label_container').removeClass('hidden');
            $('#POS_GRADE_container').removeClass('hidden');
            $('#POS_GRADE').attr('_required', 'true');
            $('#POS_PERFORMANCE_LEVEL_label_container').removeClass('hidden');
            $('#POS_PERFORMANCE_LEVEL_container').removeClass('hidden');
            $('#POS_PERFORMANCE_LEVEL').attr('_required', 'true');

        } else{
            $('#POS_CLASSIFICATION_DT_label_container').addClass('hidden');
            $('#POS_CLASSIFICATION_DT_container').addClass('hidden');
            $('#POS_CLASSIFICATION_DT').attr('_required', 'false');
            $('#NEW_PD_GROUP').removeClass('hidden');
            $('#POS_PAY_PLAN_label_container').addClass('hidden');
            $('#POS_PAY_PLAN_container').addClass('hidden');
            $('#POS_PAY_PLAN').attr('_required', 'false');
            $('#POS_SERIES_label_container').addClass('hidden');
            $('#POS_SERIES_container').addClass('hidden');
            $('#POS_SERIES').attr('_required', 'false');
            $('#POS_GRADE_label_container').addClass('hidden');
            $('#POS_GRADE_container').addClass('hidden');
            $('#POS_GRADE').attr('_required', 'false');
            $('#POS_PERFORMANCE_LEVEL_label_container').addClass('hidden');
            $('#POS_PERFORMANCE_LEVEL_container').addClass('hidden');
            $('#POS_PERFORMANCE_LEVEL').attr('_required', 'false');
        }
    });
    $('#POS_GRADE').on('change', function(e){
        var preselect = $('#POS_PERFORMANCE_LEVEL').val();
        var min = $('#POS_GRADE').val();
        $('#POS_PERFORMANCE_LEVEL').empty();

        $('#GRADE_SOURCE option').each(function(){
            console.log($(this).val());
            console.log("****");
            if($(this).val() >= min){
                $('#POS_PERFORMANCE_LEVEL').append($('#GRADE_SOURCE option[value="' + $(this).val() + '"]').clone());
            }
            if(preselect.length > 0){
                $('#POS_PERFORMANCE_LEVEL').val(preselect);
            }
        });
    });

    $('#POS_DESC_NUMBER').trigger('change');
    $('#POS_GRADE').trigger('change');
};