/**
 * Controls the SME for JA group depending on the check status of the checkbox.
 *
 * @param isChecked - boolean value for the checkbox of SME for Job Analysis
 */
function controlSmeForJAGroup(){
	var isChecked = $("#SME_FOR_JOB_ANALYSIS").prop("checked");
	if (isChecked) {
		$("#sme_ja_identity_grid_group").show();
	} else {
		$("#SME_JA_DSP").addClass('hidden').empty();
		$("#SME_JA_INPUT_container").removeClass('hidden');
		$("#SME_JA_INPUT").attr('_required', 'true');

		$("#sme_ja_identity_grid_group").hide();

		// when hiding, clear field values, too
		$("#SME_NAME_JA").val("");
		$("#SME_EMAIL_JA").val("");
	}
}

/**
 * Controls the SME for Qualification group depending on the check status of the checkbox.
 *
 * @param isChecked - boolean value for the checkbox of SME for Qualification
 */
function controlSmeForQualGroup(){
	var isChecked = $("#SME_FOR_QUALIFICATION").prop("checked");
	if (isChecked) {
		$("#sme_qual_identity_grid_group").show();
	} else {
		$("#SME_QUAL_1_DSP").addClass('hidden').empty();
		$("#SME_QUAL_1_INPUT_container").removeClass('hidden');
		$("#sme_qual_identity_grid_group").hide();
		// when hiding, clear field values, too
		$("#SME_NAME_QUAL_1").val("");
		$("#SME_EMAIL_QUAL_1").val("");
		$("#SME_NAME_QUAL_2").val("");
		$("#SME_EMAIL_QUAL_2").val("");
	}
}

/**
 * Controls Selective Factor checkbox, its associated Justify textarea, and note for GS-0602.
 *
 * For GS-0602,
 * 1. Check Selective Factor checkbox automatically.
 * 2. Set the initial text for Justify textarea
 * 3. Show Justify textarea
 * 4. Show note for GS-0602
 *
 * For non-GS-0602, reverse the above.
 *
 * @param posPayPlanValSel - Pay Plan option value that is selected.
 * @param posSeriesValSel - Series option value that is selected.
 */
function controlSelectiveFactorGroup() {
	var posSeriesValSel = $("#POS_SERIES option:selected").val();
	var posPayPlanValSel = $("#POS_PAY_PLAN option:selected").val();

	if (posPayPlanValSel == "GS" && posSeriesValSel == "0602") {
		// for GS-0602, automatically check Selective Factor checkbox
		$("#JA_SEL_FACTOR_REQ").prop("checked", true);
		$('#JA_SEL_FACTOR_REQ').attr('disabled','disabled');
		$('#JA_SEL_FACTOR_JUST').val('');
		$("#ja_sel_just_group").hide();
		$("#sel_fac_note_group").show();

		var width = $(window).width();
		$('div.cmsNoteChildWidth').parent().attr('style','width:' + width * 0.80 + 'px');
	} else {
		// for non-GS-0602, clear/hide
		$("#JA_SEL_FACTOR_REQ").prop("checked", false);
		$("#ja_sel_just_group").hide();
		$('#JA_SEL_FACTOR_REQ').removeAttr('disabled');
		$('#JA_SEL_FACTOR_JUST').val('');
		$("#sel_fac_note_group").hide();  // hide note for GS-0602

		$('div.cmsNoteChildWidth').parent().attr('style','display:none');
	}
}

/**
 * Controls show/hide of Justify textbox associated with Selective Factor checkbox.
 *
 * @param isChecked - boolean value for the checkbox of Selective Factor
 */
function controlSelectiveFactorJustifyGroup(){
	var isChecked = $("#JA_SEL_FACTOR_REQ").prop('checked');
	if (isChecked) {
		$("#ja_sel_just_group").show();
	} else {
		$("#ja_sel_just_group").hide();
		$("#JA_SEL_FACTOR_JUST").val("");  // when hiding, clear field values, too
	}
}

/**
 * Controls show/hide of Justify textbox associated with Quality Ranking Factor checkbox.
 *
 * @param isChecked - boolean value for the checkbox of Quality Ranking Factor
 */
function controlQalityRankingFactorJustifyGroup(){
	var isChecked = $("#JA_QUAL_RANK_REQ").prop("checked");
	if (isChecked) {
		$("#ja_qual_rank_just_group").show();
	} else {
		$("#ja_qual_rank_just_group").hide();
		$("#JA_QUAL_RANK_JUST").val("");  // when hiding, clear field values, too
	}
}

/**
 * Controls show/hide of Justify textbox associated with Multiple Types of Assessment checkbox.
 *
 * @param isChecked - boolean value for the checkbox of Multiple Types of Assessment
 */
function controlMultiTypeAssessGroup(){
	var isChecked = $("#JA_RESPONSES_REQ").prop("checked");
	if (isChecked) {
		$("#assess_qtype_group").show();
	} else {
		$("#assess_qtype_group").hide();
		// clear child checkbox upon unchecking parent
		$("#JA_TYPE_YES_NO").prop("checked", false);
		$("#JA_TYPE_REQ_DEFAULT").prop("checked", false);
		$("#JA_TYPE_KNOWL_SCALE").prop("checked", false);
	}
}

// This method/function shows an alert and clears the
// text due to invalid values
function  showAlert($this, id, msg) {
	var pos = $this.position();
	$("#" + id).remove();
	$this.after("<span id='" + id + "' class='limitAlert' role='alert'>" + msg + "</span>");
	$("#" + id).css({top: pos.top + 20, left: pos.left + 30, position:'absolute'});
	setTimeout(function() {
		$("#" + id).remove();
	}, 2000);
}

var baseURL = '/bizflowwebmaker/StratCon_AUT/';
function initJAAutoComplete() {
	$("#SME_JA_INPUT").autocomplete({
		appendTo:'#SME_JA_SEARCH_LIST',
		source: function (request, response) {
			$.ajax({
				url: baseURL + "SearchPeopleNameEmail.do?searchString=" + $('#SME_JA_INPUT').val(),
				dataType: "xml",
				cache: false,
				success: function (xmlResponse) {
					var data = $("record", xmlResponse ).map(function() {
						return {
							mid: $( "MID", this ).text(),
							dspname: $( "DSPNAME", this ).text(),
							deptname: $( "DEPTNAME", this ).text(),
							email: $( "EMAIL", this ).text()
						};
					}).get();
					response(data);
				}
			})
		},
		minLength: 2,
		change: function (e, u) {
			var pos = $(this).position();
			if (u.item == null) {
				showAlert($(this),'SME_JA_nomatch',"Invalid Selection:<br />Item must be selected from the available options.");
				$(this).val("");
				return false;
			}
		},
		select: function (event, ui) {
			var label = ui.item.dspname;
			if (ui.item.email != '') {
				label = label + ' (' + ui.item.email + ')';
			}
			var li = "<li id=\"ss" + ui.item.mid + "\">";
			li += getAutoCompRemoveIconElement('ja' + ui.item.mid, label, '505');
			li += label +  "</li>";
			$("#SME_JA_DSP").append(li).removeClass('hidden');
			$("#SME_JA_INPUT_container").addClass('hidden');
			$("#SME_JA_SEARCH_LIST").attr('_required', 'false')

			$('#SME_NAME_JA').val(ui.item.dspname);
			$('#SME_EMAIL_JA').val(ui.item.email);

			$('#SME_JA_SEARCH_LIST ul li').each(function() {
				$(this).remove();
			});                  
		},
		open: function() {
			$(".ui-autocomplete").css("z-index", 5000);
		},
		close: function() {
			$(".ui-autocomplete").css("z-index", 1);
		}
	})
	.autocomplete().data("ui-autocomplete")._renderItem = function (ul, item) {
		var label = item.dspname;
		if (item.email != '') {
			label = label + ' (' + item.email + ')';
		}
		return $("<li>")
		.append("<a>"  + label +  "</a>")
		.appendTo(ul);
	};

	$("#SME_JA_DSP").on("click keyup", "img", function () {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			$("#SME_JA_DSP").addClass('hidden').empty();
			$("#SME_JA_INPUT_container").removeClass('hidden');
			$("#SME_JA_INPUT").attr('_required', 'true');

			$('#SME_NAME_JA').val('');
			$('#SME_EMAIL_JA').val('');
		}
	});
	if ($('#SME_NAME_JA').val() != '') {
		var smeIDJA = '_JA';
		var label = $('#SME_NAME_JA').val();
		var email = $('#SME_EMAIL_JA').val();
		if (email != '') {
			label = label + ' (' + email + ')';
		}
		var li = "<li id=\"ss" + smeIDJA + "\">";
		if ($('#h_readOnly').val() != 'y') {
			li += getAutoCompRemoveIconElement('ss' + smeIDJA, label, '505');
		}
		li += label +  "</li>";
		$("#SME_JA_DSP").append(li).removeClass('hidden');
		$("#SME_JA_INPUT_container").addClass('hidden');
		$("#SME_JA_INPUT").attr('_required', 'false');
		hyf.util.showComponent('SME_JA_INPUT');
	}        	
}

function initQual1AutoComplete() {
	$("#SME_QUAL_1_INPUT").autocomplete({
		appendTo:'#SME_QUAL_1_SEARCH_LIST',
		source: function (request, response) {
			$.ajax({
				url: baseURL + "SearchPeopleNameEmail.do?searchString=" + $('#SME_QUAL_1_INPUT').val(),
				dataType: "xml",
				cache: false,
				success: function (xmlResponse) {
					var data = $("record", xmlResponse ).map(function() {
						return {
							mid: $( "MID", this ).text(),
							dspname: $( "DSPNAME", this ).text(),
							deptname: $( "DEPTNAME", this ).text(),
							email: $( "EMAIL", this ).text()
						};
					}).get();
					response(data);
				}
			})
		},
		minLength: 2,
		change: function (e, u) {
			var pos = $(this).position();
			if (u.item == null) {
				showAlert($(this),'SME_Q1_nomatch',"Invalid Selection:<br />Item must be selected from the available options.");
				$(this).val("");
				return false;
			}
		},
		select: function (event, ui) {
			var labelArray = []
			$('#SME_QUAL_1_DSP li').each(function() { 
				labelArray.push($(this).text().trim())
				$(this).remove();
			});

			var label = ui.item.dspname;
			if (ui.item.email != '') {
				label = label + ' (' + ui.item.email + ')';
			}
			var foundDuplicate = false;
			for (var index = 0; index < labelArray.length; index++) {
				if (labelArray[index] == label) {
					foundDuplicate = true;
					break;
				}
			}
			if (foundDuplicate != true ) {
				labelArray.push(label);
				labelArray.sort();
			}

			for (var i = 0; i < labelArray.length; i++) {
				var li = "<li id=\"sq" + '_li_' + (i+1) + "\">";
				li += getAutoCompRemoveIconElement('sq' + '_li_' + (i+1), labelArray[i], '505');
				li += labelArray[i] + "</li>";
				$("#SME_QUAL_1_DSP").append(li);
			}

			$('#SME_NAME_QUAL_1').val('');
			$('#SME_EMAIL_QUAL_1').val('');
			$('#SME_NAME_QUAL_2').val('');
			$('#SME_EMAIL_QUAL_2').val('');

			if (labelArray.length == 1) {
				$('#SME_NAME_QUAL_1').val(getNameFromLabel(labelArray[0]));
				$('#SME_EMAIL_QUAL_1').val(getEmailFromLabel(labelArray[0]));
			}
			if (labelArray.length == 2) {
				$('#SME_NAME_QUAL_1').val(getNameFromLabel(labelArray[0]));
				$('#SME_EMAIL_QUAL_1').val(getEmailFromLabel(labelArray[0]));
				$('#SME_NAME_QUAL_2').val(getNameFromLabel(labelArray[1]));
				$('#SME_EMAIL_QUAL_2').val(getEmailFromLabel(labelArray[1]));
			}

			if (labelArray.length == 0) {
				$("#SME_QUAL_1_SEARCH_LIST").attr('_required', 'true')
			} else {
				$("#SME_QUAL_1_SEARCH_LIST").attr('_required', 'false')
			}
			
			$("#SME_QUAL_1_DSP").removeClass('hidden');
			
			if (labelArray.length >= 2) {
				$("#SME_QUAL_1_INPUT_container").addClass('hidden');
			} else {
				$("#SME_QUAL_1_INPUT_container").removeClass('hidden');
			}

			$('#SME_QUAL_1_SEARCH_LIST ul li').each(function() {
				$(this).remove();
			});                  
		},
		open: function() {
			$(".ui-autocomplete").css("z-index", 5000);
		},
		close: function() {
			$(".ui-autocomplete").css("z-index", 1);
		}
	})
	.autocomplete().data("ui-autocomplete")._renderItem = function (ul, item) {
		var label = item.dspname;
		if (item.email != '') {
			label = label + ' (' + item.email + ')';
		}
		return $("<li>")
		.append("<a>"  + label + "</a>")
		.appendTo(ul);
	};

	$("#SME_QUAL_1_DSP").on("click keyup", "img", function () {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			var deletedID = $(this).attr('deleteid');
			$('#SME_QUAL_1_DSP #' + deletedID).remove()

			$("#SME_QUAL_1_INPUT_container").removeClass('hidden');

			if ($('#SME_NAME_QUAL_1').val() != '' && $('#SME_NAME_QUAL_2').val() != '') {
				$("#SME_QUAL_1_INPUT").attr('_required', 'false');
			} else {
				$("#SME_QUAL_1_INPUT").attr('_required', 'true');
			}
			
			var label = $('#SME_NAME_QUAL_1').val();
			var email = $('#SME_EMAIL_QUAL_1').val()
			if (email != '') {
				label = label + ' (' + email + ')';
			}

			if ($(this)[0].nextSibling.data.trim() == label.trim()) {
				$('#SME_NAME_QUAL_1').val('');
				$('#SME_EMAIL_QUAL_1').val('');
			} else {
				$('#SME_NAME_QUAL_2').val('');
				$('#SME_EMAIL_QUAL_2').val('');
			}
		}
	});
	if ($('#SME_NAME_QUAL_1').val() != '' || $('#SME_NAME_QUAL_2').val() != '') {
		var smeIDQual1 = '_Q1';
		var labelArray = [];

		var label = $('#SME_NAME_QUAL_1').val();
		if (label != '') {
			var email = $('#SME_EMAIL_QUAL_1').val()
			if (email != '') {
				label = label + ' (' + email + ')';
			}
			labelArray.push(label);
		}

		var label2 = $('#SME_NAME_QUAL_2').val();
		if (label2 != '') {
			var email2 = $('#SME_EMAIL_QUAL_2').val()
			if (email != '') {
				label2 = label2 + ' (' + email2 + ')';
			}
			labelArray.push(label2);
		}

		labelArray.sort();

		for (var i = 0; i < labelArray.length; i++) {
			var li = "<li id=\"sq" + '_li_' + (i+1) + "\">";
			if ($('#h_readOnly').val() != 'y') {
				li += getAutoCompRemoveIconElement('sq' + '_li_' + (i+1), labelArray[i], '505');
			}
			li += labelArray[i] +  "</li>";
			$("#SME_QUAL_1_DSP").append(li);
		}

		if (labelArray.length > 0) {
			$("#SME_QUAL_1_DSP").removeClass('hidden');
		} else {
			$("#SME_QUAL_1_DSP").addClass('hidden');
		}
		if (labelArray.length >= 2) {
			$("#SME_QUAL_1_INPUT_container").addClass('hidden');
		} else {
			$("#SME_QUAL_1_INPUT_container").removeClass('hidden');
		}
		if (labelArray.length >= 1) {
			$("#SME_QUAL_1_INPUT").attr('_required', 'false')
		} else {
			$("#SME_QUAL_1_INPUT").attr('_required', 'false')
		}
	}        	
}

function getNameFromLabel(label) {
	if (label.length > 0) {
		var separatorIndex = label.indexOf('(');
		if (separatorIndex == -1) {
			return label.trim();
		} else {
			return label.substring(0, separatorIndex).trim();
		}
	} else {
		return '';
	}
}
function getEmailFromLabel(label) {
	// Anderson, Maxine (manderson@bizflow.com)
	if (label.length > 0) {
		var separatorIndex = label.indexOf('(');
		if (separatorIndex == -1) {
			return '';
		} else {
			return label.substring(separatorIndex + 1, label.length - 1).trim()
		}
	} else {
		return '';
	}
}

/**
 * onload handler for SME/JA tab page
 */
function initSmeJaTab() {
	$("#POS_PAY_PLAN").on("change", function() {
		controlSelectiveFactorGroup();
	});
	$("#POS_SERIES").on("change", function() {
		controlSelectiveFactorGroup();
	});

	// Show Justify field for Selective Factor only the associated checkbox is checked
	$("#JA_SEL_FACTOR_REQ").change(function() {
		controlSelectiveFactorJustifyGroup();
	});
	// Show Name/Email fields for SME only if the associated Job Analysis checkbox is checked
	$("#SME_FOR_JOB_ANALYSIS").change(function() {
		controlSmeForJAGroup();
	});
	// Show Name/Email fields for SME only if the associated Qualification checkbox is checked
	$("#SME_FOR_QUALIFICATION").change(function() {
		controlSmeForQualGroup();
	});
	// Show Justify field for Quality Ranking Factor only the associated checkbox is checked.
	$("#JA_QUAL_RANK_REQ").change(function() {
		controlQalityRankingFactorJustifyGroup();
	});
	// Show checkboxes under subgroup for Multiple Types of Assessment only when the parent checkbox is checked.
	$("#JA_RESPONSES_REQ").change(function() {
		controlMultiTypeAssessGroup();
	});
	$("#POS_PAY_PLAN").on("change", function() {
		controlSelectiveFactorGroup();
	});
	$("#POS_SERIES").on("change", function() {
		controlSelectiveFactorGroup();
	});

	var posSeriesValSel = $("#POS_SERIES option:selected").val();
	var posPayPlanValSel = $("#POS_PAY_PLAN option:selected").val();
	if (posPayPlanValSel == "GS" && posSeriesValSel == "0602") {
		// for GS-0602, automatically check Selective Factor checkbox
		$("#JA_SEL_FACTOR_REQ").prop("checked", true);
		$('#JA_SEL_FACTOR_REQ').attr('disabled','disabled');
		$('#JA_SEL_FACTOR_JUST').val('');
		$("#ja_sel_just_group").hide();
		$("#sel_fac_note_group").show();

		var width = $(window).width();
		$('div.cmsNoteChildWidth').parent().attr('style','width:' + width * 0.80 + 'px');
	} else {
		// for non-GS-0602, clear/hide
		$("#sel_fac_note_group").hide();  // hide note for GS-0602
		$('div.cmsNoteChildWidth').parent().attr('style','display:none');
		// $("#JA_SEL_FACTOR_REQ").trigger("change");		
		controlSelectiveFactorJustifyGroup();		
	}			

	controlSmeForJAGroup();
	controlSmeForQualGroup();
	controlSelectiveFactorGroup();
	controlSelectiveFactorGroup();
	controlSelectiveFactorJustifyGroup();
	controlQalityRankingFactorJustifyGroup();
	controlMultiTypeAssessGroup();

	var posSeriesValSel = $("#POS_SERIES option:selected").val();
	var posPayPlanValSel = $("#POS_PAY_PLAN option:selected").val();
	if (posPayPlanValSel == "GS" && posSeriesValSel == "0602") {
		// for GS-0602, automatically check Selective Factor checkbox
		$("#JA_SEL_FACTOR_REQ").prop("checked", true);
		$('#JA_SEL_FACTOR_REQ').attr('disabled','disabled');
		$('#JA_SEL_FACTOR_JUST').val('');
		$("#ja_sel_just_group").hide();
		$("#sel_fac_note_group").show();

		var width = $(window).width();
		$('div.cmsNoteChildWidth').parent().attr('style','width:' + width * 0.80 + 'px');
	} else {
		// for non-GS-0602, clear/hide
		$("#sel_fac_note_group").hide();  // hide note for GS-0602
		$('div.cmsNoteChildWidth').parent().attr('style','display:none');
		// $("#JA_SEL_FACTOR_REQ").trigger("change");	
		controlSelectiveFactorJustifyGroup();			
	}
	initJAAutoComplete();
	initQual1AutoComplete();
} // end initSmeJaTab()