/**
 * Controls the SME for JA group depending on the check status of the checkbox.
 *
 * @param isChecked - boolean value for the checkbox of SME for Job Analysis
 */
function controlSmeForJAGroup(){
	var isChecked = $("#SME_FOR_JOB_ANALYSIS").prop("checked");
	if (isChecked) {
		$("#sme_ja_identity_grid_group").show();
	} else {
		$("#SME_JA_DSP").addClass('hidden').empty();
		$("#SME_JA_INPUT_container").removeClass('hidden');
		$("#SME_JA_INPUT").attr('_required', 'true');

		$("#sme_ja_identity_grid_group").hide();

		// when hiding, clear field values, too
		$("#SME_NAME_JA").val("");
		$("#SME_EMAIL_JA").val("");
	}
}

/**
 * Controls the SME for Qualification group depending on the check status of the checkbox.
 *
 * @param isChecked - boolean value for the checkbox of SME for Qualification
 */
function controlSmeForQualGroup(){
	var isChecked = $("#SME_FOR_QUALIFICATION").prop("checked");
	if (isChecked) {
		$("#sme_qual_identity_grid_group").show();
	} else {
		$("#SME_QUAL_1_DSP").addClass('hidden').empty();
		$("#SME_QUAL_1_INPUT_container").removeClass('hidden');
		$("#sme_qual_identity_grid_group").hide();
		// when hiding, clear field values, too
		$("#SME_NAME_QUAL_1").val("");
		$("#SME_EMAIL_QUAL_1").val("");
		$("#SME_NAME_QUAL_2").val("");
		$("#SME_EMAIL_QUAL_2").val("");
	}
}

/**
 * Controls Selective Factor checkbox, its associated Justify textarea, and note for GS-0602.
 *
 * For GS-0602,
 * 1. Check Selective Factor checkbox automatically.
 * 2. Set the initial text for Justify textarea
 * 3. Show Justify textarea
 * 4. Show note for GS-0602
 *
 * For non-GS-0602, reverse the above.
 *
 * @param posPayPlanValSel - Pay Plan option value that is selected.
 * @param posSeriesValSel - Series option value that is selected.
 */
function controlSelectiveFactorGroup(e) {
	var posSeriesValSel = $("#POS_SERIES option:selected").val();
	var posPayPlanValSel = $("#POS_PAY_PLAN option:selected").val();

	if (posPayPlanValSel == "GS" && posSeriesValSel == "0602") {
		// for GS-0602, automatically check Selective Factor checkbox
		$("#JA_SEL_FACTOR_REQ").prop("checked", true);
		$('#JA_SEL_FACTOR_REQ').attr('disabled','disabled');
		$('#JA_SEL_FACTOR_JUST').val('');
		$("#ja_sel_just_group").hide();
		$("#sel_fac_note_group").show();

		var width = $(window).width();
		$('div.cmsNoteChildWidth').parent().attr('style','width:' + width * 0.80 + 'px');
	} else {
		// for non-GS-0602, clear/hide
		if (e && e.isTrigger != true) {
			$("#JA_SEL_FACTOR_REQ").prop("checked", false);
		}
		$('#JA_SEL_FACTOR_REQ').removeAttr('disabled');
		$("#sel_fac_note_group").hide();  // hide note for GS-0602
		$('div.cmsNoteChildWidth').parent().attr('style','display:none');
		controlSelectiveFactorJustifyGroup();
	}
}

/**
 * Controls show/hide of Justify textbox associated with Selective Factor checkbox.
 *
 * @param isChecked - boolean value for the checkbox of Selective Factor
 */
function controlSelectiveFactorJustifyGroup(){
	var isChecked = $("#JA_SEL_FACTOR_REQ").prop('checked');
	if (isChecked) {
		$("#ja_sel_just_group").show();
	} else {
		$("#ja_sel_just_group").hide();
		$("#JA_SEL_FACTOR_JUST").val("");  // when hiding, clear field values, too
	}
}

/**
 * Controls show/hide of Justify textbox associated with Quality Ranking Factor checkbox.
 *
 * @param isChecked - boolean value for the checkbox of Quality Ranking Factor
 */
function controlQalityRankingFactorJustifyGroup(){
	var isChecked = $("#JA_QUAL_RANK_REQ").prop("checked");
	if (isChecked) {
		$("#ja_qual_rank_just_group").show();
	} else {
		$("#ja_qual_rank_just_group").hide();
		$("#JA_QUAL_RANK_JUST").val("");  // when hiding, clear field values, too
	}
}

/**
 * Controls show/hide of Justify textbox associated with Multiple Types of Assessment checkbox.
 *
 * @param isChecked - boolean value for the checkbox of Multiple Types of Assessment
 */
function controlMultiTypeAssessGroup(){
	var isChecked = $("#JA_RESPONSES_REQ").prop("checked");
	if (isChecked) {
		$("#assess_qtype_group").show();
	} else {
		$("#assess_qtype_group").hide();
		// clear child checkbox upon unchecking parent
		$("#JA_TYPE_YES_NO").prop("checked", false);
		$("#JA_TYPE_REQ_DEFAULT").prop("checked", false);
		$("#JA_TYPE_KNOWL_SCALE").prop("checked", false);
	}
}

// // This method/function shows an alert and clears the
// // text due to invalid values
// function  showAlert($this, id, msg) {
// 	var pos = $this.position();
// 	$("#" + id).remove();
// 	$this.after("<span id='" + id + "' class='limitAlert' role='alert'>" + msg + "</span>");
// 	$("#" + id).css({top: pos.top + 20, left: pos.left + 30, position:'absolute'});
// 	setTimeout(function() {
// 		$("#" + id).remove();
// 	}, 2000);
// }

function initJAAutoComplete() {
	var jobAnalysisOption = {
		id: 'SME_JA_INPUT',
		targetURL: 'SearchPeopleNameEmail.do',
		targetParam: 'searchString',
		minLength: 2,
		minSelectionCount: 1,
		maxSelectionCount: 1,

		mapFunction: function(context) {
			return {
				id: $( "MID", context ).text(),
				name: $( "DSPNAME", context ).text(),
				deptname: $( "DEPTNAME", context ).text(),
				email: $( "EMAIL", context ).text()
			};            
		},
		getSelectionLabel: function(item) {
			return item.name + ' ' + (item.email != null && item.email.length > 0 ? '(' + item.email + ')' : '')
		},
		getCandidateLabel: function(item) {
			return item.name + ' ' + (item.email != null && item.email.length > 0 ? '(' + item.email + ')' : '')
		},
		getItemID: function(item) {
			return 'smeJAExpert'
		},
		initialItems: [],
		setDataToForm: function(values) {
			var name = '';
			var email = '';
			if (values && values.length > 0) {
				name = values[0].name;
				email = values[0].email;
			}
			$('#SME_NAME_JA').val(name);
			$('#SME_EMAIL_JA').val(email);
		}
	}

	var smeJAName = $('#SME_NAME_JA').val();
	if (smeJAName.length > 0) {
		jobAnalysisOption.initialItems.push({
			id: 'smeJAExpert',
			name: $('#SME_NAME_JA').val(),
			deptname: '',
			email: $('#SME_EMAIL_JA').val()
		});
	}
	var jobAnalysisAC = initAutoCompletion(jobAnalysisOption);       	
}

function initQual1AutoComplete() {
	var qualificationSMEOption = {
		id: 'SME_QUAL_1_INPUT',
		targetURL: 'SearchPeopleNameEmail.do',
		targetParam: 'searchString',
		minLength: 2,
		minSelectionCount: 1,
		maxSelectionCount: 2,

		mapFunction: function(context) {
			return {
				name: $( "DSPNAME", context ).text(),
				email: $( "EMAIL", context ).text()
			};            
		},
		getSelectionLabel: function(item) {
			return item.name + ' ' + (item.email != null && item.email.length > 0 ? '(' + item.email + ')' : '')
		},
		getCandidateLabel: function(item) {
			return item.name + ' ' + (item.email != null && item.email.length > 0 ? '(' + item.email + ')' : '')
		},
		getItemID: function(item) {
			return item.email.replace('@','_');
		},
		initialItems: [],
		setDataToForm: function(values) {
			var name1 = '', name2 = '', email1 = '', email2 = '';

			var count = values.length;
			if (count >= 1) {
				name1 = values[0].name;
				email1 = values[0].email;
			}

			if (count >= 2) {
				name2 = values[1].name;
				email2 = values[1].email;
			}

			$('#SME_NAME_QUAL_1').val(name1);
			$('#SME_EMAIL_QUAL_1').val(email1);
			$('#SME_NAME_QUAL_2').val(name2);
			$('#SME_EMAIL_QUAL_2').val(email2);
		}
	}

	var name1 = $('#SME_NAME_QUAL_1').val();
	if (name1.length > 0) {
		var email1 = $('#SME_EMAIL_QUAL_1').val();
		qualificationSMEOption.initialItems.push({name: name1, email: email1});
	}
	var name2 = $('#SME_NAME_QUAL_2').val();
	if (name2.length > 0) {
		var email2 = $('#SME_EMAIL_QUAL_2').val();
		qualificationSMEOption.initialItems.push({name: name2, email: email2});
	}

	var qualificationSMEAC = initAutoCompletion(qualificationSMEOption);   	
}


/**
 * onload handler for SME/JA tab page
 */
function initSmeJaTab() {
	// Show Justify field for Selective Factor only the associated checkbox is checked
	$("#JA_SEL_FACTOR_REQ").change(function() {
		controlSelectiveFactorJustifyGroup();
	});
	// Show Name/Email fields for SME only if the associated Job Analysis checkbox is checked
	$("#SME_FOR_JOB_ANALYSIS").change(function() {
		controlSmeForJAGroup();
	});
	// Show Name/Email fields for SME only if the associated Qualification checkbox is checked
	$("#SME_FOR_QUALIFICATION").change(function() {
		controlSmeForQualGroup();
	});
	// Show Justify field for Quality Ranking Factor only the associated checkbox is checked.
	$("#JA_QUAL_RANK_REQ").change(function() {
		controlQalityRankingFactorJustifyGroup();
	});
	// Show checkboxes under subgroup for Multiple Types of Assessment only when the parent checkbox is checked.
	$("#JA_RESPONSES_REQ").change(function() {
		controlMultiTypeAssessGroup();
	});
	$("#POS_PAY_PLAN").on("change", function(e) {
		controlSelectiveFactorGroup(e);
	});
	$("#POS_SERIES").on("change", function(e) {
		controlSelectiveFactorGroup(e);
	});	

	var posSeriesValSel = $("#POS_SERIES option:selected").val();
	var posPayPlanValSel = $("#POS_PAY_PLAN option:selected").val();
	if (posPayPlanValSel == "GS" && posSeriesValSel == "0602") {
		// for GS-0602, automatically check Selective Factor checkbox
		$("#JA_SEL_FACTOR_REQ").prop("checked", true);
		$('#JA_SEL_FACTOR_REQ').attr('disabled','disabled');
		$('#JA_SEL_FACTOR_JUST').val('');
		$("#ja_sel_just_group").hide();
		$("#sel_fac_note_group").show();

		var width = $(window).width();
		$('div.cmsNoteChildWidth').parent().attr('style','width:' + width * 0.80 + 'px');
	} else {
		// for non-GS-0602, clear/hide
		$("#sel_fac_note_group").hide();  // hide note for GS-0602
		$('div.cmsNoteChildWidth').parent().attr('style','display:none');
		// $("#JA_SEL_FACTOR_REQ").trigger("change");		
		controlSelectiveFactorJustifyGroup();		
	}			

	controlSmeForJAGroup();
	controlSmeForQualGroup();
	controlSelectiveFactorGroup();
	controlSelectiveFactorJustifyGroup();
	controlQalityRankingFactorJustifyGroup();
	controlMultiTypeAssessGroup();

	var posSeriesValSel = $("#POS_SERIES option:selected").val();
	var posPayPlanValSel = $("#POS_PAY_PLAN option:selected").val();
	if (posPayPlanValSel == "GS" && posSeriesValSel == "0602") {
		// for GS-0602, automatically check Selective Factor checkbox
		$("#JA_SEL_FACTOR_REQ").prop("checked", true);
		$('#JA_SEL_FACTOR_REQ').attr('disabled','disabled');
		$('#JA_SEL_FACTOR_JUST').val('');
		$("#ja_sel_just_group").hide();
		$("#sel_fac_note_group").show();

		var width = $(window).width();
		$('div.cmsNoteChildWidth').parent().attr('style','width:' + width * 0.80 + 'px');
	} else {
		// for non-GS-0602, clear/hide
		$("#sel_fac_note_group").hide();  // hide note for GS-0602
		$('div.cmsNoteChildWidth').parent().attr('style','display:none');
		// $("#JA_SEL_FACTOR_REQ").trigger("change");	
		controlSelectiveFactorJustifyGroup();			
	}
	initJAAutoComplete();
	initQual1AutoComplete();
} // end initSmeJaTab()