var stratConGEN = {
    initAutoCompletion: function() {
        var adminCodeOption = {
            id: 'SG_ADMIN_CD_INPUT',
            minLength: 2,
            targetURL: 'SearchAdmOffOrg.do',
            targetParam: 'searchAdminCode',
            mapFunction: function(context) {
                return { code: $( "CODE", context ).text(), name: $( "NAME", context ).text() }
            },
            getSelectionLabel: function(item) {
                return item.code;
            },
            getCandidateLabel: function(item) {
                return item.code + ' - ' + item.name;
            },
            getItemID: function(item) {
                return item.code;
            },
            setDataToForm: function(values) {
                var code = "";
                if (values && values.length > 0) {
                    code = values[0].code;
                }
                $('#SG_ADMIN_CD').val(code);
            },
            initialItems: [{
                code: $('#AC_ADMIN_CD').val(),
                name:$('#AC_ADMIN_CD_DESCR').val()
            }]
        }    
        var adminCodeAC = initAutoCompletion(adminCodeOption);

        var orgOption = {
            id: 'SG_ORG_NAME',
            minLength: 2,
            targetURL: 'SearchAdmOffOrg.do',
            targetParam: 'searchOrgName',
            mapFunction: function(context) {
                return { code: $( "CODE", context ).text(), name: $( "NAME", context ).text() }
            },
            getSelectionLabel: function(item) {
                return item.name;
            },
            getCandidateLabel: function(item) {
                return item.name + ' - ' + item.code;
            },
            getItemID: function(item) {
                return item.code;
            },
            postSelect: function(event, ui, selectedValues) {
                adminCodeAC.select(event, ui);
            },
            postDelete: function(e, selectedValues) {
                adminCodeAC.deleteItem(e);
            },
            setDataToForm: function(values) {
                var code = "";
                if (values && values.length > 0) {
                    code = values[0].code;
                }
                $('#SG_ADMIN_CD').val(code);
            },
            initialItems: [{
                code: $('#AC_ADMIN_CD').val(),
                name:$('#AC_ADMIN_CD_DESCR').val()
            }]
        }
        var orgNameAC = initAutoCompletion(orgOption);
        adminCodeAC.option.postSelect = function(event, ui, selectedValues) {
            orgNameAC.select(event, ui);
        }
        adminCodeAC.option.postDelete = function(e, selectedValues) {
            orgNameAC.deleteItem(e);
        }

        var certInitialData = [];
        if ($('#OTHER_CERT_DATA option').length != 0) {
            $('#OTHER_CERT_DATA option').each(function(){
                var id = $(this).val();
                var otherCertData = $(this).text(); // Peter Lee_/~peter@bizflow.com
                var items = otherCertData.split('_/~')
                certInitialData.push({id: id, name: items[0], email: items[1]})
            });
        }

        var certOption = {
            id: 'certSearch',
            targetURL: 'SearchPeopleNameEmail.do',
            targetParam: 'searchString',
            minLength: 2,
            minSelectionCount: 1,
            maxSelectionCount: 13,
            mapFunction: function(context) {
                return {
                    name: $( "DSPNAME", context ).text(),
                    id: $( "MID", context ).text(),
                    email: $( "EMAIL", context ).text()
                };            
            },
            getSelectionLabel: function(item) {
                return item.name + (item.email != null && item.email.length > 0 ? ' (' + item.email + ')' : '')
            },
            getCandidateLabel: function(item) {
                return item.name + (item.email != null && item.email.length > 0 ? ' (' + item.email + ')' : '')
            },
            getItemID: function(item) {
                return item.id;
            },
            setDataToForm: function(values) {
                var IDs = "";
                if (values) {
                    var count = values.length;
                    for (var index = 0; index < count; index++) {
                        if (index != 0) {
                            IDs += ',';
                        }
                        IDs += values[index].id;
                    }
                }
                $('#SG_OTHER_CERT').val(IDs);
            },
            initialItems: certInitialData
        }
        var certAC = initAutoCompletion(certOption);
    },
    showHideAppointmentType: function() {
        var requestType = $('#SG_RT_ID :selected').text();
        if (requestType == 'Appointment') {
            // SHOW
            hyf.util.showComponent('layout_group_AT', null, null, null);
            
            stratConGEN.changeAppointmentType();
        } else {
            // HIDE
            $('#SG_AT_ID').val('');
            $('#SG_SAT_ID').val('');
            hyf.util.hideComponent('layout_group_AT', null, null, null);
        }
    },
    showHideClassificationType: function() {
        var requestType = $('#SG_RT_ID :selected').text();
        var appointmentType = $('#SG_AT_ID :selected').text();
    
        if (requestType != 'Appointment'
            || (appointmentType != 'Volunteer'
                && appointmentType != 'Intergovernmental Personnel Act (IPA)')
                && appointmentType != 'Expert/Consultant') {
            hyf.util.showComponent('layout_group_CT', null, null, null);
            hyf.util.showComponent('layout_group_classSpecialist', null, null, null);
        } else {
            $('#SG_CT_ID').val('');
            $('#SG_CS_ID').val('');
            hyf.util.hideComponent('layout_group_CT', null, null, null);
            hyf.util.hideComponent('layout_group_classSpecialist', null, null, null);
        }
    },
    showHideStaffSpecialistGroup: function() {
        var isSpecial = StratConMAIN.isSpecialProgram();
        if (isSpecial == true) {
            var targetActivities = ['Hold Strategic Consultation Meeting', 'Acknowledge Strat Cons Meeting', 'Approve Strat Cons Meeting'];
            var activityName = BFActivityOption.getActivityName();
            var foundActivity = CMSUtility.existInArray(targetActivities, activityName);
    
            hyf.util.disableComponent('SG_SS_ID');
            $('#SG_SS_ID').attr('donotsubmit', 'true');
    
            hyf.util.enableComponent('SG_SP_ID');
            $('#SG_SP_ID').removeAttr('donotsubmit');
    
            hyf.util.hideComponent('layout_group_staffspecialist', null, null, null);
            if (foundActivity == true) {
                hyf.util.showComponent('layout_group_specialProgram', null, null, null);
            } else {
                var specialUserGroupMemberID = StratConMAIN.getUserGroupMemberID('HR Special Programs');
    
                var alreadyAddedSpecialPrograms = false;
                $.each($('#SG_SP_ID option'), function(index, component) {
                    var value = $(this).attr('value');
                    if (value == specialUserGroupMemberID) {
                        alreadyAddedSpecialPrograms = true;
                    }
                });
    
                if (alreadyAddedSpecialPrograms == false) {
                    $('#SG_SP_ID').append('<option value="' + specialUserGroupMemberID + '">HR Special Programs</option>');
                }
                $('#SG_SP_ID').val(specialUserGroupMemberID);
                hyf.util.hideComponent('layout_group_specialProgram', null, null, null);
            }
            $('#pv_specialProgram').val('Yes');
        } else {
            hyf.util.disableComponent('SG_SP_ID');
            $('#SG_SP_ID').attr('donotsubmit', 'true');
    
            hyf.util.enableComponent('SG_SS_ID');
            $('#SG_SS_ID').removeAttr('donotsubmit');
    
            var requestType = $('#SG_RT_ID :selected').text();
            if (requestType == 'Classification Only') {
                $('#SG_SS_ID').val('');
                hyf.util.hideComponent('layout_group_staffspecialist', null, null, null);
            } else if (requestType == 'Recruitment') {
                hyf.util.showComponent('layout_group_staffspecialist', null, null, null);
            } else if (requestType == 'Appointment') {
                var appointmentType = $('#SG_AT_ID :selected').text(); // HRB-1654
                if (appointmentType == 'Intergovernmental Personnel Act (IPA)') {
                    $('#SG_SS_ID').val('');
                    hyf.util.hideComponent('layout_group_staffspecialist', null, null, null);
                } else {
                    hyf.util.showComponent('layout_group_staffspecialist', null, null, null);
                }
            } else {
                hyf.util.showComponent('layout_group_staffspecialist', null, null, null);
            }
            hyf.util.hideComponent('layout_group_specialProgram', null, null, null);
            $('#pv_specialProgram').val('No');
        }
    
        $(document).trigger('SG_SPECIAL_PROGRAM_CHANGED');
    },
    // Change button label (Default - Notify Meeting Attendees) based on Request Type & Classification Type
    setNotifyMeetingButtonLabel: function() {
        var buttonIDs = ['button_cr_notify_2', 'button_rr_notify_2', 'button_mr_notify_2', 'button_escr_notify_2'];
        var disableButtonIDs = ['button_cr_send_2', 'button_escr_send_2'];
        var requestType = $('#SG_RT_ID :selected').text();

        if (requestType == 'Appointment') {
            var appointmentType = $('#SG_AT_ID :selected').text();
            if (appointmentType == 'Volunteer') {
                buttonIDs.forEach(function(id) {
                    $('#' + id).val('Notify Special Programs');
                    CMSUtility.enableComponents(buttonIDs);
                    CMSUtility.disableComponents(disableButtonIDs);
                });
                $('#pv_meetingResched').val('No');
            } else {
                var targetClassificationTypes = ['Conduct 5-year Recertification', 'Update Coversheet', 'Review Existing Position Description'];
                var classificationType = $('#SG_CT_ID :selected').text();
                var foundClassificationType = CMSUtility.existInArray(targetClassificationTypes, classificationType);

                var targetAppointmentTypes = ['Intergovernmental Personnel Act (IPA)', 'Expert/Consultant'];
                var foundAppointmentType = CMSUtility.existInArray(targetAppointmentTypes, appointmentType);

                if (foundClassificationType == true || foundAppointmentType == true) {
                    buttonIDs.forEach(function(id) {
                        $('#' + id).val('Notify HR');
                        $('#pv_meetingRequired').val('No');
                        $('#pv_meetingResched').val('No');
                        CMSUtility.enableComponents(buttonIDs);
                        CMSUtility.disableComponents(disableButtonIDs);
                    });
                } else {
                    buttonIDs.forEach(function(id) {
                        $('#' + id).val('Notify Meeting Attendees');
                        $('#pv_meetingRequired').val('Yes');
                        TabManager.tabList[2].eventHandler.changeOnSSHMeetingSchedDT();

                        CMSUtility.disableComponents(buttonIDs);
                        CMSUtility.enableComponents(disableButtonIDs);
                    });
                }
            }
        } else {
            buttonIDs.forEach(function(id) {
                $('#' + id).val('Notify Meeting Attendees');
                TabManager.tabList[2].eventHandler.changeOnSSHMeetingSchedDT();
            });
        }
    },

    changeSelectingOfficial: function(e) {
        CMSUtility.debugLog('stratConGEN.changeSelectingOfficial START');
        var value = $('#SG_SO_ID').val();
        $('#selecting_official_titleorg').val(value)
        var titleOrg = $('#selecting_official_titleorg option:selected').text().split('~/_');
        $('#SG_SO_TITLE').val('');
        $('#SG_SO_ORG').val('');
        $('#selecting_official_detail').html('');
        if (titleOrg.length > 1) {
            $('#selecting_official_detail_container').show();
            $('#selecting_official_detail_label').show();
            $('#SG_SO_TITLE').val(titleOrg[0]);
            $('#SG_SO_ORG').val(titleOrg[1]);
            $('#selecting_official_detail').html(titleOrg[0] + '/' + titleOrg[1]);
        } else {
            $('#selecting_official_detail_container').hide();
            $('#selecting_official_detail_label').hide();
        }
        CMSUtility.debugLog('stratConGEN.changeSelectingOfficial END');
    },
    changeExecutiveOfficer: function(e) {
        CMSUtility.debugLog('stratConGEN.changeExecutiveOfficer START');
        var value = $('#SG_XO_ID').val();
        $('#executive_office_titleorg').val(value)
        var titleOrg = $('#executive_office_titleorg option:selected').text().split('~/_');
        $('#SG_XO_TITLE').val('');
        $('#SG_XO_ORG').val('');
        $('#executive_office_detail').html('');
        if (titleOrg.length > 1) {
            $('#executive_office_detail_container').show();
            $('#executive_office_detail_label').show();
            $('#SG_XO_TITLE').val(titleOrg[0]);
            $('#SG_XO_ORG').val(titleOrg[1]);
            $('#executive_office_detail').html(titleOrg[0] + '/' + titleOrg[1]);
        } else {
            $('#executive_office_detail_container').hide();
            $('#executive_office_detail_label').hide();
        }
        CMSUtility.debugLog('stratConGEN.changeExecutiveOfficer END');
    },
    changeHRLiaison: function(e) {
        CMSUtility.debugLog('stratConGEN.changeHRLiaison START');
        var value = $('#SG_HRL_ID').val();
        $('#hr_liaison_titleorg').val(value);
        var titleOrg = $('#hr_liaison_titleorg option:selected').text().split('~/_');
        $('#SG_HRL_TITLE').val('');
        $('#SG_HRL_ORG').val('');
        $('#hr_liaison_detail').html('');
        if(titleOrg.length > 1){
            $('#hr_liaison_detail_container').show();
            $('#hr_liaison_detail_label').show();
            $('#SG_HRL_TITLE').val(titleOrg[0]);
            $('#SG_HRL_ORG').val(titleOrg[1]);
            $('#hr_liaison_detail').html(titleOrg[0] + '/' + titleOrg[1]);
        } else {
            $('#hr_liaison_detail_container').hide();
            $('#hr_liaison_detail_label').hide();
        }
        CMSUtility.debugLog('stratConGEN.changeHRLiaison END');
    },
    changeStaffSpecialist: function(e) {
        CMSUtility.debugLog('stratConGEN.changeStaffSpecialist START');
        var value = $('#SG_SS_ID').val();
        $('#hr_staffing_specialist_titleorg').val(value)
        $('#hr_staffing_specialist_detail').html($('#hr_staffing_specialist_titleorg option:selected').text());
        CMSUtility.debugLog('stratConGEN.changeStaffSpecialist END');
    },
    changeClassSpecialist: function(e) {
        CMSUtility.debugLog('stratConGEN.changeClassSpecialist START');
        var value = $('#SG_CS_ID').val();
        $('#hr_classification_specialist_titleorg').val(value);
        $('#hr_classification_specialist_detail').html($('#hr_classification_specialist_titleorg option:selected').text());
        CMSUtility.debugLog('stratConGEN.changeClassSpecialist END');
    },
    changeAppointmentType: function() {
        CMSUtility.debugLog('stratConGEN.changeAppointmentType START');
        var requestType = $('#SG_RT_ID :selected').text();
        var appointmentType = $('#SG_AT_ID :selected').text();

        if (requestType == 'Appointment' && appointmentType == 'Schedule A') {
            $('#SG_VT_ID').val('');
            hyf.util.showComponent('layout_group_SAT', null, null, null);
            hyf.util.hideComponent('layout_group_VOL', null, null, null);
        } else if (requestType == 'Appointment' && appointmentType == 'Volunteer') {
            $('#SG_SAT_ID').val('');
            hyf.util.hideComponent('layout_group_SAT', null, null, null);
            hyf.util.showComponent('layout_group_VOL', null, null, null);
        } else {
            $('#SG_VT_ID').val('');
            $('#SG_SAT_ID').val('');
            hyf.util.hideComponent('layout_group_SAT', null, null, null);
            hyf.util.hideComponent('layout_group_VOL', null, null, null);
        }

        stratConGEN.showHideClassificationType();
        stratConGEN.showHideStaffSpecialistGroup();
        // stratConPOS.showHideFieldsBasedOnContext();
        StratConMAIN.showHideTabsUponRequestType();
        stratConGEN.setNotifyMeetingButtonLabel();

        // Notify document tab so that it can retrieve new document types and mandatory documents.
        $(document).trigger('ON_DOCUMENT_CHANGE');

        CMSUtility.debugLog('stratConGEN.changeAppointmentType END');
    },
    changeRequestType: function(e) {
        CMSUtility.debugLog('stratConGEN.changeRequestType START');
        var preselect = $('#SG_CT_ID').val();
        $('#SG_CT_ID').empty();

        var requestTypeValue = $('#SG_RT_ID').val();
        var requestType = $('#SG_RT_ID :selected').text();

        var requestLookup = LookupManager.findByLTYPE('RequestType[' + requestType + ']');
        if (requestLookup.length == 1) {
            var types = requestLookup[0].children;
            var count = types.length;

            for (var index = 0; index < count; index++) {
                $('#SG_CT_ID').append('<option value="' + types[index].ID + '">' + types[index].NAME + '</option');
            }
        }
 
        if (preselect !== undefined) {
            $('#SG_CT_ID').val(preselect);
        }
        hyf.util.hideComponent('layout_group_so_agree', null, null, null);

        if (requestType != null && requestType.length > 0) {
            requestType = requestType.toLowerCase();
        }

        if (requestType != 'recruitment') {
            hyf.util.hideComponent('COMMISSIONED_NOTE', null, null, null);
            $('#OTHER_CERT_DIV').addClass('hidden');
            $('#certSearch_display').empty();
            $('#SG_OTHER_CERT').val('');
        } else {
            $('#OTHER_CERT_DIV').removeClass('hidden');

            var isSelectingOfficial = StratConMAIN.isCurrentUserMemberOf('Selecting Officials');
            if (isSelectingOfficial == true) {
                hyf.util.showComponent('layout_group_so_agree', null, null, null);
            }
            hyf.util.showComponent('COMMISSIONED_NOTE', null, null, null);
        }
        stratConGEN.showHideClassificationType();
        stratConGEN.showHideAppointmentType();
        stratConGEN.showHideStaffSpecialistGroup();
        // stratConPOS.showHideAppointmentFields();
        // stratConPOS.showHideFieldsBasedOnContext();
        // Notify document tab so that it can retrieve new document types and mandatory documents.
        $(document).trigger('ON_DOCUMENT_CHANGE');
        StratConMAIN.showHideTabsUponRequestType(); // Function from StratConMain.js
        stratConGEN.setNotifyMeetingButtonLabel();

        CMSUtility.debugLog('stratConGEN.changeRequestType END');
    },
    changeClassificationType: function() {
        CMSUtility.debugLog('stratConGEN.changeClassificationType START');
        // Notify document tab so that it can retrieve new document types and mandatory documents.
        $(document).trigger('ON_DOCUMENT_CHANGE');
        StratConMAIN.showHideTabsUponRequestType();
        stratConGEN.setNotifyMeetingButtonLabel();
        CMSUtility.debugLog('stratConGEN.changeClassificationType END');
    },
    changeVolunteerType: function() {
        CMSUtility.debugLog('stratConGEN.changeVolunteerType START');
        // Notify document tab so that it can retrieve new document types and mandatory documents.
        $(document).trigger('ON_DOCUMENT_CHANGE');
        CMSUtility.debugLog('stratConGEN.changeVolunteerType END');
    },

    init: function() {
        CMSUtility.debugLog('STRATCON_GEN - stratConGEN.init START');

        $('#SG_SO_ID').on('change', stratConGEN.changeSelectingOfficial);
        $('#SG_XO_ID').on('change',stratConGEN.changeExecutiveOfficer);
        $('#SG_HRL_ID').append($('<option/>', { value: '', text: 'N/A'}));
        $('#SG_HRL_ID').on('change', stratConGEN.changeHRLiaison);
        $('#SG_SS_ID').on('change', stratConGEN.changeStaffSpecialist);
        $('#SG_CS_ID').on('change', stratConGEN.changeClassSpecialist);
        $('#SG_AT_ID').on('change', stratConGEN.changeAppointmentType);
        $('#SG_CT_ID').on('change', stratConGEN.changeClassificationType);
        $('#SG_RT_ID').on('change', stratConGEN.changeRequestType);
        $('#SG_VT_ID').on('change', stratConGEN.changeVolunteerType);

        // Initialization
        stratConGEN.changeSelectingOfficial()
        stratConGEN.changeExecutiveOfficer();
        stratConGEN.changeHRLiaison();
        stratConGEN.changeRequestType();
        stratConGEN.changeAppointmentType();
        stratConGEN.initAutoCompletion();

        CMSUtility.debugLog('STRATCON_GEN - stratConGEN.init END');
    }
}
