var ACTNAME_CREATEREQUEST  = "Create Request"
var ACTNAME_REVIEWREQUEST  = "Review Request"
var ACTNAME_MODIFYREQUEST  = "Modify Request"
var ACTNAME_HOLDMEETING    = "Hold Strategic Consultation Meeting"
var ACTNAME_ACKMEETING     = "Acknowledge Strat Cons Meeting"
var ACTNAME_APPROVEMEETING = "Approve Strat Cons Meeting"

// Required javascript files
//  lookupManager.js
var BFActivityOption = {
    _activityName: null,
    _currentActivity: null,
    _currentTabs: null,
    _activityName: null,

    getActivityName: function() {
        if (BFActivityOption._activityName == null) {
            BFActivityOption._activityName = $('#h_activityName').val();
            if (BFActivityOption._activityName == null || BFActivityOption._activityName.length == 0) {
                CMSUtility.debugLog('STRATCONMAIN - BFActivityOption.getActivityName() - ActivityName is null or empty.');
            } else {
                $('#h_activityName').val('');
            }
        }
        return BFActivityOption._activityName;
    },
    getCurrentActivityOption: function(activityName) {
        if (activityName != this._activityName) {
            this._currentActivity = null;
            this._currentTabs = null;
            this._activityName = activityName;
        }

        if (this._currentActivity == null) {
            if (activityName == null || activityName.length == 0) {
                activityName = "_Archive_";
            }

            // Find current activity name and tab information associated with current activity name
            var currentActList = [];
            currentActList = BFActivityOption.actList.filter(function(node, index) {
                var memberCount = 0;
                if (node.usergroup.length > 0) {
                    node.usergroup.forEach(function(group) {
                        if (StratConMAIN.isCurrentUserMemberOf(group) == true) {
                            memberCount++;
                        }
                    })
                }
                return node.name == activityName && (memberCount == node.usergroup.length || memberCount > 0);
            });
            // If current activity is not in the BFActivityOption, add _Archive_ configuration
            if (currentActList.length == 0) {
                currentActList.push(BFActivityOption.actList[BFActivityOption.actList.length - 1]);
            }
            this._currentActivity = currentActList[0];
            this._currentTabs = this._currentActivity.tabs.slice();
        }
        return this._currentActivity;
    },
    getActiveTabList: function(activityName) {
        if (this._currentTabs == null) {
            var activityOption = this.getCurrentActivityOption(activityName);
        }
        return this._currentTabs;
    },
    addTabToCurrentActivity: function(activityName, tabID) {
        if (this._currentTabs != null) {
            for (var index = 0; index < this._currentTabs.length; index++) {
                if (this._currentTabs[index] == tabID) {
                    return; // Already exists.
                }
            }
            for (var index = 0; index < this._currentTabs.length; index++) {
                if (this._currentTabs[index] > tabID) {
                    this._currentTabs.splice(index, 0, tabID);
                    break;
                }
            }
        }
    },
    removeTabFromCurrentActivity: function(activityName, tabID) {
        if (this._currentTabs != null) {
            for (var index = 0; index < this._currentTabs.length; index++) {
                if (this._currentTabs[index] == tabID) {
                    this._currentTabs.splice(index, 1);
                    break;
                }
            }
        }
    },
    getCurrentTabID: function() {
        var currentTabs = $('#tab_control_container a.selectedTab');
        var tabCount = currentTabs.length;

        if (currentTabs.length > 0) {
            var tabAnchorID = currentTabs[0].attributes["id"].value;
            var tabID = CMSUtility.getTabIDFromAnchorID(tabAnchorID);
            return tabID;
        }
        return null;
    },
    getNextTabID: function(currentTabID) {
        if (this._currentTabs != null) {
            for (var index = 0; index < this._currentTabs.length; index++) {
                if (this._currentTabs[index] == currentTabID) {
                    if (index < this._currentTabs.length - 1) {
                        return this._currentTabs[index + 1];
                    }
                }
            }
        }
        return null;
    },
    getPreviousTabID: function(currentTabID) {
        if (this._currentTabs != null) {
            for (var index = 0; index < this._currentTabs.length; index++) {
                if (this._currentTabs[index] == currentTabID) {
                    if (index > 0) {
                        return this._currentTabs[index - 1];
                    }
                }
            }
        }
        return null;
    },
    actList: [{
            name: ACTNAME_CREATEREQUEST,
            usergroup: [],
            tabs: ["tab1", "tab2", "tab3", "tab9", "tab10"],
            readonly: []
        },{
            name: ACTNAME_REVIEWREQUEST,
            usergroup: [],
            tabs: ["tab1", "tab2", "tab3", "tab9", "tab10"],
            readonly: []
        }, {
            name: ACTNAME_MODIFYREQUEST,
            usergroup: [],
            tabs: ["tab1", "tab2", "tab3", "tab9", "tab10"],
            readonly: []
        }, {
            name: ACTNAME_HOLDMEETING,
            usergroup: [],
            tabs: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab9", "tab10"],
            readonly: []
        }, {
            name: ACTNAME_ACKMEETING,
            usergroup: [],
            tabs: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab8", "tab9", "tab10"],
            readonly: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab9", "tab10"]
        }, {
            name: ACTNAME_APPROVEMEETING,
            usergroup: [],
            tabs: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab8", "tab9", "tab10"],
            readonly: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab9", "tab10"]
        }, {
            name: "_Archive_",
            usergroup: [],
            tabs: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab8", "tab9", "tab10"],
            readonly: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6", "tab7", "tab8", "tab9", "tab10"]
        }
    ]
};

var ActionButtonManager = new function() {
    var activityName = '';
    var activityButtons = [];
    var readOnly = false;

    var buttons = {
        'button_notify':              {visible: false, enabled: false, label: "Notify Meeting Attendees",    id: 'button_notify'},
        'button_sendToSO':            {visible: false, enabled: false, label: 'Send to Selecting Official',   id: 'button_sendToSO'},
        'button_acknowledge':         {visible: false, enabled: false, label: 'Send For Approval',           id: 'button_acknowledge'},
        'button_returnForModification':{visible: false, enabled: false, label: 'Return for Modification',      id: 'button_returnForModification'},
        'button_modify':              {visible: false, enabled: false, label: 'Modify Worksheet',            id: 'button_modify'},
        'button_approve':             {visible: false, enabled: false, label: 'Save and Approve',            id: 'button_approve'},
        'button_returnToSO':          {visible: false, enabled: false, label: 'Return to Selecting Official', id: 'button_returnToSO'},
        'button_CancelWorkitem':      {visible: true,  enabled: true,  label: 'Cancel Request',              id: 'button_CancelWorkitem'},
        'button_SaveWorkitem':        {visible: true,  enabled: true,  label: 'Save',                        id: 'button_SaveWorkitem'},
        'button_ExitWIH':             {visible: true,  enabled: true,  label: 'Exit',                        id: 'button_ExitWIH'}
    }
    
    var resetButtons = function() {
        for (var index = 0; index < activityButtons.length; index++) {
            var buttonID = activityButtons[index];
            if (buttons[buttonID].visible == true) {
                $('#' + buttonID).val(buttons[buttonID].label);
                hyf.util.showComponent(buttonID + '_group');
                // $('#' + buttonID + '_group').show();

                if (buttons[buttonID].enabled == true && CMSUtility.isReadOnly() == false) {
                    hyf.util.enableComponent(buttonID);
                } else {
                    hyf.util.disableComponent(buttonID);
                }
            } else {
                hyf.util.hideComponent(buttonID + '_group');
                // $('#' + buttonID + '_group').hide();
            }
        }
    };

    var hideAllButtons = function() {
        for (button in buttons) {
            if (buttons.hasOwnProperty(button) == true) {
                hyf.util.hideComponent(button + '_group');
            }
        }
    }

    var setNotifyButtonLabel = function(buttonID, requestType, appointmentType, isMeetingTabRequired) {
        if (requestType == 'Appointment') {
            if (appointmentType == 'Volunteer') {
                buttons[buttonID].label = 'Notify Special Programs';
            } else if (appointmentType == 'Expert/Consultant') {
                buttons[buttonID].label = 'Notify HR';
            } else {
                if (isMeetingTabRequired == false) {
                    buttons[buttonID].label = 'Notify HR';
                }
            }
        }
    }

    var isSpecialProgramChanged = function() {
        var isSpecialProgram = CMSUtility.isSpecialProgram('SG_RT_ID', 'SG_AT_ID');
        var previousProgram = $('#h_prevSpecialProgram').val();
        return (isSpecialProgram == true && previousProgram == 'No') || (isSpecialProgram == false && previousProgram == 'Yes');
    }

    var isModificationRequested = function() {
        var modificationRequestedStaff = $('#pv_returnToSOFromStaffSpec').val();
        var modificationRequestedClass = $('#pv_returnToSOFromClassSpec').val();
        var isClassificationSpecialist = StratConMAIN.isCurrentUserMemberOf('HR Classification Specialists');
        var isStaffingSpecialist = StratConMAIN.isCurrentUserMemberOf('HR Staffing Specialists');
        var isSpecialProgramSpecialist = StratConMAIN.isCurrentUserMemberOf('HR Special Programs');
        var modificationRequested = false;
        
        if ((isClassificationSpecialist === true && modificationRequestedClass === 'Updating') || 
            ((isStaffingSpecialist === true || isSpecialProgramSpecialist === true ) && modificationRequestedStaff === 'Updating')) {
            modificationRequested = true;
        }
        return modificationRequested;        
    }

    // Controls button behavior based on Activity and Situation
    var showHideActionButtons = function() {
        var isMeetingTabRequired = CMSUtility.isMeetingTabRequired();
        var meetingDate = $('#SSH_MEETING_SCHED_DT').val();
        var isMeetingDateSet = (meetingDate && meetingDate.length > 0) ? true : false;
        var requestType = $('#SG_RT_ID :selected').text();
        var appointmentType = $('#SG_AT_ID :selected').text();

        if (activityName == 'Create Request') {
            var isCurrentUserSO = StratConMAIN.isCurrentUserMemberOf('Selecting Officials')
            if (isCurrentUserSO == true) {
                buttons['button_sendToSO'].visible = false;
                buttons['button_notify'].visible = true;
                buttons['button_notify'].enabled = (isMeetingTabRequired == true) ? isMeetingDateSet : true;
                buttons['button_notify'].label = 'Notify Meeting Attendees';
                setNotifyButtonLabel('button_notify', requestType, appointmentType, isMeetingTabRequired);
                
            } else {
                buttons['button_notify'].visible = false;
                buttons['button_sendToSO'].visible = true;
                buttons['button_sendToSO'].enabled = (isMeetingTabRequired == true) ? isMeetingDateSet : true;
            }

        } else if (activityName == 'Review Request') {
            buttons['button_notify'].visible = true;
            buttons['button_notify'].enabled = (isMeetingTabRequired == true) ? isMeetingDateSet : true;
            buttons['button_notify'].label = 'Notify Meeting Attendees';
            setNotifyButtonLabel('button_notify', requestType, appointmentType, isMeetingTabRequired);

        } else if (activityName == 'Modify Request') {
            var isMeetingDateChanged = $('#MEETING_DATE_CHANGED').val() == 'true';
            var specialProgramChanged = isSpecialProgramChanged();

            buttons['button_SaveWorkitem'].visible = false;
            buttons['button_notify'].visible = true;
            buttons['button_notify'].enabled = (isMeetingTabRequired == true) ? (isMeetingDateSet && (isMeetingDateChanged || specialProgramChanged)) : true;
            buttons['button_notify'].label = 'Notify Meeting Attendees';
            setNotifyButtonLabel('button_notify', requestType, appointmentType, isMeetingTabRequired);

        } else if (activityName == 'Hold Strategic Consultation Meeting') {
            var isMeetingDateChanged = $('#MEETING_DATE_CHANGED').val() == 'true';
            var specialProgramChanged = isSpecialProgramChanged();

            if (isMeetingTabRequired) {
                buttons['button_notify'].visible = true;
                buttons['button_sendToSO'].visible = true;

                if (isMeetingDateSet) {
                    if (isMeetingDateChanged || specialProgramChanged) {
                        buttons['button_notify'].enabled = true;
                        buttons['button_sendToSO'].enabled = false;
                        buttons['button_notify'].label = 'Notify Meeting Attendees';
                        setNotifyButtonLabel('button_notify', requestType, appointmentType, isMeetingTabRequired);
                    } else {
                        buttons['button_notify'].enabled = false;
                        buttons['button_sendToSO'].enabled = true;
                    }
                } else {
                    buttons['button_notify'].enabled = false;
                    buttons['button_sendToSO'].enabled = false;
                }

            } else {
                buttons['button_sendToSO'].visible = true;
                buttons['button_sendToSO'].enabled = false;
                buttons['button_notify'].visible = true;
                buttons['button_notify'].enabled = isMeetingDateSet && (isMeetingDateChanged || specialProgramChanged);;
                buttons['button_notify'].label = 'Notify Meeting Attendees';
                setNotifyButtonLabel('button_notify', requestType, appointmentType, isMeetingTabRequired);

            }

        } else if (activityName == 'Acknowledge Strat Cons Meeting') {
            buttons['button_acknowledge'].visible = true;
            buttons['button_returnForModification'].visible = true;

            var isSOAcknowledged = $('#IS_SO_ACK').prop('checked');
            if (isSOAcknowledged == true) {
                buttons['button_acknowledge'].enabled = true;
                buttons['button_returnForModification'].enabled = false;
                buttons['button_CancelWorkitem'].enabled = false;
            } else {
                buttons['button_acknowledge'].enabled = false;
                buttons['button_returnForModification'].enabled = true;
                buttons['button_CancelWorkitem'].enabled = true;
            }

        } else if (activityName == 'Approve Strat Cons Meeting') {
            buttons['button_modify'].visible = true;
            buttons['button_returnToSO'].visible = true;
            buttons['button_approve'].visible = true;

            var modificationRequested = isModificationRequested();

            if (modificationRequested == true) {
                buttons['button_modify'].enabled = false;
                buttons['button_returnToSO'].enabled = true;
                buttons['button_approve'].enabled = false;
                buttons['button_CancelWorkitem'].enabled = false;
            } else {
                var isClassificationSpecialist = StratConMAIN.isCurrentUserMemberOf('HR Classification Specialists');
                var isStaffingSpecialist = StratConMAIN.isCurrentUserMemberOf('HR Staffing Specialists');        
                var isClassSpecialistApproved = $('#IS_HR_CLS_SPC_APR').prop('checked');
                var isStaffSpecialistApproved = $('#IS_HR_STF_SPC_APR').prop('checked');

                if ((isClassificationSpecialist == true && isClassSpecialistApproved == true) || (isStaffingSpecialist == true && isStaffSpecialistApproved == true)) {
                    buttons['button_modify'].enabled = false;
                    buttons['button_returnToSO'].enabled = false;
                    buttons['button_approve'].enabled = true;
                    buttons['button_CancelWorkitem'].enabled = false;
                } else {
                    buttons['button_modify'].enabled = true;
                    buttons['button_returnToSO'].enabled = false;
                    buttons['button_approve'].enabled = false;
                    buttons['button_CancelWorkitem'].enabled = true;
                }
            }
        }

        resetButtons();
    }

    var init = function() {
        readOnly = CMSUtility.isReadOnly();
        if (readOnly == false) {
            // $('#bottomSection div.layoutContainerContent').attr('-ms-flex-preferred-size', 'auto !important')

            activityName = BFActivityOption.getActivityName();

            activityButtons.push('button_CancelWorkitem');
            activityButtons.push('button_SaveWorkitem');
            activityButtons.push('button_ExitWIH');

            if (activityName == 'Create Request') {
                activityButtons.push('button_notify');
                activityButtons.push('button_sendToSO');
            } else if (activityName == 'Review Request') {
                activityButtons.push('button_notify');
            } else if (activityName == 'Modify Request') {
                activityButtons.push('button_notify');
            } else if (activityName == 'Hold Strategic Consultation Meeting') {
                activityButtons.push('button_notify');
                activityButtons.push('button_sendToSO');
            } else if (activityName == 'Acknowledge Strat Cons Meeting') {
                activityButtons.push('button_acknowledge');
                activityButtons.push('button_returnForModification');
            } else if (activityName == 'Approve Strat Cons Meeting') {
                activityButtons.push('button_modify');
                activityButtons.push('button_approve');
                activityButtons.push('button_returnToSO');
            }

            // Register any events which affect the action button behavior.
            $('#SG_RT_ID').on('change', ActionButtonManager.showHideActionButtons);
            $('#SG_AT_ID').on('change', ActionButtonManager.showHideActionButtons);
            $('#SSH_MEETING_SCHED_DT').on('change', ActionButtonManager.showHideActionButtons);
            $('#SG_CT_ID').on('change', ActionButtonManager.showHideActionButtons);
            $('#IS_SO_ACK').on('change', ActionButtonManager.showHideActionButtons);
            $('#IS_HR_CLS_SPC_APR').on('change', ActionButtonManager.showHideActionButtons);
            $('#IS_HR_STF_SPC_APR').on('change', ActionButtonManager.showHideActionButtons);
            $(document).on('MEETING_DATE_CHANGED', ActionButtonManager.showHideActionButtons);
            $(document).on('CMS_MODIFY_WORKSHEET_FORM_ENABLED', ActionButtonManager.showHideActionButtons);

            showHideActionButtons();
        } else {
            hideAllButtons();
        }
    }

    return {
        init: init,
        showHideActionButtons: showHideActionButtons
    }
}();

// Caution: Clear dependency is important.
// TabManager can call BFActivityOption, but BFActivityOption cannot call TabManager.
var TabManager = {
    totalLoadedTabCount: 0,
    getTab: function(tabID) {
        var selectedTabs = this.tabList.filter(function(node, index) {
            return node.id == tabID;
        });
        var foundTab = null;
        if (selectedTabs.length == 1) {
            foundTab = selectedTabs[0];
        }
        return foundTab;
    },
    loadTabFromAnchor: function(node) {
        var currentTabID = BFActivityOption.getCurrentTabID();
        var tabID = CMSUtility.getTabIDFromAnchor(node);
        var tab = this.getTab(tabID);

        if (tab.disabledHeader == false) {
            if (tabID == 'tab9' || tabID == 'tab10' || TabManager.isTabCompleted(currentTabID) == true) {
                this.loadTab(tabID);
            }
        }
        // Tab click on disabled tab should be ignored.
    },
    loadTab: function(tabID) {
        var selectedTab = this.getTab(tabID)
        if (selectedTab != null) {
            if (selectedTab.loaded == false) {
                callPartialPage(null, selectedTab.targetUrl, "system", selectedTab.targetGroup);
                selectedTab.loaded = true;
            }
        }
    },
    showTabHeader: function(tabID) {
        if ($('#' + CMSUtility.getAnchorID(tabID) + ':hidden').length > 0) {
            hyf.util.showComponent("tab_control_tab_" + tabID, null, null, null);
        }
    },
    hideTabHeader: function(tabID) {
        if ($('#' + CMSUtility.getAnchorID(tabID) + ':visible').length > 0) {
            hyf.util.hideComponent("tab_control_tab_" + tabID, null, null, null);
        }
    },
    enableTab: function(tabID) {
        hyf.util.enableComponent(tabID);
        $('#' + tabID + ' img[src="/bizflowwebmaker/StratCon_AUT/custom/images/delete-icon.png"]').show();

        var disabledComponents = $('#' + tabID).find('input, select, textarea');
        $.each(disabledComponents, function(index, component) {
            var alwaysDisabled = $(component).attr('alwaysDisabled');
            var alwaysReadonly = $(component).attr('alwaysReadonly');
            var donotsubmit    = $(component).attr('donotsubmit');

            if (donotsubmit == 'true') {
                $(component).attr('disabled', true);
            }
            if (alwaysDisabled == 'true') {
                $(component).attr('disabled', true);
            }
            if (alwaysReadonly == 'true') {
                $(component).prop('readonly', 'true');
            }
        });

        if (tabID == 'tab8') {
            stratconApr_rollbackHandler();
        }
    },

    disableTab: function(tabID) {
        hyf.util.disableComponent(tabID);
        $('#' + tabID + ' img[src="/bizflowwebmaker/StratCon_AUT/custom/images/delete-icon.png"]').hide();
    },

    clearTabContent: function(tabID) {
        $.each($('#' + tabID + ' input.checkbox'), function(component) {
            var value = $(this).prop('checked');
            if (value == true) {
                $(this).prop('checked', false);
                $(this).trigger('change');
            }
        });
        $.each($('#' + tabID + ' input.textbox'), function(component) {
            var value = $(this).val();
            if (value && value.length > 0) {
                $(this).val('');
            }
        });

        // For Outreach tab
        $.each($('#' + tabID + ' input[type=checkbox]'), function(component) {
            $(this).prop('checked', false);
            var value = $(this).val();
            if (value && value.length > 0) {
                $(this).trigger('change');
            }
        });

        $.each($('#' + tabID + ' select'), function(component) {
            var value = $(this).val();
            if (value && value.length > 0) {
                $(this).val('');
                $(this).trigger('change');
            }
        });
        $.each($('#' + tabID + ' textarea'), function(component) {
            var value = $(this).val();
            if (value && value.length > 0) {
                $(this).val('');
            }
        });

        if (tabID == 'tab6') {
            $('#RI_OA_APRV_ITEM').val('NA');
        }
    },
    enableTabHeader: function(tabID) {
        var tab = this.getTab(tabID);
        if (tab != null) {
            tab.disabledHeader = false;
            var anchorID = CMSUtility.getAnchorID(tabID);
            $('#' + anchorID).removeClass('disabledTab');
            $('#' + anchorID).addClass('unselectedTab');
        } else {
            CMSUtility.debugLog('TabManager.enableTabHeader - tabID is null');
        }
    },
    disableTabHeader: function(tabID) {
        var tab = this.getTab(tabID);
        if (tab != null) {
            tab.disabledHeader = true;
            var anchorID = CMSUtility.getAnchorID(tabID);
            $('#' + anchorID).removeClass('unselectedTab');
            $('#' + anchorID).addClass('disabledTab');
        } else {
            CMSUtility.debugLog('TabManager.disableTabHeader - tabID is null');
        }
    },
    allPreviousTabCompleted: function(tabID) {
        for (var index = 0; index < this.tabList.length; index++) {
            if (this.tabList[index].id == tabID) {
                break;
            }
            if (this.tabList[index].completed == false) {
                return false;
            }
        }
        return true;
    },
    validateTab: function(tabID) {
        if (CMSUtility.isReadOnly() == false) {
            var validationResultTab7 = true;
            var validationResultTab2 = true;
            if (tabID == 'tab7') {
                validationResultTab7 = validateStratconTrCustom();
            }
            if (tabID == 'tab2') {
                //validationResultTab2 = validateStratconPOSCustom();
                validationResultTab2 = stratConPOS.validate();
            }
            var validationResult = hyf.validation.validateContainer(tabID);
            return validationResult && validationResultTab2 && validationResultTab7;
        } else {
            return true;
        }
    },
    loadNextTab: function() {
        var currentTabID = BFActivityOption.getCurrentTabID();
        if (currentTabID != null) {
            var nextTabID = BFActivityOption.getNextTabID(currentTabID);
            if (nextTabID != null) {
                if (this.validateTab(currentTabID) == true) {
                    var nextTabID = BFActivityOption.getNextTabID(currentTabID);
                    while (nextTabID != null) {
                        this.enableTabHeader(nextTabID);
                        if (this.isTabCompleted(nextTabID) == true) {
                            nextTabID = BFActivityOption.getNextTabID(nextTabID);
                        } else {
                            break;
                        }
                    }
                    nextTabID = BFActivityOption.getNextTabID(currentTabID);
                    $('#' + CMSUtility.getAnchorID(nextTabID)).click();
                } else {
                    var nextTabID = BFActivityOption.getNextTabID(currentTabID);
                    while (nextTabID != null) {
                        if (nextTabID != 'tab9' && nextTabID != 'tab10') {
                            this.disableTabHeader(nextTabID);
                            nextTabID = BFActivityOption.getNextTabID(nextTabID);
                        } else {
                            nextTabID = null;
                        }
                    }
                }
            }
        }
    },
    loadPreviousTab: function() {
        var currentTabID = BFActivityOption.getCurrentTabID();
        if (currentTabID != null) {
            var previousTabID = BFActivityOption.getPreviousTabID(currentTabID);
            while (previousTabID != null) {
                var tab = this.getTab(previousTabID);
                if (tab.disabledHeader == false) {
                    $('#' + CMSUtility.getAnchorID(previousTabID)).click();
                    break;
                } else {
                    previousTabID = BFActivityOption.getPreviousTabID(previousTabID);
                }
            }
        }
    },
    isTabCompleted: function(tabID) {
        if (CMSUtility.isReadOnly() == false) {
            var validationResultTab7 = true;
            var validationResultTab2 = true;
            var validationResult = true;

            var tab = this.getTab(tabID);
            var container = document.getElementById(tabID);
            var fv = hyf.FMAction.getFormValidator();
            var errors = fv.checkContainer(container);

            if (errors.length > 0) {
                validationResult = false;
            }

            // var validationResult = hyf.validation.validateContainer(tabID);
            if (tabID == 'tab7') {
                validationResultTab7 = validateStratconTrCustom();
            }
            if (tabID == 'tab2') {
                //validationResultTab2 = validateStratconPOSCustom();
                validationResultTab2 = stratConPOS.validate();
            }
            tab.completed = validationResult && validationResultTab2 && validationResultTab7;
            return tab.completed;
        } else {
            return true;
        }
    },

    disableTabBasedOnActivityName: function(tabID, activityName) {
        // Disable tab based on BFActivityOption
        var foundActivity = BFActivityOption.actList.filter(function(node, index) {
            return node.name == activityName;
        })
        if (foundActivity.length > 0) {
            var readonlyTab = foundActivity[0].readonly.filter(function(node, index) {
                return node == tabID;
            });

            if (readonlyTab.length > 0) {
                this.disableTab(tabID);
            }
        }
    },

    // This function will be called after each tab is loaded.
    initTabAfterLoad: function(totalTabCount, tabID, activityName) {
        this.disableTabBasedOnActivityName(tabID, activityName);
        // tab.completed = this.isTabCompleted(tabID);
        this.totalLoadedTabCount += 1;
        if (this.totalLoadedTabCount == totalTabCount) {
            this.initTabsAfterAllTabLoaded();
        }
    },
    resetTabs : function() {
        var activeTabID = BFActivityOption.getCurrentTabID();
        hyf.util.setFieldValue('tab_control', activeTabID);

        var activeTabs = BFActivityOption.getActiveTabList(BFActivityOption.getActivityName());
        var leftTabNotCompleted = false;
        for (var index = 0; index < activeTabs.length; index++) {
            var currentTabCompleted = this.isTabCompleted(activeTabs[index]);
            var previousTabCompleted = (index > 0) ? this.isTabCompleted(activeTabs[index - 1]) : true;

            if (index == 0) {
                this.enableTabHeader(activeTabs[index]);
                document.getElementById(CMSUtility.getAnchorID(activeTabs[index])).className = 'selectedTab';
            } else {
                if (leftTabNotCompleted == true) {
                    if (activeTabs[index] == 'tab9' || activeTabs[index] == 'tab10') {
                        this.enableTabHeader(activeTabs[index]);
                    } else {
                        this.disableTabHeader(activeTabs[index]);
                    }

                } else {
                    this.enableTabHeader(activeTabs[index]);
                }
            }
            if (currentTabCompleted == false) {
                leftTabNotCompleted = true;
            }
        }
    },
    enableTabsForModification : function() {
        CMSUtility.debugLog('##### TabManager.enableTabsForModification START #####');
        var activityName = BFActivityOption.getActivityName();
        var option = BFActivityOption.getCurrentActivityOption(activityName);
        option.readonly = [];

        var currentTabID = BFActivityOption.getCurrentTabID();
        TabManager.enableATabForSubmission(currentTabID);
        CMSUtility.disableComponents(["btnApproveClsSpc","btnCancelReq_3", "btnModifyWorksheet"]);

        // $('#h_modifyRequested').val('true');
    },
    // This function will be called after all tabs are loaded.
    initTabsAfterAllTabLoaded: function() {
        StratConMAIN.initMaxSize();
        StratConMAIN.setDateIconTabOrder();

        $(document).trigger('CMS_ALL_TAB_LOADED');
        CMSUtility.infoLog('CMS_ALL_TAB_LOADED triggered.');

        this.tabList.forEach(function(tab, index) {
            tab.onInit();
        });        

        var activityName = BFActivityOption.getActivityName();
        var tabs = BFActivityOption.getActiveTabList(activityName);

        tabs.forEach(function(tab) {
            TabManager.disableTabBasedOnActivityName(tab, activityName);
        });
        this.resetTabs();
        StratConMAIN.showHideTabsUponRequestType();

        // keep the current tab selection
        var storedTabID = $("#currentTabID").val();
        if (storedTabID) {
            var tab = TabManager.getTab(storedTabID);
            if (tab.disabledHeader == false) {
                TabManager.tabChanger(storedTabID);
                TabManager.showHidePreNextButtons();

                $('#' + CMSUtility.getAnchorID(storedTabID)).focus();
            }
            $("#currentTabId").val(""); // clear current tab for closing page
        } else {
            TabManager.tabChanger("tab1");
            TabManager.showHidePreNextButtons();
        }


        var modificationRequestedStaff = $('#pv_returnToSOFromStaffSpec').val();
        var modificationRequestedClass = $('#pv_returnToSOFromClassSpec').val();
        if (modificationRequestedStaff === '" "') {
            modificationRequestedStaff = '';
            $('#pv_returnToSOFromStaffSpec').val(modificationRequestedStaff);
        }
        if (modificationRequestedClass === '" "') {
            modificationRequestedClass = '';
            $('#pv_returnToSOFromClassSpec').val('');
        }
        var isClassificationSpecialist = StratConMAIN.isCurrentUserMemberOf('HR Classification Specialists');
        var isStaffingSpecialist = StratConMAIN.isCurrentUserMemberOf('HR Staffing Specialists');
        var isSpecialProgramSpecialist = StratConMAIN.isCurrentUserMemberOf('HR Special Programs');
        
        if (BFActivityOption.getActivityName() === ACTNAME_APPROVEMEETING) {
            if ((isClassificationSpecialist === true && modificationRequestedClass === 'Updating') || 
                ((isStaffingSpecialist === true || isSpecialProgramSpecialist === true ) && modificationRequestedStaff === 'Updating')) {
                StratConMAIN.enableForModification();
            }
        }

        FormSection508.init();

        ActionButtonManager.init();

        greyOutScreen(false);

        var alertMessage = $('#pv_alertMessage').val();
        if (alertMessage != null && alertMessage.length > 0) {
            StratConMAIN.showAlertMessage(alertMessage);
            $('#pv_alertMessage').val("");
        }
    },
    // This function should be called before loading tabs.
    // This function is to add TabManager.initTabAFterLoad function to each tabs so that inittabAFterLoad can be called.
    initResponseHandler: function(totalTabCount) {
        if (window != null) {
            var activityName = BFActivityOption.getActivityName();
            this.tabList.forEach(function(tab) {
                window[tab.targetGroup + "ManipulateResponse"] = function(content, flag) {
                    content = content + '<div><script type="text/javascript">function ' + tab.targetGroup +
                        '_processAfterLoad() {TabManager.initTabAfterLoad(' + totalTabCount + ',"' + tab.id + '","' + activityName + '" );};' +
                        'hyf.attachEventHandler(window, "onload",' + tab.targetGroup + '_processAfterLoad);</script></div>';
                    return content;
                }
            });
        } else {
            CMSUtility.debugLog('STRATCONMAIN - initResponseHandler - window is null.');
        }
    },

    _currentTab: '',

    // Sometimes webmaker loses _hyfCondDisplayIds property that affects tab behavior.
    // If it is not found, this property should be reinitialized to have the array of numbers from 0 to 8.
    ensureTabControlPropertyPopulated: function() {
        try {
            var hyfCondDisplayIDs = $('#tab_control')[0]._hyfCondDisplayIds;
            if (!hyfCondDisplayIDs) {
                $('#tab_control')[0]._hyfCondDisplayIds = [0, 1, 2, 3, 4, 5, 6, 7, 8];
            } else {
                if (hyfCondDisplayIDs.length <= 0) {
                    $('#tab_control')[0]._hyfCondDisplayIds = [0, 1, 2, 3, 4, 5, 6, 7, 8];
                }
            }
        } catch (e) {
        }
    },

    // This function is called whenever webmaker tab is clicked.
    // WebMaker form has default tabChanger function and this is custom one.
    tabChanger: function(value) {
        if (this._currentTab == value) {
            return;
        };
        _currentTab = value;

        this.ensureTabControlPropertyPopulated();
        this.resetTabs();

        var currentTabID = BFActivityOption.getCurrentTabID();
        var activeTabs = BFActivityOption.getActiveTabList(BFActivityOption.getActivityName());
        if (value == "tab9" || value == "tab10" || this.isTabCompleted(currentTabID) == true) {
            hyf.util.setFieldValue('tab_control', value);
            this.tabList.forEach(function(tab) {
                if (tab.disabledHeader == false) {
                    document.getElementById(CMSUtility.getAnchorID(tab.id)).className = 'unselectedTab';
                }
            });

            var requestNumber = $('#h_requestNumber').val();
            if (CMSUtility.isReadOnly() == false) {
                if (requestNumber == null || requestNumber.length == 0) {
                    $('#h_now').val(CMSUtility.getNowUTCString());
                    callPartialPage(null, 'getRequestNumber.do', "system", 'layoutForResponse');
                };
            }
            document.getElementById(CMSUtility.getAnchorID(value)).className = 'selectedTab';
        } else {
            if (CMSUtility.isReadOnly() == false) {
                var nextTabID = BFActivityOption.getNextTabID(currentTabID);
                while (nextTabID != null) {
                    if (nextTabID != 'tab9' && nextTabID != 'tab10') {
                        this.disableTabHeader(nextTabID);
                        nextTabID = BFActivityOption.getNextTabID(nextTabID);
                    } else {
                        hyf.util.setFieldValue('tab_control', currentTabID);
                        this.tabList.forEach(function(tab) {
                            if (tab.disabledHeader != true) {
                                document.getElementById(CMSUtility.getAnchorID(tab.id)).className = 'unselectedTab';
                            }
                        });
                        document.getElementById(CMSUtility.getAnchorID(currentTabID)).className = 'selectedTab';
                        $('#' + CMSUtility.getAnchorID(currentTabID)).focus()
                        nextTabID = null;
                    }
                }
                // If destination tab is in left side
                if (value < currentTabID) {
                    hyf.util.setFieldValue('tab_control', value);
                    this.tabList.forEach(function(tab) {
                        if (tab.disabledHeader == false) {
                            document.getElementById(CMSUtility.getAnchorID(tab.id)).className = 'unselectedTab';
                        }
                    });
                    document.getElementById(CMSUtility.getAnchorID(value)).className = 'selectedTab';
                } else {
                    if (typeof event != 'undefined' && event != null) {
                        event.preventDefault();
                    }
                }
            }
        }

        // Broadcast ON_TAB_CHANGE event.
        // Attachment controller in document tab is using this event to update mandatory document type list.
        $(document).trigger("ON_TAB_CHANGE");
        return false;
    },
    showHidePreNextButtons: function() {
         var selectedTabID = BFActivityOption.getCurrentTabID();
         var activeTabs = BFActivityOption.getActiveTabList();

         var currentTabIndex = 0;
         for (var index = 0; index < activeTabs.length; index++) {
             if (activeTabs[index] == selectedTabID) {
                 currentTabIndex = index;
                 break;
             }
         }

         if (currentTabIndex == 0) {
             hyf.util.disableComponent("button_Previous");
             hyf.util.enableComponent("button_Next");
         } else if (currentTabIndex == activeTabs.length - 1) {
             hyf.util.enableComponent("button_Previous");
             hyf.util.disableComponent("button_Next");
         } else {
             CMSUtility.enableComponents(["button_Previous","button_Next"])
         }
    },
    originalTabChanger: null,
    installCustomTabChanger: function() {
        if (window.tab_controlTabChange != null) {
            this.originalTabChanger = window.tab_controlTabChange;
            window.tab_controlTabChange = function(value) {
                var tab = TabManager.getTab(value);
                if (tab.disabledHeader == false) {
                    TabManager.tabChanger(value);
                    TabManager.showHidePreNextButtons();
                    if (CMSUtility.isReadOnly() == false) {
                        TabManager.enableTabsForSubmission();
                        callPartialPage(null, 'saveTabContent.do', null, 'layoutForResponse2');
                        TabManager.rollbackTabsAfterSubmission();
                    }
                }
            }
        }
    },
    setTabListOption: function(tabListOption) {
        if (tabListOption != null && tabListOption.length > 0) {
            TabManager.tabList = tabListOption;
        } else {
            CMSUtility.logError('Tab list is null or empty.')
        }
    },
    initTab: function(tabListOption) {
        TabManager.setTabListOption(tabListOption);
        var activityName = BFActivityOption.getActivityName();
        var currentActivityOption = BFActivityOption.getCurrentActivityOption(activityName);
        this.initResponseHandler(this.tabList.length);

        this.totalLoadedTabCount = 0;
        this.tabList.forEach(function(tab, index) {
            if (typeof tab.displayMissingRequiredFields === 'undefined') {
                tab.displayMissingRequiredFields = true;
            }
            $('#' + CMSUtility.getAnchorID(tab.id)).attr('tabindex', 0);
            if (index == 0) {
                hyf.util.setFieldValue('tab_control', tab.id);
            } else {
                // Enable document tab and Notes tab always
                if (tab.id != 'tab9' && tab.id != 'tab10') {
                    TabManager.disableTabHeader(tab.id);
                }
            }
            setTimeout(TabManager.loadTab(tab.id), 0);
        });

        var firstTab = true;
        // Hide Tabs
        this.tabList.forEach(function(item) {
            var showTabs = currentActivityOption.tabs.filter(function(showTabName, index) {
                return showTabName == item.id;
            })
            if (showTabs.length == 0) {
                TabManager.hideTabHeader(item.id);
            } else {
                TabManager.showTabHeader(item.id);
                if (firstTab == true) {
                    firstTab = false;
                    document.getElementById(CMSUtility.getAnchorID(item.id)).className = 'selectedTab';
                    if (item.id != 'tab1') {
                        document.getElementById(CMSUtility.getAnchorID('tab1')).className = 'unselectedTab';
                    }
                } else {
                    document.getElementById(CMSUtility.getAnchorID(item.id)).className = 'unselectedTab';
                }
            }
        });

        $(".tabContainer a").off("click").click(function(e) {
            e.preventDefault();
            TabManager.loadTabFromAnchor(this);
        });
        $('#button_Previous').off("click").click(function() {
            TabManager.loadPreviousTab();
        });
        $('#button_Next').off("click").click(function() {
            TabManager.loadNextTab();
        });
    },
    enableATabForSubmission: function(tabID) {
        var disabledComponents = $('#' + tabID + ' input[readonly], input[disabled], select[disabled], textarea[disabled]');
        $.each(disabledComponents, function(index, component) {
            var disabledAttribute = $(this).attr('disabled');
            var readOnlyAttribute = $(this).attr('readonly');
            var donotsubmit = $(this).attr('donotsubmit');

            if (donotsubmit != 'true') {
                if (disabledAttribute) {
                    $(this).removeAttr('disabled');
                    $(this).attr('orgDisabled','disabled');
                }
                if (readOnlyAttribute) {
                    $(this).removeAttr('readonly');
                    $(this).attr('orgReadonly', 'readonly');
                }
            }
        });
    },

    preprocessFieldData: function() {
        var activityName = BFActivityOption.getActivityName();
        if (activityName == ACTNAME_HOLDMEETING) {
            var selectedMember = $("#SG_SP_ID :selected").text();
            if (selectedMember == "Select One") {
                var specialUserGroupMemberID = StratConMAIN.getUserGroupMemberID('HR Special Programs');
                CMSUtility.debugLog('TabManager.adjustFieldData - SG_SP_ID is reset to HR Special Programs usergroup member ID')
                $('#SG_SP_ID').append('<option value="' + specialUserGroupMemberID + '">HR Special Programs</option>');
                $('#SG_SP_ID').val(specialUserGroupMemberID);
            }
        }
    },

    postprocessFieldData: function() {
        var activityName = BFActivityOption.getActivityName();
        if (activityName == ACTNAME_HOLDMEETING) {
            var specialOptions = $('#SP_SP_ID option');
            var specialUserGroupMemberID = StratConMAIN.getUserGroupMemberID('HR Special Programs');

            $('#SG_SP_ID option[value="' + specialUserGroupMemberID + '"]').remove();
        }
    },

    enableTabsForSubmission: function() {
        TabManager.preprocessFieldData();

        var activityName = BFActivityOption.getActivityName();
        var activeTabs = BFActivityOption.getActiveTabList(activityName);
        activeTabs.forEach(function(tab) {
            TabManager.enableATabForSubmission(tab);
        });
    },

    rollbackTabsAfterSubmission: function() {
        var targetComponents = $('input[orgDisabled], input[orgReadonly], select[orgDisabled], select[orgReadonly], textarea[orgDisabled], textarea[orgReadonly]');
        $.each(targetComponents, function(index, component) {
            var orgDisabled = $(this).attr('orgDisabled');
            var orgReadonly = $(this).attr('orgReadonly');
            var donotsubmit = $(this).attr('donotsubmit');

            if (donotsubmit != 'true') {
                if (orgDisabled) {
                    $(this).attr('disabled', true);
                    $(this).removeAttr('orgDisabled');
                }
                if (orgReadonly) {
                    $(this).attr('readonly', true);
                    $(this).removeAttr('orgReadonly');
                }
            }
        });

        TabManager.postprocessFieldData();
    },

    getSelectedTabID: function() {
        var tabId = null;
        var currentTabs = $('#tab_control_container a.selectedTab');
        if (currentTabs.length > 0) {
            var tabAnchorId = currentTabs[0].attributes['id'].value;
            tabId = CMSUtility.getTabIDFromAnchorID(tabAnchorId);
        }
        return tabId;
    },    

    tabList: [] // This will contain Tab options.
};

var StratConMAIN = {
    tabList: [{
        id: "tab1",
        targetUrl: "/StratConMain/General.do",
        targetGroup: "partial_tab1",
        name: "General",
        loaded: false,
        completed: false,
        disabledHeader: false,
        onInit: function() {
            $('#SG_RT_ID').on("change", function() {
                StratConMAIN.resetRequestType();
            });
            StratConMAIN.resetRequestType();
            stratConGEN.init();
        }
    }, {
        id: "tab2",
        targetUrl: "/StratConMain/Position.do",
        targetGroup: "partial_tab2",
        name: "Position",
        loaded: false,
        completed: false,
        disabledHeader: false,

        onInit: function() {
            stratConPOS.init();
        }
    }, {
        id: "tab3",
        targetUrl: "/StratConMain/Meeting.do",
        targetGroup: "partial_tab3",
        name: "Meeting",
        loaded: false,
        completed: false,
        disabledHeader: false,
        onInit: function() {
            stratConMTG.init();
        }
    }, {
        id: "tab4",
        targetUrl: "/StratConMain/showAoc.do",
        targetGroup: "partial_tab4",
        name: "Area of Cons.",
        loaded: false,
        completed: false,
        disabledHeader: false,
        onInit: function() {
            initAocTab();
        }
    }, {
        id: "tab5",
        targetUrl: "/StratConMain/showSmeJa.do",
        targetGroup: "partial_tab5",
        name: "SME/Job Analysis",
        loaded: false,
        completed: false,
        disabledHeader: false,
        onInit: function() {
            initSmeJaTab();
        }
    }, {
        id: "tab6",
        targetUrl: "/StratConMain/showRi.do",
        targetGroup: "partial_tab6",
        name: "Incentives",
        loaded: false,
        completed: false,
        disabledHeader: false,
        onInit: function() {
            $('#RI_OA_APRV_ITEM').change(function() {
                $(document).trigger('ON_DOCUMENT_CHANGE');
            });
            initRiTab();
        }
    }, {
        id: "tab7",
        targetUrl: "/StratConMain/showTr.do",
        targetGroup: "partial_tab7",
        name: "Outreach",
        loaded: false,
        completed: false,
        disabledHeader: false,
        onInit: function() {
            initTrTab();
        }
    }, {
        id: "tab8",
        targetUrl: "/StratConMain/showApr.do",
        targetGroup: "partial_tab8",
        name: "Approvals",
        loaded: false,
        completed: false,
        disabledHeader: false,
        onInit: function() {
            initAprTab();
        },
        enableHandler: null,
    }, {
        id: "tab9",
        targetUrl: "/cmscommon/showAttachment.do",
        targetGroup: "partial_tab9",
        name: "Documents",
        loaded: false,
        completed: false,
        disabledHeader: false,
        displayMissingRequiredFields: false,
        onInit: function() {
            
        }
    }, {
        id: "tab10",
        targetUrl: "/cmscommon/showComment.do",
        targetGroup: "partial_tab10",
        name: "Notes",
        loaded: false,
        completed: false,
        disabledHeader: false,
        displayMissingRequiredFields: false,
        onInit: function() {
            
        }
    }],

    removeSizeLabel: function(element) {
        var target = null;
        var nodeName = $(element).get(0).tagName;
        if (nodeName == 'input') {
            if ($(element).hasClass('dijitInputInner')) {
                target = $(element).parent().parent().parent();
            } else {
                target = $(element).parent().parent();
            }
        } else if (nodeName == 'textarea') {
            target = $(element).parent();
        }

        if (target != null && target.length > 0) {
            $(target).find('p.sizeLabel').remove();
        }
    },
    // The element with alwaysDisabled/alwaysReadonly attribute will be submitted to the webserver.
    // But, when the form is enabled, element will not be enabled.
    setAlwaysDisabled: function(elementID) {
        var element = $('#' + elementID);
        var selectorKey = '#' + elementID;
        $(element).attr('disabled','disabled');
        $(element).attr('alwaysDisabled','true');

        StratConMAIN.removeSizeLabel(element);
    },
    setAlwaysReadonly: function(elementID) {
        var element = $('#' + elementID);
        $(element).prop('readonly','true');
        $(element).attr('alwaysReadonly','true');

        StratConMAIN.removeSizeLabel(element);
    },

    isSpecialProgram: function() {
        return CMSUtility.isSpecialProgram('SG_RT_ID', 'SG_AT_ID');
    },

    _CMS_allUserGroups: null,
    getUserGroupMemberID: function(userGroupName) {
        var userGroupMemberID = '';
        if (userGroupName == null || userGroupName.length == 0) {
            CMSUtility.debugLog('STRATCONMAIN - getUserGroupMemberID() - userGroupName is null or empty');
        }
        if (StratConMAIN._CMS_allUserGroups == null) {
            var rawAllUserGroupData = $('#h_cms_usergroupString').val();
            if (rawAllUserGroupData != null && rawAllUserGroupData.length > 0) {
                $('#h_cms_usergroupString').val('');
                var x2js = new X2JS();
                StratConMAIN._CMS_allUserGroups = x2js.xml_str2json(rawAllUserGroupData);
                x2js = null;
            } else {
                StratConMAIN._CMS_allUserGroups = {UserGroups: {}};
            }
            CMSUtility.debugLog('STRATCONMAIN - getUserGroupMemberID() - Usergroup information is initialized.');
        }

        if (StratConMAIN._CMS_allUserGroups != null
                && StratConMAIN._CMS_allUserGroups.cms_usergroup != null
                && StratConMAIN._CMS_allUserGroups.cms_usergroup.record != null) {
            var foundGroups = StratConMAIN._CMS_allUserGroups.cms_usergroup.record.filter(function(node, index) {
                return node.NAME == userGroupName
            });
            if (foundGroups.length > 0) {
                userGroupMemberID = foundGroups[0].MEMBERID;
            }
        }
        return userGroupMemberID;
    },
    addButtonHandler: function(buttonID, validationRequired, buttonOptions, confirmMessage) {
        if (buttonID != null && buttonOptions != null) {
            $('#' + buttonID).off('click').click(function() {
                if (validationRequired == true) {
                    var allTabCompleted = true;
                    var activeTabs = BFActivityOption.getActiveTabList(BFActivityOption.getActivityName());
                    for (var tabIndex = 0; tabIndex < activeTabs.length; tabIndex++) {
                        var validated = TabManager.validateTab(activeTabs[tabIndex]);
                        if (validated == false) {
                            TabManager.tabChanger(activeTabs[tabIndex]);
                            return;
                        }
                    }

                    var mandatoryDocumentsValid = $('#h_mandatoryDocumentsValid').val();
                    if (mandatoryDocumentsValid != 'true') {
                        TabManager.enableTabHeader('tab9');
                        TabManager.enableTab('tab9');
                        $('#' + CMSUtility.getAnchorID('tab9')).click();
                        bootbox.alert("Please upload the missing required document(s).");
                        return;
                    }
                }

                if (confirmMessage != null && confirmMessage.length > 0) {
                    bootbox.dialog({
                            message: '<p class="bootbox-body">' + confirmMessage + '</p>',
                            onEscape: true,
                            buttons: [{
                                label: 'Yes',
                                className: 'btn-success',
                                callback: function() {
                                    buttonOptions.forEach(function(option) {
                                        if (option.id == 'pv_requestStatusDate') {
                                            option.value = CMSUtility.getNowUTCString();
                                        }
                                        $('#' + option.id).val(option.value);
                                    })
                                    greyOutScreen(true);
                                    TabManager.enableTabsForSubmission();
                                    submitFormPage(buttonID, "saveNewForm");
                                }
                            }, {
                                label: 'No',
                                className: 'btn-danger'
                            }]
                        });
                } else {
                    buttonOptions.forEach(function(option) {
                        if (option.id == 'pv_requestStatusDate') {
                            option.value = CMSUtility.getNowUTCString();
                        }
                        $('#' + option.id).val(option.value);
                    })
                    greyOutScreen(true);
                    TabManager.enableTabsForSubmission();
                    submitFormPage(buttonID, "saveNewForm");
                }
            });
        } else {
            CMSUtility.debugLog('STRATCONMAIN - addButtonHandler() - buttonID or buttonOption is null.');
        }
    },
    initBasedOnActivity: function() {
        if (CMSUtility.isReadOnly() == true) {
            $('#bottomSection').hide();
            return;
        }

        CMSUtility.debugLog('STRATONMAIN - initBasedOnActivity - START');

        var activityName = BFActivityOption.getActivityName();
        if (activityName == ACTNAME_CREATEREQUEST) {
            StratConMAIN.addButtonHandler('button_notify', true, [{
                    id: 'WIH_complete_requested', value: 'true'
                }, {
                    id: 'pv_requestStatus', value: 'Request Created'
                }, {
                    id: 'pv_requestStatusDate', value: ''
                }, {
                    id: 'pv_selectOfficialReviewReq', value: 'No'
                }]);

            StratConMAIN.addButtonHandler('button_sendToSO', true, [{
                    id: 'WIH_complete_requested', value: 'true'
                }, {
                    id: 'pv_requestStatus', value: 'Request Created'
                }, {
                    id: 'pv_requestStatusDate', value: ''
                }, {
                    id: 'pv_selectOfficialReviewReq', value: 'Yes'
                }]);
        } else if (activityName == ACTNAME_REVIEWREQUEST) {
            StratConMAIN.addButtonHandler('button_notify', true, [{
                    id: 'WIH_complete_requested', value: 'true'
                }, {
                    id: 'pv_requestStatusDate', value: ''
                }]);
        } else if (activityName == ACTNAME_MODIFYREQUEST) {
            StratConMAIN.addButtonHandler('button_notify', true, [{
                    id: 'WIH_complete_requested', value: 'true'
                }, {
                    id: 'pv_requestStatusDate', value: ''
                }]);
        } else if (activityName == ACTNAME_HOLDMEETING) {
            StratConMAIN.addButtonHandler('button_notify', true, [{
                    id: 'WIH_complete_requested', value: 'true'
                }]);

            // Enabled when the all mandatory fields are completed
            StratConMAIN.addButtonHandler('button_sendToSO', true, [{
                    id: 'WIH_complete_requested', value: 'true'
                }, {
                    id: 'pv_meetingResched', value: 'No'
                }, {
                    id: 'pv_requestStatus', value: 'Consult Meeting Conducted'
                }, {
                    id: 'pv_requestStatusDate', value: ''
                }]);
        } else if (activityName == ACTNAME_ACKMEETING) {
            $('#pv_returnToSOFromClassSpec').val('');
            $('#pv_returnToSOFromStaffSpec').val('');

            StratConMAIN.addButtonHandler('button_acknowledge', true, [{
                    id: 'WIH_complete_requested', value: 'true'
                }, {
                    id: 'pv_meetingAckResponse', value: 'Yes'
                }], "Are you sure you want to submit your concurrence with the worksheet?");

            $('#button_returnForModification').off("click").click(function() {
                StratConMAIN.sendBackForModification();
            })
        } else if (activityName == ACTNAME_APPROVEMEETING) {
            StratConMAIN.addButtonHandler('button_approve', true, [{
                    id: 'WIH_complete_requested', value: 'true'
                }, {
                    id: 'pv_meetingApvResponse', value: 'Yes'
                }], "Are you sure you want to submit your approval of the worksheet?");

            $('#button_returnToSO').off("click").click(function() {
                var activityName = BFActivityOption.getActivityName();
                var tabs = BFActivityOption.getActiveTabList(activityName);

                var allValidated = true;
                tabs.forEach(function(tab) {
                    var validated = TabManager.validateTab(tab)
                    if (validated == false) {
                        allValidated = false;
                    }
                });
                if (allValidated == true) {
                    StratConMAIN.sendBackForModification();
                }
            });
console.log('#### ORDER CHECK - popupModifyRequest');
            $('#button_modify').click(function() {
                StratConMAIN.popupModifyRequest();
            });
        } else {
            CMSUtility.debugLog('STRATCONMAIN - initBasedOnActivity() - No activity name matched [' + activityName + ']');
        }

        $('#button_CancelWorkitem').off('click').click(function() {
            StratConMAIN.popupCancellation();
        });

        $('#button_SaveWorkitem').off('click').click(function() {
            setTimeout(function() {
                greyOutScreen(true);
                TabManager.enableTabsForSubmission();
                submitFormPage('button_SaveWorkitem', "saveNewForm");
            }, 0);
        });

        CMSUtility.debugLog('STRATONMAIN - initBasedOnActivity - END');
    },
    // Request Type in General Tab
    resetRequestType: function() {
        var requestTypeLabel = $('#SG_RT_ID option:selected').text();
        var requestTypeValue = $('#SG_RT_ID option:selected').val();

        if (requestTypeValue != '') {
            $('#requestType').text(requestTypeLabel);
        } else {
            $('#requestType').text('');
        }
        TabManager.resetTabs();
    },
    // This function will be called after getRequestNumber.do is completed.
    resetRequestNumber: function() {
        var requestNumber = $('#h_response_requestNumber').val();

        $('#h_requestNumber').val(requestNumber);
        $('#pv_requestStatus').val('Request Created');
        $('#requestNumber').text(requestNumber);
        $('#output_requestStatus').text('Request Created');
        var requestedStatusDate = $('#h_now').val();
        $('#pv_requestStatusDate').val(requestedStatusDate);
    },
    _currentUserGroupData: null,
    getCurrentUserGroupData: function() {
        if (StratConMAIN._currentUserGroupData == null) {
            StratConMAIN._currentUserGroupData = $('#h_userGroups').val();
            if (StratConMAIN._currentUserGroupData == null || StratConMAIN._currentUserGroupData.length == 0) {
                CMSUtility.debugLog('STRATCONMAIN - getCurrentUserGroupData() - ActivityName is null or empty.');
            } else {
                $('#h_userGroups').val('');
            }
        }
        return StratConMAIN._currentUserGroupData;
    },
    // UserGroup {
    //      Name: GroupName,
    //      ID: 0000000101,
    //      Path: /root/GroupName }
    _CMS_myUserGroups: null,
    _initUserGroupData: function() {
        var rawMyUserGroups = StratConMAIN.getCurrentUserGroupData();
        if (rawMyUserGroups != null && rawMyUserGroups.length > 0) {
            var x2js = new X2JS();
            StratConMAIN._CMS_myUserGroups = x2js.xml_str2json(rawMyUserGroups);
            x2js = null;
        } else {
            StratConMAIN._CMS_myUserGroups = {UserGroups: {}};
        }
    },
    isCurrentUserMemberOf: function(userGroupName) {
        if (userGroupName == null || userGroupName.length == 0) {
            CMSUtility.debugLog('STRATCONMAIN - isCurrentUserMemberOf() - userGroupName is null or empty');
        }
        if (StratConMAIN._CMS_myUserGroups == null) {
            StratConMAIN._initUserGroupData();
        }

        if (StratConMAIN._CMS_myUserGroups != null
                && StratConMAIN._CMS_myUserGroups.UserGroups != null
                && StratConMAIN._CMS_myUserGroups.UserGroups.UserGroup != null) {
            var foundGroups = StratConMAIN._CMS_myUserGroups.UserGroups.UserGroup.filter(function(node, index) {
                return node.Name == userGroupName
            });
            return foundGroups.length > 0;
        } else {
            return false;
        }
    },
    initMaxSizePerTab: function(tabID) {
        var inputControls = $('#' + tabID + ' input[size]');
        $.each(inputControls, function(index, control) {
            var maxSize = $(control).attr('size');
            var id = $(control).attr('id');
            var controlType = $(control).attr('_type');
            var alwaysReadonly = $('control').attr('alwaysReadonly');
            var alwaysDisabled = $('control').attr('alwaysDisabled');

            // Skip if the control is date control
            if (controlType != 'date' && typeof id != 'undefined' && !alwaysReadonly && !alwaysDisabled) {
                if ($(control).parent().length == 1
                    && $(control).parent().parent().length == 1
                    && $(control).parent().parent().parent().length == 1) {
                    var initialMessage = $(control).val();

                    var target;
                    if ($(control).hasClass('dijitInputInner')) {
                        target = $(control).parent().parent().parent();
                    } else {
                        target = $(control).parent().parent();
                    }

                    if (target.find('p.sizeLabel').length == 0) {
                        target.append('<p id="' + (id + '_sizeLabel' ) + '" class="sizeLabel" debugMessage="' + initialMessage + '">(Now: ' + initialMessage.length + ' / Max: ' + maxSize + ')</p>');

                        $('#' + id + '_sizeLabel').hide();

                        $(control).on('focus', function() {
                            var disabled = $(this).attr('disabled');
                            var readonly = $(this).prop('readonly');
                            if (!disabled && !readonly) {
                                $('#' + id + '_sizeLabel').show();
                            }
                        });

                        $(control).on('blur', function() {
                            $('#' + id + '_sizeLabel').hide();
                        });

                        $(control).on('keyup paste blur change', function() {
                            var message = $(control).val();
                            if (message.length > maxSize) {
                                $(control).val(message.substring(0, maxSize));
                            }
                            $('#' + id + '_sizeLabel').text('(Now: ' + message.length + ' / Max: ' + maxSize + ')');
                        })
                    }
                }
            }
        });

        var inputControls = $('#' + tabID + ' textarea.textbox[maxlength]');
        $.each(inputControls, function(index, control) {
            var maxSize = $(control).attr('maxlength');
            var id = $(control).attr('id');
            var alwaysReadonly = $('control').attr('alwaysReadonly');
            var alwaysDisabled = $('control').attr('alwaysDisabled');

            if ($(control).parent().length == 1 && typeof id != 'undefined' && !alwaysReadonly && !alwaysDisabled) {
                var initialMessage = $(control).val();

                if ($(control).parent().find('p.sizeLabel').length == 0) {
                    $(control).parent().append('<p id="' + (id + '_sizeLabel' ) + '" class="sizeLabel">(Now: ' + initialMessage.length + ' / Max: ' + maxSize + ')</p>');

                    $('#' + id + '_sizeLabel').hide();

                    $(control).on('focus', function() {

                        var disabled = $(this).attr('disabled');
                        var readonly = $(this).prop('readonly');
                        if (!disabled && !readonly) {
                            $('#' + id + '_sizeLabel').show();
                        }
                    });

                    $(control).on('blur', function() {
                        $('#' + id + '_sizeLabel').hide();
                    });

                    $(control).on('keyup keypress blur change', function() {
                        var message = $(control).val();
                        $('#' + id + '_sizeLabel').text('(Now: ' + message.length + ' / Max: ' + maxSize + ')');
                    })
                }
            }
        });
    },

    initMaxSize: function() {
        var tabs = ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab6', 'tab7', 'tab8', 'tab9', 'tab10'];
        tabs.forEach(function(tab) {
            StratConMAIN.initMaxSizePerTab(tab);
        });
    },
    setDateIconTabOrder: function() {
        var dateTextBoxes = $('input.textbox[_type=date]');
        $.each(dateTextBoxes, function(index, control) {
            var tabIndex = $(control).attr('tabindex');
            if ($.isNumeric(tabIndex) == true && tabIndex > 0) {
                var controlID = $(control).attr('id');
                $('#' + controlID + '_calendar_anchor').attr('tabindex', 0);
            }
        });
    },
    sendBackForModification: function() {
        var dialog = bootbox.dialog({
            title: 'Provide a summary of your changes',
            message: '<textarea rows="5" class="bootbox-input bootbox-input-text form-control"></textarea>',
            onEscape: true,
            buttons: {
                confirm: {
                    label: 'OK',
                    className: 'btn-success',
                    callback: function() {
                        var message = $('div.bootbox textarea').val();
                        if (message != null && message.length > 0) {
                            setTimeout(function() {
                                $('#WIH_complete_requested').val('true');
                                if (BFActivityOption.getActivityName() == ACTNAME_ACKMEETING) {
                                    $('#pv_meetingAckResponse').val('No');
                                    $('#pv_worksheetFeedbackSelectOfficial').val(message);
                                    $('#pv_alertMessage').val(message);
                                } else {
                                    if (StratConMAIN.isCurrentUserMemberOf('HR Classification Specialists') == true) {
                                        $('#pv_returnToSOFromClassSpec').val('Yes');
                                        $('#pv_returnToSOFromStaffSpec').val('');
                                        $('#pv_worksheetFeedbackClassSpec').val(message);
                                        $('#pv_alertMessage').val(message);
                                    } if (StratConMAIN.isCurrentUserMemberOf('HR Staffing Specialists') == true
                                        || StratConMAIN.isCurrentUserMemberOf('HR Special Programs') == true ) {
                                        $('#pv_returnToSOFromClassSpec').val('');
                                        $('#pv_returnToSOFromStaffSpec').val('Yes');
                                        $('#pv_worksheetFeedbackStaffSpec').val(message);
                                        $('#pv_alertMessage').val(message);
                                    }
                                }
                                greyOutScreen(true);
                                TabManager.enableTabsForSubmission();
                                submitFormPage('button_returnForModification', "saveNewForm");
                            }, 0);
                        } else {
                            return false;
                        }
                    }
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn-danger'
                }
            }
        });

        $('div.bootbox button.btn-success').prop("disabled", true);

        $('div.bootbox textarea').on("change keyup paste", function() {
            var message = $(this).val();
            if (message.length > 500) {
                $(this).val(message.substring(0, 500));
            }

            if (message.length == 0) {
                $('div.bootbox button.btn-success').prop("disabled", true);
            } else {
                $('div.bootbox button.btn-success').prop("disabled", false);
            }
        });
    },
    enableForModification: function() {
        var tabs = ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab6', 'tab7', 'tab8', 'tab9', 'tab10'];
        tabs.forEach(function(tab) {
            TabManager.enableTab(tab);
            StratConMAIN.initMaxSizePerTab(tab);
        })

        var activityName = BFActivityOption.getActivityName();
        var option = BFActivityOption.getCurrentActivityOption(activityName);
        option.readonly = [];

        CMSUtility.disableComponents(["IS_SO_ACK","IS_HR_CLS_SPC_APR","IS_HR_STF_SPC_APR"])

        var isClassificationSpecialist = StratConMAIN.isCurrentUserMemberOf('HR Classification Specialists');
        var isStaffingSpecialist = StratConMAIN.isCurrentUserMemberOf('HR Staffing Specialists');
        var isSpecialProgramSpecialist = StratConMAIN.isCurrentUserMemberOf('HR Special Programs');
        if (isClassificationSpecialist == true) {
            $('#pv_returnToSOFromClassSpec').val('Updating');
            $('#pv_returnToSOFromStaffSpec').val('');
        } else if (isStaffingSpecialist == true || isSpecialProgramSpecialist == true) {
            $('#pv_returnToSOFromClassSpec').val('');
            $('#pv_returnToSOFromStaffSpec').val('Updating');
        } else {
            CMSUtility.debugLog('STRATCONMAIN - enableForModification() - Modification requester is not class or staff specialist');
        }

        // ActionButtonManager and Position tab will receive this event
        $(document).trigger('CMS_MODIFY_WORKSHEET_FORM_ENABLED');
        CMSUtility.infoLog('CMS_MODIFY_WORKSHEET_FORM_ENABLED');
    },
    popupModifyRequest: function() {
        bootbox.dialog({
            message: "Are you sure you want to modify worksheet?",
            onEscape: true,
            buttons: [{
                label: 'Yes',
                className: 'btn-success',
                callback: StratConMAIN.enableForModification
            }, {
                label: 'No',
                className: 'btn-danger'
            }]
        });
    },
    popupCancellation: function() {
        var isUserSO = StratConMAIN.isCurrentUserMemberOf('Selecting Officials');
        var isUserLiaison = StratConMAIN.isCurrentUserMemberOf('HR Liaison');
        var isXO = StratConMAIN.isCurrentUserMemberOf('Executive Officers');
        var isClassificationSpecialist = StratConMAIN.isCurrentUserMemberOf('HR Classification Specialists');
        var isStaffingSpecialist = StratConMAIN.isCurrentUserMemberOf('HR Staffing Specialists');

        var reasons = [];

        if (isUserSO == true) {
            reasons = LookupManager.findByLTYPE('UserGroup[Selecting Officials]/CancellationReason');
        } else if (isUserLiaison == true) {
            reasons = LookupManager.findByLTYPE('UserGroup[HR Liaison]/CancellationReason');
        } else if (isXO == true) {
            reasons = LookupManager.findByLTYPE('UserGroup[Executive Officers]/CancellationReason');
        } else if (isClassificationSpecialist == true) {
            reasons = LookupManager.findByLTYPE('UserGroup[HR Classification Specialists]/CancellationReason');
        } else if (isStaffingSpecialist == true) {
            reasons = LookupManager.findByLTYPE('UserGroup[HR Staffing Specialists]/CancellationReason');
        } else {
            reasons = LookupManager.findByLTYPE('UserGroup[Default]/CancellationReason');
        }

        var options = '<option value>Select one</option>';
        reasons.forEach(function(reason) {
            options = options + '<option value=' + reason.LABEL + '>' + reason.LABEL + '</option>';
        });

        var dialog = bootbox.dialog({
            title: 'Reason for Cancellation',
            message: '<span>Cancellation Reason</span><span class="mandatory" style="" title="Mandatory field"> * </span><span>:&nbsp;</span><select name="CancellationReason">' + options + '</select>',
            onEscape: true,
            buttons: {
                confirm: {
                    label: 'OK',
                    className: 'btn-success',
                    callback: function() {
                        var message = $('div.bootbox select option:selected').text();
                        if (message == null || message.length == 0) {
                            return false;
                        }

                        setTimeout(function() {
                            greyOutScreen(true);
                            TabManager.enableTabsForSubmission();
                            $('#WIH_complete_requested').val('true');
                            $('#pv_requestStatus').val('Request Cancelled');
                            $('#pv_requestStatusDate').val(CMSUtility.getNowUTCString());
                            $('#pv_CancelReason').val(message);
                            submitFormPage('button_CancelWorkitem', "saveNewForm");
                        }, 0);
                    }
                },
                cancel: {
                    label: 'Cancel',
                    className: 'btn-danger'
                }
            }
        });

        $('div.bootbox button.btn-success').prop('disabled', true);

        $('div.bootbox select').on("change keyup", function() {
            var message = $('div.bootbox select option:selected').val();
            if (message == "") {
                $('div.bootbox button.btn-success').prop('disabled', true);
            } else {
                $('div.bootbox button.btn-success').prop('disabled', false);
            }
        });
    },
    showAlertMessage: function(message) {
        var dialog = bootbox.dialog({
            title: 'Requested Changes',
            message: '<textarea disabled rows="5" class="bootbox-input bootbox-input-text form-control">' + message + '</textarea>',
            onEscape: true,
            buttons: {
                confirm: {
                    label: 'OK',
                    className: 'btn-success',
                }
            }
        });
    },
    showHideMeetingTab: function() {
        CMSUtility.debugLog('STRATCONMAIN - showHideMeetingTab - START');
        var activityName = BFActivityOption.getActivityName();
        var currentActivityOption = BFActivityOption.getCurrentActivityOption(activityName);
        var meetingTabs = currentActivityOption.tabs.filter(function(tab) {
            return tab == 'tab3';
        });

        if (meetingTabs.length > 0) {
            var requestType = $('#SG_RT_ID :selected').text();
            var appointmentType = $('#SG_AT_ID :selected').text();
            var classificationType = $('#SG_CT_ID :selected').text();
            var hideMeetingTab = false;

            if (requestType == 'Appointment') {
                if (appointmentType == 'Volunteer'
                    || appointmentType == 'Intergovernmental Personnel Act (IPA)'
                    || appointmentType == 'Expert/Consultant' ) {
                    hideMeetingTab = true;
                } else if (classificationType && classificationType.length > 0
                    && (classificationType == 'Conduct 5-year Recertification'
                        || classificationType == 'Update Coversheet'
                        || classificationType == 'Review Existing Position Description')) {
                    hideMeetingTab= true;
                }
            }

            if (hideMeetingTab == true) {
                $('#pv_meetingRequired').val('No');
                TabManager.clearTabContent('tab3');
                TabManager.hideTabHeader('tab3');
                BFActivityOption.removeTabFromCurrentActivity(activityName, 'tab3');
                TabManager.resetTabs();
            } else {
                $('#pv_meetingRequired').val('Yes');
                TabManager.showTabHeader('tab3');
                BFActivityOption.addTabToCurrentActivity(activityName, 'tab3');
                TabManager.resetTabs();

                var meetingDate = $('#SSH_MEETING_SCHED_DT').val();
                if (meetingDate == null || meetingDate.length == 0) {
                    var orgMeetingDateAttributeValue = $('#SSH_MEETING_SCHED_DT').attr('_orig_value');
                    if (orgMeetingDateAttributeValue != null && orgMeetingDateAttributeValue.length > 0) {
                        $('#SSH_MEETING_SCHED_DT').val(orgMeetingDateAttributeValue);
                        $('#MEETING_DATE_CHANGED').val('false');
                    } else {
                        var originalMeetingDate = $('#h_meetingOriginalDate').val();
                        if (originalMeetingDate != null && originalMeetingDate.length > 0) {
                            $('#SSH_MEETING_SCHED_DT').attr('_orig_value', originalMeetingDate);
                            $('#SSH_MEETING_SCHED_DT').val(originalMeetingDate);
                            $('#MEETING_DATE_CHANGED').val('false');
                        }
                    }
                }
            }
        }
        CMSUtility.debugLog('STRATCONMAIN - showHideMeetingTab - END');
    },
    showHideTabsUponRequestType: function() {
        CMSUtility.debugLog('STRATCONMAIN - showHideTabsUponRequestType - START');
        var activityName = BFActivityOption.getActivityName();
        var targetTabs = ['tab4', 'tab5', 'tab6', 'tab7'];
        var currentActivityOption = BFActivityOption.getCurrentActivityOption(activityName);

        var requestType = $('#SG_RT_ID :selected').text();
        var classificationType = $('#SG_CT_ID :selected').text();
        if (requestType == 'Appointment') {
            targetTabs.forEach(function(tabID) {
                var foundTabs = currentActivityOption.tabs.filter(function(tab) {
                    return tab == tabID;
                });

                if (foundTabs.length > 0) {
                    TabManager.clearTabContent(tabID);
                    TabManager.hideTabHeader(tabID);
                    BFActivityOption.removeTabFromCurrentActivity(activityName, tabID);
                }
            });
        } else {
            if (requestType == 'Classification Only') {
                // Tab4 should be hidden
                TabManager.clearTabContent('tab4');
                TabManager.hideTabHeader('tab4');
                BFActivityOption.removeTabFromCurrentActivity(activityName, 'tab4');
                targetTabs = ['tab5', 'tab6', 'tab7'];
            }

            targetTabs.forEach(function(tabID) {
                var foundTabs = currentActivityOption.tabs.filter(function(tab) {
                    return tab == tabID;
                });

                if (foundTabs.length > 0) {
                    TabManager.showTabHeader(tabID);
                    BFActivityOption.addTabToCurrentActivity(activityName, tabID);
                }
            });
        }

        StratConMAIN.showHideMeetingTab();
        CMSUtility.debugLog('STRATCONMAIN - showHideTabsUponRequestType - END');
    },

    //
    // StratconMain ENTRY POINT
    //
    // Form Initialization function
    // This function will be called when the mainform is loaded.
    init: function() {
        CMSUtility.debugLog('StratConMain - init START');

        // Following should be called to reduce redundant network traffic.
        StratConMAIN.getCurrentUserGroupData();

        if (CMSUtility.isReadOnly() == true) {
            var activityName = BFActivityOption.getActivityName();
            var option = BFActivityOption.getCurrentActivityOption(activityName);
            option.readonly = ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab6', 'tab7', 'tab8', 'tab9', 'tab10'];
        }

        LookupManager.init();
        TabManager.installCustomTabChanger();
        TabManager.initTab(StratConMAIN.tabList);

        // Request Date
        var requestedDateString = $('#h_creationdate').val();
        if (requestedDateString != null && requestedDateString.length > 0) {
            var requestedDate = new Date(requestedDateString);  // requestedDateString is GMT
            var newDate = new Date(requestedDate.getTime() - requestedDate.getTimezoneOffset() * 60000); // Adjust to local time
            var requestedDateLabel = CMSUtility.getDateString({isUTC: false, dateFormat: 'mm/dd/yyyy'}, newDate);
            $('#initiatedDate').text(requestedDateLabel);
        }

        // Request Number
        var requestNumber = $('#h_requestNumber').val();
        $('#requestNumber').text(requestNumber);

        // Request Status
        var requestStatus = $('#pv_requestStatus').val();
        $('#output_requestStatus').text(requestStatus);

        hyf.util.disableComponent("button_Previous");
        hyf.util.enableComponent("button_Next");

        StratConMAIN.initBasedOnActivity();

    	// set focus on the current tab
    	$("a.selectedTab").focus();

        CMSUtility.debugLog('StratConMain - init END');
    },
}

// // TBD - It is moved to cmsutility.js
// var _readOnly = null;
// function isReadOnly() {
//     if (_readOnly == null) {
//         _readOnly = $('#h_readOnly').val();
//         if (_readOnly == 'y') {
//             _readOnly = true;
//         } else {
//             _readOnly = false;
//         }
//     }
//     return _readOnly;
// }
