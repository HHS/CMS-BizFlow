/**
 * Global Object which consists for properties and methods used by this project
 *
 */
var stratConMTG = {
	/**
	 * This is a flag field which changes whether meeting date is changes
	 * used when the date is changed multiple times and reverting back to original date
	 */
	setRescheduleHistory: false,

	/**
	 * This method/function return true if passed in date
	 * is less then today's date
	 *
	 * @dt - date to check
	 */
	dateLessThenToday: function (dt) {
		var today = new Date();
		today.setHours(0,0,0,0);
		var this_date = new Date(dt);
		return this_date < today;
	},

	/**
	 * This method/function converts a date from
	 * YYYY-MM-DD format to MM/DD/YYYY format
	 *
	 * @dt - date to convert in YYYY-MM-DD format
	 */
	convertToMMDDYYY: function (dt) {
		var retVal = '';
		dt = (dt + ' ').trim();
		if (dt && dt !== '') {
			var d = dt.slice(0, 10).split('-');
			if (d.length >= 3) {
				retVal = d[1] +'/'+ d[2] +'/'+ d[0];
			}
		}
		return retVal;
	},

	/**
	 * This method/function converts a UTC timestamp
	 * to Local Timestamp
	 *
	 * @dt - date to convert in UTC timestamp format
	 */
    convertToLocalTimeStamp: function (dt) {
        var retVal = '';
		dt = (dt + ' ').trim();
        if (dt && dt !== '') {
            try {
                dt = dt.replace(/\//g, "-");
                dt = dt.replace(" ", "T");
                dt = dt + "Z";
                var d = new Date(dt);

                retVal = CMSUtility.getDateString({isUTC: false, dateFormat: 'mm/dd/yyyy hh:MM:ss a'}, d);
            }
            catch (err) {
                retVal = '**Invalid Date**';
            }
        }
        return retVal;
    },

	/**
	 * Init function/method called from On PageLoad; performs
	 * various activities to setup the page UI, hide/show fields
	 */
    init:function () {
        this.setRescheduleHistory = ($('#WORKITEM_ACTIVITY_NAME').val() === 'Modify Request' || $('#WORKITEM_ACTIVITY_NAME').val() === 'Hold Strategic Consultation Meeting');
		$("textarea[id$='SSH_RESCHED_COMMENTS_DSP']").each(function() {
			$(this).attr('title', 'Comments: ' + $(this).text());
		});

		$("span[id$='SSH_MEETING_SCHED_DT_DSP'], span[id$='SSH_RESCHED_FROM_DT_DSP']").each (function() {
			$(this).text(stratConMTG.convertToMMDDYYY($(this).text()));
		});
		$("span[id$='SSH_RESCHED_ON_DSP']").each (function() {
			$(this).text(stratConMTG.convertToLocalTimeStamp($(this).text()));
        });

        var meetingDate = $('#SSH_MEETING_SCHED_DT').val();
        if (meetingDate != null && meetingDate.length > 0) {
            $('#SSH_MEETING_SCHED_DT').attr('_orig_value', meetingDate);
            $('#h_meetingOriginalDate').val(meetingDate);
            $('#MEETING_DATE_CHANGED').val(false);
        } else {
            var originalMeetingDate = $('#h_meetingOriginalDate').val();
            if (originalMeetingDate != null && originalMeetingDate.length > 0) {
                $('#SSH_MEETING_SCHED_DT').attr('_orig_value', originalMeetingDate);
                $('#SSH_MEETING_SCHED_DT').val(originalMeetingDate);
                $('#MEETING_DATE_CHANGED').val(false);
            }
        }
        $('#SSH_RESCHED_FROM_DT').attr('_orig_value', $('#SSH_RESCHED_FROM_DT').val());
        $('#SSH_RESCHED_FROM_DT').val('');
        $('#SSH_RESCHED_REASON_ID_label_container').addClass('hidden');
        $('#SSH_RESCHED_REASON_ID_container').addClass('hidden');
        $('#SSH_RESCHED_REASON_ID').attr('_required', 'false');
        $('#SSH_RESCHED_COMMENTS_label_container').addClass('hidden');
        $('#SSH_RESCHED_COMMENTS_container').addClass('hidden');
        $('#SSH_RESCHED_COMMENTS').attr('_required', 'false');
        $('#SSH_MEETING_SCHED_DT').on('change', function() {
            var this_obj = $(this);
            var meetingDate = this_obj.val();
            if (stratConMTG.dateLessThenToday(meetingDate)) {
                alert('Meeting Date must be today or later\n\nReverting to Original Value');
                this_obj.val(this_obj.attr('_orig_value'));
                meetingDate = this_obj.val();
            }
            var meetingDateChanged = (meetingDate !== this_obj.attr('_orig_value'));
            if (meetingDateChanged && meetingDate != '') {
                $('#MEETING_DATE_CHANGED').val('true');
                $(document).trigger('MEETING_DATE_CHANGED');
            } else {
                $('#MEETING_DATE_CHANGED').val('false');
                $(document).trigger('MEETING_DATE_CHANGED');
            }
            if (stratConMTG.setRescheduleHistory) {
                if (meetingDateChanged && meetingDate != '') {
                    $('#SSH_RESCHED_REASON_ID_label_container').removeClass('hidden');
                    $('#SSH_RESCHED_REASON_ID_container').removeClass('hidden');
                    $('#SSH_RESCHED_REASON_ID').attr('_required', 'true');
                    $('#SSH_RESCHED_COMMENTS_label_container').removeClass('hidden');
                    $('#SSH_RESCHED_COMMENTS_container').removeClass('hidden');
                    $('#SSH_RESCHED_COMMENTS').attr('_required', 'true');
                    $('#IS_RESCHEDULED').val('true');
                    $('#SSH_RESCHED_REASON_TEXT').val($("#SSH_RESCHED_REASON_ID option:selected").text());
                    $('#SSH_RESCHED_FROM_DT').val($('#SSH_RESCHED_FROM_DT').attr('_orig_value'));
                }
                else {
                    $('#SSH_RESCHED_REASON_ID_label_container').addClass('hidden');
                    $('#SSH_RESCHED_REASON_ID_container').addClass('hidden');
                    $('#SSH_RESCHED_REASON_ID').attr('_required', 'false');
                    $('#SSH_RESCHED_COMMENTS_label_container').addClass('hidden');
                    $('#SSH_RESCHED_COMMENTS_container').addClass('hidden');
                    $('#SSH_RESCHED_COMMENTS').attr('_required', 'false');
                    $('#IS_RESCHEDULED').val('false');
                    $('#SSH_RESCHED_REASON_TEXT').val('');
                    $('#SSH_RESCHED_FROM_DT').val('');
                }
            }
        });
        $('#SSH_RESCHED_REASON_ID').on('change', function() {
            $('#SSH_RESCHED_REASON_TEXT').val($("#SSH_RESCHED_REASON_ID option:selected").text());
        });
        $( "span[id$='reschMeetingDate'], span[id$='reschRescheduleFrom']").each(function () {
            var dt = $(this).text().trim();
            $(this).attr('_orig_text', dt);
            if (dt && dt !== '') {
                $(this).text(dt.substring(5, 7) + '/' + dt.substring(8, 10) + '/' + dt.substring(0, 4));
            }
        });

        this.adjustTabIndexForMeetingHistory();
    },

    adjustTabIndexForMeetingHistory: function() {
        var rowName = 'reschedule_history_table';
        var firstFieldName = 'SSH_MEETING_SCHED_DT_DSP';
        var fieldNames = ['SSH_RESCHED_FROM_DT_DSP', 'SSH_RESCHED_REASON_TEXT_DSP', 'SSH_RESCHED_COMMENTS_DSP', 'SSH_RESCHED_BY_NAME_DSP', 'SSH_RESCHED_ON_DSP'];

        var index = 1;
        var tabIndex = 30;
        do {
            var firstColumn = $('#tab3 #' + rowName + index + firstFieldName);
            if (firstColumn.length > 0) {
                $(firstColumn).attr('tabindex', tabIndex++);

                for (var fieldIndex = 0; fieldIndex < fieldNames.length; fieldIndex++) {
                    var fieldID = '#tab3 #' + rowName + index + fieldNames[fieldIndex];
                    var element = $(fieldID);
                    if (element.length > 0) {
                        $(element).attr('tabindex', tabIndex++);
                    } else {
                        console.log("Not found [" + fieldID + "]");
                        break;
                    }
                }

                index++;
            } else {
                break;
            }
        } while(index < 500);
        if (index >= 500) {
            console.log("This might be error situation. Looped 500 times.");
        }
    }

}
