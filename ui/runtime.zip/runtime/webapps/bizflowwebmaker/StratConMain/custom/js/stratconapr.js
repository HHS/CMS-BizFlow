var ACT_SC_ACKNOWLEDGE = "Acknowledge Strat Cons Meeting";
var ACT_SC_APPROVE = "Approve Strat Cons Meeting";
var UG_SEL_OFC = "Selecing Official";
var UG_HR_CLS_SPC = "HR Classification Specialist";
var UG_HR_STF_SPC = "HR Staffing Specialist";

/**
 * onload event handler for APT tab page.
 */
function initAprTab() {

	//=========================================================================
	// Event handler attachment for cross tab fields.
	//
	// NOTE: This is redundant event handler attaching since the ones in onload
	//       event of the current tab page may be missed due to each tab page
	//       object's load timing at runetime.
	//       In order to address this issue, CMS_ALL_TAB_LOADED event is issued
	//       from the main form.  By catching this event from the current
	//       sub-form, it is guaranteed that all sub-tab pages objects are
	//       loaded.  By attaching event handler for fields that exist in
	//       other tabs at after this event, we make sure the target fields
	//       do not miss any event handler.
	//=========================================================================
	$(document).on("CMS_ALL_TAB_LOADED", function() {
		controlCheckboxPerUser();

		// add event handler for Request Type to show/hide Staffing Specialist section
		$("#SG_RT_ID").on("change", onChange_SG_RT_ID);
		onChange_SG_RT_ID();

		$(document).trigger('CMS_CON_APR_INIT_COMPLETED');
	});

	// make acknowledgement/approval checkboxes disabled depending on the current user's role as specified in General tab
	controlCheckboxPerUser();

	var IsSelOfcAckChkElm = $("#IS_SO_ACK");             // Selecing Official acknowledgement checkbox element
	var SelOfcSigNameElm  = $("#SCA_SO_SIG");            // Selecing Official signature name textbox element
	var SelOfcSigDtElm    = $("#SCA_SO_SIG_DT");         // Selecing Official signature date textbox element
	var IsClsSpcAprChkElm = $("#IS_HR_CLS_SPC_APR");     // HR Classification Specialist approval checkbox element
	var ClsSpcSigNameElm  = $("#SCA_CLASS_SPEC_SIG");    // HR Classification Specialist signature name textbox element
	var ClsSpcSigDtElm    = $("#SCA_CLASS_SPEC_SIG_DT"); // HR Classification Specialist signature date textbox element
	var IsStfSpcAprChkElm = $("#IS_HR_STF_SPC_APR");     // HR Staffing Specialist approval checkbox element
	var StfSpcSigNameElm  = $("#SCA_STAFF_SIG");         // HR Staffing Specialist signature name textbox element
	var StfSpcSigDtElm    = $("#SCA_STAFF_SIG_DT");      // HR Staffing Specialist signature date textbox element

	// make all signature name/date fields readonly
	SelOfcSigNameElm.prop('readonly', true);
	SelOfcSigDtElm.prop('readonly', true);
	ClsSpcSigNameElm.prop('readonly', true);
	ClsSpcSigDtElm.prop('readonly', true);
	StfSpcSigNameElm.prop('readonly', true);
	StfSpcSigDtElm.prop('readonly', true);

	// hide Staffing Specialist section if Request Type is "Classification Only"
	// add event handler for Request Type to show/hide Staffing Specialist section
	$("#SG_RT_ID").on("change", onChange_SG_RT_ID);

	// When checkbox is checked, capture name and date for Selecing Official
	// When the page is reloaded, if the name/date are populated, check the checkbox, otherwise uncheck
	// Initially, check if the value of dependent fields are populated.  Otherwise, uncheck.
	if ( (SelOfcSigNameElm != null && SelOfcSigNameElm.val() != null && SelOfcSigNameElm.val().length > 0)
		|| (SelOfcSigDtElm != null && SelOfcSigDtElm.val() != null && SelOfcSigDtElm.val().length > 0) ) {
		IsSelOfcAckChkElm.prop("checked", true);
	} else {
		IsSelOfcAckChkElm.prop("checked", false);
	}

	// add event handler for the parent checkbox to capture name and date onto the dependent text fields
	IsSelOfcAckChkElm.change(function() {
		if ($(this).prop("checked")) {
			SelOfcSigNameElm.val($("#h_currentUserName").val()); // set current user name for signature
			SelOfcSigDtElm.val(getMMDDYYYYDateStr(new Date()));  // set current date for signature
		} else {
			SelOfcSigNameElm.val("");  // clear name
			SelOfcSigDtElm.val("");    // clear date
		}
	});

	// When checkbox is checked, capture name and date for HR Classification Specialist
	// When the page is reloaded, if the name/date are populated, check the checkbox, otherwise uncheck
	// Initially, check if the value of dependent fields are populated.  Otherwise, uncheck.
	if ( (ClsSpcSigNameElm != null && ClsSpcSigNameElm.val() != null && ClsSpcSigNameElm.val().length > 0)
		|| (ClsSpcSigDtElm != null && ClsSpcSigDtElm.val() != null && ClsSpcSigDtElm.val().length > 0) ) {
		IsClsSpcAprChkElm.prop("checked", true);
	} else {
		IsClsSpcAprChkElm.prop("checked", false);
	}

	// add event handler for the parent checkbox to capture name and date onto the dependent text fields
	IsClsSpcAprChkElm.change(function() {
		// set or clear dependent field values
		if ($(this).prop("checked")) {
			ClsSpcSigNameElm.val($("#h_currentUserName").val());  // set current user name for signature
			ClsSpcSigDtElm.val(getMMDDYYYYDateStr(new Date()));   // set current date for signature
		} else {
			ClsSpcSigNameElm.val("");  // clear name
			ClsSpcSigDtElm.val("");    // clear date
		}
	});

	// When checkbox is checked, capture name and date for HR Staffing Specialist
	// When the page is reloaded, if the name/date are populated, check the checkbox, otherwise uncheck
	// Initially, check if the value of dependent fields are populated.  Otherwise, uncheck.
	if ( (StfSpcSigNameElm != null && StfSpcSigNameElm.val() != null && StfSpcSigNameElm.val().length > 0)
		|| (StfSpcSigDtElm != null && StfSpcSigDtElm.val() != null && StfSpcSigDtElm.val().length > 0) ) {
		IsStfSpcAprChkElm.prop("checked", true);
	} else {
		IsStfSpcAprChkElm.prop("checked", false);
	}

	// add event handler for the parent checkbox to capture name and date onto the dependent text fields
	IsStfSpcAprChkElm.change(function() {
		if ($(this).prop("checked")) {
			StfSpcSigNameElm.val($("#h_currentUserName").val());  // set current user name for signature
			StfSpcSigDtElm.val(getMMDDYYYYDateStr(new Date()));   // set current date for signature
		} else {
			StfSpcSigNameElm.val("");  // clear name
			StfSpcSigDtElm.val("");    // clear date
		}
	});

	// trigger events for initial processing
	onChange_SG_RT_ID();

	if (shouldClearSignatures() == true) {
		IsSelOfcAckChkElm.prop('checked', false);
		SelOfcSigNameElm.val('');
		SelOfcSigDtElm.val('');
		IsClsSpcAprChkElm.prop('checked', false);
		ClsSpcSigNameElm.val('');
		ClsSpcSigDtElm.val('');
		IsStfSpcAprChkElm.prop('checked', false);
		StfSpcSigNameElm.val('');
		StfSpcSigDtElm.val('');
	}

} // end initAprTab()

function onChange_SG_RT_ID() {
	var reqTypeValSel = $('#SG_RT_ID :selected').text();
	if (reqTypeValSel != null && reqTypeValSel == "Classification Only") {
		$("#hr_stf_spc_group").hide();
	} else {
		$("#hr_stf_spc_group").show();
	}
}

/**
 * Gets date string in MM/dd/yyyy format.
 *
 * @param inputDt - Date object
 * @return - a string for the given date in MM/dd/yyyy format.
 *           In case of error, returns empty string.
 */
function getMMDDYYYYDateStr(inputDt){
	var curDateValToSet = '';
	if (inputDt != null && inputDt instanceof Date) {
		curDateValToSet = CMSUtility.getDateString({isUTC: false, dateFormat: 'mm/dd/yyyy'}, inputDt);
	}
	return curDateValToSet;
}

/**
 * Controls enable/disable of checkboxes for acknowledgement or approval
 * depending on the current user's role specified in General tab.
 */
function controlCheckboxPerUser(){
	var IsSelOfcAckChkElm = $("#IS_SO_ACK");             // Selecing Official acknowledgement checkbox element
	var IsClsSpcAprChkElm = $("#IS_HR_CLS_SPC_APR");     // HR Classification Specialist approval checkbox element
	var IsStfSpcAprChkElm = $("#IS_HR_STF_SPC_APR");     // HR Staffing Specialist approval checkbox element
	var curUsrMemId = $("#h_currentUserMemberID").val();
	if (typeof curUsrMemId != "undefined" && curUsrMemId != null && curUsrMemId.length == 10) {
		// compare with Selecing Official
		if (curUsrMemId == $("#SG_SO_ID option:selected").val()) {
			IsSelOfcAckChkElm.prop("disabled", false);
			IsSelOfcAckChkElm.attr("_required", true);
		} else {
			IsSelOfcAckChkElm.prop("disabled", true);
			IsSelOfcAckChkElm.attr("_required", false);
		}
		// compare with HR Classification Specialist
		if (curUsrMemId == $("#SG_CS_ID option:selected").val()) {
			IsClsSpcAprChkElm.prop("disabled", false);
			IsClsSpcAprChkElm.attr("_required", true);
		} else {
			IsClsSpcAprChkElm.prop("disabled", true);
			IsClsSpcAprChkElm.attr("_required", false);
		}
		// compare with HR Staffing Specialist or Special Program Staffing Specialist
		if (curUsrMemId == $("#SG_SS_ID option:selected").val()
				|| curUsrMemId == $("#SG_SP_ID option:selected").val()) {
			IsStfSpcAprChkElm.prop("disabled", false);
			IsStfSpcAprChkElm.attr("_required", true);
		} else {
			IsStfSpcAprChkElm.prop("disabled", true);
			IsStfSpcAprChkElm.attr("_required", false);
		}
	} else {
		IsSelOfcAckChkElm.prop("disabled", true);
		IsSelOfcAckChkElm.attr("_required", false);
		IsClsSpcAprChkElm.prop("disabled", true);
		IsClsSpcAprChkElm.attr("_required", false);
		IsStfSpcAprChkElm.prop("disabled", true);
		IsStfSpcAprChkElm.attr("_required", false);
	}
} // end controlCheckboxPerUser()

function shouldClearSignatures() {
	var clearSignature = false;
	var activityName = BFActivityOption.getActivityName();
	if (activityName == 'Acknowledge Strat Cons Meeting') {
		var requestStatus = $('#pv_requestStatus').val();
		var resetSOSignature = $('#h_resetSOSignature').val();
		if (requestStatus == 'Pending Component Concurrence') {
			if (resetSOSignature == null || resetSOSignature == '') {
				clearSignature = true;
				$('#h_resetSOSignature').val('cleared');
			}
		}
	} else {
		$('#h_resetSOSignature').val('');
	}

	return clearSignature;
}

function stratconApr_rollbackHandler() {
	var SelOfcSigNameElm  = $("#SCA_SO_SIG");
	var SelOfcSigDtElm    = $("#SCA_SO_SIG_DT");
	var ClsSpcSigNameElm  = $("#SCA_CLASS_SPEC_SIG");
	var ClsSpcSigDtElm    = $("#SCA_CLASS_SPEC_SIG_DT");
	var StfSpcSigNameElm  = $("#SCA_STAFF_SIG");
	var StfSpcSigDtElm    = $("#SCA_STAFF_SIG_DT");

	// make all signature name/date fields readonly
	SelOfcSigNameElm.prop('readonly', true);
	SelOfcSigDtElm.prop('readonly', true);
	ClsSpcSigNameElm.prop('readonly', true);
	ClsSpcSigDtElm.prop('readonly', true);
	StfSpcSigNameElm.prop('readonly', true);
	StfSpcSigDtElm.prop('readonly', true);
}
