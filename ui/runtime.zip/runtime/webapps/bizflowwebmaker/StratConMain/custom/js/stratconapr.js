var ACT_SC_ACKNOWLEDGE = "Acknowledge Strat Cons Meeting";
var ACT_SC_APPROVE = "Approve Strat Cons Meeting";
var UG_SEL_OFC = "Selecing Official";
var UG_HR_CLS_SPC = "HR Classification Specialist";
var UG_HR_STF_SPC = "HR Staffing Specialist";

// onload event handler for APT tab page.
function initAprTab() {
	// make acknowledgement/approval checkboxes disabled depending on the current user's role as specified in General tab
	controlCheckboxPerUser();

	var SOCheckBox = $("#IS_SO_ACK"); 
	var SONameTextBox  = $("#SCA_SO_SIG");
	var SOSignDate    = $("#SCA_SO_SIG_DT");
	var ClassCheckBox = $("#IS_HR_CLS_SPC_APR");
	var ClassNameTextBox  = $("#SCA_CLASS_SPEC_SIG");
	var ClassSignDate    = $("#SCA_CLASS_SPEC_SIG_DT");
	var StaffCheckBox = $("#IS_HR_STF_SPC_APR");
	var StaffNameTextBox  = $("#SCA_STAFF_SIG");
	var StaffSignDate    = $("#SCA_STAFF_SIG_DT");

	// make all signature name/date fields readonly
	SONameTextBox.prop('readonly', true);
	SOSignDate.prop('readonly', true);
	ClassNameTextBox.prop('readonly', true);
	ClassSignDate.prop('readonly', true);
	StaffNameTextBox.prop('readonly', true);
	StaffSignDate.prop('readonly', true);

	// When checkbox is checked, capture name and date for Selecing Official
	// When the page is reloaded, if the name/date are populated, check the checkbox, otherwise uncheck
	// Initially, check if the value of dependent fields are populated.  Otherwise, uncheck.
	if ( (SONameTextBox != null && SONameTextBox.val() != null && SONameTextBox.val().length > 0)
		|| (SOSignDate != null && SOSignDate.val() != null && SOSignDate.val().length > 0) ) {
			SOCheckBox.prop("checked", true);
	} else {
		SOCheckBox.prop("checked", false);
	}

	// add event handler for the parent checkbox to capture name and date onto the dependent text fields
	SOCheckBox.change(function() {
		if ($(this).prop("checked")) {
			SONameTextBox.val($("#h_currentUserName").val()); // set current user name for signature
			SOSignDate.val(getMMDDYYYYDateStr(new Date()));  // set current date for signature
		} else {
			SONameTextBox.val("");
			SOSignDate.val("");
		}
	});

	// When checkbox is checked, capture name and date for HR Classification Specialist
	// When the page is reloaded, if the name/date are populated, check the checkbox, otherwise uncheck
	// Initially, check if the value of dependent fields are populated.  Otherwise, uncheck.
	if ( (ClassNameTextBox != null && ClassNameTextBox.val() != null && ClassNameTextBox.val().length > 0)
		|| (ClassSignDate != null && ClassSignDate.val() != null && ClassSignDate.val().length > 0) ) {
			ClassCheckBox.prop("checked", true);
	} else {
		ClassCheckBox.prop("checked", false);
	}

	// add event handler for the parent checkbox to capture name and date onto the dependent text fields
	ClassCheckBox.change(function() {
		// set or clear dependent field values
		if ($(this).prop("checked")) {
			ClassNameTextBox.val($("#h_currentUserName").val());  // set current user name for signature
			ClassSignDate.val(getMMDDYYYYDateStr(new Date()));   // set current date for signature
		} else {
			ClassNameTextBox.val("");
			ClassSignDate.val("");
		}
	});

	// When checkbox is checked, capture name and date for HR Staffing Specialist
	// When the page is reloaded, if the name/date are populated, check the checkbox, otherwise uncheck
	// Initially, check if the value of dependent fields are populated.  Otherwise, uncheck.
	if ( (StaffNameTextBox != null && StaffNameTextBox.val() != null && StaffNameTextBox.val().length > 0)
		|| (StaffSignDate != null && StaffSignDate.val() != null && StaffSignDate.val().length > 0) ) {
			StaffCheckBox.prop("checked", true);
	} else {
		StaffCheckBox.prop("checked", false);
	}

	// add event handler for the parent checkbox to capture name and date onto the dependent text fields
	StaffCheckBox.change(function() {
		if ($(this).prop("checked")) {
			StaffNameTextBox.val($("#h_currentUserName").val());  // set current user name for signature
			StaffSignDate.val(getMMDDYYYYDateStr(new Date()));   // set current date for signature
		} else {
			StaffNameTextBox.val("");  // clear name
			StaffSignDate.val("");    // clear date
		}
	});

	if (shouldClearSignatures() == true) {
		SOCheckBox.prop('checked', false);
		SONameTextBox.val('');
		SOSignDate.val('');

		ClassCheckBox.prop('checked', false);
		ClassNameTextBox.val('');
		ClassSignDate.val('');

		StaffCheckBox.prop('checked', false);
		StaffNameTextBox.val('');
		StaffSignDate.val('');
	}

	// hide Staffing Specialist section if Request Type is "Classification Only"
	// add event handler for Request Type to show/hide Staffing Specialist section
	$("#SG_RT_ID").on("change", showHideApprovalSection);
	$('#SG_CT_ID').on('change', showHideApprovalSection);
	showHideApprovalSection();

	$(document).trigger('CMS_CON_APR_INIT_COMPLETED');

} // end initAprTab()

function onChangeRequestType() {
	var requestType = $('#SG_RT_ID :selected').text();
	if (requestType != null && requestType == "Classification Only") {
		$("#hr_stf_spc_group").hide();
	} else {
		$("#hr_stf_spc_group").show();
	}
}

function showHideApprovalSection() {
	var processVersion = CMSUtility.getProcessVersion();
	var requestType = $('#SG_RT_ID :selected').text();
	var classificationType = $('#SG_CT_ID :selected').text();

	if (requestType != null && requestType == "Classification Only") {
		$("#hr_stf_spc_group").hide();
	} else {
		$("#hr_stf_spc_group").show();
	}

	if (processVersion >= 2) {
		if (requestType == 'Classification Only') {
			var classTypeToHideSO = ['Update Coversheet', 'Reorganization Pen & Ink', 'Review Existing Position Description'];
			if (CMSUtility.existInArray(classTypeToHideSO, classificationType) == true) {
				// SO is not the participant, so should clear values.
				$("#IS_SO_ACK").prop('checked', false);
				$("#SCA_SO_SIG").val('');
				$("#SCA_SO_SIG_DT").val('');
	
				$('#so_group').hide();
			} else {
				$('#so_group').show();
			}
		} else if (requestType == 'Appointment') {
			if (classificationType == 'Review Existing Position Description') {
				// SO is not the participant, so should clear values.
				$("#IS_SO_ACK").prop('checked', false);
				$("#SCA_SO_SIG").val('');
				$("#SCA_SO_SIG_DT").val('');
				$('#so_group').hide();

				// Special Program Specialist group is participant, but will be excluded from Approval. Should maintain values.
				$('#hr_stf_spc_group').hide();
			} else {
				$('#so_group').show();
			}
		}
	}
}

/**
 * Gets date string in MM/dd/yyyy format.
 *
 * @param inputDt - Date object
 * @return - a string for the given date in MM/dd/yyyy format.
 *           In case of error, returns empty string.
 */
function getMMDDYYYYDateStr(inputDt){
	var dateString = '';
	if (inputDt != null && inputDt instanceof Date) {
		dateString = CMSUtility.getDateString({isUTC: false, dateFormat: 'mm/dd/yyyy'}, inputDt);
	}
	return dateString;
}

// Controls enable/disable of checkboxes for acknowledgement or approval
// depending on the current user's role specified in General tab.
function controlCheckboxPerUser(){
	var SOCheckBox = $("#IS_SO_ACK");
	var ClassCheckBox = $("#IS_HR_CLS_SPC_APR");
	var StaffCheckBox = $("#IS_HR_STF_SPC_APR");
	var currentUserMemberID = $("#h_currentUserMemberID").val();

	if (typeof currentUserMemberID != "undefined" && currentUserMemberID != null && currentUserMemberID.length == 10) {
		// compare with Selecing Official
		if (currentUserMemberID == $("#SG_SO_ID").val()) {
			SOCheckBox.prop("disabled", false);
			SOCheckBox.attr("_required", true);
		} else {
			SOCheckBox.prop("disabled", true);
			SOCheckBox.attr("_required", false);
		}
		// compare with HR Classification Specialist
		if (currentUserMemberID == $("#SG_CS_ID").val()) {
			ClassCheckBox.prop("disabled", false);
			ClassCheckBox.attr("_required", true);
		} else {
			ClassCheckBox.prop("disabled", true);
			ClassCheckBox.attr("_required", false);
		}
		// compare with HR Staffing Specialist or Special Program Staffing Specialist
		if (currentUserMemberID == $("#SG_SS_ID").val()
				|| currentUserMemberID == $("#SG_SP_ID").val()) {
				StaffCheckBox.prop("disabled", false);
				StaffCheckBox.attr("_required", true);
		} else {
			StaffCheckBox.prop("disabled", true);
			StaffCheckBox.attr("_required", false);
		}
	} else {
		SOCheckBox.prop("disabled", true);
		SOCheckBox.attr("_required", false);
		ClassCheckBox.prop("disabled", true);
		ClassCheckBox.attr("_required", false);
		StaffCheckBox.prop("disabled", true);
		StaffCheckBox.attr("_required", false);
	}
} // end controlCheckboxPerUser()

function shouldClearSignatures() {
	var clearSignature = false;
	var activityName = BFActivityOption.getActivityName();
	if (activityName == 'Acknowledge Strat Cons Meeting') {
		var requestStatus = $('#pv_requestStatus').val();
		var resetSOSignature = $('#h_resetSOSignature').val();
		if (requestStatus == 'Pending Component Concurrence') {
			if (resetSOSignature == null || resetSOSignature == '') {
				clearSignature = true;
				$('#h_resetSOSignature').val('cleared');
			}
		}
	} else {
		$('#h_resetSOSignature').val('');
	}

	return clearSignature;
}

function stratconApr_rollbackHandler() {
	// make all signature name/date fields readonly
	$("#SCA_SO_SIG").prop('readonly', true);
	$("#SCA_SO_SIG_DT").prop('readonly', true);
	$("#SCA_CLASS_SPEC_SIG").prop('readonly', true);
	$("#SCA_CLASS_SPEC_SIG_DT").prop('readonly', true);
	$("#SCA_STAFF_SIG").prop('readonly', true);
	$("#SCA_STAFF_SIG_DT").prop('readonly', true);
}
