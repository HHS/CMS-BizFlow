/**
 * onload event handler for TR tab page
 */
function initTrTab(){

	//-----------------------------------------------------
	// initiate each group of target recruitment fields 
	//-----------------------------------------------------
	initTargetRecruitGroup("TR_PAID_AD"); // Paid Advertisement
	initTargetRecruitGroup("TR_SCHL_PSTG"); // School/University Posting
	initTargetRecruitGroup("TR_SOCIAL_MEDIA"); // CMS Sponsored Social Media
	
	//-------------------------------------------------------------------------
	// show Specify field for Other only the associated checkbox is checked
	//-------------------------------------------------------------------------
	//debug
	//console.log("onload event, check status of TR_OTHER = " + $("#TR_OTHER").prop("checked"));
	
	// add event handler for the parent checkbox to show/hide dependent text field
	$("#TR_OTHER").on("change", function() {
		//debug
		//console.log("change event, check status of TR_OTHER = " + $(this).prop("checked"));
		controlOtherSpecifyGroup($(this).prop("checked"));
	});
	
	//------------------------------------------
	// trigger events for initial processing
	//------------------------------------------
	$("#TR_OTHER").trigger("change");
	
} // end initTrTab()


/**
 * Initializes the related elements for each targeted recruitment group.
 *
 * The main checkbox determines show/hide of the associated fields.
 * The selection dropdown provides all available options.
 * The Selected Item field is multi-checkboxes.  It contains exactly same options as the selection dropdown but only selected items will be displayed.
 * 
 * @param sectionElemId - Element ID for the driving checkbox field.
 *     "TR_PAID_AD" - Paid Advertisement
 *     "TR_SCHL_PSTG" - School/University Posting
 *     "TR_SOCIAL_MEDIA" - CMS Sponsored Social Media
 */
function initTargetRecruitGroup(sectionElemId){
	//debug
	//console.log("initTargetRecruitGroup(): sectionElemId = " + sectionElemId);
	var sectionGroupId = "";
	if ("TR_PAID_AD" == sectionElemId) {
		sectionGroupId = "paid_ad";
	} else if ("TR_SCHL_PSTG" == sectionElemId) {
		sectionGroupId = "sch_univ";
	} else if ("TR_SOCIAL_MEDIA" == sectionElemId) {
		sectionGroupId = "soc_med";
	} else {
		return;
	}
	
	// initially, show/hide field depending on the initial status of checkbox
	if ($("#"+sectionElemId).prop("checked")) {
		$("#"+sectionGroupId+"_spec_group").show();
		// if Other option selected, show textbox, otherwise hide it
		var paidAdOtherId = $("label[class~=checkbox][for^="+sectionElemId+"_SPEC]").filter(function(){return $(this).text()==="Other";}).attr("for");
		if ($("#"+paidAdOtherId).prop("checked")) {
			$("#"+sectionGroupId+"_spec_other_group").show();
		} else {
			$("#"+sectionGroupId+"_spec_other_group").hide();
		}
	} else {
		$("#"+sectionGroupId+"_spec_group").hide();
		// when hiding, clear value, too
		$("input[type=checkbox][name="+sectionElemId+"_SPEC]").prop("checked", false);
		$("input[type=checkbox][name="+sectionElemId+"_SPEC]").prop("checked", false).parent().parent().hide();
		$("#"+sectionElemId+"_SPEC_OTHR").val("");
	}
	
	// add event handler for the parent checkbox to show/hide dependent text field
	$("#"+sectionElemId).on("change", function() {
		//debug
		//console.log("change event, check status of "+sectionElemId+" = " + $(this).prop("checked"));
		
		if ($(this).prop("checked")) {
			$("#"+sectionGroupId+"_spec_group").show();
			// if Other option selected, show textbox, otherwise hide it
			var paidAdOtherIdOnchange = $("label[class~=checkbox][for^="+sectionElemId+"_SPEC]").filter(function(){return $(this).text()==="Other";}).attr("for");
			if ($("#"+paidAdOtherIdOnchange).prop("checked")) {
				$("#"+sectionGroupId+"_spec_other_group").show();
				var textBoxID = $('input', '#' + sectionGroupId + '_spec_other_group').attr('id')
				CMSUtility.setCaret(textBoxID)
			} else {
				$("#"+sectionGroupId+"_spec_other_group").hide();
			}
		} else {
			$("#"+sectionGroupId+"_spec_group").hide();
			// when hiding, clear value, too
			$("input[type=checkbox][name="+sectionElemId+"_SPEC]").prop("checked", false);
			$("input[type=checkbox][name="+sectionElemId+"_SPEC]").prop("checked", false).parent().parent().hide();
			$("input[type=checkbox][name="+sectionElemId+"_SPEC]").trigger("change");
		}
	});
		
	// initially, show checked items and hide unchecked items according to the loaded data in "Selected Item" display
	$("input[type=checkbox][name="+sectionElemId+"_SPEC]").filter(function(){ return $(this).prop("checked"); }).parent().parent().show();
	$("input[type=checkbox][name="+sectionElemId+"_SPEC]").filter(function(){ return !$(this).prop("checked"); }).parent().parent().hide();
	
	// add event handler to the selectbox - whenever selection is made, it should be synced up in the "Selected Item" data element
	$("#"+sectionElemId+"_SEL").on("change", function(){
		var trPaidAdSelVal = $(this).children("option:selected").val();
		var trPaidAdSelText = $(this).children("option:selected").text();
		if (typeof trPaidAdSelVal != "undefined" && trPaidAdSelVal != null) {
			
			// capture the selected item and set the multiselect checkbox area
			var paidAdChkElm = $("input[type=checkbox][name="+sectionElemId+"_SPEC][value=" + trPaidAdSelVal + "]");
			if (paidAdChkElm.length > 0) {  // the length should really be 1 if correctly identified
				paidAdChkElm.prop("checked", true);
				$("label[for=" + paidAdChkElm[0].id + "]").parent().removeClass("selected");
				$("label[for=" + paidAdChkElm[0].id + "]").parent().addClass("selected");
				paidAdChkElm.parent().parent().show();  // show parent/parent <tr><td><input ...
			}
			$("input[type=checkbox][name="+sectionElemId+"_SPEC]").trigger("change");
		}
		// after select propagation is done to selected item checkbox list, clear current select from dropdown
		$(this).val("");
	});
		
	// add event handler to the selected item element - whenever checkbox is unched, it should be hidden from the "Selected Item" display
	$("input[type=checkbox][name="+sectionElemId+"_SPEC]").on("change", function(){
		var paidAdSelectedText = $("label[class~=checkbox][for=" + $(this)[0].id + "]").text();  // there should really be 1 element selected
		if ($(this).prop("checked")) {
			if (paidAdSelectedText === "Other") {
				$("#"+sectionGroupId+"_spec_other_group").show();
				var textBoxID = $('input', '#' + sectionGroupId + '_spec_other_group').attr('id')
				CMSUtility.setCaret(textBoxID)
			}
		} else {
			$(this).parent().parent().hide();  // hide parent/parent <tr><td><input ...
			if (paidAdSelectedText === "Other") {
				$("#"+sectionGroupId+"_spec_other_group").hide();
				$("#"+sectionElemId+"_SPEC_OTHR").val("");
			}
		}
		
		// if no selected items left, set attribute for error check.  Otherwise, unset attribute to avoid error.
		if ($("input[type=checkbox][name="+sectionElemId+"_SPEC]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
			$("#"+sectionElemId+"_SEL").attr("_required", "true");
		} else {
			$("#"+sectionElemId+"_SEL").attr("_required", "false");
		}
	});
} // end initTargetRecruitGroup()


/**
 * Controls the Other Specify textbox depending on the associated check status.
 *
 * @param isChecked - boolean value for the checkbox of Other Specify
 */
function controlOtherSpecifyGroup(isChecked){
	//debug
	//console.log("controlOtherSpecifyGroup(): isChecked = " + isChecked);
	if (typeof isChecked != "undefined" && isChecked != null && isChecked) {
		$("#other_spec_group").show();
		CMSUtility.setCaret('TR_OTHER_SPEC');
	} else {
		$("#other_spec_group").hide();
		$("#TR_OTHER_SPEC").val("");  // when hiding, clear value, too
	}
}


/**
 * Performs validation for customized elements in this page.
 * 
 * @return true - validation successful
 *         false - validation failed (not completely successful)
 *
 * Note: This function is intended to be called from main form for as part of tab nagivation or page save action.
 */
function validateStratconTrCustom(){
	
	var validationResult = true;
	
	//-------------------------------------------------------------------------
	// In order to use WebMaker error handling framework, we need to set
	// custom attributes of the validated element dynamically
	// 	_required = true, false
	// 	_type = string, number, boolean, date
	// 	_length = 1,2,3,...
	//-------------------------------------------------------------------------
	
	//----------------------------------------
	// TR_PAID_AD section validation
	//----------------------------------------
	if ($("#TR_PAID_AD").prop("checked")
			&& $("input[type=checkbox][name=TR_PAID_AD_SPEC]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
		validationResult = false;
		//  slection becomes required, but no selection is made - set required attribute for error check
		$("#TR_PAID_AD_SEL").attr("_required", "true");
	} else {
		// reset required attribute since already selected
		$("#TR_PAID_AD_SEL").attr("_required", "false");
	}
	
	//----------------------------------------
	// TR_SCHL_PSTG section validation
	//----------------------------------------
	if ($("#TR_SCHL_PSTG").prop("checked")
			&& $("input[type=checkbox][name=TR_SCHL_PSTG_SPEC]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
		validationResult = false;
		// slection becomes required, but no selection is made - set required attribute for error check
		$("#TR_SCHL_PSTG_SEL").attr("_required", "true");
	} else {
		// reset required attribute since already selected
		$("#TR_SCHL_PSTG_SEL").attr("_required", "false");
	}
	
	//----------------------------------------
	// TR_SOCIAL_MEDIA section validation
	//----------------------------------------
	if ($("#TR_SOCIAL_MEDIA").prop("checked")
			&& $("input[type=checkbox][name=TR_SOCIAL_MEDIA_SPEC]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
		validationResult = false;
		//  slection becomes required, but no selection is made - set required attribute for error check
		$("#TR_SOCIAL_MEDIA_SEL").attr("_required", "true");
	} else {
		// reset required attribute since already selected
		$("#TR_SOCIAL_MEDIA_SEL").attr("_required", "false");
	}
	
	// hyf.validation.validateContainer(document.getElementById("section_tr_group"));
	
	return validationResult;
} // end validateStratconTrCustom()
