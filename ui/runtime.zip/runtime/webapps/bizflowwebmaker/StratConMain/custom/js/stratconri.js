/**
 * onload event handler for RI tab page
 */
function initRiTab(){
} // end initRiTab()
