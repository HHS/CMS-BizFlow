var ConductIssue = {
    initialized: false,
	groups : ['action_AdministrativeLeave_group','admin_leave_investigatory_group',
	'action_Reprimand_group','action_Suspension_group','termination_type_pre_employment_group',
	'termination_type_probation_group','suspension_oral_presentation_group','oral_presentation_date_group',
	'written_response_group','admin_leave_notice_group','action_Demotion_group','action_Counseling_group',
	'action_SickLeaveRestriction_group','action_SickLeaveWarning_group','action_Reassignment_group',
	'action_Removal_group','pre_emp_termination_oral_presentation_group','pre_emp_termination_response_group',
	'suspension_written_response_group','action_Termination_group'],
	actionTypes :['admin_leave','alt_discipline','removal_notice_date_group','removal_oral_presentation_group','removal_written_response_group'],
    init: function () {
        //implementation of initialization logic
		$('#add_review_date,#add_extended_date,#slw_add_date').on('click',addDate);
		$('#admin_leave_clear, #admin_leave_ntc_clear').on('click',clear);
		
		ConductIssue.groups.forEach(function(el,index){
				hyf.util.hideComponent(el);
		});
		hyf.calendar.setDateConstraint('leave_start', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('leave_start_2', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('date_decision_issued', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('date_propose_action_issued', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('date_counsel_issued', 'Maximum', 'Today');	
		hyf.calendar.setDateConstraint('sick_leave_date_reviewed', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('sick_leave_date_extended', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('removal_prop_action_date', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('date_counsel_issued', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('sick_leave_date_removed', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('sl_warning_discussion_date', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('sl_warn_issue', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('removal_effective_date', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('oral_presentation_date', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('written_response_date', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('date_decision_issued', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('effective_date', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('date_notice_issued', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('reprimand_issue_date', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('dt_restriction_issed', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('pre_emp_termination_oral_presentation_date', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('pre_probation_termination_decision_issued_date', 'Maximum', 'Today');
		
    },
    render: function (){
		var leaveDtStart = FormState.getState('leave_start');
		var leaveDtEnd = FormState.getState('leave_end');
		var leaveDtStart2 = FormState.getState('leave_start_2');
		var leaveDtEnd2 = FormState.getState('leave_end_2');
        var decision_issued_date = FormState.getState('date_decision_issued');
		var dt_reviewed = FormState.getState('rv_dt_selected');
		var dt_extended = FormState.getState('ex_dt_selected');
		var actionType = FormState.getState('action_type');
		var sickLeaveWarning = FormState.getState('slw_discussion_dt');
		var admin_leave = FormState.getState('admin_leave_type');
		var oral_presentation = FormState.getState('oral_presentation_requested');
		
		var removalEmployeePlacedLeaveNotice = FormState.getState('employee_notice_leave_placed');
		var removalOral_presentation = FormState.getState('removal_oral_presentaion_requested');
		var removalWritten_ResponseSubmitted = FormState.getState('removal_written_response');
		
		var terminationOral_presentation = FormState.getState('pre_emp_termination_oral_pres_requested');
		var terminationWritten_ResponseSubmitted = FormState.getState('pre_emp_termination_written_resp');
		
		var written_response_requested = FormState.getState('oral_response_submitted');
		var admin_leave_investigatory = FormState.getState('admin_investigatory_leave');
		var admin_leave_notice = FormState.getState('admin_notice_leave');
		var emp = FormState.getState('empContact');
		var terminationType = FormState.getState('termination_type');
		
		var suspensionOralPresentation = FormState.getState('suspension_oral_pres_requested');
		var suspensionWrittenPresentation = FormState.getState('suspension_written_resp');
		//var c = FormState.getState('termination_type');
		if((terminationOral_presentation && terminationOral_presentation.dirty)){
			hyfShowOrHide(terminationOral_presentation,'pre_emp_termination_oral_presentation_group');
		}
		if((terminationWritten_ResponseSubmitted && terminationWritten_ResponseSubmitted.dirty)){
			hyfShowOrHide(terminationWritten_ResponseSubmitted,'pre_emp_termination_response_group');
		}
		
		if((terminationType && terminationType.dirty)){
			terminationationTpe(terminationType.value);
		}
		
		if((removalOral_presentation && removalOral_presentation.dirty)){
			hyfShowOrHide(removalOral_presentation,'removal_oral_presentation_group');
		}
		if((removalEmployeePlacedLeaveNotice && removalEmployeePlacedLeaveNotice.dirty)){
			hyfShowOrHide(removalEmployeePlacedLeaveNotice,'removal_notice_date_group');
		}
		if((removalWritten_ResponseSubmitted && removalWritten_ResponseSubmitted.dirty)){
			hyfShowOrHide(removalWritten_ResponseSubmitted,'removal_written_response_group');
		}
		if((suspensionOralPresentation && suspensionOralPresentation.dirty)){
			hyfShowOrHide(suspensionOralPresentation,'suspension_oral_presentation_group');
		}
		if((suspensionWrittenPresentation && suspensionWrittenPresentation.dirty)){
			hyfShowOrHide(suspensionWrittenPresentation,'suspension_written_response_group');
		}
		if((leaveDtStart && leaveDtStart.dirty)||(leaveDtEnd && leaveDtEnd.dirty)){
			dateValidate({id:'investigatory',value1: leaveDtStart.value,value2:leaveDtEnd.value},'Invalid leave end date. Leave end date must come after start date.','leave_end');
		}
		if((leaveDtStart2 && leaveDtStart2.dirty)||(leaveDtEnd2 && leaveDtEnd2.dirty)){
			dateValidate({id:'notice',value1:leaveDtStart2.value,value2:leaveDtEnd2.value},'Invalid leave end date. Leave end date must come after start date.','leave_end_2');
		}
		if(decision_issued_date && decision_issued_date.dirty){
			dateDecisionIssued();
		}
		if(dt_reviewed && dt_reviewed.dirty){
			addDate({id:'add_review_date',value:dt_reviewed.value});
		}
		if(dt_extended && dt_extended.dirty){
			addDate({id:'add_extended_date',value:dt_extended.value});
		}
		if(sickLeaveWarning && sickLeaveWarning.dirty){
			addDate({id:'slw_add_date',value:sickLeaveWarning.value});
		}
		if(actionType && actionType.dirty){
			var temp = actionType.value;
			showCaseView('action_'+temp.replace(/\s/g,'')+'_group');
		}
		if(oral_presentation && oral_presentation.dirty){
			hyfShowOrHide(oral_presentation,'oral_presentation_date_group');
		}
		if(written_response_requested && written_response_requested.dirty){
			hyfShowOrHide(written_response_requested,'written_response_group');
		}
		
		if((admin_leave_investigatory && admin_leave_investigatory.dirty)){
			hyfShowOrHide(admin_leave_investigatory,'admin_leave_investigatory_group');	
		}
		if((admin_leave_notice && admin_leave_notice.dirty)){
			hyfShowOrHide(admin_leave_notice,'admin_leave_notice_group');	
		}
		if((emp && emp.dirty)){
			populateCurrentPosition(emp.value);		
		}
		if(!ConductIssue.initialized){		
			FormAutoComplete.setAutoComplete('approval_name','/bizflowwebmaker/erlr_AutoCompleteService/contactInfo.do?cust=',populateOfficial,responseMapper,appendInfo);
			FormAutoComplete.setAutoComplete('approval_name_2','/bizflowwebmaker/erlr_AutoCompleteService/contactInfo.do?cust=',populateOfficial,responseMapper,appendInfo);
			FormAutoComplete.setAutoComplete('deciding_official','/bizflowwebmaker/erlr_AutoCompleteService/contactInfo.do?cust=',populateOfficial,responseMapper,appendInfo);
			FormAutoComplete.setAutoComplete('suspension_deciding_official_name','/bizflowwebmaker/erlr_AutoCompleteService/contactInfo.do?cust=',populateOfficial,responseMapper,appendInfo);
			FormAutoComplete.setAutoComplete('termination_deciding_official_name','/bizflowwebmaker/erlr_AutoCompleteService/contactInfo.do?cust=',populateOfficial,responseMapper,appendInfo);
			ConductIssue.initialized = true;
		}
    }
};
function dateValidate(e,msg,target){
	var days = 0;
	var dt1 = '';
	var dt2 = ''
	if(e.id !=='' && (e.value1 !=undefined || e.value2 !=undefined)){
		dt1 = e.value1;
		dt2 = e.value2;
	}
	if((dt2 && dt2 !== '') ||(dt1 && dt1 !== '')){
		var m1  = moment(dt1);
		var m2 = moment(dt2);
		days = m2.diff(m1,'days');
		if(days >= 0 && e.id ==='investigatory'){
			$('#leave_length').text(days +' Day(s)');
		}else if(days >= 0 && e.id ==='notice'){
			$('#leave_length_2').text(days +' Day(s)');
		}else if((days < 0 && e.id !=='')){
			bootbox.alert({
            message: msg,//'Invalid leave end date. Leave end date must come after start date.',
            callback: function(){
                $('#' +target).val('');
            }
        });
		}
	}
}

function terminationationTpe(e){
	if(e ==='pre_emp'){
		hyf.util.showComponent('termination_type_pre_employment_group');
		hyf.util.hideComponent('termination_type_probation_group');
	}else if(e==='probation'){
		hyf.util.showComponent('termination_type_probation_group');
		hyf.util.hideComponent('termination_type_pre_employment_group');
	}else{
		hyf.util.hideComponent('termination_type_pre_employment_group');
		hyf.util.hideComponent('termination_type_probation_group');
	}
}

function dateDecisionIssued(e){
	var days = 0;
	var dt1 = $('#date_propose_action_issued').val();
	var dt2 = $('#date_decision_issued').val();
	if(dt2 && dt1){
		var m1  = moment(dt1);
		var m2 = moment(dt2);
		if(m2.isBefore(m1)){
			bootbox.alert({
            message: 'Date must be greater than Date Proposed Action Issued to Employee Date.',
            callback: function(){
                $('#date_decision_issued').val('');
            }
        });
	}
}
}
function addDate(e){
	var hidden ='',selectionId= '',selected ='',date ='';
	var target = e.target ? e.target.id : e.id;
	if(target){
		if(target === 'add_review_date'){
			hidden = 'rv_dt_selected';
			selectionId = 'rv_indecator';
			date =$('#sick_leave_date_reviewed').val();
			selected = e.value ? e.value: $('#' + hidden).val();
		}else if(target === 'add_extended_date'){
			hidden = 'ex_dt_selected';
			selectionId = 'ex_dt_indeicator';
			date = $('#sick_leave_date_extended').val();
			selected = e.value ? e.value: $('#' + hidden).val();
		}else if(target === 'slw_add_date'){
			hidden = 'slw_discussion_dt';
			selectionId = 'sick_leave_warning';
			date = $('#sl_warning_discussion_date').val();
			selected = e.value ? e.value: $('#' + hidden).val();
		}		
		if( selected !=='' && selected.indexOf(',') > -1){
			var arr = selected.split(',');
			arr.push(date);
			var tempArr =[];
			arr.forEach(function(el){
				if($.inArray(el,tempArr)=== -1 && el !==''){
					tempArr.push(el);
				}
			});
			arr = null;
			$('#' + selectionId).html('');
			tempArr.sort(function(a,b){
				return moment(a).isBefore(moment(b)) || moment(a).isSame(moment(b));
			})
			.forEach(function(el){
				$('#'+selectionId).append('<label id="'+el.replace(/\//g,'')+'"><span style="color:red;padding:5px;" onclick="removeItem('+el.replace(/\//g,'')+')" title="Remove date.">X</span>'+el+'</label><br/>');
			});
		$('#'+hidden).val(tempArr.join());
		FormState.doActionNoRender(StateAction.changeText(hidden,tempArr.join()));			
		}else{
			$('#'+selectionId).append('<label id="'+date.replace(/\//g,'')+'"><span style="color:red;padding:5px;" onclick="removeItem('+date.replace(/\//g,'')+')" title="Remove date.">X</span>'+date+'</label><br/>');
			date = date +',';
			$('#'+hidden).val(date);
			FormState.doActionNoRender(StateAction.changeText(hidden,date));
		}
	}
}
function showCaseView (caseValue){
		ConductIssue.groups.forEach(function(el,index){
			if(el === caseValue){
				hyf.util.showComponent(el);	
			}else{	
				hyf.util.hideComponent(el);
			}			
		});
	}
function populateOfficial(item,id){
	if(id ==='approval_name' && (item.last_name !==''||item.first_name !=='')){
		$('#approval_name').val(item.last_name +','+item.first_name);
	}
	if(id ==='approval_name_2' && item.value !==''){
		$('#approval_name_2').val(item.last_name +','+item.first_name);
	}
	if(id ==='deciding_official' && item.value !==''){
		$('#deciding_official').val(item.last_name +','+item.first_name);
	}
	
	if(id ==='suspension_deciding_official_name' && item.value !==''){
		$('#suspension_deciding_official_name').val(item.last_name +','+item.first_name);
	}
	if(id ==='termination_deciding_official_name' && item.value !==''){
		$('#termination_deciding_official_name').val(item.last_name +','+item.first_name);
	}
}
function clear(item){
	if(item.target.id === 'admin_leave_clear'){
		$('#approval_name').val('');
	}
	if(item.target.id === 'admin_leave_ntc_clear'){
		$('#approval_name_2').val('');
	}
	if(item.target.id !=='' && item !== ''){
		$('#' +item).val('');
	}
	if(item !=='' && item !== ''){
		$('#' +item).val('');
	}
}
function populateCurrentPosition(item){
	var currentPosition = item.split(',');
	$('#pos_title').text(currentPosition[8]);
	$('#pplan').text(currentPosition[6]);
	$('#series').text(currentPosition[7]);
	$('#current_info_step').text(currentPosition[4]);
	$('#current_info_grade').text(currentPosition[5]);//curr_admin_code
	$('#current_info_grade').text(currentPosition[2]);
}
function hyfShowOrHide(item,id){
	if(item.value ==='Y' ||Boolean(item.value)){
		hyf.util.showComponent(id);
	}else{
		hyf.util.hideComponent(id);
	}
}
function removeItem(e){
	$('#' + e).parent().remove();
}