var ConductIssue = {
    initialized: false,
	groups : ['action_AdministrativeLeave_group','admin_leave_investigatory_group',
	'action_Reprimand_group','action_Suspension_group','termination_type_pre_employment_group',
	'termination_type_probation_group','suspension_oral_presentation_group','oral_presentation_date_group',
	'written_response_group','admin_leave_notice_group','action_Demotion_group','action_Counseling_group',
	'action_SickLeaveRestriction_group','action_SickLeaveWarning_group','action_Reassignment_group',
	'action_Removal_group','pre_emp_termination_oral_presentation_group','pre_emp_termination_response_group',
	'suspension_written_response_group','action_Termination_group','oral_presentation_date_group',
	'written_response_group','removal_notice_date_group','removal_oral_presentation_group',
	'removal_written_response_group','suspension_oral_presentation_group','suspension_written_response_group',
	'pre_emp_termination_oral_presentation_group','pre_emp_termination_response_group','reassignment_date_notice_issued'],
	actionTypes :['admin_leave','alt_discipline','removal_notice_date_group','removal_oral_presentation_group','removal_written_response_group'],
	dateFields : ['leave_start','leave_start_2','leave_end','leave_end_2','date_decision_issued','date_propose_action_issued','date_counsel_issued',
				'sick_leave_date_reviewed','sick_leave_date_extended','removal_prop_action_date','date_counsel_issued','sick_leave_date_removed',
				'sl_warning_discussion_date','sl_warn_issue','removal_effective_date','oral_presentation_date','written_response_date','removal_date_decision_issued',
				'effective_date','date_notice_issued','reprimand_issue_date','dt_restriction_issed','pre_emp_termination_oral_presentation_date',
				'pre_probation_termination_decision_issued_date','pre_probation_termination_decision_issued_date','removal_notice_start_dt',
				'removal_notice_end_dt','removal_oral_presentation_dt','date_written_submitted','written_response_due_date','date_written_presentation_received',
				'suspension_proposed_action_date','suspension_oral_presentation_date','suspension_written_resp_date','suspension_written_resp_due_date',
				'suspension_decision_issued_date','pre_emp_termination_decision_issued_date','pre_emp_termination_written_resp_due_date',
				'pre_emp_termination_written_resp_date','pre_emp_termination_propose_date_action_date','sick_leave_date_issued','sick_leave_date_reviewed',
				'term_effective_decision_dt','suspension_effective_decision_date'],
    init: function (){
		$('#add_review_date,#add_extended_date,#slw_add_date').on('click',addDate);
		$('#admin_leave_clear, #admin_leave_ntc_clear').on('click',clear);
		ConductIssue.groups.forEach(function(el,index){
			hyf.util.hideComponent(el);
		});
		ConductIssue.dateFields.forEach(function(el,index){
			if(el !== ''){
				hyf.calendar.setDateConstraint(el, 'Maximum', 'Today');
			}
			
		});
		
    },
	grades : {'GP':['01','02','03','04','05','06','07','08','09','10','11','12','13','14','15'],
			'GR':['01','02','03','04','05','06','07','08','09','10','11','12','13','14','15'],
			'GS':['01','02','03','04','05','06','07','08','09','10','11','12','13','14','15'],
			'ES':['01','02','03','04','05','06'],
			'WG':['01','02','03','04','05','06','07','08','09','10']
	},
    render: function (){
		var leaveDtStart = FormState.getState('leave_start');
		var leaveDtEnd = FormState.getState('leave_end');
		var leaveDtStart2 = FormState.getState('leave_start_2');
		var leaveDtEnd2 = FormState.getState('leave_end_2');
        var decision_issued_date = FormState.getState('date_decision_issued');
		var dt_reviewed = FormState.getState('rv_dt_selected');
		var dt_extended = FormState.getState('ex_dt_selected');
		var actionType = FormState.getState('action_type');
		var sickLeaveWarning = FormState.getState('slw_discussion_dt');
		var admin_leave = FormState.getState('admin_leave_type');
		var oral_presentation = FormState.getState('oral_presentation_requested');//oral_response_submitted
		var appealDecision = FormState.getState('reprimand_appeal_decision');
		var removalEmployeePlacedLeaveNotice = FormState.getState('employee_notice_leave_placed');
		var removalOral_presentation = FormState.getState('removal_oral_presentaion_requested');
		var removalWritten_ResponseSubmitted = FormState.getState('removal_written_response');
		var terminationOral_presentation = FormState.getState('pre_emp_termination_oral_pres_requested');
		var terminationWritten_ResponseSubmitted = FormState.getState('pre_emp_termination_written_resp');	
		var written_response_requested = FormState.getState('oral_response_submitted');
		var admin_leave_investigatory = FormState.getState('admin_investigatory_leave');
		var admin_leave_notice = FormState.getState('admin_notice_leave');
		var emp = FormState.getState('empContact');
		var terminationType = FormState.getState('termination_type');
		var demotion_date_proposed_action_issued = FormState.getState('date_propose_action_issued');//oral_presentation_requested
		var removal_date_proposed_action_issued = FormState.getState('removal_prop_action_date');
		var removal_date_decision_issued = FormState.getState('removal_date_decision_issued');
		var suspensionOralPresentation = FormState.getState('suspension_oral_pres_requested');
		var suspensionWrittenPresentation = FormState.getState('suspension_written_resp');
		var suspensionDateActionProposed = FormState.getState('suspension_proposed_action_date');
		var suspensionDecisionIssued = FormState.getState('suspension_decision_issued_date');
		var reassignment_date_notice_issued	= FormState.getState('date_notice_issued');
		var termination_decision_issued = FormState.getState('pre_emp_termination_decision_issued_date');
		var termination_proposed_action_issued = FormState.getState('pre_emp_termination_propose_date_action_date');
		var proposed_pplan = FormState.getState('proposed_pplan');
		var final_pplan = FormState.getState('final_pplan');
		var proposedGradeInfo = FormState.getState('proposed_info_grade');
		var finalGradeInfo = FormState.getState('final_info_grade');
		
		if(final_pplan && final_pplan.dirty){
			populateGrades(final_pplan.value,'final_info_grade');
		}
		if(proposed_pplan && proposed_pplan.dirty){
			populateGrades(proposed_pplan.value,'proposed_info_grade');
		}
		if((termination_decision_issued && termination_decision_issued.dirty) || (termination_decision_issued && termination_decision_issued.dirty )){
			dateValidateHelper('pre_emp_termination_propose_date_action_date','pre_emp_termination_decision_issued_date','pre_emp_termination_propose_date_action_date');
		}
		if((reassignment_date_notice_issued && reassignment_date_notice_issued.dirty)){
			hyfShowOrHide(reassignment_date_notice_issued,'reassignment_date_notice_issued');
		}
		if((suspensionDateActionProposed && suspensionDateActionProposed.dirty) || (suspensionDecisionIssued && suspensionDecisionIssued.dirty )){
			dateValidateHelper('suspension_proposed_action_date','suspension_decision_issued_date','suspension_proposed_action_date');
		}
		if((removal_date_proposed_action_issued && removal_date_proposed_action_issued.dirty) || (removal_date_decision_issued && removal_date_decision_issued.dirty )){
			dateValidateHelper('removal_prop_action_date','removal_date_decision_issued','removal_prop_action_date');
		}
		if((decision_issued_date && decision_issued_date.dirty) || (demotion_date_proposed_action_issued && demotion_date_proposed_action_issued.dirty )){
			dateValidateHelper('date_decision_issued','date_propose_action_issued','date_propose_action_issued');
		}
		if((terminationOral_presentation && terminationOral_presentation.dirty)){
			hyfShowOrHide(terminationOral_presentation,'pre_emp_termination_oral_presentation_group');
		}
		if((terminationWritten_ResponseSubmitted && terminationWritten_ResponseSubmitted.dirty)){
			hyfShowOrHide(terminationWritten_ResponseSubmitted,'pre_emp_termination_response_group');
			dateAutoPopulate('pre_emp_termination_written_resp_date',$('#pre_emp_termination_oral_presentation_date').val());
		}
		if((terminationType && terminationType.dirty)){
			terminationationTpe(terminationType.value);
		}	
		if((removalOral_presentation && removalOral_presentation.dirty)){
			hyfShowOrHide(removalOral_presentation,'removal_oral_presentation_group');
		}
		if((removalEmployeePlacedLeaveNotice && removalEmployeePlacedLeaveNotice.dirty)){
			hyfShowOrHide(removalEmployeePlacedLeaveNotice,'removal_notice_date_group');
		}
		if((removalWritten_ResponseSubmitted && removalWritten_ResponseSubmitted.dirty)){
			hyfShowOrHide(removalWritten_ResponseSubmitted,'removal_written_response_group');
			dateAutoPopulate('date_written_submitted',$('#removal_oral_presentation_dt').val());
		}
		if((suspensionOralPresentation && suspensionOralPresentation.dirty)){
			hyfShowOrHide(suspensionOralPresentation,'suspension_oral_presentation_group');
		}
		if((suspensionWrittenPresentation && suspensionWrittenPresentation.dirty)){
			hyfShowOrHide(suspensionWrittenPresentation,'suspension_written_response_group');
			dateAutoPopulate('suspension_written_resp_date',$('#suspension_oral_presentation_date').val());
		}
		if((leaveDtStart && leaveDtStart.dirty)||(leaveDtEnd && leaveDtEnd.dirty)){
			dateValidate({id:'investigatory',value1: leaveDtStart.value,value2:leaveDtEnd.value},'Invalid leave end date. Leave end date must come after start date.','leave_end');
		}
		if((leaveDtStart2 && leaveDtStart2.dirty)||(leaveDtEnd2 && leaveDtEnd2.dirty)){
			dateValidate({id:'notice',value1:leaveDtStart2.value,value2:leaveDtEnd2.value},'Invalid leave end date. Leave end date must come after start date.','leave_end_2');
		}
		if(decision_issued_date && decision_issued_date.dirty){
			dateDecisionIssued();
		}
		if(dt_reviewed && dt_reviewed.dirty){
			addDate({id:'add_review_date',value:dt_reviewed.value});
		}
		if(dt_extended && dt_extended.dirty){
			addDate({id:'add_extended_date',value:dt_extended.value});
		}
		if(sickLeaveWarning && sickLeaveWarning.dirty){
			addDate({id:'slw_add_date',value:sickLeaveWarning.value});
		}
		if(actionType && actionType.dirty){
			var temp = actionType.value;
			showCaseView('action_'+temp.replace(/\s/g,'')+'_group',ConductIssue.groups);
			$('#Demotion_appeal_decision').val('');
			FormState.doActionNoRender(StateAction.changeText('Demotion_appeal_decision',''));
			$('#Removal_appeal_decision').val('');
			FormState.doActionNoRender(StateAction.changeText('Removal_appeal_decision',''));
			$('#Suspension_appeal_decision').val('');
			FormState.doActionNoRender(StateAction.changeText('Suspension_appeal_decision',''));
			$('#pre_emp_Termination_appeal_decision').val('');
			FormState.doActionNoRender(StateAction.changeText('pre_emp_Termination_appeal_decision',''));
			$('#Reprimand_appeal_decision').val('');
			FormState.doActionNoRender(StateAction.changeText('Reprimand_appeal_decision',''));
			cms_case_track_main.actionOnChange('Demotion_appeal_decision');
		}	
		if(oral_presentation && oral_presentation.dirty){
			hyfShowOrHide(oral_presentation,'oral_presentation_date_group');
			
		}
		if(written_response_requested && written_response_requested.dirty){
			hyfShowOrHide(written_response_requested,'written_response_group');
			dateAutoPopulate('written_response_date',$('#oral_presentation_date').val());
		}
		if((admin_leave_investigatory && admin_leave_investigatory.dirty)){
			hyfShowOrHide(admin_leave_investigatory,'admin_leave_investigatory_group');	
		}
		if((admin_leave_notice && admin_leave_notice.dirty)){
			hyfShowOrHide(admin_leave_notice,'admin_leave_notice_group');	
		}
		if((emp && emp.dirty)){
			populateCurrentPosition(emp.value);		
		}
		if(!ConductIssue.initialized){		
			FormAutoComplete.setAutoComplete('approval_name','/bizflowwebmaker/erlr_AutoCompleteService/contactInfo.do?cust=',populateOfficial,responseMapper,appendInfo);
			FormAutoComplete.setAutoComplete('approval_name_2','/bizflowwebmaker/erlr_AutoCompleteService/contactInfo.do?cust=',populateOfficial,responseMapper,appendInfo);
			FormAutoComplete.setAutoComplete('deciding_official','/bizflowwebmaker/erlr_AutoCompleteService/contactInfo.do?cust=',populateOfficial,responseMapper,appendInfo);
			FormAutoComplete.setAutoComplete('suspension_deciding_official_name','/bizflowwebmaker/erlr_AutoCompleteService/contactInfo.do?cust=',populateOfficial,responseMapper,appendInfo);
			FormAutoComplete.setAutoComplete('termination_deciding_official_name','/bizflowwebmaker/erlr_AutoCompleteService/contactInfo.do?cust=',populateOfficial,responseMapper,appendInfo);
			FormAutoComplete.setAutoComplete('deciding_official_name','/bizflowwebmaker/erlr_AutoCompleteService/contactInfo.do?cust=',populateOfficial,responseMapper,appendInfo);
			FormAutoComplete.setAutoComplete('final_admin_code','/bizflowwebmaker/erlr_AutoCompleteService/contactInfo.do?admin=',populateAdminCode,adminCodeResponseMapper,appendAdminCode);
			dynamicMandatory('CompleteCase');
			ConductIssue.initialized = true;
		}
    }
};
function dateValidate(e,msg,target){
	var days = 0;
	var dt1 = '';
	var dt2 = ''
	if(e.id !=='' && (e.value1 !=undefined || e.value2 !=undefined)){
		dt1 = e.value1;
		dt2 = e.value2;
	}
	if((dt2 && dt2 !== '') ||(dt1 && dt1 !== '')){
		//var m1  = moment(dt1);
		//var m2 = moment(dt2);
		days = timeStampToDays(dt1,dt2);//m2.diff(m1,'days');
		if(days.val >= 0 && e.id ==='investigatory'){
			$('#leave_length').text(days.val +' Day(s)');
		}else if(days.val >= 0 && e.id ==='notice'){
			$('#leave_length_2').text(days.val +' Day(s)');
		}else if(days.timeStamp1 < days.timeStamp2){
			bootbox.alert({
            message: msg,//'Invalid leave end date. Leave end date must come after start date.',
            callback: function(){
                $('#' +target).val('');
				FormState.doActionNoRender(StateAction.changeText(target,''));
            }
        });
		}
	}
}

function terminationationTpe(e){
	if(e ==='pre_emp'){
		hyf.util.showComponent('termination_type_pre_employment_group');
		hyf.util.hideComponent('termination_type_probation_group');
	}else if(e==='probation'){
		hyf.util.showComponent('termination_type_probation_group');
		hyf.util.hideComponent('termination_type_pre_employment_group');
	}else{
		hyf.util.hideComponent('termination_type_pre_employment_group');
		hyf.util.hideComponent('termination_type_probation_group');
	}
}

function dateDecisionIssued(e){
	var days = 0;
	var dt1 = $('#date_propose_action_issued').val();
	var dt2 = $('#date_decision_issued').val();
	if(dt2 && dt1){
		var m1  = new Date(dt1);//moment(dt1);
		var m2 = new Date(dt2);//moment(dt2);
		if(m2.getTime() < m1.getTime()){
			bootbox.alert({
            message: 'Date must be greater than Date Proposed Action Issued to Employee Date.',
            callback: function(){
                $('#date_decision_issued').val('');
				FormState.doActionNoRender(StateAction.changeText('date_decision_issued',''));
            }
        });
	}
}
}
function timeStampToDays(date1,date2){
	var oneDay = 24*60*60*1000; // hours*minutes*seconds*milliseconds
	var firstDate = new Date(date1);
	var secondDate = new Date(date2);
	return {val: Math.round(Math.abs((secondDate.getTime()- firstDate.getTime())/(oneDay))),timeStamp1: firstDate.getTime(),timeStamp2 : secondDate.getTime()};
}
function addDate(e){
	var hidden ='',selectionId= '',selected ='',date ='';
	var target = e.target ? e.target.id : e.id;
	if(target){
		if(target === 'add_review_date'){
			hidden = 'rv_dt_selected';
			selectionId = 'rv_indecator';
			date =$('#sick_leave_date_reviewed').val();
			selected = e.value ? e.value: $('#' + hidden).val();
		}else if(target === 'add_extended_date'){
			hidden = 'ex_dt_selected';
			selectionId = 'ex_dt_indeicator';
			date = $('#sick_leave_date_extended').val();
			selected = e.value ? e.value: $('#' + hidden).val();
		}else if(target === 'slw_add_date'){
			hidden = 'slw_discussion_dt';
			selectionId = 'sick_leave_warning';
			date = $('#sl_warning_discussion_date').val();
			selected = e.value ? e.value: $('#' + hidden).val();
		}		
		if( selected !=='' && selected.indexOf(',') > -1){
			var arr = selected.split(',');
			arr.push(date);
			var tempArr =[];
			arr.forEach(function(el){
				if($.inArray(el,tempArr)=== -1 && el !==''){
					tempArr.push(el);
				}
			});
			arr = null;
			$('#' + selectionId).html('');
			tempArr.sort(function(a,b){
				return moment(a).isBefore(moment(b)) || moment(a).isSame(moment(b));
			})
			.forEach(function(el){
				$('#'+selectionId).append('<label id="'+el.replace(/\//g,'')+'"><span" onclick="removeItem('+el.replace(/\//g,'')+')" title="Remove date."><a href="#" style="color:red;padding:5px; onclick="onclick="removeItem('+date.replace(/\//g,'')+')">X</a></span>'+el+'</label><br/>');
			});
		$('#'+hidden).val(tempArr.join());
		FormState.doActionNoRender(StateAction.changeText(hidden,tempArr.join()));			
		}else{
			$('#'+selectionId).append('<label id="'+date.replace(/\//g,'')+'"><span" title="Remove date."><a href="#" style="color:red;padding:5px; onclick="removeItem('+date.replace(/\//g,'')+')">X</a></span>'+date+'</label><br/>');
			date = date +',';
			$('#'+hidden).val(date);
			FormState.doActionNoRender(StateAction.changeText(hidden,date));
		}
	}
}
function showCaseView (caseValue,arr){
	arr.forEach(function(el,index){
	if(el === caseValue){  
		hyf.util.showComponent(el);	
	}else{
		$('#' + el).find('input:text').val('');		
		hyf.util.hideComponent(el);
	}			
});
}
function populateOfficial(item,id){
	if(id ==='approval_name' && (item.last_name !==''||item.first_name !=='')){
		$('#approval_name').val(item.last_name +','+item.first_name +'('+item.email+')');
	}
	if(id ==='approval_name_2' && item.value !==''){
		$('#approval_name_2').val(item.last_name +','+item.first_name +'('+item.email+')');
	}
	if(id ==='deciding_official' && item.value !==''){
		$('#deciding_official').val(item.last_name +','+item.first_name +'('+item.email+')');
	}
	
	if(id ==='suspension_deciding_official_name' && item.value !==''){
		$('#suspension_deciding_official_name').val(item.last_name +','+item.first_name +'('+item.email+')');
	}
	if(id ==='termination_deciding_official_name' && item.value !==''){
		$('#termination_deciding_official_name').val(item.last_name +','+item.first_name +'('+item.email+')');
	}
	if(id ==='deciding_official_name' && item.value !==''){
		$('#deciding_official_name').val(item.last_name +','+item.first_name +'('+item.email+')');
	}
	//	
	if(id ==='PIP_deciding_official' && item.value !==''){
		$('#PIP_deciding_official').val(item.last_name +','+item.first_name +'('+item.email+')');
	}
	if(id ==='PI_demotion_official' && item.value !==''){
		$('#PI_demotion_official').val(item.last_name +','+item.first_name +'('+item.email+')');
	}
	if(id ==='PI_removal_official' && item.value !==''){
		$('#PI_removal_official').val(item.last_name +','+item.first_name +'('+item.email+')');
	}
}
function clear(item){
	if(item.target.id === 'admin_leave_clear'){
		$('#approval_name').val('');
	}
	if(item.target.id === 'admin_leave_ntc_clear'){
		$('#approval_name_2').val('');
	}
	if(item.target.id !=='' && item !== ''){
		$('#' +item).val('');
	}
	if(item !=='' && item !== ''){
		$('#' +item).val('');
	}
}
function populateCurrentPosition(item){
	var currentPosition = item.split(',');
	$('#pos_title').text(currentPosition[8]);
	$('#pplan').text(currentPosition[6]);
	$('#series').text(currentPosition[7]);
	$('#current_info_step').text(currentPosition[4]);
	$('#curr_admin_code').text(currentPosition[2]);//curr_admin_code
	$('#re_assignment_curr_org_container').text(currentPosition[3]);//re_assignment_curr_org_container
}
function hyfShowOrHide(item,id){
	if(item.value ==='Y'){
		hyf.util.showComponent(id);
	}
	else if(item.value === 'true' || item.value == true){
		hyf.util.showComponent(id);
	}
	else{
		hyf.util.hideComponent(id);
	}
}
function dateValidateHelper(id,id2,target){
	var data = {id:target,value1: '',value2:''};
	var val1 =$('#' + id).val();
	var val2 = $('#' + id2).val();
	if( val1 && val1 !== ''){
		data.value1 = val1;
	}
	if(val2 && val2 !==''){
		data.value2 = val2;
	}
	dateValidate(data,'Date decision issued to employee must be a date before the date proposed action issued to employee.',target);
}
function appendAdminCode(item){
		var admin_code = item.adminCode +' - '+item.description;
	return '<a role="option">' + admin_code +'</a>'
}
function adminCodeResponseMapper(xml){
	var data = $('record', xml).map(function (){
		return {
			adminCode: $('ADMINISTRATIVE_CODE', this).text(),
			description: $('DESCRIPTION', this).text()
		};
	}).get();
	return data
}
function populateAdminCode(item){
	$('#final_admin_code').val(item.adminCode);
	$('#re_assignment_final_org_container').text(item.description);
}

function booleanCheckBox(group){
	var checked  = false;
	var list  = $('#' + group+' input[type=Checkbox]'); 
	if(list && Array.isArray(list)&& list.length > 0){
		list.forEach(function(el){
			if($(el).prop('checked')){
				checked = true;
			}
		});
	}
	return checked && $(group).is(':visible');
}
function dynamicMandatory(activityName){
	var dynamic_requireActivity = BFActivityOption.getActivityName().replace(/\s/g,'');
		if(dynamic_requireActivity === activityName){
		var list  = $('.'+activityName+'_dynamic_require').get();
		 list.forEach(function(el){
			 if(el.id !==''){
				hyf.util.setMandatoryConstraint(el.id, true); 
			 }
			
		});
	}
}
function dateAutoPopulate(targetId,sourceValue){
	if(sourceValue !==''){
		$('#' +targetId).val(sourceValue);
	}
}
function populateGrades(payPlan,target){
		$('#' +target).html('');
		if(payPlan !=='default' &&  ConductIssue.grades[payPlan] !== undefined){
		 $('#' + target).append('<option value="default">Select one </option>');
		 ConductIssue.grades[payPlan].forEach(function(val){	
			$('#' + target).append('<option value="' + val + '">' + val + '</option>');
		});
	}else{
		hyf.util.hideComponent(target);
	}
}