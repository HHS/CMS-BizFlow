var ConductIssue = {
    initialized: false,
	groups : ['action_AdministrativeLeave_group','admin_leave_investigatory_group',
	'action_Reprimand_group','action_Suspension_group','termination_type_pre_employment_group',
	'termination_type_probation_group','suspension_oral_presentation_group','oral_presentation_date_group',
	'written_response_group','admin_leave_notice_group','action_Demotion_group','action_Counseling_group',
	'action_SickLeaveRestriction_group','action_SickLeaveWarning_group','action_Reassignment_group',
	'action_Removal_group','pre_emp_termination_oral_presentation_group','pre_emp_termination_response_group',
	'suspension_written_response_group','action_Termination_group','oral_presentation_date_group',
	'written_response_group','removal_notice_date_group','removal_oral_presentation_group',
	'removal_written_response_group','suspension_oral_presentation_group','suspension_written_response_group',
	'pre_emp_termination_oral_presentation_group','pre_emp_termination_response_group','reassignment_date_notice_issued'],
	actionTypes :['admin_leave','alt_discipline','removal_notice_date_group','removal_oral_presentation_group','removal_written_response_group'],
    init: function (){
		$('#add_review_date,#add_extended_date,#slw_add_date').on('click',addDate);
		$('#admin_leave_clear, #admin_leave_ntc_clear').on('click',clear);
		ConductIssue.groups.forEach(function(el,index){
			hyf.util.hideComponent(el);
		});		
		hyf.calendar.setDateConstraint('leave_start', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('leave_start_2', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('leave_end', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('leave_end_2', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('date_decision_issued', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('date_propose_action_issued', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('date_counsel_issued', 'Maximum', 'Today');	
		hyf.calendar.setDateConstraint('sick_leave_date_reviewed', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('sick_leave_date_extended', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('removal_prop_action_date', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('date_counsel_issued', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('sick_leave_date_removed', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('sl_warning_discussion_date', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('sl_warn_issue', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('removal_effective_date', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('oral_presentation_date', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('written_response_date', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('removal_dt_dcn_issued', 'Maximum', 'Today');//1
		hyf.calendar.setDateConstraint('effective_date', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('date_notice_issued', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('reprimand_issue_date', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('dt_restriction_issed', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('pre_emp_term_oral_prezen_dt', 'Maximum', 'Today');//2
		hyf.calendar.setDateConstraint('prob_term_dcn_issued_dt', 'Maximum', 'Today');//3
		hyf.calendar.setDateConstraint('removal_notice_start_dt', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('removal_notice_end_dt', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('removal_oral_prezen_dt', 'Maximum', 'Today');//4
		hyf.calendar.setDateConstraint('date_written_submitted', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('written_response_due_date', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('date_writen_prezen_rcv', 'Maximum', 'Today');//5
		hyf.calendar.setDateConstraint('suspension_prop_acn_dt', 'Maximum', 'Today');//6
		hyf.calendar.setDateConstraint('suspension_oral_prezen_dt', 'Maximum', 'Today');//7
		hyf.calendar.setDateConstraint('suspension_written_resp_dt', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('suspension_written_resp_due_date', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('suspension_decision_issued_date', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('pre_emp_termination_decision_issued_date', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('pre_emp_termination_written_resp_due_date', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('pre_emp_termination_written_resp_date', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('pre_emp_term_prop_action_dt', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('sick_leave_date_issued', 'Maximum', 'Today');
		hyf.calendar.setDateConstraint('sick_leave_date_reviewed', 'Maximum', 'Today');
		//hyf.calendar.setDateConstraint('date_decision_issued', 'Maximum', 'date_propose_action_issued');// from/to constrains
    },
    render: function (){
		var leaveDtStart = FormState.getState('leave_start');
		var leaveDtEnd = FormState.getState('leave_end');
		var leaveDtStart2 = FormState.getState('leave_start_2');
		var leaveDtEnd2 = FormState.getState('leave_end_2');
        var decision_issued_date = FormState.getState('date_decision_issued');
		var dt_reviewed = FormState.getState('rv_dt_selected');
		var dt_extended = FormState.getState('ex_dt_selected');
		var actionType = FormState.getState('action_type');
		var sickLeaveWarning = FormState.getState('slw_discussion_dt');
		var admin_leave = FormState.getState('admin_leave_type');
		var oral_presentation = FormState.getState('oral_presentation_requested');
		var appealDecision = FormState.getState('reprimand_appeal_decision');
		var removalEmployeePlacedLeaveNotice = FormState.getState('employee_notice_leave_placed');
		var removalOral_presentation = FormState.getState('removal_oral_presentaion_requested');
		var removalWritten_ResponseSubmitted = FormState.getState('removal_written_response');
		var terminationOral_presentation = FormState.getState('pre_emp_termination_oral_pres_requested');
		var terminationWritten_ResponseSubmitted = FormState.getState('pre_emp_termination_written_resp');	
		var written_response_requested = FormState.getState('oral_response_submitted');
		var admin_leave_investigatory = FormState.getState('admin_investigatory_leave');
		var admin_leave_notice = FormState.getState('admin_notice_leave');
		var emp = FormState.getState('empContact');
		var terminationType = FormState.getState('termination_type');
		var demotion_date_proposed_action_issued = FormState.getState('date_propose_action_issued');
		var removal_date_proposed_action_issued = FormState.getState('removal_prop_action_date');
		var removal_date_decision_issued = FormState.getState('removal_dt_dcn_issued');
		var suspensionOralPresentation = FormState.getState('suspension_oral_pres_requested');
		var suspensionWrittenPresentation = FormState.getState('suspension_written_resp');
		var suspensionDateActionProposed = FormState.getState('suspension_prop_acn_dt');
		var suspensionDecisionIssued = FormState.getState('suspension_decision_issued_date');
		var reassignment_date_notice_issued	= FormState.getState('date_notice_issued');
		var termination_decision_issued = FormState.getState('pre_emp_termination_decision_issued_date');
		var termination_proposed_action_issued = FormState.getState('pre_emp_term_prop_action_dt');
		
		if((termination_decision_issued && termination_decision_issued.dirty) || (termination_decision_issued && termination_decision_issued.dirty )){
			dateValidateHelper('pre_emp_term_prop_action_dt','pre_emp_termination_decision_issued_date','pre_emp_term_prop_action_dt');
		}
		if((reassignment_date_notice_issued && reassignment_date_notice_issued.dirty)){
			hyfShowOrHide(reassignment_date_notice_issued,'reassignment_date_notice_issued');
		}
		if((suspensionDateActionProposed && suspensionDateActionProposed.dirty) || (suspensionDecisionIssued && suspensionDecisionIssued.dirty )){
			dateValidateHelper('suspension_prop_acn_dt','suspension_decision_issued_date','suspension_prop_acn_dt');
		}
		if((removal_date_proposed_action_issued && removal_date_proposed_action_issued.dirty) || (removal_date_decision_issued && removal_date_decision_issued.dirty )){
			dateValidateHelper('removal_prop_action_date','removal_dt_dcn_issued','removal_prop_action_date');
		}
		if((decision_issued_date && decision_issued_date.dirty) || (demotion_date_proposed_action_issued && demotion_date_proposed_action_issued.dirty )){
			dateValidateHelper('date_decision_issued','date_propose_action_issued','date_propose_action_issued');
		}
		if((terminationOral_presentation && terminationOral_presentation.dirty)){
			hyfShowOrHide(terminationOral_presentation,'pre_emp_termination_oral_presentation_group');
		}
		if((terminationWritten_ResponseSubmitted && terminationWritten_ResponseSubmitted.dirty)){
			hyfShowOrHide(terminationWritten_ResponseSubmitted,'pre_emp_termination_response_group');
		}
		if((terminationType && terminationType.dirty)){
			terminationationTpe(terminationType.value);
		}	
		if((removalOral_presentation && removalOral_presentation.dirty)){
			hyfShowOrHide(removalOral_presentation,'removal_oral_presentation_group');
		}
		if((removalEmployeePlacedLeaveNotice && removalEmployeePlacedLeaveNotice.dirty)){
			hyfShowOrHide(removalEmployeePlacedLeaveNotice,'removal_notice_date_group');
		}
		if((removalWritten_ResponseSubmitted && removalWritten_ResponseSubmitted.dirty)){
			hyfShowOrHide(removalWritten_ResponseSubmitted,'removal_written_response_group');
		}
		if((suspensionOralPresentation && suspensionOralPresentation.dirty)){
			hyfShowOrHide(suspensionOralPresentation,'suspension_oral_presentation_group');
		}
		if((suspensionWrittenPresentation && suspensionWrittenPresentation.dirty)){
			hyfShowOrHide(suspensionWrittenPresentation,'suspension_written_response_group');
		}
		if((leaveDtStart && leaveDtStart.dirty)||(leaveDtEnd && leaveDtEnd.dirty)){
			dateValidate({id:'investigatory',value1: leaveDtStart.value,value2:leaveDtEnd.value},'Invalid leave end date. Leave end date must come after start date.','leave_end');
		}
		if((leaveDtStart2 && leaveDtStart2.dirty)||(leaveDtEnd2 && leaveDtEnd2.dirty)){
			dateValidate({id:'notice',value1:leaveDtStart2.value,value2:leaveDtEnd2.value},'Invalid leave end date. Leave end date must come after start date.','leave_end_2');
		}
		if(decision_issued_date && decision_issued_date.dirty){
			dateDecisionIssued();
		}
		//$('#layout_group_4_label').append('<>');
		if(dt_reviewed && dt_reviewed.dirty){
			addDate({id:'add_review_date',value:dt_reviewed.value});
		}
		if(dt_extended && dt_extended.dirty){
			addDate({id:'add_extended_date',value:dt_extended.value});
		}
		if(sickLeaveWarning && sickLeaveWarning.dirty){
			addDate({id:'slw_add_date',value:sickLeaveWarning.value});
		}
		if(actionType && actionType.dirty){
			var temp = actionType.value;
			//if(ConductIssue.initialized){
			showCaseView('action_'+temp.replace(/\s/g,'')+'_group');
			$('#Demotion_appeal_decision').val('');
			FormState.doActionNoRender(StateAction.changeText('Demotion_appeal_decision',''));
			$('#Removal_appeal_decision').val('');
			FormState.doActionNoRender(StateAction.changeText('Removal_appeal_decision',''));
			$('#Suspension_appeal_decision').val('');
			FormState.doActionNoRender(StateAction.changeText('Suspension_appeal_decision',''));
			$('#pre_emp_Termination_appeal_decision').val('');
			FormState.doActionNoRender(StateAction.changeText('pre_emp_Termination_appeal_decision',''));
			$('#Reprimand_appeal_decision').val('');
			FormState.doActionNoRender(StateAction.changeText('Reprimand_appeal_decision',''));
			//}	
			cms_case_track_main.actionOnChange('Demotion_appeal_decision');
		}	
		if(oral_presentation && oral_presentation.dirty){
			hyfShowOrHide(oral_presentation,'oral_presentation_date_group');
		}
		if(written_response_requested && written_response_requested.dirty){
			hyfShowOrHide(written_response_requested,'written_response_group');
		}
		if((admin_leave_investigatory && admin_leave_investigatory.dirty)){
			hyfShowOrHide(admin_leave_investigatory,'admin_leave_investigatory_group');	
		}
		if((admin_leave_notice && admin_leave_notice.dirty)){
			hyfShowOrHide(admin_leave_notice,'admin_leave_notice_group');	
		}
		if((emp && emp.dirty)){
			populateCurrentPosition(emp.value);		
		}
		if(!ConductIssue.initialized){		
			FormAutoComplete.setAutoComplete('approval_name','/bizflowwebmaker/erlr_AutoCompleteService/contactInfo.do?cust=',populateOfficial,responseMapper,appendInfo);
			FormAutoComplete.setAutoComplete('approval_name_2','/bizflowwebmaker/erlr_AutoCompleteService/contactInfo.do?cust=',populateOfficial,responseMapper,appendInfo);
			FormAutoComplete.setAutoComplete('deciding_official','/bizflowwebmaker/erlr_AutoCompleteService/contactInfo.do?cust=',populateOfficial,responseMapper,appendInfo);
			FormAutoComplete.setAutoComplete('suspension_deciding_official_name','/bizflowwebmaker/erlr_AutoCompleteService/contactInfo.do?cust=',populateOfficial,responseMapper,appendInfo);
			FormAutoComplete.setAutoComplete('termination_deciding_official_name','/bizflowwebmaker/erlr_AutoCompleteService/contactInfo.do?cust=',populateOfficial,responseMapper,appendInfo);
			FormAutoComplete.setAutoComplete('deciding_official_name','/bizflowwebmaker/erlr_AutoCompleteService/contactInfo.do?cust=',populateOfficial,responseMapper,appendInfo);
			FormAutoComplete.setAutoComplete('final_admin_code','/bizflowwebmaker/erlr_AutoCompleteService/contactInfo.do?admin=',populateAdminCode,adminCodeResponseMapper,appendAdminCode);
			dynamicMandatory('CompleteCase');
			booleanCheckBox('admin_leave_type')
			booleanCheckBox('termination_probation');
			ConductIssue.initialized = true;
		}
    }
};
function dateValidate(e,msg,target){
	var days = 0;
	var dt1 = '';
	var dt2 = ''
	if(e.id !=='' && (e.value1 !=undefined || e.value2 !=undefined)){
		dt1 = e.value1;
		dt2 = e.value2;
	}
	if((dt2 && dt2 !== '') ||(dt1 && dt1 !== '')){
		var m1  = moment(dt1);
		var m2 = moment(dt2);
		days = m2.diff(m1,'days');
		if(days >= 0 && e.id ==='investigatory'){
			$('#leave_length').text(days +' Day(s)');
		}else if(days >= 0 && e.id ==='notice'){
			$('#leave_length_2').text(days +' Day(s)');
		}else if((days < 0 && e.id !=='')){
			bootbox.alert({
            message: msg,//'Invalid leave end date. Leave end date must come after start date.',
            callback: function(){
                $('#' +target).val('');
				FormState.doActionNoRender(StateAction.changeText(target,''));
            }
        });
		}
	}
}

function terminationationTpe(e){
	if(e ==='pre_emp'){
		hyf.util.showComponent('termination_type_pre_employment_group');
		hyf.util.hideComponent('termination_type_probation_group');
	}else if(e==='probation'){
		hyf.util.showComponent('termination_type_probation_group');
		hyf.util.hideComponent('termination_type_pre_employment_group');
	}else{
		hyf.util.hideComponent('termination_type_pre_employment_group');
		hyf.util.hideComponent('termination_type_probation_group');
	}
}

function dateDecisionIssued(e){
	var days = 0;
	var dt1 = $('#date_propose_action_issued').val();
	var dt2 = $('#date_decision_issued').val();
	if(dt2 && dt1){
		var m1  = moment(dt1);
		var m2 = moment(dt2);
		if(m2.isBefore(m1)){
			bootbox.alert({
            message: 'Date must be greater than Date Proposed Action Issued to Employee Date.',
            callback: function(){
                $('#date_decision_issued').val('');
				FormState.doActionNoRender(StateAction.changeText('date_decision_issued',''));
            }
        });
	}
}
}
function addDate(e){
	var hidden ='',selectionId= '',selected ='',date ='';
	var target = e.target ? e.target.id : e.id;
	if(target){
		if(target === 'add_review_date'){
			hidden = 'rv_dt_selected';
			selectionId = 'rv_indecator';
			date =$('#sick_leave_date_reviewed').val();
			selected = e.value ? e.value: $('#' + hidden).val();
		}else if(target === 'add_extended_date'){
			hidden = 'ex_dt_selected';
			selectionId = 'ex_dt_indeicator';
			date = $('#sick_leave_date_extended').val();
			selected = e.value ? e.value: $('#' + hidden).val();
		}else if(target === 'slw_add_date'){
			hidden = 'slw_discussion_dt';
			selectionId = 'sick_leave_warning';
			date = $('#sl_warning_discussion_date').val();
			selected = e.value ? e.value: $('#' + hidden).val();
		}		
		if( selected !=='' && selected.indexOf(',') > -1){
			var arr = selected.split(',');
			arr.push(date);
			var tempArr =[];
			arr.forEach(function(el){
				if($.inArray(el,tempArr)=== -1 && el !==''){
					tempArr.push(el);
				}
			});
			arr = null;
			$('#' + selectionId).html('');
			tempArr.sort(function(a,b){
				return moment(a).isBefore(moment(b)) || moment(a).isSame(moment(b));
			})
			.forEach(function(el){
				$('#'+selectionId).append('<label id="'+el.replace(/\//g,'')+'"><span" onclick="removeItem('+el.replace(/\//g,'')+')" title="Remove date."><a href="#" style="color:red;padding:5px; onclick="onclick="removeItem('+date.replace(/\//g,'')+')">X</a></span>'+el+'</label><br/>');
			});
		$('#'+hidden).val(tempArr.join());
		FormState.doActionNoRender(StateAction.changeText(hidden,tempArr.join()));			
		}else{
			$('#'+selectionId).append('<label id="'+date.replace(/\//g,'')+'"><span" title="Remove date."><a href="#" style="color:red;padding:5px; onclick="removeItem('+date.replace(/\//g,'')+')">X</a></span>'+date+'</label><br/>');
			date = date +',';
			$('#'+hidden).val(date);
			FormState.doActionNoRender(StateAction.changeText(hidden,date));
		}
	}
}
function showCaseView (caseValue){
	ConductIssue.groups.forEach(function(el,index){
	if(el === caseValue){  
		hyf.util.showComponent(el);	
	}else{
		$('#' + el).find('input:text').val('');		
		hyf.util.hideComponent(el);
	}			
});
}
function populateOfficial(item,id){
	if(id ==='approval_name' && (item.last_name !==''||item.first_name !=='')){
		$('#approval_name').val(item.last_name +','+item.first_name +'('+item.email+')');
	}
	if(id ==='approval_name_2' && item.value !==''){
		$('#approval_name_2').val(item.last_name +','+item.first_name +'('+item.email+')');
	}
	if(id ==='deciding_official' && item.value !==''){
		$('#deciding_official').val(item.last_name +','+item.first_name +'('+item.email+')');
	}
	
	if(id ==='suspension_deciding_official_name' && item.value !==''){
		$('#suspension_deciding_official_name').val(item.last_name +','+item.first_name +'('+item.email+')');
	}
	if(id ==='termination_deciding_official_name' && item.value !==''){
		$('#termination_deciding_official_name').val(item.last_name +','+item.first_name +'('+item.email+')');
	}
	if(id ==='deciding_official_name' && item.value !==''){
		$('#deciding_official_name').val(item.last_name +','+item.first_name +'('+item.email+')');
	}
}
function clear(item){
	if(item.target.id === 'admin_leave_clear'){
		$('#approval_name').val('');
	}
	if(item.target.id === 'admin_leave_ntc_clear'){
		$('#approval_name_2').val('');
	}
	if(item.target.id !=='' && item !== ''){
		$('#' +item).val('');
	}
	if(item !=='' && item !== ''){
		$('#' +item).val('');
	}
}
function populateCurrentPosition(item){
	var currentPosition = item.split(',');
	$('#pos_title').text(currentPosition[8]);
	$('#pplan').text(currentPosition[6]);
	$('#series').text(currentPosition[7]);
	$('#current_info_step').text(currentPosition[4]);
	$('#current_info_grade').text(currentPosition[5]);//curr_admin_code
	$('#curr_admin_code').text(currentPosition[2]);
}
function hyfShowOrHide(item,id){
	if(item.value ==='Y'){
		hyf.util.showComponent(id);
	}
	else if(item.value === 'true' || item.value === true){
		hyf.util.showComponent(id);
	}
	else{
		hyf.util.hideComponent(id);
	}
}
function dateValidateHelper(id,id2,target){
	var data = {id:target,value1: '',value2:''};
	var val1 =$('#' + id).val();
	var val2 = $('#' + id2).val();
	if( val1 && val1 !== ''){
		data.value1 = val1;
	}
	if(val2 && val2 !==''){
		data.value2 = val2;
	}
	dateValidate(data,'Date decision issued to employee must be a date before the date proposed action issued to employee.',target);
}
function appendAdminCode(item){
		var admin_code = item.adminCode +' - '+item.description;
	return '<a role="option">' + admin_code +'</a>'
}
function adminCodeResponseMapper(xml){
	var data = $('record', xml).map(function (){
		return {
			adminCode: $('ADMINISTRATIVE_CODE', this).text(),
			description: $('DESCRIPTION', this).text()
		};
	}).get();
	return data
}
function populateAdminCode(item){
	$('#final_admin_code').val(item.adminCode);
}

function booleanCheckBox(group){
	var list  = $('.' + group+'_booleancheckbox').get();
		var checked = false;
	if(list && Array.isArray(list)&& list.length > 0){
	list.forEach(function(el){
		$(el).change(function(){
			if($(this).is(':checked')){
				$('.' + group+'booleancheckbox').get().removeClass('CompleteCase_dynamic_require');
			}else{
			if($('.CompleteCase_dynamic_require').get().length ==0){
				$('.' + group+'booleancheckbox').addClass('CompleteCase_dynamic_require');
			}					
			}
		});
	});
	}
}
function dynamicMandatory(activityName){
	var dynamic_requireActivity = BFActivityOption.getActivityName().replace(/\s/g,'');
		if(dynamic_requireActivity === activityName){
		var list  = $('.'+activityName+'_dynamic_require').get();
		 list.forEach(function(el){
			if(el.id !==''){
				hyf.util.setMandatoryConstraint(el.id, true);
			}
		
		});
	}
}
function datePrepopulate(id,id2){
	var field1 = $('#'+id).val();
	if(field1 !==''){
		$('#'+id2).val(field1);
	}
}