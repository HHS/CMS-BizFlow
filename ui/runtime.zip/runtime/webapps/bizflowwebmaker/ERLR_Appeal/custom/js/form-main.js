var cms_main_tab1 = {
    initialized: false,
    pageElements: ['contact_info_auto', 'emp_info_auto', 'org_assign', 'case_type'],//keep page elements, such as textboxes, select boxes in array to be used duing rendering, to avoid boilerplate code.
    groups: ['case_grievance_Ind_group', 'case_grievance_union_group', 'case_conduct_issues_group', 'emp_info'],
    init: function () {
        $('#main_buttons_layout_group').removeAttr('style');
        // cms_main_tab1.showCaseView('adr');
        cms_main_tab1.groups.forEach(function (el, index) {
            hyf.util.hideComponent(el);
        });
    },
    render: function () {
        cms_main_tab1.pageElements.forEach(function (el, index) {
            var element = FormState.getState(el);
            if (element && element.dirty) {
                $(el).val(element.value);
                if (el === 'case_type') {
                    cms_main_tab1.showCaseView(element.value);
                } else if (el === 'contact_info_auto') {
                    var custContact = $('#custContact').val();
                    if ('' !== custContact) {
                        var val = custContact.split(';');
                        populateContactInfo({name: val[0], email: val[1]}, 'contact_info_auto')
                    } else {
                        hyf.util.hideComponent(el);
                    }
                } else if (el === 'emp_info_auto') {
                    var empContact = $('#empContact').val();
                    if ('' != empContact) {
                        var emps = empContact.split(';');
                        populateContactInfo({name: emps[0], email: emps[1]}, 'emp_info_auto')
                    }
                }
            }
        });
        if (!cms_main_tab1.initialized) {
            FormAutoComplete.setAutoComplete('contact_info_auto', '/bizflowwebmaker/cms_service/contactInfo.do?cust=', populateContactInfo, responseMapper, appendInfo);
            FormAutoComplete.setAutoComplete('emp_info_auto', '/bizflowwebmaker/cms_service/contactInfo.do?emp=', populateEmpInfo, responseMapper, appendInfo);
            CaseType().populateDropdowns();
            cms_main_tab1.initialized = true;
        }
    },
    // load case view will be used as event handler on case type select box.
    showCaseView: function (caseValue) {
        var tempGroups = cms_main_tab1.groups;
        tempGroups.forEach(function (el, index) {
            if (el.indexOf(caseValue) > -1) {
                hyf.util.showComponent(el);
            } else {
                hyf.util.hideComponent(el);
            }
        });

    }
};

//implement case specific logic in the function to be as an API in the render function.
//@param caseSelected: The value of the case type selected from dropdown
function CaseType() {
    return {
        conductIssue: conductIssue,
        populateDropdowns: populateDropdowns
    }

    function conductIssue() {

    }

    function populateDropdowns() {
        $.ajax({
            url: '/bizflowwebmaker/cms_service/contactInfo.do',
            dataType: 'xml',
            cache: false,
            success: function (xmlResponse) {
                var data = responseMapper(xmlResponse);
                data.filter(function (el) {
                    return el.name != '' && el.email != '';
                }).forEach(function (el, index) {
                    $('#dwc_specialist').append(append(el));
                    $('#secondary_specialist').append(append(el));
                });
            }
        });
    }

    //function func3(){}
}

function responseMapper(xml) {
    var data = $('record', xml).map(function () {
        return {
            email: $('EMAIL', this).text(),
            name: $('NAME', this).text()
        };
    }).get();
    return data;
}

function populateContactInfo(item, id) {
    var name = item.name.split(',');
    if (id === 'contact_info_auto') {
        $('#lastName').text(name[0]);
        $('#firstName').text(name[1]);
        $('#email').text(item.email);
        var custContact = item.name + ';' + item.email;
        FormState.dispatchActionNoRender(StateAction.changeText('custContact', custContact));
        hyf.util.showComponent('contactInfo');
    }
}

function populateEmpInfo(item, id) {
    var name = item.name.split(',');
    if (id === 'emp_info_auto') {
        $('#lastName_2').text(name[0]);
        $('#firstName_2').text(name[1]);
        $('#email_2').text(item.email);
        var empContact = item.name + ';' + item.email;
        FormState.dispatchActionNoRender(StateAction.changeText('empContact', empContact));
        hyf.util.showComponent('emp_Info');
    }
}

function appendInfo(item) {
    return '<a role="option">' + item.name + ' ( ' + item.email + ' )</a>'
}

function append(item) {
    return '<option value="' + item.name + '">' + item.name + ' ( ' + item.email + ' )</option>';
}
