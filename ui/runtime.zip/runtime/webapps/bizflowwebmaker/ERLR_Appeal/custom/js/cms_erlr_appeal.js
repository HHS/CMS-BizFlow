var Appeal = {
    initialized: false,
	init: function () {
        hyf.util.hideComponent('Exception_info_group');
        hyf.util.hideComponent('Arbitration_group_Grievance');        
        hyf.util.hideComponent('Exception_info_group_2');
        hyf.util.hideComponent('discovery_due_group');  
        hyf.util.hideComponent('petition_review_date_group'); 
        
    },
    render: function () {
        var appealType = FormState.getState('erlr_appeal_type');
        var exceptionFiled = FormState.getState('erlr_exception_filed');
        var isArbitrationInvoked = FormState.getState('erlr_arbitration_invoked');
        var exceptionFiled2 = FormState.getState('erlr_exception_filed_2');
        var wasDiscoveryInitiated = FormState.getState('erlr_was_discovery_initiated');
        var wasPetitionReviewFiled = FormState.getState('erlr_was_petition_filed_MSPB');
        
        if(appealType && appealType.dirty){
            if(appealType.value === 'Arbitration'){								
                hyf.util.showComponent('Arbitration_group');
                hyf.util.hideComponent('Special_Counsel_group');
                hyf.util.hideComponent('Grievance_group');
                hyf.util.hideComponent('MSPB_group');
            }
            else if(appealType.value === 'Special Counsel'){
                hyf.util.hideComponent('Arbitration_group');                
				hyf.util.showComponent('Special_Counsel_group');
                hyf.util.hideComponent('Grievance_group');
                hyf.util.hideComponent('MSPB_group');
            }
            else if(appealType.value === 'Grievance'){                
                hyf.util.hideComponent('Arbitration_group');
                hyf.util.hideComponent('Special_Counsel_group');
				hyf.util.showComponent('Grievance_group');
                hyf.util.hideComponent('MSPB_group');
            }
            else if(appealType.value === 'MSPB'){                
                hyf.util.hideComponent('Arbitration_group');
                hyf.util.hideComponent('Special_Counsel_group');
                hyf.util.hideComponent('Grievance_group');
				hyf.util.showComponent('MSPB_group');
            }
            else{                
                hyf.util.hideComponent('Arbitration_group');
                hyf.util.hideComponent('Special_Counsel_group');
                hyf.util.hideComponent('Grievance_group');
                hyf.util.hideComponent('MSPB_group');
            }
        }
        
        if(exceptionFiled && exceptionFiled.dirty){
            if(exceptionFiled.value === 'Yes'){
        	    hyf.util.showComponent('Exception_info_group');            	
            }
            else{
				hyf.util.hideComponent('Exception_info_group');            	
            }
        }
        
        if(exceptionFiled2 && exceptionFiled2.dirty){
            if(exceptionFiled2.value === 'Yes'){
        	    hyf.util.showComponent('Exception_info_group_2');            	
            }
            else{
				hyf.util.hideComponent('Exception_info_group_2');            	
            }
        }
        
        if(isArbitrationInvoked && isArbitrationInvoked.dirty){
            if(isArbitrationInvoked.value === 'Yes'){
        	    hyf.util.showComponent('Arbitration_group_Grievance');            	
            }
            else{
				hyf.util.hideComponent('Arbitration_group_Grievance');            	
            }
        }
        
        if(wasDiscoveryInitiated && wasDiscoveryInitiated.dirty){
            if(wasDiscoveryInitiated.value === 'Yes'){
        	    hyf.util.showComponent('discovery_due_group');            	
            }
            else{
				hyf.util.hideComponent('discovery_due_group');            	
            }
        }
        if(wasPetitionReviewFiled && wasPetitionReviewFiled.dirty){
            if(wasPetitionReviewFiled.value === 'Yes'){
        	    hyf.util.showComponent('petition_review_date_group');            	
            }
            else{
				hyf.util.hideComponent('petition_review_date_group');            	
            }
        }
        
        if(!Appeal.initialized){		
            hyf.calendar.setDateConstraint('erlr_appeal_filed_date', 'Maximum', 'Today');

            // Arbitration
            hyf.calendar.setDateConstraint('erlr_prehearing_date', 'Maximum', 'Today'); 
            hyf.calendar.setDateConstraint('erlr_hearing_date', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_posthearing_brief_due', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_final_arbitrator_decision_date', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_exception_file_date', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_response_to_exceptions_due', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_final_FLRA_decision_date', 'Maximum', 'Today');

            // Special Counsel
            hyf.calendar.setDateConstraint('erlr_special_counsel_prehearing_date', 'Maximum', 'Today'); 
            hyf.calendar.setDateConstraint('erlr_special_counsel_hearing_date', 'Maximum', 'Today');

            // Grievance
            hyf.calendar.setDateConstraint('erlr_date_step_decision', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_prehearing_date_2', 'Maximum', 'Today'); 
            hyf.calendar.setDateConstraint('erlr_hearing_date_2', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_posthearing_brief_due_2', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_final_arbitrator_decision_date_2', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_exception_file_date_2', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_response_to_exceptions_due_2', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_final_FLRA_decision_date_2', 'Maximum', 'Today');

            // MSPB
            hyf.calendar.setDateConstraint('erlr_date_settlement_discussion', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_date_agency_file_response_due', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_prehearing_date_MSPB', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_date_discovery_due', 'Maximum', 'Today');             
            hyf.calendar.setDateConstraint('erlr_hearing_date_MSPB', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_initial_decision_date_MSPB', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_petition_filed_date_MSPB', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_final_board_decision_date_MSPB', 'Maximum', 'Today');
            
            Appeal.initialized = true;
	   }
    }
}



