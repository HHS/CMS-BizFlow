var Appeal = {
    initialized: false,
	init: function () {
        hyf.util.hideComponent('Exception_info_group');
        hyf.util.hideComponent('Arbitration_group_Grievance');        
        hyf.util.hideComponent('Exception_info_group_2');
        hyf.util.hideComponent('discovery_due_group');  
        hyf.util.hideComponent('petition_review_date_group'); 
               
    },
    render: function () {
        var appealType = FormState.getState('erlr_appeal_type');
        var exceptionFiled = FormState.getState('erlr_exception_filed');
        var isArbitrationInvoked = FormState.getState('erlr_arbitration_invoked');
        var exceptionFiled2 = FormState.getState('erlr_exception_filed_2');
        var wasDiscoveryInitiated = FormState.getState('erlr_was_discovery_initiated');
        var wasPetitionReviewFiled = FormState.getState('erlr_was_petition_filed_MSPB');
        var prehearingDate = FormState.getState('erlr_prehearing_date');
        var hearingDate = FormState.getState('erlr_hearing_date');
        var prehearingDateMSPB = FormState.getState('erlr_prehearing_date_MSPB');
        var hearingDateMSPB = FormState.getState('erlr_hearing_date_MSPB');
        var prehearingDateSC = FormState.getState('erlr_prehearing_date_SC');
        var hearingDateSC = FormState.getState('erlr_hearing_date_SC');
        
        if(appealType && appealType.dirty){
            if(appealType.value === 'Arbitration'){								
                hyf.util.showComponent('Arbitration_group');
                hyf.util.hideComponent('Special_Counsel_group');
                hyf.util.hideComponent('Grievance_group');
                hyf.util.hideComponent('MSPB_group');
            }
            else if(appealType.value === 'Special Counsel'){
                hyf.util.hideComponent('Arbitration_group');                
				hyf.util.showComponent('Special_Counsel_group');
                hyf.util.hideComponent('Grievance_group');
                hyf.util.hideComponent('MSPB_group');
            }
            else if(appealType.value === 'Grievance'){                
                hyf.util.hideComponent('Arbitration_group');
                hyf.util.hideComponent('Special_Counsel_group');
				hyf.util.showComponent('Grievance_group');
                hyf.util.hideComponent('MSPB_group');
            }
            else if(appealType.value === 'MSPB'){                
                hyf.util.hideComponent('Arbitration_group');
                hyf.util.hideComponent('Special_Counsel_group');
                hyf.util.hideComponent('Grievance_group');
				hyf.util.showComponent('MSPB_group');
            }
            else{                
                hyf.util.hideComponent('Arbitration_group');
                hyf.util.hideComponent('Special_Counsel_group');
                hyf.util.hideComponent('Grievance_group');
                hyf.util.hideComponent('MSPB_group');
            }
        }
        
        if(exceptionFiled && exceptionFiled.dirty){
            if(exceptionFiled.value === 'Yes'){
        	    hyf.util.showComponent('Exception_info_group');            	
            }
            else{
				hyf.util.hideComponent('Exception_info_group');            	
            }
        }
        
        if(exceptionFiled2 && exceptionFiled2.dirty){
            if(exceptionFiled2.value === 'Yes'){
        	    hyf.util.showComponent('Exception_info_group_2');            	
            }
            else{
				hyf.util.hideComponent('Exception_info_group_2');            	
            }
        }
        
        if(isArbitrationInvoked && isArbitrationInvoked.dirty){
            if(isArbitrationInvoked.value === 'Yes'){
        	    hyf.util.showComponent('Arbitration_group_Grievance');            	
            }
            else{
				hyf.util.hideComponent('Arbitration_group_Grievance');            	
            }
        }
        
        if(wasDiscoveryInitiated && wasDiscoveryInitiated.dirty){
            if(wasDiscoveryInitiated.value === 'Yes'){
        	    hyf.util.showComponent('discovery_due_group');            	
            }
            else{
				hyf.util.hideComponent('discovery_due_group');            	
            }
        }
        if(wasPetitionReviewFiled && wasPetitionReviewFiled.dirty){
            if(wasPetitionReviewFiled.value === 'Yes'){
        	    hyf.util.showComponent('petition_review_date_group');            	
            }
            else{
				hyf.util.hideComponent('petition_review_date_group');            	
            }
        }
        
        if(prehearingDate && prehearingDate.dirty && hearingDate){
			Appeal.dateValidate({value1: prehearingDate.value, value2: hearingDate.value}, 'Date of Hearing must be after the Date of Prehearing Conference.','erlr_prehearing_date');
		}
        
        if(hearingDate && hearingDate.dirty && prehearingDate){
            Appeal.dateValidate({value1: prehearingDate.value, value2: hearingDate.value}, 'Date of Hearing must be after the Date of Prehearing Conference.','erlr_hearing_date');
        }
        
        if(prehearingDateMSPB && prehearingDateMSPB.dirty && hearingDateMSPB){
			Appeal.dateValidate({value1: prehearingDateMSPB.value, value2: hearingDateMSPB.value}, 'Date of Hearing must be after the Date of Prehearing Conference.','erlr_prehearing_date_MSPB');
		}
        
        if(hearingDateMSPB && hearingDateMSPB.dirty && prehearingDateMSPB){
            Appeal.dateValidate({value1: prehearingDateMSPB.value, value2: hearingDateMSPB.value}, 'Date of Hearing must be after the Date of Prehearing Conference.','erlr_hearing_date_MSPB');
        }
        
        if(prehearingDateSC && prehearingDateSC.dirty && hearingDateSC){
			Appeal.dateValidate({value1: prehearingDateSC.value, value2: hearingDateSC.value}, 'Date of Hearing must be after the Date of Prehearing Conference.','erlr_prehearing_date_SC');
		}
        
        if(hearingDateSC && hearingDateSC.dirty && prehearingDateSC){
            Appeal.dateValidate({value1: prehearingDateSC.value, value2: hearingDateSC.value}, 'Date of Hearing must be after the Date of Prehearing Conference.','erlr_hearing_date_SC');
        }
        
        if(!Appeal.initialized){		
            hyf.calendar.setDateConstraint('erlr_appeal_filed_date', 'Maximum', 'Today');

            // Arbitration
            hyf.calendar.setDateConstraint('erlr_prehearing_date', 'Maximum', 'Today'); 
            hyf.calendar.setDateConstraint('erlr_hearing_date', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_posthearing_brief_due', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_final_arbitrator_decision_date', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_exception_file_date', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_response_to_exceptions_due', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_final_FLRA_decision_date', 'Maximum', 'Today');

            // Special Counsel
            hyf.calendar.setDateConstraint('erlr_prehearing_date_SC', 'Maximum', 'Today'); 
            hyf.calendar.setDateConstraint('erlr_hearing_date_SC', 'Maximum', 'Today');

            // Grievance
            hyf.calendar.setDateConstraint('erlr_date_step_decision', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_prehearing_date_2', 'Maximum', 'Today'); 
            hyf.calendar.setDateConstraint('erlr_hearing_date_2', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_posthearing_brief_due_2', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_final_arbitrator_decision_date_2', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_exception_file_date_2', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_response_to_exceptions_due_2', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_final_FLRA_decision_date_2', 'Maximum', 'Today');

            // MSPB
            hyf.calendar.setDateConstraint('erlr_date_settlement_discussion', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_date_agency_file_response_due', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_prehearing_date_MSPB', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_date_discovery_due', 'Maximum', 'Today');             
            hyf.calendar.setDateConstraint('erlr_hearing_date_MSPB', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_initial_decision_date_MSPB', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_petition_filed_date_MSPB', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_final_board_decision_date_MSPB', 'Maximum', 'Today');
            
            dynamicMandatory('CompleteCase')
            Appeal.initialized = true;
	   }
    },
    dateValidate : function(e, msg, targetId){
        var days = 0
        var dt1 = '';
        var dt2 = ''
        if(e.value1 !=undefined || e.value2 !=undefined){
            dt1 = e.value1;
            dt2 = e.value2;
        }
        if((dt2 && dt2 !== '') ||(dt1 && dt1 !== '')){
            var m1 = moment(dt1);
            var m2 = moment(dt2);
            days = m2.diff(m1,'days');
            if(days < 0 ){
                bootbox.alert({
                message: msg,
                callback: function(){ 
                    FormState.doAction(StateAction.changeDate(targetId, ''), false);
                    $('#' +targetId).val('');
                    }
                });
            }
        }
    }/*,
    clearFields : function(targetFields){
        targetFields.forEach(fucntion(el){
			if(
			FormState.doAction(StateAction.changeText(el, ''), false);
        	FormState.doAction(StateAction.changeSelect('SME_INTERNAL_2', 'default'), false);
    		});	
        	
    }  */  
}






