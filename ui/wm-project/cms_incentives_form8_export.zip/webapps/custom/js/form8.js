(function (window) {
    var cms_incentives_sam_approval = function () {
        var _readOnly = false;
        var _initialized = false;

        var SELECTEE_MEET_CRITERIA = {
            SUPERIOR: "Superior Qualifications",
            AGENCY_NEED: "Fills a special agency need"
        };

        function onSelecteeMeetCriteria(value) {
            hyf.util.setComponentVisibility("specialAgencyNeedCriteria_group", value === SELECTEE_MEET_CRITERIA.AGENCY_NEED);
            hyf.util.setComponentVisibility("superiorQualificationCriteria_group", value === SELECTEE_MEET_CRITERIA.SUPERIOR);
        }

        function setApproverAndApprovalDate(eleId, dateEleId, checked) {
            var currentUserName = "";
            var currentUserId = "";
            var currentDate = "";
            if (checked) {
                currentUserName = myInfo.getMyName();
                currentUserId = myInfo.getMyMemberId();
                currentDate = FormUtility.getDateString(false, "mm/dd/yyyy", new Date());
            }

            $("#" + eleId).val(currentUserName);
            $("#" + dateEleId).val(currentDate);

            FormState.updateTextValue(eleId, currentUserName, false);
            FormState.updateTextValue(eleId + "Id", currentUserId, false);
            FormState.updateDateValue(dateEleId, currentDate, false);
        }

        function onSupportSAMChanged(value) {
            if ("Yes" === value) {
                FormState.updateSelectValue("approvalSOValue", "Approve", "Approve", true);
            } else if ("No" === value) {
                FormState.updateSelectValue("approvalSOValue", "Disapprove", "Disapprove", true);
            } else {
                FormState.updateSelectValue("approvalSOValue", "", "Select One", true);
            }
        }

        function initTabVisibility() {
            if (_initialized) {
                var value = $("#approvalSOValue").val();
                if ("Approve" == value) {
                    TabManager.enableTab(MENU_TAB.GENERAL);
                    TabManager.enableTab(MENU_TAB.POSITION);
                    TabManager.enableTab(MENU_TAB.SAM_DETAILS);
                    TabManager.enableTab(MENU_TAB.SAM_REVIEW);
                    FormMain.setTabVisibility(INCENTIVES_TYPE.SAM, "", false);

                    cms_incentives_sam_details.resetMandatoryFields(value);
                } else if ("Disapprove" == value) {
                    TabManager.disableTab(MENU_TAB.GENERAL);
                    TabManager.disableTab(MENU_TAB.POSITION);
                    TabManager.disableTab(MENU_TAB.SAM_DETAILS);
                    TabManager.disableTab(MENU_TAB.SAM_REVIEW);

                    TabManager.hideTabHeader(MENU_TAB.SAM_JUSTIFICATION);
                    // TabManager.resetTabs();
                    cms_incentives_sam_details.resetMandatoryFields(value);
                }
            } else {
                var value = FormState.getElementValue("approvalSOValue");
                if ("Approve" == value) {
                    //
                } else if ("Disapprove" == value) {
                    TabManager.disableTab(MENU_TAB.GENERAL);
                    TabManager.disableTab(MENU_TAB.POSITION);
                    TabManager.disableTab(MENU_TAB.SAM_DETAILS);
                    TabManager.disableTab(MENU_TAB.SAM_REVIEW);

                    TabManager.hideTabHeader(MENU_TAB.SAM_JUSTIFICATION);
                    TabManager.resetTabs();
                    cms_incentives_sam_details.resetMandatoryFields(value);
                }
            }
        }

        function initEventHandlers() {
            $('#approvalSOCheck').on('change', function (e) {
                var target = e.target;
                setApproverAndApprovalDate("approvalSO", "approvalSOResponseDate", target.checked);
            });
            $('#approvalSOValue').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                setApproverAndApprovalDate("approvalSO", "approvalSOResponseDate", value !== "");
                initTabVisibility();
            });
            $('#approvalCOCValue').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                setApproverAndApprovalDate("approvalCOC", "approvalCOCResponseDate", value !== "");
            });
            $('#approvalDGHOValue').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                setApproverAndApprovalDate("approvalDGHO", "approvalDGHOResponseDate", value !== "");
            });
            $('#approvalTABGValue').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                setApproverAndApprovalDate("approvalTABG", "approvalTABGResponseDate", value !== "");
            });
            $('#approvalOHCValue').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                setApproverAndApprovalDate("approvalOHC", "approvalOHCResponseDate", value !== "");
            });
        }

        function setApproverNotesVisibility() {
            var reviewRecommendedSalaries = FormState.getElementArrayValue("reviewRecommendedSalaries", []);
            if (reviewRecommendedSalaries.length === 1) {
                if (typeof reviewRecommendedSalaries[0].witemSeq === 'undefined') {
                    reviewRecommendedSalaries = [];
                }
            }

            if (reviewRecommendedSalaries.length > 0) {
                if (activityStep.isHRSReview()) {
                    hyf.util.showComponent("approverNotes_group");
                    hyf.util.disableComponent("approverNotes");
                } else if (activityStep.isDGHOReview() || activityStep.isTABGReview() || activityStep.isOHCReview()) {
                    hyf.util.showComponent("approverNotes_group");
                    hyf.util.enableComponent("approverNotes");
                }
            } else {
                hyf.util.hideComponent("approverNotes_group");
                FormState.updateTextValue("approverNotes", "", false);
            }
        }

        function setSignUsability() {
            var isSO = accessControl.isDesignatedSO();
            hyf.util.setComponentUsability("approvalSOCheck", isSO);
            hyf.util.setMandatoryConstraint("approvalSOCheck", isSO);
            hyf.util.setComponentUsability("approvalSOValue", isSO);
            hyf.util.setMandatoryConstraint("approvalSOValue", isSO);
            hyf.util.setComponentUsability("approvalSOActing", isSO);
            hyf.util.setMandatoryConstraint("approvalSOActing", isSO);

            var isCOC = accessControl.isDesignatedCOC();
            hyf.util.setComponentUsability("approvalCOCCheck", isCOC);
            hyf.util.setMandatoryConstraint("approvalCOCCheck", isCOC);
            hyf.util.setComponentUsability("approvalCOCValue", isCOC);
            hyf.util.setMandatoryConstraint("approvalCOCValue", isCOC);
            hyf.util.setComponentUsability("approvalCOCActing", isCOC);
            hyf.util.setMandatoryConstraint("approvalCOCActing", isCOC);

            var isDGHO = myInfo.isDGHO();
            hyf.util.setComponentUsability("approvalDGHOCheck", isDGHO);
            hyf.util.setMandatoryConstraint("approvalDGHOCheck", isDGHO);
            hyf.util.setComponentUsability("approvalDGHOValue", isDGHO);
            hyf.util.setMandatoryConstraint("approvalDGHOValue", isDGHO);
            hyf.util.setComponentUsability("approvalDGHOActing", isDGHO);
            hyf.util.setMandatoryConstraint("approvalDGHOActing", isDGHO);

            var isTABG = myInfo.isTABG();
            hyf.util.setComponentUsability("approvalTABGCheck", isTABG);
            hyf.util.setMandatoryConstraint("approvalTABGCheck", isTABG);
            hyf.util.setComponentUsability("approvalTABGValue", isTABG);
            hyf.util.setMandatoryConstraint("approvalTABGValue", isTABG);
            hyf.util.setComponentUsability("approvalTABGActing", isTABG);
            hyf.util.setMandatoryConstraint("approvalTABGActing", isTABG);

            var isOHC = accessControl.isDesignatedOHC("reviewRcmdApprovalOHCDirector");
            hyf.util.setComponentUsability("approvalOHCCheck", isOHC);
            hyf.util.setMandatoryConstraint("approvalOHCCheck", isOHC);
            hyf.util.setComponentUsability("approvalOHCValue", isOHC);
            hyf.util.setMandatoryConstraint("approvalOHCValue", isOHC);
            hyf.util.setComponentUsability("approvalOHCActing", isOHC);
            hyf.util.setMandatoryConstraint("approvalOHCActing", isOHC);
        }

        function initComponents() {
            setSignUsability();
            setApproverNotesVisibility();
        }

        function init(readOnly, tabObject) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();
            initTabVisibility();
            FormMain.resetMandatoryMark(tabObject);
            _initialized = true;
        }

        function render(action) {
        }

        return {
            setApproverNotesVisibility: setApproverNotesVisibility,
            onSupportSAMChanged: onSupportSAMChanged,
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_sam_approval || (window.cms_incentives_sam_approval = cms_incentives_sam_approval());
})(window);
