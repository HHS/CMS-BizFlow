(function (window) {
    var cms_incentives_sam_approval = function () {
        var _readOnly = false;
        var _initialized = false;

        var SELECTEE_MEET_CRITERIA = {
            SUPERIOR: "Superior Qualifications",
            AGENCY_NEED: "Fills a special agency need"
        };

        function onSelecteeMeetCriteria(value) {
            hyf.util.setComponentVisibility("specialAgencyNeedCriteria_group", value === SELECTEE_MEET_CRITERIA.AGENCY_NEED);
            hyf.util.setComponentVisibility("superiorQualificationCriteria_group", value === SELECTEE_MEET_CRITERIA.SUPERIOR);
        }

        function setApproverAndApprovalDate(eleId, dateEleId, checked) {
            var currentUserName = "";
            var currentDate = "";
            if (checked) {
                currentUserName = myInfo.getMyName();
                currentDate = FormUtility.getDateString(false, "mm/dd/yyyy", new Date());
            }

            $("#" + eleId).val(currentUserName);
            $("#" + dateEleId).val(currentDate);

            FormState.updateTextValue(eleId, currentUserName, false);
            FormState.updateDateValue(dateEleId, currentDate, false);
        }

        function initEventHandlers() {
            $('#approvalDGHOCheck').on('change', function (e) {
                var target = e.target;
                setApproverAndApprovalDate("approvalDGHO", "approvalDGHOResponseDate", target.checked);
            });
            $('#approvalTABGCheck').on('change', function (e) {
                var target = e.target;
                setApproverAndApprovalDate("approvalTABG", "approvalTABGResponseDate", target.checked);
            });
            $('#approvalOHCCheck').on('change', function (e) {
                var target = e.target;
                setApproverAndApprovalDate("approvalOHC", "approvalOHCResponseDate", target.checked);
            });
        }

        function initComponents() {
            hyf.util.disableComponent("approvalDGHOResponseDate");
            hyf.util.disableComponent("approvalTABGResponseDate");
            hyf.util.disableComponent("approvalOHCResponseDate");
        }

        function init(readOnly) {
            _readOnly = readOnly;
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_sam_review::init, readOnly ==> ", readOnly);

            initComponents();

            initEventHandlers();

            _initialized = true;
        }

        function render(action) {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_sam_review::render..., action ==> " + action);
        }

        return {
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_sam_approval || (window.cms_incentives_sam_approval = cms_incentives_sam_approval());
})(window);
