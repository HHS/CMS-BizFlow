(function (window) {
    var cms_incentives_sam_approval = function () {
        var _readOnly = false;
        var _initialized = false;

        var _generalTabEnabled = false;
        var _positionTabEnabled = false;
        var _samDetailsTabEnabled = false;
        var _samReviewTabEnabled = false;
        var _generalTabDisabledObjects = [];
        var _positionTabDisabledObjects = [];
        var _samDetailsTabDisabledObjects = [];
        var _samReviewTabDisabledObjects = [];

        var SELECTEE_MEET_CRITERIA = {
            SUPERIOR: "Superior Qualifications",
            AGENCY_NEED: "Fills a special agency need"
        };

        function onSelecteeMeetCriteria(value) {
            FormMain.setComponentVisibility("specialAgencyNeedCriteria_group", value === SELECTEE_MEET_CRITERIA.AGENCY_NEED);
            FormMain.setComponentVisibility("superiorQualificationCriteria_group", value === SELECTEE_MEET_CRITERIA.SUPERIOR);
        }

        function setApproverAndApprovalDate(eleId, dateEleId, checked) {
            var currentUserName = "";
            var currentUserId = "";
            var currentDate = "";
            if (checked) {
                currentUserName = myInfo.getMyName();
                currentUserId = myInfo.getMyMemberId();
                currentDate = FormUtility.getDateString(false, "mm/dd/yyyy", new Date());
            }

            $("#" + eleId).val(currentUserName);
            $("#" + dateEleId).val(currentDate);

            FormState.updateTextValue(eleId, currentUserName, false);
            FormState.updateTextValue(eleId + "Id", currentUserId, false);
            FormState.updateDateValue(dateEleId, currentDate, false);
        }

        function onSupportSAMChanged(value) {
            if ("Yes" === value) {
                FormState.updateSelectValue("approvalSOValue", "Approve", "Approve", true);
            } else if ("No" === value) {
                FormState.updateSelectValue("approvalSOValue", "Disapprove", "Disapprove", true);
            } else {
                FormState.updateSelectValue("approvalSOValue", "", "Select One", true);
            }
            FormMain.setComponentUsability("approvalSOValue", false);
            $("#approvalSOValue").trigger("change");
        }

        function saveDisabledObject() {
            _generalTabEnabled = !(TabManager.getTab(MENU_TAB.GENERAL)).readOnly;
            _positionTabEnabled = !(TabManager.getTab(MENU_TAB.POSITION)).readOnly;
            _samDetailsTabEnabled = !(TabManager.getTab(MENU_TAB.SAM_DETAILS)).readOnly;
            _samReviewTabEnabled = !(TabManager.getTab(MENU_TAB.SAM_REVIEW)).readOnly;
            if(_generalTabEnabled) {
                _generalTabDisabledObjects = FormMain.getDisabledObjects(MENU_TAB.GENERAL);
            }
            if(_positionTabEnabled) {
                _positionTabDisabledObjects = FormMain.getDisabledObjects(MENU_TAB.POSITION);
            }
            if(_samDetailsTabEnabled) {
                _samDetailsTabDisabledObjects = FormMain.getDisabledObjects(MENU_TAB.SAM_DETAILS);
            }
            if(_samReviewTabEnabled) {
                _samReviewTabDisabledObjects = FormMain.getDisabledObjects(MENU_TAB.SAM_REVIEW);
            }
        }

        function initTabVisibility() {
            if (_initialized) {
                var value = $("#approvalSOValue").val();
                if ("Approve" == value) {
                    // if(_generalTabEnabled) {
                    //     TabManager.enableTab(MENU_TAB.GENERAL);
                    //     if(_generalTabDisabledObjects && _generalTabDisabledObjects.length > 0) {
                    //         for (var i in _generalTabDisabledObjects) {
                    //             FormMain.setComponentUsability(_generalTabDisabledObjects[i], false);
                    //         }
                    //     }
                    // }
                    // if(_positionTabEnabled) {
                    //     TabManager.enableTab(MENU_TAB.POSITION);
                    //     if(_positionTabDisabledObjects && _positionTabDisabledObjects.length > 0) {
                    //         for (var i in _positionTabDisabledObjects) {
                    //             FormMain.setComponentUsability(_positionTabDisabledObjects[i], false);
                    //         }
                    //     }
                    // }
                    // if(_samDetailsTabEnabled) {
                    //     TabManager.enableTab(MENU_TAB.SAM_DETAILS);
                    //     if(_samDetailsTabDisabledObjects && _samDetailsTabDisabledObjects.length > 0) {
                    //         for (var i in _samDetailsTabDisabledObjects) {
                    //             FormMain.setComponentUsability(_samDetailsTabDisabledObjects[i], false);
                    //         }
                    //     }
                    // }
                    // if(_samReviewTabEnabled) {
                    //     TabManager.enableTab(MENU_TAB.SAM_REVIEW);
                    //     if(_samReviewTabDisabledObjects && _samReviewTabDisabledObjects.length > 0) {
                    //         for (var i in _samReviewTabDisabledObjects) {
                    //             FormMain.setComponentUsability(_samReviewTabDisabledObjects[i], false);
                    //         }
                    //     }
                    // }
                    TabManager.enableTab(MENU_TAB.SAM_DETAILS);
                    FormMain.setTabVisibility(INCENTIVES_TYPE.SAM, "", false);
                } else if ("Disapprove" == value) {
                    // saveDisabledObject();
                    TabManager.disableTab(MENU_TAB.GENERAL);
                    TabManager.disableTab(MENU_TAB.POSITION);
                    TabManager.disableTab(MENU_TAB.SAM_DETAILS);
                    TabManager.disableTab(MENU_TAB.SAM_REVIEW);

                    TabManager.hideTabHeader(MENU_TAB.SAM_JUSTIFICATION);
                    // TabManager.resetTabs();

                }
            } else {
                // saveDisabledObject();
                var value = FormState.getElementValue("approvalSOValue");
                if ("Approve" == value) {
                    //
                } else if ("Disapprove" == value) {
                    TabManager.disableTab(MENU_TAB.GENERAL);
                    TabManager.disableTab(MENU_TAB.POSITION);
                    TabManager.disableTab(MENU_TAB.SAM_DETAILS);
                    TabManager.disableTab(MENU_TAB.SAM_REVIEW);
                    TabManager.hideTabHeader(MENU_TAB.SAM_JUSTIFICATION);
                    TabManager.resetTabs();
                }
            }
            if(cms_incentives_sam_details) {
                cms_incentives_sam_details.resetUsabilitySupportSAM();
            }
        }

        function initEventHandlers() {
            $('#approvalSOCheck').on('change', function (e) {
                var target = e.target;
                setApproverAndApprovalDate("approvalSO", "approvalSOResponseDate", target.checked);
            });
            $('#approvalSOValue').on('change', function (e) {
                // var target = e.target;
                // var value = target.options[target.options.selectedIndex].value;
                // setApproverAndApprovalDate("approvalSO", "approvalSOResponseDate", value !== "");
                initTabVisibility();
            });
            $('#approvalSOActing').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                var text = target.options[target.options.selectedIndex].text;
                FormState.updateSelectValue("approvalSOActing", value, text, false);
            });
            $('#approvalCOCCheck').on('change', function (e) {
                var target = e.target;
                if(!target.checked) {
                    $("#approvalCOCValue").val("");
                }
                setApproverAndApprovalDate("approvalCOC", "approvalCOCResponseDate", target.checked);
            });
            $('#approvalCOCValue').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                if (_initialized) {
                    if (activityStep.isCOCReview()) {
                        // var approvalCOCActing = FormState.getElementValue("approvalCOCActing", "");
                        // if (("" != approvalCOCActing) && (("Approve" == value) || ("Disapprove" == value))) {
                        //     hyf.util.setComponentUsability('button_SubmitWorkitem', true);
                        // } else {
                        //     hyf.util.setComponentUsability('button_SubmitWorkitem', false);
                        // }
                        if (("Approve" == value) || ("Disapprove" == value)) {
                            hyf.util.setComponentUsability('button_SubmitWorkitem', true);
                        } else {
                            hyf.util.setComponentUsability('button_SubmitWorkitem', false);
                        }
                    }
                }
                setApproverAndApprovalDate("approvalCOC", "approvalCOCResponseDate", value !== "");
            });
            $('#approvalCOCActing').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                var text = target.options[target.options.selectedIndex].text;
                // var approvalCOCValue = FormState.getElementValue("approvalCOCValue", "");
                // if ( ("" != value) && (("Approve" == approvalCOCValue) || ("Disapprove" == approvalCOCValue))) {
                //     hyf.util.setComponentUsability('button_SubmitWorkitem', true);
                // } else {
                //     hyf.util.setComponentUsability('button_SubmitWorkitem', false);
                // }
                FormState.updateSelectValue("approvalCOCActing", value, text, false);
            });
            $('#approvalDGHOCheck').on('change', function (e) {
                var target = e.target;
                if(!target.checked) {
                    $("#approvalDGHOValue").val("");
                }
                setApproverAndApprovalDate("approvalDGHO", "approvalDGHOResponseDate", target.checked);
            });
            $('#approvalDGHOValue').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                if ("Approve" == value) {
                    $("#button_SubmitWorkitem").attr("value", "Send to TABG");
                } else if ("Disapprove" == value) {
                    $("#button_SubmitWorkitem").attr("value", "Send to HR");
                }
                setApproverAndApprovalDate("approvalDGHO", "approvalDGHOResponseDate", value !== "");
            });
            $('#approvalDGHOActing').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                var text = target.options[target.options.selectedIndex].text;
                FormState.updateSelectValue("approvalDGHOActing", value, text, false);
            });
            $('#approvalTABGCheck').on('change', function (e) {
                var target = e.target;
                if(!target.checked) {
                    $("#approvalTABGValue").val("");
                }
                setApproverAndApprovalDate("approvalTABG", "approvalTABGResponseDate", target.checked);
            });
            $('#approvalTABGValue').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
				var ohcApproval = FormState.getElementValue("requireOHCApproval");
                 if ("Approve" == value && ohcApproval=="Yes") {
                    $("#button_SubmitWorkitem").attr("value", "Send to OHC");
                } else {
                    $("#button_SubmitWorkitem").attr("value", "Send to HR");
                }
                setApproverAndApprovalDate("approvalTABG", "approvalTABGResponseDate", value !== "");
            });
            $('#approvalTABGActing').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                var text = target.options[target.options.selectedIndex].text;
                FormState.updateSelectValue("approvalTABGActing", value, text, false);
            });
            $('#approvalOHCCheck').on('change', function (e) {
                var target = e.target;
                if(!target.checked) {
                    $("#approvalOHCValue").val("");
                }
                setApproverAndApprovalDate("approvalOHC", "approvalOHCResponseDate", target.checked);
            });
            $('#approvalOHCValue').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                setApproverAndApprovalDate("approvalOHC", "approvalOHCResponseDate", value !== "");
            });
            $('#approvalOHCActing').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                var text = target.options[target.options.selectedIndex].text;
                FormState.updateSelectValue("approvalOHCActing", value, text, false);
            });
        }

        function setApproverNotesVisibility() {
            var reviewRecommendedSalaries = FormState.getElementArrayValue("reviewRecommendedSalaries", []);
            if (reviewRecommendedSalaries.length === 1) {
                if (typeof reviewRecommendedSalaries[0].witemSeq === 'undefined') {
                    reviewRecommendedSalaries = [];
                }
            }

            if (reviewRecommendedSalaries.length > 0) {
                if (activityStep.isHRSReview()) {
                    hyf.util.showComponent("approverNotes_group");
                    hyf.util.disableComponent("approverNotes");
                } else if (activityStep.isDGHOReview() || activityStep.isTABGReview() || activityStep.isOHCReview()) {
                    hyf.util.showComponent("approverNotes_group");
                    hyf.util.enableComponent("approverNotes");
                }
            } else {
                hyf.util.hideComponent("approverNotes_group");
                FormState.updateTextValue("approverNotes", "", false);
            }
        }

        function setSignUsability() {
            var isSO = accessControl.isDesignatedSO();
            FormMain.setComponentUsability("approvalSOCheck", isSO);
            hyf.util.setMandatoryConstraint("approvalSOCheck", isSO);
            FormMain.setComponentUsability("approvalSOValue", isSO);
            hyf.util.setMandatoryConstraint("approvalSOValue", isSO);
            FormMain.setComponentUsability("approvalSOActing", isSO);
            hyf.util.setMandatoryConstraint("approvalSOActing", isSO);
            onSupportSAMChanged(FormState.getElementValue("supportSAM"));

            var isCOC = accessControl.isDesignatedCOC();
            FormMain.setComponentUsability("approvalCOCCheck", isCOC);
            hyf.util.setMandatoryConstraint("approvalCOCCheck", isCOC);
            FormMain.setComponentUsability("approvalCOCValue", isCOC);
            hyf.util.setMandatoryConstraint("approvalCOCValue", isCOC);
            FormMain.setComponentUsability("approvalCOCActing", isCOC);
            hyf.util.setMandatoryConstraint("approvalCOCActing", isCOC);

            var isDGHO = myInfo.isDGHO();
            FormMain.setComponentUsability("approvalDGHOCheck", isDGHO);
            hyf.util.setMandatoryConstraint("approvalDGHOCheck", isDGHO);
            FormMain.setComponentUsability("approvalDGHOValue", isDGHO);
            hyf.util.setMandatoryConstraint("approvalDGHOValue", isDGHO);
            FormMain.setComponentUsability("approvalDGHOActing", isDGHO);
            hyf.util.setMandatoryConstraint("approvalDGHOActing", isDGHO);

            var isTABG = myInfo.isTABG();
            FormMain.setComponentUsability("approvalTABGCheck", isTABG);
            hyf.util.setMandatoryConstraint("approvalTABGCheck", isTABG);
            FormMain.setComponentUsability("approvalTABGValue", isTABG);
            hyf.util.setMandatoryConstraint("approvalTABGValue", isTABG);
            FormMain.setComponentUsability("approvalTABGActing", isTABG);
            hyf.util.setMandatoryConstraint("approvalTABGActing", isTABG);

            var isOHC = accessControl.isDesignatedOHC("reviewRcmdApprovalOHCDirector");
            FormMain.setComponentUsability("approvalOHCCheck", isOHC);
            hyf.util.setMandatoryConstraint("approvalOHCCheck", isOHC);
            FormMain.setComponentUsability("approvalOHCValue", isOHC);
            hyf.util.setMandatoryConstraint("approvalOHCValue", isOHC);
            FormMain.setComponentUsability("approvalOHCActing", isOHC);
            hyf.util.setMandatoryConstraint("approvalOHCActing", isOHC);
        }

        function initComponents() {
            setSignUsability();
            setApproverNotesVisibility();
        }

        function init(readOnly, tabObject) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();
            initTabVisibility();
            FormMain.resetMandatoryMark(tabObject);
            _initialized = true;
        }

        function render(action) {
        }

        return {
            setApproverNotesVisibility: setApproverNotesVisibility,
            onSupportSAMChanged: onSupportSAMChanged,
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_sam_approval || (window.cms_incentives_sam_approval = cms_incentives_sam_approval());
})(window);
