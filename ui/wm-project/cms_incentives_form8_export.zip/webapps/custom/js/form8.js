(function (window) {
    var cms_incentives_sam_approval = function () {
        var _readOnly = false;
        var _initialized = false;

        var SELECTEE_MEET_CRITERIA = {
            SUPERIOR: "Superior Qualifications",
            AGENCY_NEED: "Fills a special agency need"
        };

        function onSelecteeMeetCriteria(value) {
            hyf.util.setComponentVisibility("specialAgencyNeedCriteria_group", value === SELECTEE_MEET_CRITERIA.AGENCY_NEED);
            hyf.util.setComponentVisibility("superiorQualificationCriteria_group", value === SELECTEE_MEET_CRITERIA.SUPERIOR);
        }

        function setApproverAndApprovalDate(eleId, dateEleId, checked) {
            var currentUserName = "";
            var currentDate = "";
            if (checked) {
                currentUserName = myInfo.getMyName();
                currentDate = FormUtility.getDateString(false, "mm/dd/yyyy", new Date());
            }

            $("#" + eleId).val(currentUserName);
            $("#" + dateEleId).val(currentDate);

            FormState.updateTextValue(eleId, currentUserName, false);
            FormState.updateDateValue(dateEleId, currentDate, false);
        }

        function initEventHandlers() {
            $('#approvalSOValue').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                setApproverAndApprovalDate("approvalSO", "approvalSOResponseDate", value !== "");
            });
            $('#approvalDGHOValue').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                setApproverAndApprovalDate("approvalDGHO", "approvalDGHOResponseDate", value !== "");
            });
            $('#approvalTABGValue').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                setApproverAndApprovalDate("approvalTABG", "approvalTABGResponseDate", value !== "");
            });
            $('#approvalOHCValue').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                setApproverAndApprovalDate("approvalOHC", "approvalOHCResponseDate", value !== "");
            });
        }

        function setSignUsability() {
            var isSO = accessControl.isDesignatedSO();
            hyf.util.setComponentUsability("approvalSOCheck", isSO);
            hyf.util.setMandatoryConstraint("approvalSOCheck", isSO);
            hyf.util.setComponentUsability("approvalSOValue", isSO);
            hyf.util.setMandatoryConstraint("approvalSOValue", isSO);

            var isDGHO = accessControl.isDesignatedDGHO();
            hyf.util.setComponentUsability("approvalDGHOCheck", isDGHO);
            hyf.util.setMandatoryConstraint("approvalDGHOCheck", isDGHO);
            hyf.util.setComponentUsability("approvalDGHOValue", isDGHO);
            hyf.util.setMandatoryConstraint("approvalDGHOValue", isDGHO);

            var isTABG = accessControl.isDesignatedTABG();
            hyf.util.setComponentUsability("approvalTABGCheck", isTABG);
            hyf.util.setMandatoryConstraint("approvalTABGCheck", isTABG);
            hyf.util.setComponentUsability("approvalTABGValue", isTABG);
            hyf.util.setMandatoryConstraint("approvalTABGValue", isTABG);

            var isOHC = accessControl.isDesignatedOHC();
            hyf.util.setComponentUsability("approvalOHCCheck", isOHC);
            hyf.util.setMandatoryConstraint("approvalOHCCheck", isOHC);
            hyf.util.setComponentUsability("approvalOHCValue", isOHC);
            hyf.util.setMandatoryConstraint("approvalOHCValue", isOHC);
        }

        function initComponents() {
            hyf.util.disableComponent("approvalSOResponseDate");
            hyf.util.disableComponent("approvalDGHOResponseDate");
            hyf.util.disableComponent("approvalTABGResponseDate");
            hyf.util.disableComponent("approvalOHCResponseDate");

            setSignUsability();
        }

        function init(readOnly) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();

            _initialized = true;
        }

        function render(action) {
        }

        return {
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_sam_approval || (window.cms_incentives_sam_approval = cms_incentives_sam_approval());
})(window);
