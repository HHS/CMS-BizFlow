(function (window) {
    var cms_incentives_pca_details = function () {
        var _readOnly = false;
        var _initialized = false;
        var _licenseState_ac = null;
        var _boardCertSpecialty_ac = null;

        var _categoryAllowanceMax = {
            UNDER_24M_GS13: 8000,
            UNDER_24M_GS14: 9000,
            UNDER_24M_GS15: 10000,
            MORE_THAN_24M_GS13: 8000,
            MORE_THAN_24M_GS14: 12000,
            MORE_THAN_24M_GS15: 16000,
            UNDER_24M_ES: 10000,
            MORE_THAN_24M_ES: 16000
        };

        var _boardCertAllowance = {
            NO: "$0.00",
            YES: "$3,000.00"
        };

        var _multiYearAllowance = {
            ONE: "$0.00",
            TWO: "$4,000.00",
            THREE: "$5,000.00",
            FOUR: "$6,000.00"
        };

        var _missionAllowanceMax = {
            MORE_THAN_ONE_YEAR_GS_13: 5000,
            MORE_THAN_ONE_YEAR_GS_14: 8000,
            MORE_THAN_ONE_YEAR_GS_15: 10000,
            MORE_THAN_ONE_YEAR_GS_OTHER: 0,
            MORE_THAN_ONE_YEAR_ES: 10000,
            NOT_GS_ES: 0
        };

        var _totalAllowanceMax = {
            UNDER_24M: 14000,
            MORE_THAN_24M: 30000
        };

        function initCategoryAllowanceMax() {
            var lookupData = LookupManager.findByLTYPE('Incentives-Allowance-Category');
            if (lookupData) {
                for (var i = 0; i < lookupData.length; i++) {
                    var item = lookupData[i];
                    if (item) {
                        if (item.LABEL === "UNDER_24M_GS13") _categoryAllowanceMax.UNDER_24M_GS13 = FormUtility.parseInt(item.NAME);
                        if (item.LABEL === "UNDER_24M_GS14") _categoryAllowanceMax.UNDER_24M_GS14 = FormUtility.parseInt(item.NAME);
                        if (item.LABEL === "UNDER_24M_GS15") _categoryAllowanceMax.UNDER_24M_GS15 = FormUtility.parseInt(item.NAME);
                        if (item.LABEL === "MORE_THAN_24M_GS13") _categoryAllowanceMax.MORE_THAN_24M_GS13 = FormUtility.parseInt(item.NAME);
                        if (item.LABEL === "MORE_THAN_24M_GS14") _categoryAllowanceMax.MORE_THAN_24M_GS14 = FormUtility.parseInt(item.NAME);
                        if (item.LABEL === "MORE_THAN_24M_GS15") _categoryAllowanceMax.MORE_THAN_24M_GS15 = FormUtility.parseInt(item.NAME);
                        if (item.LABEL === "UNDER_24M_ES") _categoryAllowanceMax.UNDER_24M_ES = FormUtility.parseInt(item.NAME);
                        if (item.LABEL === "MORE_THAN_24M_ES") _categoryAllowanceMax.MORE_THAN_24M_ES = FormUtility.parseInt(item.NAME);
                    }
                }
            }
        }

        function initBoardCertAllowance() {
            var lookupData = LookupManager.findByLTYPE('Incentives-Allowance-Board-Cert');
            if (lookupData) {
                for (var i = 0; i < lookupData.length; i++) {
                    var item = lookupData[i];
                    if (item) {
                        if (item.LABEL === "NO") _boardCertAllowance.NO = item.NAME;
                        if (item.LABEL === "YES") _boardCertAllowance.YES = item.NAME;
                    }
                }
            }
        }

        function initMultiYearAllowance() {
            var lookupData = LookupManager.findByLTYPE('Incentives-Allowance-Multi-Year');
            if (lookupData) {
                for (var i = 0; i < lookupData.length; i++) {
                    var item = lookupData[i];
                    if (item) {
                        if (item.LABEL === "ONE") _multiYearAllowance.ONE = item.NAME;
                        if (item.LABEL === "TWO") _multiYearAllowance.TWO = item.NAME;
                        if (item.LABEL === "THREE") _multiYearAllowance.THREE = item.NAME;
                        if (item.LABEL === "FOUR") _multiYearAllowance.FOUR = item.NAME;
                    }
                }
            }
        }

        function initMissionAllowanceMax() {
            var lookupData = LookupManager.findByLTYPE('Incentives-Allowance-Mission');
            if (lookupData) {
                for (var i = 0; i < lookupData.length; i++) {
                    var item = lookupData[i];
                    if (item) {
                        if (item.LABEL === "MORE_THAN_ONE_YEAR_GS_13") _missionAllowanceMax.MORE_THAN_ONE_YEAR_GS_13 = FormUtility.parseInt(item.NAME);
                        if (item.LABEL === "MORE_THAN_ONE_YEAR_GS_14") _missionAllowanceMax.MORE_THAN_ONE_YEAR_GS_14 = FormUtility.parseInt(item.NAME);
                        if (item.LABEL === "MORE_THAN_ONE_YEAR_GS_15") _missionAllowanceMax.MORE_THAN_ONE_YEAR_GS_15 = FormUtility.parseInt(item.NAME);
                        if (item.LABEL === "MORE_THAN_ONE_YEAR_GS_OTHER") _missionAllowanceMax.MORE_THAN_ONE_YEAR_GS_OTHER = FormUtility.parseInt(item.NAME);
                        if (item.LABEL === "MORE_THAN_ONE_YEAR_ES") _missionAllowanceMax.MORE_THAN_ONE_YEAR_ES = FormUtility.parseInt(item.NAME);
                        if (item.LABEL === "NOT_GS_ES") _missionAllowanceMax.NOT_GS_ES = FormUtility.parseInt(item.NAME);
                    }
                }
            }
        }


        function initTotalAllowanceMax() {
            var lookupData = LookupManager.findByLTYPE('Incentives-Allowance-Total');
            if (lookupData) {
                for (var i = 0; i < lookupData.length; i++) {
                    var item = lookupData[i];
                    if (item) {
                        if (item.LABEL === "UNDER_24M") _totalAllowanceMax.UNDER_24M = FormUtility.parseInt(item.NAME);
                        if (item.LABEL === "MORE_THAN_24M") _totalAllowanceMax.MORE_THAN_24M = FormUtility.parseInt(item.NAME);
                    }
                }
            }
        }

        function initLookupData() {
            if (!_initialized) {
                initCategoryAllowanceMax();
                initBoardCertAllowance();
                initMultiYearAllowance();
                initMissionAllowanceMax();
                initTotalAllowanceMax();
            }
        }

        function setLicenseStateAutoCompletion() {
            var option = {
                id: 'licenseState_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchStates.do?q=',
                minLength: 2,
                minSelectionCount: 1,
                maxSelectionCount: 2,
                readOnly: _readOnly,

                mapFunction: function (context) {
                    return {
                        state: $("STATE", context).text(),
                        name: $("NAME", context).text(),
                        expDate: ''
                    };
                },
                getSelectionLabel: function (item) {
                    return item.name + " (" + item.state + ")";
                },
                getCandidateLabel: function (item) {
                    return item.name + " (" + item.state + ")";
                },
                getItemID: function (item) {
                    return item.state;
                },
                setDataToForm: function (values) {
                    FormState.updateObjectValue('licenseState', values);
                },
                beforeDisplayItems: function () {
                    $('#licenseStateDisp1 li').each(function () {
                        $(this).remove();
                    });
                    $('#licenseStateDisp2 li').each(function () {
                        $(this).remove();
                    });
                },
                getDisplayItemContainerId: function (index) {
                    return "licenseStateDisp" + (index + 1);
                },
                afterItemDisplayed: function (containerId, item) {
                    var index = containerId.substring(containerId.length - 1);
                    $("#licenseExpDate" + index).attr("targetId", this.getItemID(item));
                    FormState.updateDateValue("licenseExpDate" + index, item.expDate, true);
                    hyf.util.showComponent("licenseState" + index + "_group");
                },
                afterItemDeleted: function (containerId) {
                    var index = containerId.substring(containerId.length - 1);
                    hyf.util.hideComponent("licenseState" + index + "_group");
                    $("#licenseExpDate" + index).val("");
                },
                initialItems: FormState.getElementArrayValue('licenseState', [])
            };

            _licenseState_ac = FormAutoComplete.makeAutoCompletion(option);

            if (FormUtility.isReadOnly() == false) {
                $('#licenseStateDisp1').delegate("img", "click keyup", _licenseState_ac.deleteItemByEvent);
                $('#licenseStateDisp2').delegate("img", "click keyup", _licenseState_ac.deleteItemByEvent);
            }
        }

        function setBoardCertSpecialtyAutoCompletion() {
            var option = {
                id: 'boardCertSpecialty',
                useAddButton: true,
                addButtonTooltip: "Click the button to add a selection to the Board Certification Specialty list",
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                minSelectionCount: 1,
                maxSelectionCount: 3,
                readOnly: _readOnly,

                mapFunction: function (context) {
                },
                getSelectionLabel: function (item) {
                    return item.text;
                },
                getCandidateLabel: function (item) {
                    return item.value;
                },
                getItemID: function (item) {
                    return item.value;
                },
                setDataToForm: function (values) {
                    FormState.updateObjectValue('boardCertSpecialty', values);
                    handleOtherSpeciality(values);
                },
                sortSelectedValues: function (values) {
                    var other = null;
                    for (var i = 0; i < values.length; i++) {
                        var item = values[i];
                        if (item.value === 'Other') {
                            other = item;
                            values.splice(i, 1);
                            break;
                        }
                    }

                    values.sort(function (a, b) {
                        return a.value > b.value;
                    });

                    if (other !== null) {
                        values.push(item);
                    }

                    return values;
                },
                isValidListItem: function (item, target) {
                    return item.value !== "";
                },
                afterItemDisplayed: function (containerId, item) {
                    FormUtility.removeSelectOption(item.value, "boardCertSpecialty");
                },
                afterItemDeleted: function (containerId, targetId, item, values) {
                    var target = FormUtility.addSelectionAndSortExceptLast(item.text, item.value, "boardCertSpecialty", "Other");
                    target.selectedIndex = values.length === 0 ? 0 : -1;
                },
                initialItems: FormState.getElementArrayValue('boardCertSpecialty', [])
            };

            _boardCertSpecialty_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        function setAllowanceCategoryValue(value, opt) {
            opt = opt || {};
            value = value || '';

            FormState.updateDijitInputInner("allowanceCategory", value);
            opt.allowanceCategory = FormUtility.moneyToNumber(value, 0);
            handleAllowanceTotal(opt);
        }

        function setAllowanceCategoryValueRange(opt) {
            opt = opt || {};
            var lengthOfServed = undefined !== opt.lengthOfServed ? opt.lengthOfServed : FormState.getElementValue("lengthOfServed");

            var payPlan = undefined !== opt.payPlan ? opt.payPlan : FormState.getElementValue("payPlan");
            var grade = FormUtility.parseInt(undefined !== opt.grade ? opt.grade : FormState.getElementValue("grade"), -1);
            var max = 9999999;

            if (lengthOfServed === "0 to 24 Months") {
                if (payPlan === "GS") {
                    if (grade === 13) max = _categoryAllowanceMax.UNDER_24M_GS13;
                    else if (grade === 14) max = _categoryAllowanceMax.UNDER_24M_GS14;
                    else if (grade === 15) max = _categoryAllowanceMax.UNDER_24M_GS15;
                } else if (payPlan === "ES") {
                    max = _categoryAllowanceMax.UNDER_24M_ES;
                }
            } else if (lengthOfServed === "More than 24 Months") {
                if (payPlan === "GS") {
                    if (grade === 13) max = _categoryAllowanceMax.MORE_THAN_24M_GS13;
                    else if (grade === 14) max = _categoryAllowanceMax.MORE_THAN_24M_GS14;
                    else if (grade === 15) max = _categoryAllowanceMax.MORE_THAN_24M_GS15;
                } else if (payPlan === "ES") {
                    max = _categoryAllowanceMax.MORE_THAN_24M_ES;
                }
            }

            var field = document.getElementById("allowanceCategory");
            if (field) {
                field.setAttribute("data-wm-error-msg", "The allowance must be less than or equal to $" + max.format(0));
                field.setAttribute("aria-valuemax", max);
                FormUtility.setInclusiveRangeConstraint(field, 0, max);
            }

            if (_initialized) {
                setAllowanceCategoryValue("", opt);
            }

        }

        function updateAllowanceBoardCertificationTooltip(field, value) {
            FormUtility.addElementSuffixTooltip(field, " Allowance for Board Certification is " + value + ".");
        }

        function setAllowanceBoardCertificationValue(requireBoardCert) {
            requireBoardCert = requireBoardCert || FormState.getElementValue("requireBoardCert");
            var value = "No" === requireBoardCert ? _boardCertAllowance.NO : _boardCertAllowance.YES;

            updateAllowanceBoardCertificationTooltip("allowanceBoardCertification", value);
            FormState.updateDijitInputInner("allowanceBoardCertification", value);
            handleAllowanceTotal({allowanceBoardCertification: value});
        }

        function updateAllowanceMultiYearAgreementTooltip(field, value) {
            FormUtility.addElementSuffixTooltip(field, " Allowance for Multi-Year Agreement is " + value + ".");
        }

        function setAllowanceMultiYearAgreementValue(opt) {
            opt = opt || {};
            var lengthOfService = FormUtility.parseInt(undefined !== opt.lengthOfService ? opt.lengthOfService : FormState.getElementValue("lengthOfService"), 0);
            var value = "";

            if (1 === lengthOfService) {
                value = _multiYearAllowance.ONE;
            } else if (2 === lengthOfService) {
                value = _multiYearAllowance.TWO;
            } else if (3 === lengthOfService) {
                value = _multiYearAllowance.THREE;
            } else if (4 === lengthOfService) {
                value = _multiYearAllowance.FOUR;
            }

            updateAllowanceMultiYearAgreementTooltip("allowanceMultiYearAgreement", value);
            FormState.updateDijitInputInner("allowanceMultiYearAgreement", value);
            handleAllowanceTotal({allowanceMultiYearAgreement: value});
        }

        function setAllowanceMissionSpecificCriteriaValue(opt) {
            opt = opt || {};
            var lengthOfService = FormUtility.parseInt(undefined !== opt.lengthOfService ? opt.lengthOfService : FormState.getElementValue("lengthOfService"), 0);
            var payPlan = opt.payPlan || FormState.getElementValue("payPlan");
            var grade = FormUtility.parseInt(undefined !== opt.grade ? opt.grade : FormState.getElementValue("grade"), -1);

            hyf.util.disableComponent("allowanceMissionSpecificCriteria");

            if (lengthOfService > 1) {
                var max = _missionAllowanceMax.NOT_GS_ES;
                if ("GS" === payPlan) {
                    if (13 === grade) {
                        max = _missionAllowanceMax.MORE_THAN_ONE_YEAR_GS_13;
                    } else if (14 === grade) {
                        max = _missionAllowanceMax.MORE_THAN_ONE_YEAR_GS_14;
                    } else if (15 === grade) {
                        max = _missionAllowanceMax.MORE_THAN_ONE_YEAR_GS_15;
                    } else {
                        max = _missionAllowanceMax.MORE_THAN_ONE_YEAR_GS_OTHER;
                    }
                } else if ("ES" === payPlan) {
                    max = _missionAllowanceMax.MORE_THAN_ONE_YEAR_ES;
                }

                if (max > 0) {
                    var field = document.getElementById("allowanceMissionSpecificCriteria");
                    hyf.util.enableComponent("allowanceMissionSpecificCriteria");
                    field.setAttribute("data-wm-error-msg", "The allowance must be less than or equal to $" + max.format(0));
                    FormUtility.setInclusiveRangeConstraint(field, 0, max);
                }
            }

            FormState.updateDijitInputInner("allowanceMissionSpecificCriteria", "$0.00");
            handleAllowanceTotal({allowanceMissionSpecificCriteria: 0});
        }

        function handleBoardCertSpecialty(requireBoardCert) {
            requireBoardCert = "Yes" === (undefined !== requireBoardCert ? requireBoardCert : FormState.getElementValue("requireBoardCert"));
            hyf.util.setMandatoryConstraint("boardCertSpecialty", requireBoardCert);
            _boardCertSpecialty_ac.setMinSelectionCount(requireBoardCert ? 1 : 0);
        }

        function handleOtherSpeciality(boardCertSpecialties) {
            var otherSpeciality = false;
            for (var i = 0; i < boardCertSpecialties.length; i++) {
                var item = boardCertSpecialties[i];
                if (item.value === 'Other') {
                    otherSpeciality = true;
                    if (i < boardCertSpecialties.length - 1) {
                        boardCertSpecialties.splice(i, 1);
                        boardCertSpecialties.push(item);
                    }
                    break;
                }
            }

            if (true === otherSpeciality) {
                hyf.util.showComponent("otherSpeciality_group");
                var field = document.getElementById("otherSpeciality");
                if (field.value === "") {
                    field.focus();
                }
            } else {
                var field = document.getElementById("otherSpeciality");
                field.value = "";
                hyf.util.hideComponent("otherSpeciality_group");
            }
        }

        function calculateAllowanceTotal(opt) {
            opt = opt || {};
            var allowanceCategory = FormUtility.moneyToNumber(undefined !== opt.allowanceCategory ? opt.allowanceCategory : FormState.getElementValue("allowanceCategory"), 0);
            var allowanceBoardCertification = FormUtility.moneyToNumber(undefined !== opt.allowanceBoardCertification ? opt.allowanceBoardCertification : FormState.getElementValue("allowanceBoardCertification"), 0);
            var allowanceMultiYearAgreement = FormUtility.moneyToNumber(undefined !== opt.allowanceMultiYearAgreement ? opt.allowanceMultiYearAgreement : FormState.getElementValue("allowanceMultiYearAgreement"), 0);
            var allowanceMissionSpecificCriteria = FormUtility.moneyToNumber(undefined !== opt.allowanceMissionSpecificCriteria ? opt.allowanceMissionSpecificCriteria : FormState.getElementValue("allowanceMissionSpecificCriteria"), 0);

            return allowanceCategory + allowanceBoardCertification + allowanceMultiYearAgreement + allowanceMissionSpecificCriteria;
        }

        function updateTotalPayableTooltip(field, value) {
            FormUtility.addElementSuffixTooltip(field, " Total Payable PCA calculation is " + value + ".");
        }

        function setTotalPayablePCACalculation(totalPayablePCACalculationAmount, showExceedTotalPayableAmountMsg) {
            var totalPayablePCACalculation = document.getElementById("totalPayablePCACalculation");
            totalPayablePCACalculation.value = "$" + totalPayablePCACalculationAmount.format();
            FormState.updateObjectValue("totalPayablePCACalculation", totalPayablePCACalculation.value, false);

            updateTotalPayableTooltip(totalPayablePCACalculation, totalPayablePCACalculation.value);
            var exceedTotalPayableAmountMsg = document.getElementById("exceedTotalPayableAmountMsg");
            exceedTotalPayableAmountMsg.style.display = showExceedTotalPayableAmountMsg ? "" : "none";
        }

        function visibilityAllowanceTotalAndSetTotalPayablePCACalculation(total, opt) {
            opt = opt || {};
            total = undefined !== total ? total : FormUtility.moneyToNumber(FormState.getElementValue("allowanceTotal"));

            var totalPayablePCACalculation = 0;
            var showAllowanceTotal = false;
            var lengthOfServed = undefined !== opt.lengthOfServed ? opt.lengthOfServed : FormState.getElementValue("lengthOfServed");
            if (lengthOfServed === "0 to 24 Months") {
                if (total > _totalAllowanceMax.UNDER_24M) {
                    showAllowanceTotal = true;
                    totalPayablePCACalculation = _totalAllowanceMax.UNDER_24M;
                }
                else {
                    totalPayablePCACalculation = total;
                }
            } else if (lengthOfServed === "More than 24 Months") {
                if (total > _totalAllowanceMax.MORE_THAN_24M) {
                    showAllowanceTotal = true;
                    totalPayablePCACalculation = _totalAllowanceMax.MORE_THAN_24M;
                }
                else {
                    totalPayablePCACalculation = total;
                }
            }

            setTotalPayablePCACalculation(totalPayablePCACalculation, showAllowanceTotal);
        }

        function updateAllowanceTotalTooltip(field, value) {
            FormUtility.addElementSuffixTooltip(field, " Allowance Total is " + value + ".");
        }

        function handleAllowanceTotal(opt) {
            var total = calculateAllowanceTotal(opt);
            var value = "$" + total.format();

            FormState.updateDijitInputInner("allowanceTotal", value);
            updateAllowanceTotalTooltip("allowanceTotal", value);
            visibilityAllowanceTotalAndSetTotalPayablePCACalculation(total, opt);
        }

        function onGradeChanged(grade) {
            setAllowanceCategoryValueRange({grade: grade});
            setAllowanceMissionSpecificCriteriaValue({grade: grade});
        }

        function onPayPlanChanged(payPlan) {
            setAllowanceCategoryValueRange({payPlan: payPlan});
            setAllowanceMissionSpecificCriteriaValue({payPlan: payPlan});
        }

        function onRequireBoardCertChanged(requireBoardCert) {
            setAllowanceBoardCertificationValue(requireBoardCert);
            handleBoardCertSpecialty(requireBoardCert);
        }

        function updateLicenseExpDate(e) {
            var target = e.target;
            var value = target.value;
            var targetId = $(target).attr('targetId');
            var item = _licenseState_ac.getItem(targetId);
            if (item) {
                item.expDate = value;
                _licenseState_ac.updateItem(targetId, item);
            }
        }

        function initEventHandlers() {
            $('#lengthOfServed').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                setAllowanceCategoryValueRange({lengthOfServed: value});
            });

            $('#lengthOfService').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                setAllowanceMultiYearAgreementValue({lengthOfService: value});
                setAllowanceMissionSpecificCriteriaValue({lengthOfService: value});
            });

            $('#allowanceCategory').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                handleAllowanceTotal({allowanceCategory: value});
            });

            $('#allowanceBoardCertification').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                handleAllowanceTotal({allowanceBoardCertification: value});
            });

            $('#allowanceMultiYearAgreement').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                handleAllowanceTotal({allowanceMultiYearAgreement: value});
            });

            $('#allowanceMissionSpecificCriteria').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                handleAllowanceTotal({allowanceMissionSpecificCriteria: value});
            });

            $('#licenseExpDate1').on('change', updateLicenseExpDate);
            $('#licenseExpDate2').on('change', updateLicenseExpDate);
        }

        function initComponents() {
            if (_readOnly || FormUtility.isReadOnly()) {
                hyf.util.hideComponent("button_AddBoardCertSpecialty_group");
            }
            hyf.util.hideComponent("licenseState1_group");
            hyf.util.hideComponent("licenseState2_group");

            updateAllowanceBoardCertificationTooltip("allowanceBoardCertification", FormState.getElementArrayValue("allowanceBoardCertification", "$0.00"));
            updateAllowanceMultiYearAgreementTooltip("allowanceMultiYearAgreement", FormState.getElementArrayValue("allowanceMultiYearAgreement", "$0.00"));
            updateAllowanceTotalTooltip("allowanceTotal", FormState.getElementArrayValue("allowanceTotal", "$0.00"));

            setLicenseStateAutoCompletion();
            setBoardCertSpecialtyAutoCompletion();

            handleOtherSpeciality(FormState.getElementArrayValue('boardCertSpecialty', []));
            handleBoardCertSpecialty();
            visibilityAllowanceTotalAndSetTotalPayablePCACalculation();

            setAllowanceCategoryValueRange();
        }

        function reset() {
            _licenseState_ac.initializeItems([]);
            _boardCertSpecialty_ac.initializeItems([]);
            FormState.updateSelectValue("lengthOfServed", "", "Select One", true);
            FormState.updateSelectValue("lengthOfService", "", "Select One", true);
            FormState.updateTextValue("allowanceMultiYearAgreement", "0.00", true);
            FormState.updateTextValue("allowanceMissionSpecificCriteria", "0.00", true);
            FormState.updateTextValue("detailRemarks", "", true);
        }

        function init(readOnly, tabObject) {
            _readOnly = readOnly;

            initLookupData();
            initComponents();
            initEventHandlers();

            FormMain.resetMandatoryMark(tabObject);

            _initialized = true;
        }

        function render(action) {
        }

        return {
            reset: reset,
            init: init,
            render: render,
            onGradeChanged: onGradeChanged,
            onPayPlanChanged: onPayPlanChanged,
            onRequireBoardCertChanged: onRequireBoardCertChanged
        }
    };

    var _initializer = window.cms_incentives_pca_details || (window.cms_incentives_pca_details = cms_incentives_pca_details());
})(window);
