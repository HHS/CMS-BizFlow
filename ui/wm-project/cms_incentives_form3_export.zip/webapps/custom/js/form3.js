(function (window) {
    var cms_incentives_pca_details = function () {
        var _readOnly = false;
        var _initialized = false;
        var _licenseState_ac = null;

        var _categoryAllowanceMax = {
            UNDER_24M_GS13: 8000,
            UNDER_24M_GS14: 9000,
            UNDER_24M_GS15: 10000,
            MORE_THAN_24M_GS13: 8000,
            MORE_THAN_24M_GS14: 12000,
            MORE_THAN_24M_GS15: 16000
        };

        var _boardCertAllowance = {
            NO: "$0.00",
            YES: "$3,000.00"
        };

        var _multiYearAllowance = {
            ONE: "$0.00",
            TWO: "$4,000.00",
            THREE: "$5,000.00",
            FOUR: "$6,000.00"
        };

        var _missionAllowanceMax = {
            MORE_THAN_ONE_YEAR_GS_13: 5000,
            MORE_THAN_ONE_YEAR_GS_14: 8000,
            MORE_THAN_ONE_YEAR_GS_15: 10000,
            MORE_THAN_ONE_YEAR_GS_OTHER: 0,
            MORE_THAN_ONE_YEAR_ES: 10000
        };

        var _visibleTotalMax = {
            UNDER_24M: 14000,
            MORE_THAN_24M: 30000
        };

        function setLicenseStateAutoCompletion() {
            var option = {
                id: 'licenseState_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchStates.do?q=',
                minLength: 2,
                minSelectionCount: 1,
                maxSelectionCount: 2,
                readOnly: _readOnly,

                mapFunction: function (context) {
                    return {
                        state: $("STATE", context).text(),
                        expDate: ''
                    };
                },
                getSelectionLabel: function (item) {
                    return item.state
                },
                getCandidateLabel: function (item) {
                    return item.state
                },
                getItemID: function (item) {
                    return item.state;
                },
                setDataToForm: function (values) {
                    FormState.updateObjectValue('licenseState', values);
                },
                beforeDisplayItems: function () {
                    $('#licenseStateDisp1 li').each(function () {
                        $(this).remove();
                    });
                    $('#licenseStateDisp2 li').each(function () {
                        $(this).remove();
                    });
                },
                getDisplayItemContainerId: function (index) {
                    return "licenseStateDisp" + (index + 1);
                },
                afterDisplayItem: function (containerId, item) {
                    var index = containerId.substring(containerId.length - 1);
                    $("#licenseExpDate" + index).attr("targetId", this.getItemID(item));
                    FormState.updateDateValue("licenseExpDate" + index, item.expDate, true);
                    hyf.util.showComponent("licenseState" + index + "_group");
                },
                afterDeleteDisplayItem: function (containerId) {
                    var index = containerId.substring(containerId.length - 1);
                    hyf.util.hideComponent("licenseState" + index + "_group");
                    $("#licenseExpDate" + index).val("");
                },
                // initialize
                initialItems: FormState.getElementArrayValue('licenseState', [])
            };

            _licenseState_ac = FormAutoComplete.makeAutoCompletion(option);

            if (FormUtility.isReadOnly() == false) {
                $('#licenseStateDisp1').delegate("img", "click keyup", _licenseState_ac.deleteItemByEvent);
                $('#licenseStateDisp2').delegate("img", "click keyup", _licenseState_ac.deleteItemByEvent);
            }
        }

        function setAllowanceCategoryValue(value, opt) {
            opt = opt || {};
            value = value || '$0.00';
            var field = document.getElementById("allowanceCategory");
            field.value = value;
            FormState.updateDijitInputInner("allowanceCategory", field.value);

            opt.allowanceCategory = FormUtility.moneyToNumber(field.value, 0);
            handleAllowanceTotal(opt);
        }

        function setAllowanceCategoryValueRange(opt) {
            opt = opt || {};
            var lengthOfServed = undefined !== opt.lengthOfServed ? opt.lengthOfServed : FormState.getElementValue("lengthOfServed");

            var payPlan = undefined !== opt.payPlan ? opt.payPlan : FormState.getElementValue("payPlan");
            var grade = FormUtility.parseInt(undefined !== opt.grade ? opt.grade : FormState.getElementValue("grade"), -1);
            var max = 9999999;

            if (lengthOfServed === "0 to 24 Months") {
                if (payPlan === "GS") {
                    if (grade === 13) max = _categoryAllowanceMax.UNDER_24M_GS13; // 8000
                    else if (grade === 14) max = _categoryAllowanceMax.UNDER_24M_GS14;    // 9000
                    else if (grade === 15) max = _categoryAllowanceMax.UNDER_24M_GS15;    // 10000
                }
            } else if (lengthOfServed === "More than 24 Months") {
                if (payPlan === "GS") {
                    if (grade === 13) max = _categoryAllowanceMax.MORE_THAN_24M_GS13; // 8000
                    else if (grade === 14) max = _categoryAllowanceMax.MORE_THAN_24M_GS14;    // 12000
                    else if (grade === 15) max = _categoryAllowanceMax.MORE_THAN_24M_GS15;    // 16000
                }
            }

            var field = document.getElementById("allowanceCategory");
            field.setAttribute("data-wm-error-msg", "The allowance must be less than or equal to $" + max.format(0));
            field.setAttribute("aria-valuemax", max);

            hyf.util.setInclusiveRangeConstraint(field, 0, max);

            if (_initialized) {
                setAllowanceCategoryValue("$0.00", opt);
            }

        }

        function setAllowanceBoardCertificationValue(requireBoardCert) {
            requireBoardCert = requireBoardCert || FormState.getElementValue("requireBoardCert");
            var field = document.getElementById("allowanceBoardCertification");

            if ("No" === requireBoardCert) {
                field.value = _boardCertAllowance.NO; //"$0.00";
            } else {
                field.value = _boardCertAllowance.YES; //"$3,000.00";
            }

            FormState.updateDijitInputInner("allowanceBoardCertification", field.value);
            handleAllowanceTotal({allowanceBoardCertification: field.value});
        }

        function setAllowanceMultiYearAgreementValue(opt) {
            opt = opt || {};
            var lengthOfService = FormUtility.parseInt(undefined !== opt.lengthOfService ? opt.lengthOfService : FormState.getElementValue("lengthOfService"), 0);
            var field = document.getElementById("allowanceMultiYearAgreement");

            if (1 === lengthOfService) {
                field.value = _multiYearAllowance.ONE; // "$0.00";
            } else if (2 === lengthOfService) {
                field.value = _multiYearAllowance.TWO; // "$4,000.00";
            } else if (3 === lengthOfService) {
                field.value = _multiYearAllowance.THREE; // "$5,000.00";
            } else if (4 === lengthOfService) {
                field.value = _multiYearAllowance.FOUR; // "$6,000.00";
            }

            FormState.updateDijitInputInner("allowanceMultiYearAgreement", field.value);
            handleAllowanceTotal({allowanceMultiYearAgreement: field.value});
        }

        function setAllowanceMissionSpecificCriteriaValue(opt) {
            opt = opt || {};
            var lengthOfService = FormUtility.parseInt(undefined !== opt.lengthOfService ? opt.lengthOfService : FormState.getElementValue("lengthOfService"), 0);
            var payPlan = opt.payPlan || FormState.getElementValue("payPlan");
            var grade = FormUtility.parseInt(undefined !== opt.grade ? opt.grade : FormState.getElementValue("grade"), -1);

            var field = document.getElementById("allowanceMissionSpecificCriteria");

            hyf.util.disableComponent("allowanceMissionSpecificCriteria");

            if (lengthOfService > 1) {
                var max = 0;
                if ("GS" === payPlan) {
                    if (13 === grade) {
                        max = _missionAllowanceMax.MORE_THAN_ONE_YEAR_GS_13; // 5000;
                    } else if (14 === grade) {
                        max = _missionAllowanceMax.MORE_THAN_ONE_YEAR_GS_14; // 8000;
                    } else if (15 === grade) {
                        max = _missionAllowanceMax.MORE_THAN_ONE_YEAR_GS_15; // 10000;
                    } else {
                        max = _missionAllowanceMax.MORE_THAN_ONE_YEAR_GS_OTHER; // 0;
                    }
                } else if ("ES" === payPlan) {
                    max = _missionAllowanceMax.MORE_THAN_ONE_YEAR_ES; // 10000;
                }

                if (max > 0) {
                    hyf.util.enableComponent("allowanceMissionSpecificCriteria");
                    field.setAttribute("data-wm-error-msg", "The allowance must be less than or equal to $" + max.format(0));
                    hyf.util.setInclusiveRangeConstraint(field, 0, max);
                }
            }

            field.value = "$0.00";

            FormState.updateDijitInputInner("allowanceMissionSpecificCriteria", field.value);
            handleAllowanceTotal({allowanceMissionSpecificCriteria: FormUtility.moneyToNumber(field.value, 0)});
        }

        function handleBoardCertSpecialty(requireBoardCert) {
            requireBoardCert = undefined !== requireBoardCert ? requireBoardCert : FormState.getElementValue("requireBoardCert");
            hyf.util.setMandatoryConstraint("boardCertSpecialty", "Yes" == requireBoardCert);
        }

        function handleOtherSpeciality(otherSpeciality) {
            otherSpeciality = undefined !== otherSpeciality ? otherSpeciality : FormState.getElementValue("boardCertSpecialty9");
            if ("true" === otherSpeciality || true === otherSpeciality) {
                hyf.util.showComponent("otherSpeciality_group");
            } else {
                var field = document.getElementById("otherSpeciality");
                field.value = "";
                hyf.util.hideComponent("otherSpeciality_group");
            }
        }

        function calculateAllowanceTotal(opt) {
            opt = opt || {};
            var allowanceCategory = FormUtility.moneyToNumber(undefined !== opt.allowanceCategory ? opt.allowanceCategory : FormState.getElementValue("allowanceCategory"), 0);
            var allowanceBoardCertification = FormUtility.moneyToNumber(undefined !== opt.allowanceBoardCertification ? opt.allowanceBoardCertification : FormState.getElementValue("allowanceBoardCertification"), 0);
            var allowanceMultiYearAgreement = FormUtility.moneyToNumber(undefined !== opt.allowanceMultiYearAgreement ? opt.allowanceMultiYearAgreement : FormState.getElementValue("allowanceMultiYearAgreement"), 0);
            var allowanceMissionSpecificCriteria = FormUtility.moneyToNumber(undefined !== opt.allowanceMissionSpecificCriteria ? opt.allowanceMissionSpecificCriteria : FormState.getElementValue("allowanceMissionSpecificCriteria"), 0);

            return allowanceCategory + allowanceBoardCertification + allowanceMultiYearAgreement + allowanceMissionSpecificCriteria;
        }

        function setTotalPayablePCACalculation(totalPayablePCACalculationAmount, showExceedTotalPayableAmountMsg) {
            var totalPayablePCACalculation = document.getElementById("totalPayablePCACalculation");
            totalPayablePCACalculation.value = "$" + totalPayablePCACalculationAmount.format();
            FormState.updateObjectValue("totalPayablePCACalculation", totalPayablePCACalculation.value, false);

            var exceedTotalPayableAmountMsg = document.getElementById("exceedTotalPayableAmountMsg");
            exceedTotalPayableAmountMsg.style.display = showExceedTotalPayableAmountMsg ? "" : "none";
        }

        function visibilityAllowanceTotalAndSetTotalPayablePCACalculation(total, opt) {
            opt = opt || {};
            total = undefined !== total ? total : FormUtility.moneyToNumber(FormState.getElementValue("allowanceTotal"));

            var totalPayablePCACalculation = 0;
            var showAllowanceTotal = false;
            var lengthOfServed = undefined !== opt.lengthOfServed ? opt.lengthOfServed : FormState.getElementValue("lengthOfServed");
            if (lengthOfServed === "0 to 24 Months") {
                if (total > _visibleTotalMax.UNDER_24M) {
                    showAllowanceTotal = true;
                    totalPayablePCACalculation = _visibleTotalMax.UNDER_24M; // 14000;
                }
                else {
                    totalPayablePCACalculation = total;
                }
            } else if (lengthOfServed === "More than 24 Months") {
                if (total > _visibleTotalMax.MORE_THAN_24M) {
                    showAllowanceTotal = true;
                    totalPayablePCACalculation = _visibleTotalMax.MORE_THAN_24M; // 30000;
                }
                else {
                    totalPayablePCACalculation = total;
                }
            }

            if (showAllowanceTotal) {
                hyf.util.showComponent("allowanceTotal_group");
            } else {
                hyf.util.hideComponent("allowanceTotal_group");
            }

            setTotalPayablePCACalculation(totalPayablePCACalculation, showAllowanceTotal);
        }

        function handleAllowanceTotal(opt) {
            var total = calculateAllowanceTotal(opt);
            var field = document.getElementById("allowanceTotal");
            field.value = "$" + total.format();
            FormState.updateDijitInputInner("allowanceTotal", field.value);

            visibilityAllowanceTotalAndSetTotalPayablePCACalculation(total, opt);
        }

        function onGradeChanged(grade) {
            setAllowanceCategoryValueRange({grade: grade});
            setAllowanceMissionSpecificCriteriaValue({grade: grade});
        }

        function onPayPlanChanged(payPlan) {
            setAllowanceCategoryValueRange({payPlan: payPlan});
            setAllowanceMissionSpecificCriteriaValue({payPlan: payPlan});
        }

        function onRequireBoardCertChanged(requireBoardCert) {
            setAllowanceBoardCertificationValue(requireBoardCert);
            handleBoardCertSpecialty(requireBoardCert);
        }

        function updateLicenseExpDate(e) {
            var target = e.target;
            var value = target.value;
            var targetId = $(target).attr('targetId');
            var item = _licenseState_ac.getItem(targetId);
            if (item) {
                item.expDate = value;
                _licenseState_ac.updateItem(targetId, item);
            }
        }

        function initEventHandlers() {
            $('#lengthOfServed').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                setAllowanceCategoryValueRange({lengthOfServed: value});
            });

            $('#lengthOfService').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                setAllowanceMultiYearAgreementValue({lengthOfService: value});
                setAllowanceMissionSpecificCriteriaValue({lengthOfService: value});
            });

            $('#boardCertSpecialty9').on('change', function (e) {
                var target = e.target;
                var checked = target.checked;
                handleOtherSpeciality(checked);
            });

            $('#allowanceCategory').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                handleAllowanceTotal({allowanceCategory: value});
            });

            $('#allowanceBoardCertification').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                handleAllowanceTotal({allowanceBoardCertification: value});
            });

            $('#allowanceMultiYearAgreement').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                handleAllowanceTotal({allowanceMultiYearAgreement: value});
            });

            $('#allowanceMissionSpecificCriteria').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                handleAllowanceTotal({allowanceMissionSpecificCriteria: value});
            });

            $('#licenseExpDate1').on('change', updateLicenseExpDate);
            $('#licenseExpDate2').on('change', updateLicenseExpDate);

        }

        function initComponents() {
            hyf.util.hideComponent("licenseState1_group");
            hyf.util.hideComponent("licenseState2_group");
        }

        function init(readOnly) {
            _readOnly = readOnly;
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_pca_details::init, readOnly ==> ", readOnly);

            initComponents();

            handleOtherSpeciality();
            handleBoardCertSpecialty();
            visibilityAllowanceTotalAndSetTotalPayablePCACalculation();

            setAllowanceCategoryValueRange();
            setLicenseStateAutoCompletion();

            initEventHandlers();

            _initialized = true;
        }

        function render() {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_pca_details::render...");
        }

        return {
            init: init,
            render: render,
            onGradeChanged: onGradeChanged,
            onPayPlanChanged: onPayPlanChanged,
            onRequireBoardCertChanged: onRequireBoardCertChanged
        }
    };

    var _initializer = window.cms_incentives_pca_details || (window.cms_incentives_pca_details = cms_incentives_pca_details());
})(window);
