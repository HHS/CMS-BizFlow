(function (window) {
    var cms_incentives_pca_details = function () {
        var _initialized = false;

        function setAllowanceCategoryValue(value) {
            value = value || '$0.00';
            var field = document.getElementById("allowanceCategory");
            field.value = value;
            FormState.updateDijitInputInner("allowanceCategory", field.value);
            handleAllowanceTotal({allowanceCategory: FormUtility.moneyToNumber(field.value, 0)});
        }

        function setAllowanceCategoryValueRange(opt) {
            opt = opt || {};
            var lengthOfServed = undefined !== opt.lengthOfServed ? opt.lengthOfServed : FormState.getElementValue("lengthOfServed");

            var payPlan = undefined !== opt.payPlan ? opt.payPlan : FormState.getElementValue("payPlan");
            var grade = FormUtility.parseInt(undefined !== opt.grade ? opt.grade : FormState.getElementValue("grade"), -1);
            var max = 9999999;

            if (lengthOfServed === "0 to 24 Months") {
                if (payPlan === "GS") {
                    if (grade === 13) max = 8000;
                    else if (grade === 14) max = 9000;
                    else if (grade === 15) max = 10000;
                }
            } else if (lengthOfServed === "More than 24 Months") {
                if (payPlan === "GS") {
                    if (grade === 13) max = 8000;
                    else if (grade === 14) max = 12000;
                    else if (grade === 15) max = 16000;
                }
            }

            // FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_pca_details::setAllowanceCategoryValueRange - payPlan, grade, lengthOfServed, max ==> ", payPlan, grade, lengthOfServed, max);

            var field = document.getElementById("allowanceCategory");
            field.setAttribute("data-wm-error-msg", "The allowance must be less than or equal to $" + max.format(0));
            field.setAttribute("aria-valuemax", max);

            hyf.util.setInclusiveRangeConstraint(field, 0, max);

            if (_initialized) {
                setAllowanceCategoryValue();
            }

        }

        function setAllowanceBoardCertificationValue(requireBoardCert) {
            requireBoardCert = requireBoardCert || FormState.getElementValue("requireBoardCert");
            var field = document.getElementById("allowanceBoardCertification");

            if ("No" === requireBoardCert) {
                field.value = "$0.00";
            } else {
                field.value = "$3,000.00";
            }

            FormState.updateDijitInputInner("allowanceBoardCertification", field.value);
            handleAllowanceTotal({allowanceBoardCertification: field.value});
        }

        function setAllowanceMultiYearAgreementValue(opt) {
            opt = opt || {};
            var lengthOfService = FormUtility.parseInt(undefined !== opt.lengthOfService ? opt.lengthOfService : FormState.getElementValue("lengthOfService"), 0);
            var field = document.getElementById("allowanceMultiYearAgreement");

            if (1 === lengthOfService) {
                field.value = "$0.00";
            } else if (2 === lengthOfService) {
                field.value = "$4,000.00";
            } else if (3 === lengthOfService) {
                field.value = "$5,000.00";
            } else if (4 === lengthOfService) {
                field.value = "$6,000.00";
            }

            FormState.updateDijitInputInner("allowanceMultiYearAgreement", field.value);
            handleAllowanceTotal({allowanceMultiYearAgreement: field.value});
        }

        function setAllowanceMissionSpecificCriteriaValue(opt) {
            opt = opt || {};
            var lengthOfService = FormUtility.parseInt(undefined !== opt.lengthOfService ? opt.lengthOfService : FormState.getElementValue("lengthOfService"), 0);
            var payPlan = opt.payPlan || FormState.getElementValue("payPlan");
            var grade = FormUtility.parseInt(undefined !== opt.grade ? opt.grade : FormState.getElementValue("grade"), -1);

            var field = document.getElementById("allowanceMissionSpecificCriteria");

            hyf.util.disableComponent("allowanceMissionSpecificCriteria");

            if (1 === lengthOfService) {
                field.value = "$0.00";
            } else if (lengthOfService > 1) {
                var max = 0;
                if ("GS" === payPlan) {
                    if (13 === grade) {
                        max = 5000;
                    } else if (14 === grade) {
                        max = 8000;
                    } else if (15 === grade) {
                        max = 10000;
                    } else {
                        max = 0;
                    }
                } else if ("ES" === payPlan) {
                    max = 10000;
                }

                if (max === 0) {
                    field.value = "$0.00";
                } else if (max > 0) {
                    field.value = "$0.00";
                    hyf.util.enableComponent("allowanceMissionSpecificCriteria");
                    field.setAttribute("data-wm-error-msg", "The allowance must be less than or equal to $" + max.format(0));
                    hyf.util.setInclusiveRangeConstraint(field, 0, max);
                }
            }

            FormState.updateDijitInputInner("allowanceMissionSpecificCriteria", field.value);
            handleAllowanceTotal({allowanceMissionSpecificCriteria: FormUtility.moneyToNumber(field.value, 0)});
        }

        function handleBoardCertSpecialty(requireBoardCert) {
            requireBoardCert = undefined !== requireBoardCert ? requireBoardCert : FormState.getElementValue("requireBoardCert");
            hyf.util.setMandatoryConstraint("boardCertSpecialty", "Yes" == requireBoardCert);
        }

        function handleOtherSpeciality(otherSpeciality) {
            otherSpeciality = undefined !== otherSpeciality ? otherSpeciality : FormState.getElementValue("boardCertSpecialty9");
            if ("true" === otherSpeciality || true === otherSpeciality) {
                hyf.util.showComponent("otherSpeciality_group");
            } else {
                var field = document.getElementById("otherSpeciality");
                field.value = "";
                hyf.util.hideComponent("otherSpeciality_group");
            }
        }

        function calculateAllowanceTotal(opt) {
            opt = opt || {};
            var allowanceCategory = FormUtility.moneyToNumber(undefined !== opt.allowanceCategory ? opt.allowanceCategory : FormState.getElementValue("allowanceCategory"), 0);
            var allowanceBoardCertification = FormUtility.moneyToNumber(undefined !== opt.allowanceBoardCertification ? opt.allowanceBoardCertification : FormState.getElementValue("allowanceBoardCertification"), 0);
            var allowanceMultiYearAgreement = FormUtility.moneyToNumber(undefined !== opt.allowanceMultiYearAgreement ? opt.allowanceMultiYearAgreement : FormState.getElementValue("allowanceMultiYearAgreement"), 0);
            var allowanceMissionSpecificCriteria = FormUtility.moneyToNumber(undefined !== opt.allowanceMissionSpecificCriteria ? opt.allowanceMissionSpecificCriteria : FormState.getElementValue("allowanceMissionSpecificCriteria"), 0);

            return allowanceCategory + allowanceBoardCertification + allowanceMultiYearAgreement + allowanceMissionSpecificCriteria;
        }

        function handleTotalPayablePCACalculation(totalPayablePCACalculationAmount, showExceedTotalPayableAmountMsg) {
            var totalPayablePCACalculation = document.getElementById("totalPayablePCACalculation");
            totalPayablePCACalculation.value = "$" + totalPayablePCACalculationAmount.format();

            var exceedTotalPayableAmountMsg = document.getElementById("exceedTotalPayableAmountMsg");
            exceedTotalPayableAmountMsg.style.display = showExceedTotalPayableAmountMsg ? "" : "none";
        }

        function visibilityAllowanceTotal(total) {
            total = undefined !== total ? total : FormUtility.moneyToNumber(FormState.getElementValue("allowanceTotal"));

            var totalPayablePCACalculation = 0;
            var showAllowanceTotal = false;
            var lengthOfServed = FormState.getElementValue("lengthOfServed");
            if (lengthOfServed === "0 to 24 Months") {
                if (total > 14000) {
                    showAllowanceTotal = true;
                    totalPayablePCACalculation = 14000;
                }
                else {
                    totalPayablePCACalculation = total;
                }
            } else if (lengthOfServed === "More than 24 Months") {
                if (total > 30000) {
                    showAllowanceTotal = true;
                    totalPayablePCACalculation = 30000;
                }
                else {
                    totalPayablePCACalculation = total;
                }
            }

            if (showAllowanceTotal) {
                hyf.util.showComponent("allowanceTotal_group");
            } else {
                hyf.util.hideComponent("allowanceTotal_group");
            }

            handleTotalPayablePCACalculation(totalPayablePCACalculation, showAllowanceTotal);
        }

        function handleAllowanceTotal(opt) {
            var total = calculateAllowanceTotal(opt);
            var field = document.getElementById("allowanceTotal");
            field.value = "$" + total.format();
            FormState.updateDijitInputInner("allowanceTotal", field.value);

            visibilityAllowanceTotal(total);
        }

        function onGradeChanged(grade) {
            setAllowanceCategoryValueRange({grade: grade});
            setAllowanceMissionSpecificCriteriaValue({grade: grade});
        }

        function onPayPlanChanged(payPlan) {
            setAllowanceCategoryValueRange({payPlan: payPlan});
            setAllowanceMissionSpecificCriteriaValue({payPlan: payPlan});
        }

        function onRequireBoardCertChanged(requireBoardCert) {
            setAllowanceBoardCertificationValue(requireBoardCert);
            handleBoardCertSpecialty(requireBoardCert);
        }

        function initElements() {
            $('#lengthOfServed').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                setAllowanceCategoryValueRange({lengthOfServed: value});
            });

            $('#lengthOfService').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                setAllowanceMultiYearAgreementValue({lengthOfService: value});
                setAllowanceMissionSpecificCriteriaValue({lengthOfService: value});
            });

            $('#boardCertSpecialty9').on('change', function (e) {
                var target = e.target;
                var checked = target.checked;
                handleOtherSpeciality(checked);
            });

            $('#allowanceCategory').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                handleAllowanceTotal({allowanceCategory: value});
            });

            $('#allowanceBoardCertification').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                handleAllowanceTotal({allowanceBoardCertification: value});
            });

            $('#allowanceMultiYearAgreement').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                handleAllowanceTotal({allowanceMultiYearAgreement: value});
            });

            $('#allowanceMissionSpecificCriteria').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                handleAllowanceTotal({allowanceMissionSpecificCriteria: value});
            });
        }

        function init() {
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_pca_details::init...");

            handleOtherSpeciality();
            handleBoardCertSpecialty();
            visibilityAllowanceTotal();

            setAllowanceCategoryValueRange();

            initElements();

            _initialized = true;
        }

        function render() {
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_pca_details::render...");
        }

        return {
            init: init,
            render: render,
            onGradeChanged: onGradeChanged,
            onPayPlanChanged: onPayPlanChanged,
            onRequireBoardCertChanged: onRequireBoardCertChanged
        }
    };

    var _initializer = window.cms_incentives_pca_details || (window.cms_incentives_pca_details = cms_incentives_pca_details());
})(window);
