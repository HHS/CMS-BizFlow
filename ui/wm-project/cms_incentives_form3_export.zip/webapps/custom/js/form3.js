(function (window) {
    var cms_incentives_pca_coversheet = function () {
        var _initialized = false;

        function init() {
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_pca_coversheet::init...");


            _initialized = true;
        }

        function render() {
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_pca_coversheet::render...");
        }

        return {
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_pca_coversheet || (window.cms_incentives_pca_coversheet = cms_incentives_pca_coversheet());
})(window);
