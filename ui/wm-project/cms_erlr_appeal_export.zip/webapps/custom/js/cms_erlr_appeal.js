var Appeal = {
    initialized: false,
	init: function () {
        hyf.util.hideComponent('Exception_info_group');
        hyf.util.hideComponent('Arbitration_group_Grievance');        
        hyf.util.hideComponent('Exception_info_group_2');
        hyf.util.hideComponent('discovery_due_group');  
        hyf.util.hideComponent('petition_review_date_group'); 
        $('#AP_ERLR_APPEAL_TYPE').on('change',appealTypeEvent);
		$('#Appeal_group select,#Appeal_group input[type="text"]').on('change',updateEvent);
    },
	reqFieldForActivity : 
		[
			{
				actName: globalVars.actAll,
				reqFieldIds: 
				[
				
				]
			},
			{
				actName: globalVars.actCaseCreation,
				reqFieldIds: 
				[
					'PI_WRTN_NRTV_RVW_TYPE'
				]
			},
			{
				actName: globalVars.actCaseComplete,
				reqFieldIds: 
				[
				]
			}
		],
    render: function () {
		/*
        var appealType = FormState.getState('erlr_appeal_type');
        var exceptionFiled = FormState.getState('erlr_exception_filed');
        var isArbitrationInvoked = FormState.getState('erlr_arbitration_invoked');
        var exceptionFiled2 = FormState.getState('erlr_exception_filed_2');
        var wasDiscoveryInitiated = FormState.getState('erlr_was_discovery_initiated');
        var wasPetitionReviewFiled = FormState.getState('erlr_was_petition_filed_MSPB');
        var prehearingDate = FormState.getState('erlr_prehearing_date');
        var hearingDate = FormState.getState('erlr_hearing_date');
        var prehearingDateMSPB = FormState.getState('erlr_prehearing_date_MSPB');
        var hearingDateMSPB = FormState.getState('erlr_hearing_date_MSPB');
        var prehearingDateSC = FormState.getState('erlr_prehearing_date_SC');
        var hearingDateSC = FormState.getState('erlr_hearing_date_SC');
        
       
        
        if(!Appeal.initialized){		
            hyf.calendar.setDateConstraint('erlr_appeal_filed_date', 'Maximum', 'Today');

            // Arbitration
            hyf.calendar.setDateConstraint('erlr_prehearing_date', 'Maximum', 'Today'); 
            hyf.calendar.setDateConstraint('erlr_hearing_date', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_posthearing_brief_due', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_final_arbitrator_decision_date', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_exception_file_date', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_response_to_exceptions_due', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_final_FLRA_decision_date', 'Maximum', 'Today');

            // Special Counsel
            hyf.calendar.setDateConstraint('erlr_prehearing_date_SC', 'Maximum', 'Today'); 
            hyf.calendar.setDateConstraint('erlr_hearing_date_SC', 'Maximum', 'Today');

            // Grievance
            hyf.calendar.setDateConstraint('erlr_date_step_decision', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_prehearing_date_2', 'Maximum', 'Today'); 
            hyf.calendar.setDateConstraint('erlr_hearing_date_2', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_posthearing_brief_due_2', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_final_arbitrator_decision_date_2', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_exception_file_date_2', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_response_to_exceptions_due_2', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_final_FLRA_decision_date_2', 'Maximum', 'Today');

            // MSPB
            hyf.calendar.setDateConstraint('erlr_date_settlement_discussion', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_date_agency_file_response_due', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_prehearing_date_MSPB', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_date_discovery_due', 'Maximum', 'Today');             
            hyf.calendar.setDateConstraint('erlr_hearing_date_MSPB', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_initial_decision_date_MSPB', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_petition_filed_date_MSPB', 'Maximum', 'Today');
            hyf.calendar.setDateConstraint('erlr_final_board_decision_date_MSPB', 'Maximum', 'Today');
            
            Appeal.initialized = true;
	   }
	   */
    },
    dateValidate : function(e, msg, targetId){
        var days = 0
        var dt1 = '';
        var dt2 = ''
        if(e.value1 !=undefined || e.value2 !=undefined){
            dt1 = e.value1;
            dt2 = e.value2;
        }
        if((dt2 && dt2 !== '') ||(dt1 && dt1 !== '')){
            var m1 = moment(dt1);
            var m2 = moment(dt2);
            days = m2.diff(m1,'days');
            if(days < 0 ){
                bootbox.alert({
                message: msg,
                callback: function(){ 
                    FormState.doAction(StateAction.changeDate(targetId, ''), false);
                    $('#' +targetId).val('');
                    }
                });
            }
        }
    }/*,
    clearFields : function(targetFields){
        targetFields.forEach(fucntion(el){
			if(
			FormState.doAction(StateAction.changeText(el, ''), false);
        	FormState.doAction(StateAction.changeSelect('SME_INTERNAL_2', 'default'), false);
    		});	
        	
    }  */  
}
function appealTypeEvent(e){
	var appealType = '';//e.target.options[e.target.options.selectedIndex].value;
	if(e === 'undefined'){
		return;
	}else if(typeof e ==='object'){
		if(e.target !=='undefined'){
			appealType = e.target.options[e.target.options.selectedIndex].value;
		}
	}
	if(appealType && appealType !=='undefined'){
            if(appealType === 'Arbitration'){								
                hyf.util.showComponent('Arbitration_group');
                hyf.util.hideComponent('Special_Counsel_group');
                hyf.util.hideComponent('Grievance_group');
                hyf.util.hideComponent('MSPB_group');
            }
            else if(appealType === 'Special Counsel'){
                hyf.util.hideComponent('Arbitration_group');                
				hyf.util.showComponent('Special_Counsel_group');
                hyf.util.hideComponent('Grievance_group');
                hyf.util.hideComponent('MSPB_group');
            }
            else if(appealType === 'Grievance'){                
                hyf.util.hideComponent('Arbitration_group');
                hyf.util.hideComponent('Special_Counsel_group');
				hyf.util.showComponent('Grievance_group');
                hyf.util.hideComponent('MSPB_group');
            }
            else if(appealType === 'MSPB'){                
                hyf.util.hideComponent('Arbitration_group');
                hyf.util.hideComponent('Special_Counsel_group');
                hyf.util.hideComponent('Grievance_group');
				hyf.util.showComponent('MSPB_group');
            }
            else{                
                hyf.util.hideComponent('Arbitration_group');
                hyf.util.hideComponent('Special_Counsel_group');
                hyf.util.hideComponent('Grievance_group');
                hyf.util.hideComponent('MSPB_group');
            }
        }        
}
function updateEvent(e){
	var eventSource = '';
	var val = '';//e.target.options[e.target.options.selectedIndex].value;
	if(e === 'undefined'){
		return;
	}else if(typeof e ==='object'){
		if(e.target !=='undefined'){
			val = e.target.options[e.target.options.selectedIndex].value;
			eventSource = e.target.id;
		}
	}
	 if(eventSource && eventSource === 'AP_ERLR_EXCEPTION_FILED'){
            if(val === 'Yes'){
        	    hyf.util.showComponent('Exception_info_group');            	
            }
            else{
				hyf.util.hideComponent('Exception_info_group');            	
            }
        }
        
        if(eventSource && eventSource ==='AP_ERLR_EXCEPTION_FILED_2'){
            if(val === 'Yes'){
        	    hyf.util.showComponent('Exception_info_group_2');            	
            }
            else{
				hyf.util.hideComponent('Exception_info_group_2');            	
            }
        }
        
        if(eventSource && eventSource === 'AP_ERLR_ARBITRATION_INVOKED'){
            if(val === 'Yes'){
        	    hyf.util.showComponent('Arbitration_group_Grievance');            	
            }
            else{
				hyf.util.hideComponent('Arbitration_group_Grievance');            	
            }
        }
        
        if(eventSource && eventSource === 'AP_ERLR_WAS_DISCOVERY_INITIATED'){
            if(val === 'Yes'){
        	    hyf.util.showComponent('discovery_due_group');            	
            }
            else{
				hyf.util.hideComponent('discovery_due_group');            	
            }
        }
        if(eventSource && eventSource ==='AP_ERLR_WAS_PETITION_FILED_MSPB'){
            if(val === 'Yes'){
        	    hyf.util.showComponent('petition_review_date_group');            	
            }
            else{
				hyf.util.hideComponent('petition_review_date_group');            	
            }
        }      
}
function appealDateEvents(e){
	var eventSource = e.target.id;
	var val = $('#' +eventSource).val();
	 if(eventSource && eventSource ==='AP_ERLR_PREHEARING_DT'){
			 var hearingDate = FormState.getElementValue('AP_ERLR_HEARING_DT');
			Appeal.dateValidate({value1: val, value2: hearingDate}, 'Date of Hearing must be after the Date of Prehearing Conference.','AP_ERLR_PREHEARING_DT');
		}
        
        if(eventSource && eventSource === 'AP_ERLR_HEARING_DT'){
			var phearingDt = FormState.getElementValue('AP_ERLR_PREHEARING_DT');
            Appeal.dateValidate({value1: phearingDt, value2: val}, 'Date of Hearing must be after the Date of Prehearing Conference.','AP_ERLR_HEARING_DT');
        }
        
        if(eventSource && eventSource === 'AP_ERLR_PREHEARING_DT_MSPB'){//prehearingDateMSPB,hearingDateMSPB
			var hearing = FormState.getElementValue('AP_ERLR_HEARING_DT_MSPB');
			Appeal.dateValidate({value1: val, value2: hearing}, 'Date of Hearing must be after the Date of Prehearing Conference.','AP_ERLR_PREHEARING_DT_MSPB');
		}
        /*
        if(hearingDateMSPB && hearingDateMSPB.dirty && prehearingDateMSPB){
            Appeal.dateValidate({value1: prehearingDateMSPB.value, value2: hearingDateMSPB.value}, 'Date of Hearing must be after the Date of Prehearing Conference.','erlr_hearing_date_MSPB');
        }
        
        if(prehearingDateSC && prehearingDateSC.dirty && hearingDateSC){
			Appeal.dateValidate({value1: prehearingDateSC.value, value2: hearingDateSC.value}, 'Date of Hearing must be after the Date of Prehearing Conference.','erlr_prehearing_date_SC');
		}
        
        if(hearingDateSC && hearingDateSC.dirty && prehearingDateSC){
            Appeal.dateValidate({value1: prehearingDateSC.value, value2: hearingDateSC.value}, 'Date of Hearing must be after the Date of Prehearing Conference.','erlr_hearing_date_SC');
        }*/
}


