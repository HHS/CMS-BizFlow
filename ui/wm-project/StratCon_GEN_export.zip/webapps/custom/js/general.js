var stratConGEN = {
    separator: ',',
    longSeparator: '_/~',
    getUserObjectForAC: function(userID) {
        var userObject = [];
        var userFromSource = $('#group_user_info option[value="' +  userID + '"]');
        if (userFromSource && userFromSource.length > 0) {
            var userText = userFromSource.text();
            if (userText && userText.length > 0) {
                var userInfo = userText.split(stratConGEN.longSeparator);
                // userInfo[0] - memberid // userInfo[1] - name // userInfo[2] - email // userInfo[3] - deptname // userInfo[4] - jobtitlename
                userObject.push({
                    id: userID,
                    name: userInfo[1],
                    deptname: userInfo[3],
                    jobtitle: userInfo[4]       
                });
            }
        }
        return userObject;
    },
    getXOObjectForAC: function() {
        var userObject = [];

        var IDString = $('#SG_XO_ID').val();
        var IDs = IDString.split(stratConGEN.separator);
        var count = IDs.length;

        for (var i = 0; i < count; i++) {
            var userInfo = stratConGEN.getUserObjectForAC(IDs[i]);
            if (userInfo.length == 1) {
                userObject.push(userInfo[0]);
            }
        }
        return userObject;
    },
    specialProgramAC: null,
    initAutoCompletion: function() {
        var adminCodeOption = {
            id: 'SG_ADMIN_CD_INPUT',
            minLength: 2,
            targetURL: 'SearchAdmOffOrg.do',
            targetParam: 'searchAdminCode',
            mapFunction: function(context) {
                return { code: $( "CODE", context ).text(), name: $( "NAME", context ).text() }
            },
            getSelectionLabel: function(item) {
                return item.code;
            },
            getCandidateLabel: function(item) {
                return item.code + ' - ' + item.name;
            },
            getItemID: function(item) {
                return item.code;
            },
            setDataToForm: function(values) {
                var code = "";
                if (values && values.length > 0) {
                    code = values[0].code;
                }
                $('#SG_ADMIN_CD').val(code);
            },
            initialItems: [{
                code: $('#AC_ADMIN_CD').val(),
                name:$('#AC_ADMIN_CD_DESCR').val()
            }]
        }    
        var adminCodeAC = initAutoCompletion(adminCodeOption);

        var orgOption = {
            id: 'SG_ORG_NAME',
            minLength: 2,
            targetURL: 'SearchAdmOffOrg.do',
            targetParam: 'searchOrgName',
            mapFunction: function(context) {
                return { code: $( "CODE", context ).text(), name: $( "NAME", context ).text() }
            },
            getSelectionLabel: function(item) {
                return item.name;
            },
            getCandidateLabel: function(item) {
                return item.name + ' - ' + item.code;
            },
            getItemID: function(item) {
                return item.code;
            },
            postSelect: function(event, ui, selectedValues) {
                adminCodeAC.select(event, ui);
            },
            postDelete: function(e, selectedValues) {
                adminCodeAC.deleteItem(e);
            },
            setDataToForm: function(values) {
                var code = "";
                if (values && values.length > 0) {
                    code = values[0].code;
                }
                $('#SG_ADMIN_CD').val(code);
            },
            initialItems: [{
                code: $('#AC_ADMIN_CD').val(),
                name:$('#AC_ADMIN_CD_DESCR').val()
            }]
        }
        var orgNameAC = initAutoCompletion(orgOption);
        adminCodeAC.option.postSelect = function(event, ui, selectedValues) {
            orgNameAC.select(event, ui);
        }
        adminCodeAC.option.postDelete = function(e, selectedValues) {
            orgNameAC.deleteItem(e);
        }

        var certInitialData = [];
        if ($('#OTHER_CERT_DATA option').length != 0) {
            $('#OTHER_CERT_DATA option').each(function(){
                var id = $(this).val();
                var otherCertData = $(this).text(); // Peter Lee_/~peter@bizflow.com
                var items = otherCertData.split(stratConGEN.longSeparator)
                certInitialData.push({id: id, name: items[0], email: items[1]})
            });
        }

        var certOption = {
            id: 'certSearch',
            targetURL: 'SearchPeopleNameEmail.do',
            targetParam: 'searchString',
            minLength: 2,
            minSelectionCount: 0,
            maxSelectionCount: 13,
            mapFunction: function(context) {
                return {
                    name: $( "DSPNAME", context ).text(),
                    id: $( "MID", context ).text(),
                    email: $( "EMAIL", context ).text()
                };            
            },
            getSelectionLabel: function(item) {
                return item.name + (item.email != null && item.email.length > 0 ? ' (' + item.email + ')' : '')
            },
            getCandidateLabel: function(item) {
                return item.name + (item.email != null && item.email.length > 0 ? ' (' + item.email + ')' : '')
            },
            getItemID: function(item) {
                return item.id;
            },
            setDataToForm: function(values) {
                var IDs = "";
                if (values) {
                    var count = values.length;
                    for (var index = 0; index < count; index++) {
                        if (index != 0) {
                            IDs += ',';
                        }
                        IDs += values[index].id;
                    }
                }
                $('#SG_OTHER_CERT').val(IDs);
            },
            initialItems: certInitialData
        }
        var certAC = initAutoCompletion(certOption);

        // SO Auto Completion
        var soID = $('#SG_SO_ID').val();
        var soInitialData = stratConGEN.getUserObjectForAC(soID)
        var soOption = {
            id: 'soSearch',
            targetURL: 'SearchPeopleUGNameTitle.do',
            targetParam: 'userGroupName=Selecting Officials&searchString',
            searchMode: 'include',
            minLength: 2,
            minSelectionCount: 1,
            maxSelectionCount: 1,
            mapFunction: function(context) {
                return {
                    id: $( "MEMBERID", context ).text(),
                    name: $( "NAME", context ).text(),
                    deptname: $( "DEPTNAME", context ).text(),
                    jobtitle: $( "JOBTITLENAME", context ).text()
                };            
            },
            getSelectionLabel: function(item) {
                var selectionLabel = '';
                selectionLabel = item.name;
                if ((item.deptname && item.deptname.length > 0) || (item.jobtitle && item.jobtitle.length > 0)) {
                    selectionLabel += (' (' + item.deptname);
                    if (item.jobtitle && item.jobtitle.length > 0) {
                        selectionLabel += ('/' + item.jobtitle)
                    }
                    selectionLabel += ')'
                }
                return selectionLabel;
            },
            getCandidateLabel: function(item) {
                var selectionLabel = '';
                selectionLabel = item.name;
                if ((item.deptname && item.deptname.length > 0) || (item.jobtitle && item.jobtitle.length > 0)) {
                    selectionLabel += (' (' + item.deptname);
                    if (item.jobtitle && item.jobtitle.length > 0) {
                        selectionLabel += ('/' + item.jobtitle)
                    }
                    selectionLabel += ')'
                }
                return selectionLabel;
            },
            getItemID: function(item) {
                return item.id;
            },
            setDataToForm: function(values) {
                if (values && values.length == 1) {
                    $('#SG_SO_ID').val(values[0].id);
                    $('#SG_SO_TITLE').val(values[0].jobtitle);
                    $('#SG_SO_ORG').val(values[0].deptname);
                }
            },
            initialItems: soInitialData
        }
        var soAC = initAutoCompletion(soOption);

        // XO Auto Completion
        var xoOption = Object.create(soOption);
        xoOption.id = 'xoSearch';
        xoOption.minSelectionCount = 1;
        xoOption.maxSelectionCount = 3;
        xoOption.targetParam = 'userGroupName=Executive Officers&searchString';
        xoOption.setDataToForm = function(values) {
            var count = values.length;
            var IDs = '';
            var titles = '';
            var orgs = '';

            for (var i = 0; i < count; i++) {
                if (i != 0) {
                    IDs = IDs + stratConGEN.separator;
                    titles = titles + stratConGEN.longSeparator;
                    orgs = orgs + stratConGEN.longSeparator;
                }
                IDs = IDs + values[i].id;
                titles = titles + values[i].jobtitle;
                orgs = orgs + values[i].deptname;
            }

            $('#SG_XO_ID').val(IDs);
            $('#SG_XO_TITLE').val(titles);
            $('#SG_XO_ORG').val(orgs);
        },
        xoOption.initialItems = stratConGEN.getXOObjectForAC();
        var xoAC = initAutoCompletion(xoOption);

        // HR Liaison Auto Completion
        var hrID = $('#SG_HRL_ID').val();
        var hrInitialData = [];
        if (hrID == '0000000000') {
            hrInitialData.push({
                id: '0000000000',
                name: 'N/A',
                deptname: '',
                jobtitle: ''
            });
        } else {
            hrInitialData = stratConGEN.getUserObjectForAC(hrID)
        }
        
        var hrOption = Object.create(soOption);
        hrOption.id = 'hrSearch';
        hrOption.minSelectionCount = 0;
        hrOption.targetParam = 'userGroupName=HR Liaison&searchString';
        hrOption.setDataToForm = function(values) {
            if (values && values.length == 1) {
                $('#SG_HRL_ID').val(values[0].id);
                $('#SG_HRL_TITLE').val(values[0].jobtitle);
                $('#SG_HRL_ORG').val(values[0].deptname);
            }
        },
        hrOption.initialItems = hrInitialData;
        hrOption.addCandidateItems = function(candidates) {
            candidates.push({
                id: '0000000000',
                name: 'N/A',
                deptname: '',
                jobtitle: ''
            });
        }
        var hrAC = initAutoCompletion(hrOption);

        // Staff Specialist Auto Completion
        var ssID = $('#SG_SS_ID').val();
        var ssInitialData = stratConGEN.getUserObjectForAC(ssID)
        var ssOption = Object.create(soOption);
        ssOption.id = 'ssSearch';
        ssOption.targetParam = 'userGroupName=HR Staffing Specialists&searchString';
        ssOption.setDataToForm = function(values) {
            if (values && values.length == 1) {
                $('#SG_SS_ID').val(values[0].id)
            }
        },
        ssOption.initialItems = ssInitialData;
        var ssAC = initAutoCompletion(ssOption);

        // Special Program Specialist Auto Completion
        var spID = $('#SG_SP_ID').val();
        var spInitialData = stratConGEN.getUserObjectForAC(spID)
        var spOption = Object.create(soOption);
        spOption.id = 'spSearch';
        spOption.targetParam = 'userGroupName=HR Special Programs&searchString';
        spOption.setDataToForm = function(values) {
            if (values && values.length == 1) {
                $('#SG_SP_ID').val(values[0].id)
            }
        },
        spOption.initialItems = spInitialData;
        var spAC = initAutoCompletion(spOption);

        // Classification Specialist Auto Completion
        var csID = $('#SG_CS_ID').val();
        var csInitialData = stratConGEN.getUserObjectForAC(csID)
        var csOption = Object.create(soOption);
        csOption.id = 'csSearch';
        csOption.targetParam = 'userGroupName=HR Classification Specialists&searchString';
        csOption.setDataToForm = function(values) {
            if (values && values.length == 1) {
                $('#SG_CS_ID').val(values[0].id)
            }
        },
        csOption.initialItems = csInitialData;
        var csAC = initAutoCompletion(csOption);
    },
    showHideAppointmentType: function() {
        var requestType = $('#SG_RT_ID :selected').text();
        if (requestType == 'Appointment') { // SHOW
            hyf.util.showComponent('layout_group_AT', null, null, null);
            stratConGEN.changeAppointmentType();
        } else { // HIDE
            $('#SG_AT_ID').val('');
            $('#SG_SAT_ID').val('');
            hyf.util.hideComponent('layout_group_AT', null, null, null);
        }
    },
    showHideClassificationType: function() {
        var requestType = $('#SG_RT_ID :selected').text();
        var appointmentType = $('#SG_AT_ID :selected').text();
    
        if (requestType != 'Appointment'
            || (appointmentType != 'Volunteer'
                && appointmentType != 'Intergovernmental Personnel Act (IPA)')
                && appointmentType != 'Expert/Consultant') {
            hyf.util.showComponent('layout_group_CT', null, null, null);
            hyf.util.showComponent('layout_group_classSpecialist', null, null, null);
        } else {
            $('#SG_CT_ID').val('');
            $('#SG_CS_ID').val('');
            hyf.util.hideComponent('layout_group_CT', null, null, null);
            hyf.util.hideComponent('layout_group_classSpecialist', null, null, null);
        }
    },
    showHideStaffSpecialistGroup: function() {
        var isSpecial = StratConMAIN.isSpecialProgram();
        if (isSpecial == true) {
            var targetActivities = ['Hold Strategic Consultation Meeting', 'Acknowledge Strat Cons Meeting', 'Approve Strat Cons Meeting'];
            var activityName = BFActivityOption.getActivityName();
            var foundActivity = CMSUtility.existInArray(targetActivities, activityName);
    
            hyf.util.disableComponent('SG_SS_ID');
            $('#SG_SS_ID').attr('donotsubmit', 'true');
    
            hyf.util.enableComponent('SG_SP_ID');
            $('#SG_SP_ID').removeAttr('donotsubmit');
    
            hyf.util.hideComponent('layout_group_staffspecialist');
            if (foundActivity == true) {
                var version = CMSUtility.getProcessVersion();
                if (version >= 2) {
                    var classificationType = $('#SG_CT_ID :selected').text();
                    if (classificationType == 'Review Existing Position Description') {
                        hyf.util.hideComponent('layout_group_specialProgram');
                    } else {
                        hyf.util.showComponent('layout_group_specialProgram');    
                    }
                } else {
                    hyf.util.showComponent('layout_group_specialProgram');
                }
            } else {
                var specialUserGroupMemberID = StratConMAIN.getUserGroupMemberID('HR Special Programs');
    
                var alreadyAddedSpecialPrograms = false;
                $.each($('#SG_SP_ID option'), function(index, component) {
                    var value = $(this).attr('value');
                    if (value == specialUserGroupMemberID) {
                        alreadyAddedSpecialPrograms = true;
                    }
                });
    
                if (alreadyAddedSpecialPrograms == false) {
                    $('#SG_SP_ID').append('<option value="' + specialUserGroupMemberID + '">HR Special Programs</option>');
                }
                $('#SG_SP_ID').val(specialUserGroupMemberID);
                hyf.util.hideComponent('layout_group_specialProgram');
            }
            $('#pv_specialProgram').val('Yes');
        } else {
            hyf.util.disableComponent('SG_SP_ID');
            $('#SG_SP_ID').attr('donotsubmit', 'true');
    
            hyf.util.enableComponent('SG_SS_ID');
            $('#SG_SS_ID').removeAttr('donotsubmit');
    
            var requestType = $('#SG_RT_ID :selected').text();
            if (requestType == 'Classification Only') {
                $('#SG_SS_ID').val('');
                hyf.util.hideComponent('layout_group_staffspecialist', null, null, null);
            } else if (requestType == 'Recruitment') {
                hyf.util.showComponent('layout_group_staffspecialist', null, null, null);
            } else if (requestType == 'Appointment') {
                var appointmentType = $('#SG_AT_ID :selected').text(); // HRB-1654
                if (appointmentType == 'Intergovernmental Personnel Act (IPA)') {
                    $('#SG_SS_ID').val('');
                    hyf.util.hideComponent('layout_group_staffspecialist', null, null, null);
                } else {
                    hyf.util.showComponent('layout_group_staffspecialist', null, null, null);
                }
            } else {
                hyf.util.showComponent('layout_group_staffspecialist', null, null, null);
            }
            hyf.util.hideComponent('layout_group_specialProgram', null, null, null);
            $('#pv_specialProgram').val('No');
        }
    
        $(document).trigger('SG_SPECIAL_PROGRAM_CHANGED');
    },

    changeAppointmentType: function() {
        CMSUtility.debugLog('stratConGEN.changeAppointmentType START');
        var requestType = $('#SG_RT_ID :selected').text();
        var appointmentType = $('#SG_AT_ID :selected').text();

        if (requestType == 'Appointment' && appointmentType == 'Schedule A') {
            $('#SG_VT_ID').val('');
            hyf.util.showComponent('layout_group_SAT', null, null, null);
            hyf.util.hideComponent('layout_group_VOL', null, null, null);
        } else if (requestType == 'Appointment' && appointmentType == 'Volunteer') {
            $('#SG_SAT_ID').val('');
            hyf.util.hideComponent('layout_group_SAT', null, null, null);
            hyf.util.showComponent('layout_group_VOL', null, null, null);
        } else {
            $('#SG_VT_ID').val('');
            $('#SG_SAT_ID').val('');
            hyf.util.hideComponent('layout_group_SAT', null, null, null);
            hyf.util.hideComponent('layout_group_VOL', null, null, null);
        }

        stratConGEN.showHideClassificationType();
        stratConGEN.showHideStaffSpecialistGroup();
        StratConMAIN.showHideTabsUponRequestType();

        // Notify document tab so that it can retrieve new document types and mandatory documents.
        $(document).trigger('ON_DOCUMENT_CHANGE');

        CMSUtility.debugLog('stratConGEN.changeAppointmentType END');
    },
    changeRequestType: function(e) {
        CMSUtility.debugLog('stratConGEN.changeRequestType START');
        var preselect = $('#SG_CT_ID').val();
        $('#SG_CT_ID').empty();

        var requestTypeValue = $('#SG_RT_ID').val();
        var requestType = $('#SG_RT_ID :selected').text();

        var requestLookup = LookupManager.findByLTYPE('RequestType[' + requestType + ']');
        if (requestLookup.length == 1) {
            var types = requestLookup[0].children;
            var count = types.length;

            for (var index = 0; index < count; index++) {
                $('#SG_CT_ID').append('<option value="' + types[index].ID + '">' + types[index].NAME + '</option');
            }
        }
 
        if (preselect !== undefined) {
            $('#SG_CT_ID').val(preselect);
        }
        hyf.util.hideComponent('layout_group_so_agree', null, null, null);

        if (requestType != null && requestType.length > 0) {
            requestType = requestType.toLowerCase();
        }

        if (requestType != 'recruitment') {
            hyf.util.hideComponent('COMMISSIONED_NOTE', null, null, null);
            $('#OTHER_CERT_DIV').addClass('hidden');
            $('#certSearch_display').empty();
            $('#SG_OTHER_CERT').val('');
        } else {
            $('#OTHER_CERT_DIV').removeClass('hidden');

            var isSelectingOfficial = StratConMAIN.isCurrentUserMemberOf('Selecting Officials');
            if (isSelectingOfficial == true) {
                hyf.util.showComponent('layout_group_so_agree', null, null, null);
            }
            hyf.util.showComponent('COMMISSIONED_NOTE', null, null, null);
        }
        stratConGEN.showHideClassificationType();
        stratConGEN.showHideAppointmentType();
        stratConGEN.showHideStaffSpecialistGroup();
        // Notify document tab so that it can retrieve new document types and mandatory documents.
        $(document).trigger('ON_DOCUMENT_CHANGE');
        StratConMAIN.showHideTabsUponRequestType(); // Function from StratConMain.js

        CMSUtility.debugLog('stratConGEN.changeRequestType END');
    },
    changeClassificationType: function() {
        CMSUtility.debugLog('stratConGEN.changeClassificationType START');
        // Notify document tab so that it can retrieve new document types and mandatory documents.
        $(document).trigger('ON_DOCUMENT_CHANGE');
        StratConMAIN.showHideTabsUponRequestType();
        CMSUtility.debugLog('stratConGEN.changeClassificationType END');
    },
    changeVolunteerType: function() {
        CMSUtility.debugLog('stratConGEN.changeVolunteerType START');
        // Notify document tab so that it can retrieve new document types and mandatory documents.
        $(document).trigger('ON_DOCUMENT_CHANGE');
        CMSUtility.debugLog('stratConGEN.changeVolunteerType END');
    },

    init: function() {
        CMSUtility.debugLog('STRATCON_GEN - stratConGEN.init START');

        $('#SG_AT_ID').on('change', stratConGEN.changeAppointmentType);
        $('#SG_CT_ID').on('change', stratConGEN.changeClassificationType);
        $('#SG_RT_ID').on('change', stratConGEN.changeRequestType);
        $('#SG_VT_ID').on('change', stratConGEN.changeVolunteerType);

        // Initialization
        stratConGEN.changeRequestType();
        stratConGEN.changeAppointmentType();
        stratConGEN.initAutoCompletion();

        CMSUtility.debugLog('STRATCON_GEN - stratConGEN.init END');
    }
}
