(function (window) {
    var cms_incentives_le_details = function () {
        var _readOnly = false;
        var _initialized = false;

        function onChangeSupportLE(value) {
            var supportLE = "Yes" === value;

            hyf.util.setComponentVisibility("proposedAnnualLeaveAccrualRate_group", supportLE);
            hyf.util.setComponentUsability("proposedAnnualLeaveAccrualRate_group", activityStep.isSOReview());
            hyf.util.setMandatoryConstraint("proposedAnnualLeaveAccrualRate", activityStep.isSOReview());
            TabManager.setTabHeaderVisibility(MENU_TAB.LE_JUSTIFICATION, supportLE);

            if (cms_incentives_le_approval) {
                cms_incentives_le_approval.onChangeSupportLE(value);
            }
        }

        function initEventHandlers() {
            $('#supportLE').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeSupportLE(value);
            });
        }

        function initComponents() {
            if (activityStep.isStartNew()) {
                hyf.util.hideComponent("componentProposedAnnualLeaveAccrualRate_group");
            }

            var initialOfferedAnnualLeaveAccrualRate = FormState.getElementValue("initialOfferedAnnualLeaveAccrualRate", "4 hours");
            FormState.updateSelectValue("initialOfferedAnnualLeaveAccrualRate", initialOfferedAnnualLeaveAccrualRate, initialOfferedAnnualLeaveAccrualRate, true);

            var mandatory = !_readOnly && (activityStep.isStartNew() && myInfo.isHRS());

            hyf.util.setMandatoryConstraint("initialOfferedAnnualLeaveAccrualRate", mandatory);
            hyf.util.setComponentUsability("initialOfferedAnnualLeaveAccrualRate", mandatory);

            hyf.util.setComponentUsability("supportLE", activityStep.isSOReview());
            hyf.util.setMandatoryConstraint("supportLE", activityStep.isSOReview());
            onChangeSupportLE(FormState.getElementValue("supportLE", ""));
        }

        function init(readOnly) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();

            _initialized = true;
        }

        function render(action) {
        }

        return {
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_le_details || (window.cms_incentives_le_details = cms_incentives_le_details());
})(window);
