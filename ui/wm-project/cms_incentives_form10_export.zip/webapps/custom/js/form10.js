(function (window) {
    var cms_incentives_le_details = function () {
        var _readOnly = false;
        var _initialized = false;
        var _lecocDirector_ac = null;


        function setCOCDirectorAutoCompletion() {
            _lecocDirector_ac = cms_incentives_general.setDesignatedUserAutoCompletion("lecocDirector", USER_GROUP_KEY.CENTER_OFFICE_CONSORTIUM_DIRECTORS, 0, 1, _readOnly);
        }

        function onChangeSupportLE(value) {
            var supportLE = "Yes" === value;

            FormMain.setComponentVisibility("proposedAnnualLeaveAccrualRate_group", supportLE);
            FormMain.setComponentUsability("proposedAnnualLeaveAccrualRate", activityStep.isSOReview() || activityStep.isCOMPReview() || activityStep.isCOMPReviewForModification());
            if (activityStep.isSOReview()) {
                FormMain.setMandatoryConstraint("proposedAnnualLeaveAccrualRate", true);
            } else if (activityStep.isCOMPReview()) {
                FormMain.setMandatoryConstraint("proposedAnnualLeaveAccrualRate", false);
            } else {
                FormMain.setMandatoryConstraint("proposedAnnualLeaveAccrualRate", false);
            }

            if(!supportLE && !_readOnly) {
                FormState.updateSelectValue("proposedAnnualLeaveAccrualRate", "", "Select One", true);
                var approvalCOCValue = FormState.getElementValue("leApprovalCOCValue", "");
                var approvalCOCCheck = FormState.getElementValue("leApprovalCOCCheck", "");
                var approvalChecked = ("true" == approvalCOCCheck) && (("Approve" == approvalCOCValue) || ("Disapprove" == approvalCOCValue));
                if(!approvalChecked) {
                    _lecocDirector_ac.initializeItems([]);
                }
            }

            TabManager.setTabHeaderVisibility(MENU_TAB.LE_JUSTIFICATION, supportLE);

            if (cms_incentives_le_approval) {
                cms_incentives_le_approval.onChangeSupportLE(value);
            }
            if (cms_incentives_le_justification) {
                cms_incentives_le_justification.onChangeSupportLE(value);
            }
            FormMain.setComponentVisibility("lecocDirector_group", supportLE);
            FormMain.setComponentVisibility("lecocDirector_group_bordered", supportLE);
            // if( !_readOnly && myInfo.isSO()) {
            if( !_readOnly && (activityStep.isSOReview() || activityStep.isCOMPReview() || activityStep.isCOMPReviewForModification())) {
                hyf.util.enableComponent("lecocDirector_ac");
                hyf.util.setMandatoryConstraint("lecocDirector_ac", supportLE);
                if(activityStep.isCOMPReview()) {
                    hyf.util.setMandatoryConstraint("lecocDirector_ac", false);
                }
                try {
                    $("#lecocDirector_ac_DISP > li > .removeButton").show();
                } catch(e) {
                }
            }
            var processName = FormMain.getProcessInfo().process.definitionName;
            if ((processName === PROCESS_NAME.LE_V2) && activityStep.isSOReview()) {
                if ("undefined" != typeof (value)) {
                    if ("Yes" == value) {
                        $("#button_SubmitWorkitem").attr({
                            "value": "Send to Center/Office",
                            "title": "Click to send to the Center/Office/Consortium Director",
                            "responseName": "OnGoing"
                        });

                        $("#button_SendTo1").attr({
                            "value": "Send to HR",
                            "title": "Click the button to send to the HR Specialist",
                            "responseName": "SendToHR"
                        });
                        hyf.util.showComponent('button_SendTo1');

                        var approvalCOCValue = FormState.getElementValue("leApprovalCOCValue", "");
                        var approvalChecked = (($("#leApprovalCOCCheck").length == 0) || $("#leApprovalCOCCheck").is(':checked')) && (("Approve" == approvalCOCValue) || ("Disapprove" == approvalCOCValue));
                        if(approvalChecked) {
                            var approvalCOCActing = FormState.getElementValue("leApprovalCOCActing", "");
                            if (approvalCOCActing != "Yes") {
                                approvalChecked = false;
                            }
                            if ($("#leApprovalCOCActing").length > 0) {
                                if($("#leApprovalCOCActing").is(':disabled')) {
                                    //
                                } else {
                                    approvalChecked = true;
                                }
                            }
                        }
                        if (_initialized) {
                            if (approvalChecked) {
                                hyf.util.setComponentUsability('button_SendTo1', true); // Send to HR
                                hyf.util.setComponentUsability('button_SubmitWorkitem', false); // Send to Center/Office
                            } else {
                                hyf.util.setComponentUsability('button_SendTo1', false); // Send to HR
                                hyf.util.setComponentUsability('button_SubmitWorkitem', true); // Send to Center/Office
                            }
                        }
                    } else if ("No" == value) {
                        // Go to HR Specialist Records Candidate Acceptance or Rejection
                        $("#button_SubmitWorkitem").attr({
                            "value": "Send to HR",
                            "title": "Click to send to the HR Specialist",
                            "responseName": "OnGoing"
                        });
                        hyf.util.hideComponent('button_SendTo1');
                    }
                }
            }
			var requestStatus = FormUtility.getInputElementValue('pv_requestStatus');
			if (activityStep.isCOMPReviewForModification()) {
				
				if (requestStatus == 'Component Review')
				{
					hyf.util.setComponentUsability('button_SendTo2', false);
				}
			}		
            if(_initialized) {
                if (activityStep.isCOMPReviewForModification()) {
                    if ("undefined" != typeof (value)) {
						if (requestStatus == 'Return to Component') {
							if ("Yes" == value) {
								hyf.util.setComponentUsability('button_SendTo2', true);
								FormMain.setMandatoryConstraint("lecocDirector_ac", true);
							} else if ("No" == value) {
								hyf.util.setComponentUsability('button_SendTo2', false);
							}
						}
						else if (requestStatus == 'Component Review')
						{
							hyf.util.setComponentUsability('button_SendTo2', false);
						}
                    }
                }
            }
        }

        function initEventHandlers() {
            $('#supportLE').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeSupportLE(value);
            });
        }

        function initComponents() {
            if (activityStep.isStartNew()) {
                hyf.util.hideComponent("componentProposedAnnualLeaveAccrualRate_group");
            }

            var initialOfferedAnnualLeaveAccrualRate = FormState.getElementValue("initialOfferedAnnualLeaveAccrualRate", "4 hours");
            FormState.updateSelectValue("initialOfferedAnnualLeaveAccrualRate", initialOfferedAnnualLeaveAccrualRate, initialOfferedAnnualLeaveAccrualRate, true);

            var mandatory = !_readOnly && (activityStep.isStartNew() && myInfo.isHRS());

            hyf.util.setMandatoryConstraint("initialOfferedAnnualLeaveAccrualRate", mandatory);
            FormMain.setComponentUsability("initialOfferedAnnualLeaveAccrualRate", mandatory);
			
            var supportLEMandatory = !_readOnly && (activityStep.isSOReview() || activityStep.isCOMPReview() || activityStep.isCOMPReviewForModification());
            FormMain.setComponentUsability("supportLE", supportLEMandatory);
            hyf.util.setMandatoryConstraint("supportLE", supportLEMandatory);

			//$("#proposedAnnualLeaveAccrualRate option[value='4 hours']").remove();
			$("#proposedAnnualLeaveAccrualRate option[value='" + initialOfferedAnnualLeaveAccrualRate + "']").remove();

            setCOCDirectorAutoCompletion();
            if (!supportLEMandatory) {
            // if (_readOnly || myInfo.isHRL() || myInfo.isXO() || myInfo.isHRS() || myInfo.isDGHO() || myInfo.isTABG() || myInfo.isOHC()) {
                hyf.util.disableComponent("lecocDirector_ac");
                hyf.util.setMandatoryConstraint("lecocDirector_ac", false);
                try {
                    $("#lecocDirector_ac_DISP > li > .removeButton").hide();
                } catch(e) {
                }
            }

            onChangeSupportLE(FormState.getElementValue("supportLE", ""));

            if (supportLEMandatory) {
                if( myInfo.isXO() || myInfo.isHRL()) {
                    hyf.util.setMandatoryConstraint("supportLE", false);
                    hyf.util.setMandatoryConstraint("lecocDirector_ac", false);
                }
                if (activityStep.isCOMPReviewForModification()) {
                    FormMain.setMandatoryConstraint("lecocDirector_ac", true);
                }
            }
        }

        function init(readOnly, tabObject) {
            _readOnly = readOnly;
            if(tabObject && tabObject.readonly) {
                _readOnly = true;
            }

            initComponents();
            initEventHandlers();
            FormMain.resetMandatoryMark(tabObject);

            _initialized = true;
        }

        function render(action) {
        }

        return {
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_le_details || (window.cms_incentives_le_details = cms_incentives_le_details());
})(window);
