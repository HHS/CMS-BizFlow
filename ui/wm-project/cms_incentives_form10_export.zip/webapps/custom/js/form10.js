(function (window) {
    var cms_incentives_le_details = function () {
        var _readOnly = false;
        var _initialized = false;
        var _lecocDirector_ac = null;


        function setCOCDirectorAutoCompletion() {
            _lecocDirector_ac = cms_incentives_general.setDesignatedUserAutoCompletion("lecocDirector", USER_GROUP_KEY.CENTER_OFFICE_CONSORTIUM_DIRECTORS, 0, 1, _readOnly);
        }

        function onChangeSupportLE(value) {
            var supportLE = "Yes" === value;

            hyf.util.setComponentVisibility("proposedAnnualLeaveAccrualRate_group", supportLE);
            hyf.util.setComponentUsability("proposedAnnualLeaveAccrualRate_group", activityStep.isSOReview());
            hyf.util.setMandatoryConstraint("proposedAnnualLeaveAccrualRate", activityStep.isSOReview());
            TabManager.setTabHeaderVisibility(MENU_TAB.LE_JUSTIFICATION, supportLE);

            if (cms_incentives_le_approval) {
                cms_incentives_le_approval.onChangeSupportLE(value);
            }
        }

        function initEventHandlers() {
            $('#supportLE').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeSupportLE(value);
            });
        }

        function initComponents() {
            if (activityStep.isStartNew()) {
                hyf.util.hideComponent("componentProposedAnnualLeaveAccrualRate_group");
                hyf.util.hideComponent("lecocDirector_group");
                hyf.util.hideComponent("lecocDirector_group_bordered");
            } else {
                hyf.util.showComponent("lecocDirector_group");
                hyf.util.showComponent("lecocDirector_group_bordered");
            }

            var initialOfferedAnnualLeaveAccrualRate = FormState.getElementValue("initialOfferedAnnualLeaveAccrualRate", "4 hours");
            FormState.updateSelectValue("initialOfferedAnnualLeaveAccrualRate", initialOfferedAnnualLeaveAccrualRate, initialOfferedAnnualLeaveAccrualRate, true);

            var mandatory = !_readOnly && (activityStep.isStartNew() && myInfo.isHRS());

            hyf.util.setMandatoryConstraint("initialOfferedAnnualLeaveAccrualRate", mandatory);
            hyf.util.setComponentUsability("initialOfferedAnnualLeaveAccrualRate", mandatory);

            hyf.util.setComponentUsability("supportLE", activityStep.isSOReview());
            hyf.util.setMandatoryConstraint("supportLE", activityStep.isSOReview());

            setCOCDirectorAutoCompletion();
            if (myInfo.isHRL() || myInfo.isXO() || myInfo.isHRS() || myInfo.isDGHO() || myInfo.isTABG() || myInfo.isOHC()) {
                hyf.util.disableComponent("lecocDirector_ac");
            }
            if( myInfo.isSO()) {
                hyf.util.enableComponent("lecocDirector_ac");
                hyf.util.setMandatoryConstraint("lecocDirector_ac", true);
            }

            onChangeSupportLE(FormState.getElementValue("supportLE", ""));
        }

        function init(readOnly, tabObject) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();
            FormMain.resetMandatoryMark(tabObject);

            _initialized = true;
        }

        function render(action) {
        }

        return {
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_le_details || (window.cms_incentives_le_details = cms_incentives_le_details());
})(window);
