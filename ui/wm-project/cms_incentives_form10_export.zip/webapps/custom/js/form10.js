(function (window) {
    var cms_incentives_le_details = function () {
        var _readOnly = false;
        var _initialized = false;

        function initEventHandlers() {
        }

        function initComponents() {
        }

        function init(readOnly) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();

            _initialized = true;
        }

        function render(action) {
        }

        return {
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_le_details || (window.cms_incentives_le_details = cms_incentives_le_details());
})(window);
