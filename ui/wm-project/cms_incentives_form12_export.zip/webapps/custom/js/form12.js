(function (window) {
    var cms_incentives_le_review = function () {
        var _readOnly = false;
        var _initialized = false;

        function initEventHandlers() {
        }

        function initComponents() {
        }

        function init(readOnly) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();

            _initialized = true;
        }

        function render(action) {
        }

        return {
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_le_review || (window.cms_incentives_le_review = cms_incentives_le_review());
})(window);
