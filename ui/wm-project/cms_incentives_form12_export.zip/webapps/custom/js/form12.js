(function (window) {
    var cms_incentives_le_review = function () {
        var _readOnly = false;
        var _initialized = false;
        var _readOnlyCreditableNonFederalService = false;

        var _lastRcmdAARate = null;
        var _lastRcmdAARateIndex = -1;
        var _lastRcmdAARateTr = null;

        var SELECTEE_MEET_ELIGIBILITY = {
            CIVILIAN_EMPLOYEE: "5 CFR 531.212(a)(i) First appointment as a civilian employee",
            REAPPOINTMENT: "5 CFR 531.212(a)(ii) Qualifying Reappointment",
            NOT_ELIGIBILITY: "Selectee does not meet eligibility requirements"
        };
        var QUALIFYING_REAPPOINTMENT = {
            DAY90_BREAK_IN: "90-day break in service",
            OTHER: "Other exceptions"
        };

        var HRSPECIALIST_REVIEW_CERTIFICATION = {
            CONCUR: "I concur with the recommending official",
            CONCUR_WITH_MODIFICATION: "I concur with the recommending official, but have adjusted the service credit",
            NOT_CONCUR: "I do not concur with this request"
        };

        function setReviewerAndReviewDate(eleId, dateEleId, checked) {
            var currentUserName = "";
            var currentUserId = "";
            var currentDate = "";
            if (checked) {
                currentUserName = myInfo.getMyName();
                currentUserId = myInfo.getMyMemberId();
                currentDate = FormUtility.getDateString(false, "mm/dd/yyyy", new Date());
            }

            $("#" + eleId).val(currentUserName);
            $("#" + dateEleId).val(currentDate);

            FormState.updateTextValue(eleId, currentUserName, false);
            FormState.updateTextValue(eleId + "Id", currentUserId, false);
            FormState.updateDateValue(dateEleId, currentDate, false);
        }

        function onChangeHRSpecialistReviewCertification(value) {
            if (value === HRSPECIALIST_REVIEW_CERTIFICATION.CONCUR) {
                hyf.util.showComponent("rcmdAnnualLeaveAccrualRate_group", true);
                hyf.util.disableComponent("rcmdAnnualLeaveAccrualRate_group");
                if (_initialized) {
                    FormState.updateSelectValue("rcmdAnnualLeaveAccrualRate", FormState.getElementValue("proposedAnnualLeaveAccrualRate", ""));
                }
            } else if (value === HRSPECIALIST_REVIEW_CERTIFICATION.CONCUR_WITH_MODIFICATION) {
                hyf.util.showComponent("rcmdAnnualLeaveAccrualRate_group", true);
                hyf.util.enableComponent("rcmdAnnualLeaveAccrualRate_group");
                if (_initialized) {
                    FormState.updateSelectValue("rcmdAnnualLeaveAccrualRate", FormState.getElementValue("proposedAnnualLeaveAccrualRate", ""));
                }
            } else {
                hyf.util.hideComponent("rcmdAnnualLeaveAccrualRate_group");
                if (_initialized) {
                    FormState.updateSelectValue("rcmdAnnualLeaveAccrualRate", "");
                }
            }

            hyf.util.setComponentVisibility("hrSpecialistLENotSupportReason_group", value === HRSPECIALIST_REVIEW_CERTIFICATION.NOT_CONCUR);

            if (_initialized) {
                setReviewerAndReviewDate("leReviewHRSpecialist", "hrSpecialistLEReviewDate", value !== "");
            }
        }

        function deleteCreditableNonFederalService(index) {
            var creditableNonFederalServices = FormState.getElementArrayValue("creditableNonFederalServices", []);
            if (index >= 0 && index < creditableNonFederalServices.length) {
                creditableNonFederalServices.splice(index, 1);
                FormState.updateObjectValue("creditableNonFederalServices", creditableNonFederalServices);
                drawCreditableNonFederalServices(creditableNonFederalServices);
            }
        }

        function getCreditableNonFederalServiceHtml(creditableNonFederalService, index) {
            var html = "<td>" + creditableNonFederalService.startDate + "</td>";
            html += "<td>" + creditableNonFederalService.endDate + "</td>";
            html += "<td>" + creditableNonFederalService.workSchedule + "</td>";
            html += "<td>" + creditableNonFederalService.positionTitle + "</td>";
            html += "<td>" + (creditableNonFederalService.calculatedTime ? creditableNonFederalService.calculatedTime.years : "") + "</td>";
            html += "<td>" + (creditableNonFederalService.calculatedTime ? creditableNonFederalService.calculatedTime.months : "") + "</td>";
            if (activityStep.isHRSReviewForModification()) {
                html += "<td><input name='creditableYear" + index + "' data_type='years' data_index='" + index + "' value='" + (creditableNonFederalService.calculatedTime ? creditableNonFederalService.creditableTime.years : "") + "'></td>";
                html += "<td><input name='creditableMonth" + index + "' data_type='months' data_index='" + index + "' value='" + (creditableNonFederalService.calculatedTime ? creditableNonFederalService.creditableTime.months : "") + "'></td>";
                html += "<td></td>";
            } else if (_readOnly || _readOnlyCreditableNonFederalService) {
                html += "<td>" + (creditableNonFederalService.calculatedTime ? creditableNonFederalService.creditableTime.years : "") + "</td>";
                html += "<td>" + (creditableNonFederalService.calculatedTime ? creditableNonFederalService.creditableTime.months : "") + "</td>";
                html += "<td></td>";
            } else {
                html += "<td><input disabled name='creditableYear" + index + "' data_type='years' data_index='" + index + "' value='" + (creditableNonFederalService.calculatedTime ? creditableNonFederalService.creditableTime.years : "") + "'></td>";
                html += "<td><input disabled name='creditableMonth" + index + "' data_type='months' data_index='" + index + "' value='" + (creditableNonFederalService.calculatedTime ? creditableNonFederalService.creditableTime.months : "") + "'></td>";
                html += "<td><button data_index='" + index + "'>Delete</button></td>";
            }

            return html;
        }

        function cleanCreditableNonFederalServices(table) {
            var trs = table.getElementsByTagName("tr");
            if (trs) {
                for (var i = trs.length - 1; i >= 0; i--) {
                    var tr = trs[i];
                    var type = tr.getAttribute("data_type");
                    if (type && type === "creditableNonFederalService") {
                        tr.parentElement.removeChild(tr);
                    }
                }
            }
        }

        function updateCreditableNonFederalService(target) {
            var index = FormUtility.parseInt(target.getAttribute("data_index"), -1);
            if (index >= 0) {
                var type = target.getAttribute("data_type");
                var creditableNonFederalServices = FormState.getElementArrayValue("creditableNonFederalServices", []);

                if (type === "years") {
                    creditableNonFederalServices[index].creditableTime.years = FormUtility.parseInt(target.value, 0);
                } else {
                    creditableNonFederalServices[index].creditableTime.months = FormUtility.parseInt(target.value, 0);
                }

                FormState.updateObjectValue("creditableNonFederalServices", creditableNonFederalServices);
                drawCreditableNonFederalServices(creditableNonFederalServices);
            }
        }

        function drawCreditableNonFederalServices(creditableNonFederalServices) {
            var table = document.getElementById("creditableNonFederalServices");
            cleanCreditableNonFederalServices(table);

            var years = 0;
            var months = 0;

            var noRow = document.getElementById("creditableNonFederalServicesNoRecordRow");
            if (creditableNonFederalServices.length === 0) {
                noRow.style.display = "";
            } else {
                noRow.style.display = "none";
                for (var i = 0; i < creditableNonFederalServices.length; i++) {
                    var creditableNonFederalService = creditableNonFederalServices[i];
                    if (creditableNonFederalService) {
                        var tr$ = $("<tr id='creditableNonFederalService'" + i +" data_type='creditableNonFederalService'></tr>");
                        tr$.append(getCreditableNonFederalServiceHtml(creditableNonFederalService, i));
                        $(table).append(tr$);

                        years += FormUtility.parseInt(creditableNonFederalService.creditableTime.years, 0);
                        months += FormUtility.parseInt(creditableNonFederalService.creditableTime.months, 0);
                    }
                }
            }

            FormState.updateTextValue("totalCreditableServiceYears", years, true);
            FormState.updateTextValue("totalCreditableServiceMonths", months, true);

            $(table).find('button').on('click keyup', function (e) {
                e = e || window.event;
                if (e.type === 'click' || (e.type === 'keyup' && (e.key === ' ' || e.key === 'Enter'))) {
                    var target = e.target;
                    var index = FormUtility.parseInt(target.getAttribute("data_index"), -1);
                    deleteCreditableNonFederalService(index);
                }
            });

            $(table).find('input').on('blur', function (e) {
                e = e || window.event;
                var target = e.target;
                updateCreditableNonFederalService(target)
            });
        }

        function validateCreditableNonFederalServiceDate(startDate, endDate) {
            var startDate = FormUtility.stringToDate(startDate, "mm/yyyy", "/");
            var endDate = FormUtility.stringToDate(endDate, "mm/yyyy", "/");
            if (endDate) {
                if (!startDate || startDate.getTime() > endDate.getTime()) {
                    return false;
                }
            }

            return true;
        }

        function addCreditableNonFederalService() {
            var creditableNonFederalServiceStartDate = $("#creditableNonFederalServiceStartDate").val();
            var creditableNonFederalServiceEndDate = $("#creditableNonFederalServiceEndDate").val();
            var creditableNonFederalServiceWorkSchedule = $("#creditableNonFederalServiceWorkSchedule").val();
            var creditableNonFederalServicePositionTitle = $("#creditableNonFederalServicePositionTitle").val();

            if (!validateCreditableNonFederalServiceDate(creditableNonFederalServiceStartDate, creditableNonFederalServiceEndDate)) {
                setTimeout(function () {
                    FormUtility.displayError("creditableNonFederalServiceEndDate", '"End Date" cannot be prior to "Start Date"');
                }, 50);
                return false;
            }

            if (creditableNonFederalServiceStartDate && creditableNonFederalServiceEndDate && creditableNonFederalServiceWorkSchedule && creditableNonFederalServicePositionTitle) {
                var monthDiff = FormUtility.diffMonth(FormUtility.stringToDate(creditableNonFederalServiceStartDate, "mm/yyyy", "/")
                    , FormUtility.stringToDate(creditableNonFederalServiceEndDate, "mm/yyyy", "/"));

                var creditableNonFederalService = {
                    startDate: creditableNonFederalServiceStartDate,
                    endDate: creditableNonFederalServiceEndDate,
                    workSchedule: creditableNonFederalServiceWorkSchedule,
                    positionTitle: creditableNonFederalServicePositionTitle,
                    calculatedTime: {
                        years: parseInt(monthDiff / 12),
                        months: monthDiff % 12
                    },
                    creditableTime: {
                        years: "",
                        months: ""
                    }
                };

                var creditableNonFederalServices = FormState.getElementArrayValue("creditableNonFederalServices", []);
                creditableNonFederalServices.push(creditableNonFederalService);
                FormState.updateObjectValue("creditableNonFederalServices", creditableNonFederalServices);

                drawCreditableNonFederalServices(creditableNonFederalServices);

                $("#creditableNonFederalServiceStartDate").val("");
                $("#creditableNonFederalServiceEndDate").val("");
                $("#creditableNonFederalServiceWorkSchedule").val("");
                $("#creditableNonFederalServicePositionTitle").val("");
            } else {
                bootbox.alert('Please enter a valid date into the "Start Date" field, "End Date" field, make a selection from the "Work Schedule" field, and enter a "Position Title"');
            }
        }

        function getRcmdAnnualLeaveAccrualRates() {
            var rcmdAnnualLeaveAccrualRates = FormState.getElementArrayValue("rcmdAnnualLeaveAccrualRates", []);
            if (rcmdAnnualLeaveAccrualRates.length === 1) {
                if (typeof rcmdAnnualLeaveAccrualRates[0].witemSeq === 'undefined') {
                    rcmdAnnualLeaveAccrualRates = [];
                }
            }

            return rcmdAnnualLeaveAccrualRates;
        }

        function getRcmdAnnualLeaveAccrualRateHtml(rcmdAARate) {
            var html = "<td>" + rcmdAARate.rate + "</td>";
            html += "<td>" + rcmdAARate.createdBy + "</td>";
            html += "<td>" + rcmdAARate.modifiedBy + "</td>";
            html += "<td>" + rcmdAARate.modifierRoleGroup + "</td>";
            html += "<td>" + FormUtility.getDateString(false, "mm/dd/yyyy", new Date(FormUtility.parseInt(rcmdAARate.modifiedDate, 0))) + "</td>";

            return html;
        }

        function drawPreviouslyRecommendedAnnualAccrualRate() {
            var rcmdAnnualLeaveAccrualRates = getRcmdAnnualLeaveAccrualRates();
            if (rcmdAnnualLeaveAccrualRates.length > 0) {
                var table = document.getElementById("reviewRcmdAARate_history");
                hyf.util.showComponent("previousRcmdAARate_group");
                for (var i = 0; i < rcmdAnnualLeaveAccrualRates.length; i++) {
                    var item = rcmdAnnualLeaveAccrualRates[i];
                    if (item && item.witemSeq) {
                        var html = getRcmdAnnualLeaveAccrualRateHtml(item);
                        var tr = document.createElement("tr");
                        tr.setAttribute("id", "rcmdAnnualLeaveAccrualRateTr" + i);
                        tr.innerHTML = html;
                        table.appendChild(tr);
                    }
                }
            } else {
                hyf.util.hideComponent("previousRcmdAARate_group");
            }
        }

        function onChangeRcmdAnnualLeaveAccrualRate(value) {
            var now = new Date();
            var witemSeq = FormMain.getProcessInfo().workitem.sequence;
            var rcmdAnnualLeaveAccrualRates = getRcmdAnnualLeaveAccrualRates();

            if (null == _lastRcmdAARate) {
                for (var i = 0; i < rcmdAnnualLeaveAccrualRates.length; i++) {
                    var item = rcmdAnnualLeaveAccrualRates[i];
                    if (item.witemSeq == witemSeq && item.modifier == myInfo.getMyMemberId()) {
                        _lastRcmdAARate = item;
                        _lastRcmdAARateIndex = i;
                        _lastRcmdAARateTr = document.getElementById("rcmdAnnualLeaveAccrualRateTr" + i);
                        break;
                    }
                }
            }

            var rcmdAARate_2 = undefined !== value ? value : FormState.getElementValue("rcmdAnnualLeaveAccrualRate");

            if (null == _lastRcmdAARate) {
                var rcmdAARate = FormState.getElementValue("lastRcmdAnnualLeaveAccrualRate");

                if (rcmdAARate !== rcmdAARate_2) {
                    var last = null;

                    if (rcmdAnnualLeaveAccrualRates.length > 0) {
                        last = rcmdAnnualLeaveAccrualRates[rcmdAnnualLeaveAccrualRates.length - 1];
                    }

                    _lastRcmdAARate = {
                        rate: rcmdAARate,
                        createdBy: null != last ? last.modifiedBy : FormState.getElementValue("leReviewHRSpecialist"),
                        modifiedBy: myInfo.getMyName(),
                        modifier: myInfo.getMyMemberId(),
                        modifiedDate: now.getTime(),
                        modifierRoleGroup: activityStep.getCurrentRoleGroup(),
                        witemSeq: witemSeq
                    };

                    if (rcmdAnnualLeaveAccrualRates.length === 0) {
                        hyf.util.showComponent("previousRcmdAARate_group");
                    }

                    rcmdAnnualLeaveAccrualRates.push(_lastRcmdAARate);
                    _lastRcmdAARateIndex = rcmdAnnualLeaveAccrualRates.length - 1;
                    FormState.updateObjectValue("rcomdAnnualLeaveAccrualRates", rcmdAnnualLeaveAccrualRates);
                    var table = document.getElementById("reviewRcmdAARate_history");
                    _lastRcmdAARateTr = document.createElement("tr");
                    _lastRcmdAARateTr.innerHTML = getRcmdAnnualLeaveAccrualRateHtml(_lastRcmdAARate);
                    table.appendChild(_lastRcmdAARateTr);
                }
            } else {
                if (rcmdAARate_2 === _lastRcmdAARate.rate) {
                    if (null != _lastRcmdAARateTr) {
                        var table = document.getElementById("reviewRcmdAARate_history");
                        table.removeChild(_lastRcmdAARateTr);
                        _lastRcmdAARateTr = null;
                    }
                    if (_lastRcmdAARateIndex !== -1) {
                        rcmdAnnualLeaveAccrualRates.splice(_lastRcmdAARateIndex, 1);
                        FormState.updateObjectValue("rcmdAnnualLeaveAccrualRates", rcmdAnnualLeaveAccrualRates);
                        if (rcmdAnnualLeaveAccrualRates.length === 0) {
                            hyf.util.hideComponent("previousRcmdAARate_group");
                        }
                        _lastRcmdAARateIndex = -1;
                    }
                    _lastRcmdAARate = null;
                } else {
                    _lastRcmdAARate.modifiedDate = now.getTime();
                    _lastRcmdAARateTr.innerHTML = getRcmdAnnualLeaveAccrualRateHtml(_lastRcmdAARate);
                }
            }

            FormState.updateSelectValue("lastRcmdAnnualLeaveAccrualRate", rcmdAARate_2, rcmdAARate_2, false);
        }

        function onChangeSelecteeMeetEligibility(value) {
            var isReappointment = value === SELECTEE_MEET_ELIGIBILITY.REAPPOINTMENT;
            hyf.util.setComponentVisibility("lequalifyingReappointment_group", isReappointment);
            if (!isReappointment) {
                FormState.updateSelectValue("lequalifyingReappointment", "", "Select One", true);
                onChangeQualifyingReappointment("");
            }
            var isNotEligibility = value === SELECTEE_MEET_ELIGIBILITY.NOT_ELIGIBILITY;
            if (isNotEligibility) {
                if (activityStep.isStartNew()) {
                    hyf.util.disableComponent("button_SubmitWorkitem");
                }
            } else {
                if (activityStep.isStartNew()) {
                    hyf.util.enableComponent("button_SubmitWorkitem");
                }
            }
        }
        function onChangeQualifyingReappointment(value) {
            var isOther = value === QUALIFYING_REAPPOINTMENT.OTHER;
            if (!isOther) {
                FormState.updateTextValue("leotherExceptions", "", true);
            }
            hyf.util.setComponentVisibility("leotherExceptions_group", isOther);
        }

        function initEventHandlers() {
            $('#leSelecteeEligibility').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeSelecteeMeetEligibility(value);
            });
            $('#lequalifyingReappointment').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeQualifyingReappointment(value);
            });
            $('#hrSpecialistLEReviewCertification').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeHRSpecialistReviewCertification(value);
            });
            $('#button_addCreditableService').on('click', function (e) {
                addCreditableNonFederalService();
            });
            $('#rcmdAnnualLeaveAccrualRate').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                if (activityStep.isDGHOReview() || activityStep.isTABGReview()) {
                    onChangeRcmdAnnualLeaveAccrualRate(value);
                }
            });
        }

        function initComponents() {
            LookupManager.fillListBox("creditableNonFederalServiceWorkSchedule", "WorkSchedule");

            onChangeSelecteeMeetEligibility(FormState.getElementValue("leSelecteeEligibility"));
            onChangeQualifyingReappointment(FormState.getElementValue("lequalifyingReappointment"));

            // if (activityStep.isSOReview() || activityStep.isTABGReview()) {
            //     hyf.util.disableComponent("creditableNonFederalService_group");
            //     _readOnlyCreditableNonFederalService = true;
            // }

            if (activityStep.isStartNew() && myInfo.isHRS()) {
                hyf.util.hideComponent("creditableNonFederalService_group");
            }
            if (myInfo.isDGHO() || myInfo.isTABG()) {
                hyf.util.disableComponent("creditableNonFederalService_group");
                _readOnlyCreditableNonFederalService = true;
            }

            if (!activityStep.isSOReview()) {
                _readOnlyCreditableNonFederalService = true;

                hyf.util.disableComponent("creditableNonFederalServiceStartDate");
                hyf.util.disableComponent("creditableNonFederalServiceStartDate");
                hyf.util.disableComponent("creditableNonFederalServiceStartDate_calendar_anchor");
                hyf.util.disableComponent("creditableNonFederalServiceEndDate");
                hyf.util.disableComponent("creditableNonFederalServiceEndDate_calendar_anchor");
                hyf.util.disableComponent("creditableNonFederalServiceWorkSchedule");
                hyf.util.disableComponent("creditableNonFederalServicePositionTitle");
                hyf.util.disableComponent("button_addCreditableService");
            }

            if (activityStep.isStartNew() || activityStep.isHRSReviewForModification() || activityStep.isSOReview()) {
                hyf.util.hideComponent("hrsRegulatoryLEReview_group");
            }

            hyf.util.setComponentUsability("hrsRegulatoryLEReview_group", activityStep.isHRSReview());

            onChangeHRSpecialistReviewCertification(FormState.getElementValue("hrSpecialistLEReviewCertification"));
            hyf.util.setComponentUsability("leselecteeMeets_group", activityStep.isHRSReview() || (activityStep.isStartNew() && myInfo.isHRS()));
            if (myInfo.isXO() || myInfo.isSO() || myInfo.isHRL() || myInfo.isDGHO() || myInfo.isTABG()) {
                hyf.util.disableComponent("leselecteeMeets_group");
            }

            drawCreditableNonFederalServices(FormState.getElementArrayValue("creditableNonFederalServices", []));

            var lastRcmdAnnualLeaveAccrualRate = FormState.getElementValue("lastRcmdAnnualLeaveAccrualRate", "");
            if (!lastRcmdAnnualLeaveAccrualRate) {
                FormState.updateObjectValue("lastRcmdAnnualLeaveAccrualRate", FormState.getElementValue("rcmdAnnualLeaveAccrualRate", ""))
            }

            drawPreviouslyRecommendedAnnualAccrualRate();
        }

        function init(readOnly) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();

            _initialized = true;
        }

        function render(action) {
        }

        return {
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_le_review || (window.cms_incentives_le_review = cms_incentives_le_review());
})(window);
