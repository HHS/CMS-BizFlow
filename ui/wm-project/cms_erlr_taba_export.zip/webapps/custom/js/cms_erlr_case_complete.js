(function (window) {
    'use strict';

    function cms_case_complete() {
        var _CC_FINAL_ACTION_ac = null;

        function init() {
            var reqFieldForActivity =
                [
                    {
                        actName: globalVars.actAll,
                        reqFieldIds:
                            []
                    },
                    {
                        actName: globalVars.actCaseCreation,
                        reqFieldIds:
                            []
                    },
                    {
                        actName: globalVars.actCaseComplete,
                        reqFieldIds:
                            [
                                'CC_FINAL_ACTION',
                                'CC_FINAL_ACTION_OTHER',
                                'CC_CASE_COMPLETE_DT'
                            ]
                    }
                ];
            CommonOpUtil.dynamicMandatory(reqFieldForActivity);
            hyf.calendar.setDateConstraint('CC_CASE_COMPLETE_DT', 'Maximum', 'Today');

            var actions = FormState.getElementArrayValue('CC_FINAL_ACTION',[]);
            var hasOther = false;
            for (var i = 0; i < actions.length; i++) {
                if (actions[i] === 'Other') {
                    hasOther = true;
                    break;
                }
            }
            CommonOpUtil.showHideLayoutGroup("CC_FINAL_ACTION_OTHER_group", hasOther);

            setCompleteCaseAutoCompletion();
        }

        var _firstTimeRender = true;

        function render(){
            if (FormState.isDirty('GEN_CASE_TYPE') || FormState.isDirty('THRD_PRTY_APPEAL_TYPE')) {
                finalAction(_firstTimeRender);
            }
            _firstTimeRender = false;
        }

        function finalAction(showPriorSelectedValue) {
            var optionLookupArray = [];
            var caseTypeState = FormState.getState('GEN_CASE_TYPE');
            if (typeof caseTypeState === 'undefined' || caseTypeState == null) return;
            var caseTypeTxt = caseTypeState.text;
            if (caseTypeTxt === 'Third Party Hearing') {
                var appealType = FormState.getElementValue('THRD_PRTY_APPEAL_TYPE');
                if (_.isEmpty(appealType)) {
                    //TODO
                } else {
                    optionLookupArray = LookupManager.findByLTYPE('ERLRInitialResponseCaseType[' + caseTypeTxt + ']/ERLRCasesCompletedFinalAction[' + appealType + ']/ERLRCasesCompletedFinalAction');
                }
            } else {
                caseTypeTxt = caseTypeTxt.replace('/', '*/*'); // replace slash to distinguish literal from path separator in lookup manager
                optionLookupArray = LookupManager.findByLTYPE('ERLRInitialResponseCaseType[' + caseTypeTxt + ']/ERLRCasesCompletedFinalAction');
            }

            if (typeof optionLookupArray === 'undefined' || optionLookupArray == null || !$.isArray(optionLookupArray)) return;

            var optionStr = "<option value selected>Select</option>";
            for (var i = 0; i < optionLookupArray.length; i++) {
                optionStr += "<option value=\"" + optionLookupArray[i].NAME + "\">" + optionLookupArray[i].LABEL + "</option>";
            }
            $('#CC_FINAL_ACTION').find('option').remove().end().append(optionStr);

            if (!showPriorSelectedValue) {
                _CC_FINAL_ACTION_ac.initializeItems([]);
            }
        }

        function completeCaseMultiSelectOptions(dropdownID) {
            var optionsMinSelection = (FormMain.isCompleteCaseActivity()) ? 1 : 0;
            var optionsInitialData = [];
            var optionsIdString = FormState.getElementValue(dropdownID);
            var optionsIds = ((optionsIdString != null && optionsIdString.length > 0) ? optionsIdString.split(',') : []);
            var count = optionsIds.length;
            for (var index = 0; index < count; index++) {
                var itemLabel = $('#' + dropdownID + '_SEL option[value="' + optionsIds[index] + '"]').text();
                optionsInitialData.push({
                    id: optionsIds[index],
                    label: itemLabel
                });
            }
            var multiSelectOptions = {
                id: dropdownID,
                tabindex: 0,
                minSelectionCount: optionsMinSelection,
                maxSelectionCount: 10,
                getSelectionLabel: function (item) {
                    return item.label
                },
                getItemID: function (item) {
                    return item.id;
                },
                initialItems: optionsInitialData,
                setDataToForm: function (values) {
                    if (typeof values == 'undefined') return;
                    var selectedIds = '';
                    if (values != null && $.isArray(values)) {
                        selectedIds = values.reduce(function (accumulator, currentValue, currentIndex, array) {
                            return (accumulator && accumulator.length > 0) ? accumulator + ',' + currentValue.id : currentValue.id;
                        }, '');
                    }
                    FormState.updateObjectValue(dropdownID, selectedIds);
                }
            };
            MultiSelectDropdown.setupMultiSelectDropdown(multiSelectOptions);
        }

        function handleOtherFinalAction(values) {
            var hasOther = false;
            for (var i = 0; i < values.length; i++) {
                var item = values[i];
                if (item.value === 'Other') {
                    hasOther = true;
                    if (i < values.length - 1) {
                        values.splice(i, 1);
                        values.push(item);
                    }
                    break;
                }
            }

            CommonOpUtil.showHideLayoutGroup("CC_FINAL_ACTION_OTHER_group", hasOther);
        }

        function setCompleteCaseAutoCompletion() {
            var option = {
                id: 'CC_FINAL_ACTION',
                useAddButton: false,
                baseURL: '/bizflowwebmaker/StratCon_AUT',
                minSelectionCount: (FormMain.isCompleteCaseActivity()) ? 1 : 0,
                maxSelectionCount: 10,


                mapFunction: function (context) {
                },
                getSelectionLabel: function (item) {
                    return item.text;
                },
                getCandidateLabel: function (item) {
                    return item.value;
                },
                getItemID: function (item) {
                    return item.value;
                },
                setDataToForm: function (values) {
                    FormState.updateObjectValue('CC_FINAL_ACTION_SEL', values, false);
                    handleOtherFinalAction(values);
                },
                sortSelectedValues: function (values) {
                    var other = null;
                    for (var i = 0; i < values.length; i++) {
                        var item = values[i];
                        if (item.value === 'Other') {
                            other = item;
                            values.splice(i, 1);
                            break;
                        }
                    }

                    values.sort(function (a, b) {
                        return a.value > b.value;
                    });

                    if (other !== null) {
                        values.push(item);
                    }

                    return values;
                },
                isValidListItem: function (item, target) {
                    return item.value !== "";
                },
                afterItemDisplayed: function (containerId, item) {
                    //FormUtility.removeSelectOption(item.value, "CC_FINAL_ACTION", false);
                },
                afterItemDeleted: function (containerId, targetId, item, values) {
                    // var target = FormUtility.addSelectionAndSortExceptLast(item.text, item.value, "CC_FINAL_ACTION", "Other");
                    // target.selectedIndex = values.length === 0 ? 0 : -1;
                },
                initialItems: FormState.getElementArrayValue('CC_FINAL_ACTION_SEL', [])
            };

            _CC_FINAL_ACTION_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        return {
            init: init,
            render: render
        }
    }

    (window.cms_case_complete !== undefined ? window.cms_case_complete : (window.cms_case_complete = cms_case_complete()));
})(window)