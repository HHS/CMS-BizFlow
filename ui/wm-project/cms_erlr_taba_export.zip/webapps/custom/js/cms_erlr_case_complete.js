(function (window) {
    'use strict';

    function cms_case_complete() {
        var _CC_FINAL_ACTION_ac = null;

        function init() {
            var reqFieldForActivity =
                [
                    {
                        actName: globalVars.actAll,
                        reqFieldIds:
                            []
                    },
                    {
                        actName: globalVars.actCaseCreation,
                        reqFieldIds:
                            []
                    },
                    {
                        actName: globalVars.actCaseComplete,
                        reqFieldIds:
                            [
                                'CC_FINAL_ACTION',
                                'CC_FINAL_ACTION_OTHER',
                                'CC_CASE_COMPLETE_DT'
                            ]
                    }
                ];
            CommonOpUtil.dynamicMandatory(reqFieldForActivity);
            hyf.calendar.setDateConstraint('CC_CASE_COMPLETE_DT', 'Maximum', 'Today');
            FormState.updateSelectValue('CC_FINAL_ACTION', '', false);
            var actions = FormState.getElementArrayValue('CC_FINAL_ACTION_SEL', []);

            var hasOther = false;
            for (var i = 0; i < actions.length; i++) {
                if (actions[i] === 'Other') {
                    hasOther = true;
                    break;
                }
            }
            CommonOpUtil.showHideLayoutGroup("CC_FINAL_ACTION_OTHER_group", hasOther);
            CommonOpUtil.showHideLayoutGroup("cc_career_ladder_denied_note_group", false);
            setCompleteCaseAutoCompletion();
        }

        var _firstTimeRender = true;

        function getFinalActionControl(){
            return _CC_FINAL_ACTION_ac;
        }

        function render() {

            if (FormState.isDirty('GEN_CASE_TYPE') || FormState.isDirty('THRD_PRTY_APPEAL_TYPE')) {
                resetFinalAction(_firstTimeRender);
            }

            if(FormState.isDirty('CC_FINAL_ACTION_SEL')){
                console.log(FormState.getElementArrayValue('CC_FINAL_ACTION_SEL', []));
            }

            var hasNoActionTaken = false;
            var values = FormState.getElementArrayValue('CC_FINAL_ACTION_SEL', []);
            $.each(values, function (i, item) {
                if (item.value === 'No Action Taken') {
                    hasNoActionTaken = true;
                    return false;
                }
            });

            if (hasNoActionTaken) {
                getFinalActionControl().initializeItems([{value: 'No Action Taken', text: 'No Action Taken'}]);
                hyf.util.disableComponent('CC_FINAL_ACTION');
                CommonOpUtil.showHideLayoutGroup('cc_career_ladder_denied_note_group', false, false);
            } else {
                hyf.util.enableComponent('CC_FINAL_ACTION');

                var hasCLPD = false;
                var piActionType = FormState.getElementValue('PI_ACTION_TYPE','');
                if (piActionType === '1794'){ // Career Ladder Promotion Denial
                    $.each(values, function (i, item) {
                        if (item.value === 'Career Ladder Promotion Denied') {
                            hasCLPD = true;
                            return false;
                        }
                    });
                }
                CommonOpUtil.showHideLayoutGroup('cc_career_ladder_denied_note_group', hasCLPD, false);
            }

            _firstTimeRender = false;
        }


        function resetFinalAction(showPriorSelectedValue) {
            var optionLookupArray = [];
            var caseTypeState = FormState.getState('GEN_CASE_TYPE');
            if (typeof caseTypeState === 'undefined' || caseTypeState == null) return;
            var caseTypeTxt = caseTypeState.text;
            //FormState.updateObjectValue('CC_FINAL_ACTION_SEL',[]);
            if (caseTypeTxt === 'Third Party Hearing') {
                var appealType = FormState.getElementValue('THRD_PRTY_APPEAL_TYPE');
                if (_.isEmpty(appealType)) {
                    //TODO
                } else {
                    optionLookupArray = LookupManager.findByLTYPE('ERLRInitialResponseCaseType[' + caseTypeTxt + ']/ERLRCasesCompletedFinalAction[' + appealType + ']/ERLRCasesCompletedFinalAction');
                }
            } else {
                caseTypeTxt = caseTypeTxt.replace('/', '*/*'); // replace slash to distinguish literal from path separator in lookup manager
                optionLookupArray = LookupManager.findByLTYPE('ERLRInitialResponseCaseType[' + caseTypeTxt + ']/ERLRCasesCompletedFinalAction').sort(
				function(a,b){
					if(a.LABEL.toUpperCase() > b.LABEL.toUpperCase()) return 1;
					if(a.LABEL.toUpperCase() <  b.LABEL.toUpperCase()) return -1;
					if(a.LABEL.toUpperCase() == b.LABEL.toUpperCase()) return 0;
				});
            }

            if (typeof optionLookupArray === 'undefined' || optionLookupArray == null || !$.isArray(optionLookupArray)) return;

            var optionStr = "<option value selected>Select One</option>";
            for (var i = 0; i < optionLookupArray.length; i++) {
                optionStr += "<option value=\"" + optionLookupArray[i].NAME + "\">" + optionLookupArray[i].LABEL + "</option>";
            }
            $('#CC_FINAL_ACTION').find('option').remove().end().append(optionStr);

            if (!showPriorSelectedValue) {
                _CC_FINAL_ACTION_ac.initializeItems([]);
            }
        }

        function handleOtherFinalAction(values) {
            var hasOther = false;
            for (var i = 0; i < values.length; i++) {
                var item = values[i];
                if (item.value === 'Other') {
                    hasOther = true;
                    if (i < values.length - 1) {
                        values.splice(i, 1);
                        values.push(item);
                    }
                    break;
                }
            }
            CommonOpUtil.showHideLayoutGroup("CC_FINAL_ACTION_OTHER_group", hasOther);
        }

        function setCompleteCaseAutoCompletion() {
            var option = {
                id: 'CC_FINAL_ACTION',
                useAddButton: false,
                baseURL: '/bizflowwebmaker/StratCon_AUT',
                minSelectionCount: (FormMain.isCompleteCaseActivity()) ? 1 : 0,
                maxSelectionCount: 10,


                mapFunction: function (context) {
                },
                getSelectionLabel: function (item) {
                    return item?item.text:'';
                },
                getCandidateLabel: function (item) {
                    return item?item.value:'';
                },
                getItemID: function (item) {
                    return item?item.value:'';
                },
                setDataToForm: function (values) {
                    FormState.updateObjectValue('CC_FINAL_ACTION_SEL', values, false);
                    FormState.updateSelectValue('CC_FINAL_ACTION', '', '', true);
                    handleOtherFinalAction(values);
                },
                sortSelectedValues: function (values) {
                    var other = null;
                    for (var i = 0; i < values.length; i++) {
                        var item = values[i];
                        if (item.value === 'Other') {
                            other = item;
                            values.splice(i, 1);
                            break;
                        }
                    }

                    values.sort(function (a, b) {
                        var x = a.value.toLowerCase();
                        var y = b.value.toLowerCase();
                        if (x < y) {
                            return -1;
                        } else if (x > y) {
                            return 1;
                        } else {
                            return 0;
                        }
                    });

                    if (other !== null) {
                        values.push(item);
                    }

                    return values;
                },
                isValidListItem: function (item, target) {
                    return item.value !== "";
                },
                afterItemDisplayed: function (containerId, item) {
                    //$('#'+this.id)[0].selectedIndex = 0;
                },
                afterItemDeleted: function (containerId, targetId, item, values) {
                },
                initialItems: FormState.getElementArrayValue('CC_FINAL_ACTION_SEL', [])
            };

            _CC_FINAL_ACTION_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        return {
            init: init,
            render: render
        }
    }

    (window.cms_case_complete !== undefined ? window.cms_case_complete : (window.cms_case_complete = cms_case_complete()));
})(window)