'use strict';
(function (window) {
    var cms_erlr_career_ladder_promotion_denial = function () {

        var initialized = false;

        var dateFieldsPastPresent =
            [
                'CLPD_ENTRANCE_DUTY_DT',
                'CLPD_FIRST_WITHHELD_DT'
            ];

        var dateFieldsPresentFuture =
            [];

        var reqFieldForActivity =
            [
                {
                    actName: globalVars.actAll,
                    reqFieldIds:
                        []
                },
                {
                    actName: globalVars.actCaseCreation,
                    reqFieldIds:
                        []
                },
                {
                    actName: globalVars.actCaseComplete,
                    reqFieldIds:
                        [
                            'CLPD_ENTRANCE_DUTY_DT',
                            'CLPD_NEXT_CLP_DUE_DT',
                            'CLPD_PRE_WITHHELD',
                            'CLPD_FIRST_WNI_DT',
                            'CLPD_DAPI_DT',
                            'CLPD_FIRST_WITHHELD_DT',
                            'CLPD_SECOND_REVIEW_DT',
                            'CLPD_DETER_FAV',
                            'CLPD_EMP_GRIEVANCE',
                            'CLPD_EMP_APPEAL_DECISION',
                            'CLPD_SECOND_WNI_DT'
                        ]
                }
            ];

        function initVisibility() {
            controlFLRADocumentVisibility();
            controlHearingInfoVisibility();
            controlExceptionVisibility();
            controlExceptionDateVisibility();
        }

        function setSelectElemValue(selElem) {
            if (typeof selElem == 'undefined' || selElem == null
                || typeof selElem.id == 'undefined' || selElem.id == null
                || typeof selElem.options == 'undefined' || selElem.options == null) {
                return;
            }
            var selectedVal = selElem.options[selElem.options.selectedIndex].value;
            var selectedTxt = selElem.options[selElem.options.selectedIndex].text;
            FormState.updateSelectValue(selElem.id, selectedVal, selectedTxt);
        }

        function controlHearingInfoVisibility() {
            var elemVal = FormState.getElementValue('ULP_DISPOSITION_TYPE');
            CommonOpUtil.showHideLayoutGroup('ulp_hearing_info_layout_frame', (elemVal === 'Complaint'));
            CommonOpUtil.clearGroupContent('ulp_hearing_info_layout');
            CommonOpUtil.clearGroupContent('ulp_exception_layout');
        }

        function controlFLRADocumentVisibility() {
            var elemVal = FormState.getElementValue('ULP_FLRA_DOCUMENT_REUQESTED');
            CommonOpUtil.showHideLayoutGroup('ulp_flra_document_layout', (elemVal === 'Yes'));
            CommonOpUtil.clearGroupContent('ulp_flra_document_layout');
        }

        function controlExceptionDateVisibility() {
            var elemVal = FormState.getElementValue('ULP_EXCEPTION_FILED');
            CommonOpUtil.showHideLayoutGroup('ulp_exception_date_layout', (elemVal === 'Yes'));
            CommonOpUtil.clearGroupContent('ulp_exception_date_layout');
        }

        function controlExceptionVisibility() {
            var elemVal = FormState.getElementValue('ULP_DISPOSITION_TYPE');
            CommonOpUtil.showHideLayoutGroup('ulp_exception_layout', (elemVal === 'Complaint' || elemVal === 'Dismissal' || elemVal === 'Withdrawal'));
            CommonOpUtil.clearGroupContent('ulp_exception_layout');
        }

        function initEventHandlers() {
        }

        function setupCustomWidget() {
        }


        function init() {
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_career_ladder_promotion_denial::init START');

            //-----------------------------------
            // visibility configuration
            //-----------------------------------
            initVisibility();


            //-----------------------------------
            // validation configuration
            //-----------------------------------
            CommonOpUtil.setDateConstraintMaximumToday(dateFieldsPastPresent);
            CommonOpUtil.setDateConstraintMinimumToday(dateFieldsPresentFuture);
            CommonOpUtil.dynamicMandatory(reqFieldForActivity);


            //-----------------------------------
            // event handler configuration
            //-----------------------------------
            initEventHandlers();


            //-----------------------------------
            // custom ui element initialization
            //-----------------------------------
            setupCustomWidget();

            initialized = true;
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_career_ladder_promotion_denial::init END');
        }

        var firstRendering = true;
        function render() {
            var state = FormState.getState('CLPD_PRE_WITHHELD');
            if(_.isUndefined(state)) {
                CommonOpUtil.showHideLayoutGroup('CLPD_NO_PRE_WITHHELD_layout_group', false);
                CommonOpUtil.showHideLayoutGroup('CLPD_YES_PRE_WITHHELD_layout_group', false);
            }else if(state.dirty){
                var val = FormState.getElementBooleanValue('CLPD_PRE_WITHHELD');
                if(_.isUndefined(val)){
                    CommonOpUtil.showHideLayoutGroup('CLPD_NO_PRE_WITHHELD_layout_group', false);
                    CommonOpUtil.showHideLayoutGroup('CLPD_YES_PRE_WITHHELD_layout_group', false);
                }else if(val === true){
                    CommonOpUtil.showHideLayoutGroup('CLPD_NO_PRE_WITHHELD_layout_group', false);
                    CommonOpUtil.showHideLayoutGroup('CLPD_YES_PRE_WITHHELD_layout_group', true);
                }else{
                    CommonOpUtil.showHideLayoutGroup('CLPD_NO_PRE_WITHHELD_layout_group', true);
                    CommonOpUtil.showHideLayoutGroup('CLPD_YES_PRE_WITHHELD_layout_group', false);
                }
            }


            state = FormState.getState('CLPD_DETER_FAV');
            if(_.isUndefined(state)) {
                CommonOpUtil.showHideLayoutGroup('CLPD_NO_DETER_FAV_layout_group', false);
            }else if(state.dirty){
                var val = FormState.getElementBooleanValue('CLPD_DETER_FAV');
                if(_.isUndefined(val)){
                    CommonOpUtil.showHideLayoutGroup('CLPD_NO_DETER_FAV_layout_group', false);
                }else if(val === true){
                    CommonOpUtil.showHideLayoutGroup('CLPD_NO_DETER_FAV_layout_group', false);
                }else{
                    CommonOpUtil.showHideLayoutGroup('CLPD_NO_DETER_FAV_layout_group', true);
                }
            }

            if(FormState.getElementBooleanValue('CLPD_PRE_WITHHELD', true) === false
                || (FormState.getElementBooleanValue('CLPD_PRE_WITHHELD', true) === true && FormState.getElementBooleanValue('CLPD_DETER_FAV', true) === false)){
                CommonOpUtil.showHideLayoutGroup('CLPD_EMP_DECISION_layout_group', true);
            }else{
                CommonOpUtil.showHideLayoutGroup('CLPD_EMP_DECISION_layout_group', false);
            }

            state = FormState.getState('CLPD_EMP_GRIEVANCE');
            if(_.isUndefined(state)) {
                CommonOpUtil.showHideLayoutGroup('CLPD_TRIGGER_GRIEVANCE_layout_group', false);
            }else if(state.dirty){
                var val = FormState.getElementBooleanValue('CLPD_EMP_GRIEVANCE', false);
                if(val === true){
                    CommonOpUtil.showHideLayoutGroup('CLPD_TRIGGER_GRIEVANCE_layout_group', true);
                }else{
                    CommonOpUtil.showHideLayoutGroup('CLPD_TRIGGER_GRIEVANCE_layout_group', false);
                }
            }


        }

        return {
            initialized: initialized,
            render: render,
            init: init
        };
    };

    var _initializer = window.cms_erlr_career_ladder_promotion_denial || (window.cms_erlr_career_ladder_promotion_denial = cms_erlr_career_ladder_promotion_denial());
})(window);
