'use strict';
(function (window) {
    var cms_erlr_career_ladder_promotion_denial = function () {

        var initialized = false;

        var dateFieldsPastPresent =
            [
                'CLPD_ENTRANCE_DUTY_DT',
                'CLPD_FIRST_WNI_DT',
                'CLPD_FIRST_WITHHELD_DT',
                'CLPD_DECISION_ISSUED_DT',
                'CLPD_SECOND_WNI_DT'
            ];

        var initHiddenLayoutGroups = [
            'CLPD_NO_PRE_WITHHELD_layout_group',
            'CLPD_YES_PRE_WITHHELD_layout_group',
            'CLPD_FINAL_DECISION_layout_group',
            'CLPD_EMP_DECISION_layout_group','CLPD_NO_DETER_FAV_layout_group'
        ];

        var dateFieldsPresentFuture =
            [];

        var reqFieldForActivity =
            [
                {
                    actName: globalVars.actAll,
                    reqFieldIds:
                        []
                },
                {
                    actName: globalVars.actCaseCreation,
                    reqFieldIds:
                        []
                },
                {
                    actName: globalVars.actCaseComplete,
                    reqFieldIds:
                        [
                            'CLPD_ENTRANCE_DUTY_DT',
                            'CLPD_NEXT_CLP_DUE_DT',
                            'CLPD_PRE_WITHHELD',
                            'CLPD_FIRST_WNI_DT',
                            'CLPD_DAPI_DT',
                            'CLPD_FIRST_WITHHELD_DT',
                            'CLPD_FINAL_REVIEW_DT',
                            'CLPD_DETER_FAV',
                            'CLPD_EMP_GRIEVANCE',
                            'CLPD_EMP_APPEAL_DECISION',
                            'CLPD_SECOND_WNI_DT',
                            'CLPD_DECISION_ISSUED_DT',
                            'CLPD_DECIDING_OFFCL_SEARCH'
                        ]
                }
            ];


        function init() {
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_career_ladder_promotion_denial::init START');

            $.each(initHiddenLayoutGroups, function(i, v){
                CommonOpUtil.showHideLayoutGroup(v, false, false);
            });

            //-----------------------------------
            // validation configuration
            //-----------------------------------
            CommonOpUtil.setDateConstraintMaximumToday(dateFieldsPastPresent);
            CommonOpUtil.setDateConstraintMinimumToday(dateFieldsPresentFuture);
            CommonOpUtil.dynamicMandatory(reqFieldForActivity);
            FormAutoComplete.makeAutoCompletion(FormMain.getAutoCompleteOptionForEmployee('CLPD_DECIDING_OFFCL_SEARCH', 'CLPD_DECIDING_OFFCL'));

            initialized = true;
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_career_ladder_promotion_denial::init END');
        }

        var firstRendering = true;
        function render() {
            var state = FormState.getState('CLPD_PRE_WITHHELD');
            if(state && state.dirty){
                var val = FormState.getElementBooleanValue('CLPD_PRE_WITHHELD');
                if(_.isUndefined(val)){
                    CommonOpUtil.showHideLayoutGroup('CLPD_NO_PRE_WITHHELD_layout_group', false);
                    CommonOpUtil.showHideLayoutGroup('CLPD_YES_PRE_WITHHELD_layout_group', false);
                }else if(val === true){
                    CommonOpUtil.showHideLayoutGroup('CLPD_NO_PRE_WITHHELD_layout_group', false);
                    CommonOpUtil.showHideLayoutGroup('CLPD_YES_PRE_WITHHELD_layout_group', true);
                }else{
                    CommonOpUtil.showHideLayoutGroup('CLPD_NO_PRE_WITHHELD_layout_group', true);
                    CommonOpUtil.showHideLayoutGroup('CLPD_YES_PRE_WITHHELD_layout_group', false);
                }
            }


            state = FormState.getState('CLPD_DETER_FAV');
            if(state && state.dirty){
                var val = FormState.getElementBooleanValue('CLPD_DETER_FAV');
                if(_.isUndefined(val)){
                    CommonOpUtil.showHideLayoutGroup('CLPD_NO_DETER_FAV_layout_group', false);
                    CommonOpUtil.showHideLayoutGroup('CLPD_FINAL_DECISION_layout_group', false);
                }else if(val === true){
                    CommonOpUtil.showHideLayoutGroup('CLPD_NO_DETER_FAV_layout_group', false);
                    CommonOpUtil.showHideLayoutGroup('CLPD_FINAL_DECISION_layout_group', false);
                }else{
                    CommonOpUtil.showHideLayoutGroup('CLPD_NO_DETER_FAV_layout_group', true);
                    CommonOpUtil.showHideLayoutGroup('CLPD_FINAL_DECISION_layout_group', true);
                }
            }


            state = FormState.getState('CLPD_EMP_APPEAL_DECISION');
            if(state && state.dirty) {
                var appeal = FormState.getElementBooleanValue('CLPD_EMP_APPEAL_DECISION', false);

                if(appeal){
                    FormState.updateSelectValue('CLPD_EMP_GRIEVANCE', 'No', 'No', false);
                    $('#CLPD_EMP_GRIEVANCE').val('No');
                    hyf.validation.validateField('CLPD_EMP_GRIEVANCE');
                }
            }


            state = FormState.getState('CLPD_EMP_GRIEVANCE');
            if(state && state.dirty){
                var grievance = FormState.getElementBooleanValue('CLPD_EMP_GRIEVANCE', false);
                if (grievance) {
                    state.dirty = false;
                    FormState.updateSelectValue('CLPD_EMP_APPEAL_DECISION', 'No', 'No', true);
                    $('#CLPD_EMP_APPEAL_DECISION').val('No');
                    hyf.validation.validateField('CLPD_EMP_APPEAL_DECISION');
                }

                CommonOpUtil.showHideLayoutGroup('CLPD_TRIGGER_GRIEVANCE_layout_group', grievance);
            }

            // Employee Decision Group
            val = FormState.getElementBooleanValue('CLPD_PRE_WITHHELD');
            if(val === false){
                CommonOpUtil.showHideLayoutGroup('CLPD_EMP_DECISION_layout_group', true);
            }else{
                val = FormState.getElementBooleanValue('CLPD_DETER_FAV');
                if(_.isUndefined(val)){
                    CommonOpUtil.showHideLayoutGroup('CLPD_EMP_DECISION_layout_group', false);
                }else{
                    CommonOpUtil.showHideLayoutGroup('CLPD_EMP_DECISION_layout_group', true);
                }
            }

            state = FormState.getState('CLPD_ENTRANCE_DUTY_DT');
            if(state && state.dirty){
                var eod = FormState.getElementValue('CLPD_ENTRANCE_DUTY_DT');
                var nextDue = FormState.getElementValue('CLPD_NEXT_CLP_DUE_DT');
                if(_.isEmpty(nextDue)){
                    var eodDt = new Date(eod);
                    eodDt.setFullYear(eodDt.getFullYear()+1);
                    var nextDueDt = formatDate(eodDt, 'MM/dd/yyyy');
                    $('#CLPD_NEXT_CLP_DUE_DT').val(nextDueDt);
                    FormState.updateDateValue('CLPD_NEXT_CLP_DUE_DT', nextDueDt, false);
                    hyf.validation.validateField('CLPD_NEXT_CLP_DUE_DT');
                }
            }

            state = FormState.getState('CLPD_FIRST_WITHHELD_DT');
            if(state && state.dirty) {
                var dt = FormState.getElementValue('CLPD_FIRST_WITHHELD_DT');
                if(!_.isEmpty(dt)){
                    var minDate = new Date(dt);
                    minDate.setDate(minDate.getDate()-1);
                    var minDateStr = formatDate(minDate, 'MM/dd/yyyy');
                    hyf.calendar.setDateConstraint('CLPD_SECOND_WNI_DT', 'Minimum', minDateStr);
                }else{
                    hyf.calendar.setDateConstraint('CLPD_SECOND_WNI_DT', 'Minimum', '01/01/2000');
                }
            }

            var dt1 = FormState.getElementValue('CLPD_FIRST_WITHHELD_DT');
            var dt2 = FormState.getElementValue('CLPD_SECOND_WNI_DT');
            if (dt2 && dt1) {
                var m1 = new Date(dt1);
                var m2 = new Date(dt2);
                if (m2.getTime() < m1.getTime()) {
                    bootbox.alert({
                        message: 'Date Second Withholding Notice Issued must come after Date Career Ladder Promotion First Withheld.',
                        callback: function () {
                            $('#CLPD_SECOND_WNI_DT').val('');
                            FormState.updateDateValue('CLPD_SECOND_WNI_DT', '', false);
                        }
                    });
                }
            }



            var dt1 = FormState.getElementValue('CLPD_FIRST_WNI_DT');
            var dt2 = FormState.getElementValue('CLPD_DAPI_DT');
            if (dt2 && dt1) {
                var m1 = new Date(dt1);
                var m2 = new Date(dt2);
                if (m2.getTime() < m1.getTime()) {
                    bootbox.alert({
                        message: 'Date Developmental Assistance Plan Issued must come after Date First Withholding Notice Issued.',
                        callback: function () {
                            $('#CLPD_DAPI_DT').val('');
                            FormState.updateDateValue('CLPD_DAPI_DT', '', false);
                        }
                    });
                }
            }
        }

        return {
            initialized: initialized,
            render: render,
            init: init
        };
    };

    var _initializer = window.cms_erlr_career_ladder_promotion_denial || (window.cms_erlr_career_ladder_promotion_denial = cms_erlr_career_ladder_promotion_denial());
})(window);
