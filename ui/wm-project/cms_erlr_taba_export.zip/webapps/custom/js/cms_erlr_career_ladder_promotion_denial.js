'use strict';
(function (window) {
    var cms_erlr_career_ladder_promotion_denial = function () {

        var initialized = false;

        var dateFieldsPastPresent =
            [
                'CLPD_ENTRANCE_DUTY_DT',
                'CLPD_FIRST_WNI_DT',
                'CLPD_FIRST_WITHHELD_DT'
            ];

        var dateFieldsPresentFuture =
            [];

        var reqFieldForActivity =
            [
                {
                    actName: globalVars.actAll,
                    reqFieldIds:
                        []
                },
                {
                    actName: globalVars.actCaseCreation,
                    reqFieldIds:
                        []
                },
                {
                    actName: globalVars.actCaseComplete,
                    reqFieldIds:
                        [
                            'CLPD_ENTRANCE_DUTY_DT',
                            'CLPD_NEXT_CLP_DUE_DT',
                            'CLPD_PRE_WITHHELD',
                            'CLPD_FIRST_WNI_DT',
                            'CLPD_DAPI_DT',
                            'CLPD_FIRST_WITHHELD_DT',
                            'CLPD_SECOND_REVIEW_DT',
                            'CLPD_DETER_FAV',
                            'CLPD_EMP_GRIEVANCE',
                            'CLPD_EMP_APPEAL_DECISION',
                            'CLPD_SECOND_WNI_DT'
                        ]
                }
            ];


        function init() {
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_career_ladder_promotion_denial::init START');

            //-----------------------------------
            // validation configuration
            //-----------------------------------
            CommonOpUtil.setDateConstraintMaximumToday(dateFieldsPastPresent);
            CommonOpUtil.setDateConstraintMinimumToday(dateFieldsPresentFuture);
            CommonOpUtil.dynamicMandatory(reqFieldForActivity);

            initialized = true;
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_career_ladder_promotion_denial::init END');
        }

        var firstRendering = true;
        function render() {
            var state = FormState.getState('CLPD_PRE_WITHHELD');
            if(_.isUndefined(state)) {
                CommonOpUtil.showHideLayoutGroup('CLPD_NO_PRE_WITHHELD_layout_group', false);
                CommonOpUtil.showHideLayoutGroup('CLPD_YES_PRE_WITHHELD_layout_group', false);
            }else if(state.dirty){
                var val = FormState.getElementBooleanValue('CLPD_PRE_WITHHELD');
                if(_.isUndefined(val)){
                    CommonOpUtil.showHideLayoutGroup('CLPD_NO_PRE_WITHHELD_layout_group', false);
                    CommonOpUtil.showHideLayoutGroup('CLPD_YES_PRE_WITHHELD_layout_group', false);
                }else if(val === true){
                    CommonOpUtil.showHideLayoutGroup('CLPD_NO_PRE_WITHHELD_layout_group', false);
                    CommonOpUtil.showHideLayoutGroup('CLPD_YES_PRE_WITHHELD_layout_group', true);
                }else{
                    CommonOpUtil.showHideLayoutGroup('CLPD_NO_PRE_WITHHELD_layout_group', true);
                    CommonOpUtil.showHideLayoutGroup('CLPD_YES_PRE_WITHHELD_layout_group', false);
                }
            }


            state = FormState.getState('CLPD_DETER_FAV');
            if(_.isUndefined(state)) {
                CommonOpUtil.showHideLayoutGroup('CLPD_NO_DETER_FAV_layout_group', false);
            }else if(state.dirty){
                var val = FormState.getElementBooleanValue('CLPD_DETER_FAV');
                if(_.isUndefined(val)){
                    CommonOpUtil.showHideLayoutGroup('CLPD_NO_DETER_FAV_layout_group', false);
                }else if(val === true){
                    CommonOpUtil.showHideLayoutGroup('CLPD_NO_DETER_FAV_layout_group', false);
                }else{
                    CommonOpUtil.showHideLayoutGroup('CLPD_NO_DETER_FAV_layout_group', true);
                }
            }

            if(FormState.getElementBooleanValue('CLPD_PRE_WITHHELD', true) === false
                || (FormState.getElementBooleanValue('CLPD_PRE_WITHHELD', true) === true && FormState.getElementBooleanValue('CLPD_DETER_FAV', true) === false)){
                CommonOpUtil.showHideLayoutGroup('CLPD_EMP_DECISION_layout_group', true);
            }else{
                CommonOpUtil.showHideLayoutGroup('CLPD_EMP_DECISION_layout_group', false);
            }

            state = FormState.getState('CLPD_EMP_APPEAL_DECISION');
            if(!_.isUndefined(state) && state.dirty) {
                var appeal = FormState.getElementBooleanValue('CLPD_EMP_APPEAL_DECISION', false);

                if(appeal){
                    FormState.updateSelectValue('CLPD_EMP_GRIEVANCE', 'No', 'No', false);
                    $('#CLPD_EMP_GRIEVANCE').val('No');
                    hyf.validation.validateField('CLPD_EMP_GRIEVANCE');
                }
            }


            state = FormState.getState('CLPD_EMP_GRIEVANCE');
            if(_.isUndefined(state)) {
                CommonOpUtil.showHideLayoutGroup('CLPD_TRIGGER_GRIEVANCE_layout_group', false);
            }else if(state.dirty){
                var grievance = FormState.getElementBooleanValue('CLPD_EMP_GRIEVANCE', false);
                if (grievance) {
                    FormState.updateSelectValue('CLPD_EMP_APPEAL_DECISION', 'No', 'No', false);
                    $('#CLPD_EMP_APPEAL_DECISION').val('No');
                    hyf.validation.validateField('CLPD_EMP_APPEAL_DECISION');
                }

                CommonOpUtil.showHideLayoutGroup('CLPD_TRIGGER_GRIEVANCE_layout_group', grievance);
            }
        }

        return {
            initialized: initialized,
            render: render,
            init: init
        };
    };

    var _initializer = window.cms_erlr_career_ladder_promotion_denial || (window.cms_erlr_career_ladder_promotion_denial = cms_erlr_career_ladder_promotion_denial());
})(window);
