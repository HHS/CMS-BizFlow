var ConductIssue = {
    initialized: false,
    groups: [
        'action_AdministrativeLeave_group',
        'action_Reprimand_group',
        'action_Suspension_group',
        'suspension_oral_presentation_group',
        'oral_presentation_date_group',
        'written_response_group',
        'action_Demotion_group',
        'action_Counseling_group',
        'action_SickLeaveRestriction_group',
        'action_SickLeaveWarning_group',
        'action_Reassignment_group',
        'action_Removal_group',
        'suspension_written_response_group',
        'oral_presentation_date_group',
        'written_response_group',
        'removal_notice_date_group',
        'removal_oral_presentation_group',
        'removal_written_response_group',
        'suspension_oral_presentation_group',
        'suspension_written_response_group',
        'reassignment_date_notice_issued',
        'ci_final_decision_detail_by_agency',
        'ci_removal_final_decision_detail_by_agency',
        'ci_susp_final_decision_detail_by_agency'
    ],
    actionTypes: [
        'admin_leave',
        'alt_discipline',
        'removal_notice_date_group',
        'removal_oral_presentation_group',
        'removal_written_response_group'
    ],
    reqFieldForActivity:
        [
            {
                actName: globalVars.actAll,
                reqFieldIds:
                    []
            },
            {
                actName: globalVars.actCaseCreation,
                reqFieldIds:
                    []
            },
            {
                actName: globalVars.actCaseComplete,
                reqFieldIds:
                    [
                        'CI_ACTION_TYPE',
                        'CI_LEAVE_START_DT',
                        'CI_LEAVE_END_DT',
                        'CI_APPROVAL_NAME_SRCH',
                        'CI_LEAVE_START_DT_2',
                        'CI_LEAVE_END_DT_2',
                        'CI_APPROVAL_NAME_2_SRCH',
                        'CI_PROP_ACTION_ISSUED_DT',
                        'CI_ORAL_PREZ_REQUESTED',
                        'CI_ORAL_PREZ_DT',
                        'CI_ORAL_RESPONSE_SUBMITTED',
                        'CI_RESPONSE_DUE_DT',
                        'CI_WRITTEN_RESPONSE_SUBMITTED_DT',
                        'CI_PROPOSED_POS_TITLE',
                        'CI_PROPOSED_PPLAN',
                        'CI_PROPOSED_SERIES',
                        'CI_PROPOSED_INFO_GRADE',
                        'CI_PROPOSED_INFO_STEP',
                        'CI_DEMO_FINAL_AGENCY_DECISION',
                        'CI_DECIDING_OFFCL_SRCH',
                        'CI_DECISION_ISSUED_DT',
                        'CI_DEMO_FINAL_AGENCY_EFF_DT',
                        'CI_COUNSEL_TYPE',
                        'CI_COUNSEL_ISSUED_DT',
                        'CI_SICK_LEAVE_ISSUED_DT',
                        'CI_RESTRICTION_ISSED_DT',
                        'CI_SICK_LEAVE_REVIEWED_DT',
                        'CI_SL_WARNING_DISCUSSION_DT',
                        'CI_SL_WARN_ISSUE',
                        'CI_NOTICE_ISSUED_DT',
                        'CI_EFFECTIVE_DT',
                        'CI_REMOVAL_PROP_ACTION_DT',
                        'CI_EMP_NOTICE_LEAVE_PLACED',
                        'CI_REMOVAL_NOTICE_START_DT',
                        'CI_REMOVAL_NOTICE_END_DT',
                        'CI_REMOVAL_ORAL_PREZ_REQUESTED',
                        'CI_REMOVAL_ORAL_PREZ_DT',
                        'CI_REMOVAL_WRITTEN_RESPONSE',
                        'CI_WRITTEN_RESPONSE_DUE_DT',
                        'CI_WRITTEN_SUBMITTED_DT',
                        'CI_RMVL_FINAL_AGENCY_DECISION',
                        'CI_DECIDING_OFFCL_NAME_SRCH',
                        'CI_REMOVAL_DATE_DECISION_ISSUED',
                        'CI_REMOVAL_EFFECTIVE_DT',
                        'CI_SUSPENTION_TYPE',
                        'CI_SUSP_PROP_ACTION_DT',
                        'CI_SUSP_ORAL_PREZ_REQUESTED',
                        'CI_SUSP_ORAL_PREZ_DT',
                        'CI_SUSP_WRITTEN_RESP',
                        'CI_SUSP_WRITTEN_RESP_DUE_DT',
                        'CI_SUSP_WRITTEN_RESP_DT',
                        'CI_SUSP_FINAL_AGENCY_DECISION',
                        'CI_SUSP_DECIDING_OFFCL_NAME_SRCH',
                        'CI_SUSP_DECISION_ISSUED_DT',
                        'CI_SUSP_EFFECTIVE_DECISION_DT',
                        'CI_REPRIMAND_ISSUE_DT',
                        'CI_FINAL_POS_TITLE',
                        'CI_FINAL_PPLAN',
                        'CI_FINAL_SERIES',
                        'CI_FINAL_INFO_GRADE',
                        'CI_FINAL_INFO_STEP',
                        'CI_EMP_APPEAL_DECISION',
                        'CI_FINAL_ADMIN_CODE_SRCH',
						'CI_SUS_NUMB_DAYS',
						'CI_NUMB_DAYS',
						'CI_RMVL_NUMB_DAYS',
						'LN_LETTER_PROVIDED',
						'GI_STEP_2_REQUEST'
                    ]
            }
        ],
    CI_APPROVAL_NAME: null,
    CI_APPROVAL_NAME_2: null,
    CI_DECIDING_OFFCL: null,
    CI_SUSP_DECIDING_OFFCL_NAME: null,
    CI_TERM_DECIDING_OFFCL_NAME: null,
    CI_DECIDING_OFFCL_NAME: null,
    CI_adminLeave: false,
    CI_SICK_LEAVE_REVIEWED_DT_LIST_group: null,
    CI_SL_WARNING_DISCUSSION_DT_LIST_group: null,
    init: function () {
        ConductIssue.groups.forEach(function (el, index) {
            hyf.util.hideComponent(el);
        });
        ConductIssue.booleanCheckBox();
        clearData();
        //multi date selection
        $('#admin_leave_clear, #admin_leave_ntc_clear').on('click', clear);
		var adminLeaveMandatory = (ActivityManager.getActivityName() === globalVars.actCaseComplete);
        ConductIssue.CI_SICK_LEAVE_REVIEWED_DT_LIST_group = MultiDataSelectField.init({
            layoutGroupId: 'CI_SICK_LEAVE_REVIEWED_DT_LIST_group',
            mandatory: true,
            dataFieldId: 'CI_SICK_LEAVE_REVIEWED_DT_LIST',
            sort: {fieldId: 'CI_SICK_LEAVE_REVIEWED_DT', valueType: 'date', order: 'desc'},
            recordFields: ['CI_SICK_LEAVE_REVIEWED_DT', 'CI_SICK_LEAVE_REVIEWED_EXTENDED', 'CI_SICK_LEAVE_REVIEWED_EXTENDED_DT', 'CI_SICK_LEAVE_REVIEWED_REMOVED_DT'],
            outputRender: function (data, config) {
                if (0 < data.length) {
                    if (data[0].CI_SICK_LEAVE_REVIEWED_EXTENDED === 'Yes') {
                        hyf.util.showComponent('CI_SICK_LEAVE_REVIEWED_EXTENDED_DT_layout_group');
                        hyf.util.hideComponent('CI_SICK_LEAVE_REVIEWED_REMOVED_DT_layout_group');
                    } else {
                        hyf.util.hideComponent('CI_SICK_LEAVE_REVIEWED_EXTENDED_DT_layout_group');
                        hyf.util.showComponent('CI_SICK_LEAVE_REVIEWED_REMOVED_DT_layout_group');
                    }

                    var showAddButton = true;
                    $.each(data, function(i, v){
                        if(!_.isEmpty(v.CI_SICK_LEAVE_REVIEWED_REMOVED_DT)){
                            showAddButton = false;
                            return false;
                        }
                    });

                    if(showAddButton){
                        $('#CI_SICK_LEAVE_REVIEWED_DT_LIST_add_button').show();
                    }else{
                        $('#CI_SICK_LEAVE_REVIEWED_DT_LIST_add_button').hide();
                    }

                }
            },
            dialog: {
                input: {
                    init: function () {
						var container = $('#CI_SICK_LEAVE_REVIEWED_DT_LIST_input_dialog').parent().parent().parent();
						$('button.btn.btn-primary',container).prop('title','Click the add button to have the date reviewed and other information entered into the pop-up window to be added to the case. When you click this, you will be returned to the conduct issue tab.');
						$('button.btn.btn-default',container).prop('title','Click the cancel button to return to the conduct issue tab without saving a date that the sick leave restriction was reviewed and any other information entered into the pop-up window.');
                        hyf.util.hideComponent('_CI_SICK_LEAVE_REVIEWED_EXTENDED_DT_layout_group');
                        hyf.util.hideComponent('_CI_SICK_LEAVE_REVIEWED_REMOVED_DT_layout_group');

                        $('#_CI_SICK_LEAVE_REVIEWED_EXTENDED').on('change', function (e) {
                            if ($(this).val() === 'Yes') {
                                hyf.util.showComponent('_CI_SICK_LEAVE_REVIEWED_EXTENDED_DT_layout_group');
                                hyf.util.hideComponent('_CI_SICK_LEAVE_REVIEWED_REMOVED_DT_layout_group');
                            } else {
                                hyf.util.hideComponent('_CI_SICK_LEAVE_REVIEWED_EXTENDED_DT_layout_group');
                                hyf.util.showComponent('_CI_SICK_LEAVE_REVIEWED_REMOVED_DT_layout_group');
                            }
                        });
                    }
                },
                history: {
                    init: function () {

                    }
                }
            }
        });
        ConductIssue.CI_SL_WARNING_DISCUSSION_DT_LIST_group = MultiDataSelectField.init({
            layoutGroupId: 'CI_SL_WARNING_DISCUSSION_DT_LIST_group',
            mandatory: false,
            dataFieldId: 'CI_SL_WARNING_DISCUSSION_DT_LIST',
            sort: {fieldId: 'CI_SL_WARNING_DISCUSSION_DT', valueType: 'date', order: 'desc'},
            recordFields: ['CI_SL_WARNING_DISCUSSION_DT'],
			dialog :{
				input : {
					init : function(){
						var container = $('#CI_SL_WARNING_DISCUSSION_DT_LIST_input_dialog').parent().parent().parent();
						$('button.btn.btn-primary',container).prop('title','Click the add button to have the date when the manager discussed the sick leave warning with the employee entered into the pop-up window to be added to the case. When you click this, you will be returned to the conduct issue tab.');
						$('button.btn.btn-default',container).prop('title','Click the cancel button to return to the conduct issue tab without saving a date when the manager discussed the sick leave warning with the employee.');
					}
				}
			}
        });

        initLeaveBusinessDays();
        initAdminLeaveDynamic();

        $('#conduct_issue_layout select').on('change', helperEventHandler);
       // $('#CI_SUSP_PROP_ACTION_DT, #CI_REMOVAL_PROP_ACTION_DT, #CI_DECISION_ISSUED_DT,#CI_PROP_ACTION_ISSUED_DT').on('change', dateChangeEventConduct);
        $('#CI_PROPOSED_PPLAN,#CI_FINAL_PPLAN').on('change', populateGrades);
        $('#CI_LEAVE_START_DT,#CI_LEAVE_END_DT,#CI_LEAVE_START_DT_2,#CI_LEAVE_END_DT_2').on('change', dateValidate);

        $('#CI_RMVL_FINAL_AGENCY_DECISION,#CI_DEMO_FINAL_AGENCY_DECISION,#CI_SUSP_FINAL_AGENCY_DECISION').on('change', finalAgencyDecision);

        $('#CI_ADMIN_NOTICE_LEAVE, #CI_ADMIN_INVESTIGATORY_LEAVE').on('click', function (e) {
            var val = $(this).prop('checked');
            if (e.target.id === 'CI_ADMIN_INVESTIGATORY_LEAVE') {
                $('#admin_leave_investigatory_group input[type="text"]').val('');
                $('#leave_length').text('');
                if (val) {
                    hyf.util.showComponent('admin_leave_investigatory_group');
                }
                else {
                    hyf.util.hideComponent('admin_leave_investigatory_group');
                }
            }
            if (e.target.id === 'CI_ADMIN_NOTICE_LEAVE') {
                $('#admin_leave_notice_group input[type="text"]').val('');
                $('#leave_length_2').text('');
                if (val) {
                    hyf.util.showComponent('admin_leave_notice_group');
                }
                else {
                    hyf.util.hideComponent('admin_leave_notice_group');
                }
            }
        });
        CommonOpUtil.setDateConstraintMaximumToday(ConductIssue.dateFields);
        ConductIssue.CI_APPROVAL_NAME = conductAutoCompleteOptions('CI_APPROVAL_NAME');
        ConductIssue.CI_APPROVAL_NAME_2 = conductAutoCompleteOptions('CI_APPROVAL_NAME_2');
        ConductIssue.CI_DECIDING_OFFCL = conductAutoCompleteOptions('CI_DECIDING_OFFCL');
        ConductIssue.CI_SUSP_DECIDING_OFFCL_NAME = conductAutoCompleteOptions('CI_SUSP_DECIDING_OFFCL_NAME');
        ConductIssue.CI_DECIDING_OFFCL_NAME = conductAutoCompleteOptions('CI_DECIDING_OFFCL_NAME');
        ConductIssue.reAssignmentAdminCode = conductAdminCodeAutoCompleteOptions('CI_FINAL_ADMIN_CODE');
        populateCIReassignCurInfo();
        populateReassignFinAdminCdDesc();
        CommonOpUtil.dynamicMandatory(ConductIssue.reqFieldForActivity);

        //var name = FormState.getElementValue('CI_REASGN_FIN_ORG_NM');
        //CommonOpUtil.showHideLayoutGroup('ci_reassignment_final_org_name_group', !_.isEmpty(name));

        var actionType = FormState.getElementValue('CI_ACTION_TYPE');
        if (actionType === 'Demotion' || actionType === 'Suspension' ||
            actionType === 'Removal' || actionType === 'Reassignment' || actionType === 'Reprimand') {
            hyf.util.showComponent('emp_appeal_decision_group');
        } else {
            hyf.util.hideComponent('emp_appeal_decision_group');
        }

        populateCIDemotionCurPosnData();
        //hyf.util.setMandatoryConstraint('CI_ADMIN_INVESTIGATORY_LEAVE', f);
        //hyf.util.setMandatoryConstraint('CI_ADMIN_NOTICE_LEAVE', false);
        $('#CI_ADMIN_INVESTIGATORY_LEAVE,#CI_ADMIN_NOTICE_LEAVE').attr('_required', 'true');

        var payPlan = FormState.getElementValue('CI_PROPOSED_PPLAN');
        if(_.isEmpty(payPlan)){
            CommonOpUtil.showHideLayoutGroup('CI_PROPOSED_INFO_STEP', false);
            CommonOpUtil.showHideLayoutGroup('CI_PROPOSED_INFO_GRADE', false);
        }else{
            populateGradesByPayPlan('CI_PROPOSED_INFO_GRADE', payPlan);
        }

        payPlan = FormState.getElementValue('CI_FINAL_PPLAN');
        if(_.isEmpty(payPlan)){
            CommonOpUtil.showHideLayoutGroup('CI_FINAL_INFO_STEP', false);
            CommonOpUtil.showHideLayoutGroup('CI_FINAL_INFO_GRADE', false);
        }else{
            populateGradesByPayPlan('CI_FINAL_INFO_GRADE', payPlan);
        }
		if(adminLeaveMandatory){
			hyf.util.showComponent('CI_ADMIN_LEAVE_LABEL');
		}else{
			hyf.util.hideComponent('CI_ADMIN_LEAVE_LABEL');
		}
    },
    dateFields: [
        'CI_PROP_ACTION_ISSUED_DT',
        'CI_ORAL_PREZ_DT',
        'CI_WRITTEN_RESPONSE_SUBMITTED_DT',
        'CI_DECISION_ISSUED_DT',
        'CI_COUNSEL_ISSUED_DT',
        'CI_SICK_LEAVE_ISSUED_DT',
        'CI_RESTRICTION_ISSED_DT',
        'CI_SICK_LEAVE_REVIEWED_DT',
        'CI_SL_WARNING_DISCUSSION_DT',
        'CI_SL_WARN_ISSUE',
        'CI_NOTICE_ISSUED_DT',
        'CI_REMOVAL_PROP_ACTION_DT',
        'CI_REMOVAL_ORAL_PREZ_DT',
        'CI_WRITTEN_SUBMITTED_DT',
        'CI_DECIDING_OFFCL_NAME',
        'CI_SUSP_PROP_ACTION_DT',
        'CI_SUSP_ORAL_PREZ_DT',
        'CI_SUSP_WRITTEN_RESP_DT',
        'CI_SUSP_DECISION_ISSUED_DT',    
        'CI_REPRIMAND_ISSUE_DT',
        '_CI_SL_WARNING_DISCUSSION_DT',
        '_CI_SICK_LEAVE_REVIEWED_DT',
        'CI_REMOVAL_DATE_DECISION_ISSUED'
    ],
    inputEvents: {
        /*I intend to have a list of dropdowns and their corresponding event hanlder helper functions, so that I can access the reference to the function, then call it
        like dropdownTargets[event.target.id](),where event target id corresponds to the obj key*/

        'CI_ACTION_TYPE': actionTypeEvent,
        'CI_PROP_ACTION_ISSUED': {action: hyfToogle, target: ''}
        },
    booleanCheckBox: function () {
        $('#CI_ADMIN_INVESTIGATORY_LEAVE,#CI_ADMIN_NOTICE_LEAVE').click(function () {
            if ($(this).prop("checked") == true && $(this)[0].id === 'CI_ADMIN_INVESTIGATORY_LEAVE') {
                $('#CI_ADMIN_NOTICE_LEAVE').removeAttr('_required');
            }
            else if ($(this).prop("checked") == true && $(this)[0].id === 'CI_ADMIN_NOTICE_LEAVE') {
                $('#CI_ADMIN_INVESTIGATORY_LEAVE').removeAttr('_required');
            }
            else if ($('#CI_ADMIN_INVESTIGATORY_LEAVE,#CI_ADMIN_NOTICE_LEAVE').prop('checked') === 'false') {
                $('#CI_ADMIN_INVESTIGATORY_LEAVE,#CI_ADMIN_NOTICE_LEAVE').attr('_required', 'true');
            }
        });
    },
    render: function () {
        var actionType = FormState.getState('CI_ACTION_TYPE');
        if (actionType && actionType.dirty) {
            ConductIssue.showCaseView('action_' + actionType.value.replace(/\s/g, '') + '_group', ConductIssue.groups);
        }
		if ((actionType && actionType.dirty) && actionType.value ==='Demotion') {
			populateCIDemotionCurPosnData();
        }
		if ((actionType && actionType.dirty) && actionType.value ==='Reassignment') {
			populateCIReassignCurInfo();
        }
        var suspFinalAgency = FormState.getElementValue('CI_SUSP_FINAL_AGENCY_DECISION');
        var rmvlFinalAgency = FormState.getElementValue('CI_RMVL_FINAL_AGENCY_DECISION');
        var dmnpFinalAgency = FormState.getElementValue('CI_DEMO_FINAL_AGENCY_DECISION');
        initAdminLeaveDynamic();
        if (suspFinalAgency != undefined) {
            finalAgencyDecisionHelper('CI_SUSP_FINAL_AGENCY_DECISION', suspFinalAgency);
        }
        if (rmvlFinalAgency != undefined) {
            finalAgencyDecisionHelper('CI_RMVL_FINAL_AGENCY_DECISION', rmvlFinalAgency);
        }
        if (dmnpFinalAgency != undefined) {
            finalAgencyDecisionHelper('CI_DEMO_FINAL_AGENCY_DECISION', dmnpFinalAgency);
        }


        if(FormState.isDirty('CI_EMP_NOTICE_LEAVE_PLACED')){
            CommonOpUtil.showHideLayoutGroup('removal_notice_date_group', FormState.getElementBooleanValue('CI_EMP_NOTICE_LEAVE_PLACED'));
        }
        if(FormState.isDirty('CI_ORAL_RESPONSE_SUBMITTED')){
            CommonOpUtil.showHideLayoutGroup('written_response_group', FormState.getElementBooleanValue('CI_ORAL_RESPONSE_SUBMITTED'));
        }

        if(FormState.isDirty('CI_ORAL_PREZ_REQUESTED')){
            CommonOpUtil.showHideLayoutGroup('oral_presentation_date_group', FormState.getElementBooleanValue('CI_ORAL_PREZ_REQUESTED'));
        }

        if(FormState.isDirty('CI_REMOVAL_ORAL_PREZ_REQUESTED')){
            CommonOpUtil.showHideLayoutGroup('removal_oral_presentation_group', FormState.getElementBooleanValue('CI_REMOVAL_ORAL_PREZ_REQUESTED'));
        }
        if(FormState.isDirty('CI_REMOVAL_WRITTEN_RESPONSE')){
            CommonOpUtil.showHideLayoutGroup('removal_written_response_group', FormState.getElementBooleanValue('CI_REMOVAL_WRITTEN_RESPONSE'));
        }
        if(FormState.isDirty('CI_SUSP_ORAL_PREZ_REQUESTED')){
            CommonOpUtil.showHideLayoutGroup('suspension_oral_presentation_group', FormState.getElementBooleanValue('CI_SUSP_ORAL_PREZ_REQUESTED'));
        }
        if(FormState.isDirty('CI_SUSP_WRITTEN_RESP')){
            CommonOpUtil.showHideLayoutGroup('suspension_written_response_group', FormState.getElementBooleanValue('CI_SUSP_WRITTEN_RESP'));
        }


        if (actionType && (actionType.value === 'Demotion' || actionType.value === 'Suspension' ||
            actionType.value === 'Removal' || actionType.value === 'Reassignment' || actionType.value === 'Reprimand')) {
            hyf.util.showComponent('emp_appeal_decision_group');
        } else {
            hyf.util.hideComponent('emp_appeal_decision_group');
        }
        ConductIssue.CI_SICK_LEAVE_REVIEWED_DT_LIST_group.render();
        ConductIssue.CI_SL_WARNING_DISCUSSION_DT_LIST_group.render();

        var genEmployeeFormState = FormState.getState('GEN_EMPLOYEE');
        if (genEmployeeFormState && genEmployeeFormState.dirty) {
            populateCIReassignCurInfo();
            populateCIDemotionCurPosnData();
        }
		initLeaveBusinessDays();
    },
    populateOfficial: function (item, id) {
        if (id === 'CI_APPROVAL_NAME' && (item.last_name !== '' || item.first_name !== '')) {
            $('#CI_APPROVAL_NAME').val(item.last_name + ',' + item.first_name + '(' + item.email + ')');
        }
        if (id === 'CI_APPROVAL_NAME_2' && item.value !== '') {
            $('#CI_APPROVAL_NAME_2').val(item.last_name + ',' + item.first_name + '(' + item.email + ')');
        }
        if (id === 'CI_APPROVAL_NAME' && item.value !== '') {
            $('#CI_APPROVAL_NAME').val(item.last_name + ',' + item.first_name + '(' + item.email + ')');
        }

        if (id === 'CI_SUSP_DECIDING_OFFCL_NAME' && item.value !== '') {
            $('#CI_SUSP_DECIDING_OFFCL_NAME').val(item.last_name + ',' + item.first_name + '(' + item.email + ')');
        }
        if (id === 'CI_DECIDING_OFFCL' && item.value !== '') {
            $('#CI_DECIDING_OFFCL').val(item.last_name + ',' + item.first_name + '(' + item.email + ')');
        }
        if (id === 'CI_DECIDING_OFFCL_NAME' && item.value !== '') {
            $('#CI_DECIDING_OFFCL_NAME').val(item.last_name + ',' + item.first_name + '(' + item.email + ')');
        }
    },
    showCaseView: function (caseValue, arr) {
        arr.forEach(function (el, index) {
            CommonOpUtil.showHideLayoutGroup(el, el === caseValue);
        });
    }

};

function initAdminLeaveDynamic() {
    if ($('#CI_ADMIN_INVESTIGATORY_LEAVE').prop('checked')){
        hyf.util.showComponent('admin_leave_investigatory_group');
    } else {
        hyf.util.hideComponent('admin_leave_investigatory_group');
    }
    if ($('#CI_ADMIN_NOTICE_LEAVE').prop('checked')) {
        hyf.util.showComponent('admin_leave_notice_group');
    } else {
        hyf.util.hideComponent('admin_leave_notice_group');
    }
}
//helper function for business day format.
	function dateFormat(dt){
		if(dt && dt !==''){
			dt = dt.split('/');
			return dt[2] + '-' + dt[0] + '-' + dt[1];
		}	
	}
function initLeaveBusinessDays() {
		var InvLeaveStartDate = '';
		var InvLeaveEndDate = '';
		var ntcLeaveStartDate = '';
		var ntcLeaveEndDate = '';
    try {
        InvLeaveStartDate = dateFormat(FormState.getElementValue('CI_LEAVE_START_DT'));
        InvLeaveEndDate = dateFormat(FormState.getElementValue('CI_LEAVE_END_DT'));
        ntcLeaveStartDate =dateFormat(FormState.getElementValue('CI_LEAVE_START_DT_2'));
        ntcLeaveEndDate = dateFormat(FormState.getElementValue('CI_LEAVE_END_DT_2'));
		
		// TODO: remove dialog then set restriction to start date
		if ((InvLeaveStartDate != '' && InvLeaveEndDate != '')) {
			CommonOpUtil.getBusinessDaysCount(InvLeaveStartDate, InvLeaveEndDate, inventoryBusinessDays, 'CI_LEAVE_END_DT');
		}
		if ((ntcLeaveStartDate != '' && ntcLeaveEndDate != '')) {
			CommonOpUtil.getBusinessDaysCount(ntcLeaveStartDate, ntcLeaveEndDate, noticeBusinessDays, 'CI_LEAVE_END_DT_2');
		}
    } catch (e) {

    }
    
}

function dateValidate(e) {
    var days = 0;
    var dt1 = '';
    var dt2 = '';
    if (e == undefined) {
        return;
    }
    if (e.target.id === 'CI_LEAVE_START_DT' || e.target.id === 'CI_LEAVE_START_DT_2' || e.target.id === 'CI_LEAVE_END_DT' || e.target.id === 'CI_LEAVE_END_DT_2') {
        if (e.target.id === 'CI_LEAVE_START_DT' || e.target.id === 'CI_LEAVE_END_DT') {
            dt1 = dateFormat($('#CI_LEAVE_START_DT').val());
            dt2 = dateFormat($('#CI_LEAVE_END_DT').val());
        } else if (e.target.id === 'CI_LEAVE_START_DT_2' || e.target.id === 'CI_LEAVE_END_DT_2') {
            dt1 = dateFormat($('#CI_LEAVE_START_DT_2').val());
            dt2 = dateFormat($('#CI_LEAVE_END_DT_2').val());
        }
    }
  
    if (e.target.id === 'CI_LEAVE_START_DT' || e.target.id === 'CI_LEAVE_END_DT') {
        if (dt2 !== '' && dt1 !== '') {
            CommonOpUtil.getBusinessDaysCount(dt1, dt2, inventoryBusinessDays, e.target.id);
        } else {
            inventoryBusinessDays([-1]);
        }
    } else if (e.target.id === 'CI_LEAVE_START_DT_2' || e.target.id === 'CI_LEAVE_END_DT_2') {
        if (dt2 !== '' && dt1 !== '') {
            CommonOpUtil.getBusinessDaysCount(dt1, dt2, noticeBusinessDays, e.target.id);
        } else {
            noticeBusinessDays([-1]);
        }
    }
}

function conductAutoCompleteOptions(id) {
    return FormAutoComplete.makeAutoCompletion(FormMain.getAutoCompleteOptionForEmployee(id+'_SRCH', id));
}

function conductAdminCodeAutoCompleteOptions(id) {
    var optionConfig = {
        id: id + '_SRCH',
        baseURL: '/bizflowwebmaker/StratCon_AUT',
        targetURL: '/bizflowwebmaker/StratCon_AUT/SearchAdmOffOrg.do?searchAdmOff=',
        minLength: 2,
        minSelectionCount: 0,
        maxSelectionCount: 1,
        mapFunction: function (context) {
            return {
                id: $("AC_ADMIN_CD", context).text(),
                adminCd: $("AC_ADMIN_CD", context).text(),
                adminCdDesc: $("AC_ADMIN_CD_DESCR", context).text(),
                value:$("AC_ADMIN_CD", context).text()
            };
        },
        getSelectionLabel: function (item) {
            return item.adminCd;
        },
        getCandidateLabel: function (item) {
            return item.adminCd + ' - ' + item.adminCdDesc;// + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '');
        },
        getItemID: function (item) {
            return item.adminCd;
        },
        setDataToForm: function (values) {
            if (typeof values == 'undefined' || values == null) return;
            var item = null;
            if ($.isArray(values)) {
                item = values[0];
            } else {
                item = values;
            }
            if (typeof item === 'object' && item != null
                && typeof item.adminCd != 'undefined' && item.adminCd != null && item.adminCd.trim().length > 0
                && typeof item.adminCdDesc != 'undefined' && item.adminCdDesc != null && item.adminCdDesc.trim().length > 0) {
                //CommonOpUtil.showHideLayoutGroup('ci_reassignment_final_org_name_group', true);
                $('#CI_RE_ASSIGNMENT_FINAL_ORG').text(item.adminCdDesc);
                FormState.updateObjectValue('CI_FINAL_ADMIN_CODE', values,false);
                FormState.updateVariableValue('CI_RE_ASSIGNMENT_FINAL_ORG', item.adminCdDesc, true);
            } else {
                //CommonOpUtil.showHideLayoutGroup('ci_reassignment_final_org_name_group',false);
                $('#CI_RE_ASSIGNMENT_FINAL_ORG').text('');
                FormState.updateObjectValue('CI_FINAL_ADMIN_CODE', [],false);
                FormState.updateVariableValue('CI_RE_ASSIGNMENT_FINAL_ORG', '', true);
            }
        },
        // initialize
        initialItems: FormState.getElementArrayValue(id, []),
    };
    return FormAutoComplete.makeAutoCompletion(optionConfig);
}

function clearData() {
    var caseType;
    try {
        caseType = FormState.getState('GEN_CASE_TYPE');
        if (caseType.value.replace(/\s/g, '') !== 'ConductIssue') {
            $('#conduct_issue_layout input[type!="button"]').val('');
            $('#conduct_issue_layout input[type=checkbox]').prop('checked', false);
            $('#conduct_issue_layout select').val('');
            $('#conduct_issue_layout input').each(function (field) {
                FormState.updateObjectValue(field.id, '');
            });
            $('#conduct_issue_layout select').each(function (field) {
                FormState.updateObjectValue(field.id, '');
            });
        }
    } catch (err) {

    }
}

function actionTypeEvent(actionValue, value2) {
    var actions = ['Demotion', 'Suspension', 'Removal', 'Reassignment', 'Reprimand'];
    var inputs = [];
    var inputSelect = [];
    if (value2 && value2 !== undefined) {
        ConductIssue.showCaseView('action_' + value2.replace(/\s/g, '') + '_group', ConductIssue.groups);
        $('#CI_EMP_APPEAL_DECISION').val('');
        FormState.updateObjectValue('CI_EMP_APPEAL_DECISION', '');
        if (value2 !== '' && actions.includes(value2)) {
            hyf.util.showComponent('emp_appeal_decision_group');
        } else {
            hyf.util.hideComponent('emp_appeal_decision_group');
        }
        $('#conduct_issue_layout input[type!="button"]').val('');
        $('#conduct_issue_layout input[type="checkbox"]').prop('checked', false);
        $('#conduct_issue_layout select[id!="CI_ACTION_TYPE"]').val('');
        inputs = $('#conduct_issue_layout input');
        inputSelect = $('#conduct_issue_layout select');
        for (let field in inputs) {
            if (inputs[field].id !== '' && ConductIssue.reqFieldForActivity[2].reqFieldIds.indexOf(inputs[field].id) > -1) {
                FormState.updateObjectValue(inputs[field].id, '');
            }
        }
        for (let select in inputSelect) {
            if (inputSelect[select].id !== '' && ConductIssue.reqFieldForActivity[2].reqFieldIds.indexOf(inputSelect[select].id) >= -1) {
                FormState.updateObjectValue(inputSelect[select].id, '');
            }
        }
        if (typeof ConductIssue.CI_APPROVAL_NAME !== 'undefined' && ConductIssue.CI_APPROVAL_NAME != null) {
            ConductIssue.CI_APPROVAL_NAME.initializeItems([]);
        }
        if (typeof ConductIssue.CI_APPROVAL_NAME_2 !== 'undefined' && ConductIssue.CI_APPROVAL_NAME_2 != null) {
            ConductIssue.CI_APPROVAL_NAME_2.initializeItems([]);
        }
        if (typeof ConductIssue.CI_DECIDING_OFFCL !== 'undefined' && ConductIssue.CI_DECIDING_OFFCL != null) {
            ConductIssue.CI_DECIDING_OFFCL.initializeItems([]);
        }
        if (typeof ConductIssue.CI_DECIDING_OFFCL_NAME !== 'undefined' && ConductIssue.CI_DECIDING_OFFCL_NAME != null) {
            ConductIssue.CI_DECIDING_OFFCL_NAME.initializeItems([]);

        }

    }
}

function dateDecisionIssued(e){
    var days = 0;
    var dt1 = $('#CI_PROPOSE_ACTION_ISSUED_DT').val();
    var dt2 = $('#CI_DECISION_ISSUED_DT').val();
    if (dt2 && dt1) {
        var m1 = new Date(dt1);
        var m2 = new Date(dt2);
        if (m2.getTime() < m1.getTime()) {
            bootbox.alert({
                message: 'Date must be greater than Date Proposed Action Issued to Employee Date.',
                callback: function () {
                    $('#CI_DECISION_ISSUED_DT').val('');
                    FormState.updateObjectValue('CI_DECISION_ISSUED_DT', '');
                }
            });
        }
    }
}

function helperEventHandler(e) {
    var target;
    var dropdownAction;
    try {
        target = e.target;
        dropdownAction = target.options[target.options.selectedIndex].value;
        FormState.updateObjectValue(target.id, dropdownAction);
        dropdownCallBack(target.id, dropdownAction);
    } catch (err) {

    }

}

function hyfToogle(val, id) {
    CommonOpUtil.showHideLayoutGroup(id, val === 'Yes');
    //CommonOpUtil.hyfShowOrHide({value: val}, id);
}

function dropdownCallBack(dropdownId, value) {
    if (typeof dropdownId !== 'undefined') {
        if (ConductIssue.inputEvents[dropdownId] !== 'undefined' && typeof ConductIssue.inputEvents[dropdownId] === 'function') {
            ConductIssue.inputEvents[dropdownId](dropdownId, value);
        }
        else if (typeof ConductIssue.inputEvents[dropdownId] === 'object' && ConductIssue.inputEvents[dropdownId].action !== 'undefined') {
            var target = ConductIssue.inputEvents[dropdownId].target;
            ConductIssue.inputEvents[dropdownId].action(value, target);
        }
    }
}

function inventoryBusinessDays(days, callbackTargetElementId) {
    if (days != null && days[0] >= 0) {
        $('#leave_length').text(days[0] + ' Day(s)');
    }
    else {
        if(days == null) {
            bootbox.alert({
                message: 'Invalid Leave Start Date or Leave End Date. Leave end date must come after start date.',
                callback: function () {
                    setTimeout(function(){$('#' + callbackTargetElementId).val('').focus();},1);
                }
            });
        }
        $('#leave_length').text('');
    }
}

function noticeBusinessDays(days, callbackTargetElementId) {
    if (days != null && days[0] >= 0) {
        $('#leave_length_2').text(days[0] + ' Day(s)');
    }
    else {
        if(days == null){
            bootbox.alert({
                message: 'Invalid Leave Start Date or Leave End Date. Leave end date must come after start date.',
                callback: function(){
                    setTimeout(function(){$('#' + callbackTargetElementId).val('').focus();},1);
                }
            });
        }

        $('#leave_length_2').text('');
    }
}

function clear(item) {
    if (item.target.id === 'admin_leave_clear') {
        $('#CI_APPROVAL_NAME').val('');
    }
    if (item.target.id === 'admin_leave_ntc_clear') {
        $('#CI_APPROVAL_NAME_2').val('');
    }
    if (item.target.id !== '' && item !== '') {
        $('#' + item).val('');
    }
}


function populateCIReassignCurInfo() {
    var genEmployee = FormState.getElementJSONValue('GEN_EMPLOYEE');
    if (typeof genEmployee === 'undefined'){
        $('#CI_CURRENT_ADMIN_CODE').text('');
        $('#CI_RE_ASSIGNMENT_CURR_ORG').text('');
        FormState.updateTextValue('CI_CURRENT_ADMIN_CODE', '', false);
        FormState.updateTextValue('CI_RE_ASSIGNMENT_CURR_ORG', '', false);
    }else{
        $('#CI_CURRENT_ADMIN_CODE').text(genEmployee.adminCode);
        $('#CI_RE_ASSIGNMENT_CURR_ORG').text(genEmployee.adminCodeDesc);
        FormState.updateTextValue('CI_CURRENT_ADMIN_CODE', genEmployee.adminCode, false);
        FormState.updateTextValue('CI_RE_ASSIGNMENT_CURR_ORG', genEmployee.adminCodeDesc, false);
    }
}

function populateReassignFinAdminCdDesc() {
    var item = FormState.getElementSingleValue('CI_FINAL_ADMIN_CODE');
    if (typeof item !== 'object' || item == null
        || typeof item.adminCdDesc == 'undefined' || item.adminCdDesc == null) {
        return;
    }
    $('#CI_RE_ASSIGNMENT_FINAL_ORG').text(item.adminCdDesc);
    FormState.updateTextValue('CI_RE_ASSIGNMENT_FINAL_ORG', item.adminCdDesc, false);
}

function populateGrades(e) {
    var source = e.target.id;
    var target = '';
    var payPlan = e.target.options[e.target.options.selectedIndex].value;

    if (source === 'CI_PROPOSED_PPLAN') {
        target = 'CI_PROPOSED_INFO_GRADE';
    } else {
        target = 'CI_FINAL_INFO_GRADE';
    }

    populateGradesByPayPlan(target, payPlan);
}

function populateGradesByPayPlan(target, payPlan) {
    var showGradeStepField = false;
    $('#' + target).html('');
    if (payPlan !== 'default' && PayPlanGrade[payPlan] !== undefined) {
        $('#' + target).append('<option value="default">Select one </option>');
        PayPlanGrade[payPlan].forEach(function (val) {
            $('#' + target).append('<option value="' + val + '">' + val + '</option>');
        });

        CommonOpUtil.showHideLayoutGroup(target, true);
        showGradeStepField = true;
    } else {
        CommonOpUtil.showHideLayoutGroup(target, false, false);
    }

    if(target === 'CI_PROPOSED_INFO_GRADE'){
        CommonOpUtil.showHideLayoutGroup('CI_PROPOSED_INFO_STEP', showGradeStepField);
        CommonOpUtil.showHideLayoutGroup('CI_PROPOSED_INFO_GRADE', showGradeStepField);
    }else if(target === 'CI_FINAL_INFO_GRADE'){
        CommonOpUtil.showHideLayoutGroup('CI_FINAL_INFO_STEP', showGradeStepField);
        CommonOpUtil.showHideLayoutGroup('CI_FINAL_INFO_GRADE', showGradeStepField);
    }
}

function populateCIDemotionCurPosnData() {
    var genEmployee = FormState.getElementJSONValue('GEN_EMPLOYEE');
    if (typeof genEmployee === 'undefined'){
        $('#CI_POS_TITLE').text('');
        $('#CI_PPLAN').text('');
        $('#CI_SERIES').text('');
        $('#CI_CURRENT_INFO_STEP').text('');
        $('#CI_CURRENT_INFO_GRADE').text('');
        CommonOpUtil.showHideLayoutGroup('CI_CURRENT_INFO_STEP', false);
        CommonOpUtil.showHideLayoutGroup('CI_CURRENT_INFO_GRADE', false);

        FormState.updateVariableValue('CI_POS_TITLE', '', false);
        FormState.updateVariableValue('CI_PPLAN', '', false);
        FormState.updateVariableValue('CI_SERIES', '', false);
        FormState.updateVariableValue('CI_CURRENT_INFO_STEP', '', false);
        FormState.updateVariableValue('CI_CURRENT_INFO_GRADE', '', false);
    }else{
        $('#CI_POS_TITLE').text(genEmployee.positionTitle);
        $('#CI_PPLAN').text(genEmployee.payPlan);
        $('#CI_SERIES').text(genEmployee.series);
        $('#CI_CURRENT_INFO_STEP').text(genEmployee.grade);
        $('#CI_CURRENT_INFO_GRADE').text(genEmployee.step);
        CommonOpUtil.showHideLayoutGroup('CI_CURRENT_INFO_STEP', !_.isEmpty(genEmployee.step));
        CommonOpUtil.showHideLayoutGroup('CI_CURRENT_INFO_GRADE', !_.isEmpty(genEmployee.grade));

        FormState.updateVariableValue('CI_POS_TITLE', genEmployee.positionTitle, false);
        FormState.updateVariableValue('CI_PPLAN', genEmployee.payPlan, false);
        FormState.updateVariableValue('CI_SERIES', genEmployee.series, false);
        FormState.updateVariableValue('CI_CURRENT_INFO_STEP', genEmployee.grade, false);
        FormState.updateVariableValue('CI_CURRENT_INFO_GRADE', genEmployee.step, false);
    }
}

//TODO: dynamically hide/show fields based on
function finalAgencyDecision(e) {
    var id = '';
    var value;
    try {
        id = e.target.id;
        value = e.target.options[e.target.options.selectedIndex].value;
        finalAgencyDecisionHelper(id, value);
    } catch (err) {

    }
}

function finalAgencyDecisionHelper(id, value) {
    if (id === 'CI_DEMO_FINAL_AGENCY_DECISION') {
        if (value === 'Demotion Rescinded') {
            CommonOpUtil.showHideLayoutGroup('ci_final_decision_detail_by_agency', true);
            CommonOpUtil.showHideLayoutGroup('ci_final_decision_effdt_group', false);
            CommonOpUtil.showHideLayoutGroup('ci_final_decision_suspend_days_group', false);
        } else if (value === 'No Action Taken') {
            CommonOpUtil.showHideLayoutGroup('ci_final_decision_detail_by_agency', false);
            CommonOpUtil.showHideLayoutGroup('ci_final_decision_effdt_group', false);
            CommonOpUtil.showHideLayoutGroup('ci_final_decision_suspend_days_group', false);
        } else if (value === 'Suspension') {
            CommonOpUtil.showHideLayoutGroup('ci_final_decision_detail_by_agency', true);
            CommonOpUtil.showHideLayoutGroup('ci_final_decision_effdt_group', true);
            CommonOpUtil.showHideLayoutGroup('ci_final_decision_suspend_days_group', true);
        } else {
            CommonOpUtil.showHideLayoutGroup('ci_final_decision_detail_by_agency', true);
            CommonOpUtil.showHideLayoutGroup('ci_final_decision_effdt_group', true);
            CommonOpUtil.showHideLayoutGroup('ci_final_decision_suspend_days_group', false);
        }
    } else if (id === 'CI_SUSP_FINAL_AGENCY_DECISION') {
        if (value === 'Suspension Rescinded') {
            CommonOpUtil.showHideLayoutGroup('ci_susp_final_decision_detail_by_agency', true);
            CommonOpUtil.showHideLayoutGroup('ci_susp_final_decision_effdt_group', false);
            CommonOpUtil.showHideLayoutGroup('ci_susp_final_decision_suspend_days_group', false);
        } else if (value === 'No Action Taken') {
            CommonOpUtil.showHideLayoutGroup('ci_susp_final_decision_detail_by_agency', false);
            CommonOpUtil.showHideLayoutGroup('ci_susp_final_decision_effdt_group', false);
            CommonOpUtil.showHideLayoutGroup('ci_susp_final_decision_suspend_days_group', false);
        } else if ((value === 'Suspension Upheld ') || (value === 'Suspension Reduced')) {
            CommonOpUtil.showHideLayoutGroup('ci_susp_final_decision_detail_by_agency', true);
            CommonOpUtil.showHideLayoutGroup('ci_susp_final_decision_effdt_group', true);
            CommonOpUtil.showHideLayoutGroup('ci_susp_final_decision_suspend_days_group', true);
        } else {
            CommonOpUtil.showHideLayoutGroup('ci_susp_final_decision_detail_by_agency', true);
            CommonOpUtil.showHideLayoutGroup('ci_susp_final_decision_effdt_group', true);
            CommonOpUtil.showHideLayoutGroup('ci_susp_final_decision_suspend_days_group', false);
        }
    } else if (id === 'CI_RMVL_FINAL_AGENCY_DECISION') {
        if (value === 'Removal Rescinded') {
            CommonOpUtil.showHideLayoutGroup('ci_removal_final_decision_detail_by_agency', true);
            CommonOpUtil.showHideLayoutGroup('ci_removal_final_decision_effdt_group', false);
            CommonOpUtil.showHideLayoutGroup('ci_removal_final_decision_suspend_days_group', false);
        } else if (value === 'No Action Taken') {
            CommonOpUtil.showHideLayoutGroup('ci_removal_final_decision_detail_by_agency', false);
            CommonOpUtil.showHideLayoutGroup('ci_removal_final_decision_effdt_group', false);
            CommonOpUtil.showHideLayoutGroup('ci_removal_final_decision_suspend_days_group', false);
        } else if (value === 'Suspension') {
            CommonOpUtil.showHideLayoutGroup('ci_removal_final_decision_detail_by_agency', true);
            CommonOpUtil.showHideLayoutGroup('ci_removal_final_decision_effdt_group', true);
            CommonOpUtil.showHideLayoutGroup('ci_removal_final_decision_suspend_days_group', true);
        } else {
            CommonOpUtil.showHideLayoutGroup('ci_removal_final_decision_detail_by_agency', true);
            CommonOpUtil.showHideLayoutGroup('ci_removal_final_decision_effdt_group', true);
            CommonOpUtil.showHideLayoutGroup('ci_removal_final_decision_suspend_days_group', false);
        }
    }
}