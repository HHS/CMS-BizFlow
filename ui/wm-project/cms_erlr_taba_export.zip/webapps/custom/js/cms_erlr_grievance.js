//(function(window){
'use strict';
var cms_grievance = {
    initialized: false,
    groups: [
        'GI_admin_stg2_group',
        'grievance_step2_request_group',
        'grievance_ind_step2_group'],
    reqFieldForActivity:
        [
            {
                actName: globalVars.actAll,
                reqFieldIds:
                    []
            },
            {
                actName: globalVars.actCaseCreation,
                reqFieldIds:
                    []
            },
            {
                actName: globalVars.actCaseComplete,
                reqFieldIds:
                    [
                        'GI_TYPE',
                        'GI_FILING_DT',
                        'GI_IND_STEP_1_DECISION_DT',
                        'GI_IND_STEP_1_DEADLINE',
                        'GI_IND_DECISION_ISSUE_DT',
                        'GI_IND_STEP_2_MTG_DT',
                        'GI_IND_STEP_2_DECISION_DUE_DT',
                        'GI_IND_STEP_2_DECISION_ISSUE_DT',
                        'GI_IND_STEP_2_DEADLINE',
                        'GI_IND_THIRD_PARTY_APPEAL_DT',
                        'GI_IND_THIRD_APPEAL_REQUEST',
                        'GI_UM_GRIEVABILITY_SEL',
                        'GI_GRIEVANCE_STATUS',
                        'GI_ARBITRATION_DEADLINE_DT',
                        'GI_ARBITRATION_REQUEST',
                        'GI_ADMIN_OFFCL_1_SRCH',
                        'GI_ADMIN_STG_1_DECISION_DT',
                        'GI_ADMIN_STG_1_ISSUE_DT',
                        'GI_ADMIN_STG_2_RESP',
                        'GI_ADMIN_OFFCL_2_SRCH',
                        'GI_ADMIN_STG_2_DECISION_DT',
                        'GI_ADMIN_STG_2_ISSUE_DT',
                        'GI_NEGOTIATED_GRIEVANCE_TYPE',
                        'GI_TIMELY_FILING',
                        'GI_TIMELY_FILING_2',
                        'GI_IND_MANAGER_SRCH',
                        'GI_FILING_DT_2'
                    ]

            }
        ],
    standardDTs: [
        'GI_FILING_DT',
        'GI_IND_MEETING_DT',
        'GI_IND_DECISION_ISSUE_DT',
        'GI_IND_STEP_2_MEETING_DT',
        'GI_IND_STEP_2_DECISION_ISSUE_DT',
        'GI_ADMIN_STG_1_ISSUE_DT',
        'GI_ADMIN_STG_2_ISSUE_DT',
        'GI_FILING_DT_2',
        'GI_IND_STEP_2_MTG_DT'
    ],
    GI_ADMIN_OFFCL_1: null,
    GI_ADMIN_OFFCL_2: null,
    GI_IND_MANAGER: null,
    GI_UM_GRIEVABILITY: null,
    GI_IND_STEP_1_EXT_DUE_DT_LIST_group: null,
    GI_IND_STEP_2_EXT_DUE_DT_LIST_group: null,
    GIExtDialog: null,
    init: function () {
        cms_grievance.groups.forEach(function (el) {
            hyf.util.hideComponent(el);
        });
        CommonOpUtil.setDateConstraintMaximumToday(cms_grievance.standardDTs);
        //hyf.util.hideComponent('grievance_Negotiated_group');
        hyf.util.hideComponent('grievance_Administrative_group');
        hyf.util.hideComponent('GI_Negotiated_grievance_group');
        // hyf.util.hideComponent('grievance_Individual_group');
        CommonOpUtil.showHideLayoutGroup('grievance_Individual_group', false);

        hyf.util.hideComponent('grievance_Union_Management_group');
        hyf.util.hideComponent('manager_layout_group');
        hyf.util.showComponent('non_manager_layout_group');

        CommonOpUtil.dynamicMandatory(cms_grievance.reqFieldForActivity);

        // var Step1RevDt = $('#GI_IND_EXT_HIDDEN_SELECTION').val();
        // var Step2ExtDt = $('#GI_IND_STEP_2_PREV_EXT_DT').val();
        // if (Step1RevDt && Step1RevDt.trim().length <= 0) {
        //     Step1RevDt = FormState.getState('GI_IND_EXT_HIDDEN_SELECTION');
        // }
        // if (Step2ExtDt && Step2ExtDt.trim().length <= 0) {
        //     Step2ExtDt = FormState.getState('GI_IND_STEP_2_PREV_EXT_DT');
        // }
        $('#GI_TYPE').on('change', grievanceEvent);
        $('#GI_NEGOTIATED_GRIEVANCE_TYPE').on('change', negotiatedType);
        $('#GI_ADMIN_STG_2_RESP,#GI_STEP_2_REQUEST,#GI_IND_STEP_2_DEADLINE, #GI_IND_STEP_1_DEADLINE').on('change', grievanceToggle);

        cms_grievance.GI_ADMIN_OFFCL_1 = FormAutoComplete.makeAutoCompletion(FormMain.getAutoCompleteOptionForEmployee('GI_ADMIN_OFFCL_1_SRCH', 'GI_ADMIN_OFFCL_1'));
        cms_grievance.GI_IND_MANAGER = FormAutoComplete.makeAutoCompletion(FormMain.getAutoCompleteOptionForEmployee('GI_IND_MANAGER_SRCH', 'GI_IND_MANAGER'));
        cms_grievance.GI_ADMIN_OFFCL_2 = FormAutoComplete.makeAutoCompletion(FormMain.getAutoCompleteOptionForEmployee('GI_ADMIN_OFFCL_2_SRCH', 'GI_ADMIN_OFFCL_2'));
        cms_grievance.GI_UM_GRIEVABILITY = grievanceMultiSelectOptions('GI_UM_GRIEVABILITY');

        cms_grievance.GI_IND_STEP_1_EXT_DUE_DT_LIST_group = MultiDataSelectField.init({
            layoutGroupId: 'GI_IND_STEP_1_EXT_DUE_DT_LIST_group',
            mandatory: true,
            dataFieldId: 'GI_IND_STEP_1_EXT_DUE_DT_LIST',
            sort: {fieldId: 'GI_IND_STEP_1_EXT_DUE_DT', valueType: 'date', order: 'desc'},
            recordFields: ['GI_IND_STEP_1_EXT_DUE_DT', 'GI_IND_STEP_1_EXT_DUE_REASON']
        });

        cms_grievance.GI_IND_STEP_2_EXT_DUE_DT_LIST_group = MultiDataSelectField.init({
            layoutGroupId: 'GI_IND_STEP_2_EXT_DUE_DT_LIST_group',
            mandatory: true,
            dataFieldId: 'GI_IND_STEP_2_EXT_DUE_DT_LIST',
            sort: {fieldId: 'GI_IND_STEP_2_EXT_DUE_DT', valueType: 'date', order: 'desc'},
            recordFields: ['GI_IND_STEP_2_EXT_DUE_DT', 'GI_IND_STEP_2_EXT_DUE_REASON']
        });

        onloadInit();
    },

    render: function () {

        cms_grievance.GI_IND_STEP_1_EXT_DUE_DT_LIST_group.render();
        cms_grievance.GI_IND_STEP_2_EXT_DUE_DT_LIST_group.render();
    },
    clearData: function () {
        var caseType;
        try {
            caseType = FormState.getState('GEN_CASE_TYPE');
            if (caseType.value.replace(/\s/g, '') !== 'Grievance') {
                $('#grievance_layout input[type!="button"]').val('');
                $('#grievance_layout input[type=checkbox]').prop('checked', false);
                $('#grievance_layout select').not('#GI_TYPE,#GI_NEGOTIATED_GRIEVANCE_TYPE').val('');
                $('#grievance_layout input').each(function (field) {
                    FormState.updateObjectValue(field.id, '');
                });
                $('#grievance_layout select').each(function (field) {
                    FormState.updateObjectValue(field.id, '');
                });
            }
            if (typeof cms_grievance.GI_ADMIN_OFFCL_1 !== 'undefined' && cms_grievance.GI_ADMIN_OFFCL_1 != null) {
                cms_grievance.GI_ADMIN_OFFCL_1.initializeItems([]);
            }
            if (typeof cms_grievance.GI_IND_MANAGER !== 'undefined' && cms_grievance.GI_IND_MANAGER != null) {
                cms_grievance.GI_IND_MANAGER.initializeItems([]);
            }
            if (typeof cms_grievance.GI_ADMIN_OFFCL_2 !== 'undefined' && cms_grievance.GI_ADMIN_OFFCL_2 != null) {
                cms_grievance.GI_ADMIN_OFFCL_2.initializeItems([]);
            }
            if (typeof cms_grievance.GI_UM_GRIEVABILITY !== 'undefined' && cms_grievance.GI_UM_GRIEVABILITY != null) {
                cms_grievance.GI_UM_GRIEVABILITY.deleteAll();
            }
        } catch (err) {

        }
    }
}

//use this function where a multi select is needed, without creating config object repeatedly. Just pass field ID from index 0 up until "_SEL". eg. GEN_CASE_CATEGORY_SEL, you pass GEN_CASE_CATEGORY instead.
function grievanceMultiSelectOptions(dropdownID) {
    var activityName = ActivityManager.getActivityName();
    var optionsMinSelection = (activityName === 'Complete Case') ? 1 : 0;
    var optionsInitialData = [];
    var optionsIdString = FormState.getElementValue(dropdownID);
    var optionsIds = ((optionsIdString != null && optionsIdString.length > 0) ? optionsIdString.split(',') : []);
    var count = optionsIds.length;
    for (var index = 0; index < count; index++) {
        var itemLabel = $('#' + dropdownID + '_SEL option[value="' + optionsIds[index] + '"]').text();
        optionsInitialData.push({
            id: optionsIds[index],
            label: itemLabel
        });
    }
    var multiSelectOptions = {
        id: dropdownID,
        tabindex: 0,
        minSelectionCount: optionsMinSelection,
        maxSelectionCount: 10,
        getSelectionLabel: function (item) {
            return item.label
        },
        getItemID: function (item) {
            return item.id;
        },
        initialItems: optionsInitialData,
        setDataToForm: function (values) {
            if (typeof values == 'undefined') return;
            var selectedIds = '';
            if (values != null && $.isArray(values)) {
                selectedIds = values.reduce(function (accumulator, currentValue, currentIndex, array) {
                    return (accumulator && accumulator.length > 0) ? accumulator + ',' + currentValue.id : currentValue.id;
                }, '');
            }
            FormState.updateObjectValue(dropdownID, selectedIds);
        }
    };
    return MultiSelectDropdown.setupMultiSelectDropdown(multiSelectOptions);
}



function grievanceEvent(e) {
    var grievanceType = '';// e.target.options[e.target.options.selectedIndex].value;
    if (e === 'undefined') {
        return;
    } else if (typeof e === 'object') {
        if (e.target !== 'undefined') {
            grievanceType = e.target.options[e.target.options.selectedIndex].value;
        }
    } else {
        grievanceType = e;
    }
    if (grievanceType && grievanceType !== '') {
        if (grievanceType === 'Negotiated') {
            hyf.util.showComponent('GI_Negotiated_grievance_group');
            hyf.util.showComponent('grievance_Negotiated_group');
            hyf.util.hideComponent('grievance_Administrative_group');
        } else if (grievanceType === 'Administrative') {
            hyf.util.hideComponent('GI_Negotiated_grievance_group');
            hyf.util.hideComponent('grievance_Negotiated_group');
            hyf.util.showComponent('grievance_Administrative_group');
        } else {
            hyf.util.hideComponent('GI_Negotiated_grievance_group');
            hyf.util.hideComponent('grievance_Administrative_group');
            hyf.util.hideComponent('grievance_Negotiated_group');

        }
    }
    cms_grievance.clearData();
}

function negotiatedType(e) {
    var negotiatedValue = '';// e.target.options[e.target.options.selectedIndex].value;
    if (e === 'undefined') {
        return;
    } else if (typeof e === 'object') {
        if (e.target !== 'undefined') {
            negotiatedValue = e.target.options[e.target.options.selectedIndex].value;
        }
    } else {
        negotiatedValue = e;
    }
    if (negotiatedValue === 'Individual') {
        CommonOpUtil.showHideLayoutGroup('grievance_Individual_group', true);
        CommonOpUtil.showHideLayoutGroup('manager_layout_group', true);
        CommonOpUtil.showHideLayoutGroup('grievance_Union_Management_group', false);
        CommonOpUtil.showHideLayoutGroup('non_manager_layout_group', false);
    } else if (negotiatedValue === 'Union' || negotiatedValue === 'Management') {
        CommonOpUtil.showHideLayoutGroup('grievance_Individual_group', false);
        CommonOpUtil.showHideLayoutGroup('manager_layout_group', false);
        CommonOpUtil.showHideLayoutGroup('grievance_Union_Management_group', true);
        CommonOpUtil.showHideLayoutGroup('non_manager_layout_group', true);
    } else {
        CommonOpUtil.showHideLayoutGroup('grievance_Individual_group', false);
        CommonOpUtil.showHideLayoutGroup('manager_layout_group', false);
        CommonOpUtil.showHideLayoutGroup('grievance_Union_Management_group', false);
        CommonOpUtil.showHideLayoutGroup('non_manager_layout_group', true);
    }
    $('#GI_main_body select,#GI_main_body input[type="text"]').not('#GI_TYPE,#GI_NEGOTIATED_GRIEVANCE_TYPE').val('');
    //GI_ARBITRATION_REQUEST
    FormState.updateObjectValue('GI_ARBITRATION_REQUEST', '', false);
    cms_grievance.clearData();
}

function grievanceToggle(e) {
    var negotiatedValue = '';
    if (e !== 'undefined') {
        if (e.target !== 'undefined') {
            negotiatedValue = e.target.options[e.target.options.selectedIndex].value;
        }
    } else {
        return;
    }
    var dynamicSection = '';
    if (e.target.id === 'GI_ADMIN_STG_2_RESP') {
        dynamicSection = 'GI_admin_stg2_group';
    }
    if (e.target.id === 'GI_STEP_2_REQUEST') {
        dynamicSection = 'grievance_step2_request_group';
    }
    if (e.target.id === 'GI_IND_STEP_1_DEADLINE') {
        dynamicSection = 'GI_IND_STEP_1_EXT_DUE_DT_LIST_group';
    }
    if (e.target.id === 'GI_IND_STEP_2_DEADLINE') {
        dynamicSection = 'GI_IND_STEP_2_EXT_DUE_DT_LIST_group';
    }

    CommonOpUtil.showHideLayoutGroup(dynamicSection, negotiatedValue === 'Yes')
    //CommonOpUtil.hyfShowOrHide({value: negotiatedValue}, dynamicSection);
}

function onloadInit() {
    var negotiatedType = FormState.getElementValue('GI_NEGOTIATED_GRIEVANCE_TYPE');
    var grievanceType = FormState.getElementValue('GI_TYPE');

    if (grievanceType && grievanceType === 'Negotiated') {
        if (negotiatedType === 'Individual') {
            hyf.util.showComponent('GI_Negotiated_grievance_group');
            //hyf.util.showComponent('grievance_Individual_group');
            CommonOpUtil.showHideLayoutGroup('grievance_Individual_group', true);

            hyf.util.hideComponent('grievance_Union_Management_group');
        } else if (negotiatedType === 'Union' || negotiatedType === 'Management') {
            hyf.util.showComponent('GI_Negotiated_grievance_group');
            hyf.util.showComponent('grievance_Union_Management_group');
            // hyf.util.hideComponent('grievance_Individual_group');
            CommonOpUtil.showHideLayoutGroup('grievance_Individual_group', false);

            hyf.util.showComponent('non_manager_layout_group');
            hyf.util.hideComponent('manager_layout_group');
        }
    } else if (grievanceType && grievanceType === 'Administrative') {
        hyf.util.hideComponent('GI_Negotiated_grievance_group');
        hyf.util.showComponent('grievance_Administrative_group');
    } else {
        hyf.util.hideComponent('grievance_Administrative_group');
        hyf.util.hideComponent('GI_Negotiated_grievance_group');
    }

    CommonOpUtil.showHideLayoutGroup('GI_admin_stg2_group', FormState.getElementBooleanValue('GI_ADMIN_STG_2_RESP'));
    CommonOpUtil.showHideLayoutGroup('grievance_step2_request_group', FormState.getElementBooleanValue('GI_STEP_2_REQUEST'));
    CommonOpUtil.showHideLayoutGroup('GI_IND_STEP_1_EXT_DUE_DT_LIST_group', FormState.getElementBooleanValue('GI_IND_STEP_1_DEADLINE'));
    CommonOpUtil.showHideLayoutGroup('GI_IND_STEP_2_EXT_DUE_DT_LIST_group', FormState.getElementBooleanValue('GI_IND_STEP_2_DEADLINE'));
}

//return{
//init : init,
//render : render
//}
//})(window);
//(window.cms_grievance !== undefined ? window.cms_grievance : (window.cms_grievance = cms_grievance()));
//})(window);
//})(window);