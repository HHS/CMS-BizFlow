var cms_erlr_prob_period = {
    initialized: false,
	groups : [
	'termination_type_pre_employment_group',
	'termination_type_probation_group',
	'oral_presentation_date_group',
	'written_response_group',
	'action_Demotion_group',
	'action_Reassignment_group',
	'pre_emp_termination_oral_presentation_group',
	'pre_emp_termination_response_group',
	'action_Termination_group',
	'oral_presentation_date_group',
	'written_response_group',
	'pre_emp_termination_oral_presentation_group',
	'pre_emp_termination_response_group',
	'reassignment_date_notice_issued',
	'emp_appeal_decision_group'
	],
	actionTypes :[
	'alt_discipline',
	],
	init: function (){
		/* ConductIssue.groups.forEach(function(el,index){
			hyf.util.hideComponent(el);
		});
		var reqFieldForActivity = 
		[
			{
				actName: globalVars.actAll,
				reqFieldIds: 
				[
				
				
				]
			},
			{
				actName: globalVars.actCaseCreation,
				reqFieldIds: 
				[
					
				]
			},
			{
				actName: globalVars.actCaseComplete,
				reqFieldIds: 
				[
				'CI_ACTION_TYPE',
				'CI_APPROVAL_NAME_SRCH',
				'CI_APPROVAL_NAME_2_SRCH',
				'CI_PROP_ACTION_ISSUED_DT',
				'CI_ORAL_PREZ_REQUESTED',
				'CI_ORAL_PREZ_DT',
				'CI_ORAL_RESPONSE_SUBMITTED',
				'CI_RESPONSE_DUE_DT',
				'CI_WRITTEN_RESPONSE_SUBMITTED_DT',
				'CI_PROPOSED_POS_TITLE',
				'CI_PROPOSED_PPLAN',
				'CI_PROPOSED_SERIES',
				'CI_PROPOSED_INFO_GRADE',
				'CI_PROPOSED_INFO_STEP',
				'CI_FINAL_INFO_STEP',
				'CI_DEMO_FINAL_AGENCY_DECISION',
				'CI_DECIDING_OFFCL_SRCH',
				'CI_DECISION_ISSUED_DT',
				'CI_DEMO_FINAL_AGENCY_EFF_DT',
				'CI_NOTICE_ISSUED_DT',
				'CI_EFFECTIVE_DT',
				'CI_CURRENT_ADMIN_CODE',
				'CI_RE_ASSIGNMENT_CURR_ORG',
				'CI_RE_ASSIGNMENT_FINAL_ORG',
				'CI_EMP_NOTICE_LEAVE_PLACED',
				'CI_WRITTEN_RESPONSE_DUE_DT',
				'CI_WRITTEN_SUBMITTED_DT',
				'CI_DECIDING_OFFCL_NAME_SRCH',
				'CI_TERMINATION_TYPE',
				'CI_TERM_PROP_ACTION_DT',
				'CI_TERM_ORAL_PREZ_REQUESTED',
				'CI_TERM_ORAL_PREZ_DT',
				'CI_TERM_WRITTEN_RESP',
				'CI_TERM_WRITTEN_RESP_DUE_DT',
				'CI_TERM_WRITTEN_RESP_DT',
				'CI_TERM_AGENCY_DECISION',
				'CI_TERM_DECIDING_OFFCL_NAME_SRCH',
				'CI_TERM_DECISION_ISSUED_DT',
				'CI_TERM_EFFECTIVE_DECISION_DT',
				'CI_PRE_PROBATION_TERMINATION_DECISION_ISSUED_DT',
				'CI_REPRIMAND_ISSUE_DT'
				]
			}
		];
		var empData = FormState.getElementValue('GEN_EMPLOYEE');
		//populateCurrentPosition(empData);
		$('#conduct_issue_layout select').on('change',helperEventHandler);
		$('#CI_TERM_PROP_ACTION_DT,#CI_SUSP_PROP_ACTION_DT, #CI_REMOVAL_PROP_ACTION_DT, #CI_DECISION_ISSUED_DT,#CI_PROP_ACTION_ISSUED_DT').on('change',dateChangeEventConduct);
		$('#CI_PROPOSED_PPLAN,#CI_FINAL_PPLAN').on('change',populateGrades);
		$('#CI_LEAVE_START_DT,#CI_LEAVE_END_DT,#CI_LEAVE_START_DT_2,#CI_LEAVE_END_DT_2').on('change',dateValidate);
		$('#CI_EMP_APPEAL_DECISION').on('change',employeeAppealDecision);
		
		$('#CI_RMVL_FINAL_AGENCY_DECISION,#CI_DEMO_FINAL_AGENCY_DECISION,#CI_SUSP_FINAL_AGENCY_DECISION, #CI_TERM_AGENCY_DECISION').on('change',finalAgencyDecision);

		$('#CI_ADMIN_NOTICE_LEAVE, #CI_ADMIN_INVESTIGATORY_LEAVE').on('click',function(e){
			var val = $(this).prop('checked');
			if(e.target.id ==='CI_ADMIN_INVESTIGATORY_LEAVE'){
				$('#admin_leave_investigatory_group input[type="text"]').val('');
				$('#leave_length').text('');
				if(val){
					hyf.util.showComponent('admin_leave_investigatory_group');
				}
				else{
					hyf.util.hideComponent('admin_leave_investigatory_group');
				}
			}
		if(e.target.id ==='CI_ADMIN_NOTICE_LEAVE'){
			$('#admin_leave_notice_group input[type="text"]').val('');	
			$('#leave_length_2').text('');
			if(val){
					hyf.util.showComponent('admin_leave_notice_group');
				}
				else{
					hyf.util.hideComponent('admin_leave_notice_group');
				}
			}
		});
		ConductIssue.dateFields.forEach(function(el){
			if(el !==''){
				try{hyf.calendar.setDateConstraint(el, 'Maximum', 'Today');}catch(err){}
			}
		})
		conductAutoCompleteOptions('CI_APPROVAL_NAME');//,'/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=',ConductIssue.populateOfficial,CommonOpUtil.responseMapper,CommonOpUtil.appendEmplInfo);
		conductAutoCompleteOptions('CI_APPROVAL_NAME_2');//,'/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=',ConductIssue.populateOfficial,CommonOpUtil.responseMapper,CommonOpUtil.appendEmplInfo);
		conductAutoCompleteOptions('CI_DECIDING_OFFCL');//,'/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=',ConductIssue.populateOfficial,CommonOpUtil.responseMapper,CommonOpUtil.appendEmplInfo);
		conductAutoCompleteOptions('CI_SUSP_DECIDING_OFFCL_NAME');//,'/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=',ConductIssue.populateOfficial,CommonOpUtil.responseMapper,CommonOpUtil.appendEmplInfo);
		conductAutoCompleteOptions('CI_TERM_DECIDING_OFFCL_NAME');//,'/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=',ConductIssue.populateOfficial,CommonOpUtil.responseMapper,CommonOpUtil.appendEmplInfo);
		conductAutoCompleteOptions('CI_DECIDING_OFFCL_NAME');//,'/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=',ConductIssue.populateOfficial,CommonOpUtil.responseMapper,CommonOpUtil.appendEmplInfo);
		conductAdminCodeAutoCompleteOptions('CI_FINAL_ADMIN_CODE');//,'/bizflowwebmaker/cms_erlr_service/contactInfo.do?admin=',populateAdminCode,CommonOpUtil.adminCodeResponseMapper,appendAdminCode);
		CommonOpUtil.dynamicMandatory(reqFieldForActivity);	
		hyf.util.hideComponent('tab_control_tab_tab4');
		populateCIDemotionCurPosnData(); */
	},
	grades: {'GP':['01','02','03','04','05','06','07','08','09','10','11','12','13','14','15'],
			'GR':['01','02','03','04','05','06','07','08','09','10','11','12','13','14','15'],
			'GS':['01','02','03','04','05','06','07','08','09','10','11','12','13','14','15'],
			'ES':['01','02','03','04','05','06'],
			'WG':['01','02','03','04','05','06','07','08','09','10']
	},
	dateFields :[
		'CI_PROP_ACTION_ISSUED_DT',
		'CI_ORAL_PREZ_DT',
		'CI_RESPONSE_DUE_DT',
		'CI_WRITTEN_RESPONSE_SUBMITTED_DT',
		'CI_DECISION_ISSUED_DT',
		'CI_DEMO_FINAL_AGENCY_EFF_DT',
		'CI_NOTICE_ISSUED_DT',
		'CI_EFFECTIVE_DT',
		'CI_WRITTEN_RESPONSE_DUE_DT',
		'CI_WRITTEN_SUBMITTED_DT',
		'CI_DECIDING_OFFCL_NAME',
		'CI_REMOVAL_EFFECTIVE_DT',
		'CI_TERM_PROP_ACTION_DT',
		'CI_TERM_ORAL_PREZ_DT',
		'CI_TERM_WRITTEN_RESP_DUE_DT',
		'CI_TERM_WRITTEN_RESP_DT',
		'CI_TERM_DECISION_ISSUED_DT',
		'CI_TERM_EFFECTIVE_DECISION_DT',
		'CI_PRE_PROBATION_TERMINATION_DECISION_ISSUED_DT',
		'CI_REPRIMAND_ISSUE_DT'
	],
	inputEvents : {
		/*I intend to have a list of dropdowns and their corresponding event hanlder helper functions, so that I can access the reference to the function, then call it 
		like dropdownTargets[event.target.id](),where event target id corresponds to the obj key*/
		
		 'CI_ACTION_TYPE':actionTypeEvent,
		 'CI_TERMINATION_TYPE': terminationationTpe,
		 'CI_PROP_ACTION_ISSUED': {action:hyfToogle,target:''},
		 'CI_ORAL_PREZ_REQUESTED':{action:hyfToogle,target:'oral_presentation_date_group'},
		 'CI_ORAL_RESPONSE_SUBMITTED': {action:hyfToogle,target:'written_response_group'},
		 'CI_EMP_NOTICE_LEAVE_PLACED':{action:hyfToogle,target:'removal_notice_date_group'},
		 'CI_REMOVAL_ORAL_PREZ_REQUESTED': {action:hyfToogle,target:'removal_oral_presentation_group'},
		 'CI_REMOVAL_WRITTEN_RESPONSE': {action:hyfToogle,target:'removal_written_response_group'},
		 'CI_SUSP_ORAL_PREZ_REQUESTED': {action:hyfToogle,target:'suspension_oral_presentation_group'},
		 'CI_SUSP_WRITTEN_RESP': {action:hyfToogle,target:'suspension_written_response_group'},
		 'CI_TERM_ORAL_PREZ_REQUESTED' : {action:hyfToogle,target:'pre_emp_termination_oral_presentation_group'},
		 'CI_TERM_WRITTEN_RESP' : {action:hyfToogle,target:'pre_emp_termination_response_group'},		 
	},
	booleanCheckBox: function(group){
	var checked  = false;
	var list  = $('.' + group).get(); 
	if(list && Array.isArray(list)&& list.length > 0){
		list.forEach(function(el){
			if($(el).prop('checked')){
				checked = true;
			}
		});
	}
	return checked;
},
 render: function (){
	/*   var actionType = FormState.getState('CI_ACTION_TYPE');
	 if(actionType && actionType.dirty){
		ConductIssue.showCaseView('action_'+actionType.value.replace(/\s/g,'')+'_group',ConductIssue.groups);
	 } 
	 var dmnOralPrez = FormState.getElementValue('CI_ORAL_PREZ_REQUESTED');
	 var dmnOralResponse = FormState.getElementValue('CI_ORAL_RESPONSE_SUBMITTED');
	 var rmvlLeaveNotice = FormState.getElementValue('CI_EMP_NOTICE_LEAVE_PLACED');
	 var rmvlOralPrez = FormState.getElementValue('CI_REMOVAL_ORAL_PREZ_REQUESTED');
	 var rmvlWrtnResp = FormState.getElementValue('CI_REMOVAL_WRITTEN_RESPONSE');
	 var susOralPrez = FormState.getElementValue('CI_SUSP_ORAL_PREZ_REQUESTED');
	 var susOralPrez = FormState.getElementValue('CI_SUSP_WRITTEN_RESP');
	 var suspFinalAgency = FormState.getElementValue('CI_SUSP_FINAL_AGENCY_DECISION');
	 var rmvlFinalAgency = FormState.getElementValue('CI_RMVL_FINAL_AGENCY_DECISION');
	 var dmnpFinalAgency = FormState.getElementValue('CI_DEMO_FINAL_AGENCY_DECISION');
	if(suspFinalAgency === 'undefined'){
		 finalAgencyDecisionHelper('CI_SUSP_FINAL_AGENCY_DECISION',suspFinalAgency);
	 }
	 if(rmvlFinalAgency === 'undefined'){
		finalAgencyDecisionHelper('CI_RMVL_FINAL_AGENCY_DECISION',rmvlFinalAgency);
	 }
	 if(dmnpFinalAgency === 'undefined'){
		finalAgencyDecisionHelper('CI_DEMO_FINAL_AGENCY_DECISION',dmnpFinalAgency);
	 }
	 
	 if(dmnOralPrez && dmnOralPrez === 'Y'){
		 hyf.util.showComponent('oral_presentation_date_group');
	 }
	 if(dmnOralResponse && dmnOralResponse === 'Y'){
		 hyf.util.showComponent('written_response_group');
	 }
	 if(rmvlLeaveNotice && rmvlLeaveNotice === 'Y'){
		 hyf.util.showComponent('removal_notice_date_group');
	 }
	 if(rmvlOralPrez && rmvlOralPrez === 'Y'){
		 hyf.util.showComponent('removal_oral_presentation_group');
	 }
	 if(rmvlWrtnResp && rmvlWrtnResp === 'Y'){
		 hyf.util.showComponent('removal_written_response_group');
	 }
	 
	 if(susOralPrez && susOralPrez === 'Y'){
		 hyf.util.showComponent('suspension_oral_presentation_group');
	 }
	 if(susOralPrez && susOralPrez === 'Y'){
		 hyf.util.showComponent('suspension_written_response_group');
	 }  */
    },
	populateOfficial : function(item,id){
		if(id ==='CI_APPROVAL_NAME' && (item.last_name !==''||item.first_name !=='')){
		$('#CI_APPROVAL_NAME').val(item.last_name +','+item.first_name +'('+item.email+')');
		}
		if(id ==='CI_APPROVAL_NAME_2' && item.value !==''){
		$('#CI_APPROVAL_NAME_2').val(item.last_name +','+item.first_name +'('+item.email+')');
		}
		if(id ==='CI_APPROVAL_NAME' && item.value !==''){
		$('#CI_APPROVAL_NAME').val(item.last_name +','+item.first_name +'('+item.email+')');
		}
		
		if(id ==='CI_SUSP_DECIDING_OFFCL_NAME' && item.value !==''){
		$('#CI_SUSP_DECIDING_OFFCL_NAME').val(item.last_name +','+item.first_name +'('+item.email+')');
		}
		if(id ==='CI_TERM_DECIDING_OFFCL_NAME' && item.value !==''){
		$('#CI_TERM_DECIDING_OFFCL_NAME').val(item.last_name +','+item.first_name +'('+item.email+')');
		}
		if(id ==='CI_DECIDING_OFFCL' && item.value !==''){
		$('#CI_DECIDING_OFFCL').val(item.last_name +','+item.first_name +'('+item.email+')');
		}
		if(id ==='CI_DECIDING_OFFCL_NAME' && item.value !==''){
		$('#CI_DECIDING_OFFCL_NAME').val(item.last_name +','+item.first_name +'('+item.email+')');
		}
	},
	showCaseView :function(caseValue,arr){
	arr.forEach(function(el,index){
	if(el === caseValue){  
		hyf.util.showComponent(el);	
	}else{
		//$('#' + el).find('input:text').val('');		
		hyf.util.hideComponent(el);
	}			
});
}

};
function initAdminLeaveDynamic(){
	var investigatoryLeave = FormState.getElementValue('CI_ADMIN_INVESTIGATORY_LEAVE');
	var noticeLeave = FormState.getElementValue('CI_ADMIN_NOTICE_LEAVE');
	if(Boolean(investigatoryLeave)){
		hyf.util.showComponent('admin_leave_investigatory_group');		
	}else{
		hyf.util.hideComponent('admin_leave_investigatory_group');
	}
	if(Boolean(noticeLeave)){
		hyf.util.showComponent('admin_leave_notice_group');		
	}else{
		hyf.util.hideComponent('admin_leave_notice_group');
	}
}
function employeeAppealDecision(e){
	var action = FormState.getElementValue('CI_EMP_APPEAL_DECISION');
	if(action === 'Y'){
		hyf.util.showComponent('tab_control_tab_tab4');		
	}else{
		hyf.util.hideComponent('tab_control_tab_tab4');
	}
}

function initLeaveBusinessDays(){
	
	var firstDate ='';
	var secondDate = '';
	var thrdDate = '';
	var fourthDate ='';
	var dtString1 ='';
	var dtString2 ='';
	var dtString3 ='';
	var dtString4 ='';
	try{
		firstDate = new Date(FormState.getElementValue('CI_LEAVE_START_DT'));
		secondDate = new Date(FormState.getElementValue('CI_LEAVE_END_DT'));
		thrdDate = new Date(FormState.getElementValue('CI_LEAVE_START_DT_2'));
		fourthDate = new Date(FormState.getElementValue('CI_LEAVE_END_DT_2'));
		dtString1 = firstDate.getFullYear() + '-' + parseInt(firstDate.getMonth()+ 1)  + '-' +firstDate.getDate();
		dtString2 = secondDate.getFullYear() + '-' + parseInt(secondDate.getMonth()+ 1) + '-' +secondDate.getDate();
		dtString3 = thrdDate.getFullYear() + '-' + parseInt(thrdDate.getMonth()+ 1)  + '-' +thrdDate.getDate();
		dtString4 = fourthDate.getFullYear() + '-' + parseInt(fourthDate.getMonth()+ 1) + '-' +fourthDate.getDate();
	}catch(e){
		
	}	
	if((dtString1 != '' && dtString2 != '')){
		CommonOpUtil.getBusinessDaysCount(dtString1,dtString2,inventoryBusinessDays);
	}
	if((dtString3 != '' && dtString4 != '')){
		CommonOpUtil.getBusinessDaysCount(dtString3,dtString4,noticeBusinessDays);
	}
}
function dateValidate(e){
	var days = 0;
	var dt1 = '';
	var dt2 = ''
	if(e === 'undefined'){
		return;
	}
	if(e.target.id ==='CI_LEAVE_START_DT' || e.target.id ==='CI_LEAVE_START_DT_2' || e.target.id ==='CI_LEAVE_END_DT' || e.target.id ==='CI_LEAVE_END_DT_2'){
		if(e.target.id ==='CI_LEAVE_START_DT' || e.target.id ==='CI_LEAVE_END_DT'){
			dt1 = $('#CI_LEAVE_START_DT').val();
			dt2 = $('#CI_LEAVE_END_DT').val();
		}else if(e.target.id ==='CI_LEAVE_START_DT_2' || e.target.id ==='CI_LEAVE_END_DT_2'){
			dt1 = $('#CI_LEAVE_START_DT_2').val();
			dt2 = $('#CI_LEAVE_END_DT_2').val();
		}		
	}
	var firstDate = new Date(dt1);
	var secondDate = new Date(dt2);
	var dtString1 = firstDate.getFullYear() + '-' + parseInt(firstDate.getMonth()+ 1)  + '-' +firstDate.getDate();
	var dtString2 = secondDate.getFullYear() + '-' + parseInt(secondDate.getMonth()+ 1) + '-' +secondDate.getDate();
	if((dt2 !== '' && dt1 !== '') && (e.target.id ==='CI_LEAVE_START_DT' || e.target.id ==='CI_LEAVE_END_DT')){
		CommonOpUtil.getBusinessDaysCount(dtString1,dtString2,inventoryBusinessDays);
	}
	if((dt2 !== '' && dt1 !== '') && (e.target.id ==='CI_LEAVE_START_DT_2' || e.target.id ==='CI_LEAVE_END_DT_2')){
		CommonOpUtil.getBusinessDaysCount(dtString1,dtString2,noticeBusinessDays);
	}
}


function conductAutoCompleteOptions(id){
	var optionConfig = {
		id: id + '_SRCH',
		 baseURL: '/bizflowwebmaker/StratCon_AUT',
		 targetURL : '/bizflowwebmaker/cms_erlr_service/searchParticipants.do?g=&q=',
		 minLength: 2,
		 minSelectionCount: 0,
		 maxSelectionCount: 1,
		 mapFunction: function(context){
			return {
				id: $("MID", context).text(),
				participantId:  "[" + $("MTYPE", context).text() + "]" + $("MID", context).text(),
				name:  $("NAME", context).text(),
				email: $("EMAIL", context).text(),
				org:  $("DEPTNAME", context).text(),
				title: $("JOBTITLENAME", context).text()
			};
		},
		 getSelectionLabel: function(item){
			var label = item.name + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '');
			if (item.title) {
				label += '/' + item.title;
			}
			return label;
		},
		getCandidateLabel: function(item) {
			return item.name + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '');
		},
		 getItemID : function(item){
			 return item.id;
		 },
		 setDataToForm: function (values) {
             FormState.updateObjectValue(id, values);
         },
		  // initialize
         initialItems: FormState.getElementArrayValue(id, []),
		};
		FormAutoComplete.makeAutoCompletion(optionConfig);
}

function conductAdminCodeAutoCompleteOptions(id){
	var optionConfig = {
		id: id + '_SEARCH',
		 baseURL: '/bizflowwebmaker/StratCon_AUT',
		 targetURL : '/bizflowwebmaker/StratCon_AUT/SearchAdmOffOrg.do?searchAdmOff=',
		 minLength: 2,
		 minSelectionCount: 0,
		 maxSelectionCount: 1,
		 mapFunction: function(context){
			return {
				adminCd:      $("AC_ADMIN_CD", context).text(),
				adminCdDesc:  $("AC_ADMIN_CD_DESCR", context).text()
			};
		},
		 getSelectionLabel: function(item){
			return item.adminCd;
		},
		getCandidateLabel: function(item) {
			return item.adminCd + ' - ' + item.adminCdDesc;// + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '');
		},
		 getItemID : function(item){
			 return item.id;
		 },
		 setDataToForm: function (values) {
             if (typeof values == 'undefined' || values == null) return;
			var item = null;
			if ($.isArray(values)) {
				item = values[0];
			} else {
				item = values;
			}
			
			if ( typeof item === 'object' && item != null 
					&& typeof item.adminCd != 'undefined' && item.adminCd != null && item.adminCd.trim().length > 0
					&& typeof item.adminCdDesc != 'undefined' && item.adminCdDesc != null && item.adminCdDesc.trim().length > 0 ) {
				$('#CI_RE_ASSIGNMENT_FINAL_ORG').text(item.adminCdDesc);
				FormState.updateObjectValue('CI_FINAL_ADMIN_CODE', values);
				FormState.updateVariableValue('CI_RE_ASSIGNMENT_FINAL_ORG', item.adminCdDesc, false);
			} else {
				$('#CI_RE_ASSIGNMENT_FINAL_ORG').text('');
				FormState.updateObjectValue('CI_FINAL_ADMIN_CODE', []);
				FormState.updateVariableValue('CI_RE_ASSIGNMENT_FINAL_ORG', '', false);
			}
         },
		  // initialize
         initialItems: FormState.getElementArrayValue(id, []),
		};
		FormAutoComplete.makeAutoCompletion(optionConfig);
}
function dateChangeEventConduct(e){
	var id = e.target.id;
	var dt1 ='';
	var dt2 ='';
	switch(id){
		case 'CI_TERM_PROP_ACTION_DT':
			dateValidateHelper('CI_TERM_PROP_ACTION_DT','CI_TERM_DECISION_ISSUED_DT','CI_TERM_DECISION_ISSUED_DT');
		break;
		case 'CI_SUSP_PROP_ACTION_DT':
			dateValidateHelper('CI_SUSP_PROP_ACTION_DT','CI_SUSP_DECISION_ISSUED_DT','CI_SUSP_PROP_ACTION_DT');
		break;
		case 'CI_REMOVAL_PROP_ACTION_DT':
			dateValidateHelper('CI_REMOVAL_PROP_ACTION_DT','CI_REMOVAL_DECISION_ISSUED_DT','CI_REMOVAL_PROP_ACTION_DT');
		break;
		case 'CI_DECISION_ISSUED_DT':
			dateValidateHelper('CI_DECISION_ISSUED_DT','CI_PROPOSE_ACTION_ISSUED_DT','CI_PROP_ACTION_ISSUED_DT');
		break;	
	}
	
}
//TODO: Move termaination type functionality to 3rd party hearing.
function terminationationTpe(id,val){
	if(val ==='pre_emp'){
		hyf.util.showComponent('termination_type_pre_employment_group');
		hyf.util.hideComponent('termination_type_probation_group');
	}else if(val==='probation'){
		hyf.util.showComponent('termination_type_probation_group');
		hyf.util.hideComponent('termination_type_pre_employment_group');
	}else{
		hyf.util.hideComponent('termination_type_pre_employment_group');
		hyf.util.hideComponent('termination_type_probation_group');
	}
	$('#action_Termination_group input').val('');
	$('#action_Termination_group input[type=checkbox]').prop('checked',false);
	$('#action_Termination_group select').not('#CI_TERMINATION_TYPE').val('');
	$('#pre_emp_termination_oral_presentation_group').hide();
	$('#pre_emp_termination_response_group').hide();
}
function actionTypeEvent(actionValue,value2){
	var actions = ['Demotion','Suspension','Reprimand','Termination','Removal'];
	if(value2 && value2  !== undefined){
			ConductIssue.showCaseView('action_'+value2.replace(/\s/g,'')+'_group',ConductIssue.groups);//CI_SUSP_WRITTEN_RESP
			$('#CI_EMP_APPEAL_DECISION').val('');		
			FormState.updateObjectValue('CI_EMP_APPEAL_DECISION','');
			if(value2 !== '' && actions.includes(value2)){
				hyf.util.showComponent('emp_appeal_decision_group');
			}else{
				hyf.util.hideComponent('emp_appeal_decision_group');
			}
			$('#conduct_issue_layout input[type="text"]').val('');
			$('#conduct_issue_layout input[type="checkbox"]').prop('checked',false);
			$('#conduct_issue_layout select[id!="CI_ACTION_TYPE"]').val('');
		}
}
function dateDecisionIssued(e){
	var days = 0;
	var dt1 = $('#CI_PROPOSE_ACTION_ISSUED_DT').val();
	var dt2 = $('#CI_DECISION_ISSUED_DT').val();
	if(dt2 && dt1){
		var m1  = new Date(dt1);
		var m2 = new Date(dt2);
		if(m2.getTime() < m1.getTime()){
			bootbox.alert({
            message: 'Date must be greater than Date Proposed Action Issued to Employee Date.',
            callback: function(){
                $('#CI_DECISION_ISSUED_DT').val('');
				FormState.updateObjectValue('CI_DECISION_ISSUED_DT','');
            }
        });
	}
}
}
function helperEventHandler(e){
	var target = e.target;
	var dropdownAction = target.options[target.options.selectedIndex].value;
	FormState.updateObjectValue(target.id, dropdownAction);
	dropdownCallBack(target.id,dropdownAction);
}
function hyfToogle(val,id){
	CommonOpUtil.hyfShowOrHide({value:val},id);	
}

function dropdownCallBack(dropdownId, value){
	if(typeof dropdownId !=='undefined'){
		if(ConductIssue.inputEvents[dropdownId] !=='undefined' && typeof ConductIssue.inputEvents[dropdownId] === 'function'){
			ConductIssue.inputEvents[dropdownId](dropdownId,value);
		}
		else if( typeof ConductIssue.inputEvents[dropdownId] === 'object' && ConductIssue.inputEvents[dropdownId].action !=='undefined'){
			var target = ConductIssue.inputEvents[dropdownId].target;
			ConductIssue.inputEvents[dropdownId].action(value,target);
		}		
	}
}
function inventoryBusinessDays(days){
	if(days[0] >= 0 ){
			$('#leave_length').text(days[0] +' Day(s)');
	}
	else{
		/* bootbox.alert({
		message: 'Invalid leave end date. Leave end date must come after start date.',//'Invalid leave end date. Leave end date must come after start date.',
		callback: function(){
			//FormState.updateObjectValue('','');
		}
	}); */
	$('#leave_length').text('');
	}	
}
function noticeBusinessDays(days){
		if(days[0] >= 0 ){
			$('#leave_length_2').text(days[0] +' Day(s)');
		}
	else {
		/*bootbox.alert({
		message: 'Invalid leave end date. Leave end date must come after start date.',//'Invalid leave end date. Leave end date must come after start date.',
		callback: function(){
			//FormState.updateObjectValue('','');
		}
	}); */
	$('#leave_length_2').text('');
	}	
}
function clear(item){
	if(item.target.id === 'admin_leave_clear'){
		$('#CI_APPROVAL_NAME').val('');
	}
	if(item.target.id === 'admin_leave_ntc_clear'){
		$('#CI_APPROVAL_NAME_2').val('');
	}
	if(item.target.id !=='' && item !== ''){
		$('#' +item).val('');
	}
}
function populateCurrentPosition(item){
	if(item !== undefined && item !== ''){
	var currentPosition = item.split(',');
	$('#CI_POS_TITLE').text(currentPosition[8]);
	$('#CI_PPLAN').text(currentPosition[6]);
	$('#CI_SERIES').text(currentPosition[7]);
	$('#CI_CURRENT_INFO_GRADE').text(currentPosition[4]);
	$('#CI_CURR_ADMIN_CODE').text(currentPosition[2]);//curr_admin_code
	$('#CI_RE_ASSIGNMENT_CURR_ORG').text(currentPosition[3]);//re_assignment_curr_org
	}	
}
	//TODO: Complete this function implementation to compare dates.
function dateValidateHelper(id,id2,target){
	var dt1 =$('#' + id).val();
	var dt2 = $('#' + id2).val();
	if(dt1 !== ''){
		
	}
	if(dt2 !==''){
		
	}
}
function appendAdminCode(item){
		var admin_code = item.adminCode +' - '+item.description;
	return '<a role="option">' + admin_code +'</a>'
}

function populateAdminCode(item){
	$('#CI_FINAL_ADMIN_CODE').val(item.adminCode);
	$('#CI_RE_ASSIGNMENT_FINAL_ORG').text(item.description);
}



function dateAutoPopulate(targetId,sourceValue){
	if(sourceValue !==''){
		$('#' +targetId).val(sourceValue);
	}
}
function populateGrades(e){
		var source = e.target.id;
		var target = '';
		var payPlan = e.target.options[e.target.options.selectedIndex].value;
		if(source === 'CI_PROPOSED_PPLAN'){
			target ='CI_PROPOSED_INFO_GRADE';
		}else{
			target = 'CI_FINAL_INFO_GRADE';
		}
		$('#' +target).html('');
		if(payPlan !=='default' &&  ConductIssue.grades[payPlan] !== undefined){
		 $('#' + target).append('<option value="default">Select one </option>');
		 ConductIssue.grades[payPlan].forEach(function(val){	
			$('#' + target).append('<option value="' + val + '">' + val + '</option>');
		});
		hyf.util.showComponent(target);
	}else{
		hyf.util.hideComponent(target,null);
	}
}
function populateDateItems(displayId,hiddenValue){	
	var hiddenSelection = hiddenValue.split(',');
		if(Array.isArray(hiddenSelection) && hiddenSelection.length > 0){
		$('#' + displayId).html('');
		hiddenSelection.forEach(function(el){
			//append string
		});
	}
}
function populateCIDemotionCurPosnData() {
	var genEmployee = FormState.getElementValue('GEN_EMPLOYEE');
	if (typeof genEmployee == 'undefined' || genEmployee == null || genEmployee.trim().length <= 0) return;
	var dataArray = genEmployee.split(',');
	if (!$.isArray(dataArray) || dataArray.length < 11) return;
	$('#CI_POS_TITLE').text(dataArray[6]);
	$('#CI_PPLAN').text(dataArray[7]);
	$('#CI_SERIES').text(dataArray[8]);
	$('#CI_CURRENT_INFO_STEP').text(dataArray[9]);
	$('#CI_CURRENT_INFO_GRADE').text(dataArray[10]);
	FormState.updateVariableValue('CI_POS_TITLE',dataArray[6], false);
	FormState.updateVariableValue('CI_PPLAN',dataArray[7], false);
	FormState.updateVariableValue('CI_SERIES',dataArray[8], false);
	FormState.updateVariableValue('CI_CURRENT_INFO_STEP',dataArray[9], false);
	FormState.updateVariableValue('CI_CURRENT_INFO_GRADE',dataArray[10], false);
}
//TODO: dynamically hide/show fields based on
function finalAgencyDecision(e){
	var id = '';
	var value;
	try{
		id = e.target.id;
		value = e.target.options[e.target.options.selectedIndex].value;
		finalAgencyDecisionHelper(id,value);
	}catch(err){
		
	}	
}
function finalAgencyDecisionHelper(id,value){
	if(id ==='CI_DEMO_FINAL_AGENCY_DECISION'){
			if(value ==='DemotionRescinded'){
				$('#CI_DEMO_FINAL_AGENCY_EFF_DT').closest('.layoutContainerContent').hide();
				$('#CI_NUMB_DAYS').closest('.layoutContainerContent').hide();
				$('#CI_DEMO_DECISION_ISSUED_DT').closest('.layoutContainerContent').show();
			}else if(value ==='NoDecisionIssued'){
				$('#CI_DEMO_FINAL_AGENCY_EFF_DT').closest('.layoutContainerContent').hide();
				$('#CI_DEMO_DECISION_ISSUED_DT').closest('.layoutContainerContent').hide();
				$('#CI_NUMB_DAYS').closest('.layoutContainerContent').hide();
			}else if(value === 'Suspension'){
				$('#CI_DEMO_FINAL_AGENCY_EFF_DT').closest('.layoutContainerContent').show();
				$('#CI_NUMB_DAYS').closest('.layoutContainerContent').show();
				$('#CI_DEMO_DECISION_ISSUED_DT').closest('.layoutContainerContent').show();
			}else{
				$('#CI_NUMB_DAYS').closest('.layoutContainerContent').hide();
				$('#CI_DEMO_FINAL_AGENCY_EFF_DT').closest('.layoutContainerContent').show();
				$('#CI_DEMO_DECISION_ISSUED_DT').closest('.layoutContainerContent').show();
			}		
		}
		if(id ==='CI_SUSP_FINAL_AGENCY_DECISION'){
			if(value.replace(/\s/g,'') ==='SuspensionRescinded'){
				$('#CI_SUSP_EFFECTIVE_DECISION_DT').closest('.layoutContainerContent').hide();
				$('#CI_SUS_NUMB_DAYS').closest('.layoutContainerContent').hide();
			}else if(value.replace(/\s/g,'') ==='NoDecisionIssued'){
				$('#CI_SUSP_EFFECTIVE_DECISION_DT').closest('.layoutContainerContent').hide();
				$('#CI_SUSP_DECISION_ISSUED_DT').closest('.layoutContainerContent').hide();
				$('#CI_SUS_NUMB_DAYS').closest('.layoutContainerContent').hide();
			}else if((value.replace(/\s/g,'') === 'SuspensionUpheld') || (value.replace(/\s/g,'') === 'SuspensionReduced')){
				$('#CI_SUSP_EFFECTIVE_DECISION_DT').closest('.layoutContainerContent').show();
				$('#CI_SUS_NUMB_DAYS').closest('.layoutContainerContent').show();
				$('#CI_SUSP_DECISION_ISSUED_DT').closest('.layoutContainerContent').show();
			}else{
				$('#CI_SUS_NUMB_DAYS').closest('.layoutContainerContent').hide();
				$('#CI_SUSP_EFFECTIVE_DECISION_DT').closest('.layoutContainerContent').show();
				$('#CI_SUSP_DECISION_ISSUED_DT').closest('.layoutContainerContent').show();
			}
		}
		
		if(id ==='CI_RMVL_FINAL_AGENCY_DECISION'){
			if(value.replace(/\s/g,'') ==='RemovalRescinded'){
				$('#CI_REMOVAL_EFFECTIVE_DT').closest('.layoutContainerContent').hide();
				$('#CI_REMOVAL_DATE_DECISION_ISSUED').closest('.layoutContainerContent').show();
				$('#CI_RMVL_NUMB_DAYS').closest('.layoutContainerContent').hide();
			}else if(value.replace(/\s/g,'') ==='NoDecisionIssued'){
				$('#CI_REMOVAL_EFFECTIVE_DT').closest('.layoutContainerContent').hide();
				$('#CI_REMOVAL_DATE_DECISION_ISSUED').closest('.layoutContainerContent').hide();
				$('#CI_RMVL_NUMB_DAYS').closest('.layoutContainerContent').hide();
			}else if(value.replace(/\s/g,'') === 'Suspension'){
				$('#CI_REMOVAL_EFFECTIVE_DT').closest('.layoutContainerContent').show();
				$('#CI_RMVL_NUMB_DAYS').closest('.layoutContainerContent').show();
				$('#CI_REMOVAL_DATE_DECISION_ISSUED').closest('.layoutContainerContent').show();
			}else{
				$('#CI_RMVL_NUMB_DAYS').closest('.layoutContainerContent').hide();
				$('#CI_REMOVAL_EFFECTIVE_DT').closest('.layoutContainerContent').show();
				$('#CI_REMOVAL_DATE_DECISION_ISSUED').closest('.layoutContainerContent').show();
			}
		}		
}