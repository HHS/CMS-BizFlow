(function (window) {
    var cms_incentives_sam_details = function () {
        var _readOnly = false;
        var _initialized = false;
        var _cocDirector_ac = null;

        function setCOCDirectorAutoCompletion() {
            _cocDirector_ac = cms_incentives_general.setDesignatedUserAutoCompletion("cocDirector", USER_GROUP_KEY.CENTER_OFFICE_CONSORTIUM_DIRECTORS, 0, 1, _readOnly);
        }

        function calculateTotalCompensation(opt) {
            var selecteeSalaryPerAnnum = FormUtility.moneyToNumber(undefined !== opt.selecteeSalaryPerAnnum ? opt.selecteeSalaryPerAnnum : FormState.getElementValue("selecteeSalaryPerAnnum"), 0);
            var bonus = FormUtility.moneyToNumber(undefined !== opt.bonus ? opt.bonus : FormState.getElementValue("selecteeBonus"), 0);

            var total = selecteeSalaryPerAnnum + bonus;
            var value = "$" + total.format();
            FormState.updateDijitInputInner("selecteeTotalCompensation", value);
            cms_incentives_sam_review.onChangeSelecteeTotalCompensation(value);
        }

        function setSelecteeExistingCompensationPackageUsability() {
            var isComponent = activityStep.isSOReview();
            if (isComponent) {
                hyf.util.setComponentVisibility("selecteeECPackage_group", false);
            } else {
                var isEditable = activityStep.isHRSReview() || activityStep.isDGHOReview();
                hyf.util.setComponentUsability("selecteeSalaryPerAnnum", isEditable);
                hyf.util.setComponentUsability("selecteeSalaryType", isEditable);
                hyf.util.setComponentUsability("selecteeBonus", isEditable);
                hyf.util.setComponentUsability("selecteeBenefits", isEditable);
            }
        }

        function setComponentRecommendedSalaryUsability() {
            var isComponent = activityStep.isSOReview();
            hyf.util.setComponentUsability("componentRcmdStep", isComponent);
            hyf.util.setMandatoryConstraint("componentRcmdStep", isComponent);
            hyf.util.setComponentUsability("componentRcmdSalaryPerAnnum", isComponent);
            hyf.util.setMandatoryConstraint("componentRcmdSalaryPerAnnum", isComponent);
            // hyf.util.setComponentUsability("componentRcmdLocalityPayScale", isComponent);

            var componentRcmdGrade = FormState.getElementValue("componentRcmdGrade");
            hyf.util.setComponentVisibility("componentRcmdStep_group", "00" !== componentRcmdGrade);
        }

        function setLocalityPayScaleBox() {
            // LookupManager.fillListBox("componentRcmdLocalityPayScale", "Incentives-Locality");
            LookupManager.fillListBox("hrInitialSalaryLocalityPayScale", "Incentives-Locality");
        }

        function onGradeHidden(visible) {
            var ele = document.getElementById("componentRcmdGrade_group");
            if (ele) {
                ele.parentElement.style.display = visible ? "" : "none";
            }
        }

        function onGradeChanged(grade) {
            hyf.util.setComponentVisibility("componentRcmdStep_group", "00" !== grade);
            if (_initialized) {
                FormState.updateSelectValue("componentRcmdGrade", grade, grade, true);
                FormState.updateTextValue("hrInitialSalaryGrade", grade, true);
            }
        }

        function onSupportSAMChanged(value) {
            hyf.util.setComponentVisibility("componentRcmdFields_group", value === "Yes");

            if (_initialized) {
                cms_incentives_sam_approval.onSupportSAMChanged(value);
                TabManager.setTabHeaderVisibility(MENU_TAB.SAM_JUSTIFICATION, value === "Yes");
            } else if (activityStep.isSOReview()) {
                TabManager.setTabHeaderVisibility(MENU_TAB.SAM_JUSTIFICATION, value === "Yes");
            }
        }

        function validateSupportingDocumentDate(requested, received) {
            var requestedDate = FormUtility.stringToDate(requested, "mm/dd/yyyy", "/");
            var receivedDate = FormUtility.stringToDate(received, "mm/dd/yyyy", "/");
            if (receivedDate) {
                if (!requestedDate || requestedDate.getTime() > receivedDate.getTime()) {
                    return false;
                }
            }

            return true;
        }

        function checkSupportingDocumentDate(requested, received) {
            if (!validateSupportingDocumentDate(requested, received)) {
                setTimeout(function () {
                    FormUtility.displayError("dateSupDocReceived", '"Date Supporting Documents Received" cannot be prior to "Date Supporting Documents Requested"');
                }, 50);
                return false;
            } else {
                var field = document.getElementById("dateSupDocReceived");
                field.removeAttribute("data-wm-error-msg");
            }

            return true;
        }

        function validateForm() {
            return checkSupportingDocumentDate(FormState.getElementValue("dateSupDocRequested"), FormState.getElementValue("dateSupDocReceived"));
        }

        function initEventHandlers() {
            $('#selecteeSalaryPerAnnum').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                calculateTotalCompensation({selecteeSalaryPerAnnum: value});
            });
            $('#selecteeBonus').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                calculateTotalCompensation({bonus: value});
            });
            $('#supportSAM').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onSupportSAMChanged(value);
            });
            $('#dateSupDocRequested').on('change', function (e) {
                var target = e.target;
                var value = target.value;
                checkSupportingDocumentDate(value, FormState.getElementValue("dateSupDocReceived"));
            });
            $('#dateSupDocReceived').on('change', function (e) {
                var target = e.target;
                var value = target.value;
                checkSupportingDocumentDate(FormState.getElementValue("dateSupDocRequested"), value);
            });
            $('#dateSupDocReceived').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                checkSupportingDocumentDate(FormState.getElementValue("dateSupDocRequested"), value);
            });
            $('#dateSupDocReceived').on('focus', function (e) {
                var field = document.getElementById("dateSupDocReceived");
                field.setAttribute("data-wm-error-msg", "This value must not be a future date and a valid date in the format MM/DD/YYYY.");
            });
            $('#hrInitialSalaryLocalityPayScale').on('change', function (e) {
                var target = e.target;
                var value = target.value;
                FormState.updateTextValue("componentRcmdLocalityPayScale", value, true);
            });
        }

        function initComponents() {
            var hrInitialSalaryStep = FormState.getElementValue("hrInitialSalaryStep", "1");
            FormState.updateSelectValue("hrInitialSalaryStep", hrInitialSalaryStep, hrInitialSalaryStep, true);

            hyf.util.setComponentVisibility("compontProposedSalary_group", !activityStep.isStartNew());
            hyf.util.setComponentVisibility("selecteeECPackage_group", !activityStep.isStartNew());

            hyf.util.setComponentUsability("supportSAM_group", activityStep.isSOReview());
            hyf.util.setMandatoryConstraint("supportSAM", activityStep.isSOReview());
            hyf.util.setComponentUsability("hrInitialSalarySalaryPerAnnum", myInfo.isHRS());
            hyf.util.setComponentUsability("hrInitialSalaryLocalityPayScale", myInfo.isHRS());

            hyf.calendar.setDateConstraint("dateSupDocRequested", 'Maximum', 'Today');
            hyf.calendar.setDateConstraint("dateSupDocReceived", 'Maximum', 'Today');

            if (activityStep.isStartNew() || activityStep.isHRSReview() || activityStep.isDGHOReview()) {
                hyf.util.setMandatoryConstraint("dateSupDocRequested", activityStep.isHRSReview());
                hyf.util.setMandatoryConstraint("dateSupDocReceived", activityStep.isHRSReview());
            } else {
                hyf.util.disableComponent("dateSupDocRequested");
                hyf.util.disableComponent("dateSupDocReceived");
            }

            setSelecteeExistingCompensationPackageUsability();
            setComponentRecommendedSalaryUsability();
            setLocalityPayScaleBox();

            setCOCDirectorAutoCompletion();
            if (activityStep.isStartNew()) {
                hyf.util.hideComponent("cocDirector_group");
            } else {
                hyf.util.showComponent("cocDirector_group");
                hyf.util.showComponent("cocDirector_group_bordered");
            }
            if (myInfo.isHRL() || myInfo.isXO() || myInfo.isHRS() || myInfo.isDGHO() || myInfo.isTABG() || myInfo.isOHC()) {
                hyf.util.disableComponent("cocDirector_ac");
            }
            if( myInfo.isSO()) {
                hyf.util.enableComponent("cocDirector_ac");
                hyf.util.setMandatoryConstraint("cocDirector_ac", true);
            }

            var payPlan = FormState.getElementValue('payPlan');
            onGradeHidden(payPlan && 'ES, GP, GR, GS, WG'.indexOf(payPlan) !== -1);
            onGradeChanged(FormState.getElementValue("grade"));
            onSupportSAMChanged(FormState.getElementValue("supportSAM"));
        }

        function init(readOnly) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();

            _initialized = true;
        }

        function render(action) {
        }

        function resetMandatoryFields(value) {
            if (activityStep.isSOReview()) {
                if ("Approve" == value) {
                    hyf.util.setMandatoryConstraint("hrInitialSalarySalaryPerAnnum", true);
                    hyf.util.setMandatoryConstraint("hrInitialSalaryLocalityPayScale", true);
                } else if ("Disapprove" == value) {
                    hyf.util.setMandatoryConstraint("hrInitialSalarySalaryPerAnnum", false);
                    hyf.util.setMandatoryConstraint("hrInitialSalaryLocalityPayScale", false);
                }
            }
        }

        return {
            onGradeChanged: onGradeChanged,
            onGradeHidden: onGradeHidden,
            resetMandatoryFields: resetMandatoryFields,
            init: init,
            render: render,
            validateForm: validateForm
        }
    };

    var _initializer = window.cms_incentives_sam_details || (window.cms_incentives_sam_details = cms_incentives_sam_details());
})(window);
