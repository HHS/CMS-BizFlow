(function (window) {
    var cms_incentives_sam_details = function () {
        var _readOnly = false;
        var _initialized = false;

        function calculateTotalCompensation(opt) {
            var selecteeSalaryPerAnnum = FormUtility.moneyToNumber(undefined !== opt.selecteeSalaryPerAnnum ? opt.selecteeSalaryPerAnnum : FormState.getElementValue("selecteeSalaryPerAnnum"), 0);
            var bonus = FormUtility.moneyToNumber(undefined !== opt.bonus ? opt.bonus : FormState.getElementValue("selecteeBonus"), 0);

            var total = selecteeSalaryPerAnnum + bonus;
            var value = "$" + total.format();
            FormState.updateDijitInputInner("selecteeTotalCompensation", value);
            cms_incentives_sam_review.onChangeSelecteeTotalCompensation(value);
        }

        function setSelecteeExistingCompensationPackageUsability() {
            var isComponent = myInfo.isComponent();
            if (isComponent) {
                hyf.util.setComponentVisibility("selecteeECPackage_group", false);
            } else {
                var isEditable = myInfo.isHRS() || myInfo.isDGHO();
                hyf.util.setComponentUsability("selecteeSalaryPerAnnum", isEditable);
                hyf.util.setComponentUsability("selecteeSalaryType", isEditable);
                hyf.util.setComponentUsability("selecteeBonus", isEditable);
                hyf.util.setComponentUsability("selecteeBenefits", isEditable);
            }
        }

        function setComponentRecommendedSalaryUsability() {
            var isComponent = myInfo.isComponent();
            hyf.util.setComponentUsability("componentRcmdStep", isComponent);
            hyf.util.setComponentUsability("componentRcmdSalaryPerAnnum", isComponent);
            hyf.util.setComponentUsability("componentRcmdLocalityPayScale", isComponent);

            var componentRcmdGrade = FormState.getElementValue("componentRcmdGrade");
            hyf.util.setComponentVisibility("componentRcmdStep_group", "00" !== componentRcmdGrade);
        }

        function setComponentRcmdLocalityPayScaleBox() {
            LookupManager.fillListBox("componentRcmdLocalityPayScale", "Incentives-Locality");
        }

        function onGradeHidden(visible) {
            var ele = document.getElementById("componentRcmdGrade_group");
            ele.parentElement.style.display = visible ? "" : "none";
        }

        function onGradeChanged(grade) {
            hyf.util.setComponentVisibility("componentRcmdStep_group", "00" !== grade);
            if (_initialized) {
                FormState.updateSelectValue("componentRcmdGrade", grade, grade, true);
            }
        }

        function initEventHandlers() {
            $('#selecteeSalaryPerAnnum').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                calculateTotalCompensation({selecteeSalaryPerAnnum: value});
            });
            $('#selecteeBonus').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                calculateTotalCompensation({bonus: value});
            });
        }

        function initComponents() {
            setSelecteeExistingCompensationPackageUsability();
            setComponentRecommendedSalaryUsability();
            setComponentRcmdLocalityPayScaleBox();

            var payPlan = FormState.getElementValue('payPlan');
            onGradeHidden(payPlan && 'ES, GP, GR, GS, WG'.indexOf(payPlan) !== -1);
            onGradeChanged(FormState.getElementValue("grade"));
        }

        function init(readOnly) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();

            _initialized = true;
        }

        function render(action) {
        }

        return {
            onGradeChanged: onGradeChanged,
            onGradeHidden: onGradeHidden,
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_sam_details || (window.cms_incentives_sam_details = cms_incentives_sam_details());
})(window);
