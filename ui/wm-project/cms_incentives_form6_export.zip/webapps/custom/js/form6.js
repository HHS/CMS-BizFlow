(function (window) {
    var cms_incentives_sam_details = function () {
        var _readOnly = false;
        var _initialized = false;

        function calculateTotalCompensation(opt) {
            var salaryPerAnnum = FormUtility.moneyToNumber(undefined !== opt.salaryPerAnnum ? opt.salaryPerAnnum : FormState.getElementValue("salaryPerAnnum"), 0);
            var bonus = FormUtility.moneyToNumber(undefined !== opt.bonus ? opt.bonus : FormState.getElementValue("bonus"), 0);

            var total = salaryPerAnnum + bonus;

            var field = document.getElementById("totalCompensation");
            field.value = "$" + total.format();
            FormState.updateDijitInputInner("totalCompensation", field.value);
        }

        function initEventHandlers() {
            $('#salaryPerAnnum').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                calculateTotalCompensation({salaryPerAnnum: value});
            });
            $('#bonus').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                calculateTotalCompensation({bonus: value});
            });
        }

        function initComponents() {
        }

        function init(readOnly) {
            _readOnly = readOnly;
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_sam_details::init, readOnly ==> ", readOnly);

            initComponents();

            initEventHandlers();

            _initialized = true;
        }

        function render() {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_sam_details::render...");
        }

        return {
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_sam_details || (window.cms_incentives_sam_details = cms_incentives_sam_details());
})(window);
