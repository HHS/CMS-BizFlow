(function (window) {
    var cms_incentives_sam_details = function () {
        var _readOnly = false;
        var _initialized = false;
        var _cocDirector_ac = null;

        function setCOCDirectorAutoCompletion() {
            _cocDirector_ac = cms_incentives_general.setDesignatedUserAutoCompletion("cocDirector", USER_GROUP_KEY.CENTER_OFFICE_CONSORTIUM_DIRECTORS, 0, 1, _readOnly);
        }

        function calculateTotalCompensation(opt) {
            var selecteeSalaryPerAnnum = FormUtility.moneyToNumber(undefined !== opt.selecteeSalaryPerAnnum ? opt.selecteeSalaryPerAnnum : FormState.getElementValue("selecteeSalaryPerAnnum"), 0);
            var bonus = FormUtility.moneyToNumber(undefined !== opt.bonus ? opt.bonus : FormState.getElementValue("selecteeBonus"), 0);

            var total = selecteeSalaryPerAnnum + bonus;
            var value = "$" + total.format();
            FormState.updateDijitInputInner("selecteeTotalCompensation", value);
            cms_incentives_sam_review.onChangeSelecteeTotalCompensation(value);
        }

        function setSelecteeExistingCompensationPackageUsability() {
            var isComponent = activityStep.isSOReview();
            if (isComponent) {
                FormMain.setComponentVisibility("selecteeECPackage_group", false);
            } else {
                var isEditable = activityStep.isHRSReview() || activityStep.isDGHOReview();
                hyf.util.setComponentUsability("selecteeSalaryPerAnnum", isEditable);
                FormMain.setComponentUsability("selecteeSalaryType", isEditable);
                hyf.util.setComponentUsability("selecteeBonus", isEditable);
                hyf.util.setComponentUsability("selecteeBenefits", isEditable);
            }
        }

        function setComponentRecommendedSalaryUsability() {
            var isComponent = activityStep.isSOReview() || activityStep.isCOMPReview();
            FormMain.setComponentUsability("componentRcmdStep", isComponent);
            hyf.util.setMandatoryConstraint("componentRcmdStep", isComponent);
            hyf.util.setComponentUsability("componentRcmdSalaryPerAnnum", isComponent);
            hyf.util.setMandatoryConstraint("componentRcmdSalaryPerAnnum", isComponent);
            // hyf.util.setComponentUsability("componentRcmdLocalityPayScale", isComponent);

            var componentRcmdGrade = FormState.getElementValue("componentRcmdGrade");
            FormMain.setComponentVisibility("componentRcmdStep_group", "00" !== componentRcmdGrade);
        }

        function setLocalityPayScaleBox() {
            // LookupManager.fillListBox("componentRcmdLocalityPayScale", "Incentives-Locality");
            LookupManager.fillListBox("hrInitialSalaryLocalityPayScale", "Incentives-Locality");
        }

        function onGradeHidden(visible) {
            var ele = document.getElementById("componentRcmdGrade_group");
            if (ele) {
                ele.parentElement.style.display = visible ? "" : "none";
            }
        }

        function onGradeChanged(grade) {
            FormMain.setComponentVisibility("componentRcmdStep_group", "00" !== grade);
            if (_initialized) {
                FormState.updateSelectValue("componentRcmdGrade", grade, grade, true);
                FormState.updateTextValue("hrInitialSalaryGrade", grade, true);
            }
        }

        function onSupportSAMChanged(value) {
            FormMain.setComponentVisibility("componentRcmdFields_group", value === "Yes");

            if (_initialized) {
                cms_incentives_sam_approval.onSupportSAMChanged(value);
                TabManager.setTabHeaderVisibility(MENU_TAB.SAM_JUSTIFICATION, value === "Yes");
            } else if (activityStep.isSOReview()) {
                TabManager.setTabHeaderVisibility(MENU_TAB.SAM_JUSTIFICATION, value === "Yes");
            }
            FormMain.setComponentVisibility("cocDirector_group", value === "Yes");
            FormMain.setComponentVisibility("cocDirector_group_bordered", value === "Yes");
            if( myInfo.isSO()) {
                hyf.util.enableComponent("cocDirector_ac");
                if (value === "Yes") {
                    hyf.util.setMandatoryConstraint("cocDirector_ac", true);
                } else {
                    hyf.util.setMandatoryConstraint("cocDirector_ac", false);
                }
            }
            var processName = FormMain.getProcessInfo().process.definitionName;
            if ((processName === PROCESS_NAME.SAM_V2) && activityStep.isSOReview()) {
                if ("undefined" != typeof(value)) {
                    if ("Yes" == value) {
                        $("#button_SubmitWorkitem").attr({
                            "value": "Send to Center/Office",
                            "title": "Click to send to the Center/Office/Consortium Director",
                            "responseName": "OnGoing"
                        });

                        $("#button_SendTo1").attr({
                            "value": "Send to HR",
                            "title": "Click the button to send to the HR Specialist",
                            "responseName": "SendToHR"
                        });
                        hyf.util.showComponent('button_SendTo1');

                        var approvalCOCValue = FormState.getElementValue("approvalCOCValue", "");
                        if ((($("#approvalSOCheck").length == 0) || $("#approvalSOCheck").is(':checked')) && (("Approve" == approvalCOCValue) || ("Disapprove" == approvalCOCValue))) {
                            hyf.util.setComponentUsability('button_SentTo1', true); // Send to HR
                            hyf.util.setComponentUsability('button_SubmitWorkitem', false); // Send to Center/Office
                        } else {
                            hyf.util.setComponentUsability('button_SentTo1', false); // Send to HR
                            hyf.util.setComponentUsability('button_SubmitWorkitem', true); // Send to Center/Office
                        }
                    } else if ("No" == value) {
                        // Go to HR Specialist Records Candidate Acceptance or Rejection
                        $("#button_SubmitWorkitem").attr({
                            "value": "Send to HR",
                            "title": "Click to send to the HR Specialist",
                            "responseName": "OnGoing"
                        });
                        hyf.util.hideComponent('button_SendTo1');
                    }
                }
            }
        }

        function validateSupportingDocumentDate(requested, received) {
            var requestedDate = FormUtility.stringToDate(requested, "mm/dd/yyyy", "/");
            var receivedDate = FormUtility.stringToDate(received, "mm/dd/yyyy", "/");
            if (receivedDate) {
                if (!requestedDate || requestedDate.getTime() > receivedDate.getTime()) {
                    return false;
                }
            }

            return true;
        }

        function checkSupportingDocumentDate(requested, received) {
            if (!validateSupportingDocumentDate(requested, received)) {
                setTimeout(function () {
                    FormUtility.displayError("dateSupDocReceived", '"Date Supporting Documents Received" cannot be prior to "Date Supporting Documents Requested"');
                }, 50);
                return false;
            } else {
                var field = document.getElementById("dateSupDocReceived");
                field.removeAttribute("data-wm-error-msg");
            }

            return true;
        }

        function validateForm() {
            return checkSupportingDocumentDate(FormState.getElementValue("dateSupDocRequested"), FormState.getElementValue("dateSupDocReceived"));
        }

        function initEventHandlers() {
            $('#selecteeSalaryPerAnnum').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                calculateTotalCompensation({selecteeSalaryPerAnnum: value});
            });
            $('#selecteeBonus').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                calculateTotalCompensation({bonus: value});
            });
            $('#supportSAM').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onSupportSAMChanged(value);
            });
            $('#dateSupDocRequested').on('change', function (e) {
                var target = e.target;
                var value = target.value;
                checkSupportingDocumentDate(value, FormState.getElementValue("dateSupDocReceived"));
            });
            $('#dateSupDocReceived').on('change', function (e) {
                var target = e.target;
                var value = target.value;
                checkSupportingDocumentDate(FormState.getElementValue("dateSupDocRequested"), value);
            });
            $('#dateSupDocReceived').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                checkSupportingDocumentDate(FormState.getElementValue("dateSupDocRequested"), value);
            });
            $('#dateSupDocReceived').on('focus', function (e) {
                var field = document.getElementById("dateSupDocReceived");
                field.setAttribute("data-wm-error-msg", "This value must not be a future date and a valid date in the format MM/DD/YYYY.");
            });
            $('#hrInitialSalaryLocalityPayScale').on('change', function (e) {
                var target = e.target;
                var value = target.value;
                FormState.updateTextValue("componentRcmdLocalityPayScale", value, true);
            });
        }

        function initComponents() {
            var hrInitialSalaryStep = FormState.getElementValue("hrInitialSalaryStep", "1");
            FormState.updateSelectValue("hrInitialSalaryStep", hrInitialSalaryStep, hrInitialSalaryStep, true);

            FormMain.setComponentVisibility("compontProposedSalary_group", !activityStep.isStartNew());
            FormMain.setComponentVisibility("selecteeECPackage_group", !activityStep.isStartNew());

            hyf.util.setComponentUsability("supportSAM_group", activityStep.isSOReview() || activityStep.isCOMPReview());
            hyf.util.setMandatoryConstraint("supportSAM", activityStep.isSOReview() || activityStep.isCOMPReview());
            var hrInitialSalaryGroupEnabled = true;
            if (activityStep.isHRSRecordConclusion() || activityStep.isHRSReview()) {
                hrInitialSalaryGroupEnabled = false;
                hyf.util.setComponentUsability("hrInitialSalaryGrade", hrInitialSalaryGroupEnabled);
            } else {
                hrInitialSalaryGroupEnabled = myInfo.isHRS();
            }
            FormMain.setComponentUsability("hrInitialSalaryStep", hrInitialSalaryGroupEnabled);
            hyf.util.setComponentUsability("hrInitialSalarySalaryPerAnnum", hrInitialSalaryGroupEnabled);
            hyf.util.setComponentUsability("hrInitialSalaryLocalityPayScale", hrInitialSalaryGroupEnabled);

            hyf.calendar.setDateConstraint("dateSupDocRequested", 'Maximum', 'Today');
            hyf.calendar.setDateConstraint("dateSupDocReceived", 'Maximum', 'Today');

            if (activityStep.isStartNew() || activityStep.isHRSReview() || activityStep.isDGHOReview()) {
                hyf.util.setMandatoryConstraint("dateSupDocRequested", activityStep.isHRSReview());
                hyf.util.setMandatoryConstraint("dateSupDocReceived", activityStep.isHRSReview());
            } else {
                hyf.util.disableComponent("dateSupDocRequested");
                hyf.util.disableComponent("dateSupDocReceived");
            }

            setSelecteeExistingCompensationPackageUsability();
            setComponentRecommendedSalaryUsability();
            setLocalityPayScaleBox();

            setCOCDirectorAutoCompletion();

            if (myInfo.isHRL() || myInfo.isXO() || myInfo.isHRS() || myInfo.isDGHO() || myInfo.isTABG() || myInfo.isOHC()) {
                hyf.util.disableComponent("cocDirector_ac");
                try {
                    $("#cocDirector_ac_DISP > li > img").hide();
                } catch(e) {
                }
            }
            if (activityStep.isCOMPReview()) {
                hyf.util.setMandatoryConstraint("supportSAM", false);
                hyf.util.setMandatoryConstraint("cocDirector_ac", false);
            }

            var payPlan = FormState.getElementValue('payPlan');
            onGradeHidden(payPlan && 'ES, GP, GR, GS, WG'.indexOf(payPlan) !== -1);
            onGradeChanged(FormState.getElementValue("grade"));
            onSupportSAMChanged(FormState.getElementValue("supportSAM"));
        }

        function init(readOnly, tabObject) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();
            FormMain.resetMandatoryMark(tabObject);

            _initialized = true;
        }

        function render(action) {
        }

        function resetMandatoryFields(value) {
            if (activityStep.isSOReview()) {
                if ("Approve" == value) {
                    hyf.util.setMandatoryConstraint("hrInitialSalarySalaryPerAnnum", true);
                    hyf.util.setMandatoryConstraint("hrInitialSalaryLocalityPayScale", true);
                } else if ("Disapprove" == value) {
                    hyf.util.setMandatoryConstraint("hrInitialSalarySalaryPerAnnum", false);
                    hyf.util.setMandatoryConstraint("hrInitialSalaryLocalityPayScale", false);
                }
            }
        }

        return {
            onGradeChanged: onGradeChanged,
            onGradeHidden: onGradeHidden,
            resetMandatoryFields: resetMandatoryFields,
            init: init,
            render: render,
            validateForm: validateForm
        }
    };

    var _initializer = window.cms_incentives_sam_details || (window.cms_incentives_sam_details = cms_incentives_sam_details());
})(window);
