(function (window) {
    var cms_incentives_sam_details = function () {
        var _readOnly = false;
        var _initialized = false;

        function calculateTotalCompensation(opt) {
            var selecteeSalaryPerAnnum = FormUtility.moneyToNumber(undefined !== opt.selecteeSalaryPerAnnum ? opt.selecteeSalaryPerAnnum : FormState.getElementValue("selecteeSalaryPerAnnum"), 0);
            var bonus = FormUtility.moneyToNumber(undefined !== opt.bonus ? opt.bonus : FormState.getElementValue("selecteeBonus"), 0);

            var total = selecteeSalaryPerAnnum + bonus;

            var field = document.getElementById("selecteeTotalCompensation");
            field.value = "$" + total.format();
            FormState.updateDijitInputInner("selecteeTotalCompensation", field.value);
        }

        function setSelecteeExistingCompensationPackageUsability() {
            var isComponent = myInfo.isComponent();
            if (isComponent) {
                hyf.util.setComponentVisibility("selecteeECPackage_group", false);
            } else {
                var isEditable = myInfo.isHRS() || myInfo.isDGHO();
                hyf.util.setComponentUsability("selecteeSalaryPerAnnum", isEditable);
                hyf.util.setComponentUsability("selecteeSalaryType", isEditable);
                hyf.util.setComponentUsability("selecteeBonus", isEditable);
                hyf.util.setComponentUsability("selecteeBenefits", isEditable);
            }
        }

        function setComponentRecommendedSalaryUsability() {
            var isComponent = myInfo.isComponent();
            // hyf.util.setComponentUsability("componentRcmdGrade", isComponent);
            hyf.util.setComponentUsability("componentRcmdStep", isComponent);
            hyf.util.setComponentUsability("componentRcmdSalaryPerAnnum", isComponent);
            hyf.util.setComponentUsability("componentRcmdLocalityPayScale", isComponent);
        }

        function setComponentRcmdLocalityPayScaleBox() {
            var localities = LookupManager.findByLTYPE('Incentives-Locality');

            var selObj = $("#componentRcmdLocalityPayScale");

            selObj.children('option:not(:first)').remove();
            if (localities.length > 0) {
                for (var i = 0; i < localities.length; i++) {
                    var item = localities[i];
                    if (item) {
                        selObj.append($("<option></option>").attr("value", item.NAME).text(item.LABEL));
                    }
                }
            }
        }

        function onGradeChanged(grade) {
            FormState.updateSelectValue("componentRcmdGrade", grade, grade, true);
        }

        function initEventHandlers() {
            $('#selecteeSalaryPerAnnum').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                calculateTotalCompensation({selecteeSalaryPerAnnum: value});
            });
            $('#selecteeBonus').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                calculateTotalCompensation({bonus: value});
            });
        }

        function initComponents() {
            setSelecteeExistingCompensationPackageUsability();
            setComponentRecommendedSalaryUsability();
            setComponentRcmdLocalityPayScaleBox();
        }

        function init(readOnly) {
            _readOnly = readOnly;
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_sam_details::init, readOnly ==> ", readOnly);

            initComponents();
            initEventHandlers();

            _initialized = true;
        }

        function render(action) {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_sam_details::render..., action ==> ", action);
        }

        return {
            onGradeChanged: onGradeChanged,
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_sam_details || (window.cms_incentives_sam_details = cms_incentives_sam_details());
})(window);
