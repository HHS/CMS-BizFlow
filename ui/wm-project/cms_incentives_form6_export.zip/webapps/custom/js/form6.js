(function (window) {
    var cms_incentives_sam_details = function () {
        var _readOnly = false;
        var _initialized = false;
        var _cocDirector_ac = null;

        function setCOCDirectorAutoCompletion() {
            _cocDirector_ac = cms_incentives_general.setDesignatedUserAutoCompletion("cocDirector", USER_GROUP_KEY.CENTER_OFFICE_CONSORTIUM_DIRECTORS, 0, 1, _readOnly);
        }

        function calculateTotalCompensation(opt) {
            var selecteeSalaryPerAnnum = FormUtility.moneyToNumber(undefined !== opt.selecteeSalaryPerAnnum ? opt.selecteeSalaryPerAnnum : FormState.getElementValue("selecteeSalaryPerAnnum"), 0);
            var bonus = FormUtility.moneyToNumber(undefined !== opt.bonus ? opt.bonus : FormState.getElementValue("selecteeBonus"), 0);

            var total = selecteeSalaryPerAnnum + bonus;
            var value = "$" + total.format();
            FormState.updateDijitInputInner("selecteeTotalCompensation", value);
            if (cms_incentives_sam_review) {
                cms_incentives_sam_review.onChangeSelecteeTotalCompensation(value);
            }
        }

        function setSelecteeExistingCompensationPackageUsability() {
            var isComponent = activityStep.isSOReview() || activityStep.isCOMPReview() || activityStep.isCOCReview() || activityStep.isCOMPReviewForModification() || activityStep.isHRSReviewForModification();
            if (isComponent) {
                FormMain.setComponentVisibility("selecteeECPackage_group", false);
            } else {
                var isEditable = activityStep.isHRSReview() || activityStep.isDGHOReview();
                hyf.util.setComponentUsability("selecteeSalaryPerAnnum", isEditable);
                FormMain.setComponentUsability("selecteeSalaryType", isEditable);
                hyf.util.setComponentUsability("selecteeBonus", isEditable);
                hyf.util.setComponentUsability("selecteeBenefits", isEditable);
            }
        }

        function setComponentRcmdStepVisibility(payPlan, grade) {
            // var visible = ("00" !== grade) && ("" !== grade) && ("ED, EE, EF, EG, ES, EX".indexOf(payPlan) == -1);
            var visible = ("ED, EE, EF, EG, ES, EX".indexOf(payPlan) == -1);
            if (!visible) {
                FormMain.setComponentVisibility("componentRcmdStep_group", false);
                // FormMain.setComponentUsability("componentRcmdStep", false);
                // FormMain.setMandatoryConstraint("componentRcmdStep", false);
            } else {
                FormMain.setComponentVisibility("componentRcmdStep_group", true);
                // FormMain.setComponentUsability("componentRcmdStep", true);
                // FormMain.setMandatoryConstraint("componentRcmdStep", true);
            }
        }

        function setComponentRecommendedSalaryUsability() {
            var isComponent = activityStep.isSOReview() || activityStep.isCOMPReview() || activityStep.isCOMPReviewForModification();
            if (!isComponent) {
                FormMain.setMandatoryConstraint("componentRcmdStep", isComponent);
                FormMain.setMandatoryConstraint("componentRcmdSalaryPerAnnum", isComponent);
                FormMain.setComponentUsability("componentRcmdStep", isComponent);
                hyf.util.setComponentUsability("componentRcmdSalaryPerAnnum", isComponent);
            } else {
                FormMain.setComponentUsability("componentRcmdStep", isComponent);
                hyf.util.setComponentUsability("componentRcmdSalaryPerAnnum", isComponent);
                if (activityStep.isCOMPReview() || activityStep.isCOMPReviewForModification()) {
                    FormMain.setMandatoryConstraint("componentRcmdStep", false);
                    FormMain.setMandatoryConstraint("componentRcmdSalaryPerAnnum", false);
                } else {
                    FormMain.setMandatoryConstraint("componentRcmdStep", isComponent);
                    FormMain.setMandatoryConstraint("componentRcmdSalaryPerAnnum", isComponent);
                }
            }

            var grade = FormState.getElementValue("componentRcmdGrade");
            setComponentRcmdStepVisibility(FormState.getElementValue("payPlan", ""), grade);
            hyf.util.setComponentUsability("componentRcmdLocalityPayScale", false);
        }

        function setLocalityPayScaleBox() {
            // LookupManager.fillListBox("componentRcmdLocalityPayScale", "Incentives-Locality");
            LookupManager.fillListBox("hrInitialSalaryLocalityPayScale", "Incentives-Locality");
        }

        function onGradeHidden(visible) {
            var ele = document.getElementById("componentRcmdGrade_group");
            if (ele) {
                ele.parentElement.style.display = visible ? "" : "none";
            }
        }

        function onGradeChanged(grade) {
            setComponentRcmdStepVisibility(FormState.getElementValue("payPlan", ""), grade);
            if (_initialized) {
                FormState.updateSelectValue("componentRcmdGrade", grade, grade, true);
                FormState.updateTextValue("hrInitialSalaryGrade", grade, true);
            }
        }

        function onPayPlanChanged(payPlan) {
            if ("ED, EE, EF, EG, ES, EX".indexOf(payPlan) > -1) {
                FormMain.setComponentVisibility("hrInitialSalaryStep", false);
                hyf.util.setComponentVisibility("hrInitialSalaryStep_label_container", false);
            } else {
                FormMain.setComponentVisibility("hrInitialSalaryStep", true);
                hyf.util.setComponentVisibility("hrInitialSalaryStep_label_container", true);
            }
            var grade = FormState.getElementValue("componentRcmdGrade");
            setComponentRcmdStepVisibility(payPlan, grade);
        }

        function onSupportSAMChanged(value) {
            FormMain.setComponentVisibility("componentRcmdFields_group", value === "Yes");
            try {
                $("#componentRcmdGrade_marker, #componentRcmdStep_marker, #componentRcmdSalaryPerAnnum_marker, #componentRcmdLocalityPayScale_marker").show();
            } catch(e) {
            }

            if (_initialized) {
                if (cms_incentives_sam_approval) {
                    cms_incentives_sam_approval.onSupportSAMChanged(value);
                }
                TabManager.setTabHeaderVisibility(MENU_TAB.SAM_JUSTIFICATION, value === "Yes");
            } else {
                TabManager.setTabHeaderVisibility(MENU_TAB.SAM_JUSTIFICATION, value === "Yes");
            }
            FormMain.setComponentVisibility("cocDirector_group", value === "Yes");
            FormMain.setComponentVisibility("cocDirector_group_bordered", value === "Yes");
            if (!_readOnly && (activityStep.isSOReview() || activityStep.isCOMPReview() || activityStep.isCOMPReviewForModification())) {
                hyf.util.enableComponent("cocDirector_ac");
                if (value === "Yes") {
                    FormMain.setMandatoryConstraint("cocDirector_ac", true);
                } else {
                    FormMain.setMandatoryConstraint("cocDirector_ac", false);
                }
                try {
                    $("#cocDirector_ac_DISP > li > .removeButton").show();
                } catch(e) {
                }
            }
            var processName = FormMain.getProcessInfo().process.definitionName;
            if ((processName === PROCESS_NAME.SAM_V2) && activityStep.isSOReview()) {
                if ("undefined" != typeof(value)) {
                    if ("Yes" == value) {
                        $("#button_SubmitWorkitem").attr({
                            "value": "Send to Center/Office",
                            "title": "Click to send to the Center/Office/Consortium Director",
                            "responseName": "OnGoing"
                        });

                        $("#button_SendTo1").attr({
                            "value": "Send to HR",
                            "title": "Click the button to send to the HR Specialist",
                            "responseName": "SendToHR"
                        });
                        hyf.util.showComponent('button_SendTo1');
                        var approvalCOCValue = FormState.getElementValue("approvalCOCValue", "");
                        var approvalChecked = (($("#approvalCOCCheck").length == 0) || $("#approvalCOCCheck").is(':checked')) && (("Approve" == approvalCOCValue) || ("Disapprove" == approvalCOCValue));
                        if(approvalChecked) {
                            var approvalCOCActing = FormState.getElementValue("approvalCOCActing", "");
                            if (approvalCOCActing != "Yes") {
                                approvalChecked = false;
                            }
                            if ($("#approvalCOCActing").length > 0) {
                                if($("#approvalCOCActing").is(':disabled')) {
                                    //
                                } else {
                                    approvalChecked = true;
                                }
                            }
                        }
                        if(_initialized) {
                            if (approvalChecked) {
                                hyf.util.setComponentUsability('button_SendTo1', true); // Send to HR
                                hyf.util.setComponentUsability('button_SubmitWorkitem', false); // Send to Center/Office
                            } else {
                                hyf.util.setComponentUsability('button_SendTo1', false); // Send to HR
                                hyf.util.setComponentUsability('button_SubmitWorkitem', true); // Send to Center/Office
                            }
                        }
                    } else if ("No" == value) {
                        // Go to HR Specialist Records Candidate Acceptance or Rejection
                        $("#button_SubmitWorkitem").attr({
                            "value": "Send to HR",
                            "title": "Click to send to the HR Specialist",
                            "responseName": "OnGoing"
                        });
                        hyf.util.hideComponent('button_SendTo1');
                    }
                }
            }
            if(_initialized) {
                if (activityStep.isCOMPReviewForModification()) {
                    if ("undefined" != typeof (value)) {
                        if ("Yes" == value) {
                            hyf.util.setComponentUsability('button_SendTo2', true);
                        } else if ("No" == value) {
                            hyf.util.setComponentUsability('button_SendTo2', false);
                        }
                    }
                }
                resetUsability();
            }
        }

        function validateSupportingDocumentDate(requested, received) {
            var requestedDate = FormUtility.stringToDate(requested, "mm/dd/yyyy", "/");
            var receivedDate = FormUtility.stringToDate(received, "mm/dd/yyyy", "/");
            if (receivedDate) {
                if (!requestedDate || requestedDate.getTime() > receivedDate.getTime()) {
                    return false;
                }
            }

            return true;
        }

        function checkSupportingDocumentDate(requested, received) {
            if (!validateSupportingDocumentDate(requested, received)) {
                setTimeout(function () {
                    FormUtility.displayError("dateSupDocReceived", '"Date Supporting Documents Received" cannot be prior to "Date Supporting Documents Requested"');
                }, 50);
                return false;
            } else {
                var field = document.getElementById("dateSupDocReceived");
                field.removeAttribute("data-wm-error-msg");
            }

            return true;
        }

        function validateForm() {
            return checkSupportingDocumentDate(FormState.getElementValue("dateSupDocRequested"), FormState.getElementValue("dateSupDocReceived"));
        }

        function initEventHandlers() {
            $('#selecteeSalaryPerAnnum').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                calculateTotalCompensation({selecteeSalaryPerAnnum: value});
            });
            $('#selecteeBonus').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                calculateTotalCompensation({bonus: value});
            });
            $('#supportSAM').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onSupportSAMChanged(value);
            });
            $('#dateSupDocRequested').on('change', function (e) {
                var target = e.target;
                var value = target.value;
                checkSupportingDocumentDate(value, FormState.getElementValue("dateSupDocReceived"));
            });
            $('#dateSupDocReceived').on('change', function (e) {
                var target = e.target;
                var value = target.value;
                checkSupportingDocumentDate(FormState.getElementValue("dateSupDocRequested"), value);
            });
            $('#dateSupDocReceived').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                checkSupportingDocumentDate(FormState.getElementValue("dateSupDocRequested"), value);
            });
            $('#dateSupDocReceived').on('focus', function (e) {
                var field = document.getElementById("dateSupDocReceived");
                field.setAttribute("data-wm-error-msg", "This value must not be a future date and a valid date in the format MM/DD/YYYY.");
            });
            $('#hrInitialSalaryLocalityPayScale').on('change', function (e) {
                var target = e.target;
                var value = target.value;
                FormState.updateTextValue("componentRcmdLocalityPayScale", value, true);
                hyf.util.setComponentUsability("componentRcmdLocalityPayScale", false);
            });
        }

        function resetUsability(callFromApproval) {
            if ("undefined" == typeof(callFromApproval)) {
                callFromApproval = false;
            }
            if (callFromApproval && !_initialized) {
                return;
            }

            hyf.util.setComponentUsability("supportSAM_group", activityStep.isSOReview() || activityStep.isCOMPReview() || activityStep.isCOMPReviewForModification());
            FormMain.setMandatoryConstraint("supportSAM", activityStep.isSOReview() || activityStep.isCOMPReview() || activityStep.isCOMPReviewForModification());
            var hrInitialSalaryGroupEnabled = true;
            if (activityStep.isHRSRecordConclusion() || activityStep.isHRSReview()) {
                hrInitialSalaryGroupEnabled = false;
            } else {
                hrInitialSalaryGroupEnabled = myInfo.isHRS();
            }
            hyf.util.setComponentUsability("hrInitialSalaryGrade", hrInitialSalaryGroupEnabled);

            onPayPlanChanged(FormState.getElementValue("payPlan", ""));

            FormMain.setComponentUsability("hrInitialSalaryStep", hrInitialSalaryGroupEnabled);
            FormMain.setMandatoryConstraint("hrInitialSalaryStep", hrInitialSalaryGroupEnabled);
            hyf.util.setComponentUsability("hrInitialSalarySalaryPerAnnum", hrInitialSalaryGroupEnabled);
            FormMain.setMandatoryConstraint("hrInitialSalarySalaryPerAnnum", hrInitialSalaryGroupEnabled);
            hyf.util.setComponentUsability("hrInitialSalaryLocalityPayScale", hrInitialSalaryGroupEnabled);
            FormMain.setMandatoryConstraint("hrInitialSalaryLocalityPayScale", hrInitialSalaryGroupEnabled);

            if(!callFromApproval) {
                hyf.calendar.setDateConstraint("dateSupDocRequested", 'Maximum', 'Today');
                hyf.calendar.setDateConstraint("dateSupDocReceived", 'Maximum', 'Today');
            }

            if (activityStep.isStartNew() || activityStep.isHRSReview() || activityStep.isDGHOReview()) {
                FormMain.setMandatoryConstraint("dateSupDocRequested", activityStep.isHRSReview());
                FormMain.setMandatoryConstraint("dateSupDocReceived", activityStep.isHRSReview());
            } else {
                hyf.util.disableComponent("dateSupDocRequested");
                hyf.util.disableComponent("dateSupDocReceived");
            }

            setSelecteeExistingCompensationPackageUsability();
            setComponentRecommendedSalaryUsability();
            if(!_initialized) {
                setLocalityPayScaleBox();
                setCOCDirectorAutoCompletion();
            }


            var isComponent = activityStep.isSOReview() || activityStep.isCOMPReview() || activityStep.isCOMPReviewForModification();
            if (_readOnly || !isComponent ) {
            // if (myInfo.isHRL() || myInfo.isXO() || myInfo.isHRS() || myInfo.isDGHO() || myInfo.isTABG() || myInfo.isOHC()) {
                hyf.util.disableComponent("cocDirector_ac");
                try {
                    $("#cocDirector_ac_DISP > li > .removeButton").hide();
                } catch(e) {
                }
            }
            if (activityStep.isCOMPReview()) {
                FormMain.setMandatoryConstraint("supportSAM", false);
                FormMain.setMandatoryConstraint("cocDirector_ac", false);
                FormMain.setMandatoryConstraint("componentRcmdStep", false);
                FormMain.setMandatoryConstraint("componentRcmdSalaryPerAnnum", false);
                try {
                    $("#cocDirector_ac_DISP > li > .removeButton").hide();
                } catch(e) {
                }
            } else if (activityStep.isCOMPReviewForModification()) {
                FormMain.setMandatoryConstraint("cocDirector_ac", true);
                try {
                    $("#cocDirector_ac_DISP > li > .removeButton").show();
                } catch(e) {
                }
            }

            var payPlan = FormState.getElementValue('payPlan');
            onGradeHidden(payPlan && 'ES, GP, GR, GS, WG'.indexOf(payPlan) !== -1);
            onGradeChanged(FormState.getElementValue("grade"));
        }

        function initComponents() {
            var hrInitialSalaryStep = FormState.getElementValue("hrInitialSalaryStep", "1");
            FormState.updateSelectValue("hrInitialSalaryStep", hrInitialSalaryStep, hrInitialSalaryStep, true);

            FormMain.setComponentVisibility("compontProposedSalary_group", !activityStep.isStartNew());
            FormMain.setComponentVisibility("selecteeECPackage_group", !activityStep.isStartNew());

            resetUsability();

            onSupportSAMChanged(FormState.getElementValue("supportSAM"));
        }

        function init(readOnly, tabObject) {
            _readOnly = readOnly;
            if(tabObject && tabObject.readonly) {
                _readOnly = true;
            }

            initComponents();
            initEventHandlers();
            FormMain.resetMandatoryMark(tabObject);

            _initialized = true;
        }

        function render(action) {
        }

        function resetUsabilitySupportSAM() {
            resetUsability(true);
        }

        return {
            onGradeChanged: onGradeChanged,
            onGradeHidden: onGradeHidden,
            resetUsabilitySupportSAM: resetUsabilitySupportSAM,
            onPayPlanChanged: onPayPlanChanged,
            init: init,
            render: render,
            validateForm: validateForm
        }
    };

    var _initializer = window.cms_incentives_sam_details || (window.cms_incentives_sam_details = cms_incentives_sam_details());
})(window);
