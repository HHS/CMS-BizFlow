(function (window) {
    var cms_incentives_le_justification = function () {
        var _readOnly = false;
        var _initialized = false;
        var _dialog_leJustificationModificationReason_ac = null;

        function setDialogJustificationModificationReasonAutoCompletion() {
            FormState.updateObjectValue("dialog_leJustificationModificationReason", [], false);
            var option = {
                id: 'dialog_leJustificationModificationReason',
                useAddButton: true,
                addButtonTooltip: "Click the button to add a selection to the Modification Reason list",
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                minSelectionCount: 1,
                maxSelectionCount: 3,
                readOnly: _readOnly,

                mapFunction: function (context) {
                },
                getSelectionLabel: function (item) {
                    return item.text;
                },
                getCandidateLabel: function (item) {
                    return item.value;
                },
                getItemID: function (item) {
                    return item.value;
                },
                setDataToForm: function (values) {
                    FormState.updateObjectValue('dialog_leJustificationModificationReason', values);
                },
                sortSelectedValues: function (values) {
                    var other = null;
                    for (var i = 0; i < values.length; i++) {
                        var item = values[i];
                        if (item.value === 'Other') {
                            other = item;
                            values.splice(i, 1);
                            break;
                        }
                    }

                    values.sort(function (a, b) {
                        return a.value > b.value;
                    });

                    if (other !== null) {
                        values.push(item);
                    }

                    return values;
                },
                isValidListItem: function (item, target) {
                    return item.value !== "";
                },
                afterItemDisplayed: function (containerId, item) {
                    FormUtility.removeSelectOption(item.value, "dialog_leJustificationModificationReason");
                },
                afterItemDeleted: function (containerId, targetId, item, values) {
                    var target = FormUtility.addSelectionAndSortExceptLast(item.text, item.value, "dialog_leJustificationModificationReason", "Other");
                    target.selectedIndex = values.length === 0 ? 0 : -1;
                },
                initialItems: FormState.getElementArrayValue('dialog_leJustificationModificationReason', [])
            };

            _dialog_leJustificationModificationReason_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        function setJustificationModificationReason() {
            var reasons = FormState.getElementArrayValue('dialog_leJustificationModificationReason', []);
            var mergedReason = "";
            var reasonArray = [];
            var i = 0;
            if (reasons.length > 0) {
                for (i = 0; i < reasons.length; i++) {
                    reasonArray.push(reasons[i].text);
                }
                mergedReason = reasonArray.join(", ");
            }
            FormState.updateTextValue("leJustificationModificationReason", mergedReason, false);
        }

        function initEventHandlers() {
            initModifyJustification();
            initJustificationHistory();
            setDialogJustificationModificationReasonAutoCompletion();
        }

        function setModifiedInfo(eleId, dateEleId) {
            var currentUserName = myInfo.getMyName();
            var currentUserId = myInfo.getMyMemberId();
            var currentDate = FormUtility.getDateString(false, "mm/dd/yyyy HH:MM:ss", new Date());

            $("#" + eleId).val(currentUserName);
            $("#" + dateEleId).val(currentDate);

            FormState.updateTextValue(eleId, currentUserName, false);
            FormState.updateTextValue(eleId + "Id", currentUserId, false);
            FormState.updateDateValue(dateEleId, currentDate, false);
        }

        function modifyJustification() {
            FormState.updateObjectValue("dialog_leJustificationModificationReason", [], false);
            _dialog_leJustificationModificationReason_ac.deleteAllItems();

            $("#dialog_leJustificationModificationSummary").val("");
            $("#dialog_leJustificationSkillAndExperience_modify").val($("#justificationSkillAndExperience").val());
            $("#dialog_leJustificationAgencyMissionOrPerformanceGoal_modify").val($("#justificationAgencyMissionOrPerformanceGoal").val());

            var cancelCallbackHandler = function() {
                $("#dialog_leJustificationSkillAndExperience_modify").val($("#justificationSkillAndExperience").val());
                $("#dialog_leJustificationAgencyMissionOrPerformanceGoal_modify").val($("#justificationAgencyMissionOrPerformanceGoal").val());

                $("#dialog_leJustificationModifyContent_group_parent").empty();
                $("#dialog_leJustificationModifyContent_group").addClass('hide');
                $("#dialog_leJustificationModifyContent_group").appendTo("#dialog_leJustificationModifyContent_group_parent");
            };

            var inputDialogOption = {
                onEscape: cancelCallbackHandler,
                animate: false,
                size: "large",
                buttons: {
                    cancel:{
                        label: 'Cancel',
                        className: 'btn-default',
                        callback: cancelCallbackHandler
                    },
                    confirm: {
                        label: 'Update',
                        className: 'btn-primary',
                        callback: function(){
                            var valid = true;
                            var $dialogForm = $('#dialog_leJustificationModifyContent_group');
                            $dialogForm.find('INPUT,SELECT.select,textarea.textbox').each(function(i,v){
                                var fieldId = $(this).attr("id");
                                if(fieldId){
                                    valid = hyf.validation.validateField(fieldId, false);
                                    if(!valid){
                                        return false;
                                    }
                                }
                            });

                            if(valid) {
                                setJustificationModificationReason();
                                FormState.updateTextValue("leJustificationModificationSummary", $("#dialog_leJustificationModificationSummary").val(), false);

                                FormState.updateTextValue("justificationSkillAndExperience", $("#dialog_leJustificationSkillAndExperience_modify").val(), true);
                                FormState.updateTextValue("justificationAgencyMissionOrPerformanceGoal", $("#dialog_leJustificationAgencyMissionOrPerformanceGoal_modify").val(), true);

                                setModifiedInfo("leJustificationModifier", "leJustificationModified");

                                $("#dialog_leJustificationModifyContent_group_parent").empty();
                                $("#dialog_leJustificationModifyContent_group").addClass('hide');
                                $("#dialog_leJustificationModifyContent_group").appendTo("#dialog_leJustificationModifyContent_group_parent");
                            }else{
                                return false;
                            }
                        }
                    }
                }
            };
            $("#dialog_leJustificationModifyContent_group").removeClass('hide');
            inputDialogOption.title = "Modify Justification";
            inputDialogOption.message = $("#dialog_leJustificationModifyContent_group")[0];
            inputDialogOption.layoutGroupId = $("#dialog_leJustificationModifyContent_group").attr("id");

            $("#dialog_leJustificationModificationSummary").attr("rows", "3");
            $("#dialog_leJustificationSkillAndExperience_modify").attr("rows", "5");
            $("#dialog_leJustificationAgencyMissionOrPerformanceGoal_modify").attr("rows", "5");

            var dialog = bootbox.dialog(inputDialogOption);
            dialog.init(function(){
                // dialog.find(".modal-body").css({"height": "720px", "overflow-y": "auto"});
            });
        }

        function setJustificationHistory() {
            var procId = FormUtility.getInputElementValue('h_procid');
            var url = '/bizflowwebmaker/cms_incentives_service/searchIncentivesLEJustHistory.do?l=100&q=' + procId;
            var mapFunction = function (context) {
                return {
                    ver: $("JUSTIFICATION_VER", context).text(),
                    modReason: $("JUSTIFICATION_MOD_REASON", context).text(),
                    modSummary: $("JUSTIFICATION_MOD_SUMMARY", context).text(),
                    creatorName: $("JUSTIFICATION_MODIFIER_NAME", context).text(),
                    creatorId: $("JUSTIFICATION_MODIFIER_ID", context).text(),
                    createdDate: $("JUSTIFICATION_MODIFIED_DATE", context).text(),
                    skillExp: $("JUSTIFICATION_SKILL_EXP", context).text(),
                    agencyGoal: $("JUSTIFICATION_AGENCY_GOAL", context).text()
                };
            };
            var openJustificationHistory = function(values) {
                var $inputDialog = $("<div class='layoutContainer alignVertical alignLeft alignTop expandWidth fitHeight hide'></div>");
                // var $tmplElem = $($("#le-justification-history-template")[0].content); // <template> tag didn't work with IE11
                var $tmplElem = $("<div></div>").append($("#le-justification-history-template").children().clone(true));
                var $currentJustification = $tmplElem.clone(true);

                $currentJustification.find(".justification-history-header").css({"background-color": "white"});
                $currentJustification.find(".justification-history-heading-label").html("Current Justification");
                $currentJustification.find(".justification-history-modifier-name-label").html("Modified by:");
                $currentJustification.find(".justification-history-modifier-name").html(FormState.getElementValue("leJustificationModifier", ""));

                $currentJustification.find(".justification-history-modified-date-label").html("Date Modified:");
                $currentJustification.find(".justification-history-modified-date").html(FormState.getElementValue("leJustificationModified", ""));

                $currentJustification.find(".justification-history-modification-reason-label").html("Modification Reason(s):");
                $currentJustification.find(".justification-history-modification-reason").html(FormState.getElementValue("leJustificationModificationReason", ""));

                $currentJustification.find(".justification-history-modification-summary-label").html("Summary of Modification(s):");
                var justificationModificationSummary = FormState.getElementValue("leJustificationModificationSummary", "");
                if(justificationModificationSummary == "") {
                    justificationModificationSummary = "No summary of modifications provided.";
                }
                $currentJustification.find(".justification-history-modification-summary").html(justificationModificationSummary);

                $currentJustification.find(".justification-history-modification-skillAndExperience").html(FormState.getElementValue("justificationSkillAndExperience", ""));
                $currentJustification.find(".justification-history-modification-agencyMissionOrPerformanceGoal").html(FormState.getElementValue("justificationAgencyMissionOrPerformanceGoal", ""));
                $inputDialog.append($currentJustification);

                if(values && values.length > 0) {
                    for (var i = 0; i < values.length; i++) {
                        var $item = $tmplElem.clone(true);
                        var justificationModificationSummary = values[i].modSummary;
                        if(justificationModificationSummary == "") {
                            justificationModificationSummary = "No summary of modifications provided.";
                        }
                        $item.find(".justification-history-header").css({"background-color": "lightgray"});
                        if (values[i].ver == 1) {
                            $item.find(".justification-history-heading-label").html("Original Justification");
                            $item.find(".justification-history-modifier-name-label").html("Created by:");
                            $item.find(".justification-history-modifier-name").html(values[i].creatorName);

                            $item.find(".justification-history-modified-date-label").html("Date Created:");
                            $item.find(".justification-history-modified-date").html(values[i].createdDate);

                            $item.find(".justification-history-modification-reason-label").closest(".layoutContainerContent").addClass("hide");
                            $item.find(".justification-history-modification-summary-label").closest(".layoutContainerContent").addClass("hide");

                            $item.find(".justification-history-modification-superQualificationDesc").html(values[i].superQualDesc);
                            $item.find(".justification-history-modification-qualificationComparedDesc").html(values[i].qualCompDesc);
                            $item.find(".justification-history-modification-payEquityDesc").html(values[i].payEquityDesc);
                        } else {
                            $item.find(".justification-history-heading-label").html("Justification Modification " + (values[i].ver - 1));
                            $item.find(".justification-history-modifier-name-label").html("Modified by:");
                            $item.find(".justification-history-modifier-name").html(values[i].creatorName);

                            $item.find(".justification-history-modified-date-label").html("Date Modified:");
                            $item.find(".justification-history-modified-date").html(values[i].createdDate);

                            $item.find(".justification-history-modification-reason-label").html("Modification Reason(s):");
                            $item.find(".justification-history-modification-reason").html(values[i].modReason);

                            $item.find(".justification-history-modification-summary-label").html("Summary of Modification(s):");
                            $item.find(".justification-history-modification-summary").html(justificationModificationSummary);

                            $item.find(".justification-history-modification-skillAndExperience").html(values[i].skillExp);
                            $item.find(".justification-history-modification-agencyMissionOrPerformanceGoal").html(values[i].agencyGoal);
                        }
                        $inputDialog.append($item);
                    }
                }

                var inputDialogOption = {
                    onEscape: true,
                    animate: false,
                    size: "large",
                    buttons: {
                        cancel:{
                            label: 'Close',
                            className: 'btn-default'
                        }
                    }
                };

                $inputDialog.removeClass('hide');
                inputDialogOption.title = "Justification History";
                inputDialogOption.message = $inputDialog[0];
                inputDialogOption.layoutGroupId = $inputDialog.attr("id");

                var dialog = bootbox.dialog(inputDialogOption);
                dialog.init(function(){
                    dialog.find(".modal-body").css({"height": "520px", "overflow-y": "auto"});
                    var width = dialog.find(".bootbox-body").width();
                    dialog.find(".wrapContent").css({"width": (width - 20), "word-wrap": "break-word"});
                });
            };

            $.ajax({
                url: url,
                dataType: "xml",
                cache: false,
                success: function (xmlResponse) {
                    var data = $("record", xmlResponse).map(function () {
                        return mapFunction(this);
                    }).get();
                    openJustificationHistory(data);
                }
            });
        }

        function initModifyJustification() {
            $('#leJustification_modify_button').off('click').click(function (e) {
                modifyJustification();
            });
        }
        function initJustificationHistory() {
            $('#leJustification_history_button').off('click').click(function (e) {
                setJustificationHistory();
            });
        }

        function initComponents() {
            var mandatory = !_readOnly && (activityStep.isSOReview() || activityStep.isTABGReview() ||
                activityStep.isCOMPReview() || activityStep.isCOMPReviewForModification());

            hyf.util.setMandatoryConstraint("justificationSkillAndExperience", mandatory);
            hyf.util.setMandatoryConstraint("justificationAgencyMissionOrPerformanceGoal", mandatory);
            if (mandatory && activityStep.isSOReview()) {
                if( myInfo.isXO() || myInfo.isHRL()) {
                    hyf.util.setMandatoryConstraint("justificationSkillAndExperience", false);
                    hyf.util.setMandatoryConstraint("justificationAgencyMissionOrPerformanceGoal", false);
                }
            }
            if (mandatory && (activityStep.isCOMPReview() || activityStep.isCOMPReviewForModification())) {
                hyf.util.setMandatoryConstraint("justificationSkillAndExperience", false);
                hyf.util.setMandatoryConstraint("justificationAgencyMissionOrPerformanceGoal", false);
            }
            if(myInfo.isHRS() && activityStep.isHRSReview()) {
                hyf.util.setComponentUsability("justificationSkillAndExperience", false);
                hyf.util.setComponentUsability("justificationAgencyMissionOrPerformanceGoal", false);
                hyf.util.setComponentVisibility("leJustification_modify_button", true);
            } else {
                hyf.util.setComponentUsability("justificationSkillAndExperience", mandatory);
                hyf.util.setComponentUsability("justificationAgencyMissionOrPerformanceGoal", mandatory);
                hyf.util.setComponentVisibility("leJustification_modify_button", false);
            }
            var justificationModifier = FormState.getElementValue("leJustificationModifier", "");
            if(justificationModifier == "") {
                hyf.util.setComponentVisibility("leJustification_history_button", false);
            } else {
                hyf.util.setComponentVisibility("leJustification_history_button", true);
            }

            FormState.updateTextValue("currentUser", myInfo.getMyName(), false);
            FormState.updateTextValue("currentUserId", myInfo.getMyMemberId(), false);
            FormState.updateDateValue("currentDate", FormUtility.getDateString(false, "mm/dd/yyyy HH:MM:ss", new Date()), false);
        }

        function onChangeSupportLE(value) {
            var supportLE = "Yes" === value;
            if(!supportLE && !_readOnly) {
                FormState.updateTextValue("justificationSkillAndExperience", "", true);
                FormState.updateTextValue("justificationAgencyMissionOrPerformanceGoal", "", true);
            }
        }

        function init(readOnly, tabObject) {
            _readOnly = readOnly;
            if(tabObject && tabObject.readonly) {
                _readOnly = true;
            }

            initComponents();
            initEventHandlers();
            FormMain.resetMandatoryMark(tabObject);

            _initialized = true;
        }

        function render(action) {
        }

        return {
            init: init,
            render: render,
            onChangeSupportLE: onChangeSupportLE
        }
    };

    var _initializer = window.cms_incentives_le_justification || (window.cms_incentives_le_justification = cms_incentives_le_justification());
})(window);
