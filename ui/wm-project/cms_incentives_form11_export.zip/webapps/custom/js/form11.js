(function (window) {
    var cms_incentives_le_justification = function () {
        var _readOnly = false;
        var _initialized = false;

        function initEventHandlers() {
        }

        function initComponents() {
            var mandatory = !_readOnly && (activityStep.isSOReview() || activityStep.isHRSReview() || activityStep.isTABGReview());

            hyf.util.setMandatoryConstraint("justificationSkillAndExperience", mandatory);
            hyf.util.setMandatoryConstraint("justificationAgencyMissionOrPerformanceGoal", mandatory);
        }

        function init(readOnly) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();

            _initialized = true;
        }

        function render(action) {
        }

        return {
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_le_justification || (window.cms_incentives_le_justification = cms_incentives_le_justification());
})(window);
