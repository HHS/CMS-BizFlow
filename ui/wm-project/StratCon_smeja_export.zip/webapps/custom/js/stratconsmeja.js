/**
 * onload handler for SME/JA tab page
 */
function initSmeJaTab() {
		// When accessing the elements in other tab, access the elements after receiving global event "CMS_ALL_TAB_LOADED".
		// This will guarantee that the elements in other tab exist.
		$(document).on("CMS_ALL_TAB_LOADED", function() {
			$("#POS_PAY_PLAN").on("change", function() {
				controlSelectiveFactorGroup();
			});
	
			$("#POS_SERIES").on("change", function() {
				controlSelectiveFactorGroup();
			});
	
			var posSeriesValSel = $("#POS_SERIES option:selected").val();
			var posPayPlanValSel = $("#POS_PAY_PLAN option:selected").val();
			if (posPayPlanValSel == "GS" && posSeriesValSel == "0602") {
				// for GS-0602, automatically check Selective Factor checkbox
				$("#JA_SEL_FACTOR_REQ").prop("checked", true);
				$('#JA_SEL_FACTOR_REQ').attr('disabled','disabled');
				$('#JA_SEL_FACTOR_JUST').val('');
				$("#ja_sel_just_group").hide();
				$("#sel_fac_note_group").show();
		
				var width = $(window).width();
				$('div.cmsNoteChildWidth').parent().attr('style','width:' + width * 0.80 + 'px');
			} else {
				// for non-GS-0602, clear/hide
				$("#sel_fac_note_group").hide();  // hide note for GS-0602
				$('div.cmsNoteChildWidth').parent().attr('style','display:none');
				$("#JA_SEL_FACTOR_REQ").trigger("change");				
			}			
		});
	
		// Show Name/Email fields for SME only if the associated Job Analysis checkbox is checked
		$("#SME_FOR_JOB_ANALYSIS").change(function() {
			controlSmeForJAGroup();
		});
	
		// Show Name/Email fields for SME only if the associated Qualification checkbox is checked
		$("#SME_FOR_QUALIFICATION").change(function() {
			controlSmeForQualGroup();
		});
		
		// Show Justify field for Selective Factor only the associated checkbox is checked
		$("#JA_SEL_FACTOR_REQ").change(function() {
			controlSelectiveFactorJustifyGroup();
		});
		
		// Show Justify field for Quality Ranking Factor only the associated checkbox is checked.
		$("#JA_QUAL_RANK_REQ").change(function() {
			controlQalityRankingFactorJustifyGroup();
		});
	
		// Show checkboxes under subgroup for Multiple Types of Assessment only when the parent checkbox is checked.
		$("#JA_RESPONSES_REQ").change(function() {
			controlMultiTypeAssessGroup();
		});
	
		// trigger events for initial processing
		$("#SME_FOR_JOB_ANALYSIS").trigger("change");
		$("#SME_FOR_QUALIFICATION").trigger("change");
		$("#POS_PAY_PLAN").trigger("change");
		$("#POS_SERIES").trigger("change");
		$("#JA_SEL_FACTOR_REQ").trigger("change");
		$("#JA_QUAL_RANK_REQ").trigger("change");
		$("#JA_RESPONSES_REQ").trigger("change");

	} // end initSmeJaTab()
	
	
	/**
	 * Controls the SME for JA group depending on the check status of the checkbox.
	 *
	 * @param isChecked - boolean value for the checkbox of SME for Job Analysis
	 */
	function controlSmeForJAGroup(){
		var isChecked = $("#SME_FOR_JOB_ANALYSIS").prop("checked");
		if (isChecked) {
			$("#sme_ja_identity_grid_group").show();
		} else {
			$("#sme_ja_identity_grid_group").hide();
			// when hiding, clear field values, too
			$("#SME_NAME_JA").val("");
			$("#SME_EMAIL_JA").val("");
		}
	}
	
	
	/**
	 * Controls the SME for Qualification group depending on the check status of the checkbox.
	 *
	 * @param isChecked - boolean value for the checkbox of SME for Qualification
	 */
	function controlSmeForQualGroup(){
		var isChecked = $("#SME_FOR_QUALIFICATION").prop("checked");
		if (isChecked) {
			$("#sme_qual_identity_grid_group").show();
		} else {
			$("#sme_qual_identity_grid_group").hide();
			// when hiding, clear field values, too
			$("#SME_NAME_QUAL_1").val("");
			$("#SME_EMAIL_QUAL_1").val("");
			$("#SME_NAME_QUAL_2").val("");
			$("#SME_EMAIL_QUAL_2").val("");
		}
	}
	
	
	/**
	 * Controls Selective Factor checkbox, its associated Justify textarea, and note for GS-0602.
	 *
	 * For GS-0602,
	 * 1. Check Selective Factor checkbox automatically.
	 * 2. Set the initial text for Justify textarea
	 * 3. Show Justify textarea
	 * 4. Show note for GS-0602
	 *
	 * For non-GS-0602, reverse the above.
	 *
	 * @param posPayPlanValSel - Pay Plan option value that is selected.
	 * @param posSeriesValSel - Series option value that is selected.
	 */
	function controlSelectiveFactorGroup() {
		var posSeriesValSel = $("#POS_SERIES option:selected").val();
		var posPayPlanValSel = $("#POS_PAY_PLAN option:selected").val();
	
		if (posPayPlanValSel == "GS" && posSeriesValSel == "0602") {
			// for GS-0602, automatically check Selective Factor checkbox
			$("#JA_SEL_FACTOR_REQ").prop("checked", true);
			$('#JA_SEL_FACTOR_REQ').attr('disabled','disabled');
			$('#JA_SEL_FACTOR_JUST').val('');
			$("#ja_sel_just_group").hide();
			$("#sel_fac_note_group").show();
	
			var width = $(window).width();
			$('div.cmsNoteChildWidth').parent().attr('style','width:' + width * 0.80 + 'px');
		} else {
			// for non-GS-0602, clear/hide
			$("#JA_SEL_FACTOR_REQ").prop("checked", false);
			$("#ja_sel_just_group").hide();
			$('#JA_SEL_FACTOR_REQ').removeAttr('disabled');
			$('#JA_SEL_FACTOR_JUST').val('');
			$("#sel_fac_note_group").hide();  // hide note for GS-0602
	
			$('div.cmsNoteChildWidth').parent().attr('style','display:none');
		}
	}
	
	/**
	 * Controls show/hide of Justify textbox associated with Selective Factor checkbox.
	 *
	 * @param isChecked - boolean value for the checkbox of Selective Factor
	 */
	function controlSelectiveFactorJustifyGroup(){
		var isChecked = $("#JA_SEL_FACTOR_REQ").prop('checked');
		if (isChecked) {
			$("#ja_sel_just_group").show();
		} else {
			$("#ja_sel_just_group").hide();
			$("#JA_SEL_FACTOR_JUST").val("");  // when hiding, clear field values, too
		}
	}
	
	/**
	 * Controls show/hide of Justify textbox associated with Quality Ranking Factor checkbox.
	 *
	 * @param isChecked - boolean value for the checkbox of Quality Ranking Factor
	 */
	function controlQalityRankingFactorJustifyGroup(){
		var isChecked = $("#JA_QUAL_RANK_REQ").prop("checked");
		if (isChecked) {
			$("#ja_qual_rank_just_group").show();
		} else {
			$("#ja_qual_rank_just_group").hide();
			$("#JA_QUAL_RANK_JUST").val("");  // when hiding, clear field values, too
		}
	}
	
	/**
	 * Controls show/hide of Justify textbox associated with Multiple Types of Assessment checkbox.
	 *
	 * @param isChecked - boolean value for the checkbox of Multiple Types of Assessment
	 */
	function controlMultiTypeAssessGroup(){
		var isChecked = $("#JA_RESPONSES_REQ").prop("checked");
		if (isChecked) {
			$("#assess_qtype_group").show();
		} else {
			$("#assess_qtype_group").hide();
			// clear child checkbox upon unchecking parent
			$("#JA_TYPE_YES_NO").prop("checked", false);
			$("#JA_TYPE_REQ_DEFAULT").prop("checked", false);
			$("#JA_TYPE_KNOWL_SCALE").prop("checked", false);
		}
	}
	