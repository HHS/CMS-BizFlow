var BFActivity = (function(){
	BFActivity = function(name, usergroups, tabs, readonlytabs){
		this.name = name;
		this.usergroup = (typeof usergroups === 'object' && usergroups != null && Array.isArray(usergroups) ? usergroups : []);
		this.tabs = (typeof tabs === 'object' && tabs != null && Array.isArray(tabs) ? tabs : []);
		this.readonly = (typeof readonlytabs === 'object' && readonlytabs != null && Array.isArray(readonlytabs) ? readonlytabs : []);
	}
}());




var BFActivityOption = (function(){


	/**
	 * Constructor for BFActivityOption.
	 *
	 * @param actList - array of activity options in the following format.
	 *				[
	 *					{
	 *						name: 'Conduct Eligibility and Qualification Review',
	 *						usergroup: ['Administrator','Application Developer','Selecting Official'],
	 *						tabs: ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab9'],
	 *						readonly: ['tab2', 'tab3']
	 *					},
	 *					{
	 *						...
	 *					}
	 *				]
	 * @param activityName - current activity name
	 * @param currentActivity - current activity
	 * @param currentTabs - current tabs
	 */
	BFActivityOption = function(actList, activityName, currentActivity, currentTabs){
		this.actList = actList;
		this.activityName = activityName;
		this.currentActivity = currentActivity;
		this.currentTabs = currentTabs;
	}

	BFActivityOption.prototype.getActivityName = function() {
		//if (this.activityName == null) {
		//	this.activityName = $('#h_activityName').val();
		//	if (this.activityName == null || this.activityName.length == 0) {
		//		CMSUtility.debugLog('BFActivityOption - this.getActivityName() - ActivityName is null or empty.');
		//	} 
		//	else {
		//		$('#h_activityName').val('');
		//	}
		//}
		return this.activityName;
	}
	
	BFActivityOption.prototype.setActivityName = function(newActivityName) {
		this.activityName = newActivityName;
	}
	
	BFActivityOption.prototype.getCurrentActivityOption = function(activityName) {
		if (activityName != this.activityName) {
			this.currentActivity = null;
			this.currentTabs = null;
			this.activityName = activityName;
		}

		if (this.currentActivity == null) {
			if (activityName == null || activityName.length == 0) {
				activityName = '_Archive_';
			}

			// Find current activity name and tab information associated with current activity name
			var currentActList = [];
			currentActList = this.actList.filter(function(node, index) {
				var memberCount = 0;
				//if (node.usergroup.length > 0) {
				//    node.usergroup.forEach(function(group) {
				//        if (StratConMAIN.isCurrentUserMemberOf(group) == true) {
				//            memberCount++;
				//        }
				//    })
				//}
				return node.name == activityName && (memberCount == node.usergroup.length || memberCount > 0);
			});
			// If current activity is not in the BFActivityOption, add _Archive_ configuration
			if (currentActList.length == 0) {
				currentActList.push(this.actList[this.actList.length - 1]);
			}
			this.currentActivity = currentActList[0];
			this.currentTabs = this.currentActivity.tabs.slice();
		}
		return this.currentActivity;
	}

	BFActivityOption.prototype.getActiveTabList = function(activityName) {
		if (this.currentTabs == null) {
			var activityOption = this.getCurrentActivityOption(activityName);
		}
		return this.currentTabs;
	}

	BFActivityOption.prototype.addTabToCurrentActivity = function(activityName, tabID) {
		if (this.currentTabs != null) {
			for (var index = 0; index < this.currentTabs.length; index++) {
				if (this.currentTabs[index] == tabID) {
					return; // Already exists.
				}
			}
			for (var index = 0; index < this.currentTabs.length; index++) {
				if (this.currentTabs[index] > tabID) {
					this.currentTabs.splice(index, 0, tabID);
					break;
				}
			}
		}
	}

	BFActivityOption.prototype.removeTabFromCurrentActivity = function(activityName, tabID) {
		if (this.currentTabs != null) {
			for (var index = 0; index < this.currentTabs.length; index++) {
				if (this.currentTabs[index] == tabID) {
					this.currentTabs.splice(index, 1);
					break;
				}
			}
		}
	}

	BFActivityOption.prototype.getCurrentTabID = function() {
		var currentTabs = $('#tab_control_container a.selectedTab');
		var tabCount = currentTabs.length;

		if (currentTabs.length > 0) {
			var tabAnchorID = currentTabs[0].attributes['id'].value;
			var tabID = CMSUtility.getTabIDFromAnchorID(tabAnchorID);
			return tabID;
		}
		return null;
	}

	BFActivityOption.prototype.getNextTabID = function(currentTabID) {
		if (this.currentTabs != null) {
			for (var index = 0; index < this.currentTabs.length; index++) {
				if (this.currentTabs[index] == currentTabID) {
					if (index < this.currentTabs.length - 1) {
						return this.currentTabs[index + 1];
					}
				}
			}
		}
		return null;
	}

	BFActivityOption.prototype.getPreviousTabID = function(currentTabID) {
		if (this.currentTabs != null) {
			for (var index = 0; index < this.currentTabs.length; index++) {
				if (this.currentTabs[index] == currentTabID) {
					if (index > 0) {
						return this.currentTabs[index - 1];
					}
				}
			}
		}
		return null;
	}

	/*
	actList: [{
			name: 'Conduct Eligibility and Qualification Review',
			usergroup: [],
			tabs: ['tab1', 'tab2', 'tab3', 'tab6'],
			readonly: []
		},{
			name: 'Modify Request',
			usergroup: [],
			tabs: ['tab1', 'tab2', 'tab3', 'tab6'],
			readonly: []
		}, {
			name: 'Selection',
			usergroup: [],
			tabs: ['tab1', 'tab2', 'tab3', 'tab4', 'tab6'],
			readonly: []
		}, {
			name: 'Approve',
			usergroup: [],
			tabs: ['tab1', 'tab2', 'tab3', 'tab5', 'tab6'],
			readonly: []
		}, {
			name: '_Archive_',
			usergroup: [],
			tabs: ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab6'],
			readonly: ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab6']
		}
	]
	*/
	
	return BFActivityOption;
}());