var ConductIssue = {
    initialized: false,
	groups : [
	'action_AdministrativeLeave_group',
	'admin_leave_investigatory_group',
	'action_Reprimand_group',
	'action_Suspension_group',
	'termination_type_pre_employment_group',
	'termination_type_probation_group',
	'suspension_oral_presentation_group',
	'oral_presentation_date_group',
	'written_response_group',
	'admin_leave_notice_group',
	'action_Demotion_group',
	'action_Counseling_group',
	'action_SickLeaveRestriction_group',
	'action_SickLeaveWarning_group',
	'action_Reassignment_group',
	'action_Removal_group',
	'pre_emp_termination_oral_presentation_group',
	'pre_emp_termination_response_group',
	'suspension_written_response_group',
	'action_Termination_group',
	'oral_presentation_date_group',
	'written_response_group',
	'removal_notice_date_group',
	'removal_oral_presentation_group',
	'removal_written_response_group',
	'suspension_oral_presentation_group',
	'suspension_written_response_group',
	'pre_emp_termination_oral_presentation_group',
	'pre_emp_termination_response_group',
	'reassignment_date_notice_issued',
	'emp_appeal_decision_group'
	],
	actionTypes :[
	'admin_leave',
	'alt_discipline',
	'removal_notice_date_group',
	'removal_oral_presentation_group',
	'removal_written_response_group'
	],
	init: function (){
		ConductIssue.groups.forEach(function(el,index){
			hyf.util.hideComponent(el);
		});
		//multi date selection
		$('#admin_leave_clear, #admin_leave_ntc_clear').on('click',clear);
		var SLRevDtOption = {
			dataElemId: 'rv_dt_selected',
			dispElemId: 'rv_indecator',
			inputElemId: 'CI_SICK_LEAVE_REVIEWED_DT',
			btnElemId: 'add_review_date'
		};
		var SLExtDtOption = {
			dataElemId: 'ex_dt_selected',
			dispElemId: 'ex_dt_indicator',
			inputElemId: 'CI_SICK_LEAVE_EXTENDED_DT',
			btnElemId: 'add_extended_date'
		};
		var SLWDtOption = {
			dataElemId: 'CI_manager_discuss_dt',
			dispElemId: 'sick_leave_warning',
			inputElemId: 'CI_SL_WARNING_DISCUSSION_DT',
			btnElemId: 'slw_add_date'	
		};
		var SLRevDtObj = MultiDateSelection.setupMultiDateSelection(SLRevDtOption);
		var SLExtDtObj = MultiDateSelection.setupMultiDateSelection(SLExtDtOption);
		var SLWDtObj = MultiDateSelection.setupMultiDateSelection(SLWDtOption);	
		
		var SLRevDt = $('#rv_dt_selected').val();
		var SLExtDt =$('#ex_dt_selected').val();
		var SLWDt = $('#CI_manager_discuss_dt').val();
		
		if(SLRevDt && SLRevDt.trim().length <= 0){
			SLRevDt = FormState.getState('rv_dt_selected');
		}
		SLRevDtObj.refreshData(SLRevDt);
		if(SLExtDt && SLExtDt.trim().length <= 0){
			SLExtDt = FormState.getState('ex_dt_selected');
		}
		SLExtDtObj.refreshData(SLExtDt);
		if(SLWDt && SLWDt.trim().length <= 0){
			SLWDt = FormState.getState('CI_manager_discuss_dt');
		}
		SLWDtObj.refreshData(SLWDt);
		var reqFieldForActivity = 
		[
			{
				actName: globalVars.actAll,
				reqFieldIds: 
				[
				'CI_ACTION_TYPE',
				'CI_LEAVE_START_DT',
				'CI_LEAVE_END_DT',
				'CI_APPROVAL_NAME',
				'CI_LEAVE_START_DT_2',
				'CI_LEAVE_END_DT_2',
				'CI_APPROVAL_NAME_2',
				'CI_PROP_ACTION_ISSUED_DT',
				'CI_ORAL_PREZ_REQUESTED',
				'CI_ORAL_PREZ_DT',
				'CI_ORAL_RESPONSE_SUBMITTED',
				'CI_RESPONSE_DUE_DT',
				'CI_WRITTEN_RESPONSE_SUBMITTED_DT',
				'CI_PROPOSED_POS_TITLE',
				'CI_PROPOSED_PPLAN',
				'CI_PROPOSED_SERIES',
				'CI_PROPOSED_INFO_GRADE',
				'CI_PROPOSED_INFO_STEP',
				'CI_FINAL_INFO_STEP',
				'CI_DEMO_FINAL_AGENCY_DECISION',
				'CI_DECIDING_OFFCL',
				'CI__DECISION_ISSUED_DT',
				'CI_DEMO_FINAL_AGENCY_EFF_DT',
				'CI_COUNSEL_TYPE',
				'CI_COUNSEL_ISSUED_DT',
				'CI_SICK_LEAVE_ISSUED_DT',
				'CI_RESTRICTION_ISSED_DT',
				'CI_SICK_LEAVE_REVIEWED_DT',
				'CI_SICK_LEAVE_EXTENDED_DT',
				'CI_SICK_LEAVE_REMOVED_DT',
				'CI_SL_WARNING_DISCUSSION_DT',
				'CI_SL_WARN_ISSUE',
				'CI_NOTICE_ISSUED_DT',
				'CI_EFFECTIVE_DT',
				'CI_CURRENT_ADMIN_CODE',
				'CI_RE_ASSIGNMENT_CURR_ORG',
				'CI_RE_ASSIGNMENT_FINAL_ORG',
				'CI_REMOVAL_PROP_ACTION_DT',
				'CI_EMP_NOTICE_LEAVE_PLACED',
				'CI_REMOVAL_NOTICE_START_DT',
				'CI_REMOVAL_NOTICE_END_DT',
				'CI_REMOVAL_ORAL_PREZ_REQUESTED',
				'CI_REMOVAL_ORAL_PREZ_DT',
				'CI_REMOVAL_WRITTEN_RESPONSE',
				'CI_WRITTEN_RESPONSE_DUE_DT',
				'CI_WRITTEN_SUBMITTED_DT',
				'CI_RMVL_FINAL_AGENCY_DECISION',
				'CI_DECIDING_OFFCL_NAME',
				'CI_REMOVAL_DATE_DECISION_ISSUED',
				'CI_REMOVAL_EFFECTIVE_DT',
				'CI_SUSPENTION_TYPE',
				'CI_SUSP_PROP_ACTION_DT',
				'CI_SUSP_ORAL_PREZ_REQUESTED',
				'CI_SUSP_ORAL_PREZ_DT',
				'CI_SUSP_WRITTEN_RESP',
				'CI_SUSP_WRITTEN_RESP_DUE_DT',
				'CI_SUSP_WRITTEN_RESP_DT',
				'CI_SUSP_FINAL_AGENCY_DECISION',
				'CI_SUSP_DECIDING_OFFCL_NAME',
				'CI_SUSP_DECISION_ISSUED_DT',
				'CI_SUSP_EFFECTIVE_DECISION_DT',
				'CI_TERMINATION_TYPE',
				'CI_TERM_PROP_ACTION_DT',
				'CI_TERM_ORAL_PREZ_REQUESTED',
				'CI_TERM_ORAL_PREZ_DT',
				'CI_TERM_WRITTEN_RESP',
				'CI_TERM_WRITTEN_RESP_DUE_DT',
				'CI_TERM_WRITTEN_RESP_DT',
				'CI_TERM_AGENCY_DECISION',
				'CI_TERM_DECIDING_OFFCL_NAME',
				'CI_TERM_DECISION_ISSUED_DT',
				'CI_TERM_EFFECTIVE_DECISION_DT',
				'CI_PRE_PROBATION_TERMINATION_DECISION_ISSUED_DT',
				'CI_REPRIMAND_ISSUE_DT'
				
				]
			},
			{
				actName: globalVars.actCaseCreation,
				reqFieldIds: 
				[
					
				]
			},
			{
				actName: globalVars.actCaseComplete,
				reqFieldIds: 
				[
				]
			}
		];
		var empData = FormState.getElementValue('GEN_EMPCONTACT');
		populateCurrentPosition(empData);
		$('#conduct_issue_layout select').on('change',helperEventHandler);
		$('#CI_TERM_PROP_ACTION_DT,#CI_SUSP_PROP_ACTION_DT, #CI_REMOVAL_PROP_ACTION_DT, #CI_DECISION_ISSUED_DT,#CI_PROP_ACTION_ISSUED_DT').on('change',dateChangeEventConduct);
		$('#CI_PROPOSED_PPLAN,#CI_FINAL_PPLAN').on('change',populateGrades);
		$('#CI_LEAVE_START_DT,#CI_LEAVE_END_DT,#CI_LEAVE_START_DT_2,#CI_LEAVE_END_DT_2').on('change',dateValidate);
		$('#CI_EMP_APPEAL_DECISION').on('change',employeeAppealDecision);
		$('#CI_ADMIN_NOTICE_LEAVE, #CI_ADMIN_INVESTIGATORY_LEAVE').on('click',function(e){
			var val = $(this).prop('checked');
			if(e.target.id ==='CI_ADMIN_INVESTIGATORY_LEAVE'){
				$('#admin_leave_investigatory_group input[type="text"]').val('');
				$('#leave_length').text('');
				CommonOpUtil.hyfShowOrHide({value:val},'admin_leave_investigatory_group');	
			}
		if(e.target.id ==='CI_ADMIN_NOTICE_LEAVE'){
			CommonOpUtil.hyfShowOrHide({value:val},'admin_leave_notice_group');	
			$('#admin_leave_notice_group input[type="text"]').val('');	
			$('#leave_length_2').text('');
		}
		});
		ConductIssue.render();
		//if(!ConductIssue.initialized){
		FormAutoComplete.setAutoComplete('CI_APPROVAL_NAME','/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=',ConductIssue.populateOfficial,CommonOpUtil.responseMapper,CommonOpUtil.appendEmplInfo);
		FormAutoComplete.setAutoComplete('CI_APPROVAL_NAME_2','/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=',ConductIssue.populateOfficial,CommonOpUtil.responseMapper,CommonOpUtil.appendEmplInfo);
		FormAutoComplete.setAutoComplete('CI_DECIDING_OFFCL','/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=',ConductIssue.populateOfficial,CommonOpUtil.responseMapper,CommonOpUtil.appendEmplInfo);
		FormAutoComplete.setAutoComplete('CI_SUSP_DECIDING_OFFCL_NAME','/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=',ConductIssue.populateOfficial,CommonOpUtil.responseMapper,CommonOpUtil.appendEmplInfo);
		FormAutoComplete.setAutoComplete('CI_TERM_DECIDING_OFFCL_NAME','/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=',ConductIssue.populateOfficial,CommonOpUtil.responseMapper,CommonOpUtil.appendEmplInfo);
		FormAutoComplete.setAutoComplete('CI_DECIDING_OFFCL_NAME','/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=',ConductIssue.populateOfficial,CommonOpUtil.responseMapper,CommonOpUtil.appendEmplInfo);
		FormAutoComplete.setAutoComplete('CI_FINAL_ADMIN_CODE','/bizflowwebmaker/cms_erlr_service/contactInfo.do?admin=',populateAdminCode,CommonOpUtil.adminCodeResponseMapper,appendAdminCode);
		//CommonOpUtil.setStandardDateConstraint('standard_date');
		CommonOpUtil.dynamicMandatory(reqFieldForActivity);	
		hyf.util.hideComponent('tab_control_tab_tab4');
		//}	
	},
	grades: {'GP':['01','02','03','04','05','06','07','08','09','10','11','12','13','14','15'],
			'GR':['01','02','03','04','05','06','07','08','09','10','11','12','13','14','15'],
			'GS':['01','02','03','04','05','06','07','08','09','10','11','12','13','14','15'],
			'ES':['01','02','03','04','05','06'],
			'WG':['01','02','03','04','05','06','07','08','09','10']
	},
	inputEvents : {
		/*I intend to have a list of dropdowns and their corresponding event hanlder helper functions, so that I can access the reference to the function, then call it 
		like dropdownTargets[event.target.id](),where event target id corresponds to the obj key*/
		
		 'CI_ACTION_TYPE':actionTypeEvent,
		 'CI_TERMINATION_TYPE': terminationationTpe,
		 'CI_PROP_ACTION_ISSUED': {action:hyfToogle,target:''},
		 'CI_ORAL_PREZ_REQUESTED':{action:hyfToogle,target:'oral_presentation_date_group'},
		 'CI_ORAL_RESPONSE_SUBMITTED': {action:hyfToogle,target:'written_response_group'},
		 'CI_EMP_NOTICE_LEAVE_PLACED':{action:hyfToogle,target:'removal_notice_date_group'},
		 'CI_REMOVAL_ORAL_PREZ_REQUESTED': {action:hyfToogle,target:'removal_oral_presentation_group'},
		 'CI_REMOVAL_WRITTEN_RESPONSE': {action:hyfToogle,target:'removal_written_response_group'},
		 'CI_SUSP_ORAL_PREZ_REQUESTED': {action:hyfToogle,target:'suspension_oral_presentation_group'},
		 'CI_SUSP_WRITTEN_RESP': {action:hyfToogle,target:'suspension_written_response_group'},
		 'CI_TERM_ORAL_PREZ_REQUESTED' : {action:hyfToogle,target:'pre_emp_termination_oral_presentation_group'},
		 'CI_TERM_WRITTEN_RESP' : {action:hyfToogle,target:'pre_emp_termination_response_group'},		 
	},
	
    render: function (){
		/*
		var leaveDtStart = FormState.getState('CI_LEAVE_START_DT');
		var leaveDtEnd = FormState.getState('CI_LEAVE_END_DT');
		var leaveDtStart2 = FormState.getState('CI_LEAVE_START_2');
		var leaveDtEnd2 = FormState.getState('CI_LEAVE_END_2');
        var decision_issued_date = FormState.getState('CI_DECISION_ISSUED_DT');
		var dt_reviewed = FormState.getState('CI_RV_SELECTED_DT');
		var dt_extended = FormState.getState('CI_EX_SELECTED_DT');
		var actionType = FormState.getState('CI_ACTION_TYPE');
		var sickLeaveWarning = FormState.getState('CI_SLW_DISCUSSION_DT');
		var admin_leave = FormState.getState('CI_ADMIN_LEAVE_TYPE');
		var oral_presentation = FormState.getState('CI_ORAL_PREZ_REQUESTED');//oral_response_submitted
		var appealDecision = FormState.getState('CI_REPRIMAND_APPEAL_DECISION');
		var removalEmployeePlacedLeaveNotice = FormState.getState('CI_EMP_NOTICE_LEAVE_PLACED');
		var removalOral_presentation = FormState.getState('CI_REMOVAL_ORAL_PREZ_REQUESTED');
		var removalWritten_ResponseSubmitted = FormState.getState('CI_REMOVAL_WRITTEN_RESPONSE');
		var terminationOral_presentation = FormState.getState('CI_TERM_ORAL_PREZ_REQUESTED');
		var terminationWritten_ResponseSubmitted = FormState.getState('CI_TERM_WRITTEN_RESP');
		var written_response_requested = FormState.getState('CI_ORAL_RESPONSE_SUBMITTED');
		var admin_leave_investigatory = FormState.getState('CI_ADMIN_INVESTIGATORY_LEAVE');
		var admin_leave_notice = FormState.getState('CI_ADMIN_NOTICE_LEAVE');
		var emp = FormState.getState('EMPCONTACT');
		var terminationType = FormState.getState('CI_TERMINATION_TYPE');
		var demotion_date_proposed_action_issued = FormState.getState('CI_PROP_ACTION_ISSUED');//oral_presentation_requested
		var removal_date_proposed_action_issued = FormState.getState('CI_REMOVAL_PROP_ACTION_DT');
		var removal_date_decision_issued = FormState.getState('CI_REMOVAL_DECISION_ISSUED_DT');
		var suspensionOralPresentation = FormState.getState('CI_SUSP_ORAL_PREZ_REQUESTED');
		var suspensionWrittenPresentation = FormState.getState('CI_SUSP_WRITTEN_RESP');//CI_SUSP_WRITTEN_RESP
		var suspensionDateActionProposed = FormState.getState('CI_SUSP_PROP_ACTION_DT');
		var suspensionDecisionIssued = FormState.getState('CI_SUSP_DECISION_ISSUED_DT');
		var reassignment_date_notice_issued	= FormState.getState('CI_NOTICE_ISSUED_DT');
		var termination_decision_issued = FormState.getState('CI_TERM_DECISION_ISSUED_DT');
		var termination_proposed_action_issued = FormState.getState('CI_TERM_PROP_ACTION_DT');
		var proposed_pplan = FormState.getState('CI_PROPOSED_PPLAN');
		var final_pplan = FormState.getState('CI_FINAL_PPLAN');
		
		var proposedGradeInfo = FormState.getState('CI_PROPOSED_INFO_GRADE');
		var finalGradeInfo = FormState.getState('CI_FINAL_INFO_GRADE');
		
		
		if((termination_decision_issued && termination_decision_issued.dirty) || (termination_decision_issued && termination_decision_issued.dirty )){
			dateValidateHelper('CI_TERM_PROP_ACTION_DT','CI_TERM_DECISION_ISSUED_DT','CI_TERM_DECISION_ISSUED_DT');
		}
		if((suspensionDateActionProposed && suspensionDateActionProposed.dirty) || (suspensionDecisionIssued && suspensionDecisionIssued.dirty )){
			dateValidateHelper('CI_SUSP_PROP_ACTION_DT','CI_SUSP_DECISION_ISSUED_DT','CI_SUSP_PROP_ACTION_DT');
		}
		if((removal_date_proposed_action_issued && removal_date_proposed_action_issued.dirty) || (removal_date_decision_issued && removal_date_decision_issued.dirty )){
			dateValidateHelper('CI_REMOVAL_PROP_ACTION_DT','CI_REMOVAL_DECISION_ISSUED_DT','CI_REMOVAL_PROP_ACTION_DT');
		}
		if((decision_issued_date && decision_issued_date.dirty) || (demotion_date_proposed_action_issued && demotion_date_proposed_action_issued.dirty )){
			dateValidateHelper('CI_DECISION_ISSUED_DT','CI_PROPOSE_ACTION_ISSUED_DT','CI_PROP_ACTION_ISSUED_DT');
		}
		if((terminationWritten_ResponseSubmitted && terminationWritten_ResponseSubmitted.dirty)){
			hyfShowOrHide(terminationWritten_ResponseSubmitted,'pre_emp_termination_response_group');
			dateAutoPopulate('CI_TERM_WRITTEN_RESP_DUE_DT',$('#CI_TERM_ORAL_PREZ_DT').val());
		}
			
		if((removalOral_presentation && removalOral_presentation.dirty)){
			hyfShowOrHide(removalOral_presentation,'removal_oral_presentation_group');
		}
		if((removalWritten_ResponseSubmitted && removalWritten_ResponseSubmitted.dirty)){
			hyfShowOrHide(removalWritten_ResponseSubmitted,'removal_written_response_group');
			dateAutoPopulate('CI_WRITTEN_RESPONSE_DUE_DT',$('#CI_REMOVAL_ORAL_PREZ_DT').val());
		}
		if((suspensionWrittenPresentation && suspensionWrittenPresentation.dirty)){
			hyfShowOrHide(suspensionWrittenPresentation,'suspension_written_response_group');
			dateAutoPopulate('CI_SUSP_WRITTEN_RESP_DUE_DT',$('#CI_SUSP_ORAL_PREZ_DT').val());
		}
		if(decision_issued_date && decision_issued_date.dirty){
			dateDecisionIssued();
		}
		if(oral_presentation && oral_presentation.dirty){
			hyfShowOrHide(oral_presentation,'oral_presentation_date_group');
			
		}
		if(written_response_requested && written_response_requested.dirty){
			hyfShowOrHide(written_response_requested,'written_response_group');
			dateAutoPopulate('CI_RESPONSE_DUE_DT',$('#CI_ORAL_PREZ_DT').val());
		}

		if((emp && emp.dirty)){
			populateCurrentPosition(emp.value);		
		}
	*/
    },
	populateOfficial : function(item,id){
		if(id ==='CI_APPROVAL_NAME' && (item.last_name !==''||item.first_name !=='')){
		$('#CI_APPROVAL_NAME').val(item.last_name +','+item.first_name +'('+item.email+')');
		}
		if(id ==='CI_APPROVAL_NAME_2' && item.value !==''){
		$('#CI_APPROVAL_NAME_2').val(item.last_name +','+item.first_name +'('+item.email+')');
		}
		if(id ==='CI_APPROVAL_NAME' && item.value !==''){
		$('#CI_APPROVAL_NAME').val(item.last_name +','+item.first_name +'('+item.email+')');
		}
		
		if(id ==='CI_SUSP_DECIDING_OFFCL_NAME' && item.value !==''){
		$('#CI_SUSP_DECIDING_OFFCL_NAME').val(item.last_name +','+item.first_name +'('+item.email+')');
		}
		if(id ==='CI_TERM_DECIDING_OFFCL_NAME' && item.value !==''){
		$('#CI_TERM_DECIDING_OFFCL_NAME').val(item.last_name +','+item.first_name +'('+item.email+')');
		}
		if(id ==='CI_DECIDING_OFFCL_NAME' && item.value !==''){
		$('#CI_DECIDING_OFFCL_NAME').val(item.last_name +','+item.first_name +'('+item.email+')');
		}
	}

};
function employeeAppealDecision(e){
	var action = FormState.getElementValue('CI_EMP_APPEAL_DECISION');
	if(action === 'Y'){
		hyf.util.showComponent('tab_control_tab_tab4');		
	}else{
		hyf.util.hideComponent('tab_control_tab_tab4');
	}
}
function dateValidate(e){
	var days = 0;
	var dt1 = '';
	var dt2 = ''
	if(e === 'undefined'){
		return;
	}
	if(e.target.id ==='CI_LEAVE_START_DT' || e.target.id ==='CI_LEAVE_START_DT_2' || e.target.id ==='CI_LEAVE_END_DT' || e.target.id ==='CI_LEAVE_END_DT_2'){
		if(e.target.id ==='CI_LEAVE_START_DT' || e.target.id ==='CI_LEAVE_END_DT'){
			dt1 = $('#CI_LEAVE_START_DT').val();
			dt2 = $('#CI_LEAVE_END_DT').val();
		}else if(e.target.id ==='CI_LEAVE_START_DT_2' || e.target.id ==='CI_LEAVE_END_DT_2'){
			dt1 = $('#CI_LEAVE_START_DT_2').val();
			dt2 = $('#CI_LEAVE_END_DT_2').val();
		}		
	}
	if((dt2 !== '') ||(dt1 !== '')){
		days = timeStampToDays(dt1,dt2);
		if(days.val >= 0 && (e.target.id ==='CI_LEAVE_START_DT' || e.target.id === 'CI_LEAVE_END_DT')){
			$('#leave_length').text(days.val +' Day(s)');
		}else if(days.val >= 0 && (e.target.id ==='CI_LEAVE_START_DT_2' || e.target.id ==='CI_LEAVE_END_DT_2')){
			$('#leave_length_2').text(days.val +' Day(s)');
		}else if(days.timeStamp1 > days.timeStamp2){
			bootbox.alert({
            message: 'Invalid leave end date. Leave end date must come after start date.',//'Invalid leave end date. Leave end date must come after start date.',
            callback: function(){
                $('#' +e.target.id).val('');
				FormState.updateObjectValue(e.target.id,'');
            }
        });
		}
		else{
			$('#leave_length').text('');
			$('#leave_length_2').text('');
		}
	}
}
function dateChangeEventConduct(e){
	var id = e.target.id;
	var dt1 ='';
	var dt2 ='';
	switch(id){
		case 'CI_TERM_PROP_ACTION_DT':
			dateValidateHelper('CI_TERM_PROP_ACTION_DT','CI_TERM_DECISION_ISSUED_DT','CI_TERM_DECISION_ISSUED_DT');
		break;
		case 'CI_SUSP_PROP_ACTION_DT':
			dateValidateHelper('CI_SUSP_PROP_ACTION_DT','CI_SUSP_DECISION_ISSUED_DT','CI_SUSP_PROP_ACTION_DT');
		break;
		case 'CI_REMOVAL_PROP_ACTION_DT':
			dateValidateHelper('CI_REMOVAL_PROP_ACTION_DT','CI_REMOVAL_DECISION_ISSUED_DT','CI_REMOVAL_PROP_ACTION_DT');
		break;
		case 'CI_DECISION_ISSUED_DT':
			dateValidateHelper('CI_DECISION_ISSUED_DT','CI_PROPOSE_ACTION_ISSUED_DT','CI_PROP_ACTION_ISSUED_DT');
		break;	
	}
	
}
function terminationationTpe(id,val){
	if(val ==='pre_emp'){
		hyf.util.showComponent('termination_type_pre_employment_group');
		hyf.util.hideComponent('termination_type_probation_group');
	}else if(val==='probation'){
		hyf.util.showComponent('termination_type_probation_group');
		hyf.util.hideComponent('termination_type_pre_employment_group');
	}else{
		hyf.util.hideComponent('termination_type_pre_employment_group');
		hyf.util.hideComponent('termination_type_probation_group');
	}
	$('#action_Termination_group input').val('');
	$('#action_Termination_group input[type=checkbox]').prop('checked',false);
	$('#action_Termination_group select').not('#CI_TERMINATION_TYPE').val('');
	$('#pre_emp_termination_oral_presentation_group').hide();
	$('#pre_emp_termination_response_group').hide();
}
function actionTypeEvent(actionValue,value2){
	var actions = ['Demotion','Suspension','Reprimand','Termination','Removal'];
	if(value2 && value2  !== undefined){
			showCaseView('action_'+value2.replace(/\s/g,'')+'_group',ConductIssue.groups);//CI_SUSP_WRITTEN_RESP
			$('#CI_EMP_APPEAL_DECISION').val('');
			FormState.updateObjectValue('CI_EMP_APPEAL_DECISION','');
			if(value2 !== '' && actions.includes(value2)){
				hyf.util.showComponent('emp_appeal_decision_group');
			}else{
				hyf.util.hideComponent('emp_appeal_decision_group');
			}
			//cms_case_track_main.actionOnChange('CI_DEMO_APPEAL_DECISION');conduct_issue_layout
			$('#conduct_issue_layout input[type="text"]').val('');
			$('#conduct_issue_layout input[type="checkbox"]').prop('checked',false);
			$('#conduct_issue_layout select[id!="CI_ACTION_TYPE"]').val('');
		}
}
function dateDecisionIssued(e){
	var days = 0;
	var dt1 = $('#CI_PROPOSE_ACTION_ISSUED_DT').val();
	var dt2 = $('#CI_DECISION_ISSUED_DT').val();
	if(dt2 && dt1){
		var m1  = new Date(dt1);
		var m2 = new Date(dt2);
		if(m2.getTime() < m1.getTime()){
			bootbox.alert({
            message: 'Date must be greater than Date Proposed Action Issued to Employee Date.',
            callback: function(){
                $('#CI_DECISION_ISSUED_DT').val('');
				FormState.updateObjectValue('CI_DECISION_ISSUED_DT','');
            }
        });
	}
}
}
function helperEventHandler(e){
	var target = e.target;
	var dropdownAction = target.options[target.options.selectedIndex].value;
	FormState.updateObjectValue(target.id, dropdownAction);
	dropdownCallBack(target.id,dropdownAction);
}
function hyfToogle(val,id){
	CommonOpUtil.hyfShowOrHide({value:val},id);	
}

function dropdownCallBack(dropdownId, value){
	if(typeof dropdownId !=='undefined'){
		if(ConductIssue.inputEvents[dropdownId] !=='undefined' && typeof ConductIssue.inputEvents[dropdownId] === 'function'){
			ConductIssue.inputEvents[dropdownId](dropdownId,value);
		}
		else if( typeof ConductIssue.inputEvents[dropdownId] === 'object' && ConductIssue.inputEvents[dropdownId].action !=='undefined'){
			var target = ConductIssue.inputEvents[dropdownId].target;
			ConductIssue.inputEvents[dropdownId].action(value,target);
		}
		
	}
}
function timeStampToDays(date1,date2){
	var oneDay = 24*60*60*1000; // hours*minutes*seconds*milliseconds
	var firstDate = new Date(date1);
	var secondDate = new Date(date2);
	return {val: Math.round((secondDate.getTime()- firstDate.getTime())/oneDay),timeStamp1: firstDate.getTime(),timeStamp2 : secondDate.getTime()};
}
function showCaseView (caseValue,arr){
	arr.forEach(function(el,index){
	if(el === caseValue){  
		hyf.util.showComponent(el);
		$('#' + el).find('input:text').val('');		
	}else{
		$('#' + el).find('input:text').val('');		
		hyf.util.hideComponent(el);
	}			
});
}

function clear(item){
	if(item.target.id === 'admin_leave_clear'){
		$('#CI_APPROVAL_NAME').val('');
	}
	if(item.target.id === 'admin_leave_ntc_clear'){
		$('#CI_APPROVAL_NAME_2').val('');
	}
	if(item.target.id !=='' && item !== ''){
		$('#' +item).val('');
	}
}
function populateCurrentPosition(item){
	if(item !== undefined && item !== ''){
	var currentPosition = item.split(',');
	$('#CI_POS_TITLE').text(currentPosition[8]);
	$('#CI_PPLAN').text(currentPosition[6]);
	$('#CI_SERIES').text(currentPosition[7]);
	$('#CI_CURRENT_INFO_GRADE').text(currentPosition[4]);
	$('#CI_CURR_ADMIN_CODE').text(currentPosition[2]);//curr_admin_code
	$('#CI_RE_ASSIGNMENT_CURR_ORG').text(currentPosition[3]);//re_assignment_curr_org
	}	
}

function dateValidateHelper(id,id2,target){
	var dt1 =$('#' + id).val();
	var dt2 = $('#' + id2).val();
	if(dt1 !== ''){
		
	}
	if(dt2 !==''){
		
	}
}
function appendAdminCode(item){
		var admin_code = item.adminCode +' - '+item.description;
	return '<a role="option">' + admin_code +'</a>'
}

function populateAdminCode(item){
	$('#CI_FINAL_ADMIN_CODE').val(item.adminCode);
	$('#CI_RE_ASSIGNMENT_FINAL_ORG').text(item.description);
}

function booleanCheckBox(group){
	var checked  = false;
	var list  = $('.' + group).get(); 
	if(list && Array.isArray(list)&& list.length > 0){
		list.forEach(function(el){
			if($(el).prop('checked')){
				checked = true;
			}
		});
	}
	return checked;
}

function dateAutoPopulate(targetId,sourceValue){
	if(sourceValue !==''){
		$('#' +targetId).val(sourceValue);
	}
}
function populateGrades(e){
		var source = e.target.id;
		var target = '';
		var payPlan = e.target.options[e.target.options.selectedIndex].value;
		if(source === 'CI_PROPOSED_PPLAN'){
			target ='CI_PROPOSED_INFO_GRADE';
		}else{
			target = 'CI_FINAL_INFO_GRADE';
		}
		$('#' +target).html('');
		if(payPlan !=='default' &&  ConductIssue.grades[payPlan] !== undefined){
		 $('#' + target).append('<option value="default">Select one </option>');
		 ConductIssue.grades[payPlan].forEach(function(val){	
			$('#' + target).append('<option value="' + val + '">' + val + '</option>');
		});
		hyf.util.showComponent(target);
	}else{
		hyf.util.hideComponent(target,null);
	}
}
function populateDateItems(displayId,hiddenValue){	
	var hiddenSelection = hiddenValue.split(',');
		if(Array.isArray(hiddenSelection) && hiddenSelection.length > 0){
		$('#' + displayId).html('');
		hiddenSelection.forEach(function(el){
			//append string
		});
	}
}