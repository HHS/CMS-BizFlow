'use strict';
(function (window) {
    var cms_erlr_labor_negotiation = function () {
	
		var initialized = false;
		
		var dateFieldsPastPresent = 
		[
		];
		
		var dateFieldsPresentFuture = 
		[
		];
		
		var reqFieldForActivity = 
		[
			{
				actName: globalVars.actAll,
				reqFieldIds: 
				[
				]
			},
			{
				actName: globalVars.actCaseCreation,
				reqFieldIds: 
				[
				]
			},
			{
				actName: globalVars.actCaseComplete,
				reqFieldIds: 
				[
				]
			}
		];

		function initVisibility() {
            controlXXXVisibility();
		}

		function setSelectElemValue(selElem) {
			if ( typeof selElem == 'undefined' || selElem == null 
					|| typeof selElem.id == 'undefined' || selElem.id == null 
					|| typeof selElem.options == 'undefined' || selElem.options == null ) {
				return;
			}
			var selectedVal = selElem.options[selElem.options.selectedIndex].value;
			var selectedTxt = selElem.options[selElem.options.selectedIndex].text;
			FormState.updateSelectValue(selElem.id, selectedVal, selectedTxt);
		}
		
		function controlXXXVisibility() {
            var elemVal = FormState.getElementValue('XXX');
			CommonOpUtil.showHideLayoutGroup('ir_cms_requester_layout_group', ('CMS' === elemVal));
			CommonOpUtil.showHideLayoutGroup('ir_non_cms_requester_layout_group', ('NONCMS' === elemVal));
        }

		function initEventHandlers() {
			$('#XXX').on('change', function(e) {
				setSelectElemValue(e.target);
				controlXXXVisibility();
			});
		}

        function setupCustomWidget() {
        }


        function init() {
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_labor_negotiation::init START');
			
			//-----------------------------------
			// visibility configuration
			//-----------------------------------
			initVisibility();
			
			
			//-----------------------------------
			// validation configuration
			//-----------------------------------
			dateFieldsPastPresent.forEach(function(item){
				hyf.calendar.setDateConstraint(item, 'Maximum', 'Today');
			});
			dateFieldsPresentFuture.forEach(function(item){
				hyf.calendar.setDateConstraint(item, 'Minimum', 'Today');
			});
			CommonOpUtil.dynamicMandatory(reqFieldForActivity);
			
			
			//-----------------------------------
			// event handler configuration
			//-----------------------------------
			initEventHandlers();
			
			
			//-----------------------------------
			// custom ui element initialization
			//-----------------------------------
			setupCustomWidget();
			
			initialized = true;
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_labor_negotiation::init END');
		}
		
		function render() {
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_labor_negotiation::render START');
			
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_labor_negotiation::render END');
		}
		
		return {
			initialized: initialized,
			render: render,
			init: init
		};
	};
	
    var _initializer = window.cms_erlr_labor_negotiation || (window.cms_erlr_labor_negotiation = cms_erlr_labor_negotiation());
})(window);
