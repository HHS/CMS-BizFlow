'use strict';
(function (window) {
    var cms_erlr_labor_negotiation = function () {

        var initialized = false;

        /* var dateFieldsPastPresent =
            [
			'LN_BRIEFING_DT',
			'LN_PROPOSAL_INFO_NEG_COMMENCED_DT'
			]; */
        var groups =
            [
			  'LN_UNION_GROUP'
			, 'LN_PROPOSAL_INFO_GROUP'
			, 'LN_PROPOSAL_NOT_SUBMITTED_GROUP'
			, 'LN_PROPOSAL_SUBMITTED_GROUP'
			, 'LN_NEGOTIABLE_PROPOSAL_GROUP'
			, 'LN_NEGOTIABLE_SUBMITTED'
			, 'LN_NEGOTIABLE_NOT_SUBMITTED'
			, 'LN_MANAGEMENT_GROUP'
			, 'LN_RESPOND_TO_NTC_GROUP'
			, 'LN_LETTER_SUB_GROUP'
			, 'LN_MNGMNT_NOTICE_RESPONSE_GROUP'
			, 'LN_BRIEFING2_LAYOUT'
			, 'LN_BRIEFING_LAYOUT'
			, 'LN_ULP_layout_group'
			, 'LN_PROPOSAL_SUMISSION_GROUP'
			,'letter_provided_layout_group'
			,'LN_UNION_RESPONSE_2_NOTICE_GROUP'
            ]
        var dateFields =
            [
			'LN_BRIEFING_DT',
			'LN_BRIEFING_REQUESTED2_DT',
			'LN_PROPOSAL_INFO_NEG_COMMENCED_DT',
			'LN_BRIEFING_REQUESTED2_DT',
			'LN_BRIEFING_REQUESTED2_DT'
			];

        var reqFieldForActivity =
            [
                {
                    actName: globalVars.actAll,
                    reqFieldIds:
                        []
                },
                {
                    actName: globalVars.actCaseCreation,
                    reqFieldIds:
                        []
                },
                {
                    actName: globalVars.actCaseComplete,
                    reqFieldIds:
                        [
                            'LN_NEGOTIATION_TYPE'
                            , 'LN_INITIATOR'
                            , 'LN_BRIEFING_REQUEST'
                            , 'LN_MNGMNT_BRIEFING_REQUEST'
                            , 'LN_PROPOSAL_SUBMISSION'
                            , 'LN_PROPOSAL_NEGOTIABLE'
                            , 'LN_NON_NEGOTIABLE_LETTER'
                            , 'LN_LETTER_PROVIDED_DT'
                            , 'LN_NEGOTIABLE_PROPOSAL'
                            , 'LN_FSIP_DECISION_DT'
                            , 'LN_MNGMNT_NOTICE_RESPONSE'
							,'LN_BRIEFING_REQUESTED2_DT'
							,'LN_BRIEFING_DT'
							,'LN_LETTER_PROVIDED'
                        ]
                }
            ];

        function initVisibility() {
        }

        function setSelectElemValue(selElem) {
            if (typeof selElem == 'undefined' || selElem == null
                || typeof selElem.id == 'undefined' || selElem.id == null
                || typeof selElem.options == 'undefined' || selElem.options == null) {
                return;
            }
            var selectedVal = selElem.options[selElem.options.selectedIndex].value;
            var selectedTxt = selElem.options[selElem.options.selectedIndex].text;
            FormState.updateSelectValue(selElem.id, selectedVal, selectedTxt);
        }

        function initEventHandlers() {
            onLoadEventHandlers();
        }

        function initiatorEventHandler(e) {
            var initiator;
			
            try {
                initiator = e.target.options[e.target.selectedIndex].value;
				
                if (initiator != undefined) {
                    if (initiator === 'union') {
                        CommonOpUtil.showHideLayoutGroup('LN_UNION_GROUP', true);
                        CommonOpUtil.showHideLayoutGroup('LN_PROPOSAL_INFO_GROUP', true);
                        CommonOpUtil.showHideLayoutGroup('LN_MANAGEMENT_GROUP', false);
                        CommonOpUtil.showHideLayoutGroup('LN_PROPOSAL_SUMISSION_GROUP', true);															
						clearAll();
                    }
                    else if (initiator === 'management') {
						CommonOpUtil.showHideLayoutGroup('LN_UNION_GROUP', false);
                        CommonOpUtil.showHideLayoutGroup('LN_MANAGEMENT_GROUP', true);
                        CommonOpUtil.showHideLayoutGroup('LN_PROPOSAL_INFO_GROUP', true);
                        CommonOpUtil.showHideLayoutGroup('LN_PROPOSAL_SUMISSION_GROUP', false);															
						clearAll();
                    }
                    else {
                        CommonOpUtil.showHideLayoutGroup('LN_MANAGEMENT_GROUP', false);
                        CommonOpUtil.showHideLayoutGroup('LN_PROPOSAL_INFO_GROUP', false);
                        CommonOpUtil.showHideLayoutGroup('LN_UNION_GROUP', false);
                        CommonOpUtil.showHideLayoutGroup('LN_PROPOSAL_SUMISSION_GROUP', false);
						//$('#LN_PROPOSAL_SUBMISSION').val('');
						clearAll();
                    }
                }
            }
            catch (e) {
            }
        }

        function proposalSubmissionEventHandler(e) {
            var val;
            try {
                val = e.target.options[e.target.selectedIndex].value;
                CommonOpUtil.showHideLayoutGroup('LN_PROPOSAL_INFO_GROUP', val === 'Yes');
            }
            catch (err) {

            }
        }
        function unionProposalNetiableEventHandler(e) {
            var val;
            try {
                val = e.target.options[e.target.selectedIndex].value;
                if (val === 'Yes') {
                    CommonOpUtil.showHideLayoutGroup('LN_PROPOSAL_NOT_SUBMITTED_GROUP', false);
                    CommonOpUtil.showHideLayoutGroup('LN_PROPOSAL_SUBMITTED_GROUP', true);
                } else if (val === 'No') {
                    CommonOpUtil.showHideLayoutGroup('LN_PROPOSAL_NOT_SUBMITTED_GROUP', true);
                    CommonOpUtil.showHideLayoutGroup('LN_PROPOSAL_SUBMITTED_GROUP', false);
                }
                else {
                    CommonOpUtil.showHideLayoutGroup('LN_PROPOSAL_NOT_SUBMITTED_GROUP', false);
                    CommonOpUtil.showHideLayoutGroup('LN_PROPOSAL_SUBMITTED_GROUP', false);
                }
            }
            catch (err) {

            }
        }
		/*
		*/
        function unionNonNegotiableLetterHandler(e) {
            var val;
            try {
                val = e.target.options[e.target.selectedIndex].value;
                CommonOpUtil.showHideLayoutGroup('letter_provided_layout_group', val === 'Yes');
            }
            catch (err){

            }
        }

        function unionLetterProvidedHandler(e) {
            var val;
            try {
                val = e.target.options[e.target.selectedIndex].value;
                CommonOpUtil.showHideLayoutGroup('LN_LETTER_SUB_GROUP', val === 'Yes');
            }
            catch (err) {

            }
        }
		function unionBriefingHandler(e) {
            var val;
            try {
                val = e.target.options[e.target.selectedIndex].value;
                CommonOpUtil.showHideLayoutGroup('LN_BRIEFING_LAYOUT', val === 'Yes');
            }
            catch (err) {

            }
        }
		function managementBriefingHandler(e) {
            var val;
            try {
                val = e.target.options[e.target.selectedIndex].value;
                CommonOpUtil.showHideLayoutGroup('LN_BRIEFING2_LAYOUT', val === 'Yes');
            }
            catch (err) {

            }
        }
		function ULPTriggeredHandler(e) {
            var val;
            try {
                val = e.target.options[e.target.selectedIndex].value;
                CommonOpUtil.showHideLayoutGroup('LN_ULP_layout_group', val === 'Yes');
            }
            catch (err) {

            }
        }
        function unionNegotiableProposalHandler(e){
            var val;
            try {
                val = e.target.options[e.target.selectedIndex].value;
                if (val === 'Yes') {
                    CommonOpUtil.showHideLayoutGroup('LN_NEGOTIABLE_PROPOSAL_GROUP', true);
                    CommonOpUtil.showHideLayoutGroup('LN_NEGOTIABLE_SUBMITTED', true);
                    CommonOpUtil.showHideLayoutGroup('LN_NEGOTIABLE_NOT_SUBMITTED', false);
                }
                else if (val === 'No') {
                    CommonOpUtil.showHideLayoutGroup('LN_NEGOTIABLE_PROPOSAL_GROUP', true);
                    CommonOpUtil.showHideLayoutGroup('LN_NEGOTIABLE_NOT_SUBMITTED', true);
                    CommonOpUtil.showHideLayoutGroup('LN_NEGOTIABLE_SUBMITTED', false);
                }
                else {
                    CommonOpUtil.showHideLayoutGroup('LN_NEGOTIABLE_PROPOSAL_GROUP', false);
                    CommonOpUtil.showHideLayoutGroup('LN_NEGOTIABLE_NOT_SUBMITTED', false);
                    CommonOpUtil.showHideLayoutGroup('LN_NEGOTIABLE_SUBMITTED', false);
                }
            }
            catch (err) {

            }
        }
        function managementNoticeResponse(e) {
			var intiator;
            try {
                var val = e.target.options[e.target.selectedIndex].value;
				intiator = FormState.getElementValue('LN_INITIATOR');
                CommonOpUtil.showHideLayoutGroup('LN_MNGMNT_NOTICE_RESPONSE_GROUP', val === 'Yes');
                CommonOpUtil.showHideLayoutGroup('LN_MNGMN_UNION_RESPOND_TO_NTC_GROUP', val === 'Yes');
				if((intiator && intiator ==='management') && (val ==='Yes')){
					CommonOpUtil.showHideLayoutGroup('LN_PROPOSAL_SUMISSION_GROUP', true);		
				}else if((intiator && intiator ==='management') && (val ==='No')){
					CommonOpUtil.showHideLayoutGroup('LN_PROPOSAL_SUMISSION_GROUP', false);			
				}else {
					if(intiator && intiator ==='union'){
						CommonOpUtil.showHideLayoutGroup('LN_PROPOSAL_SUMISSION_GROUP', true);							
					}
				}
            }
            catch (err) {

            }
        }
        function onLoadEventHandlers() {
            $('#LN_PROPOSAL_NEGOTIABLE').on('change', unionProposalNetiableEventHandler);
            $('#LN_PROPOSAL_SUBMISSION,#LN_MNGMNT_PROPOSAL_SUBMISSION').on('change', proposalSubmissionEventHandler);
            $('#LN_NON_NEGOTIABLE_LETTER').on('change', unionNonNegotiableLetterHandler);
            $('#LN_LETTER_PROVIDED').on('change', unionLetterProvidedHandler);
            $('#LN_NEGOTIABLE_PROPOSAL').on('change', unionNegotiableProposalHandler);
            $('#LN_INITIATOR').on('change', initiatorEventHandler);
            $('#LN_MNGMNT_NOTICE_RESPONSE').on('change', managementNoticeResponse);
            $('#LN_BRIEFING_REQUEST').on('change',unionBriefingHandler);
            $('#LN_MNGMNT_BRIEFING_REQUEST').on('change',managementBriefingHandler);
            $('#LN_FILE_ULP').on('change',ULPTriggeredHandler);
        }
        function clearAll(){
            CommonOpUtil.clearGroupContent('LN_PROPOSAL_INFO_GROUP');
            CommonOpUtil.clearGroupContent('LN_PROPOSAL_SUMISSION_GROUP');
        }

        function init() {
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_labor_negotiation::init START');

            //-----------------------------------
            // visibility configuration
            //-----------------------------------
            initVisibility();

            groups.forEach(function (el, index) {
                hyf.util.hideComponent(el);
            });

            //-----------------------------------
            // validation configuration
            //-----------------------------------
            CommonOpUtil.setDateConstraintMaximumToday(dateFields);
            //CommonOpUtil.setDateConstraintMinimumToday(dateFields);
			
            CommonOpUtil.dynamicMandatory(reqFieldForActivity);


            //-----------------------------------
            // event handler configuration
            //-----------------------------------
            initEventHandlers();
            //onLoad();

            //-----------------------------------
            // custom ui element initialization
            //-----------------------------------
            //setupCustomWidget();

            initialized = true;
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_labor_negotiation::init END');
        }

        var firstRendering = true;
        function render() {
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_labor_negotiation::render START');
            var initiator = FormState.getElementValue('LN_INITIATOR');
            var proposalSubmission = FormState.getElementValue('LN_PROPOSAL_SUBMISSION');
            var unionNonNegotiableLetter = FormState.getElementValue('LN_NON_NEGOTIABLE_LETTER');
            var unionLetterProvided = FormState.getElementValue('LN_LETTER_PROVIDED');
            var unionNegotiableProposal = FormState.getElementValue('LN_NEGOTIABLE_PROPOSAL');
            var managementResponsenotice = FormState.getElementValue('LN_MNGMNT_NOTICE_RESPONSE');
            var ulpNote = FormState.getElementValue('LN_FILE_ULP');
            if (initiator != undefined){
                if (initiator === 'union') {
                    CommonOpUtil.showHideLayoutGroup('LN_UNION_GROUP', true);
                    CommonOpUtil.showHideLayoutGroup('LN_MANAGEMENT_GROUP', false);
                }
                else if (initiator === 'management') {
                    CommonOpUtil.showHideLayoutGroup('LN_MANAGEMENT_GROUP', true);
                    CommonOpUtil.showHideLayoutGroup('LN_UNION_GROUP', false);
                }
                else {
                    CommonOpUtil.showHideLayoutGroup('LN_MANAGEMENT_GROUP', false);
                    CommonOpUtil.showHideLayoutGroup('LN_UNION_GROUP', false);
                }
            }
            CommonOpUtil.showHideLayoutGroup('LN_PROPOSAL_INFO_GROUP', proposalSubmission === 'Yes');
            CommonOpUtil.showHideLayoutGroup('LN_LETTER_GROUP', unionNonNegotiableLetter === 'Yes');
            CommonOpUtil.showHideLayoutGroup('LN_LETTER_SUB_GROUP', unionLetterProvided === 'Yes');
            CommonOpUtil.showHideLayoutGroup('LN_MNGMNT_NOTICE_RESPONSE_GROUP', managementResponsenotice === 'Yes');
            CommonOpUtil.showHideLayoutGroup('LN_MNGMN_UNION_RESPOND_TO_NTC_GROUP', managementResponsenotice === 'Yes');
            if(unionNegotiableProposal === 'Yes') {
                CommonOpUtil.showHideLayoutGroup('LN_NEGOTIABLE_PROPOSAL_GROUP', true);
                CommonOpUtil.showHideLayoutGroup('LN_NEGOTIABLE_SUBMITTED', true);
                CommonOpUtil.showHideLayoutGroup('LN_NEGOTIABLE_NOT_SUBMITTED', false);
            }
            else if(unionNegotiableProposal === 'No') {
                CommonOpUtil.showHideLayoutGroup('LN_NEGOTIABLE_PROPOSAL_GROUP', true);
                CommonOpUtil.showHideLayoutGroup('LN_NEGOTIABLE_NOT_SUBMITTED', true);
                CommonOpUtil.showHideLayoutGroup('LN_NEGOTIABLE_SUBMITTED', false);
            }
            else {
                CommonOpUtil.showHideLayoutGroup('LN_NEGOTIABLE_PROPOSAL_GROUP', false);
                CommonOpUtil.showHideLayoutGroup('LN_NEGOTIABLE_NOT_SUBMITTED', false);
                CommonOpUtil.showHideLayoutGroup('LN_NEGOTIABLE_SUBMITTED', false);
            }
            var val = FormState.getState('LN_PROPOSAL_NEGOTIABLE');
			var val2 = FormState.getState('LN_MNGMNT_PROPOSAL_SUBMISSION');
			var ulpFiling = FormState.getElementValue('LN_FILE_ULP');
			
            if((val && val.dirty)){
				if (val.value === 'Yes'){
					CommonOpUtil.showHideLayoutGroup('LN_PROPOSAL_NOT_SUBMITTED_GROUP', false);
					CommonOpUtil.showHideLayoutGroup('LN_PROPOSAL_SUBMITTED_GROUP', true);
				} else if (val.value === 'No') {
					CommonOpUtil.showHideLayoutGroup('LN_PROPOSAL_NOT_SUBMITTED_GROUP', true);
					CommonOpUtil.showHideLayoutGroup('LN_PROPOSAL_SUBMITTED_GROUP', false);
				}
				else {
					CommonOpUtil.showHideLayoutGroup('LN_PROPOSAL_NOT_SUBMITTED_GROUP', false);
					CommonOpUtil.showHideLayoutGroup('LN_PROPOSAL_SUBMITTED_GROUP', false);
				}
			}
            if(firstRendering || FormState.isDirty('LN_SECON_LETTER_REQUEST')){
                CommonOpUtil.showHideLayoutGroup('LN_2ND_LETTER_PROVIDED_GROUP', FormState.getElementBooleanValue('LN_SECON_LETTER_REQUEST'));
            }
            if(firstRendering || FormState.isDirty('LN_2ND_LETTER_PROVIDED')){
                CommonOpUtil.showHideLayoutGroup('LN_2ND_PROVIDED_DT_GROUP', FormState.getElementBooleanValue('LN_2ND_LETTER_PROVIDED'));
            }
			if(FormState.isDirty('LN_FILE_ULP')){
                CommonOpUtil.showHideLayoutGroup('LN_ULP_layout_group',FormState.getElementBooleanValue('LN_FILE_ULP'));
            }
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_labor_negotiation::render END');
            firstRendering = false;
        }
        return {
            initialized: initialized,
            render: render,
            init: init
        };
    };

    var _initializer = window.cms_erlr_labor_negotiation || (window.cms_erlr_labor_negotiation = cms_erlr_labor_negotiation());
})(window);
