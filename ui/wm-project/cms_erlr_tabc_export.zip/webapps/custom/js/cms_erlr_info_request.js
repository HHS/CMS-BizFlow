'use strict';
(function (window) {
    var cms_erlr_info_request = function () {

        var initialized = false;

        var dateFieldsPastPresent =
            [
                '_IR_PROVIDE_DT',
                'IR_SUBMIT_DT',
                '_IR_DENIAL_NOTICE_DT'
            ];

        var dateFieldsPresentFuture =
            [];

        var reqFieldForActivity =
            [
                {
                    actName: globalVars.actAll,
                    reqFieldIds:
                        []
                },
                {
                    actName: globalVars.actCaseCreation,
                    reqFieldIds:
                        []
                },
                {
                    actName: globalVars.actCaseComplete,
                    reqFieldIds:
                        ['IR_REQUESTER',
                        'IR_NON_CMS_REQUESTER_LAST_NAME',
                        'IR_NON_CMS_REQUESTER_FIRST_NAME',
                        'IR_NON_CMS_REQUESTER_PHONE',
                        'IR_NON_CMS_REQUESTER_ORGANIZATION_AFFILIATION',
                        'IR_NON_CMS_REQUESTER_EMAIL',
                        'IR_SUBMIT_DT',
                        'IR_MEET_PARTICULARIZED_NEED_STANDARD',
                        'IR_REASONABLY_AVAILABLE_AND_NECESSARY',
                        'IR_PROTECTED_FROM_DISCLOSURE_BY_LAW',
                        'IR_MAINTAINED_BY_AGENCY',
                        'IR_COLLECTIVE_BARGAINING_UNIT',
                        'IR_APPROVE',
                        'IR_APPEAL_DENIAL'
                        ]
                }
            ];

        var irProvideDtGroup, irDenialNoticeDtGroup;

        function initVisibility() {
            controlIrRequesterVisibility();
            controlIrApprovedVisibility();
            controlIrRequesterAppealDenialVisibility();
        }

        function setSelectElemValue(selElem) {
            if (typeof selElem == 'undefined' || selElem == null
                || typeof selElem.id == 'undefined' || selElem.id == null
                || typeof selElem.options == 'undefined' || selElem.options == null) {
                return;
            }
            var selectedVal = selElem.options[selElem.options.selectedIndex].value;
            var selectedTxt = selElem.options[selElem.options.selectedIndex].text;
            FormState.updateSelectValue(selElem.id, selectedVal, selectedTxt);
        }

        function controlIrRequesterVisibility() {
            var elemVal = FormState.getElementValue('IR_REQUESTER');
            CommonOpUtil.showHideLayoutGroup('ir_cms_requester_layout_group', ('CMS' === elemVal));
            CommonOpUtil.showHideLayoutGroup('ir_non_cms_requester_layout_group', ('NONCMS' === elemVal));
        }

        function controlIrApprovedVisibility() {
            var elemVal = FormState.getElementValue('IR_APPROVE');
            if ('Yes' === elemVal) {
                CommonOpUtil.showHideLayoutGroup('ir_provide_dt_group', true);
                CommonOpUtil.showHideLayoutGroup('ir_not_approved_layout_group', false);
                CommonOpUtil.showHideLayoutGroup('ir_approved_in_part_layout_group', false);
            } else if ('No' === elemVal) {
                CommonOpUtil.showHideLayoutGroup('ir_provide_dt_group', false);
                CommonOpUtil.showHideLayoutGroup('ir_not_approved_layout_group', true);
                CommonOpUtil.showHideLayoutGroup('ir_approved_in_part_layout_group', false);

            } else if ('Approved in Part' === elemVal) {
                CommonOpUtil.showHideLayoutGroup('ir_provide_dt_group', false);
                CommonOpUtil.showHideLayoutGroup('ir_not_approved_layout_group', false);
                CommonOpUtil.showHideLayoutGroup('ir_approved_in_part_layout_group', true);
            } else {
                CommonOpUtil.showHideLayoutGroup('ir_provide_dt_group', false);
                CommonOpUtil.showHideLayoutGroup('ir_not_approved_layout_group', false);
                CommonOpUtil.showHideLayoutGroup('ir_approved_in_part_layout_group', false);
            }

        }

        function controlIrRequesterAppealDenialVisibility() {
            CommonOpUtil.showHideLayoutGroup('ir_appeal_denial_note_group', FormState.getElementBooleanValue('IR_APPEAL_DENIAL'));
        }


        function initEventHandlers() {
            $('#IR_REQUESTER').on('change', function (e) {
                setSelectElemValue(e.target);
                controlIrRequesterVisibility();
            });
            $('#IR_APPROVE').on('change', function (e) {
                setSelectElemValue(e.target);
                controlIrApprovedVisibility();
            });
            $('#IR_APPEAL_DENIAL').on('change', function (e) {
                setSelectElemValue(e.target);
                controlIrRequesterAppealDenialVisibility();
            });


            irProvideDtGroup = MultiDataSelectField.init({
                layoutGroupId: 'ir_provide_dt_group',
                mandatory: true,
                dataFieldId: 'IR_PROVIDE_DT_LIST',
                sort: {fieldId: 'IR_PROVIDE_DT', valueType: 'date', order: 'desc'},
                recordFields: ['IR_PROVIDE_DT'],
				dialog: {
					input: {
						init: function(){
							// set tooltips
							var container = $('#IR_PROVIDE_DT_LIST_input_dialog').parent().parent().parent();
							$('button.btn.btn-primary', container).prop('title', 'Click the add button to have the date information provided appear on the form and return to the Information Request tab.');
							$('button.btn.btn-default', container).prop('title', 'Click the cancel button to return to the Information Request tab without saving a date that the information was provided.');				
						}
					}
				}
            });

            irDenialNoticeDtGroup = MultiDataSelectField.init({
                layoutGroupId: 'ir_denial_notice_dt_group',
                mandatory: true,
                dataFieldId: 'IR_DENIAL_NOTICE_DT_LIST',
                sort: {fieldId: 'IR_DENIAL_NOTICE_DT', valueType: 'date', order: 'desc'},
                recordFields: ['IR_DENIAL_NOTICE_DT', 'IR_DENIAL_NOTICE_REASON'],
                dialog: {
                    input: {
                        init: function () {
							// set tooltips
							var container = $('#IR_DENIAL_NOTICE_DT_LIST_input_dialog').parent().parent().parent();
							$('button.btn.btn-primary', container).prop('title', 'Click the add button to save the Date of Denial Notice and return to the Information Request tab.');
							$('button.btn.btn-default', container).prop('title', 'Click the cancel button to return to the Information Request tab without saving data you entered for Date of Denial Notice.');				
                            $('#_IR_DENIAL_NOTICE_SELECT_REASON').on('change', function (e) {
                                var selElem = e.target;
                                if (0 < selElem.options.selectedIndex) {
                                    var selectedValue = selElem.options[selElem.options.selectedIndex].text;
                                    var priorValue = $('#_IR_DENIAL_NOTICE_REASON').val();
                                    if (-1 === priorValue.indexOf(selectedValue)) {
                                        var txt = '• ' + selectedValue;
                                        var val = priorValue.trim();
                                        $('#_IR_DENIAL_NOTICE_REASON').val(val.length === 0 ? txt : val + '\n' + txt);
                                    }
                                }
                            });
                        }
                    }
                }
            });

        }

        function setupCustomWidget() {
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_info_request::setupCustomWidget START');

            FormAutoComplete.makeAutoCompletion(FormMain.getAutoCompleteOptionForEmployee('IR_CMS_REQUESTER_NAME_SEARCH', 'IR_CMS_REQUESTER_NAME'));

            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_info_request::setupCustomWidget END');
        }


        function init() {
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_info_request::init START');

            //-----------------------------------
            // visibility configuration
            //-----------------------------------
            initVisibility();


            //-----------------------------------
            // validation configuration
            //-----------------------------------
            CommonOpUtil.setDateConstraintMaximumToday(dateFieldsPastPresent);
            CommonOpUtil.setDateConstraintMinimumToday(dateFieldsPresentFuture);
            CommonOpUtil.dynamicMandatory(reqFieldForActivity);


            //-----------------------------------
            // event handler configuration
            //-----------------------------------
            initEventHandlers();


            //-----------------------------------
            // custom ui element initialization
            //-----------------------------------
            setupCustomWidget();

            initialized = true;
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_info_request::init END');
        }

        function render() {
            irProvideDtGroup.render();
            irDenialNoticeDtGroup.render();
        }

        return {
            initialized: initialized,
            render: render,
            init: init
        };
    };

    var _initializer = window.cms_erlr_info_request || (window.cms_erlr_info_request = cms_erlr_info_request());
})(window);

