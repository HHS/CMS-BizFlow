var TRACK_TAB = {
    initialized: false,
    track_request_details : {},
    init: function (){
        //TRACK_TAB.getCertificates();
        TRACK_TAB.setJobNumberAutoComplete();
        TRACK_TAB.renderPositionNumberGroup(1);
    },
    render: function () {
        if(!TRACK_TAB.initialized){
            var job_codeNumber = FormState.getState('interface_job_requisitionNumber');
            if(job_codeNumber && job_codeNumber.dirty){
                TRACK_TAB.getJobDetail(job_codeNumber.value);
            }else{
                TRACK_TAB.renderPositionNumberGroup(1);
            }
            hyf.util.hideComponent('re_ann_reason_group');
            TRACK_TAB.initialized = true;
        }

    },
    renderPositionNumberGroup : function(numb){
        var count = numb ? parseInt(numb) + 1 : 1,vac = numb ? parseInt(numb) : 1;
        for (var fieldGroup = count; fieldGroup <= 5; fieldGroup++){
            hyf.util.hideComponent('positionNumberGroup_' + fieldGroup);
        }
        for (var fieldGroup = 1; fieldGroup <= vac; fieldGroup++){
            hyf.util.showComponent('positionNumberGroup_' + fieldGroup);
        }
    },
    loadJobNumberDetails: function (request, response){
        $.ajax({
            url:  '/bizflowwebmaker/ihsrec_track/loadTrackRequest.do',
            data: {searchString: $('#interface_job_requisitionNumber').val()},
            dataType: 'xml',
            cache: false,
            success: function (xmlResponse) {
                var data = $('record', xmlResponse).map(function () {
                    return {
                        JOB_OPEN_NUMBER : $('HRS_JOB_OPENING_ID', this).text()
                    };
                }).get();
                response(data);
            }
        });
    },
    setJobNumberAutoComplete: function () {
        $('#interface_job_requisitionNumber').autocomplete({
            source: function (request, response) {
                TRACK_TAB.loadJobNumberDetails(request, response);
            },
            minLength: 1,
            change: function (e, u) {
                var pos = $(this).position();
                if (u.item == null) {
                    $(this).val('');
                    return false;
                }
            },
            select: function (event, ui) {
                event.preventDefault();
                var dl = ui.item.JOB_OPEN_NUMBER;
                $('#interface_job_requisitionNumber').val(dl);
                TRACK_TAB.getJobDetail(dl);//populatePageData([ui.item]);
                FormState.doAction(StateAction.changeText('interface_job_requisitionNumber', dl), false);
            },
            open: function () {
                $('.ui-autocomplete').css('z-index', 5000);
            },
            close: function () {
                $('.ui-autocomplete').css('z-index', 1);
            }
        })
            .autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
            return $('<li>')
                .append('<a>'+item.JOB_OPEN_NUMBER+'</a>')
                .appendTo(ul);
        };
    }
    ,
    populatePageData : function(inputData){
        if(inputData && Array.isArray(inputData) && inputData.length > 0){
            $('#interface_postingTitle').text(inputData[0].JOB_POSTING_TITLE);
            $('#interface_geo_Loc').text(inputData[0].GEO_LOCATION_CODE);
            $('#approverName').text(inputData[0].APPROVER_USER_NAME);
            $('#interface_authorizeDate').text(inputData[0].AUTHORIZATION_DATE);
            $('#interface_openStatus_code').text(inputData[0].OPEN_STATUS_CODE);
            $('#interface_jobOpenStatusDate').text(inputData[0].STATUS_DATE);
            $('#interface_adminCode_desc').text(inputData[0].ADMIN_CODE);
            $('#interface_openDate').text(inputData[0].OPEN_DATE);
            $('#interface_LocDesc').text(inputData[0].GEO_LOCATION_DESCR);
            $('#interface_approverEmpID').text(inputData[0].APPROVER_EMPLID);//not found
            $('#interface_openingStatus').text(inputData[0].OPENING_STATUS);
            $('#interface_statusLastUpdated').text(inputData[0].STATUS_DATE);
            $('#interface_number_of_vacancies').text(inputData[0].NUMBER_OF_VACANCIES);
            $('#can_numb').text(inputData[0].CAN);
            $('#interface_approvalComments').text('');
            $('#interface_remarks').text(inputData[0].REMARKS);
            var numOfVacancies =  inputData[0].NUMBER_OF_VACANCIES ? parseInt(inputData[0].NUMBER_OF_VACANCIES) : 1;
            TRACK_TAB.renderPositionNumberGroup(numOfVacancies);
        }
    },
    populateCertificateTable : function(cellObjArray) {
        if (cellObjArray && Array.isArray(cellObjArray)) {
            $('#certificates').html('');
            if (cellObjArray.length > 0) {
                $('#cert_info').text(cellObjArray[0].CERT_LAST_UPDATED_DATE);
                cellObjArray.forEach(function (el, index) {
                    var row = '<tr"><td style="font-weight:normal !important;">' + cellObjArray[index].CERTIFICATE_NUMBER + '</td>'
                        + '<td style="font-weight:normal !important;">' + cellObjArray[index].CERTIFICATE_ISSUE_DATE + '</td>'
                        + '<td style="font-weight:normal !important;">' + cellObjArray[index].CERTIFICATE_DUE_DATE + '</td>'
                        + '<td style="font-weight:normal !important;">' + cellObjArray[index].CERTIFICATE_RETURN_DATE + '</td>'
                        + '<td style="font-weight:normal !important;">' + cellObjArray[index].ANNOUNCEMENT_NUMBER + '</td>'
                        + '</tr>';

                    if (cellObjArray[index].CERTIFICATE_NUMBER && cellObjArray[index].CERTIFICATE_ISSUE_DATE && cellObjArray[index].CERTIFICATE_RETURN_DATE) {
                        $('#certificates').append(row);
                    }
                });
            }
        }
    },
    populateNewHire : function(cellObjArray) {
        if (cellObjArray && Array.isArray(cellObjArray)) {
            if (cellObjArray.length > 0) {
                cellObjArray.forEach(function (el, index) {
                    var index2 = index + 1;
                    $('#newHireName_' + index2).text(cellObjArray[index].NEW_HIRE_NAME);
                    $('#interface_positionTitle_' + index2).text(cellObjArray[index].NEW_HIRE_POSITION_TITLE);
                    $('#interface_dutyLoc_' + index2).text(cellObjArray[index].NEW_HIRE_DUTY_LOCATION);
                    $('#interface_sendOffer_' + index2).text(cellObjArray[index].NEW_HIRE_SEND_OFFER);
                    $('#n_hire_info_' + index2).text(cellObjArray[index].NEW_HIRE_LAST_UPDATED_DATE);
                    $('#interface_effectiveDate_' + index2).text(cellObjArray[index].NEW_HIRE_EFFECTIVE_DATE);
                    $('#interface_newHireNo_' + index2).text(cellObjArray[index].NEW_HIRE_NUMBER);
                    $('#interface_pplanSeries_grade_' + index2).text(cellObjArray[index].NEW_HIRE_PAYPLAN_SERIES_GRADE);

                    if (cellObjArray[index].NEW_HIRE_NAME) {
                        hyf.util.showComponent('USAStaffingNewHire_' + index2);
                    }
                });
            }
        }
    },
    populateAnnouncement: function(cellObjArray){
        $('#interface_req_number').text(cellObjArray[0].REQUEST_NUMBER);
        $('#interface_vacancyType').text(cellObjArray[0].VACANCY_TYPE);
        $('#interface_annNumber').text(cellObjArray[0].ANNOUNCEMENT_NUMBER);
        $('#interface_joaDate').text(cellObjArray[0].JOA_DATE);
        $('#interface_annDate').text(cellObjArray[0].ANNOUNCEMENT_DATE);
        $('#interface_announceCloseDate').text(cellObjArray[0].ANNOUNCEMENT_CLOSE_DATE);
        $('#interface_annType').text(cellObjArray[0].ANNOUNCEMENT_TYPE);
        $('#interface_location').text(cellObjArray[0].ANNOUNCEMENT_LOCATION);
        $('#ann_info').text(cellObjArray[0].ANNC_LAST_UPDATED_DATE);
    },
    populatePositions: function(cellObjArray){
         var id = 1;    
        cellObjArray.forEach(function(el, index){     
                if(index < 5){
                    $('#interface_positionNumber_' + id).text(el.POSITION_NBR);
                    $('#interface_jobCode_' + id).text(el.JOBCODE);
                    id++;
            }
         });
    },
    getCertificates : function(){
        $.ajax({
            url:  '/bizflowwebmaker/ihsrec_track/loadTrackRequest.do',
            data: {cert: $('#h_procid').val()},
            dataType: 'xml',
            cache: false,
            success: function (xmlResponse) {
                var data = $('record', xmlResponse).map(function () {
                    return {
                        CERTIFICATE_NUMBER : $('CERTIFICATE_NUMBER', this).text(),
                        ANNOUNCEMENT_NUMBER : $('ANNOUNCEMENT_NUMBER', this).text(),
                        CERTIFICATE_ISSUE_DATE : $('ISSUE_DATE', this).text(),
                        CERTIFICATE_DUE_DATE : $('REVIEW_DUE_DATE', this).text(),
                        CERTIFICATE_RETURN_DATE : $('REVIEW_RETURN_DATE', this).text(),
                        REQUEST_NUMBER : $('REQUEST_NUMBER', this).text(),
                        CERT_LAST_UPDATED_DATE : $('LAST_UPDATE_DATE', this).text(),
                    };
                }).get();
                TRACK_TAB.populateCertificateTable(data);
            }
        });
    },


    getNewHire : function(){
        $.ajax({
            url:  '/bizflowwebmaker/ihsrec_track/loadTrackRequest.do',
            data: {newHire: $('#h_procid').val()},
            dataType: 'xml',
            cache: false,
            success: function (xmlResponse) {
                var data = $('record', xmlResponse).map(function () {
                    return {
                        NEW_HIRE_NAME : $('NEW_HIRE_NAME', this).text(),
                        NEW_HIRE_POSITION_TITLE : $('POSITION_TITLE', this).text(),
                        NEW_HIRE_DUTY_LOCATION : $('DUTY_LOCATION', this).text(),
                        NEW_HIRE_SEND_OFFER : $('SEND_TENT_OFFR_CMPL_DATE', this).text(),
                        NEW_HIRE_EFFECTIVE_DATE : $('EFFECTIVE_DATE', this).text(),
                        NEW_HIRE_NUMBER : $('NEW_HIRE_NUMBER', this).text(),
                        NEW_HIRE_PAYPLAN_SERIES_GRADE : $('PAYPLAN_SERIES_GRADE', this).text(),
                        NEW_HIRE_LAST_UPDATED_DATE : $('LAST_UPDATE_DATE', this).text()
                    };
                }).get();
                TRACK_TAB.populateNewHire(data);
            }
        });

    },
    getAnnouncement : function(){
        $.ajax({
            url:  '/bizflowwebmaker/ihsrec_track/loadTrackRequest.do',
            data: {annc: $('#h_procid').val()},
            dataType: 'xml',
            cache: false,
            success: function (xmlResponse) {
                var data = $('record', xmlResponse).map(function () {
                    return {
                        REQUEST_NUMBER : $('REQUEST_NUMBER', this).text(),
                        ANNOUNCEMENT_NUMBER :  $('ANNOUNCEMENT_NUMBER', this).text(),
                        VACANCY_TYPE : $('VACANCY_TYPE', this).text(),
                        JOA_DATE : $('REVIEW_JOA_DATE', this).text(),
                        ANNOUNCEMENT_DATE :  $('OPEN_DATE', this).text(),
                        ANNOUNCEMENT_CLOSE_DATE : $('CLOSE_DATE', this).text(),
                        ANNOUNCEMENT_TYPE: $('ANNOUNCEMENT_TYPE', this).text(),
                        ANNOUNCEMENT_LOCATION :$('LOCATION', this).text(),
                        ANNC_LAST_UPDATED_DATE : $('LAST_UPDATE_DATE', this).text()
                    };
                }).get();
                TRACK_TAB.populateAnnouncement(data);
            }
        });
    },
    getJobDetail : function(number){
        var url = '/bizflowwebmaker/ihsrec_track/loadTrackRequest.do?jobId=';
        if(number != undefined){
            url += number;
        }
        $.ajax({
            url:  url,
            dataType: 'xml',
            cache: false,
            success: function (xmlResponse) {
                var data = $('record', xmlResponse).map(function(){
                    return {
                        JOB_POSTING_TITLE : $('HRS_PRM_PST_TITLE', this).text(),
                        ADMIN_CODE : $('DEPTID', this).text(),
                        GEO_LOCATION_CODE : $('DESCR', this).text(),
                        OPEN_DATE : $('OPEN_DT', this).text(),
                        OPEN_CLOSE_DATE : $('CLOSE_DT', this).text(),
                        APPROVER_USER_NAME : $('HE_APPROVALO_OPRID', this).text(),
                        GEO_LOCATION_DESCR : $('HRS_PRM_LOCATION', this).text(),
                        AUTHORIZATION_DATE: $('AUTHORIZATION_DT', this).text(),
                        OPEN_STATUS_CODE : $('STATUS_CODE', this).text(),
                        OPENING_STATUS : $('POSN_STATUS', this).text(),
                        STATUS_DATE : $('STATUS_DT', this).text(),
                        STATUS_CLOSE_DATE : $('CLOSE_DT', this).text(),
                        NUMBER_OF_VACANCIES : $('OPENINGS_TARGET', this).text(),
                        CAN : $('ACCT_CD', this).text(),
                        APPROVAL_COMMENTS : $('HE_COMMENTS', this).text(),
                        REMARKS : $('HE_COMMENTS', this).text()
                    };
                }).get();
                if(data.length > 0){
                    TRACK_TAB.populatePageData(data);
                    TRACK_TAB.getPosDetail($('#interface_job_requisitionNumber').val());
                    TRACK_TAB.getAnnouncement();
                    TRACK_TAB.getCertificates();
                    TRACK_TAB.getNewHire();
                }else{
                    bootbox.alert('No record matched the Job Opening number entered. Please try again.');
                }

            }
        });
    },
      getPosDetail : function(number){
        var url = '/bizflowwebmaker/ihsrec_track/loadTrackRequest.do?pos=';
        if(number != undefined){
            url += number;
        }
        $.ajax({
            url:  url,
            dataType: 'xml',
            cache: false,
            success: function (xmlResponse) {
                var data = $('record', xmlResponse).map(function(){
                    return {
                        POSITION_NBR : $('POSITION_NBR', this).text(),
                        JOBCODE : $('JOBCODE', this).text()
                    };
                }).get();
                if(data.length > 0){
                    TRACK_TAB.populatePositions(data);
                    
                }

            }
        });
    }
};