/* ===================================================================================================
* WARNING – This file is part of the base implementation for WebMaker, so it should not be edited or changed for any project.
* These files are replaced if a project is re-imported to the WebMaker Studio or migrated to a new version of the product.
* For guidance on 'How do I override or clone Hyfinity webapp files such as CSS & javascript?', please read the following relevant FAQ entry:
* http://www.hyfinity.net/faq/index/solution_id/1113
==================================================================================================== */

if (typeof(hyf) == 'undefined')
{
    hyf = {
        version: 1.0
    }
}

hyf.pagingtable = {
    version: 2.0,
    desc: 'Provides for client side sorting and paging of an HTML table',
    optionsCollection: {}  //links the options collections provided for each table to the table ids
}

/**
 * The function that is used to get the value out of a table cell.
 * This should handle cells that contain editable fields.
 * @private
 * @author Hyfinity Limited
 */
hyf.pagingtable.textExtractor = function(node)
{
    var toReturn = null;

    if (node.id && node.id.indexOf('_container', node.id.length - 10) != -1)
    {
        toReturn = hyf.util.getFieldValue(node.id.substring(0, node.id.length - 10), true);
    }

    if (toReturn == null)
    {
        var inputs = $(node).find(':input');
        if (inputs.length > 0)
        {
            inputs.each(function() {
                    switch (this.type)
                    {
                        case 'hidden'   :   break;
                        case 'radio'    :   if (this.checked)
                                            {
                                                toReturn = this.value;
                                                return false;
                                            }
                                            break;
                        case 'checkbox' :   if (hyf.util.getWebMakerAttribute(this, 'use') == 'selectMany')
                                            {
                                                if (this.checked)
                                                {
                                                    if (toReturn != '')
                                                        toReturn += ', '
                                                    toReturn += this.value;
                                                }
                                            }
                                            else
                                            {
                                                if (this.checked)
                                                {
                                                    toReturn = this.value;
                                                    return false;
                                                }
                                                else
                                                {
                                                    toReturn = $('#' + this.id + '_value_if_not_submitted').val();
                                                    return false;
                                                }
                                            }
                                            break;

                        default:            toReturn = this.value;
                                            return false;

                    }



            })
        }
    }

    if (toReturn == null)
    {
        if (typeof(node.textContent) != 'undefined')
            toReturn = node.textContent;
        else
            toReturn = node.innerText;
    }

    return toReturn;
}


/** This contains the default options to apply to any new paging table.  Any speciifc options provided
 * when initialising a new table will override these.
 */
hyf.pagingtable.defaults = {
    initialised: false,
    enablePaging: true,
    //the class name to apply to a td that actually contians child data
    //the contents of matching cells will be hidden initially and shown (in a new row)
    //on click of the main row.
    cssChildDataContainer: 'child-data',
    //the class name of an element on the row that should toggle child data, ratehr than the whole row.
    cssChildDataToggle: null,

    tablesorterOptions: {
        widthFixed: true,
        cssHeader: 'header',
        cssAsc: 'headerSortUp',
        cssDesc: 'headerSortDown',
        textExtraction: hyf.pagingtable.textExtractor,
        widgets: ['zebra'],
        widgetOptions: {
            zebra: ['alternateRow', 'firstRow']
        }
    },
    pagerOptions: {
        cssContainer: 'tablesorterPager', // class name added to container for the paging controls
        size: null,
        output: '{page}/{filteredPages}',
        // if true, the table will remain the same height no matter how many records are displayed. The space is made up by an empty
        // table row set to a height to compensate; default is false
        fixedHeight: false,
        // apply disabled classname to the pager arrows when the rows at either extreme is visible - default is true
        updateArrows: true,

        //title messages for the page controls
        messages: {
            firstBtnTitle: 'First page',
            prevBtnTitle: 'Previous page',
            nextBtnTitle: 'Next page',
            lastBtnTitle: 'Last page',
            pageSizeTitle: 'Page size'
        }
    }
}


/**
 * Initialises the provided table to be sortable and provide paging capability.
 * This uses the tablesorter jQuery widget from http://mottie.github.io/tablesorter/docs/index.html
 *
 * See http://www.hyfinity.net/faq/index/solution_id/2005 for more details
 *
 * @param table The HTML table object to convert
 * @param options {object} configuration options for the table.  This object can contain the following properties:
 *              enablePaging - boolean value indicating whether the table should provide paging as well as
 *                             sorting capabilities. (default true)
 *              cssChildDataContainer - Class name to check for to find cells containing child data.  These will
 *                             be removed from the table and displayed on click.
 *              tableSorterOptions - Object containing any settings to apply to the tablesorter instance, for example:
 *                             widthFixed - boolean value indicating whether the width of the columns should be fixed.  This can be useful when using paging
 *                                           to stop the column sizes adjusting as you change pages. (default true)
 *                             widgets    - Array of tablesorter widgets to enable, eg ['zebra'] for striped rows.
 *                             ...
 *              pagerOptions - Object containing configuration settings to pass to the tablesorter pager plugin if
 *                             enablePagining is set to true. For example:
 *                             cssContainer - The CSS class name that will be applied to the HTML component containing the paging controls
 *                             size   - If provided this fixes the number of records displayed on a page.  If not provided
 *                                      a dropdown will be shown to allow the user to customize this.

 *                             output - Formats the text shown to indicate the current page.  This can contain the variables
 *                                      {page}, {totalPages}, {filteredPages}, {startRow}, {endRow}, {filteredRows} and {totalRows}.
 *                                      Examples: '{page}/{totalPages}', or '{startRow} to {endRow} ({totalRows})'
 *                             ...
 * @private
 * @author Hyfinity Limited
 */
hyf.pagingtable.init = function(table, options)
{


    if (typeof(options) != 'undefined')
    {
        //map old format of flat custom options to the new approach of using the
        //tablesorter settings directly
        if (options.enablePaging)
        {
            if (!options.pagerOptions)
                options.pagerOptions = {};

            if (typeof(options.pageSize) != 'undefined')
                options.pagerOptions.size = options.pageSize;
            if (typeof(options.pagerControlsCss) != 'undefined')
                options.pagerOptions.cssContainer = options.pagerControlsCss;
            if (typeof(options.output) != 'undefined')
                options.pagerOptions.output = options.output;

        }

        if (!options.tablesorterOptions)
            options.tablesorterOptions = {};
        if (typeof(options.headerCss) != 'undefined')
            options.tablesorterOptions.cssHeader = options.headerCss;
        if (typeof(options.headerAscCss) != 'undefined')
            options.tablesorterOptions.cssAsc = options.headerAscCss;
        if (typeof(options.headerDescCss) != 'undefined')
            options.tablesorterOptions.cssDesc = options.headerDescCss;
        if (typeof(options.widthFixed) != 'undefined')
            options.tablesorterOptions.widthFixed = options.widthFixed;

        if (options.stripeRows)
        {
            if (!options.tablesorterOptions.widgets)
                options.tablesorterOptions.widgets = ['zebra'];
            else if ($.inArray('zebra', options.tablesorterOptions.widgets) == -1)
                options.tablesorterOptions.widgets.push('zebra');

            if (options.firstRowCss || options.secondRowCss)
            {
                if (!options.tablesorterOptions.widgetOptions)
                    options.tablesorterOptions.widgetOptions = {};

                options.tablesorterOptions.widgetOptions.zebra = [options.secondRowCss, options.firstRowCss];
            }
        }

    }
    else
        options = {};

    opts = $.extend({}, hyf.pagingtable.defaults, options);

    //handle the sub level options collections separatley so that we dont override all settings
    opts.pagerOptions = $.extend({}, hyf.pagingtable.defaults.pagerOptions, options.pagerOptions);
    opts.pagerOptions.messages = $.extend({}, hyf.pagingtable.defaults.pagerOptions.messages, options.pagerOptions.messages);
    opts.tablesorterOptions = $.extend({}, hyf.pagingtable.defaults.tablesorterOptions, options.tablesorterOptions);
    opts.tablesorterOptions.widgetOptions = $.extend({}, hyf.pagingtable.defaults.tablesorterOptions.widgetOptions, options.tablesorterOptions.widgetOptions);

    //store the details for future initialisation
    hyf.pagingtable.optionsCollection[table.getAttribute('id')] = opts;
}

/**
 * Initialises any paging tables that have been specified in the given container.
 * @private
 * @author Hyfinity Limited
 */
hyf.pagingtable.initTables = function(container)
{
    //check if we have any editable tables that have not yet been initialised
    for (tableId in hyf.pagingtable.optionsCollection)
    {
        if (hyf.pagingtable.optionsCollection[tableId].initialised == false)
        {
            //check if it is contained within the provided container.
            if ($('#' + tableId, container).length > 0)
            {
                hyf.pagingtable.initImpl(document.getElementById(tableId), hyf.pagingtable.optionsCollection[tableId]);
            }
        }
    }
}
dojo.connect(hyf.hooks, 'widgetsParsed', hyf.pagingtable.initTables);



/**
 * This function actually performs the table initialisation, and should be called when
 * all the needed startup stuff has already happened
 * @param table The HTML table to convert
 * @param defaults The set of options for this table.  This should be a combination of the defaults,
 * and the user provided options.
 * @private - call hyf.pagingtable.init instead.
 * @author Hyfinity Limited
 */
hyf.pagingtable.initImpl = function(table, defaults)
{

    $(table).addClass('tablesorter');

    //check for any child data to move it to the correct location to toggle visibility etc
    if ($('td.' + defaults.cssChildDataContainer, table).length > 0)
    {
        defaults.hasChildData = true;

        var childCols = [];
        $('> tbody > tr.table', table).each(function (rowNum) {
                var row = this;
                var insertAfter = row;
                var childDataAdded = false
                $(row).children('.' + defaults.cssChildDataContainer).each(function (dataNum) {


                        var newRowId = row.id + '_childData_' + dataNum;

                        var newRow = $('<tr class="tablesorter-childRow" id="'+newRowId+'"><td class="tablesorter-child-spacer"></td><td id="'+newRowId+'_cell" colspan="'+ (row.cells.length - 2)+'"><div id="'+newRowId+'_cell_div"></div></td></tr>');

                        newRow.insertAfter(insertAfter);
                        insertAfter = newRow.get(0);

                        if (hyf.util.getWebMakerAttribute(row, 'repeatId'))
                            hyf.util.setWebMakerAttribute(newRow.get(0), 'repeatId', hyf.util.getWebMakerAttribute(row, 'repeatId'));

                        $(this).children().appendTo('#'+newRowId+'_cell_div');

                        //store a record of this column to remove the header cell later
                        var colNum = this.cellIndex + dataNum;
                        if ($.inArray(colNum, childCols) == -1)
                            childCols.push(colNum);

                        this.parentNode.removeChild(this);

                        childDataAdded = true;

                        newRow.find('> td > div').hide();
                });

                if (childDataAdded)
                {
                    $(row).addClass('tablesorter-hasChildRow');
                    if ((defaults.cssChildDataToggle != null) && (defaults.cssChildDataToggle != ''))
                    {

                        $('.' + defaults.cssChildDataToggle, row).click(function(e) {
                                      $(row).nextUntil('tr:not(.tablesorter-childRow)').toggleClass('tablesorter-childRow-visible').find('> td > div').slideToggle();
                        });
                    }
                    else
                    {
                        $(row).click(function(e) {

                                      var cb = $(e.target).closest('.controlBody');
                                      if (cb.length == 1)
                                      {
                                          var cont = cb.parent();
                                          if (!cont.hasClass('outputControl'))
                                              return;
                                      }

                                      $(row).nextUntil('tr:not(.tablesorter-childRow)').toggleClass('tablesorter-childRow-visible').find('> td > div').slideToggle();
                        });
                    }
                }

        });

        var headers = $('> thead tr th', table)
        for (var i = 0; i < childCols.length; ++i)
        {
            var thToRemove = headers.get(childCols[i]);
            thToRemove.parentNode.removeChild(thToRemove);
        }
    }

    hyf.pagingtable.connectEditableControls(table);

    //initialise the main table sorter
    $(table).tablesorter(defaults.tablesorterOptions);

    //now check if paging is also required
    if (defaults.enablePaging)
    {
        //create a div container to store the paging controls
        var pc = document.createElement('div');
        var pcid = table.getAttribute('id') + '_pager';
        pc.className = defaults.pagerOptions.cssContainer;
        pc.setAttribute('id', pcid);

        //create the paging controls
        var pcHTML = '<span class="first" title="' + defaults.pagerOptions.messages.firstBtnTitle + '"></span>';
        pcHTML += '<span class="prev" title="' + defaults.pagerOptions.messages.prevBtnTitle + '"></span>';
        pcHTML += '<span class="pagedisplay"></span>';
        pcHTML += '<span class="next" title="' + defaults.pagerOptions.messages.nextBtnTitle + '"></span>';
        pcHTML += '<span class="last" title="' + defaults.pagerOptions.messages.lastBtnTitle + '"></span>';
        if (defaults.pagerOptions.size != null)
            pcHTML += '<input type="hidden" class="pagesize" value="' + defaults.pagerOptions.size + '"/>';
        else
            pcHTML += '<select class="pagesize" title="' + defaults.pagerOptions.messages.pageSizeTitle + '"><option value="5">5</option><option selected="selected" value="10">10</option><option value="20">20</option><option value="30">30</option><option value="40">40</option><option value="50">50</option></select>';

        pc.innerHTML = pcHTML;

        table.parentNode.appendChild(pc);

        defaults.pagerOptions.container = $(pc)

        //initilise the paging
        $(table).tablesorterPager(defaults.pagerOptions);


        //call the change function on the page size to ensure the table is rendered correctly initially
        $('.pagesize', pc).change();
    }

    defaults.initialised = true;
}


/**
 * Checks if the given table contains any editable controls, eg text boxes, selects, etc.
 * If so, then this adds events to handle chanegs to the control values so that sorting
 * and filtering etc will be updated accordingly.
 *
 * @param table The HTML table object for the paging table.
 * @private
 */
hyf.pagingtable.connectEditableControls = function(table)
{
    if ($('input, select, textarea', table).length > 0)
    {
        $(table).on('tablesorter-initialized updateComplete', function() {
                var namespace = '.wm-paging-table';
                var tbody = $(this).children('tbody');

                var updateHandler = function(target) {
                        var $target = $(target);

                        var $cell = $target.closest('td');
                        var $table = $cell.closest('table');

                        //there seems to be a bug in the updateCell call which causes issues
                        //if the table contains child data rows.
                        //Therefore we check for this, and update the whole table in this scenario.
                        //This isnt really ideal, as it might have a performance hit for bigger tables, but not really much choice
                        //until the issue is resolved
                        if (hyf.pagingtable.optionsCollection[$table[0].getAttribute('id')].hasChildData)
                        {
                            $table.trigger('update');
                        }
                        else
                        {
                            $table.trigger('updateCell', [$cell]);
                        }

                }

                tbody.off(namespace);
                tbody.on('change' + namespace, 'select, input[type=text], textarea', function(e){updateHandler(e.target);});
                tbody.on('click' + namespace, 'input[type=radio], input[type=checkbox]', function(e){updateHandler(e.target);});


                //specail handling for dojo widgets (eg filtering select)
                if ((typeof(dijit) != 'undefined') && (typeof(dijit.findWidgets) == 'function'))
                {
                    require(["dojo/_base/array", "dojo/on"], function(array, on) {
                        var widgets = dijit.findWidgets(tbody[0]);

                        array.forEach(widgets, function(item, i) {
                                if (!item.ptChangeEventAttached)
                                {
                                    on(item, 'change', function(e){updateHandler(item.domNode)});
                                    item.ptChangeEventAttached = true;
                                }
                        });
                    });

                }

        });

    }

}


/**
 * Finds the last table object that has been output to the document.
 * This is used as the page is being rendered to initialise any ediatbale tables
 * This is an exact copy of the same function in the editabletable script
 * so should be combined at some point.
 * @private
 * @author Hyfinity Limited
 */
hyf.pagingtable.getLastTableOutput = function()
{
    var elem = document.lastChild;
    while (elem.lastChild != null)
    {
        elem = elem.lastChild;
    }
    if (elem.nodeType != 1)
    {
        var prevElem = hyf.util.getPreviousElementSibling(elem);
        if (prevElem == null)
        {
            elem = elem.parentNode;
        }
        else
        {
            elem = prevElem;
        }
    }

    //at this point elem should be the script tag containing the init script.
    //For old style containers, the table should be the previous element, so just
    //find the table within the parentNode.
    //for new style groups need to find the preceding layoutContainerContent element
    //which should have the table within it.
    var table = null;
    if (dojo.hasClass(elem.parentNode, 'layoutContainerContent'))
    {
        var prevElem = hyf.util.getPreviousElementSibling(elem.parentNode);
        while (prevElem != null && !dojo.hasClass(prevElem, 'layoutContainerContent'))
        {
            prevElem = hyf.util.getPreviousElementSibling(prevElem);
        }
        if (prevElem != null)
            table = prevElem.parentNode.getElementsByTagName('table')[0];
    }
    else
        table = elem.parentNode.getElementsByTagName('table')[0];

    return table;
}