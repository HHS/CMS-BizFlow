/* global $ TabManager FormUtility BFActivityOption FormLog FormState StateAction bootbox hyf LookupManager */
var globalVars = {
	actAll: 'ALLACTIVITIES',
	actCaseCreation : 'Create Case',
    actCaseComplete : 'Complete Case',    
    form_title : 'Case Information',
	tabId_general : 'tab1',
    tabId_conduct_issue : 'tab2',
    tabId_performance_issue : 'tab3',
    tabId_appeal : 'tab80',    
	tabId_documents : 'tab99',
	caseType : '',
    conduct_issue : 'Conduct Issue',
    performance_issue : 'Performance Issue'
};

var MessageResource = {
    SELECT_ONE: 'Select one',
    SELECT_ALL_THAT_APPLY: 'Select all that apply'
};

var SYSTEM_ERROR_MESSAGE = "<h3 style='color:red'>Something went wrong</h3><p><h4>The system has encountered an error. Please try again, and if it still doesn't work, contact EWITS 2.0 help desk.</h4>";

var PayPlanGrade = {
    'GP': ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15'],
    'GR': ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15'],
    'GS': ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15'],
    'ES': ['01', '02', '03', '04', '05', '06'],
    'WG': ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10']};

(function (window) {
	var tab1 = new Tab('tab1', 'General', '/cms_erlr_tab/initial_response.do', 'partial_tab1', true, ['/cms_erlr_tab/custom/js/cms_erlr_general.js']);
	tab1.onInit = function () {
		try {
            cms_main_tab1.init();
        }catch(e){
			FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
		}
	};
	tab1.renderer = function () {
        try {
            cms_main_tab1.render();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
	};
    tab1.validator = function () {
        try {
            return FormMain.multipleDataSelectFieldValidator(this);
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
    };

	var tab2 = new Tab('tab2', 'Conduct Issue', '/cms_erlr_tab/conduct_issue.do', 'partial_tab2', true, ['/cms_erlr_tab/custom/js/cms_erlr_conduct_issue.js']);
	tab2.onInit = function () {
        try {
            ConductIssue.init();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
	};
	tab2.renderer = function () {
        try {
            ConductIssue.render();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
	};
    tab2.validator = function () {
        try {
            return FormMain.multipleDataSelectFieldValidator(this);
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
    };

	var tab3 = new Tab('tab3', 'Performance Issue', '/cms_erlr_tab/performance_issue.do', 'partial_tab3', true, ['/cms_erlr_tab/custom/js/cms_erlr_performance_issue.js']);
	tab3.onInit = function () {
        try {
            cms_perf_issue.init();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
	};
	tab3.renderer = function () {
        try {
            cms_perf_issue.render();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
	};
    tab3.validator = function () {
        try {
            return FormMain.multipleDataSelectFieldValidator(this);
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
    };
	tab3.postClearTabContents = function() {
        try {
            cms_perf_issue.clearAllContentCustom();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
	}

	var tab4 = new Tab('tab4', 'Medical Documentation', '/cms_erlr_tab/meddoc.do', 'partial_tab4', true, ['/cms_erlr_tab/custom/js/cms_erlr_meddoc.js']);
	tab4.onInit = function () {
        try {
            cms_meddoc.init();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
	};
	tab4.renderer = function () {
        try {
            cms_meddoc.render();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
	};
    tab4.validator = function () {
        try {
            return FormMain.multipleDataSelectFieldValidator(this);
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
    };

	var tab5 = new Tab('tab5', 'Grievance', '/cms_erlr_tab/grievance.do', 'partial_tab5', true, ['/cms_erlr_tab/custom/js/cms_erlr_grievance.js']);
	tab5.onInit = function () {
        try {
            cms_grievance.init();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
	};
	tab5.renderer = function () {
        try {
            cms_grievance.render();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
	};
    tab5.validator = function () {
        try {
            return FormMain.multipleDataSelectFieldValidator(this);
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
    };

	var tab6 = new Tab('tab6', 'Investigation', '/cms_erlr_tab/investigation.do', 'partial_tab6', true, ['/cms_erlr_tab/custom/js/cms_erlr_investigation.js']);
	tab6.onInit = function () {
        try {
            cms_investigation.init();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
	};
	tab6.renderer = function () {
        try {
            cms_investigation.render();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
	};
    tab6.validator = function () {
        try {
            return FormMain.multipleDataSelectFieldValidator(this);
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
    };

	var tab7 = new Tab('tab7', 'Third Party Hearing', '/cms_erlr_tab/thirdPartyHearing.do', 'partial_tab7', true, ['/cms_erlr_tab/custom/js/cms_erlr_3rdparty_hear.js']);
	tab7.onInit = function () {
        try {
            cms_erlr_3rdparty_hear.init();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
	};
	tab7.renderer = function () {
        try {
            cms_erlr_3rdparty_hear.render();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
	};
    tab7.validator = function () {
        try {
            return FormMain.multipleDataSelectFieldValidator(this);
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
    };

	var tab8 = new Tab('tab8', 'WGI Denial', '/cms_erlr_tab/wgiDenial.do', 'partial_tab8', true, ['/cms_erlr_tab/custom/js/cms_erlr_wgi_denial.js']);
	tab8.onInit = function () {
        try {
            cms_erlr_wgi_denial.init();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
	};
	tab8.renderer = function () {
        try {
            cms_erlr_wgi_denial.render();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
	};
    tab8.validator = function () {
        try {
            return FormMain.multipleDataSelectFieldValidator(this);
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
    };

    var tab9 = new Tab('tab9', 'Probationary Action', '/cms_erlr_tab/probation_period.do', 'partial_tab9', true, ['/cms_erlr_tab/custom/js/cms_erlr_prob_period.js']);
	tab9.onInit = function () {
        try {
            cms_erlr_prob_period.init();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
	};
	tab9.renderer = function () {
        try {
            cms_erlr_prob_period.render();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
	};
    tab9.validator = function () {
        try {
            return FormMain.multipleDataSelectFieldValidator(this);
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
    };

	var tab10 = new Tab('tab10', 'Information Request', '/cms_erlr_tab/information_request.do', 'partial_tab10', true, ['/cms_erlr_tab/custom/js/cms_erlr_info_request.js']);
	tab10.onInit = function () {
        try {
            cms_erlr_info_request.init();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
	};
	tab10.renderer = function () {
        try {
            cms_erlr_info_request.render();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
	};
    tab10.validator = function () {
        try {
            return FormMain.multipleDataSelectFieldValidator(this);
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
    };

    var tab11 = new Tab('tab11', 'Labor Negotiation', '/cms_erlr_tab/labor_negotiation.do', 'partial_tab11', true, ['/cms_erlr_tab/custom/js/cms_erlr_labor_negotiation.js']);
    tab11.onInit = function () {
        try {
            cms_erlr_labor_negotiation.init();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
    };
    tab11.renderer = function () {
        try {
            cms_erlr_labor_negotiation.render();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
    };
    tab11.validator = function () {
        try {
            return FormMain.multipleDataSelectFieldValidator(this);
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
    };

    var tab12 = new Tab('tab12', 'Unfair Labor Practice', '/cms_erlr_tab/unfair_labor_practice.do', 'partial_tab12', true, ['/cms_erlr_tab/custom/js/cms_erlr_unfair_labor_practice.js']);
    tab12.onInit = function () {
        try {
            cms_erlr_unfair_labor_practice.init();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
    };
    tab12.renderer = function () {
        try {
            cms_erlr_unfair_labor_practice.render();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
    };
    tab12.validator = function () {
        try {
            return FormMain.multipleDataSelectFieldValidator(this);
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
    };

	var tab80 = new Tab('tab80', 'Appeal', '/cms_erlr_tab/appeal.do', 'partial_tab80', true, ['/cms_erlr_tab/custom/js/cms_erlr_appeal.js']);
	tab80.onInit = function () {
        try {
            Appeal.init();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
	};
	tab80.renderer = function () {
        try {
            Appeal.render();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
	};
    tab80.validator = function () {
        try {
            return FormMain.multipleDataSelectFieldValidator(this);
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
    };

	var tab90 = new Tab('tab90', 'Case Completed', '/cms_erlr_tab/case_complete.do', 'partial_tab90', true, ['/cms_erlr_tab/custom/js/cms_erlr_case_complete.js']);
	tab90.onInit = function () {
        try {
            cms_case_complete.init();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
	};
	tab90.renderer = function () {
        try {
            cms_case_complete.render();
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
	};
    tab90.validator = function () {
        try {
            return FormMain.multipleDataSelectFieldValidator(this);
        }catch(e){
            FormLog.log(FormLog.LOG_LEVEL.ERROR, e);
        }
    };

	// last tab
	var tab99 = new Tab('tab99', 'Documents', '/cms_common/showAttachment.do', 'partial_tab99');
	tab99.validator = function () {
		//TODO: implement document validation logic
		//return 'true' === $('#h_mandatoryDocumentsValid').val();
		return true;
	};
	// suppress missing required fields for doc tab in case there is no required document left.
	tab99.displayMissingRequiredFields = false;

	var tabs = [tab1, tab2, tab3, tab4, tab5, tab6, tab7, tab8, tab9, tab10, tab11, tab12, tab80, tab90, tab99];
	
	// define activities
	var activity1 = new Activity(globalVars.actCaseCreation, ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab6', 'tab7', 'tab8', 'tab9', 'tab10', 'tab11','tab12','tab80', 'tab90', 'tab99']);
	var activity2 = new Activity(globalVars.actCaseComplete, ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab6', 'tab7', 'tab8', 'tab9', 'tab10', 'tab11','tab12','tab80', 'tab90', 'tab99']);
	var activities = [activity1, activity2];

	// creating activityTabDefinition and initialize
	var activityTabDefinition = window.activityTabDefinition || (window.activityTabDefinition = new ActivityTabDefinition(tabs, activities));
	//FormLog.setLogLevel(FormLog.LOG_LEVEL.INFO);
	FormLog.setLogLevel(FormLog.LOG_LEVEL.DEBUG);
	FormRequire.loadScripts(activityTabDefinition.tabs);
	
})(window);



(function (window) {
	
	'use strict';

	/** * Form Main Object. This is main object that starts a form. */
	var FormMain = function () {
		
		var _contextPath = '/bizflowwebmaker';
		var _actionWorkitemDo = 'actionWorkitem.do';
		
		
		function formRenderer() {
			//STUB
		}
		
		function updatePrimarySpecialistStatusBar(primarySpecialist){
			if (typeof primarySpecialist != 'undefined' && primarySpecialist != null && primarySpecialist.trim().length > 0) {
				$('#initiatorName').text(primarySpecialist);
			}
		}
		
		function updateCaseStatusStatusBar(caseStatus){
			if (typeof caseStatus != 'undefined' && caseStatus != null && caseStatus.trim().length > 0) {
				$('#output_caseStatus').text(caseStatus);
			}
		}
		
		function updateStatusBar(initiatedDate, initiatorName, caseStatus) {
			var caseNumber = FormState.getElementValue('CASE_NUMBER', 0);
		    $('#caseNumber').text(caseNumber);
			$('#initiatedDate').text(initiatedDate);
			var initiatorNameVal = $('#initiatorName').text();
			if (typeof initiatorNameVal == 'undefined' || initiatorNameVal == null || initiatorNameVal.trim().length <= 0) {
				// Initialize the name only if it currently is empty.
				// This value may be overwritten by selection of the Primary Specialist from General tab
				updatePrimarySpecialistStatusBar(initiatorName);
			}
			updateCaseStatusStatusBar(caseStatus);
		}

		function initStatusBar() {
			//var initiatedDate = FormUtility.getLocalDateString(FormState.getElementValue('initiatedDate'), 'mm/dd/yyyy');
			var initiatedDateString = $('#h_creationdate').val();
			var initiatedDate = FormUtility.getLocalDateString(initiatedDateString, 'mm/dd/yyyy');
			var initiatorName = $('#h_initiatorName').val();
			var caseStatus = FormState.getElementValue('GEN_CASE_STATUS');
			updateStatusBar(initiatedDate, initiatorName, caseStatus);
		}

		function showHideClearTab(tabId, isShown) {
			if (isShown) {
				TabManager.showTabHeader(tabId);
			} else {
				TabManager.hideTabHeader(tabId);
				TabManager.clearTabContent(tabId);
			}
		}

		function showHideConductIssueTab(isShown) {
			showHideClearTab('tab2', isShown);
		}

		function showHidePerformanceIssueTab(isShown) {
			showHideClearTab('tab3', isShown);
		}

		function showHideGrievanceTab(isShown) {
			showHideClearTab('tab5', isShown);
		}
		
		function showHideInvestigationTab(isShown) {
			showHideClearTab('tab6', isShown);
		}
		
		function showHide3rdPartyHearingTab(isShown) {
			showHideClearTab('tab7', isShown);
		}
		
		function showHideWgiDenialTab(isShown) {
			showHideClearTab('tab8', isShown);
		}
		
		function showHideProbationaryActionTab(isShown) {
			showHideClearTab('tab9', isShown);
		}

		function showHideInformationRequestTab(isShown) {
			showHideClearTab('tab10', isShown);
		}
        function showHideLaborNegotiationTab(isShown) {
            showHideClearTab('tab11', isShown);
        }
        function showHideUnfairLaborPracticeTab(isShown) {
            showHideClearTab('tab12', isShown);
        }
		function controlDynamicTab(){
		    var showAppealTab = false;
            var caseTypeState = FormState.getState('GEN_CASE_TYPE');
            if (typeof caseTypeState !== 'undefined') {
                if ('Performance Issue' === caseTypeState.text) {
                    showAppealTab = (FormState.getElementBooleanValue('PI_PIP_APPEAL_DECISION')
                        || FormState.getElementBooleanValue('PI_DMTN_APPEAL_DECISION')
                        || FormState.getElementBooleanValue('PI_RMV_APPEAL_DECISION'));
                } else if('Grievance' === caseTypeState.text){
                    showAppealTab = FormState.getElementBooleanValue('GI_ARBITRATION_REQUEST')
                        || FormState.getElementBooleanValue('GI_IND_THIRD_APPEAL_REQUEST');
                } else if('Within Grade Increase Denial/Reconsideration' === caseTypeState.text){
                    showAppealTab = FormState.getElementBooleanValue('WGI_EMP_APPEAL_DECISION');
                } else if('Conduct Issue' === caseTypeState.text){
                    showAppealTab = FormState.getElementBooleanValue('CI_EMP_APPEAL_DECISION');
                } else if('Probationary Period' === caseTypeState.text){
                    showAppealTab = FormState.getElementBooleanValue('PPA_EMP_APPEAL_DECISION');
                }
            }
            showHideClearTab('tab80', showAppealTab);
        }
		function controlTabVisibility() {
			//-------------------------------
			// tab visibility by Case Type
			//-------------------------------
			
			var caseTypeSelVal = FormState.getElementValue('GEN_CASE_TYPE');
			var caseTypeSelTxt = $('#GEN_CASE_TYPE option[value="' + caseTypeSelVal + '"]').text();
			var caseTypeTabId = null;
			if (typeof caseTypeSelTxt != 'undefined' && caseTypeSelTxt != null && caseTypeSelTxt.trim().length > 0) {
				if ('Conduct Issue' === caseTypeSelTxt) {
					caseTypeTabId = 'tab2';
				} else if ('Performance Issue' === caseTypeSelTxt) {
					caseTypeTabId = 'tab3';
				} else if ('Medical Documentation' === caseTypeSelTxt) {
					caseTypeTabId = 'tab4';
				} else if ('Grievance' === caseTypeSelTxt) {
					caseTypeTabId = 'tab5';
				} else if ('Investigation' === caseTypeSelTxt) {
					caseTypeTabId = 'tab6';
				} else if ('Third Party Hearing' === caseTypeSelTxt) {
					caseTypeTabId = 'tab7';
				} else if ('Within Grade Increase Denial/Reconsideration' === caseTypeSelTxt) {
					caseTypeTabId = 'tab8';
				} else if ('Probationary Period' === caseTypeSelTxt) {
					caseTypeTabId = 'tab9';
				} else if ('Information Request' === caseTypeSelTxt) {
					caseTypeTabId = 'tab10';
				} else if ('Labor Negotiation' === caseTypeSelTxt) {
                	caseTypeTabId = 'tab11';
            	} else if ('Unfair Labor Practices' === caseTypeSelTxt) {
                    caseTypeTabId = 'tab12';
                }
			}
			
			// Note: careful with index range
			for (var i = 2; i <= 12; i++) {
				var tabId = 'tab' + i;
				showHideClearTab(tabId, (tabId === caseTypeTabId));
			}

			//-------------------------------
			// tab visibility by Activity
			//-------------------------------
			var activityName = ActivityManager.getActivityName();
			if (activityName === 'Complete Case') {
				TabManager.showTabHeader('tab90');
			} else {
				TabManager.hideTabHeader('tab90');
			}
        }
		
		function controlButtonVisibility() {
			var tabId = TabManager.getSelectedTabID();
			var activityName = ActivityManager.getActivityName();
			if (activityName === 'Create Case') {
				hyf.util.showComponent('button_Initiation');
			} else if (activityName === 'Complete Case') {
				hyf.util.showComponent('button_SubmitWorkitem');
				hyf.util.showComponent('button_UpdateSpecialist');
			}
			hyf.util.showComponent('button_SaveWorkitem');
			hyf.util.showComponent('button_Cancel');
			hyf.util.showComponent('button_ExitWIH');
		}
		
		function initWIHPane(time_) {
			if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'FormMainHandler::initWIHPane');
			setTimeout(function () {
				var ui = basicWIHActionClient.getUI();
				ui.getPane(ui.PANE_TOOL).open();
				ui.getPane(ui.PANE_TOOL).close();
				ui.getPane(ui.PANE_ATTACHMENT).hide();
				ui.getPane(ui.PANE_INTERNAL_DISCUSSION).open();
			}, time_ || 100);
		}
		
		function onTabChange(e) {
			if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "FormMain::onTabChange, e ==> ", e);
			
			controlButtonVisibility();
			
			if (FormUtility.isReadOnly() == false) {
				// var caseNumber = FormState.getElementValue('CASE_NUMBER');
				// if (caseNumber == null || caseNumber.length == 0) {
				// 	$('#h_now').val(FormUtility.getNowUTCString());
				// }
                var xml = FormState.getFinalStateXML();
                $('#h_formData').val(xml);
                basicWIHActionClient.setWIHOption('requestAction', 'tabChange');
                ajaxSubmission(_actionWorkitemDo);
			}
		}
		
		function onAllTabLoaded() {
			if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'FormMainHandler::onAllTabLoaded');
			if (!FormUtility.isReadOnly()) {
				hyf.util.showComponent('main_buttons_layout_group');
				hyf.util.showComponent('tab_container_group');
				var tabIdList = ActivityManager.getTabIdList();
				FormUtility.initMaxSize(tabIdList, 'bottom');
				FormUtility.setDateIconTabOrder(tabIdList);
				
				$(document).on('ON_TAB_CHANGE', onTabChange);
				
				if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'FormMainHandler::onAllTabLoaded - attach ON_TAB_CHANGE event to onTabChange');
				$('.datePickerIcon').each(function () {
					var refId = $(this).attr('id').slice(0, -16);
					var title = "Calendar icon used to select " + $('#' + refId + '_label').text() + " value";
					$(this).attr('title', title);
				});

				initWIHPane();
				controlTabVisibility();
				controlButtonVisibility();
			}
		}
		
		
		

		//---------------------------------------------------------------------
		// Submit form data via ajax
		// @param action WebMaker action name
		// @param sourceGroup (Optional) indicates whether to send all the data on the page or just the data within a particular group.
		// @param targetGroup (Optional) indicates which group to place the results into.
		// @param validate (Optional) indicates whether to validate first. default: false
		// @example
		//     Submit all data without form validation on the page, and result page is not showing.
		//         ajaxSubmission('actionWorkitem.do');
		//     Form validation before submit all data on the page, and result page is not showing.
		//         ajaxSubmission('actionWorkitem.do', 'all', undefined, true);
		//     Form validation before submit data within 'input_layout_group', and results showing to 'output_layout_group'.
		//         ajaxSubmission('actionWorkitem.do', 'input_layout_group', 'output_layout_group', true);
		function ajaxSubmission(action, sourceGroup, targetGroup, validate) {
			if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "FormMainHandler::ajaxSubmission - action, sourceGroup, targetGroup, validate ==>", action, sourceGroup, targetGroup, validate);
			if (window.location.pathname.indexOf(_contextPath) > -1 && action.indexOf('/') === 0) {
				action = _contextPath + action;
			}
			var objAction = {
				name: 'Action',
				option: 'Action',
				value: action
			};
			var objSourceGroup = null;
			if (typeof sourceGroup === 'undefined' || null === sourceGroup || '' === sourceGroup
				|| 'all' === sourceGroup || 'ALL' === sourceGroup) {
				objSourceGroup = {name: 'SourceGroup', option: 'AllFormData', value: ''};
			} else {
				objSourceGroup = {name: 'SourceGroup', option: 'PageGroup', value: sourceGroup};
			}

			var partialPageContainerId = '_hidden_partial_page_container_';
			if (typeof targetGroup === 'undefined') {
				var partialPageContainer = document.createElement('div');
				if (document.getElementById(partialPageContainerId) === null) {
					partialPageContainer.id = partialPageContainerId;
					partialPageContainer.style.display = "none";
					document.getElementsByTagName('body')[0].appendChild(partialPageContainer);
				}
			} else {
				partialPageContainerId = targetGroup;
			}

			var objTargetGroup = {
				name: 'TargetGroup',
				option: 'PageGroup',
				value: partialPageContainerId
			};
			var objValidate = {
				name: 'Validate',
				option: 'Static',
				value: validate ? validate : false
			};
			hyf.FMAction.handleAjaxSubmission(objAction, objSourceGroup, objTargetGroup, objValidate, {value: targetGroup});
		}
		
		//---------------------------------------------------------------------
		// Submit form data and save workitem.
		// @param requestAction: the WIH request action name.
		function saveForm(requestAction, currentTabIdSelector_) {
			currentTabIdSelector_ = currentTabIdSelector_ || '#h_currentTabID';
			if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'FormMainHandler::saveForm - requestAction, currentTabIdSelector ==>', requestAction, currentTabIdSelector_);

			$(currentTabIdSelector_).val(TabManager.getSelectedTabID()); // store current tabId to reset after page reload
			var xml = FormState.getFinalStateXML();

			$('#h_formData').val(xml);
			if (typeof requestAction === 'string') {
				basicWIHActionClient.setWIHOption('requestAction', requestAction);
			}
			ajaxSubmission(_actionWorkitemDo);
		}
		
		//---------------------------------------------------------------------
		// Submit form data and complete workitem. Workitem Handler closed when it completed successfully.
		// @param responseName: (Optional) the response name should be one of the available response names on current activity.
		function completeWorkitem(responseName, formValidation, formDataSelector_) {
			formDataSelector_ = formDataSelector_ || '#h_formData';
			var xml = FormState.getFinalStateXML();
			$(formDataSelector_).val(xml);
			//$('#WIH_complete_requested').val(true);
			if (typeof responseName !== 'undefined') {
				basicWIHActionClient.setResponseByName(responseName);
			}
			basicWIHActionClient.setWIHOption('requestAction', 'complete');
			if (!basicWIHActionClient.getWIHOption('formSaved')) {
				basicWIHActionClient.setWait();
				ajaxSubmission(_actionWorkitemDo + '?requestAction=' + responseName, 'all', undefined, formValidation);
			}
		}
		
		//---------------------------------------------------------------------
		// Pop up confirmation dialog for exit.
		// @param alertMsg_: prompt message on dialog (def: 'Would you like to save your entries before exit?')
		function confirmExit(alertMsg_) {
			alertMsg_ = alertMsg_ || 'Would you like to save your entries before exit?';
			if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'FormMainHandler::confirmExit - msg ==>', alertMsg_);

			bootbox.dialog({
				message: '<p class="bootbox-body">' + alertMsg_ + '</p>',
				onEscape: true,
				buttons: 
				[
					{
						label: 'No',
						callback: function () {
							basicWIHActionClient.exit({confirmMsg: null});
						}
					},
					{
						label: 'Yes, save and exit',
						className: 'btn-primary',
						callback: function () {
							$('#WIH_exit_requested').val(true);
							saveForm('exit');
						}
					}
				]
			});
		}
		
		
		//---------------------------------------------------------------------
		// Pop up confirmation dialog for Update Specialist.
		function confirmUpdateSpecialist() {
			if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'FormMainHandler::confirmUpdateSpecialist');
			
			var primSpcOption = $('#GEN_PRIMARY_SPECIALIST option');
			var secSpcOption = $('#GEN_SECONDARY_SPECIALIST option');
			var specialistSelectHtml = '';
			specialistSelectHtml += '<p class="bootbox-body">Please, select new specialist and confirm the change.</p><br/><br/>';
			specialistSelectHtml += '<div class="layoutContainer alignVertical alignLeft alignTop expandWidth fitHeight" id="dialog_specialist_group">';
			specialistSelectHtml += '	<div class="layoutContainerContent">';
			specialistSelectHtml += '		<div class="controlContainer labelAbove">';
			specialistSelectHtml += '			<div class="controlRow">';
			specialistSelectHtml += '				<span class="labelBackground labelControl" id="DIA_PRIMARY_SPECIALIST_label_container">';
			specialistSelectHtml += '					<label class="label" for="DIA_PRIMARY_SPECIALIST" id="DIA_PRIMARY_SPECIALIST_label">Primary Specialist: </label>';
			specialistSelectHtml += '				</span>';
			specialistSelectHtml += '			</div>';
			specialistSelectHtml += '			<div class="controlRow">';
			specialistSelectHtml += '				<span class="defaultBackground selectControl" id="DIA_PRIMARY_SPECIALIST_container">';
			specialistSelectHtml += '					<select class="select" id="DIA_PRIMARY_SPECIALIST" name="DIA_PRIMARY_SPECIALIST">';
			for (var i = 0; i < primSpcOption.length; i++) {
				specialistSelectHtml += '<option value="' + primSpcOption[i].value + '">' + primSpcOption[i].text + '</option>';
			}
			specialistSelectHtml += '					</select>';
			specialistSelectHtml += '				</span>';
			specialistSelectHtml += '			</span>';
			specialistSelectHtml += '		</div>';
			specialistSelectHtml += '		</div>';
			specialistSelectHtml += '	</div>';
			specialistSelectHtml += '	<br/>';
			specialistSelectHtml += '	<div class="layoutContainerContent">';
			specialistSelectHtml += '		<div class="controlContainer labelAbove">';
			specialistSelectHtml += '			<div class="controlRow">';
			specialistSelectHtml += '				<span class="labelBackground labelControl" id="DIA_SECONDARY_SPECIALIST_label_container">';
			specialistSelectHtml += '					<label class="label" for="DIA_SECONDARY_SPECIALIST" id="DIA_SECONDARY_SPECIALIST_label">Secondary Specialist: </label>';
			specialistSelectHtml += '				</span>';
			specialistSelectHtml += '			</div>';
			specialistSelectHtml += '			<div class="controlRow">';
			specialistSelectHtml += '				<span class="defaultBackground selectControl" id="DIA_SECONDARY_SPECIALIST_container">';
			specialistSelectHtml += '					<span class="controlBody">';
			specialistSelectHtml += '						<select class="select" id="DIA_SECONDARY_SPECIALIST" name="DIA_SECONDARY_SPECIALIST">';
			for (var i = 0; i < secSpcOption.length; i++) {
				specialistSelectHtml += '<option value="' + secSpcOption[i].value + '">' + secSpcOption[i].text + '</option>';
			}
			specialistSelectHtml += '						</select>';
			specialistSelectHtml += '					</span>';
			specialistSelectHtml += '				</span>';
			specialistSelectHtml += '			</div>';
			specialistSelectHtml += '		</div>';
			specialistSelectHtml += '	</div>';
			specialistSelectHtml += '</div>';
			
			bootbox.dialog({
				title: 'Update Specialist',
				message: specialistSelectHtml,
				onEscape: true,
				buttons: 
				[
					{
						label: 'Cancel',
						callback: function () {
							FormState.updateVariableValue('reassign', 'No', false);
						}
					},
					{
						label: 'OK',
						className: 'btn-primary',
						callback: function () {
							FormState.updateVariableValue('reassign', 'Yes', false);
							var elemVal = null;
							var elemTxt = null;
							elemVal = $('#DIA_PRIMARY_SPECIALIST option:selected').val();
							if (typeof elemVal != 'undefined' && elemVal != null && elemVal.length > 0) {
								elemTxt = $('#DIA_PRIMARY_SPECIALIST option:selected').text();
								$('#GEN_PRIMARY_SPECIALIST').val(elemVal);
								FormState.updateSelectValue('GEN_PRIMARY_SPECIALIST', elemVal, elemTxt);
							}
							elemVal = $('#DIA_SECONDARY_SPECIALIST option:selected').val();
							if (typeof elemVal != 'undefined' && elemVal != null && elemVal.length > 0) {
								elemTxt = $('#DIA_SECONDARY_SPECIALIST option:selected').text();
								$('#GEN_SECONDARY_SPECIALIST').val(elemVal);
								FormState.updateSelectValue('GEN_SECONDARY_SPECIALIST', elemVal, elemTxt);
							}
							
							completeWorkitem('Submit', false);
							//FormUtility.blockScreen();
						}
					}
				]
			});
		}
		
		
		//---------------------------------------------------------------------
		// Pop up confirmation dialog for cancellation.
		// @param reasonLookupType_: cancellation reason lookup LTYPE (def: 'CancellationReason')
		// @param title_: title of dialog (def: 'What is the reason for canceling this request?')
		// @param msgWhenNotSelectReason_: explanation/instruction of error in dialog')
		function confirmCancel(reasonLookupType_, title_, msgWhenNotSelectReason_) {
			reasonLookupType_ = reasonLookupType_ || 'CancellationReason';
			title_ = title_ || 'What is the reason for canceling this request?';
			msgWhenNotSelectReason_ = msgWhenNotSelectReason_ || 'Please select a cancellation reason';

			if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'FormMainHandler::confirmCancel - reasonLookupType, title,msgWhenNotSelectReason ==>', reasonLookupType_, title_, msgWhenNotSelectReason_);

			var cancelReasons = LookupManager.findByLTYPE(reasonLookupType_);
			if (cancelReasons.length > 0) {
				var selectHTML = '<select class="form-control" id="cancelReason" name="cancelReason"><option value="">Select One</option>';
				for (var i = 0; i < cancelReasons.length; i++) {
					selectHTML += '<option value="' + cancelReasons[i].NAME + '">' + cancelReasons[i].NAME + '</option>';
				}
				selectHTML += '</select>';

				bootbox.confirm({
					title: title_,
					message: selectHTML,
					buttons: {
						confirm: {
							label: 'OK',
							className: 'btn-success'
						}
					},
					callback: function (result) {
						if (result) {
							if ('' === $('#cancelReason').val()) {
								bootbox.alert(msgWhenNotSelectReason_);
							} else {
								FormState.updateVariableValue('cancelReason', $('#pv_cancelReason').val(), false);
								FormState.updateSelectValue('GEN_CASE_STATUS', 'closeNow', 'closeNow', false);
								completeWorkitem('Cancel', false);
							}
						}
					}
				});
			} else {
				title_ = 'Are you sure you want to cancel this request?';
				$('#cancelReason').val('N/A');
				if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'FormMainHandler::confirmCancel - No CancellationReason lookup data, title ==> ', title_);

				bootbox.confirm(title_, function (result) {
					if (result) {
						FormState.updateVariableValue('cancelReason', $('#pv_cancelReason').val(), false);
						FormState.updateSelectValue('GEN_CASE_STATUS', 'closeNow', 'closeNow', false);
						completeWorkitem('Cancel', false);
					}
				});
			}
		}
		
		function attachBtnHandler() {
			//--------------------
			// Save
			//--------------------
			$('#button_SaveWorkitem').on('click', function(){
				saveForm('saveDraft');
			});
			
			//--------------------
			// Save and Close
			//--------------------
			$('#button_SubmitWorkitem').off('click').click(function (e) {
				// Form validation
				var showAlertMsg = true;
				var alertMsg = 'Please fill in all the required fields before submit';
				var isValidForm = true;
                var watchTabId = null;
                var activeTabs = ActivityManager.getTabIdList(ActivityManager.getActivityName());
                for (var i = 0; i < activeTabs.length; i++) {
                    watchTabId = activeTabs[i];
                    isValidForm = TabManager.validateTab(watchTabId);
                    if (isValidForm === false) {
                        break;
                    }
                }
                if (isValidForm) {
                    completeWorkitem('Submit', false);
                } else {
                    if (showAlertMsg) {
                        bootbox.alert(alertMsg);
                    }
                    $('#' + TabManager.getAnchorID(watchTabId)).click();
                }
            });
			
			//--------------------
			// Initiate Case
			//--------------------
			$('#button_Initiation').off('click').click(function (e) {
				// Form validation
				var showAlertMsg = true;
				var alertMsg = 'Please fill in all the required fields before submit';
				var isValidForm = true;
				var watchTabId = null;
				var activeTabs = ActivityManager.getTabIdList(ActivityManager.getActivityName());
				for (var i = 0; i < activeTabs.length; i++) {
					watchTabId = activeTabs[i];
					isValidForm = TabManager.validateTab(watchTabId);
					if (isValidForm === false) {
						break;
					}
				}
				if (isValidForm) {
					completeWorkitem('Submit', false);
				} else {
					if (showAlertMsg) {
						bootbox.alert(alertMsg);
					}
					$('#' + TabManager.getAnchorID(watchTabId)).click();
				}
			});
			
			
			//-----------------------------
			// Update Specialist
			//-----------------------------
			$('#button_UpdateSpecialist').off('click').click(function (e) {
				confirmUpdateSpecialist();
			});
			
			//--------------------
			// Close Case (Cancel)
			//--------------------
			$('#button_Cancel').off('click').click(function (e) {
				confirmCancel('ERLRClosingReason', 'Reason for Closing Case', 'Please select a closing reason');
			});
			
			//--------------------
			// Exit
			//--------------------
			$('#button_ExitWIH').off('click').click(function (e) {
				confirmExit();
			});
			
		}
		
		function init() {
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_case_track_main::init');
			//$('#main_buttons_layout_group').css('visibility', 'hidden');
			
			if ($('#WIH_exit_requested').val() == 'true') {
				basicWIHActionClient.exit({confirmMsg: null});
			}
			$(document).on('ALL_TABS_LOADED', function () {
				$(document).on('ON_TAB_CHANGE', onTabChange);
				onAllTabLoaded();
			});

			var activityName = $('#h_activityName').val();
			var formDataXml = $('#h_formData').val();      
			$('#formTitle').text(globalVars.form_title);
			LookupManager.init();
			FormManager.init(activityName, activityTabDefinition, formDataXml);
			FormState.updateVariableValue('reassign', 'No', false);  // reset reassign PV
            FormUtility.setRemainingCharacterDispType("NOW_MAX");

			initStatusBar();
			attachBtnHandler();
			$('a.selectedTab').focus();
		
		}

		function isCompleteCaseActivity(){
            return (ActivityManager.getActivityName() === globalVars.actCaseComplete);
		}

        function isCreateCaseActivity(){
            return (ActivityManager.getActivityName() === globalVars.actCaseCreation);
        }

        function multipleDataSelectFieldValidator(tab){
            var isValid = true;
            // find visible field
            $('#'+ tab.id +' .multipleDataFieldLayoutGroup i.feedbackIcon').removeClass('fiError');
            $('#'+ tab.id +' .multipleDataFieldLayoutGroup.isMandatory').each(function(){
                var $layoutGroup = $(this);
                var isVisible = true;
                $(this).parents().each(function(){
                	var $this = $(this);
                    if($this.attr('id') === 'partial_' + tab.id){
                        return false;
                    }

                    if($this.css('display')==='none'){
                        isVisible = false;
                        return false;
                    }
                });

                if(isVisible){
                    var dataFieldId = $layoutGroup.attr("_dataFieldId");
                    if(0===$('#'+dataFieldId).val().length){
                        $layoutGroup.find('i.feedbackIcon').addClass('fiError');
                        isValid = false;
                        return false;
                    }
                }
            });

            return isValid;
        }


        return {
            init: init,
            controlDynamicTab: controlDynamicTab,
			controlTabVisibility: controlTabVisibility,
			showHideConductIssueTab: showHideConductIssueTab,
			showHidePerformanceIssueTab: showHidePerformanceIssueTab,
			showHideGrievanceTab: showHideGrievanceTab,
			controlButtonVisibility: controlButtonVisibility,
			updatePrimarySpecialistStatusBar: updatePrimarySpecialistStatusBar,
			updateCaseStatusStatusBar: updateCaseStatusStatusBar,
			isCompleteCaseActivity: isCompleteCaseActivity,
			isCreateCaseActivity: isCreateCaseActivity,
            multipleDataSelectFieldValidator: multipleDataSelectFieldValidator
        };
    };

    var _initializer = window.FormMain || (window.FormMain = FormMain());
})(window);


$(document).ready(function() {
	try {
		FormMain.init();
	} catch (e) {
		FormLog.log(FormLog.LOG_LEVEL.ERROR, 'document::ready ==>', e);
		bootbox.alert({
			message: SYSTEM_ERROR_MESSAGE,
			callback: function () {
				basicWIHActionClient.exit({confirmMsg: null});
			}
		});
	}
});


$( document ).ajaxError(function( event, request, settings, thrownError ) {
    bootbox.alert(SYSTEM_ERROR_MESSAGE);
	FormLog.log(FormLog.LOG_LEVEL.ERROR, 'document::ajaxError', thrownError);
});


/**
 * This function to be called when the partial page is loaded.
 */
function onLoadResultActionWorkitem() {
	var errorMessage = $('#ResultActionWorkitemtErrorMessage').val();
	if (errorMessage && 0 < errorMessage.length) {
		if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.ERROR, 'onLoadResultActionWorkitem - ERROR ==>', errorMessage);
		bootbox.alert(SYSTEM_ERROR_MESSAGE);
	} else {
		basicWIHActionClient.setWIHOption('formSaved', true);
		var action = basicWIHActionClient.getWIHOption('requestAction');
		if (action === 'complete') {
			basicWIHActionClient.setContinue();
			basicWIHActionClient.setWIHOption('closeWihOnComplete', true);
			basicWIHActionClient.setWIHOption('completionWindow', false);
			basicWIHActionClient.complete();
		} else if (action === 'tabChange') {

		} else if (action === 'saveDraft') {
			basicWIHActionClient.notify('Your data has been successfully saved.', 3000);
		} else if (action === 'exit') {
			basicWIHActionClient.exit({confirmMsg: null});
		}

		basicWIHActionClient.setWIHOption('formSaved', undefined);
		basicWIHActionClient.setWIHOption('requestAction', undefined);
	}

	FormUtility.greyOutScreen(false);
}


(function(window){
	'use strict';
	
	var MultiSelectDropdown = function(){
		
		/**
		 * Initializes multi-select elements for the given select element (dropdown).
		 * 
		 * @param initOption - the object that specifies options for the multi-select element.  It can specify the following options. 
		 *
		 *		id: string - id of the input element (i.e. a hidden element) that stores the selected values.
		 *
		 *		tabindex: number - tabindex for the input element.  Optional.  
		 *			If specified, the same value will be used for the subsequent selected elements.  
		 *			If omitted, the selected elements will not have tab focus.
		 *
		 *		minSelectionCount: number - the minimum number of selection to be made.  
		 *			Set to 0 if not a required field.
		 *
		 *		maxSelectionCount: number - the maximum number of selection allowed.  
		 *			If the number of selected items reaches this, the input element (dropdown) will be hidden.
		 *
		 *		getSelectionLabel: function - callback function definition that should return the string for the displayed value of the selected item.
		 *
		 *		getItemID: function - callback function definition that should return the string for the stored value of the selected item.
		 *
		 *		initialItems: array of item - item is an object that has data that will be used for constructing the stored value and displayed value.
		 *			The structure of the item should be coordinated with the callback functions in the initOption object.
		 *
		 *		setDataToForm: function - callback function definition that should perform any actions to set data for persistence.
		 *
		 *	For example, 
		 *		{
		 *			id: 'PD_CYB_SEC_CD',
		 *			tabindex: 204,
		 *			minSelectionCount: 1,
		 *			maxSelectionCount: 3, 
		 *			getSelectionLabel: function(item) {
		 *				return item.label
		 *			},
		 *			getItemID: function(item) {
		 *				return item.id;
		 *			},
		 *			initialItems: cybersecInitialData,
		 *			setDataToForm: function(values) {
		 *				var Ids = values.reduce(function(accumulator, currentValue, currentIndex, array) {
		 *					return (accumulator && accumulator.length > 0) ? accumulator + ',' + currentValue.id : currentValue.id;
		 *				}, '');
		 *				$('#PD_CYB_SEC_CD').val(Ids);
		 *			}
		 *		}
		 *		
		 * @return an object that reflects the data and callback functions used for the multi-select element.
		 *	{
		 *		inputId: _inputId,
		 *		selectedElementId: _selectedElementId,
		 *		inputContainerId: _inputContainerId,
		 *		selectedValues: _selectedValues,
		 *		select: select,
		 *		deleteItem: deleteItem
		 *	}
		 *
		 */
		var setupMultiSelectDropdown = function(initOption) {
			if (initOption == null) {
				console.log('Invalid option. Option is null.');
				return;
			}
			if (initOption.id == null || typeof initOption.id !== 'string' || initOption.id.length <= 0) {
				console.log('Invalid option. option.id should be string and cannot be blank.');
				return;
			}
			if (initOption.getItemID == null || typeof initOption.getItemID !== 'function') {
				console.log('Invalid option. option.getItemID is required and mandatory.');
				return;
			}
			if (initOption.getSelectionLabel == null || typeof initOption.getSelectionLabel !== 'function') {
				console.log('Invalid option. option.getSelectionLabel is required and mandatory.');
				return;
			}
			if (initOption.setDataToForm == null || typeof initOption.setDataToForm !== 'function') {
				console.log('Invalid option. option.setDataToForm is required and mandatory.');
				return;
			}
			
			var _option = initOption;
			var _inputId = _option.id + "_SEL";
			var _selectedElementId = _inputId + '_DISP';
			var _inputContainerId = _inputId + '_container';
			var _separator = _option.separator || ',';
			var _selectedValues = [];
			var _tabindex = _option.tabindex || 0;

			_option.minSelectionCount = _option.minSelectionCount || 1;
			_option.maxSelectionCount = _option.maxSelectionCount || 1;

			var footerHTML = '<div class="customControl"><ul class="hidden nobullet autocomplete_ul" id="___UL___" /></div>';
			footerHTML = footerHTML.replace('___UL___', _selectedElementId);
			$('#' + _inputContainerId).parent().parent().append(footerHTML);

			var getListItemHTML = function(targetID, targetLabel, tabIndex) {
				var elementString = "";
				if (FormUtility.isReadOnly() == true) {
					elementString = '<li id="' + targetID + '">' + targetLabel + '</li>';
				} else {
					elementString = "<li id=\"" + targetID + "\"><img src=\"/bizflowwebmaker/StratCon_AUT/custom/images/delete-icon.png"
					+ "\" id=\"delete-" + targetID + "\" deleteId=\"" + targetID
					+ "\" title=\"Remove " + targetLabel + "\" tabindex=\"" + tabIndex + "\" />" + targetLabel + "</li>";
				}
				return elementString;
			}

			var sortSelectedValues = function() {
				if (_selectedValues && _selectedValues.length > 1) {
					if (_option.compare != null && typeof _option.compare === 'function') {
						_selectedValues.sort(_option.compare);
					} else {
						_selectedValues.sort(function(a,b) {
							return _option.getSelectionLabel(a) > _option.getSelectionLabel(b);
						});
					}
				}
			}

			var setDataToForm = function() {
				_option.setDataToForm(_selectedValues);
			}

			var display = function() {
				var count = _selectedValues.length
				var selectedItemDisp = $('#' + _selectedElementId + ' li');
				if (selectedItemDisp != null && selectedItemDisp.length > 0) {
					$('#' + _selectedElementId + ' li').each(function() {
						$(this).remove();
					});
				}
				for (var index = 0; index < count; index++) {
					var itemID = _option.getItemID(_selectedValues[index]);
					var itemLabel = _option.getSelectionLabel(_selectedValues[index])
					var listItemHTML = getListItemHTML(itemID, itemLabel, _tabindex);
					$('#' + _selectedElementId).append(listItemHTML);
				}
				$('#' + _selectedElementId).removeClass('hidden');
				if (count >= _option.maxSelectionCount) {
					$('#' + _inputContainerId).addClass('hidden');
				}
				if (count >= _option.minSelectionCount) {
					$('#' + _inputId).attr('_required', 'false');
				}
			}
			
			var select = function() {
				var selectedVal = $('#' + _inputId + ' option:selected').val();
				if (typeof selectedVal == 'undefined' || selectedVal == null || selectedVal.trim().length <= 0) return;
				var currentItem = {
					id: selectedVal,
					label: $('#' + _inputId + ' option:selected').text()
				};
				var found = false;
				for (var valueIndex = 0; valueIndex < _selectedValues.length; valueIndex++) {
					var foundID = _option.getItemID(_selectedValues[valueIndex]);
					if (foundID === currentItem.id) {
						found = true;
						break;
					}
				}

				if (found === false) {
					_selectedValues.push(currentItem);
					var count = _selectedValues.length;
					sortSelectedValues();
					display();
					setDataToForm();  // Call form to save selected values after addition
					$('#' + _inputId + ' option:selected').prop('selected', false);  // unselect the dropdown
				}
			};

			var deleteItem = function(e) {
				var count = _selectedValues.length;
				var targetID = $(e.currentTarget).attr('deleteid');
				var found = false;

				for (var valueIndex = 0; valueIndex < _selectedValues.length; valueIndex++) {
					var foundID = _option.getItemID(_selectedValues[valueIndex]);
					if (foundID === targetID) {
						found = true;
						break;
					}
				}

				if (found) {    
					for (var index = 0; index < count; index++) {
						if (targetID === _option.getItemID(_selectedValues[index])) {
							_selectedValues.splice(index, 1);
							count -= 1;
							break;
						}
					}

					$('#' + _selectedElementId + ' li[id="' + targetID + '"]').remove();
					setDataToForm();  // Call form to save changed values after removal
					$('#' + _inputContainerId).removeClass('hidden');

					if (count == 0) {
						$('#' + _selectedElementId).addClass('hidden').empty();
					}
					if (count < _option.minSelectionCount) {
						$('#' + _inputId).attr('_required', 'true');
					}
				}
			};

			$('#' + _inputId).on('change', function(){
				select();
			});

			if (FormUtility.isReadOnly() == false) {
				$('#' + _selectedElementId).delegate("img", "click keyup", function (e) {
					if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
						deleteItem(e);
					}
				});
			}
			
			var deleteAll = function() {
				_selectedValues = [];
				display();
				_option.setDataToForm('');
			}

			// if there is initial items, build selected item list to display
			if (_option.initialItems && typeof _option.initialItems === 'object') {
				var count = _option.initialItems.length
				var isEmpty = true;
				for (var index = 0; index < count; index++) {
					var ui = {};
					ui.item = _option.initialItems[index];

					for (var key in ui.item) {
						if (ui.item.hasOwnProperty(key)) {
							var data = ui.item[key];
							if (typeof data == 'string' && data.length > 0) {
								isEmpty = false;
								break;
							}
						}
					}
				}
				if(!isEmpty){
					_selectedValues = _option.initialItems.slice();
					sortSelectedValues();
					display();
				}
			}

			if (FormUtility.isReadOnly() == true) {
				$('#' + _inputContainerId).addClass('hidden');
			}

			console.log('Multiselect is initialized!! - ' + _option.id);
			return {
				//option: option,
				inputId: _inputId,
				selectedElementId: _selectedElementId,
				inputContainerId: _inputContainerId,
				selectedValues: _selectedValues,
				select: select,
				deleteItem: deleteItem,
				deleteAll: deleteAll
			};
		};
		// end of setupMultiSelectDropdown
		
		return {
			setupMultiSelectDropdown: setupMultiSelectDropdown
		};
	};
	
    var _initializer = window.MultiSelectDropdown || (window.MultiSelectDropdown = MultiSelectDropdown());
})(window);


(function(window){
	'use strict';

	function CommonOpUtil(){
		
		function hyfShowOrHide(item, id){
			if (item.value === 'Y' || item.value === 'yes' || item.value === 'Yes' || item.value === 'true' || item.value == true){
				hyf.util.showComponent(id);
			} else {
				hyf.util.hideComponent(id);
			}
		}
		
		/*
			Set standard date constraint for date fields, who's maximum value is today's date.
			The query selector is a css class name, that all date fields with this constraint must bear in their class list in wm.
		function setStandardDateConstraint(fieldClass){
			if (fieldClass.replace(/\s/g,'') !== '' && fieldClass !== undefined){
				var list  = $('.'+fieldClass.replace(/\s/g,'')).get();
				list.forEach(function(el){
					if (el.id !=='' && el.id !== undefined){
						hyf.calendar.setDateConstraint(el.id, 'Maximum', 'Today'); 
					}
				});

			}
		}
		 */
		 
		function setStandardDateConstraint(dateFields) {
			if ( Array.isArray(dateFields) && dateFields.length > 0) {
				dateFields.forEach(function(el){
					if (el !=='' && el !== undefined){
						try {
							hyf.calendar.setDateConstraint(el, 'Maximum', 'Today'); 
						} catch(e) {
							FormLog.log(FormLog.LOG_LEVEL.ERROR, "cms_erlr_main::setStandardDateConstraint(item) item = ", item);
						}
					}
				});
			}
		}
		
		/*
			dynamically set fields required based on activityName.
			The query selector is activityName_dynamic_require. All elements that should be dynamically required must have a class activityName_dynamic_require
			set in the css classes property in wm.
		
			reqFieldForActivity: 
			[
				{
					actName: globalVars.case_creation,
					reqFieldIds: 
					[
						'PI_ACTION_TYPE'
					]
				},
				{
					actName: globalVars.case_complete,
					reqFieldIds: 
					[
						'PI_ACTION_TYPE'
					]
				}
			],
			
		*/
		
		function dynamicMandatory(reqFieldForActivity){
			var reqFieldIds = [];
			for (var i = 0; i < reqFieldForActivity.length; i++) {
				//TODO: perhaps, it's more generic and safer to move activity name as function param
				if (reqFieldForActivity[i].actName == 'ALLACTIVITIES' || reqFieldForActivity[i].actName == ActivityManager.getActivityName()) {
					reqFieldIds = reqFieldIds.concat(reqFieldForActivity[i].reqFieldIds);
				}
			}
			if (reqFieldIds != null && reqFieldIds.length > 0) {
				reqFieldIds.forEach(function(item) {
					try {
						hyf.util.setMandatoryConstraint(item, true);
					} catch (e) {
						FormLog.log(FormLog.LOG_LEVEL.ERROR, "cms_erlr_main::dynamicMandatory(item) item = ", item);
					}
				});
			}
		}
		
		
		/*
			Generic XMLRespose processor for auto complete ajax calls to employee table. This is passed as a parameter to setAutoComplete function.
		*/
		function responseMapper(xml){
			var data = $('record', xml).map(function(){
				return {
					email: $('EMAIL_ADDR', this).text(),
					last_name: $('LAST_NAME', this).text(),
					first_name: $('FIRST_NAME', this).text(),
					middle_name: $('MIDDLE_NAME', this).text(),
					adminCode: $('ORG_CD', this).text(),
					admin_code_desc :$('ADMIN_CODE_DESC', this).text(),
					series : $('SERIES', this).text(),
					grade :$('GRADE', this).text(),
					step : $('STEP', this).text(),
					pay_plan :$('PAY_PLAN', this).text(),
					position_title: $('POSITION_TITLE_NAME', this).text()
				};
			}).get();
			return data;
		}
		
		function appendEmplInfo(item){
			var emplInfo = item.last_name + ', '+ item.first_name;
			if (typeof item.email != 'undefined' && item.email != null && item.email.length > 0) {
				emplInfo += ' (' + item.email + ')';
			}
			return '<a role="option">' + emplInfo + '</a>';
		}
		
		function adminCodeResponseMapper(xml){
			var data = $('record', xml).map(function (){
				return {
					adminCode: $('ADMINISTRATIVE_CODE', this).text(),
					description: $('DESCRIPTION', this).text()
				};
			}).get();
			return data;
		}
		
		function appendAdminCode(item){
			var admin_code = item.adminCode +' - '+item.description;
			return '<a role="option">' + admin_code +'</a>';
		}
		
		// Calls ajax service for business day count.
		// @param startDt - start date in yyyy-MM-dd format
		// @param endDt - end date in yyyy-MM-dd format
		// @param callbackForBusinessDaysCount - callback function that handles successful response from service call.
		// 				This callback should extract data from the response, and assign the value to the target field.
		// 			ex) 
		//			function callbackForBusinessDaysCount(data) {
		//				$('#GEN_BUS_DAY').text(data[0]);
		//			}
		function getBusinessDaysCount(startDt, endDt, callbackForBusinessDaysCount, callbackTargetElementId) {
			if (typeof startDt == 'undefined' || startDt == null || startDt.length <= 0 || 0<=startDt.indexOf('NaN')
				|| typeof endDt == 'undefined' || endDt == null || endDt.length <= 0  || 0<=endDt.indexOf('NaN')
				|| typeof callbackForBusinessDaysCount != 'function' || callbackForBusinessDaysCount == null) return 0;

			var sDt = parseDate(startDt);
			var eDt = parseDate(endDt);
			if(sDt != null && sDt != null){
                if(sDt.getDate() <= eDt.getDate())
                {
                    $.ajax({
                        url: '/bizflowwebmaker/cms_erlr_service/getBusinessDayCount.do?startDt=' + startDt + '&endDt=' + endDt,
                        dataType: 'xml',
                        cache: false,
                        success: function (xmlResponse) {
                            var data = $('record', xmlResponse).map(function(){
                                return $('BUSDAYS', this).text();
                            });
                            callbackForBusinessDaysCount(data, callbackTargetElementId);
                        },
                        error: function(xhr, status, errmsg) {
                            alert('error: status = ' + status + ' errmsg = ' + errmsg);
                        }
                    });
                }else{
                    callbackForBusinessDaysCount(null, callbackTargetElementId);
                }
            }
		}
		
		// Clears content of elements that belongs to the group specified.
		// @param groupId - element id of the group layout (div tag)
		function clearGroupContent(groupId) {

			// TEXTBOX
			$.each($('#' + groupId + ' input.textbox'), function (index, value) {
				var value = $(this).val();
				if (value && value.length > 0) {
					$(this).val('');
					FormState.updateTextValue($(this)[0].id, '', false);
				}
			});

			// TEXTAREA
			$.each($('#' + groupId + ' textarea'), function (i, v) {
				var value = $(this).val();
				if (value && value.length > 0) {
					$(this).val('');
					FormState.updateTextValue($(this)[0].id, '', false);
				}
			});

			// CHECKBOX
			$.each($('#' + groupId + ' input[type=checkbox]'), function (i, v) {
				$(this).prop('checked', false);
				var value = $(this).val();
				if (value && value.length > 0) {
					$(this).trigger('change');
				}
			});
			$.each($('#' + groupId + ' input.checkbox'), function (i, v) {
				var value = $(this).prop('checked');
				if (value === true) {
					$(this).prop('checked', false);
					$(this).trigger('change');
				}
			});

			// SELECT
			$.each($('#' + groupId + ' select'), function (i, v) {
				var value = $(this).val();
				if (value && value.length > 0) {
					$(this).val('');
					$(this).trigger('change');
					
				}
			});
			
			// OUTPUT
			$.each($('#' + groupId + ' span.output'), function (i, v) {
				var value = $(this).text();
				if (value && value.length > 0) {
					$(this).text('');
					FormState.updateTextValue($(this)[0].id, '', false);
				}
			});

			// HIDDEN
            $.each($('#' + groupId + ' input[type=hidden]'), function (index, value) {
                var value = $(this).val();
                if (value && value.length > 0) {
                    $(this).val('');
                    FormState.updateTextValue($(this)[0].id, '', false);
                }
            });

			
			// SELECTED - READONLY
            $('#'+groupId+'  ul.autocomplete_ul li img').trigger("click");
			// $.each($('#' + groupId + ' ul.autocomplete_ul li'), function (i, v) {
			// 	// remove elements created by autocomplete selection
			// 	$(this).remove();
			// });
		}
		
		function showHideLayoutGroup(groupId, isShown, clearWhenHidden) {
			if (isShown === true) {
				hyf.util.showComponent(groupId+'_label_container');
                hyf.util.showComponent(groupId);
			} else {
				if (clearWhenHidden !== false) {
					// unless specifically set false, clear content when hiding
                    if($('#'+groupId).css('display') !== 'none'){
                        clearGroupContent(groupId);
                    }
				}
                hyf.util.hideComponent(groupId+'_label_container');
				hyf.util.hideComponent(groupId);
			}
		}

		
		return {
			hyfShowOrHide: hyfShowOrHide,
			setStandardDateConstraint: setStandardDateConstraint,
			dynamicMandatory: dynamicMandatory,
			responseMapper: responseMapper,
			appendEmplInfo: appendEmplInfo,
			adminCodeResponseMapper: adminCodeResponseMapper,
			appendAdminCode: appendAdminCode,
			getBusinessDaysCount: getBusinessDaysCount,
			clearGroupContent: clearGroupContent,
			showHideLayoutGroup: showHideLayoutGroup
		};
	}(window.CommonOpUtil !== undefined ? window.CommonOpUtil : (window.CommonOpUtil = CommonOpUtil()));
})(window);


(function(window){
    'use strict';

    var MultiDataSelectField = function(){

        var init = function(config) {
            config = _.assignIn({unique:true,mandatory:false},config);
            var readOnly = FormUtility.isReadOnly();
            var inputDialogSelector          = '#' + config.dataFieldId + '_input_dialog';
            var historyDialogSelector        = '#' + config.dataFieldId + '_history_dialog';
            var addButtonSelector            = '#' + config.dataFieldId + '_add_button';
            var historyLinkSelector          = '#' + config.dataFieldId + '_history_link';
            var historyTemplateSelector      = '#' + config.dataFieldId + '_history_template';
            var displayFieldGroupSelector    = '#' + config.dataFieldId + '_display_field_group';
            var historyTableSelector         = '#' + config.dataFieldId + '_history_table';

            var $multipleDataFieldGroup     = $('#'+config.layoutGroupId);
            $multipleDataFieldGroup.attr("_dataFieldId", config.dataFieldId);
            $multipleDataFieldGroup.addClass("multipleDataFieldLayoutGroup");

            var isIE = /MSIE|Trident/.test(window.navigator.userAgent);

            if(config.mandatory){
                $multipleDataFieldGroup.addClass("isMandatory");
            }

            var $inputDialog = $(inputDialogSelector);

            var resetData = function(){
                $('#'+config.dataFieldId).val('');
                FormState.updateTextValue(config.dataFieldId, '', false);
            };
            var getJSONData = function(){
                var val = $('#'+config.dataFieldId).val();
                if(val.length === 0){
                    return [];
                }
                return JSON.parse(val);
            };
            var setData = function(data){
                var str = JSON.stringify(data);
                $('#'+config.dataFieldId).val(str);
                FormState.updateTextValue(config.dataFieldId, str, true);
            };
            var pushData = function(value, fieldID){
                var data = getJSONData();

                if(typeof (value) === 'object'){
                    data.push(value);
                }else{
                    var obj = {};
                    obj[fieldID] = value;
                    data.push(obj);
                }

                if(config.unique.fieldId){
                    data = _.uniqBy(data, config.unique.fieldId);
                }else if (typeof (config.unique) === 'boolean' && config.unique){
                    data = _.uniqBy(data, function(o){return JSON.stringify(o);});
                }

                if(config.sort){
                    data = _.sortBy(data, [function(o){
                        if(typeof(config.sort.valueType) !== 'undefined' && config.sort.valueType === 'date'){
                            return getDateFromFormat(o[config.sort.fieldId], 'MM/dd/yyyy');
                        }else{
                            return o[config.sort.fieldId];
                        }
                    }]);
                    if(config.sort.order && config.sort.order === 'desc'){
                        data = data.reverse();
                    }
                }

                setData(data);

                return data;
            };
            var toggleButtonLabel = function(show){
                var $addButton = $(addButtonSelector);
                var labelId = $addButton.attr("id") + "_label";
                if(show) {
                    $('#'+labelId).css("visibility", "visible");
                }else{
                    $('#'+labelId).css("visibility", "hidden");
                }
            };

            var render = function(){
                // if(!FormState.isDirty(config.dataFieldId)){
                //     return
                // }

                FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'MultiDataSelectField::render', config.dataFieldId);
                var data = getJSONData();
                if(0<data.length){
                    var firstItem = data[0];
                    $.each(config.recordFields, function(i, fieldId){
                        $('#' + fieldId).text(firstItem[fieldId]);
                    });
                }

                CommonOpUtil.showHideLayoutGroup(config.dataFieldId + '_display_field_group', 0<data.length, false);
                $(addButtonSelector).toggle(!readOnly);
                $(historyLinkSelector).toggle(0<data.length);
                toggleButtonLabel(0===data.length);

                // extra
                if(config.outputRender){
                    config.outputRender(data, config);
                }
            };
            var addCallbackFunc = function(){
                var valid = true;
                var dialogId = $inputDialog.attr('id');
                var $dialogForm = $('#' + dialogId);
                $dialogForm.find('INPUT,SELECT.select,textarea.textbox').each(function(i,v){
                    var fieldId = $(this).attr("id");
                    if(fieldId){
                        valid = hyf.validation.validateField(fieldId, false);
                        if(!valid){
                            return false;
                        }
                    }
                });

                if(valid) {
                    var obj = getNewValue();
                    pushData(obj);
                }else{
                    return false;
                }
            };
            var getNewValue = function(){
                var ret = {};
                $('#'+inputDialogOption.layoutGroupId).find("input, select.select, textarea.textbox").each(function(){
                    var $this = $(this);
                    var tmpId = $this.attr('id');
                    if(tmpId && tmpId.indexOf('_') === 0){
                        var id = tmpId.substring(1);
                        if(config.recordFields && -1<config.recordFields.indexOf(id)){
                            ret[id] = $this.val();
                        }
                    }
                });
                return ret;
            };

            if(!readOnly){
                var inputDialogOption = {
                    onEscape: true,
                    buttons: {
                        confirm: {
                            label: 'Add',
                            className: 'btn-primary',
                            callback: addCallbackFunc
                        },
                        cancel:{
                            label: 'Cancel',
                            className: 'btn-default'
                        }
                    }
                };

                // button label
                var $addButton = $(addButtonSelector);
                if(config.mandatory){
                    var labelId = $addButton.attr("id") + "_label";
                    var $label = $('#'+labelId);
                    $label.html($label.text()+'<span class="mandatory" style="" title="Mandatory field"> * </span>');
                    $addButton.parent().append('<i class="feedbackIcon" style="font-size: 13px; font-weight: 400;position:relative;right:-2px"></i>');
                }

                var displayInputForm = function(){
                    if(typeof(inputDialogOption.message) === 'undefined'){
                        $inputDialog.removeClass('hide');
                        inputDialogOption.title = $inputDialog.attr("_title");
                        inputDialogOption.message = $inputDialog[0];
                        inputDialogOption.layoutGroupId = $inputDialog.attr("id");
                    }

                    var dialog = bootbox.dialog(inputDialogOption);
                    dialog.init(function(){
                        CommonOpUtil.clearGroupContent(inputDialogOption.layoutGroupId);
                        if(config.dialog && config.dialog.input && config.dialog.input.init){
                            config.dialog.input.init();
                        }
                    });
                };

                $addButton.on('click', displayInputForm);
            }

            var deleteItemByIndex = function(index){
                var data = getJSONData();
                data.splice(index,1);
                setData(data);
                return data;
            };

            var displayHistory = function(){
                var data = getJSONData();
                $.each(data, function(idx, item){
                    item['dataFieldId'] = config.dataFieldId;
                    item['index'] = idx;
                });
                var view = {dataFieldId: config.dataFieldId, items:data};
                var historyData;
                if(0<data.length){
                    var template = '';
                    if(isIE){
                        template = $(historyTemplateSelector)[0].defaultValue;
                    }else{
                        template = $(historyTemplateSelector).text();
                    }
                    Mustache.parse(template, ['[[',']]']);
                    historyData = Mustache.render(template, view);

                }else{
                    historyData = "<h4>There is no historical record.</h4>"
                }

                var $historyDialog = $(historyDialogSelector);
                var dialog = bootbox.dialog({
                    title: $historyDialog.attr("_title"),
                    message: historyData,
                    onEscape: true,
                    buttons: {
                        cancel:{
                            label: 'Close',
                            className: 'btn-primary'
                        }
                    }
                });
                setTimeout(function(){
                    dialog.init(function(){
                        if(readOnly){
                            $(historyTableSelector + ' a.deleteAction').remove();
                        }else{
                            $(historyTableSelector + ' a.deleteAction').on('click', function(e){
                                var index = $(this).attr("_index");
                                var data = deleteItemByIndex(index);
                                bootbox.hideAll();
                                if(0<data.length){
                                    displayHistory();
                                }
                            });
                        }
                        if(config.dialog && config.dialog.history && config.dialog.history.init){
                            config.dialog.history.init();
                        }
                    });
                }, 500);
            };

            $(historyLinkSelector).on('click', displayHistory);

            render();

            return {
                render:    render
            };
        };

        return {
            init: init
        };

    };

    var _initializer = window.MultiDataSelectField || (window.MultiDataSelectField = MultiDataSelectField());
})(window);
