var CASE_COMPLETED = {
    initialized: false,
    init: function () {
        
    },
    render: function () {
        
    }
};