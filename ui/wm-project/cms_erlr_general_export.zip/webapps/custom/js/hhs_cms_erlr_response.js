//var  cms_main_tab1  = {
	

(function (window) {
	
	'use strict';
	
    var cms_main_tab1 = function () {
		
		var initialized = false;
		
		
		var dateFieldsPastPresent = 
		[
			'GEN_CUST_INIT_CONTACT_DT',
			'GEN_INVESTIGATE_START_DT',
			'GEN_INVESTIGATE_END_DT',
		];
		
		var dateFieldsPresentFuture = 
		[
		];
		
		var reqFieldForActivity = 
		[
			{
				actName: globalVars.actAll,
				reqFieldIds: 
				[
					'GEN_PRIMARY_SPECIALIST', 
					'GEN_CASE_DESC',
					'GEN_CUST_INIT_CONTACT_DT'
				]
			},
			{
				actName: globalVars.actCaseCreation,
				reqFieldIds: 
				[
				]
			},
			{
				actName: globalVars.actCaseComplete,
				reqFieldIds: 
				[
				]
			}
		];
		
		
		var pageElements = [
			'contact_info_auto',
			'emp_info_auto',
			'org_assign'
		];
		
		
		var groups = [
			'cms_rep_name_group',
			'investigation_conducted_date_group',
			'empl_detail_group',
			'contact_detail_group',
			'primary_rep_group',
			'non_cms_primary_group',
			'non_cms_primary_2_group',
			'selected_case_categ_group'
		];
		
		// var dropdownEvents = {
			// /*I intend to have a list of dropdowns and their corresponding event hanlder helper functions, so that I can access the reference to the function, then call it 
			// like dropdownTargets[event.target.id](),where event target id corresponds to the obj key
			// */
			 // 'GEN_PRIMARY_SPECIALIST':primaryDWCSpecialist, 
			 // 'GEN_PRIMARY_REP':primaryRep,
			 // 'GEN_INVESTIGATION': investigationConducted,
			 // 'GEN_STD_CONDUCT': stdConduct
		// };
		
		
		
		
		function controlPrimarySpecialistVisibility(){
            var elemVal = FormState.getElementValue('GEN_PRIMARY_SPECIALIST');
            var elemTxt = $('#GEN_PRIMARY_SPECIALIST option[value="' + elemVal + '"]').text();
			if (typeof elemTxt == 'undefined' || elemTxt == null || elemTxt.trim().length <= 0) return;
			// control Primary Specialist in form summary bar area
			var searchIndex = elemTxt.indexOf('(');
			if (searchIndex != null && searchIndex > -1){
				FormMain.updatePrimarySpecialistStatusBar(elemTxt.substring(0, searchIndex));
			} else {
				FormMain.updatePrimarySpecialistStatusBar(elemTxt);
			}
		}
		
		function controlCaseStatusVisibility(){
            var elemVal = FormState.getElementValue('GEN_CASE_STATUS');
            var elemTxt = $('#GEN_CASE_STATUS option[value="' + elemVal + '"]').text();
			if (typeof elemTxt == 'undefined' || elemTxt == null || elemTxt.trim().length <= 0) return;
			// control Case Status in form summary bar area
			FormMain.updateCaseStatusStatusBar(elemTxt);
		}
		
		function controlPrimaryRepVisibility(){
			var elemVal = FormState.getElementValue('GEN_PRIMARY_REP');
			if ('CMS' === elemVal) {
				hyf.util.showComponent('cms_rep_name_group');
			} else {
				hyf.util.hideComponent('cms_rep_name_group');
			}
			
			if ('NON-CMS' === elemVal) {
				hyf.util.showComponent('non_cms_primary_group');
				hyf.util.showComponent('non_cms_primary_2_group');
			} else {
				hyf.util.hideComponent('non_cms_primary_group');
				hyf.util.hideComponent('non_cms_primary_2_group');
			}
		}
		
		function controlCaseTypeVisibility() {
            var elemVal = FormState.getElementValue('GEN_CASE_TYPE');
            var elemTxt = $('#GEN_CASE_TYPE option[value="' + elemVal + '"]').text();
			if ('Performance Issue' === elemTxt){
				hyf.util.hideComponent('case_type_perf_group');
			} else {
				hyf.util.showComponent('case_type_perf_group');
			}
        }
		
		function controlInvestigationVisibility() {
            var elemVal = FormState.getElementValue('GEN_INVESTIGATION');
			if ('Yes' === elemVal){
				hyf.util.showComponent('primary_start_end_date_group');
			} else {
				hyf.util.hideComponent('primary_start_end_date_group');
			}
        }
		
		function controlStdConductVisibility() {
            var elemVal = FormState.getElementValue('GEN_STD_CONDUCT');
			if ('Yes' === elemVal){
				hyf.util.showComponent('conduct_type_group');
			} else {
				hyf.util.hideComponent('conduct_type_group');
			}
        }


	
		function initVisibility() {
			controlPrimarySpecialistVisibility();
			controlCaseStatusVisibility();
			controlPrimaryRepVisibility();
			controlCaseTypeVisibility();
			controlInvestigationVisibility();
			controlStdConductVisibility();
		}

		function initEventHandlers() {
			$('#GEN_PRIMARY_SPECIALIST').on('change', function(e) {
				var target = e.target;
				var elemVal = target.options[target.options.selectedIndex].value;
				var elemTxt = target.options[target.options.selectedIndex].text;
				FormState.updateSelectValue('GEN_PRIMARY_SPECIALIST', elemVal, elemTxt);
				controlPrimarySpecialistVisibility();
			});
			
			$('#GEN_CASE_STATUS').on('change', function(e) {
				var target = e.target;
				var elemVal = target.options[target.options.selectedIndex].value;
				var elemTxt = target.options[target.options.selectedIndex].text;
				FormState.updateSelectValue('GEN_CASE_STATUS', elemVal, elemTxt);
				controlCaseStatusVisibility();
			});
			
			$('#GEN_PRIMARY_REP').on('change', function(e) {
				var target = e.target;
				var elemVal = target.options[target.options.selectedIndex].value;
				var elemTxt = target.options[target.options.selectedIndex].text;
				FormState.updateSelectValue('GEN_PRIMARY_REP', elemVal, elemTxt);
				controlPrimaryRepVisibility();
			});
			
			$('#GEN_CASE_TYPE').on('change', function(e) {
				var target = e.target;
				var elemVal = target.options[target.options.selectedIndex].value;
				var elemTxt = target.options[target.options.selectedIndex].text;
				FormState.updateSelectValue('GEN_CASE_TYPE', elemVal, elemTxt);
				controlCaseTypeVisibility();
				FormMain.controlTabVisibility();
			});
			
			$('#GEN_INVESTIGATION').on('change', function(e) {
				var target = e.target;
				var elemVal = target.options[target.options.selectedIndex].value;
				var elemTxt = target.options[target.options.selectedIndex].text;
				FormState.updateSelectValue('GEN_INVESTIGATION', elemVal, elemTxt);
				controlInvestigationVisibility();
			});
			
			$('#GEN_STD_CONDUCT').on('change', function(e) {
				var target = e.target;
				var elemVal = target.options[target.options.selectedIndex].value;
				var elemTxt = target.options[target.options.selectedIndex].text;
				FormState.updateSelectValue('GEN_STD_CONDUCT', elemVal, elemTxt);
				controlStdConductVisibility();
			});
			
			//TODO: cust/emp delete button
		}
		
		
		/*
			if (!cms_main_tab1.initialized){
				FormAutoComplete.setAutoComplete('contact_info_auto','/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=',populateContactInfo,CommonOpUtil.responseMapper,appendInfo);
				FormAutoComplete.setAutoComplete('emp_info_auto','/bizflowwebmaker/cms_erlr_service/contactInfo.do?emp=',populateContactInfo,CommonOpUtil.responseMapper,appendInfo);
				FormAutoComplete.setAutoComplete('cms_primary_rep','/bizflowwebmaker/cms_erlr_service/contact
				
		*/
		/*
        function mapContactInfoResponse(context) {
            return {
                lastName: $("LAST_NAME", context).text(),
                firstName: $("FIRST_NAME", context).text(),
                lastName: $("MIDDLE_NAME", context).text(),
                email: $("EMAIL_ADDR", context).text(),
                adminCode: $("ORG_CD", context).text(),
                adminCodeDesc: $("ADMIN_CODE_DESC", context).text()
            };
        }
	
        function getContactInfoSelectionLabel(item) {
            return item.name + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '');
        }

        function _getContactInfoCandidateLabel(item) {
            return item.name + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '');
        }

        function _getItemID(item) {
            return item.id;
        }
		
		function setAutocompCustContact() {
			var option = {
                id: 'GEN_CUST_CONTACT_SEARCH',
                baseURL: '/bizflowwebmaker/StratCon_AUT',
                targetURL: '/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=',
                minLength: 2,
                minSelectionCount: 1,
                maxSelectionCount: 1,

                mapFunction: _mapFunction,
                getSelectionLabel: _getSelectionLabel,
                getCandidateLabel: _getCandidateLabel,
                getItemID: _getItemID,
                setDataToForm: function (values) {
                    FormState.updateObjectValue('selectingOfficial', values);
                    setPVRelatedUserIds();
                },

                // initialize
                initialItems: FormState.getElementArrayValue('selectingOfficial', [])
            };
		}
		*/
		
		function init() {
			//$('#main_buttons_layout_group').removeAttr('style');
			//cms_main_tab1.showCaseView('adr');
			//cms_main_tab1.groups.forEach(function(el,index){
			//	hyf.util.hideComponent(el);
			//});
			//$('#primary_start_end_date_group,#conduct_type_group').hide();
			//$('#delete_cust,#delete_emp').on('click',deleteContact);
			//$('#cat_1,#cat_2,#cat_3').on('click',selectedCatChange);
			
			
			
			
			//-----------------------------------
			// visibility configuration
			//-----------------------------------
			//layout_group.forEach(function(item,index){
			//	hyf.util.hideComponent(item);
			//});
			initVisibility();
			
			
			//-----------------------------------
			// validation configuration
			//-----------------------------------
			dateFieldsPastPresent.forEach(function(item){
				hyf.calendar.setDateConstraint(item, 'Maximum', 'Today');
			});
			//dateFieldsPresentFuture.forEach(function(item){
			//	hyf.calendar.setDateConstraint(item, 'Minimum', 'Today');
			//});
			CommonOpUtil.dynamicMandatory(reqFieldForActivity);
			
			//-----------------------------------
			// event handler configuration
			//-----------------------------------
			initEventHandlers();
			
			
			
			//TODO: Contact (GEN_CONTACT_INFO_AUTO) autocomplete implementation
			//setAutocompCustContact();
			
			//TODO: Employee (GEN_EMP_INFO_AUTO) autocomplete implementation
			
			//TODO: CMS Primary Rep (GEN_CMS_PRIMARY_REP) autocomplete implementation
			
			//TODO: Related Case (GEN_CMS_PRIMARY_REP) autocomplete implementation
			
			//TODO: Case Category multi-select implementation
			
		
		
		}
		
		function render() {
			var contact = FormState.getState('custContact');
			var empContact = FormState.getState('empContact');
			//var conduct = FormState.getState('std_conduct');
			//var investigation = FormState.getState('investigation');
			//var primarySpecialist = FormState.getState('dwc_specialist');
			//var status = FormState.getState('case_status');
			//var cmsRep = FormState.getState('primary_rep');
			var relatedTo = FormState.getState('relatedCaseNumber');
			var relatedToHidden = FormState.getState('related_to_case');
			//var caseCat = FormState.getState('selected_category');
			// var caseType = FormState.getState('GEN_CASE_TYPE');
			// if (caseType && caseType.dirty){
				// if (caseType.value.replace(/\s/g,'') === 'PerformanceIssue'){
					// hyf.util.hideComponent('case_type_perf_group');
				// } else {
					// hyf.util.showComponent('case_type_perf_group');
				// }
			// }
			// if (conduct && conduct.dirty){
				// stdConduct(conduct.value);
			// }
			// if (investigation && investigation.dirty){
				// investigationConducted(investigation.value);
			// }
			// if (primarySpecialist && primarySpecialist.dirty){
				// primaryDWCSpecialist(primarySpecialist.text);
			// }
			// if (status && status.dirty && status.value !=='default'){
				// $('#output_caseStatus').text(status.text);
			// }
			// if (cmsRep && cmsRep.dirty && cmsRep.value === 'cms'){
				// primaryRep();
				// hyf.util.showComponent('cms_rep_name_group');
			// } else if (cmsRep && cmsRep.dirty && cmsRep.value === 'non_cms'){
				// primaryRep();
				// hyf.util.showComponent('non_cms_primary_group');
				// hyf.util.showComponent('non_cms_primary_2_group');
			// } else if (cmsRep && cmsRep.dirty){
				// primaryRep();
			// }
			if ((contact && contact.dirty)){	
				var name  = contact.value.split(',');
				populateContactInfo({last_name: name[0],first_name: name[1],adminCode : name[2],admin_code_desc:name[3]
				,step:name[4],grade:name[5],series:name[7],pay_plan:name[6]},'contact_info_auto');
			}
			if ((empContact && empContact.dirty)){
				var name  = empContact.value.split(',');				
				populateContactInfo({last_name: name[0],first_name: name[1],adminCode : name[2],admin_code_desc:name[3]
				,step:name[4],grade:name[5],series:name[7],pay_plan:name[6],position_title:name[8]},'emp_info_auto');
			}
			if (!cms_main_tab1.initialized && (relatedToHidden && relatedToHidden.dirty)){
				var parse = (relatedToHidden.value.indexOf(',') > -1) ? relatedToHidden.value.split(',') : [relatedToHidden.value];
				parse.forEach(function(el, indx){
					if (el !='' && el !== undefined){
					$('#RELATED_CASE_LIST').append('<br/><a href="#" id="'+el+'">'+el+'</a>');
					}
				});
			}
			if ((relatedTo && relatedTo.dirty)){
				if (relatedTo.dirty){relatedCaseNumber(relatedTo.value);}
			}
			if ( relatedToHidden && relatedToHidden.dirty){
				if (relatedToHidden.dirty){relatedCaseNumber(relatedToHidden.value);}
			}
			// if (caseCat && caseCat.dirty){
				// caseCategory();
				// hyf.util.showComponent('selected_case_categ_group');
			// }
			if (!cms_main_tab1.initialized){
				FormAutoComplete.setAutoComplete('contact_info_auto','/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=',populateContactInfo,CommonOpUtil.responseMapper,appendInfo);
				FormAutoComplete.setAutoComplete('emp_info_auto','/bizflowwebmaker/cms_erlr_service/contactInfo.do?emp=',populateContactInfo,CommonOpUtil.responseMapper,appendInfo);
				FormAutoComplete.setAutoComplete('cms_primary_rep','/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=',populateContactInfo,CommonOpUtil.responseMapper,appendInfo);
				// hyf.calendar.setDateConstraint('date_customer_contacted', 'Maximum', 'Today');
				// hyf.calendar.setDateConstraint('start_date', 'Maximum', 'Today');
				// hyf.calendar.setDateConstraint('end_date', 'Maximum', 'Today');
				cms_main_tab1.initialized = true;
		   }
		  
		}
		
		// load case view will be used as event handler on case type select box. 
		// function showCaseView(caseValue) {
			// var tempGroups = cms_main_tab1.groups;
			// tempGroups.forEach(function(el,index){
				// if (el.indexOf(caseValue) > -1){
					// hyf.util.showComponent(el);	
				// }
			// });
		// }
		
		return {
			init: init,
			render: render
		};
	};

    var _initializer = window.cms_main_tab1 || (window.cms_main_tab1 = cms_main_tab1());
})(window);


function populateContactInfo(item,id){
	var validName  = (item.last_name  && item.first_name) ? true :false;
	if (id ==='contact_info_auto'){
		if (!validName){
			hyf.util.hideComponent('contact_detail_group');
		} else { 
			var name = item.last_name +','+item.first_name +' '+item.middle_name;	
			if (item.email!=='' && item.email !== undefined){
				name +=' ('+item.email+')';	
			}
			if (item.admin_code_desc ==='' || item.admin_code_desc === undefined){
				item.admin_code_desc ='';	
			}
			name = name.replace(/undefined/g,'');
			$('#contactName').text(name);                
			FormState.doAction(StateAction.changeText('contactName', name), false); // For PV binding by Ginnah
			$('#admin_code2').text(item.adminCode);
			$('#custContact').val(name);
			$('#cust_org').text(item.admin_code_desc);
			FormState.doActionNoRender(StateAction.changeText('custContact',name +','+item.adminCode+','+item.admin_code_desc+','+item.step+','+item.grade,+','+item.series+','+item.pay_plan));
			$('#contact_info_auto').val('');
			hyf.util.showComponent('contact_detail_group');	
			hyf.util.setMandatoryConstraint('contact_info_auto', false);
		}			
	} else if (id ==='emp_info_auto'){
		if (!validName){
				hyf.util.hideComponent('empl_detail_group');	
			} else {
				var name = item.last_name +','+item.first_name +' '+item.middle_name;				
				if (item.email!=='' && item.email !== undefined){
					name +=' ('+item.email+')';
				}
				if (item.admin_code_desc ==='' || item.admin_code_desc === undefined){
					item.admin_code_desc ='';	
				}
				name = name.replace(/undefined/g,'');
				$('#empName').text(name);                
				FormState.doAction(StateAction.changeText('empName', name), false); // For PV binding by Ginnah
				$('#admin_code').text(item.adminCode);
				$('#emp_org').text(item.admin_code_desc);                
				FormState.doActionNoRender(StateAction.changeText('empOrg', item.admin_code_desc)); // For PV binding by Ginnah
				var txt = item.adminCode+','+item.admin_code_desc+','+item.step+','+item.grade+','+item.series+','+item.pay_plan+','+item.position_title;
				$('#empContact').val(name+','+txt);	
				FormState.doActionNoRender(StateAction.changeText('empContact',name+','+txt));                
				$('#emp_info_auto').val('');
				hyf.util.showComponent('empl_detail_group');	
		}			
	} else if (id ==='cms_primary_rep'){
		if (validName){
			var name = item.last_name +','+item.first_name +' '+item.middle_name;
				name = name.replace(/undefined/g,'');
		if (item.email!=='' && item.email !== undefined){
				name +='('+item.email+')';
			}
			$('#cms_primary_rep').val(name);	
			FormState.doActionNoRender(StateAction.changeText('cms_primary_rep',name));
		}
	}		
}
function appendInfo(item){
		var name = item.last_name +','+item.first_name +' '+item.middle_name;
		if (item.email!=='' && item.email !== undefined){
			name +='('+item.email+')';	
		}
	return '<a role="option">' + name +'</a>'
}
function append(item){
	return '<option value="'+item.name+'">'+ item.name + ' ('+ item.email +')</option>';
}
function deleteContact(e){
	if (e.target.id ==='delete_cust'){
		$('#contactName').text('');	
		$('#admin_code2').text('');
		$('#cust_org').text('');		
		$('#phone').val('');
		$('#custContact').val(''+','+''+','+''+','+'');
		FormState.doActionNoRender(StateAction.changeText('custContact',''+','+''+','+''+','+''));
		FormState.doActionNoRender(StateAction.changeText('phone',''));
		hyf.util.setMandatoryConstraint('contact_info_auto', true);
		hyf.util.hideComponent('contact_detail_group');
	} else if (e.target.id ==='delete_emp'){
		$('#empName').text('');	
		$('#admin_code').text('');
		$('#emp_org').text('');		
		$('#phone_2').val('');		
		$('#empContact').val(''+','+''+','+''+','+'');	
		FormState.doActionNoRender(StateAction.changeText('empContact',''+','+''+','+''+','+''));
		FormState.doActionNoRender(StateAction.changeText('phone_2',''));
		hyf.util.hideComponent('empl_detail_group');		
	}
}
/*
function primaryRep(){
	var val = $('#GEN_PRIMARY_REP').val();
	if (val ==='CMS'){
		hyf.util.showComponent('cms_rep_name_group');
		hyf.util.hideComponent('non_cms_primary_group');
		hyf.util.hideComponent('non_cms_primary_2_group');
	} else {
		hyf.util.hideComponent('cms_rep_name_group');
	}
	if (val ==='NON-CMS'){
		hyf.util.showComponent('non_cms_primary_group');
		hyf.util.showComponent('non_cms_primary_2_group');
	} else {
		hyf.util.hideComponent('non_cms_primary_group');
		hyf.util.hideComponent('non_cms_primary_2_group');
	}
}
*/
/*
function investigationConducted(e){
	//var yes = (e === 'Y') ? true : false;
	if (e === 'Y'){
		hyf.util.showComponent('primary_start_end_date_group');
	} else {
		hyf.util.hideComponent('primary_start_end_date_group');
	}
}
*/
/*
function stdConduct(e){
	//var yes = (e === 'Y') ? true : false;
	if (e === 'Y'){
		hyf.util.showComponent('conduct_type_group');
	} else {
		hyf.util.hideComponent('conduct_type_group');
	}
}
*/
/*
function primaryDWCSpecialist(e){
	if (e !== 'Select One'){
		if (e && e.indexOf('(')){
		$('#initiatorName').text(e.substring(0, e.indexOf('(')));
	} else {
		$('#initiatorName').text(e);
	}
	}		
}
*/
/*
function caseCategory(){
	var selection = $('#GEN_CASE_CATEGORY').val();
	var hidenVal = $('#selected_category').val() +','+selection;
	$(selection).prop('checked', true);
	FormState.doActionNoRender(StateAction.changeText('selected_category',hidenVal));
	hyf.util.showComponent('selected_case_categ_group');
}
*/
function relatedCaseNumber(val){
	var relatedTo ='';
	if (val != undefined && val !==''){
		relatedTo = $('#related_to_case').val() +','+ val;
		$('#relatedCaseNumber').val('');
		FormState.doActionNoRender(StateAction.changeText('related_to_case',relatedTo));
		$('#relatedCaseNumber').attr('value','');
		var selction = relatedTo.split(',');
		$('#RELATED_CASE_LIST').html('');
		if (selction.length == 1){
			$('#RELATED_CASE_LIST').append('<a href="#">'+el+'</a>');
		} else {
			selction.forEach(function(el){
			if (el !==''){
			$('#RELATED_CASE_LIST').append('<a href="#">'+el+'</a><br/>');
			}
		});
		}		
	}	
}
function selectedCatChange(){
	var values = ['cat_1','cat_2','cat_3'];
		values.forEach(function(el, indx){
		if ($(el).val() === 'true'){
			$(el).show();
		} else {
			$(el).hide();
		}
	});
}