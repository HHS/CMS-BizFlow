
(function (window) {
	
	'use strict';
	
    var cms_main_tab1 = function () {
		
		var initialized = false;
		
		
		var dateFieldsPastPresent = 
		[
			'GEN_CUST_INIT_CONTACT_DT',
			'GEN_INVESTIGATE_START_DT',
			'GEN_INVESTIGATE_END_DT',
		];
		
		var dateFieldsPresentFuture = 
		[
		];
		
		var reqFieldForActivity = 
		[
			{
				actName: globalVars.actAll,
				reqFieldIds: 
				[
					'GEN_PRIMARY_SPECIALIST', 
					'GEN_CUSTOMER_NAME',
					'GEN_CASE_DESC',
					'GEN_CUST_INIT_CONTACT_DT'
				]
			},
			{
				actName: globalVars.actCaseCreation,
				reqFieldIds: 
				[
				]
			},
			{
				actName: globalVars.actCaseComplete,
				reqFieldIds: 
				[
					'GEN_CASE_CATEGORY_SEL',
					'GEN_INVESTIGATE_START_DT'
				]
			}
		];
		
		var groups = [
			'cms_rep_name_group',
			'investigation_conducted_date_group',
			'empl_detail_group',
			'customer_detail_group',
			'primary_rep_group',
			'non_cms_primary_group',
			'non_cms_primary_2_group'
		];
		
		var cmsPrimRepAutocomplete = null;
		var caseCategDropdown = null;
		
		
		
		function populateCaseCategoryOptions() {
			var caseTypeState = FormState.getState('GEN_CASE_TYPE');
			if (typeof caseTypeState == 'undefined' || caseTypeState == null) return;
			var caseTypeTxt = caseTypeState.text;
			caseTypeTxt = caseTypeTxt.replace('/', '*/*'); // replace slash to distinguish literal from path separator in lookup manager
			var optionLookupArray = LookupManager.findByLTYPE('ERLRInitialResponseCaseType[' + caseTypeTxt + ']/ERLRCaseCategory');
			if (typeof optionLookupArray == 'undefined' || optionLookupArray == null || !$.isArray(optionLookupArray)) return;
			
			var optionStr = "<option value selected>Select One</option>";
			for (var i = 0; i < optionLookupArray.length; i++) {
				optionStr += "<option value=\"" + optionLookupArray[i].ID + "\">" + optionLookupArray[i].LABEL + "</option>";
			}
			$('#GEN_CASE_CATEGORY_SEL').find('option').remove().end().append(optionStr); // refresh Case Category options
		}
		
		function controlPrimarySpecialistVisibility(){
			var elemVal = FormState.getElementValue('GEN_PRIMARY_SPECIALIST');
			var elemTxt = $('#GEN_PRIMARY_SPECIALIST option[value="' + elemVal + '"]').text();
			if (typeof elemTxt == 'undefined' || elemTxt == null || elemTxt.trim().length <= 0) return;
			// control Primary Specialist in form summary bar area
			var searchIndex = elemTxt.indexOf('(');
			if (searchIndex != null && searchIndex > -1){
				FormMain.updatePrimarySpecialistStatusBar(elemTxt.substring(0, searchIndex));
			} else {
				FormMain.updatePrimarySpecialistStatusBar(elemTxt);
			}
		}
		
		function controlCaseStatusVisibility(){
			var elemVal = FormState.getElementValue('GEN_CASE_STATUS');
			var elemTxt = $('#GEN_CASE_STATUS option[value="' + elemVal + '"]').text();
			if (typeof elemTxt == 'undefined' || elemTxt == null || elemTxt.trim().length <= 0) return;
			// control Case Status in form summary bar area
			FormMain.updateCaseStatusStatusBar(elemTxt);
		}
		
		function controlCustomerDetailVisibility(){
			var elemVal = FormState.getElementValue('GEN_CUSTOMER_NAME');
			CommonOpUtil.showHideLayoutGroup('customer_detail_group', (typeof elemVal != 'undefined' && elemVal != null && elemVal.trim().length > 0));
		}
		
		function controlEmployeeDetailVisibility(){
			var elemVal = FormState.getElementValue('GEN_EMPLOYEE_NAME');
			CommonOpUtil.showHideLayoutGroup('empl_detail_group', (typeof elemVal != 'undefined' && elemVal != null && elemVal.trim().length > 0));
		}
		
		function controlPrimaryRepVisibility(){
			var elemVal = FormState.getElementValue('GEN_PRIMARY_REP');
			CommonOpUtil.showHideLayoutGroup('cms_rep_name_group', ('CMS' === elemVal));
			CommonOpUtil.showHideLayoutGroup('non_cms_primary_group', ('NON-CMS' === elemVal));
			CommonOpUtil.showHideLayoutGroup('non_cms_primary_2_group', ('NON-CMS' === elemVal));
			if ('CMS' === elemVal && typeof cmsPrimRepAutocomplete != 'undefined' && cmsPrimRepAutocomplete != null) {
				cmsPrimRepAutocomplete.deleteAllItems();
			}
		}
		
		function controlCaseTypeVisibility() {
			var elemVal = FormState.getElementValue('GEN_CASE_TYPE');
			var elemTxt = $('#GEN_CASE_TYPE option[value="' + elemVal + '"]').text();
			CommonOpUtil.showHideLayoutGroup('case_type_perf_group', ('Performance Issue' !== elemTxt));
			populateCaseCategoryOptions();
		}
		
		function controlInvestigationVisibility() {
			var elemVal = FormState.getElementValue('GEN_INVESTIGATION');
			CommonOpUtil.showHideLayoutGroup('primary_start_end_date_group', ('Yes' === elemVal));
		}
		
		function controlStdConductVisibility() {
			var elemVal = FormState.getElementValue('GEN_STD_CONDUCT');
			CommonOpUtil.showHideLayoutGroup('conduct_type_group', ('Yes' === elemVal));
		}
		
		function controlContactInfoVisibility(id) {
			if (typeof id == 'undefined' || id == null || id.trim().length <= 0) return;
			//item.firstName + ',' + item.middleName + ',' + item.lastName + ',' + item.email + ',' + item.adminCode + ',' + item.adminCodeDesc;
			var elemVal = FormState.getElementValue(id);
			if (typeof elemVal == 'undefined' || elemVal == null || elemVal.trim().length <= 0) return;
			var valArray = elemVal.split('_,_');
			if (valArray != null && $.isArray(valArray) && valArray.length > 0) {
				var item = {
					firstName:     valArray[0],
					middleName:    valArray[1],
					lastName:      valArray[2],
					email:         valArray[3],
					adminCode:     valArray[4],
					adminCodeDesc: valArray[5],
					positionTitle: valArray[6],
					payPlan:       valArray[7],
					series:        valArray[8],
					grade:         valArray[9],
					step:          valArray[10],
					wgiDueDate:    valArray[11]
				};
				selectionCallBackForContactInfo(item, id + '_SEARCH');
			}
		}
	
		function initVisibility() {
			controlPrimarySpecialistVisibility();
			controlCaseStatusVisibility();
			controlCustomerDetailVisibility();
			controlEmployeeDetailVisibility();
			controlPrimaryRepVisibility();
			controlCaseTypeVisibility();
			controlInvestigationVisibility();
			controlStdConductVisibility();
			controlContactInfoVisibility('GEN_CUSTOMER');
			controlContactInfoVisibility('GEN_EMPLOYEE');
		}
		
		
		
		
		function setSelectElemValue(selElem) {
			if ( typeof selElem == 'undefined' || selElem == null 
					|| typeof selElem.id == 'undefined' || selElem.id == null 
					|| typeof selElem.options == 'undefined' || selElem.options == null ) {
				return;
			}
			var selectedVal = selElem.options[selElem.options.selectedIndex].value;
			var selectedTxt = selElem.options[selElem.options.selectedIndex].text;
			FormState.updateSelectValue(selElem.id, selectedVal, selectedTxt);
		}

		function initEventHandlers() {
			$('#GEN_PRIMARY_SPECIALIST').on('change', function(e) {
				setSelectElemValue(e.target);
				controlPrimarySpecialistVisibility();
			});
			
			$('#GEN_CASE_STATUS').on('change', function(e) {
				setSelectElemValue(e.target);
				controlCaseStatusVisibility();
			});
			
			$('#GEN_PRIMARY_REP').on('change', function(e) {
				setSelectElemValue(e.target);
				controlPrimaryRepVisibility();
			});
			
			$('#GEN_CASE_TYPE').on('change', function(e) {
				setSelectElemValue(e.target);
				if (typeof caseCategDropdown != 'undefined' && caseCategDropdown != null) {
					caseCategDropdown.deleteAll();
				}
				populateCaseCategoryOptions();
				controlCaseTypeVisibility();
				FormMain.controlTabVisibility();
				FormMain.showHideAppealTab(false);
			});
			
			$('#GEN_INVESTIGATION').on('change', function(e) {
				setSelectElemValue(e.target);
				controlInvestigationVisibility();
			});
			
			$('#GEN_STD_CONDUCT').on('change', function(e) {
				setSelectElemValue(e.target);
				controlStdConductVisibility();
			});
			
			$('#btnDeleteCustomer').on('click', function(e) {
				$('#GEN_CUSTOMER').val('');
				$('#GEN_CUSTOMER_PHONE').val('');
				$('#GEN_CUSTOMER_NAME').text('');
				$('#GEN_CUSTOMER_ADMIN_CD').text('');
				$('#GEN_CUSTOMER_ADMIN_CD_DESC').text('');
				FormState.updateObjectValue('GEN_CUSTOMER', '');
				FormState.updateTextValue('GEN_CUSTOMER_PHONE', '');
				FormState.updateVariableValue('GEN_CUSTOMER_NAME', '');
				FormState.updateVariableValue('GEN_CUSTOMER_ADMIN_CD', '');
				hyf.util.hideComponent('customer_detail_group');
				hyf.util.setMandatoryConstraint('GEN_CUSTOMER_SEARCH', true);
			});
			
			$('#btnDeleteEmployee').on('click', function(e) {
				$('#GEN_EMPLOYEE').val('');
				$('#GEN_EMPLOYEE_PHONE').val('');
				$('#GEN_EMPLOYEE_NAME').text('');
				$('#GEN_EMPLOYEE_ADMIN_CD').text('');
				$('#GEN_EMPLOYEE_ADMIN_CD_DESC').text('');
				FormState.updateObjectValue('GEN_EMPLOYEE', '');
				FormState.updateTextValue('GEN_EMPLOYEE_PHONE', '');
				FormState.updateVariableValue('GEN_EMPLOYEE_NAME', '');
				FormState.updateVariableValue('GEN_EMPLOYEE_ADMIN_CD', '');
				hyf.util.hideComponent('empl_detail_group');
			});
			
		}

		
		function selectionCallBackForContactInfo(items, id) {
			var item = null;
			if (typeof items != 'undefined' && items != null) {
				if($.isArray(items) && items.length > 0) {
					item = items[0];
				} else {
					item = items;
				}
			}
			
			var idPfx = id.substring(0, id.lastIndexOf('_SEARCH'));
			// set id of elements that need to be populated
			// NOTE: make sure the related element id conforms to the convention
			var storageElemId     = idPfx;
			var nameElemId        = idPfx + '_NAME';
			var adminCdElemId     = idPfx + '_ADMIN_CD';
			var adminCdDescElemId = idPfx + '_ADMIN_CD_DESC';
			// set id for the display group containing related fields
			// NOTE: make sure the container group id conforms to the convention
			var dispGroupId = $('#'+storageElemId).parents('[id$="_detail_group"]')[0].id;
			
			var validName = (item != null && item.lastName && item.firstName) ? true : false;
			if (!validName) {
				hyf.util.hideComponent(dispGroupId);
			} else {
				var name = item.lastName + ', ' + item.firstName + ' ' + item.middleName;
				var nameDisp = name;
				if (typeof item.email != 'undefined' && item.email != null && item.email.length > 0) {
					nameDisp += ' (' + item.email + ')';
				}
				if (typeof item.adminCodeDesc == 'undefined' || item.adminCodeDesc == null || item.adminCodeDesc.length <= 0) {
					item.adminCodeDesc = '';
				}
				name = name.replace(/undefined/g, '');
				nameDisp = nameDisp.replace(/undefined/g, '');
				var delimit = '_,_';
				var storedData = item.firstName + delimit + item.middleName + delimit + item.lastName + delimit + item.email + delimit + item.adminCode + delimit + item.adminCodeDesc;
				if (item.positionTitle) {
					storedData += delimit + item.positionTitle + delimit + item.payPlan + delimit + item.series + delimit + item.grade + delimit + item.step;
				}
				if (item.wgiDueDate) {
					storedData += delimit + item.wgiDueDate;
				}
				$('#' + storageElemId).val(storedData);
				$('#' + nameElemId).text(nameDisp);
				$('#' + adminCdElemId).text(item.adminCode);
				$('#' + adminCdDescElemId).text(item.adminCodeDesc);
				$('#' + id).val('');  // clear search input field
				FormState.updateObjectValue(storageElemId, storedData, true);
				FormState.updateVariableValue(nameElemId, name, false);
				FormState.updateVariableValue(adminCdElemId, item.adminCode, false);
				hyf.util.showComponent(dispGroupId);
				hyf.util.setMandatoryConstraint(id, false);
			}
		}
		
		function responseProcessorForContactInfo(xmlResponse) {
			var data = $('record', xmlResponse).map(function(){
				return {
					firstName:     $('FIRST_NAME', this).text(),
					middleName:    $('MIDDLE_NAME', this).text(),
					lastName:      $('LAST_NAME', this).text(),
					email:         $('EMAIL_ADDR', this).text(),
					adminCode:     $('ORG_CD', this).text(),
					adminCodeDesc: $('ADMIN_CODE_DESC', this).text(),
					positionTitle: $('POSITION_TITLE_NAME', this).text(),
					payPlan:       $('PAY_PLAN', this).text(),
					series:        $('SERIES', this).text(),
					grade:         $('GRADE', this).text(),
					step:          $('STEP', this).text(),
					wgiDueDate:    $('GVT_WGI_DUE_DATE', this).text()
				};
			}).get();
			return data;
		}
		
		function appenderForContactInfo(item) {
			var data = item.lastName + ', ' + item.firstName + ' ' + item.middleName;
			if (typeof item.email != 'undefined' && item.email != null && item.email.length > 0) {
				data += ' (' + item.email + ')';
			}
			return '<a role="option">' + data + '</a>';
		}
		
		
		function mapFunctionCmsRep(context) {
			return {
				id:             $("MID", context).text(),
				participantId:  "[" + $("MTYPE", context).text() + "]" + $("MID", context).text(),
				name:           $("NAME", context).text(),
				email:          $("EMAIL", context).text(),
				org:            $("DEPTNAME", context).text(),
				title:          $("JOBTITLENAME", context).text()
			};
		}

		function getSelectionLabelCmsRep(item) {
			var label = item.name + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '') + ' ' + item.org;
			if (item.title) {
				label += '/' + item.title;
			}

			return label;
		}

		function getCandidateLabelCmsRep(item) {
			return item.name + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '');
		}

		function getItemIDCmsRep(item) {
			return item.id;
		}
		
		function setupCustomWidget() {
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_main_tab1::setupCustomWidget START');
			
			var activityName = ActivityManager.getActivityName();
			
			// GEN_CUSTOMER
			FormAutoComplete.setAutoComplete(
				'GEN_CUSTOMER_SEARCH'
				, '/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust='
				, selectionCallBackForContactInfo
				, responseProcessorForContactInfo
				, appenderForContactInfo
			);
			
			// GEN_EMPLOYEE
			FormAutoComplete.setAutoComplete(
				'GEN_EMPLOYEE_SEARCH'
				, '/bizflowwebmaker/cms_erlr_service/contactInfo.do?emp='
				, selectionCallBackForContactInfo
				, responseProcessorForContactInfo
				, appenderForContactInfo
			);
			
			// GEN_CMS_PRIMARY_REP
            var optionCmsPrimRep = {
                id: 'GEN_CMS_PRIMARY_REP_SEARCH',
                baseURL: '/bizflowwebmaker/StratCon_AUT',
                targetURL: '/bizflowwebmaker/cms_erlr_service/searchParticipants.do?g=DWC&q=',
                minLength: 2,
                minSelectionCount: 0,
                maxSelectionCount: 1,

                mapFunction: mapFunctionCmsRep,
                getSelectionLabel: getSelectionLabelCmsRep,
                getCandidateLabel: getCandidateLabelCmsRep,
                getItemID: getItemIDCmsRep,
                setDataToForm: function (values) {
                    FormState.updateObjectValue('GEN_CMS_PRIMARY_REP', values);
                },

                // initialize
                initialItems: FormState.getElementArrayValue('GEN_CMS_PRIMARY_REP', [])
            };
			cmsPrimRepAutocomplete = FormAutoComplete.makeAutoCompletion(optionCmsPrimRep);
			
			//TODO: Related Case (GEN_RELATED_TO_CASE) autocomplete implementation
			
			// set up Case Category dropdown as multi-select widget
			var caseCategMinSelection = (activityName === 'Complete Case') ? 1 : 0;
			var caseCategoryInitialData = [];
			var caseCategIdString = FormState.getElementValue('GEN_CASE_CATEGORY');
			var caseCategIds = ((caseCategIdString != null && caseCategIdString.length > 0) ? caseCategIdString.split(',') : []);
			var count = caseCategIds.length;
			for (var index = 0; index < count; index++) {
				var itemLabel = $('#GEN_CASE_CATEGORY_SEL option[value="' + caseCategIds[index] + '"]').text();
				caseCategoryInitialData.push({
					id: caseCategIds[index],
					label: itemLabel
				});
			}
			var caseCategDropdownOption = {
				id: 'GEN_CASE_CATEGORY',
				tabindex: 0,
				minSelectionCount: caseCategMinSelection,
				maxSelectionCount: 10, 
				getSelectionLabel: function(item) {
					return item.label
				},
				getItemID: function(item) {
					return item.id;
				},
				initialItems: caseCategoryInitialData,
				setDataToForm: function(values) {
					if (typeof values == 'undefined') return;
					var selectedIds = '';
					if (values != null && $.isArray(values)) {
						selectedIds = values.reduce(function(accumulator, currentValue, currentIndex, array) {
							return (accumulator && accumulator.length > 0) ? accumulator + ',' + currentValue.id : currentValue.id;
						}, '');
					}
					FormState.updateObjectValue('GEN_CASE_CATEGORY', selectedIds);
				}
			};
			caseCategDropdown = MultiSelectDropdown.setupMultiSelectDropdown(caseCategDropdownOption);
			
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_main_tab1::setupCustomWidget END');
		}
		
		
		function init() {
			
			//-----------------------------------
			// visibility configuration
			//-----------------------------------
			//layout_group.forEach(function(item,index){
			//	hyf.util.hideComponent(item);
			//});
			initVisibility();
			
			//-----------------------------------
			// validation configuration
			//-----------------------------------
			dateFieldsPastPresent.forEach(function(item){
				hyf.calendar.setDateConstraint(item, 'Maximum', 'Today');
			});
			//dateFieldsPresentFuture.forEach(function(item){
			//	hyf.calendar.setDateConstraint(item, 'Minimum', 'Today');
			//});
			CommonOpUtil.dynamicMandatory(reqFieldForActivity);
			
			//-----------------------------------
			// event handler configuration
			//-----------------------------------
			initEventHandlers();
			
			//-----------------------------------
			// custom widget configuration
			//-----------------------------------
			setupCustomWidget();
		
			initialized = true;
		}
		
		function render() {
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_main_tab1::render START');
			
			/*
			var relatedTo = FormState.getState('relatedCaseNumber');
			var relatedToHidden = FormState.getState('related_to_case');
			if (!cms_main_tab1.initialized && (relatedToHidden && relatedToHidden.dirty)){
				var parse = (relatedToHidden.value.indexOf(',') > -1) ? relatedToHidden.value.split(',') : [relatedToHidden.value];
				parse.forEach(function(el, indx){
					if (el !='' && el !== undefined){
					$('#RELATED_CASE_LIST').append('<br/><a href="#" id="'+el+'">'+el+'</a>');
					}
				});
			}
			if ((relatedTo && relatedTo.dirty)){
				if (relatedTo.dirty){relatedCaseNumber(relatedTo.value);}
			}
			if ( relatedToHidden && relatedToHidden.dirty){
				if (relatedToHidden.dirty){relatedCaseNumber(relatedToHidden.value);}
			}
			*/
			
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_main_tab1::render END');
		}
		
		return {
			init: init,
			render: render
		};
	};

    var _initializer = window.cms_main_tab1 || (window.cms_main_tab1 = cms_main_tab1());
})(window);


function relatedCaseNumber(val){
	var relatedTo ='';
	if (val != undefined && val !==''){
		relatedTo = $('#GEN_RELATED_TO_CASE').val() +','+ val;
		$('#relatedCaseNumber').val('');
		FormState.doActionNoRender(StateAction.changeText('GEN_RELATED_TO_CASE',relatedTo));
		$('#relatedCaseNumber').attr('value','');
		var selction = relatedTo.split(',');
		$('#RELATED_CASE_LIST').html('');
		if (selction.length == 1){
			$('#RELATED_CASE_LIST').append('<a href="#">'+el+'</a>');
		} else {
			selction.forEach(function(el){
			if (el !==''){
			$('#RELATED_CASE_LIST').append('<a href="#">'+el+'</a><br/>');
			}
		});
		}		
	}	
}
