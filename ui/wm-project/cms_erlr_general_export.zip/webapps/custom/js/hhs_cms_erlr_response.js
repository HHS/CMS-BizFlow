
(function (window) {
	
	'use strict';
	
    var cms_main_tab1 = function () {
		
		var initialized = false;
		
		
		var dateFieldsPastPresent = 
		[
			'GEN_CUST_INIT_CONTACT_DT',
			'GEN_INVESTIGATE_START_DT',
			'GEN_INVESTIGATE_END_DT',
		];
		
		var dateFieldsPresentFuture = 
		[
		];
		
		var reqFieldForActivity = 
		[
			{
				actName: globalVars.actAll,
				reqFieldIds: 
				[
					'GEN_PRIMARY_SPECIALIST', 
					'GEN_CASE_DESC',
					'GEN_CUST_INIT_CONTACT_DT'
				]
			},
			{
				actName: globalVars.actCaseCreation,
				reqFieldIds: 
				[
				]
			},
			{
				actName: globalVars.actCaseComplete,
				reqFieldIds: 
				[
				]
			}
		];
		
		var groups = [
			'cms_rep_name_group',
			'investigation_conducted_date_group',
			'empl_detail_group',
			'customer_detail_group',
			'primary_rep_group',
			'non_cms_primary_group',
			'non_cms_primary_2_group',
			'selected_case_categ_group'
		];
		
		
		function controlPrimarySpecialistVisibility(){
			var elemVal = FormState.getElementValue('GEN_PRIMARY_SPECIALIST');
			var elemTxt = $('#GEN_PRIMARY_SPECIALIST option[value="' + elemVal + '"]').text();
			if (typeof elemTxt == 'undefined' || elemTxt == null || elemTxt.trim().length <= 0) return;
			// control Primary Specialist in form summary bar area
			var searchIndex = elemTxt.indexOf('(');
			if (searchIndex != null && searchIndex > -1){
				FormMain.updatePrimarySpecialistStatusBar(elemTxt.substring(0, searchIndex));
			} else {
				FormMain.updatePrimarySpecialistStatusBar(elemTxt);
			}
		}
		
		function controlCaseStatusVisibility(){
			var elemVal = FormState.getElementValue('GEN_CASE_STATUS');
			var elemTxt = $('#GEN_CASE_STATUS option[value="' + elemVal + '"]').text();
			if (typeof elemTxt == 'undefined' || elemTxt == null || elemTxt.trim().length <= 0) return;
			// control Case Status in form summary bar area
			FormMain.updateCaseStatusStatusBar(elemTxt);
		}
		
		function controlCustomerDetailVisibility(){
			var elemVal = FormState.getElementValue('GEN_CUSTOMER_NAME');
			if (typeof elemVal != 'undefined' && elemVal != null && elemVal.trim().length > 0) {
				hyf.util.showComponent('customer_detail_group');
			} else {
				hyf.util.hideComponent('customer_detail_group');
			}
		}
		
		function controlEmployeeDetailVisibility(){
			var elemVal = FormState.getElementValue('GEN_EMPLOYEE_NAME');
			if (typeof elemVal != 'undefined' && elemVal != null && elemVal.trim().length > 0) {
				hyf.util.showComponent('empl_detail_group');
			} else {
				hyf.util.hideComponent('empl_detail_group');
			}
		}
		
		function controlPrimaryRepVisibility(){
			var elemVal = FormState.getElementValue('GEN_PRIMARY_REP');
			if ('CMS' === elemVal) {
				hyf.util.showComponent('cms_rep_name_group');
			} else {
				hyf.util.hideComponent('cms_rep_name_group');
			}
			
			if ('NON-CMS' === elemVal) {
				hyf.util.showComponent('non_cms_primary_group');
				hyf.util.showComponent('non_cms_primary_2_group');
			} else {
				hyf.util.hideComponent('non_cms_primary_group');
				hyf.util.hideComponent('non_cms_primary_2_group');
			}
		}
		
		function controlCaseTypeVisibility() {
			var elemVal = FormState.getElementValue('GEN_CASE_TYPE');
			var elemTxt = $('#GEN_CASE_TYPE option[value="' + elemVal + '"]').text();
			if ('Performance Issue' === elemTxt){
				hyf.util.hideComponent('case_type_perf_group');
			} else {
				hyf.util.showComponent('case_type_perf_group');
			}
		}
		
		function controlInvestigationVisibility() {
			var elemVal = FormState.getElementValue('GEN_INVESTIGATION');
			if ('Yes' === elemVal){
				hyf.util.showComponent('primary_start_end_date_group');
			} else {
				hyf.util.hideComponent('primary_start_end_date_group');
			}
		}
		
		function controlStdConductVisibility() {
			var elemVal = FormState.getElementValue('GEN_STD_CONDUCT');
			if ('Yes' === elemVal){
				hyf.util.showComponent('conduct_type_group');
			} else {
				hyf.util.hideComponent('conduct_type_group');
			}
		}
		
		function controlContactInfoVisibility(id) {
			if (typeof id == 'undefined' || id == null || id.trim().length <= 0) return;
			//item.firstName + ',' + item.middleName + ',' + item.lastName + ',' + item.email + ',' + item.adminCode + ',' + item.adminCodeDesc;
			var elemVal = FormState.getElementValue(id);
			if (typeof elemVal == 'undefined' || elemVal == null || elemVal.trim().length <= 0) return;
			var valArray = elemVal.split(',');
			if (valArray != null && $.isArray(valArray) && valArray.length > 0) {
				var item = {
					firstName:     valArray[0],
					middleName:    valArray[1],
					lastName:      valArray[2],
					email:         valArray[3],
					adminCode:     valArray[4],
					adminCodeDesc: valArray[5]
				};
				selectionCallBackForContactInfo(item, id + '_SEARCH');
			}
		}
	
		function initVisibility() {
			controlPrimarySpecialistVisibility();
			controlCaseStatusVisibility();
			controlCustomerDetailVisibility();
			controlEmployeeDetailVisibility();
			controlPrimaryRepVisibility();
			controlCaseTypeVisibility();
			controlInvestigationVisibility();
			controlStdConductVisibility();
			controlContactInfoVisibility('GEN_CUSTOMER');
			controlContactInfoVisibility('GEN_EMPLOYEE');
		}

		function initEventHandlers() {
			$('#GEN_PRIMARY_SPECIALIST').on('change', function(e) {
				var target = e.target;
				var elemVal = target.options[target.options.selectedIndex].value;
				var elemTxt = target.options[target.options.selectedIndex].text;
				FormState.updateSelectValue('GEN_PRIMARY_SPECIALIST', elemVal, elemTxt);
				controlPrimarySpecialistVisibility();
			});
			
			$('#GEN_CASE_STATUS').on('change', function(e) {
				var target = e.target;
				var elemVal = target.options[target.options.selectedIndex].value;
				var elemTxt = target.options[target.options.selectedIndex].text;
				FormState.updateSelectValue('GEN_CASE_STATUS', elemVal, elemTxt);
				controlCaseStatusVisibility();
			});
			
			$('#GEN_PRIMARY_REP').on('change', function(e) {
				var target = e.target;
				var elemVal = target.options[target.options.selectedIndex].value;
				var elemTxt = target.options[target.options.selectedIndex].text;
				FormState.updateSelectValue('GEN_PRIMARY_REP', elemVal, elemTxt);
				controlPrimaryRepVisibility();
			});
			
			$('#GEN_CASE_TYPE').on('change', function(e) {
				var target = e.target;
				var elemVal = target.options[target.options.selectedIndex].value;
				var elemTxt = target.options[target.options.selectedIndex].text;
				FormState.updateSelectValue('GEN_CASE_TYPE', elemVal, elemTxt);
				controlCaseTypeVisibility();
				FormMain.controlTabVisibility();
			});
			
			$('#GEN_INVESTIGATION').on('change', function(e) {
				var target = e.target;
				var elemVal = target.options[target.options.selectedIndex].value;
				var elemTxt = target.options[target.options.selectedIndex].text;
				FormState.updateSelectValue('GEN_INVESTIGATION', elemVal, elemTxt);
				controlInvestigationVisibility();
			});
			
			$('#GEN_STD_CONDUCT').on('change', function(e) {
				var target = e.target;
				var elemVal = target.options[target.options.selectedIndex].value;
				var elemTxt = target.options[target.options.selectedIndex].text;
				FormState.updateSelectValue('GEN_STD_CONDUCT', elemVal, elemTxt);
				controlStdConductVisibility();
			});
			
			$('#btnDeleteCustomer').on('click', function(e) {
				$('#GEN_CUSTOMER').val('');
				$('#GEN_CUSTOMER_PHONE').val('');
				$('#GEN_CUSTOMER_NAME').text('');
				$('#GEN_CUSTOMER_ADMIN_CD').text('');
				$('#GEN_CUSTOMER_ADMIN_CD_DESC').text('');
				FormState.updateTextValue('GEN_CUSTOMER', '');
				FormState.updateTextValue('GEN_CUSTOMER_PHONE', '');
				FormState.updateVariableValue('GEN_CUSTOMER_NAME', '');
				FormState.updateVariableValue('GEN_CUSTOMER_ADMIN_CD', '');
				hyf.util.hideComponent('customer_detail_group');
				hyf.util.setMandatoryConstraint('GEN_CUSTOMER_SEARCH', true);
			});
			
			$('#btnDeleteEmployee').on('click', function(e) {
				$('#GEN_EMPLOYEE').val('');
				$('#GEN_EMPLOYEE_PHONE').val('');
				$('#GEN_EMPLOYEE_NAME').text('');
				$('#GEN_EMPLOYEE_ADMIN_CD').text('');
				$('#GEN_EMPLOYEE_ADMIN_CD_DESC').text('');
				FormState.updateTextValue('GEN_EMPLOYEE', '');
				FormState.updateTextValue('GEN_EMPLOYEE_PHONE', '');
				FormState.updateVariableValue('GEN_EMPLOYEE_NAME', '');
				FormState.updateVariableValue('GEN_EMPLOYEE_ADMIN_CD', '');
				hyf.util.hideComponent('empl_detail_group');
			});
			
		}

		
		function selectionCallBackForContactInfo(items, id) {
			var item = null;
			if (typeof items != 'undefined' && items != null) {
				if($.isArray(items) && items.length > 0) {
					item = items[0];
				} else {
					item = items;
				}
			}
			
			var idPfx = id.substring(0, id.lastIndexOf('_SEARCH'));
			// set id of elements that need to be populated
			// NOTE: make sure the related element id conforms to the convention
			var storageElemId     = idPfx;
			var nameElemId        = idPfx + '_NAME';
			var adminCdElemId     = idPfx + '_ADMIN_CD';
			var adminCdDescElemId = idPfx + '_ADMIN_CD_DESC';
			// set id for the display group containing related fields
			// NOTE: make sure the container group id conforms to the convention
			var dispGroupId = $('#'+storageElemId).parents('[id$="_detail_group"]')[0].id;
			
			var validName = (item != null && item.lastName && item.firstName) ? true : false;
			if (!validName) {
				hyf.util.hideComponent(dispGroupId);
			} else {
				var name = item.lastName + ', ' + item.firstName + ' ' + item.middleName;
				var nameDisp = name;
				if (typeof item.email != 'undefined' && item.email != null && item.email.length > 0) {
					nameDisp += ' (' + item.email + ')';
				}
				if (typeof item.adminCodeDesc == 'undefined' || item.adminCodeDesc == null || item.adminCodeDesc.length <= 0) {
					item.adminCodeDesc = '';
				}
				name = name.replace(/undefined/g, '');
				nameDisp = nameDisp.replace(/undefined/g, '');
				var storedData = item.firstName + ',' + item.middleName + ',' + item.lastName + ',' + item.email + ',' + item.adminCode + ',' + item.adminCodeDesc;
				if (item.positionTitle) {
					storedData += ',' + item.positionTitle + ',' + item.payPlan + ',' + item.series + ',' + item.grade + ',' + item.step;
				}
				$('#' + storageElemId).val(storedData);
				$('#' + nameElemId).text(nameDisp);
				$('#' + adminCdElemId).text(item.adminCode);
				$('#' + adminCdDescElemId).text(item.adminCodeDesc);
				$('#' + id).val('');  // clear search input field
				//FormState.updateTextValue(storageElemId, storedData, false);
				//FormState.updateVariableValue(nameElemId, name, false);
				//FormState.updateVariableValue(adminCdElemId, item.adminCode, false);
				hyf.util.showComponent(dispGroupId);
				hyf.util.setMandatoryConstraint(id, false);
			}
		}
		
		function responseProcessorForContactInfo(xmlResponse) {
			var data = $('record', xmlResponse).map(function(){
				return {
					firstName:     $('FIRST_NAME', this).text(),
					middleName:    $('MIDDLE_NAME', this).text(),
					lastName:      $('LAST_NAME', this).text(),
					email:         $('EMAIL_ADDR', this).text(),
					adminCode:     $('ORG_CD', this).text(),
					adminCodeDesc: $('ADMIN_CODE_DESC', this).text(),
					positionTitle: $('POSITION_TITLE_NAME', this).text(),
					payPlan:       $('PAY_PLAN', this).text(),
					series:        $('SERIES', this).text(),
					grade:         $('GRADE', this).text(),
					step:          $('STEP', this).text()
				};
			}).get();
			return data;
		}
		
		function appenderForContactInfo(item) {
			var data = item.lastName + ', ' + item.firstName + ' ' + item.middleName;
			if (typeof item.email != 'undefined' && item.email != null && item.email.length > 0) {
				data += ' (' + item.email + ')';
			}
			return '<a role="option">' + data + '</a>';
		}
		
		
		function mapFunctionCmsRep(context) {
			return {
				id:             $("MID", context).text(),
				participantId:  "[" + $("MTYPE", context).text() + "]" + $("MID", context).text(),
				name:           $("NAME", context).text(),
				email:          $("EMAIL", context).text(),
				org:            $("DEPTNAME", context).text(),
				title:          $("JOBTITLENAME", context).text()
			};
		}

		function getSelectionLabelCmsRep(item) {
			var label = item.name + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '') + ' ' + item.org;
			if (item.title) {
				label += '/' + item.title;
			}

			return label;
		}

		function getCandidateLabelCmsRep(item) {
			return item.name + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '');
		}

		function getItemIDCmsRep(item) {
			return item.id;
		}
		
		function setupCustomWidget() {
			FormAutoComplete.setAutoComplete(
				'GEN_CUSTOMER_SEARCH'
				, '/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust='
				, selectionCallBackForContactInfo
				, responseProcessorForContactInfo
				, appenderForContactInfo
			);
			
			FormAutoComplete.setAutoComplete(
				'GEN_EMPLOYEE_SEARCH'
				, '/bizflowwebmaker/cms_erlr_service/contactInfo.do?emp='
				, selectionCallBackForContactInfo
				, responseProcessorForContactInfo
				, appenderForContactInfo
			);
			
			
			//GEN_CMS_PRIMARY_REP
            var optionCmsPrimRep = {
                id: 'GEN_CMS_PRIMARY_REP_SEARCH',
                baseURL: '/bizflowwebmaker/StratCon_AUT',
                targetURL: '/bizflowwebmaker/cms_erlr_service/searchParticipants.do?g=DWC&q=',
                minLength: 2,
                minSelectionCount: 0,
                maxSelectionCount: 1,

                mapFunction: mapFunctionCmsRep,
                getSelectionLabel: getSelectionLabelCmsRep,
                getCandidateLabel: getCandidateLabelCmsRep,
                getItemID: getItemIDCmsRep,
                setDataToForm: function (values) {
                    FormState.updateObjectValue('GEN_CMS_PRIMARY_REP', values);
                },

                // initialize
                initialItems: FormState.getElementArrayValue('GEN_CMS_PRIMARY_REP', [])
            };
			FormAutoComplete.makeAutoCompletion(optionCmsPrimRep);
			
			//TODO: Related Case (GEN_RELATED_TO_CASE) autocomplete implementation
			
			//TODO: Case Category multi-select implementation
			
		}
		
		
		function init() {
			//cms_main_tab1.groups.forEach(function(el,index){
			//	hyf.util.hideComponent(el);
			//});
			//$('#cat_1,#cat_2,#cat_3').on('click',selectedCatChange);
			
			
			//-----------------------------------
			// visibility configuration
			//-----------------------------------
			//layout_group.forEach(function(item,index){
			//	hyf.util.hideComponent(item);
			//});
			initVisibility();
			
			//-----------------------------------
			// validation configuration
			//-----------------------------------
			dateFieldsPastPresent.forEach(function(item){
				hyf.calendar.setDateConstraint(item, 'Maximum', 'Today');
			});
			//dateFieldsPresentFuture.forEach(function(item){
			//	hyf.calendar.setDateConstraint(item, 'Minimum', 'Today');
			//});
			CommonOpUtil.dynamicMandatory(reqFieldForActivity);
			
			//-----------------------------------
			// event handler configuration
			//-----------------------------------
			initEventHandlers();
			
			//-----------------------------------
			// custom widget configuration
			//-----------------------------------
			setupCustomWidget();
		
			initialized = true;
		}
		
		function render() {
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_main_tab1::render START');
			
			/*
			var relatedTo = FormState.getState('relatedCaseNumber');
			var relatedToHidden = FormState.getState('related_to_case');
			if (!cms_main_tab1.initialized && (relatedToHidden && relatedToHidden.dirty)){
				var parse = (relatedToHidden.value.indexOf(',') > -1) ? relatedToHidden.value.split(',') : [relatedToHidden.value];
				parse.forEach(function(el, indx){
					if (el !='' && el !== undefined){
					$('#RELATED_CASE_LIST').append('<br/><a href="#" id="'+el+'">'+el+'</a>');
					}
				});
			}
			if ((relatedTo && relatedTo.dirty)){
				if (relatedTo.dirty){relatedCaseNumber(relatedTo.value);}
			}
			if ( relatedToHidden && relatedToHidden.dirty){
				if (relatedToHidden.dirty){relatedCaseNumber(relatedToHidden.value);}
			}
			// if (caseCat && caseCat.dirty){
				// caseCategory();
				// hyf.util.showComponent('selected_case_categ_group');
			// }
			if (!cms_main_tab1.initialized){
				FormAutoComplete.setAutoComplete('cms_primary_rep','/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=',populateContactInfo,CommonOpUtil.responseMapper,appendInfo);
			}
			*/
			
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_main_tab1::render END');
		}
		
		return {
			init: init,
			render: render
		};
	};

    var _initializer = window.cms_main_tab1 || (window.cms_main_tab1 = cms_main_tab1());
})(window);


/*
function caseCategory(){
	var selection = $('#GEN_CASE_CATEGORY').val();
	var hidenVal = $('#selected_category').val() +','+selection;
	$(selection).prop('checked', true);
	FormState.doActionNoRender(StateAction.changeText('selected_category',hidenVal));
	hyf.util.showComponent('selected_case_categ_group');
}
*/
function relatedCaseNumber(val){
	var relatedTo ='';
	if (val != undefined && val !==''){
		relatedTo = $('#GEN_RELATED_TO_CASE').val() +','+ val;
		$('#relatedCaseNumber').val('');
		FormState.doActionNoRender(StateAction.changeText('GEN_RELATED_TO_CASE',relatedTo));
		$('#relatedCaseNumber').attr('value','');
		var selction = relatedTo.split(',');
		$('#RELATED_CASE_LIST').html('');
		if (selction.length == 1){
			$('#RELATED_CASE_LIST').append('<a href="#">'+el+'</a>');
		} else {
			selction.forEach(function(el){
			if (el !==''){
			$('#RELATED_CASE_LIST').append('<a href="#">'+el+'</a><br/>');
			}
		});
		}		
	}	
}
function selectedCatChange(){
	var values = ['cat_1','cat_2','cat_3'];
		values.forEach(function(el, indx){
		if ($(el).val() === 'true'){
			$(el).show();
		} else {
			$(el).hide();
		}
	});
}