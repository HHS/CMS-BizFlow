(function (window) {
    var cms_incentives_pca_approval = function () {
        var _initialized = false;

        function setVisibilityAsRequireAdminApproval(requireAdminApproval) {
            requireAdminApproval = requireAdminApproval || FormState.getElementValue("requireAdminApproval");
            var isRequireAdminApproval = "Yes" === requireAdminApproval;

            hyf.util.setComponentVisibility("approveTABGCheck_group", !isRequireAdminApproval);
            hyf.util.setComponentVisibility("approveADMCheck_group", isRequireAdminApproval);
        }

        function onRequireAdminApprovalChanged(requireAdminApproval) {
            setVisibilityAsRequireAdminApproval(requireAdminApproval);
        }

        function setApproverAndApproveDate(approverEleId, approveDateEleId, checked) {
            var currentUserName = "";
            var currentDate = "";
            if (checked) {
                currentUserName = myInfo.getMyName();
                currentDate = FormUtility.getDateString(false, "mm/dd/yyyy", new Date());
            }

            $("#" + approverEleId).val(currentUserName);
            $("#" + approveDateEleId).val(currentDate);

            FormState.updateTextValue(approverEleId, currentUserName, false);
            FormState.updateDateValue(approveDateEleId, currentDate, false);
        }

        function initEventHandlers() {
            $('#approveTABGCheck').on('change', function (e) {
                var target = e.target;
                setApproverAndApproveDate("approveTABG", "approveTABGDate", target.checked);
            });
            $('#approveADMCheck').on('change', function (e) {
                var target = e.target;
                setApproverAndApproveDate("approveADM", "approveADMDate", target.checked);
            });
        }

        function initComponents() {
            hyf.util.disableComponent("approveTABGDate");
            hyf.util.disableComponent("approveADMDate");

            var isTABG = accessControl.isDesignatedTABG();
            hyf.util.setComponentUsability("approveTABGCheck", isTABG);
            hyf.util.setMandatoryConstraint("approveTABGCheck", isTABG);

            var isAdmin = accessControl.isDesignatedOffAdmin();
            hyf.util.setComponentUsability("approveADMCheck", isAdmin);
            hyf.util.setMandatoryConstraint("approveADMCheck", isAdmin);
        }

        function init() {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_pca_approval::init...");

            initComponents();
            initEventHandlers();

            setVisibilityAsRequireAdminApproval();

            _initialized = true;
        }

        function render(action) {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_pca_approval::render..., action ==> ", action);
        }

        return {
            init: init,
            render: render,
            onRequireAdminApprovalChanged: onRequireAdminApprovalChanged
        }
    };

    var _initializer = window.cms_incentives_pca_approval || (window.cms_incentives_pca_approval = cms_incentives_pca_approval());
})(window);
