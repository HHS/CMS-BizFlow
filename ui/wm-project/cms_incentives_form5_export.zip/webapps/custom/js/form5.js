(function (window) {
    var cms_incentives_approve = function () {
        var _initialized = false;

        function setVisibilityAsRequireAdminApproval(requireAdminApproval) {
            requireAdminApproval = requireAdminApproval || FormState.getElementValue("requireAdminApproval");
            var isRequireAdminApproval = "Yes" === requireAdminApproval;

            hyf.util.setComponentVisibility("approveTABGCheck_group", !isRequireAdminApproval);
            hyf.util.setComponentVisibility("approveTABG_group", !isRequireAdminApproval);
            hyf.util.setComponentVisibility("approveADMCheck_group", isRequireAdminApproval);
            hyf.util.setComponentVisibility("approveADM_group", isRequireAdminApproval);
        }

        function onRequireAdminApprovalChanged(requireAdminApproval) {
            setVisibilityAsRequireAdminApproval(requireAdminApproval);
        }

        function setApproverAndApproveDate(approverEleId, approveDateEleId, checked) {
            var currentUserName = "";
            var currentDate = "";
            if (checked) {
                currentUserName = myInfo.getMyName();
                currentDate = FormUtility.getDateString(false, "mm/dd/yyyy", new Date());
            }

            $("#" + approverEleId).val(currentUserName);
            $("#" + approveDateEleId).val(currentDate);

            FormState.updateTextValue(approverEleId, currentUserName, false);
            FormState.updateDateValue(approveDateEleId, currentDate, false);
        }

        function initEventHandlers() {
            $('#approveTABGCheck').on('change', function (e) {
                var target = e.target;
                setApproverAndApproveDate("approveTABG", "approveTABGDate", target.checked);
            });
            $('#approveADMCheck').on('change', function (e) {
                var target = e.target;
                setApproverAndApproveDate("approveADM", "approveADMDate", target.checked);
            });
        }

        function initComponents() {
            hyf.util.disableComponent("approveTABGDate");
            hyf.util.disableComponent("approveADMDate");

            var isTABG = accessControl.isDesignatedTABG();
            hyf.util.setComponentUsability("approveTABGCheck", isTABG);
            hyf.util.setMandatoryConstraint("approveTABGCheck", isTABG);

            var isAdmin = accessControl.isDesignatedOffAdmin();
            hyf.util.setComponentUsability("approveADMCheck", isAdmin);
            hyf.util.setMandatoryConstraint("approveADMCheck", isAdmin);
        }

        function init() {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_approve::init...");

            initComponents();
            initEventHandlers();

            setVisibilityAsRequireAdminApproval();

            _initialized = true;
        }

        function render() {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_approve::render...");
        }

        return {
            init: init,
            render: render,
            onRequireAdminApprovalChanged: onRequireAdminApprovalChanged
        }
    };

    var _initializer = window.cms_incentives_approve || (window.cms_incentives_approve = cms_incentives_approve());
})(window);
