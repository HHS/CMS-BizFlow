(function (window) {
    var cms_incentives_pca_approval = function () {
        var _readOnly = false;
        var _initialized = false;

        function setVisibilityAsRequireAdminApproval(requireAdminApproval) {
            requireAdminApproval = requireAdminApproval || FormState.getElementValue("requireAdminApproval");
            var isRequireAdminApproval = "Yes" === requireAdminApproval;

            FormMain.setComponentVisibility("pcaApproveTABGCheck_group", !isRequireAdminApproval);
            FormMain.setComponentVisibility("pcaApproveADMCheck_group", isRequireAdminApproval);
        }

        function onRequireAdminApprovalChanged(requireAdminApproval) {
            setVisibilityAsRequireAdminApproval(requireAdminApproval);
        }

        function setApproverAndApproveDate(approverEleId, approveDateEleId, checked) {
            var currentUserName = "";
            var currentUserId = "";
            var currentDate = "";
            if (checked) {
                currentUserName = myInfo.getMyName();
                currentUserId = myInfo.getMyMemberId();
                currentDate = FormUtility.getDateString(false, "mm/dd/yyyy", new Date());
            }

            $("#" + approverEleId).val(currentUserName);
            $("#" + approveDateEleId).val(currentDate);

            FormState.updateTextValue(approverEleId, currentUserName, false);
            FormState.updateTextValue(approverEleId + "Id", currentUserId, false);
            FormState.updateDateValue(approveDateEleId, currentDate, false);
        }

        function initEventHandlers() {
			/* no longer using
            $('#pcaApproveTABGCheck').on('change', function (e) {
                var target = e.target;
                setApproverAndApproveDate("pcaApproveTABG", "pcaApproveTABGDate", target.checked);
            });
            $('#pcaApproveADMCheck').on('change', function (e) {
                var target = e.target;
                setApproverAndApproveDate("pcaApproveADM", "pcaApproveADMDate", target.checked);
            });
			*/
        }

        function initComponents() {
			/* no longer using
			hyf.util.disableComponent("pcaApproveTABGDate");
            hyf.util.disableComponent("pcaApproveADMDate");

            var isTABG = accessControl.isDesignatedTABG();
            hyf.util.setComponentUsability("pcaApproveTABGCheck", isTABG);
            hyf.util.setMandatoryConstraint("pcaApproveTABGCheck", isTABG);

            var isAdmin = accessControl.isDesignatedOffAdmin();
            hyf.util.setComponentUsability("pcaApproveADMCheck", isAdmin);
            hyf.util.setMandatoryConstraint("pcaApproveADMCheck", isAdmin);
			*/
        }

        function init(readOnly, tabObject) {
            _readOnly = readOnly;

			//no longer using
            //initComponents();     
			//initEventHandlers();

            setVisibilityAsRequireAdminApproval();
            FormMain.resetMandatoryMark(tabObject);

            _initialized = true;
        }

        function render(action) {
        }

        return {
            init: init,
            render: render,
            onRequireAdminApprovalChanged: onRequireAdminApprovalChanged
        }
    };

    var _initializer = window.cms_incentives_pca_approval || (window.cms_incentives_pca_approval = cms_incentives_pca_approval());
})(window);
