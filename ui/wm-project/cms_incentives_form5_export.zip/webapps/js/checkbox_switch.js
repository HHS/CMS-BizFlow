/*
 * checkbox_switch.js
 *
 * Functions for the standard checkbox to apply a switch type style commonly seen on mobile devices.
 *
 * Company: Hyfinity Ltd
 * Copyright (c) 2014
 */

hyf.checkbox_switch = {};

/**
 * This function is called when the page loads to ensure that any switches are presented with the appropriate setting checked or empty.
 *
 * @author Hyfinity Limited
 */
hyf.checkbox_switch.init = function()
{
    if (dojo.isIE < 9)
        return;

    var container;
    container = document.body;
    //first process all the switchess to be shown based on the class names
    dojo.query('input.checkbox.switch', container).forEach(function(objDisplayState) {
        //Check that this control has not already been initialised
        if (dojo.query('input.checkbox.switch ~ label', objDisplayState).length == 0)
        {
            var switchLabel = '<label class="label switch" for="' + objDisplayState.id  + '" id="' + objDisplayState.id + '_label_switch">&nbsp;</label>';
            dojo.place(switchLabel, objDisplayState, 'after');
        }
    });

}