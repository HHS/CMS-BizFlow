(function(window){
	'use strict';
	function cms_case_complete(){
		function init(){
		var reqFieldForActivity = 
		[
		 {
		 actName: globalVars.actAll,
		 reqFieldIds: 
		 [
		 
		 
		 ]
		 },
		 {
		 actName: globalVars.actCaseCreation,
		 reqFieldIds: 
		 [
			 
		 ]
		 },
		 {
		 actName: globalVars.actCaseComplete,
		 reqFieldIds: 
		 [
		 'CC_FINAL_ACTION',
		 'CC_CASE_COMPLETE_DT',
		 'CC_PERF_FINAL_ACTION'
		 ]
		 }
		];
		CommonOpUtil.dynamicMandatory(reqFieldForActivity);
		hyf.calendar.setDateConstraint('CC_CASE_COMPLETE_DT', 'Maximum', 'Today');
		hyf.util.hideComponent('CC_PER_FINAL_ACTION');
		hyf.util.hideComponent('CC_CONDUCT_INVESTIGATION_FINAL_ACTION');	
		}
		function render(){
			var caseType = FormState.getElementValue('GEN_CASE_TYPE');
			if(caseType !=='undefined' && (caseType === '744' || caseType === '743')){
				hyf.util.showComponent('CC_CONDUCT_INVESTIGATION_FINAL_ACTION');
				hyf.util.hideComponent('CC_PER_FINAL_ACTION');
			}else if(caseType !=='undefined' && caseType === '750'){
				hyf.util.showComponent('CC_PER_FINAL_ACTION');
				hyf.util.hideComponent('CC_CONDUCT_INVESTIGATION_FINAL_ACTION');
			}else{
				hyf.util.hideComponent('CC_PER_FINAL_ACTION');
				hyf.util.hideComponent('CC_CONDUCT_INVESTIGATION_FINAL_ACTION');
			}
		}
		return{
			init: init,
			render : render
		}
	}
	(window.cms_case_complete !== undefined ? window.cms_case_complete : (window.cms_case_complete = cms_case_complete()));
})(window)