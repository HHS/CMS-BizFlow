(function(window){
	'use strict';
	function cms_case_complete(){
		function init(){
		var reqFieldForActivity = 
		[
		 {
		 actName: globalVars.actAll,
		 reqFieldIds: 
		 [
		 
		 
		 ]
		 },
		 {
		 actName: globalVars.actCaseCreation,
		 reqFieldIds: 
		 [
			 
		 ]
		 },
		 {
		 actName: globalVars.actCaseComplete,
		 reqFieldIds: 
		 [
		 'CC_FINAL_ACTION',
		 'CC_CASE_COMPLETE_DT'
		 ]
		 }
		];
		CommonOpUtil.dynamicMandatory(reqFieldForActivity);
		hyf.calendar.setDateConstraint('CC_CASE_COMPLETE_DT', 'Maximum', 'Today');
		}
		function render(){}
		return{
			init: init,
			render : render
		}
	}
	(window.cms_case_complete !== undefined ? window.cms_case_complete : (window.cms_case_complete = cms_case_complete()));
})(window)