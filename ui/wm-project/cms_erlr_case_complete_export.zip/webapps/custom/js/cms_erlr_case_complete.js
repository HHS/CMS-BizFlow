(function(window){
	'use strict';
	function cms_case_complete(){
		function init(){
		var reqFieldForActivity = 
		[
		 {
		 actName: globalVars.actAll,
		 reqFieldIds: 
		 [
		 
		 
		 ]
		 },
		 {
		 actName: globalVars.actCaseCreation,
		 reqFieldIds: 
		 [
			 
		 ]
		 },
		 {
		 actName: globalVars.actCaseComplete,
		 reqFieldIds: 
		 [
		 'CC_FINAL_ACTION_SEL',
		 'CC_CASE_COMPLETE_DT',
		 'CC_PERF_FINAL_ACTION_SEL'
		 ]
		 }
		];
		CommonOpUtil.dynamicMandatory(reqFieldForActivity);
		hyf.calendar.setDateConstraint('CC_CASE_COMPLETE_DT', 'Maximum', 'Today');
		hyf.util.hideComponent('CC_PER_FINAL_ACTION');
		hyf.util.hideComponent('CC_CONDUCT_INVESTIGATION_FINAL_ACTION');	
		completeCaseMultiSelectOptions('CC_FINAL_ACTION');
		completeCaseMultiSelectOptions('CC_PERF_FINAL_ACTION');
		}
		function render(){
			var caseType = FormState.getElementValue('GEN_CASE_TYPE');
			if(caseType !=='undefined' && (caseType === '744' || caseType === '743')){
				hyf.util.showComponent('CC_CONDUCT_INVESTIGATION_FINAL_ACTION');
				hyf.util.hideComponent('CC_PER_FINAL_ACTION');
			}else if(caseType !=='undefined' && caseType === '750'){
				hyf.util.showComponent('CC_PER_FINAL_ACTION');
				hyf.util.hideComponent('CC_CONDUCT_INVESTIGATION_FINAL_ACTION');
			}else{
				hyf.util.hideComponent('CC_PER_FINAL_ACTION');
				hyf.util.hideComponent('CC_CONDUCT_INVESTIGATION_FINAL_ACTION');
			}
		}
function completeCaseMultiSelectOptions(dropdownID){
	var activityName = ActivityManager.getActivityName();
	var optionsMinSelection = (activityName === 'Complete Case') ? 1 : 0;
	var optionsInitialData = [];
	var optionsIdString = FormState.getElementValue(dropdownID);
	var optionsIds = ((optionsIdString != null && optionsIdString.length > 0) ? optionsIdString.split(',') : []);
	var count = optionsIds.length;
	for (var index = 0; index < count; index++) {
		var itemLabel = $('#'+ dropdownID + '_SEL option[value="' + optionsIds[index] + '"]').text();
		optionsInitialData.push({
			id: optionsIds[index],
			label: itemLabel
		});
	}
	var multiSelectOptions = {
	id: dropdownID,
	tabindex: 0,
	minSelectionCount: optionsMinSelection,
	maxSelectionCount: 10, 
	getSelectionLabel: function(item) {
		return item.label
	},
	getItemID: function(item) {
		return item.id;
	},
	initialItems: optionsInitialData,
	setDataToForm: function(values) {
		if (typeof values == 'undefined') return;
		var selectedIds = '';
		if (values != null && $.isArray(values)) {
			selectedIds = values.reduce(function(accumulator, currentValue, currentIndex, array) {
				return (accumulator && accumulator.length > 0) ? accumulator + ',' + currentValue.id : currentValue.id;
			}, '');
		}
		FormState.updateObjectValue(dropdownID, selectedIds);
	}
	};
	MultiSelectDropdown.setupMultiSelectDropdown(multiSelectOptions);
}
		return{
			init: init,
			render : render
		}
	}
	(window.cms_case_complete !== undefined ? window.cms_case_complete : (window.cms_case_complete = cms_case_complete()));
})(window)