(function(window){
	'use strict';
	function cms_case_complete(){
		function init(){}
		function render(){}
		return{
			init: init,
			render : render
		}
	}
	(window.cms_case_complete !== undefined ? window.cms_case_complete : (window.cms_case_complete = cms_case_complete()));
})(window)