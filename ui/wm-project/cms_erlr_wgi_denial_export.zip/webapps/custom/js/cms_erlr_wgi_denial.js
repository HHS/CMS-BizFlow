'use strict';
(function (window) {
    var cms_erlr_wgi_denial = function () {
	
		var initialized = false;
		
		
		var dateFieldsPastPresent = 
		[
			'WD_WGI_RVW_DT',
			'WD_RECON_REQ_DT',
			'WD_RECON_ISSUE_DT',
			'WD_WGI_DENIAL_ISSUE_DT'
		];
		
		var dateFieldsPresentFuture = 
		[
		];
		
		var reqFieldForActivity = 
		[
			{
				actName: globalVars.actAll,
				reqFieldIds: 
				[
				]
			},
			{
				actName: globalVars.actCaseCreation,
				reqFieldIds: 
				[
				]
			},
			{
				actName: globalVars.actCaseComplete,
				reqFieldIds: 
				[
					'WD_WGI_RVW_DT',
					'WD_EMP_REQ_RECON',
					'WD_RECON_REQ_DT',
					'WD_RECON_ISSUE_DT',
					'WD_WGI_DENIED',
					'WD_WGI_DENIAL_ISSUE_DT',
					'WD_WGI_DENIAL_APPEAL'
				]
			}
		];
		
		
		
		
		function controlWdWgiDeniedVisibility() {
            var elemVal = FormState.getElementValue('WD_WGI_DENIED');
			CommonOpUtil.showHideLayoutGroup('wd_issued_date_group', ('Yes' === elemVal));
			CommonOpUtil.showHideLayoutGroup('wd_detail_appeal_group', ('Yes' === elemVal));
        }
		
		function controlWdReconsiderDetailVisibility() {
            var elemVal = FormState.getElementValue('WD_EMP_REQ_RECON');
			CommonOpUtil.showHideLayoutGroup('wd_reconsider_detail_group', ('Yes' === elemVal));
        }
		
		function controlAppealVisibility() {
			var caseTypeState = FormState.getState('GEN_CASE_TYPE');
			if (typeof caseTypeState == 'undefined' || caseTypeState == null) return;
			var caseTypeTxt = caseTypeState.text;
			if ('Within Grade Increase Denial/Reconsideration' !== caseTypeTxt) return;
			var piWgiAppealVal  = FormState.getElementValue('WD_WGI_DENIAL_APPEAL');
			FormMain.showHideAppealTab('Yes' === piWgiAppealVal);
		}
		
		
		function initVisibility() {
			controlWdWgiDeniedVisibility();
			controlWdReconsiderDetailVisibility();
			controlAppealVisibility();
		}
		
		
		
		
		function setSelectElemValue(selElem) {
			if ( typeof selElem == 'undefined' || selElem == null 
					|| typeof selElem.id == 'undefined' || selElem.id == null 
					|| typeof selElem.options == 'undefined' || selElem.options == null ) {
				return;
			}
			var selectedVal = selElem.options[selElem.options.selectedIndex].value;
			var selectedTxt = selElem.options[selElem.options.selectedIndex].text;
			FormState.updateSelectValue(selElem.id, selectedVal, selectedTxt);
		}
		
		function initEventHandlers() {
			$('#WD_WGI_DENIED').on('change', function(e) {
				setSelectElemValue(e.target);
				controlWdWgiDeniedVisibility();
			});
			
			$('#WD_EMP_REQ_RECON').on('change', function(e) {
				setSelectElemValue(e.target);
				controlWdReconsiderDetailVisibility();
			});
			
			$('#WD_WGI_DENIAL_APPEAL').on('change', function(e) {
				setSelectElemValue(e.target);
				controlAppealVisibility();
			});
		}
		
		
		
		
		function init() {
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_wgi_denial::init START');
			
			//-----------------------------------
			// visibility configuration
			//-----------------------------------
			initVisibility();
			
			
			//-----------------------------------
			// validation configuration
			//-----------------------------------
			dateFieldsPastPresent.forEach(function(item){
				hyf.calendar.setDateConstraint(item, 'Maximum', 'Today');
			});
			dateFieldsPresentFuture.forEach(function(item){
				hyf.calendar.setDateConstraint(item, 'Minimum', 'Today');
			});
			CommonOpUtil.dynamicMandatory(reqFieldForActivity);
			
			
			//-----------------------------------
			// event handler configuration
			//-----------------------------------
			initEventHandlers();
			
			
			//-----------------------------------
			// custom ui element initialization
			//-----------------------------------
			//setupCustomWidget();
			
			initialized = true;
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_wgi_denial::init END');
		}
		
		function render() {
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_wgi_denial::render START');
			
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_wgi_denial::render END');
		}
		
		return {
			initialized: initialized,
			render: render,
			init: init
		};
	};
	
    var _initializer = window.cms_erlr_wgi_denial || (window.cms_erlr_wgi_denial = cms_erlr_wgi_denial());
})(window);
