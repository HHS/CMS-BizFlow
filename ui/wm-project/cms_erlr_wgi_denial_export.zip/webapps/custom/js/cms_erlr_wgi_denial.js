'use strict';
(function (window) {
    var cms_erlr_wgi_denial = function () {
	
		var initialized = false;
		
		
		var dateFieldsPastPresent = 
		[
			'WGI_DTR_DENIAL_ISSUED_DT',
			'WGI_DTR_RECON_REQ_DT',
			'WGI_DTR_RECON_ISSUE_DT',
			'WGI_DTR_DENIAL_ISSUE_TO_EMP_DT',
			'WGI_REVIEW_DTR_NOTICE_ISSUED_DT',
			'WGI_REVIEW_RECON_REQ_DT'
		];
		
		var dateFieldsPresentFuture = 
		[
		];
		
		var reqFieldForActivity = 
		[
			{
				actName: globalVars.actAll,
				reqFieldIds: 
				[
				]
			},
			{
				actName: globalVars.actCaseCreation,
				reqFieldIds: 
				[
				]
			},
			{
				actName: globalVars.actCaseComplete,
				reqFieldIds: 
				[
					'WGI_DTR_DENIAL_ISSUED_DT',
					'WGI_DTR_EMP_REQ_RECON',
					'WGI_DTR_RECON_REQ_DT',
					'WGI_DTR_RECON_ISSUE_DT',
					'WGI_DTR_DENIED',
					'WGI_DTR_DENIAL_ISSUE_TO_EMP_DT',
					'WGI_EMP_APPEAL_DECISION'
				]
			}
		];



        function controlDtrFavorableVisibility() {
            var elemVal = FormState.getElementValue('WGI_REVIEW_DTR_FAVORABLE');
            CommonOpUtil.showHideLayoutGroup('wr_no_dtr_favorable_group', ('No' === elemVal));
        }

		function controlWdWgiDeniedVisibility() {
            var elemVal = FormState.getElementValue('WGI_DTR_DENIED');
			CommonOpUtil.showHideLayoutGroup('wgi_dtr_denial_issue_group', ('Yes' === elemVal));
            var recon = FormState.getElementValue('WGI_DTR_EMP_REQ_RECON');
			CommonOpUtil.showHideLayoutGroup('wgi_review_group', ('Yes' === elemVal || 'No' === recon));
        }
		
		function controlWdReconsiderDetailVisibility() {
            var elemVal = FormState.getElementValue('WGI_DTR_EMP_REQ_RECON');
			CommonOpUtil.showHideLayoutGroup('wd_reconsider_detail_group', ('Yes' === elemVal));
            CommonOpUtil.showHideLayoutGroup('wd_reconsider_detail_group2', ('Yes' === elemVal));
            var denied = FormState.getElementValue('WGI_DTR_DENIED');
            CommonOpUtil.showHideLayoutGroup('wgi_review_group', ('Yes'===denied || 'No' === elemVal));
        }

        function controlWdReviewReconsiderDetailVisibility() {
            var elemVal = FormState.getElementValue('WGI_REVIEW_EMP_REQ_RECON');
            CommonOpUtil.showHideLayoutGroup('wd_review_reconsider_detail_group', ('Yes' === elemVal));
        }

        function controlAppealVisibility() {
			var caseTypeState = FormState.getState('GEN_CASE_TYPE');
			if (typeof caseTypeState == 'undefined' || caseTypeState == null) return;
			var caseTypeTxt = caseTypeState.text;
			if ('Within Grade Increase Denial/Reconsideration' !== caseTypeTxt) return;
			var piWgiAppealVal  = FormState.getElementValue('WGI_EMP_APPEAL_DECISION');
			FormMain.showHideAppealTab('Yes' === piWgiAppealVal);
		}

        function controlWdWgiReviewDeniedVisibility() {
            var elemVal = FormState.getElementValue('WGI_REVIEW_DENIED');
            CommonOpUtil.showHideLayoutGroup('wgi_emp_appeal_group', ('Yes' === elemVal));
        }


        function initVisibility() {
			controlWdWgiDeniedVisibility();
            controlDtrFavorableVisibility();
			controlWdReconsiderDetailVisibility();
            controlWdReviewReconsiderDetailVisibility();
			controlAppealVisibility();
            controlWdWgiReviewDeniedVisibility();
		}
		
		
		
		
		function setSelectElemValue(selElem) {
			if ( typeof selElem == 'undefined' || selElem == null 
					|| typeof selElem.id == 'undefined' || selElem.id == null 
					|| typeof selElem.options == 'undefined' || selElem.options == null ) {
				return;
			}
			var selectedVal = selElem.options[selElem.options.selectedIndex].value;
			var selectedTxt = selElem.options[selElem.options.selectedIndex].text;
			FormState.updateSelectValue(selElem.id, selectedVal, selectedTxt);
		}
		
		function initEventHandlers() {
			$('#WGI_DTR_DENIED').on('change', function(e) {
				setSelectElemValue(e.target);
				controlWdWgiDeniedVisibility();
			});

            $('#WGI_REVIEW_DTR_FAVORABLE').on('change', function(e) {
                setSelectElemValue(e.target);
                controlDtrFavorableVisibility();
            });

            $('#WGI_DTR_EMP_REQ_RECON').on('change', function(e) {
				setSelectElemValue(e.target);
				controlWdReconsiderDetailVisibility();
			});

            $('#WGI_REVIEW_EMP_REQ_RECON').on('change', function(e) {
                setSelectElemValue(e.target);
                controlWdReviewReconsiderDetailVisibility();
            });

			$('#WGI_EMP_APPEAL_DECISION').on('change', function(e) {
				setSelectElemValue(e.target);
				controlAppealVisibility();
			});
            $('#WGI_REVIEW_DENIED').on('change', function(e) {
                setSelectElemValue(e.target);
                controlWdWgiReviewDeniedVisibility();
            });
		}
		
		
		
		
		function init() {
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_wgi_denial::init START');
			
			//-----------------------------------
			// visibility configuration
			//-----------------------------------
			initVisibility();
			
			
			//-----------------------------------
			// validation configuration
			//-----------------------------------
			dateFieldsPastPresent.forEach(function(item){
				hyf.calendar.setDateConstraint(item, 'Maximum', 'Today');
			});
			dateFieldsPresentFuture.forEach(function(item){
				hyf.calendar.setDateConstraint(item, 'Minimum', 'Today');
			});
			CommonOpUtil.dynamicMandatory(reqFieldForActivity);
			
			
			//-----------------------------------
			// event handler configuration
			//-----------------------------------
			initEventHandlers();
			
			
			//-----------------------------------
			// custom ui element initialization
			//-----------------------------------
			//setupCustomWidget();
			
			initialized = true;
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_wgi_denial::init END');
		}
		
		function render() {
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_wgi_denial::render START');
			
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_wgi_denial::render END');
		}
		
		return {
			initialized: initialized,
			render: render,
			init: init
		};
	};
	
    var _initializer = window.cms_erlr_wgi_denial || (window.cms_erlr_wgi_denial = cms_erlr_wgi_denial());
})(window);
