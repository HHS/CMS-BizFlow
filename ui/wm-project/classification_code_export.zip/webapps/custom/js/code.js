var ACTNAME_DWC = "Confirm BUS Code";  // activity name designated for DWC users
var ACTNAME_COMPETEPD = "Complete PD Coversheet and Classification Analysis";
var ACTNAME_CONFIRMANALYSIS = "Confirm Classification Analysis";


/**
 * onload event handler for Codes tab page
 */
function initCodeTab(){
	initPositionClassificationStandardGroup();
	initCybersecurityGroup();

	//------------------------------------------
	// trigger events for initial processing
	//------------------------------------------
	$("input[type=checkbox][name=PD_CLS_STANDARDS]").trigger("change");
	$("input[type=checkbox][name=PD_CYB_SEC_CD]").trigger("change");
	

	$('#PD_COMPET_LVL_CD').on('input', function() {
		var code = $(this).val();
		if (code.length > 5) {
			code = code.substring(0, 5);
			$(this).val(code);
		}
	})

	// if the current activity is for DWC users, disable all fields except for BUS Code
	var actName = getActivityName();
	if (ACTNAME_DWC == actName){
        CMSUtility.disableComponents(["code_group"]);
        if (isReadOnly() === false) {
            CMSUtility.enableComponents(["dwc_group"]);
        }
	}

	if (ACTNAME_CONFIRMANALYSIS == actName) {
		var byPassDWC = $('#BYPASS_DWC_FL').val();
		if (byPassDWC == 'No') {
			$('#btnSendToDwc').val('Send to HR');
		}
	}
	
	// From version 1.0, user can select whether DWC needs to confirm BUS code or not.
	// Before version 1.0 or empty version, then DWC needs to confirm BUS code always.
	var versionElement = $('#h_version');
	if (versionElement.length > 0 && versionElement.val() * 1.0 >= 1.0) {
		if (actName === ACTNAME_COMPETEPD) {
			$('#PD_BUS_CD').on('keyup paste blur change', onChangeBusCode);
			onChangeBusCode();
			$('#BYPASS_DWC_FL').on('keyup paste blur change', onChangeByPassDWC);
			onChangeByPassDWC();
		} else {
			hyf.util.disableComponent("dwc_confirm_group");
			hyf.util.disableComponent("BYPASS_DWC_FL");
		}
	} else {
		$('#dwc_confirm_group').hide();
	}
}

function onChangeByPassDWC() {
	var selectedValue = $('#BYPASS_DWC_FL').val();
	$('#pv_bypassDwc').val(selectedValue);
}

function onChangeBusCode() {
	var selectedBUSCode = $('#PD_BUS_CD').val()
	if (selectedBUSCode.length > 0) {
		$('#dwc_confirm_group').show();
	} else {
		$('#BYPASS_DWC_FL').val('');
		$('#pv_bypassDwc').val('');
		$('#dwc_confirm_group').hide();
	}
}

/**
 * Initializes the related elements for each Position Classification Standard group.
 *
 * The selection dropdown provides all available options.
 * The Selected Item field is multi-checkboxes.  It contains exactly same options as the selection dropdown but only selected items will be displayed.
 */
function initPositionClassificationStandardGroup(){
	//debug
	//console.log("initPositionClassificationStandardGroup()");

	// initially, show checked items and hide unchecked items according to the loaded data in "Selected Item" display
	$("input[type=checkbox][name=PD_CLS_STANDARDS]").filter(function(){ return $(this).prop("checked"); }).parent().parent().show();
	$("input[type=checkbox][name=PD_CLS_STANDARDS]").filter(function(){ return !$(this).prop("checked"); }).parent().parent().hide();

	// add event handler to the selectbox - whenever selection is made, it should be synced up in the "Selected Item" data element
	$("#PD_CLS_STANDARDS_SEL").on("change", function(){
		var selVal = $(this).children("option:selected").val();
		if (typeof selVal != "undefined" && selVal != null) {
			// capture the selected item and set the multiselect checkbox area
			var selChkElms = $("input[type=checkbox][name=PD_CLS_STANDARDS][value=" + selVal + "]");
			if (selChkElms.length > 0) {  // the length should really be 1 if correctly identified
				selChkElms.prop("checked", true);
				$("label[for=" + selChkElms[0].id + "]").parent().removeClass("selected");
				$("label[for=" + selChkElms[0].id + "]").parent().addClass("selected");
				selChkElms.parent().parent().show();  // show parent/parent <tr><td><input ...
			}
			$("input[type=checkbox][name=PD_CLS_STANDARDS]").trigger("change");
		}
		// after select propagation is done to selected item checkbox list, clear current select from dropdown
		$(this).val("");
	});

	// add event handler to the selected item element - whenever checkbox is unched, it should be hidden from the "Selected Item" display
	$("input[type=checkbox][name=PD_CLS_STANDARDS]").on("change", function(){
		if (!$(this).prop("checked")) {
			$(this).parent().parent().hide();  // hide parent/parent <tr><td><input ...
		}

		// if no selected items left, set attribute for error check.  Otherwise, unset attribute to avoid error.
		if ($("input[type=checkbox][name=PD_CLS_STANDARDS]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
			$("#PD_CLS_STANDARDS_SEL").attr("_required", "true");
		} else {
			$("#PD_CLS_STANDARDS_SEL").attr("_required", "false");
		}
	});
} // end initPositionClassificationStandardGroup()




/**
 * Initializes the related elements for Cybersecurity Code group.
 *
 * The selection dropdown provides all available options.
 * The Selected Item field is multi-checkboxes.  It contains exactly same options as the selection dropdown but only selected items will be displayed.
 */
function initCybersecurityGroup(){
	//debug
	//console.log("initCybersecurityGroup()");

	// initially, show checked items and hide unchecked items according to the loaded data in "Selected Item" display
	$("input[type=checkbox][name=PD_CYB_SEC_CD]").filter(function(){ return $(this).prop("checked"); }).parent().parent().show();
	$("input[type=checkbox][name=PD_CYB_SEC_CD]").filter(function(){ return !$(this).prop("checked"); }).parent().parent().hide();

	// add event handler to the selectbox - whenever selection is made, it should be synced up in the "Selected Item" data element
	$("#PD_CYB_SEC_CD_SEL").on("change", function(){
		var selVal = $(this).children("option:selected").val();
		if (typeof selVal != "undefined" && selVal != null) {
			// capture the selected item and set the multiselect checkbox area
			var selChkElms = $("input[type=checkbox][name=PD_CYB_SEC_CD][value=" + selVal + "]");
			if (selChkElms.length > 0) {  // the length should really be 1 if correctly identified
				selChkElms.prop("checked", true);
				$("label[for=" + selChkElms[0].id + "]").parent().removeClass("selected");
				$("label[for=" + selChkElms[0].id + "]").parent().addClass("selected");
				selChkElms.parent().parent().show();  // show parent/parent <tr><td><input ...
			}
			$("input[type=checkbox][name=PD_CYB_SEC_CD]").trigger("change");
		}
		// after select propagation is done to selected item checkbox list, clear current select from dropdown
		$(this).val("");
	});

	// add event handler to the selected item element - whenever checkbox is unched, it should be hidden from the "Selected Item" display
	$("input[type=checkbox][name=PD_CYB_SEC_CD]").on("change", function(){
		if (!$(this).prop("checked")) {
			$(this).parent().parent().hide();  // hide parent/parent <tr><td><input ...
		}

		// if no selected items left, set attribute for error check.  Otherwise, unset attribute to avoid error.
		if ($("input[type=checkbox][name=PD_CYB_SEC_CD]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
			$("#PD_CYB_SEC_CD_SEL").attr("_required", "true");
		} else {
			$("#PD_CYB_SEC_CD_SEL").attr("_required", "false");
		}
	});
} // end initCybersecurityGroup()




/**
 * Performs validation for customized elements in this page.
 *
 * @return true - validation successful
 *         false - validation failed (not completely successful)
 *
 * Note: This function is intended to be called from main form for as part of tab nagivation or page save action.
 */
function validateClsfCodeCustom(){

	var validationResultClsfStd = true;
	var validationResultCybersec = true;

	//-------------------------------------------------------------------------
	// In order to use WebMaker error handling framework, we need to set
	// custom attributes of the validated element dynamically
	// 	_required = true, false
	// 	_type = string, number, boolean, date
	// 	_length = 1,2,3,...
	//-------------------------------------------------------------------------

	//----------------------------------------
	// PD_CLS_STANDARDS section validation
	//----------------------------------------
	if ($("input[type=checkbox][name=PD_CLS_STANDARDS]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
		validationResultClsfStd = false;
		//  slection becomes required, but no selection is made - set required attribute for error check
		$("#PD_CLS_STANDARDS_SEL").attr("_required", "true");
	} else {
		// reset required attribute since already selected
		$("#PD_CLS_STANDARDS_SEL").attr("_required", "false");

		// prohibit selecting more than 7 items
		validationResultClsfStd = validateClsfCodeCustomClsfStd();
	}
	
	//----------------------------------------
	// PD_CYB_SEC_CD section validation
	//----------------------------------------
	if ($("input[type=checkbox][name=PD_CYB_SEC_CD]").filter(function(){ return $(this).prop("checked"); }).length == 0) {
		validationResultCybersec = false;
		//  slection becomes required, but no selection is made - set required attribute for error check
		$("#PD_CYB_SEC_CD_SEL").attr("_required", "true");
	} else {
		// reset required attribute since already selected
		$("#PD_CYB_SEC_CD_SEL").attr("_required", "false");

		// prohibit selecting more than 3 items
		validationResultCybersec = validateClsfCodeCustomCybersec();
	}
	
	return validationResultClsfStd && validationResultCybersec;
} // end of validateClsfCodeCustom()


/**
 * Validates PD_CLS_STANDARDS field to restrict the number of options selected.
 *
 * @return true - validation successful
 *         false - validation failed (not completely successful)
 */
function validateClsfCodeCustomClsfStd(){
	var isValid = true;

	// prohibit selecting more than 7 items
	var selectedClsfStdItems = $("input[type=checkbox][name=PD_CLS_STANDARDS]").filter(function(){ return $(this).prop("checked"); });
	if (selectedClsfStdItems.length > 7){
		isValid = false;
		var lastSelectedClsfStd = selectedClsfStdItems[selectedClsfStdItems.length - 1];
		var objErrorField = {name: 'ErrorField', option: 'PageField', value: lastSelectedClsfStd.id};
		var objMessage = {name: 'Message', option: 'Static', value: 'You can only select a maximum of 7 options'};
		var objEventSource = null; // not necessary to specify event source object {name: 'EventSource', option: 'field', event: evt, component: sourceComponent, value: 'btnRaiseError', field: document.getElementById('btnRaiseError')};
		hyf.FMAction.raiseError.handle(objErrorField, objMessage, objEventSource);
	}
	return isValid;
}


/**
 * Validates PD_CYB_SEC_CD field to restrict the number of options selected.
 *
 * @return true - validation successful
 *         false - validation failed (not completely successful)
 */
function validateClsfCodeCustomCybersec(){
	var isValid = true;

	// prohibit selecting more than 3 items
	var selectedItems = $("input[type=checkbox][name=PD_CYB_SEC_CD]").filter(function(){ return $(this).prop("checked"); });
	if (selectedItems.length > 3){
		isValid = false;
		var lastSelectedItem = selectedItems[selectedItems.length - 1];
		var objErrorField = {name: 'ErrorField', option: 'PageField', value: lastSelectedItem.id};
		var objMessage = {name: 'Message', option: 'Static', value: 'You can only select a maximum of 7 options'};
		var objEventSource = null; // not necessary to specify event source object {name: 'EventSource', option: 'field', event: evt, component: sourceComponent, value: 'btnRaiseError', field: document.getElementById('btnRaiseError')};
		hyf.FMAction.raiseError.handle(objErrorField, objMessage, objEventSource);
	}
	return isValid;
}
