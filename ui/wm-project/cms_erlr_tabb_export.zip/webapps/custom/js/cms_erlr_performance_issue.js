//var PerformanceIssue = {

(function (window) {
    var cms_perf_issue = function () {

        var initialized = false;
		var mayRelease = null;
		var initHiddenLayoutGroups = [
            'PI_CLPD_NO_PRE_WITHHELD_layout_group',
            'PI_CLPD_YES_PRE_WITHHELD_layout_group',
            'PI_CLPD_FINAL_DECISION_layout_group',
            'PI_CLPD_EMP_DECISION_layout_group',
			'PI_CLPD_NO_DETER_FAV_layout_group',
			'PI_CLPD_TRIGGER_GRIEVANCE_layout_group'
        ];
        /* var layout_group =
            [
                'pi_action_counseling_group',
                'pi_counseling_grievance_decision_note_group',
                'pi_action_written_narrative_review_group',
                'pi_action_pip_group',
                'pi_pip_written_resp_detail_group',
                'pi_pip_oral_present_detail_group',
                'pi_pip_end_prior_to_plan_group',
                'pi_pip_end_prior_to_plan_other_group',
                'pi_action_demotion_group',
                'pi_demotion_oral_present_detail_group',
                'pi_demotion_written_resp_detail_group',
                'pi_action_reassignment_group',
                'pi_action_removal_group',
                'pi_removal_notice_leave_detail_group',
                'pi_removal_oral_present_detail_group',
                'pi_removal_written_resp_detail_group',
				'PI_career_ladder_layout_group',
				'PI_NO_PRE_WITHHELD_layout_group',
				'PI_YES_PRE_WITHHELD_layout_group',
				'PI_FINAL_DECISION_layout_group',
				'PI_EMP_DECISION_layout_group',
				'CLPD_NO_DETER_FAV_layout_group',
				'PI_career_ladder_main',
				'PI_Date_of_WGI_Review_group'
            ]; */
			
        var dateFieldsPastPresent =
            [
                'PI_PERF_COUNSEL_ISSUE_DT',
                'PI_DMTN_WRTN_RESP_SBMT_DT',
                'PI_DMTN_DECISION_ISSUE_DT',
                'PI_DMTN_PRPS_ACTN_ISSUE_DT',
                'PI_DMTN_ORAL_PRSNT_DT',
                'PI_PIP_WGI_RVW_DT',
                'PI_PIP_START_DT',
                'PI_PIP_ACTUAL_DT',
                'PI_PIP_PMAP_RTNG_SIGN_DT',
                'PI_PIP_PMAP_RVW_SIGN_DT',
                'PI_PIP_PRPS_ISSUE_DT',
                'PI_PIP_ORAL_PRSNT_DT',
                'PI_PIP_WRTN_SBMT_DT',
                'PI_PIP_DECISION_ISSUE_DT',
                'PI_REASGN_NOTICE_DT',
                'PI_RMV_ORAL_PRSNT_DT',
                'PI_RMV_WRTN_RESP_SBMT_DT',
                'PI_RMV_DECISION_ISSUE_DT',
                'PI_RMV_PRPS_ACTN_ISSUE_DT',
                'PI_WNR_SPCLST_RVW_CMPLT_DT',
                'PI_WNR_MGR_RVW_RTNG_DT',
                'PI_WNR_RVW_OFC_CONCUR_DT',
                'PI_WNR_WGI_RVW_DT',
                'PI_DMTN_FIN_DECISION_ISSUE_DT',
				'PI_CLPD_SERVICE_COMP_DT',
                'PI_CLPD_FIRST_WNI_DT',
                'PI_CLPD_FIRST_WITHHELD_DT',
                'PI_CLPD_DECISION_ISSUED_DT',
                'PI_CLPD_SECOND_WNI_DT'
            ];

        var dateFieldsPresentFuture =
            [];

        var reqFieldForActivity =
            [
                {
                    actName: globalVars.actAll,
                    reqFieldIds:
                        []
                },
                {
                    actName: globalVars.actCaseCreation,
                    reqFieldIds:
                        []
                },
                {
                    actName: globalVars.actCaseComplete,
                    reqFieldIds:
                        [
                            'PI_ACTION_TYPE',
                            'PI_DMTN_FIN_AGCY_DECISION',
                            'PI_PIP_EMPL_SBMT_MEDDOC',
                            'PI_PIP_DOC_SBMT_FOH_RVW',
                            'PI_PIP_WGI_WTHLD',
                            'PI_PIP_WGI_RVW_DT',
                            'PI_PIP_PRPS_ISSUE_DT',
                            'PI_PIP_PMAP_RTNG_SIGN_DT',
                            'PI_PIP_PMAP_RVW_SIGN_DT',
                            'PI_PIP_FIN_AGCY_DECISION',
                            'PI_PIP_EMPL_GRIEVANCE',
                            'PI_PIP_APPEAL_DECISION',
                            'PI_REASGN_NOTICE_DT',
                            'PI_REASGN_EFF_DT',
                            'PI_REASGN_FIN_ADMIN_CD_SEARCH',
                            'PI_RMV_FIN_AGCY_DECISION',
                            'PI_WRTN_NRTV_RVW_TYPE',
                            'PI_WNR_MGR_RVW_RTNG_DT',
                            'PI_RMV_WRTN_RESP_SBMT',
                            'PI_WNR_WGI_WTHLD',
                            'PI_WNR_WGI_RVW_DT',
                            'PI_DMTN_FIN_AGCY_DECISION',
                            'PI_DMTN_FIN_DECIDING_OFC_SRCH',
                            'PI_DMTN_FIN_DECISION_ISSUE_DT',
                            'PI_DMTN_DECISION_EFF_DT',
                            'PI_DMTN_NUM_DAYS',
                            'PI_RMV_FIN_AGCY_DECISION',
                            'PI_RMV_FIN_DECIDING_OFC_SRCH',
                            'PI_RMV_DECISION_ISSUE_DT',
                            'PI_RMV_EFF_DT',
                            'PI_DMTN_APPEAL_DECISION',
                            'PI_RMV_PRPS_ACTN_ISSUE_DT',
                            'PI_RMV_EMPL_NOTC_LEV',
                            'PI_RMV_NOTC_LEV_START_DT',
                            'PI_RMV_ORAL_PRSNT_REQ',
                            'PI_RMV_ORAL_PRSNT_DT',
                            'PI_RMV_WRTN_RESP_DUE_DT',
                            'PI_RMV_WRTN_RESP_SBMT_DT',
                            'PI_RMV_APPEAL_DECISION',
                            'PI_DMTN_WRTN_RESP_DUE_DT',
                            'PI_DMTN_PRPS_ACTN_ISSUE_DT',
                            'PI_DMTN_ORAL_PRSNT_REQ',
                            'PI_DMTN_ORAL_PRSNT_DT',
                            'PI_DMTN_WRTN_RESP_SBMT',
                            'PI_DMTN_WRTN_RESP_SBMT_DT',
                            'PI_DMTN_PRPS_POS_TITLE',
                            'PI_DMTN_PRPS_PAY_PLAN',
                            'PI_DMTN_PRPS_JOB_SERIES',
                            'PI_DMTN_PRPS_GRADE',
                            'PI_DMTN_PRPS_STEP',
                            'PI_DMTN_FIN_POS_TITLE',
                            'PI_DMTN_FIN_PAY_PLAN',
                            'PI_DMTN_FIN_JOB_SERIES',
                            'PI_DMTN_FIN_GRADE',
                            'PI_DMTN_FIN_STEP',
                            'PI_PIP_ORAL_PRSNT_DT',
                            'PI_PIP_WRTN_RESP_SBMT',
                            'PI_PIP_WRTN_RESP_DUE_DT',
                            'PI_PIP_WRTN_SBMT_DT',
                            'PI_PIP_DECIDING_OFFICAL_SRCH',
                            'PI_PIP_DECISION_ISSUE_DT',
                            'PI_PIP_EFF_ACTN_DT',
                            'PI_PIP_ORAL_PRSNT_REQ',
							'PI_CLPD_SERVICE_COMP_DT',
                            'PI_CLPD_NEXT_CLP_DUE_DT',
                            'PI_CLPD_PRE_WITHHELD',
                            'PI_CLPD_FIRST_WNI_DT',
                            'PI_CLPD_DAPI_DT',
                            'PI_CLPD_FIRST_WITHHELD_DT',
                            'PI_CLPD_FINAL_REVIEW_DT',
                            'PI_CLPD_DETER_FAV',
                            'PI_CLPD_EMP_GRIEVANCE',
                            'PI_CLPD_EMP_APPEAL_DECISION',
                            'PI_CLPD_SECOND_WNI_DT',
                            'PI_CLPD_DECISION_ISSUED_DT',
                            'PI_CLPD_DECIDING_OFFCL_SEARCH'
                        ]
                }
            ];

        var disabledElementIds = [];


        var piDmtnDecidingOfcAutocomplete = null;
        var piPipDecidingOfcAutocomplete = null;
        var piReassignFinAdminCdAutocomplete = null;
        var piRmvDecidingOfcAutocomplete = null;
        var PI_PIP_EXT_DT_LIST_group = null;
		
        function populateGradesByPayPlan(target, payPlan) {
            var showGradeStepField = false;
            $('#' + target).html('');
            if (payPlan !== 'default' && PayPlanGrade[payPlan] !== undefined) {
                $('#' + target).append('<option value="default">Select one </option>');
                PayPlanGrade[payPlan].forEach(function (val) {
                    $('#' + target).append('<option value="' + val + '">' + val + '</option>');
                });

                CommonOpUtil.showHideLayoutGroup(target, true);
                showGradeStepField = true;
            } else {
                CommonOpUtil.showHideLayoutGroup(target, false, false);
            }

            if (target === 'PI_DMTN_PRPS_GRADE') {
                CommonOpUtil.showHideLayoutGroup('PI_DMTN_PRPS_GRADE', showGradeStepField);
                CommonOpUtil.showHideLayoutGroup('PI_DMTN_PRPS_STEP', showGradeStepField);
            } else if (target === 'PI_DMTN_FIN_GRADE') {
                CommonOpUtil.showHideLayoutGroup('PI_DMTN_FIN_GRADE', showGradeStepField);
                CommonOpUtil.showHideLayoutGroup('PI_DMTN_FIN_STEP', showGradeStepField);
            }
        }

        function populateNextWgiDueDate() {
            var genEmployee = FormState.getElementJSONValue('GEN_EMPLOYEE');
            var nextWgiDueDt = '';
            if (typeof genEmployee !== 'undefined') {
                var nextWgiDueDt = genEmployee.wgiDueDate;
                if (typeof nextWgiDueDt === 'undefined' || nextWgiDueDt == null || nextWgiDueDt.length <= 0) {
                    nextWgiDueDt = '';
                }
                if (nextWgiDueDt.length >= 10) {
                    var datePtrn = /^(\d{4})-(\d{2})-(\d{2})/;
                    var dateMatch = datePtrn.exec(nextWgiDueDt);
                    nextWgiDueDt = dateMatch[2] + '/' + dateMatch[3] + '/' + dateMatch[1];
                }
            }

            $('#PI_NEXT_WGI_DUE_DT').text(nextWgiDueDt);
            FormState.updateDateValue('PI_NEXT_WGI_DUE_DT', nextWgiDueDt, false);
        }

        function populatePiDemotionCurPosnData() {
            var genEmployee = FormState.getElementJSONValue('GEN_EMPLOYEE');
            if (typeof genEmployee === 'undefined') return;
            $('#PI_DMTN_CUR_POS_TITLE').text(genEmployee.positionTitle);
            $('#PI_DMTN_CUR_PAY_PLAN').text(genEmployee.payPlan);
            $('#PI_DMTN_CUR_JOB_SERIES').text(genEmployee.series);

            if(_.isEmpty(genEmployee.grade)){
                CommonOpUtil.showHideLayoutGroup('PI_DMTN_CUR_GRADE', false);
                CommonOpUtil.showHideLayoutGroup('PI_DMTN_CUR_STEP', false);
                FormState.updateVariableValue('PI_DMTN_CUR_GRADE', '', false);
                FormState.updateVariableValue('PI_DMTN_CUR_STEP', '', false);
            }else{
                $('#PI_DMTN_CUR_GRADE').text(genEmployee.grade);
                $('#PI_DMTN_CUR_STEP').text(genEmployee.step);
                FormState.updateVariableValue('PI_DMTN_CUR_GRADE', genEmployee.grade, false);
                FormState.updateVariableValue('PI_DMTN_CUR_STEP', genEmployee.step, false);
            }
            FormState.updateVariableValue('PI_DMTN_CUR_POS_TITLE', genEmployee.positionTitle, false);
            FormState.updateVariableValue('PI_DMTN_CUR_PAY_PLAN', genEmployee.payPlan, false);
            FormState.updateVariableValue('PI_DMTN_CUR_JOB_SERIES', genEmployee.series, false);
        }

        function populatePiReassignCurInfo() {
            var genEmployee = FormState.getElementJSONValue('GEN_EMPLOYEE');
            if (typeof genEmployee === 'undefined') return;
            $('#PI_REASGN_CUR_ADMIN_CD').text(genEmployee.adminCode);
            $('#PI_REASGN_CUR_ORG_NM').text(genEmployee.adminCodeDesc);
            FormState.updateTextValue('PI_REASGN_CUR_ADMIN_CD', genEmployee.adminCode, false);
            FormState.updateTextValue('PI_REASGN_CUR_ORG_NM', genEmployee.adminCodeDesc, false);
        }

        function populateReassignFinAdminCdDesc() {
            var item = FormState.getElementSingleValue('PI_REASGN_FIN_ADMIN_CD');
            if (typeof item !== 'object' || item == null
                || typeof item.adminCdDesc == 'undefined' || item.adminCdDesc == null) {
                return;
            }
            $('#PI_REASGN_FIN_ORG_NM').text(item.adminCdDesc);
            FormState.updateTextValue('PI_REASGN_FIN_ORG_NM', item.adminCdDesc, false);
        }

        function clearReassignFinAdminCdDesc() {
            if (typeof piReassignFinAdminCdAutocomplete !== 'undefined' && piReassignFinAdminCdAutocomplete != null) {
                piReassignFinAdminCdAutocomplete.deleteAllItems();
            }
            FormState.updateObjectValue('PI_REASGN_FIN_ADMIN_CD', [], false);
            FormState.updateTextValue('PI_REASGN_FIN_ORG_NM', '', false);
        }

        function controlPiActionTypeVisibility() {
            var piActionTypeSelVal = FormState.getElementValue('PI_ACTION_TYPE');
            var piActionTypeSelTxt = $('#PI_ACTION_TYPE option[value="' + piActionTypeSelVal + '"]').text();
            if (typeof piActionTypeSelTxt == 'undefined' || piActionTypeSelTxt == null || piActionTypeSelTxt.trim().length <= 0) {
                // hide all subsection of the tab unless Action Type is set
                $('#performance_issue_group div[id^="pi_action_"]').each(function (index, item) {
                    hyf.util.hideComponent(item.id);
                    CommonOpUtil.clearGroupContent(item.id);
                });
                return;
            }

            // layout group names maps to PI_ACTION_TYPE value: "pi_action_" + selected label in lower case, replacing space with underscore
            var selectedPiActionTypeGroupId = 'pi_action_' + piActionTypeSelTxt.toLowerCase().replace(/\s/g, '_') + '_group';
            $('#performance_issue_group div[id^="pi_action_"]').each(function (index, item) {
                if (item.id === selectedPiActionTypeGroupId) {
                    if (piActionTypeSelTxt == 'Demotion') {
                        populatePiDemotionCurPosnData();
                        clearReassignFinAdminCdDesc();
                    } else if (piActionTypeSelTxt == 'PIP') {
                        clearReassignFinAdminCdDesc();
                        controlPiPipEndDtEnableDisable();
                        controlPiPipSuccessfullyCompletedVisibility();
                    } else if (piActionTypeSelTxt == 'Reassignment') {
                        populatePiReassignCurInfo();
                        populateReassignFinAdminCdDesc();
                    } else {
                        clearReassignFinAdminCdDesc();
                    }
                    hyf.util.showComponent(item.id);
                } else {
                    hyf.util.hideComponent(item.id);
                    CommonOpUtil.clearGroupContent(item.id);
                }
            });
        }

        function controlPiCounselGrievanceDecisionVisibility() {
            CommonOpUtil.showHideLayoutGroup('pi_counseling_grievance_decision_note_group', FormState.getElementBooleanValue('PI_CNSL_GRV_DECISION'));
        }

        function controlPiDemotionOralPresentReqVisibility() {
            CommonOpUtil.showHideLayoutGroup('pi_demotion_oral_present_detail_group', FormState.getElementBooleanValue('PI_DMTN_ORAL_PRSNT_REQ'));
        }

        function controlPiDemotionWrittenRespSubmitVisibility() {
            CommonOpUtil.showHideLayoutGroup('pi_demotion_written_resp_detail_group', FormState.getElementBooleanValue('PI_DMTN_WRTN_RESP_SBMT'));
        }


        function controlPiDemotionFinDecisionVisibility() {
            var elemVal = FormState.getElementValue('PI_DMTN_FIN_AGCY_DECISION');
            var elemTxt = null;
            if (typeof elemVal != 'undefined' && elemVal != null && elemVal.length > 0) {
                elemTxt = $('#PI_DMTN_FIN_AGCY_DECISION option[value="' + elemVal + '"]').text();
            }
            CommonOpUtil.showHideLayoutGroup('pi_demotion_final_decision_detail_by_type_group', (null !== elemTxt && 'No Action Taken' !== elemTxt));
            CommonOpUtil.showHideLayoutGroup('pi_demotion_final_decision_effdt_group', ('Demotion Rescinded' !== elemTxt));
            CommonOpUtil.showHideLayoutGroup('pi_demotion_final_decision_suspend_days_group', ('Suspension' === elemTxt));
        }

        function controlPiPipSubmitMeddocVisibility() {
            CommonOpUtil.showHideLayoutGroup('pi_pip_meddoc_group', FormState.getElementBooleanValue('PI_PIP_EMPL_SBMT_MEDDOC'));
        }

        function controlPiPipMeddocReviewVisibility() {
            CommonOpUtil.showHideLayoutGroup('pi_pip_meddoc_review_group', FormState.getElementBooleanValue('PI_PIP_DOC_SBMT_FOH_RVW'));
        }

        function controlPiPipWgiWithheldNoteVisibility() {
            CommonOpUtil.showHideLayoutGroup('pi_pip_wgi_withheld_note_group', FormState.getElementBooleanValue('PI_PIP_WGI_WTHLD'));
            CommonOpUtil.showHideLayoutGroup('PI_Date_of_WGI_Review_group', FormState.getElementBooleanValue('PI_PIP_WGI_WTHLD'));
        }

        function controlPiPipSuccessfullyCompletedVisibility() {
            CommonOpUtil.showHideLayoutGroup('pi_pip_not_success_group', !FormState.getElementBooleanValue('PI_PIP_SUCCESS_CMPLT', true));
        }

        function controlPiPipEndPriorToPlanOtherVisibility() {
            var elemVal = FormState.getElementValue('PI_PIP_END_PRIOR_TO_PLAN_RSN');
            var elemTxt = null;
            if (typeof elemVal != 'undefined' && elemVal != null && elemVal.length > 0) {
                elemTxt = $('#PI_PIP_END_PRIOR_TO_PLAN_RSN option[value="' + elemVal + '"]').text();
            }
            CommonOpUtil.showHideLayoutGroup('pi_pip_end_prior_to_plan_other_group', ('Other' === elemTxt));
        }

        function controlPiPipNotCompletedOtherVisibility() {
            var elemVal = FormState.getElementValue('PI_PIP_NOT_CMPLT_RSN');
            var elemTxt = null;
            if (typeof elemVal != 'undefined' && elemVal != null && elemVal.length > 0) {
                elemTxt = $('#PI_PIP_NOT_CMPLT_RSN option[value="' + elemVal + '"]').text();
            }
            CommonOpUtil.showHideLayoutGroup('pi_pip_not_completed_other_rsn_group', ('Other' === elemTxt));
        }

        function controlPiPipEndPriorToPlanVisibility() {
            CommonOpUtil.showHideLayoutGroup('pi_pip_end_prior_to_plan_group', FormState.getElementBooleanValue('PI_PIP_END_PRIOR_TO_PLAN'));
        }

        function controlPiPipOralPresentReqVisibility() {
            CommonOpUtil.showHideLayoutGroup('pi_pip_oral_present_detail_group', FormState.getElementBooleanValue('PI_PIP_ORAL_PRSNT_REQ'));
        }

        function controlPiPipWrittenRespSubmitVisibility() {
            CommonOpUtil.showHideLayoutGroup('pi_pip_written_resp_detail_group', FormState.getElementBooleanValue('PI_PIP_WRTN_RESP_SBMT'));
        }

        function controlPiRemovalEmplPlacedNoticeLeaveVisibility() {
            CommonOpUtil.showHideLayoutGroup('pi_removal_notice_leave_detail_group', FormState.getElementBooleanValue('PI_RMV_EMPL_NOTC_LEV'));
        }

        function controlPiRemovalOralPresentReqVisibility() {
            CommonOpUtil.showHideLayoutGroup('pi_removal_oral_present_detail_group', FormState.getElementBooleanValue('PI_RMV_ORAL_PRSNT_REQ'));
        }

        function controlPiRemovalWrittenRespSubmitVisibility() {
            CommonOpUtil.showHideLayoutGroup('pi_removal_written_resp_detail_group', FormState.getElementBooleanValue('PI_RMV_WRTN_RESP_SBMT'));
        }

        function controlPiRemovalFinDecisionVisibility() {
            var elemVal = FormState.getElementValue('PI_RMV_FIN_AGCY_DECISION');
            var elemTxt = null;
            if (typeof elemVal != 'undefined' && elemVal != null && elemVal.length > 0) {
                elemTxt = $('#PI_RMV_FIN_AGCY_DECISION option[value="' + elemVal + '"]').text();
            }
            CommonOpUtil.showHideLayoutGroup('pi_removal_final_decision_detail_by_type_group', (null !== elemTxt && 'No Action Taken' !== elemTxt));
            CommonOpUtil.showHideLayoutGroup('pi_removal_final_decision_effdt_group', ('Removal Rescinded' !== elemTxt));
            CommonOpUtil.showHideLayoutGroup('pi_removal_final_decision_suspend_days_group', ('Suspension' === elemTxt));
        }

        function controlPiWrtnNartvRvwTypeVisibility() {
            var elemVal = FormState.getElementValue('PI_WRTN_NRTV_RVW_TYPE');
            var elemTxt = null;
            if (typeof elemVal != 'undefined' && elemVal != null && elemVal.length > 0) {
                elemTxt = $('#PI_WRTN_NRTV_RVW_TYPE option[value="' + elemVal + '"]').text();
            }
            CommonOpUtil.showHideLayoutGroup('pi_wnr_final_review_group', ('End of Year' === elemTxt));
        }

        function controlPiWrtnNartvRvwWgiWithheldNoteVisibility() {
            CommonOpUtil.showHideLayoutGroup('pi_wnr_wgi_withheld_note_group', FormState.getElementBooleanValue('PI_WNR_WGI_WTHLD'));
        }
	function initAdminLeaveDynamic() {
		if ($('#PI_ADMIN_INVESTIGATORY_LEAVE').prop('checked')) {
			hyf.util.showComponent('pi_admin_leave_investigatory_group');
		} else {
			hyf.util.hideComponent('pi_admin_leave_investigatory_group');
		}
		if ($('#PI_ADMIN_NOTICE_LEAVE').prop('checked')) {
			hyf.util.showComponent('pi_admin_leave_notice_group');
		} else {
			hyf.util.hideComponent('pi_admin_leave_notice_group');
		}
	}
	//helper function for business day format.
	function dateFormat(dt){
		var datePtrn = /^(\d{4})-(\d{2})-(\d{2})/;;
        var dateMatch ='';
		if(dt !='undefined'){
			dateMatch = datePtrn.exec(dt);
		}
		return dateMatch[1] + '-' + dateMatch[2] + '-' + dateMatch[3];
	}
	
	function inventoryBusinessDays(days, callbackTargetElementId) {
		if (days != null && days[0] >= 0) {
			$('#pi_leave_length').text(days[0] + ' Day(s)');
		}
		else {
			if(days == null) {
				bootbox.alert({
					message: 'Invalid Leave Start Date or Leave End Date. Leave end date must come after start date.',
					callback: function () {
						setTimeout(function(){$('#' + callbackTargetElementId).val('').focus();},1);
					}
				});
			}
			$('#pi_leave_length').text('');
		}
	}

	function noticeBusinessDays(days, callbackTargetElementId) {
		if (days != null && days[0] >= 0) {
			$('#pi_leave_length_2').text(days[0] + ' Day(s)');
		}
		else {
			if(days == null){
				bootbox.alert({
					message: 'Invalid Leave Start Date or Leave End Date. Leave end date must come after start date.',
					callback: function(){
						setTimeout(function(){$('#' + callbackTargetElementId).val('').focus();},1);
					}
				});
			}

			$('#pi_leave_length_2').text('');
		}
	}
	//load business day during load
	function initLeaveBusinessDays() {
		var InvLeaveStartDate = '';
		var InvLeaveEndDate = '';
		var ntcLeaveStartDate = '';
		var ntcLeaveEndDate = '';		
		try {
			InvLeaveStartDate = dateFormat(FormState.getElementValue('PI_LEAVE_START_DT'));
			InvLeaveEndDate = 	dateFormat(FormState.getElementValue('PI_LEAVE_END_DT'));
			ntcLeaveStartDate = dateFormat(FormState.getElementValue('PI_LEAVE_START_DT_2'));
			ntcLeaveEndDate = 	dateFormat(FormState.getElementValue('PI_LEAVE_END_DT_2'));
			
			if ((InvLeaveStartDate != '' && InvLeaveEndDate != '')) {
				CommonOpUtil.getBusinessDaysCount(InvLeaveStartDate, InvLeaveEndDate, inventoryBusinessDays, 'PI_LEAVE_END_DT');
			}
			if ((ntcLeaveStartDate != '' && ntcLeaveEndDate != '')) {
				CommonOpUtil.getBusinessDaysCount(ntcLeaveStartDate, ntcLeaveEndDate, noticeBusinessDays, 'PI_LEAVE_END_DT_2');
			}
		} catch (e) {

		}	
	}
	function conductAutoCompleteOptions(id) {
		return FormAutoComplete.makeAutoCompletion(FormMain.getAutoCompleteOptionForEmployee(id+'_SRCH', id));
	}
        function initVisibility() {
			initAdminLeaveDynamic();
			conductAutoCompleteOptions('PI_APPROVAL_NAME');
			conductAutoCompleteOptions('PI_APPROVAL_NAME_2');
            controlPiActionTypeVisibility();
            controlPiCounselGrievanceDecisionVisibility();
            controlPiDemotionOralPresentReqVisibility();
            controlPiDemotionWrittenRespSubmitVisibility();
            controlPiDemotionFinDecisionVisibility();
            controlPiPipSubmitMeddocVisibility();
            controlPiPipMeddocReviewVisibility();
            controlPiPipWgiWithheldNoteVisibility();
            controlPiPipSuccessfullyCompletedVisibility();
            controlPiPipNotCompletedOtherVisibility();
            controlPiPipEndPriorToPlanVisibility();
            controlPiPipOralPresentReqVisibility();
            controlPiPipWrittenRespSubmitVisibility();
            controlPiRemovalEmplPlacedNoticeLeaveVisibility();
            controlPiRemovalOralPresentReqVisibility();
            controlPiRemovalWrittenRespSubmitVisibility();
            controlPiRemovalFinDecisionVisibility();
            controlPiWrtnNartvRvwTypeVisibility();
            controlPiWrtnNartvRvwWgiWithheldNoteVisibility();
            controlPiPipEndPriorToPlanOtherVisibility();
        }

        function controlPiPipEndDtEnableDisable() {
            var origDt = FormState.getElementValue('PI_PIP_END_DT');
            var isValidOrigDt = (typeof origDt !== 'undefined' && origDt != null && 0 < origDt.length);
            CommonOpUtil.showHideLayoutGroup('PI_PIP_EXT_DT_LIST_group', isValidOrigDt);

            var extDt = FormState.getElementValue('PI_PIP_EXT_DT_LIST');
            try {
                extDt = JSON.parse(extDt);
            } catch (e) {
                extDt = null;
            }
            if (typeof extDt === 'undefined' || extDt == null || extDt.length <= 0) {
                hyf.util.enableComponent('PI_PIP_END_DT');
            } else {
                hyf.util.disableComponent('PI_PIP_END_DT');
            }
        }

        function controlEnableDisable() {
            disabledElementIds.forEach(function (item) {
                hyf.util.disableComponent(item);
            });
            controlPiPipEndDtEnableDisable();
        }


        function setSelectElemValue(selElem) {
            if (typeof selElem == 'undefined' || selElem == null
                || typeof selElem.id == 'undefined' || selElem.id == null
                || typeof selElem.options == 'undefined' || selElem.options == null) {
                return;
            }
            var selectedVal = selElem.options[selElem.options.selectedIndex].value;
            var selectedTxt = selElem.options[selElem.options.selectedIndex].text;
            FormState.updateSelectValue(selElem.id, selectedVal, selectedTxt, false);
        }

        function initEventHandlers() {
            $('#PI_ACTION_TYPE').on('change', function (e) {
                setSelectElemValue(e.target);
                controlPiActionTypeVisibility();
            });

            $('#PI_CNSL_GRV_DECISION').on('change', function (e) {
                setSelectElemValue(e.target);
                controlPiCounselGrievanceDecisionVisibility();
            });

            $('#PI_DMTN_ORAL_PRSNT_REQ').on('change', function (e) {
                setSelectElemValue(e.target);
                controlPiDemotionOralPresentReqVisibility();
            });

            $('#PI_DMTN_WRTN_RESP_SBMT').on('change', function (e) {
                setSelectElemValue(e.target);
                controlPiDemotionWrittenRespSubmitVisibility();
            });


            $('#PI_DMTN_FIN_AGCY_DECISION').on('change', function (e) {
                setSelectElemValue(e.target);
                controlPiDemotionFinDecisionVisibility();
            });

            $('#PI_PIP_EMPL_SBMT_MEDDOC').on('change', function (e) {
                setSelectElemValue(e.target);
                controlPiPipSubmitMeddocVisibility();
            });

            $('#PI_PIP_DOC_SBMT_FOH_RVW').on('change', function (e) {
                setSelectElemValue(e.target);
                controlPiPipMeddocReviewVisibility();
            });

            $('#PI_PIP_WGI_WTHLD').on('change', function (e) {
                setSelectElemValue(e.target);
                controlPiPipWgiWithheldNoteVisibility();
            });

            $('#PI_PIP_SUCCESS_CMPLT').on('change', function (e) {
                setSelectElemValue(e.target);
                controlPiPipSuccessfullyCompletedVisibility();
            });

            $('#PI_PIP_NOT_CMPLT_RSN').on('change', function (e) {
                setSelectElemValue(e.target);
                controlPiPipNotCompletedOtherVisibility();
            });

            $('#PI_PIP_END_PRIOR_TO_PLAN_RSN').on('change', function (e) {
                setSelectElemValue(e.target);
                controlPiPipEndPriorToPlanOtherVisibility();
            });


            $('#PI_PIP_END_DT').on('change', function (e) {
                FormState.updateDateValue(e.target.id, e.target.value, false);
                controlPiPipEndDtEnableDisable();
            });

            $('#PI_PIP_END_PRIOR_TO_PLAN').on('change', function (e) {
                setSelectElemValue(e.target);
                controlPiPipEndPriorToPlanVisibility();
            });

            $('#PI_PIP_ORAL_PRSNT_REQ').on('change', function (e) {
                setSelectElemValue(e.target);
                controlPiPipOralPresentReqVisibility();
            });

            $('#PI_PIP_WRTN_RESP_SBMT').on('change', function (e) {
                setSelectElemValue(e.target);
                controlPiPipWrittenRespSubmitVisibility();
            });

            $('#PI_RMV_EMPL_NOTC_LEV').on('change', function (e) {
                setSelectElemValue(e.target);
                controlPiRemovalEmplPlacedNoticeLeaveVisibility();
            });

            $('#PI_RMV_ORAL_PRSNT_REQ').on('change', function (e) {
                setSelectElemValue(e.target);
                controlPiRemovalOralPresentReqVisibility();
            });

            $('#PI_RMV_WRTN_RESP_SBMT').on('change', function (e) {
                setSelectElemValue(e.target);
                controlPiRemovalWrittenRespSubmitVisibility();
            });

            $('#PI_RMV_FIN_AGCY_DECISION').on('change', function (e) {
                setSelectElemValue(e.target);
                controlPiRemovalFinDecisionVisibility();
            });

            $('#PI_WRTN_NRTV_RVW_TYPE').on('change', function (e) {
                setSelectElemValue(e.target);
                controlPiWrtnNartvRvwTypeVisibility();
            });

            $('#PI_WNR_WGI_WTHLD').on('change', function (e) {
                setSelectElemValue(e.target);
                controlPiWrtnNartvRvwWgiWithheldNoteVisibility();
            });


            PI_PIP_EXT_DT_LIST_group = MultiDataSelectField.init({
                layoutGroupId: 'PI_PIP_EXT_DT_LIST_group',
                mandatory: false,
                dataFieldId: 'PI_PIP_EXT_DT_LIST',
                sort: {fieldId: 'PI_PIP_EXT_END_DT', valueType: 'date', order: 'desc'},
                recordFields: ['PI_PIP_EXT_END_DT', 'PI_PIP_EXT_END_REASON', 'PI_PIP_EXT_END_NOTIFY_DT'],
                dialog: {
                    input: {
                        init: function () {
                            hyf.calendar.setDateConstraint('_PI_PIP_EXT_END_DT', 'Minimum', 'PI_PIP_END_DT');
                           // hyf.calendar.setDateConstraint('_PI_PIP_EXT_END_NOTIFY_DT', 'Minimum', 'PI_PIP_END_DT');
                            hyf.util.hideComponent('_PI_PIP_EXT_END_OTHER_REASON_layout_group');

                            $('#_PI_PIP_EXT_END_REASON1').on('change', function (e) {
                                var text = $(this).find('option:selected').text();
                                if (text === 'Other') {
                                    hyf.util.showComponent('_PI_PIP_EXT_END_OTHER_REASON_layout_group');
                                    $('#_PI_PIP_EXT_END_REASON').val('');
                                } else {
                                    hyf.util.hideComponent('_PI_PIP_EXT_END_OTHER_REASON_layout_group');
                                    $('#_PI_PIP_EXT_END_REASON').val(text);
                                }
                            });
                            $('#_PI_PIP_EXT_END_REASON2').on('blur', function (e) {
                                $('#_PI_PIP_EXT_END_REASON').val($(this).val());
                            });
                        }
                    }
                }
            });
			
			$('#PI_ADMIN_NOTICE_LEAVE, #PI_ADMIN_INVESTIGATORY_LEAVE').on('click', function (e) {
            var val = $(this).prop('checked');
            if (e.target.id === 'PI_ADMIN_INVESTIGATORY_LEAVE') {
                $('#pi_admin_leave_investigatory_group input[type="text"]').val('');
                $('#leave_length').text('');
                if (val) {
                    hyf.util.showComponent('pi_admin_leave_investigatory_group');
                }
                else {
                    hyf.util.hideComponent('pi_admin_leave_investigatory_group');
                }
            }
            if (e.target.id === 'PI_ADMIN_NOTICE_LEAVE') {
                $('#pi_admin_leave_notice_group input[type="text"]').val('');
                $('#leave_length_2').text('');
                if (val) {
                    hyf.util.showComponent('pi_admin_leave_notice_group');
                }
                else {
                    hyf.util.hideComponent('pi_admin_leave_notice_group');
                }
            }
        });
		$('#PI_LEAVE_START_DT,#PI_LEAVE_END_DT,#PI_LEAVE_START_DT_2,#PI_LEAVE_END_DT_2').on('change', initLeaveBusinessDays);
        }

        function mapFunctionAdminCd(context) {
            return {
                adminCd: $("AC_ADMIN_CD", context).text(),
                adminCdDesc: $("AC_ADMIN_CD_DESCR", context).text(),
                value: $("AC_ADMIN_CD", context).text()
            };
        }

        function getSelectionLabelAdminCd(item) {
            var label = item.adminCd;
            return label;
        }

        function getCandidateLabelAdminCd(item) {
            return item.adminCd + ' - ' + item.adminCdDesc;
        }

        function getItemIDAdminCd(item) {
            return item.adminCd;
        }

        function setDataToFormAdminCd(items) {
            if (typeof items == 'undefined' || items == null) return;
            var item = null;
            if ($.isArray(items)) {
                item = items[0];
            } else {
                item = items;
            }

            if (typeof item === 'object' && item != null
                && typeof item.adminCd != 'undefined' && item.adminCd != null && item.adminCd.trim().length > 0
                && typeof item.adminCdDesc != 'undefined' && item.adminCdDesc != null && item.adminCdDesc.trim().length > 0) {
                CommonOpUtil.showHideLayoutGroup('pi_reassignment_final_org_name_group', true);
                $('#PI_REASGN_FIN_ORG_NM').text(item.adminCdDesc);
                FormState.updateObjectValue('PI_REASGN_FIN_ADMIN_CD', items, false);
                //FormState.updateVariableValue('PI_REASGN_FIN_ORG_NM', item.adminCdDesc, false);
                FormState.updateVariableValue('PI_REASGN_FIN_ORG_NM', item.adminCdDesc, true);
            } else {
                CommonOpUtil.showHideLayoutGroup('pi_reassignment_final_org_name_group', false);
                $('#PI_REASGN_FIN_ORG_NM').text('');
                FormState.updateObjectValue('PI_REASGN_FIN_ADMIN_CD', [], false);
                //FormState.updateVariableValue('PI_REASGN_FIN_ORG_NM', '', false);
                FormState.updateVariableValue('PI_REASGN_FIN_ORG_NM', '', true);
            }
        }

        function setupCustomWidget() {
            piDmtnDecidingOfcAutocomplete = FormAutoComplete.makeAutoCompletion(FormMain.getAutoCompleteOptionForEmployee('PI_DMTN_FIN_DECIDING_OFC_SRCH', 'PI_DMTN_FIN_DECIDING_OFC_NM'));
            piPipDecidingOfcAutocomplete = FormAutoComplete.makeAutoCompletion(FormMain.getAutoCompleteOptionForEmployee('PI_PIP_DECIDING_OFFICAL_SRCH', 'PI_PIP_DECIDING_OFFICAL_NM'));
            piRmvDecidingOfcAutocomplete = FormAutoComplete.makeAutoCompletion(FormMain.getAutoCompleteOptionForEmployee('PI_RMV_FIN_DECIDING_OFC_SRCH', 'PI_RMV_FIN_DECIDING_OFC_NM'));

            //PI_REASGN_FIN_ADMIN_CD
            var optionReassignFinAdminCd = {
                id: 'PI_REASGN_FIN_ADMIN_CD_SEARCH',
                baseURL: '/bizflowwebmaker/StratCon_AUT',
                targetURL: '/bizflowwebmaker/StratCon_AUT/SearchAdmOffOrg.do?searchAdmOff=',
                minLength: 2,
                minSelectionCount: 0,
                maxSelectionCount: 1,

                mapFunction: mapFunctionAdminCd,
                getSelectionLabel: getSelectionLabelAdminCd,
                getCandidateLabel: getCandidateLabelAdminCd,
                getItemID: getItemIDAdminCd,
                setDataToForm: setDataToFormAdminCd,

                // initialize
                initialItems: FormState.getElementArrayValue('PI_REASGN_FIN_ADMIN_CD', [])
            };
            piReassignFinAdminCdAutocomplete = FormAutoComplete.makeAutoCompletion(optionReassignFinAdminCd);

            // var name = FormState.getElementValue('PI_REASGN_FIN_ORG_NM');
            // CommonOpUtil.showHideLayoutGroup('pi_reassignment_final_org_name_group', !_.isEmpty(name));
        }


        // Clear data for all custom widget in the tab.
        // Note: This function will be called by the main tab when subsequent tabs are
        function clearAllContentCustom() {
            // clearPiPipExtInfo();
            clearReassignFinAdminCdDesc();
        }


        function init() {
			
            $.each(initHiddenLayoutGroups, function(i, v){
                CommonOpUtil.showHideLayoutGroup(v, false, false);
            });
            initVisibility();
			initAdminLeaveDynamic();
            controlEnableDisable();
			initLeaveBusinessDays();
            CommonOpUtil.setDateConstraintMaximumToday(dateFieldsPastPresent);
            CommonOpUtil.setDateConstraintMinimumToday(dateFieldsPresentFuture);
			FormAutoComplete.makeAutoCompletion(FormMain.getAutoCompleteOptionForEmployee('PI_CLPD_DECIDING_OFFCL_SEARCH', 'PI_CLPD_DECIDING_OFFCL'));
            CommonOpUtil.dynamicMandatory(reqFieldForActivity);

            initEventHandlers();

            setupCustomWidget();
            /* var payPlan = FormState.getElementValue('PI_DMTN_PRPS_PAY_PLAN');
            if(_.isEmpty(payPlan)){
                CommonOpUtil.showHideLayoutGroup('PI_DMTN_PRPS_STEP', false);
                CommonOpUtil.showHideLayoutGroup('PI_DMTN_PRPS_GRADE', false);
            }else{
                populateGradesByPayPlan('PI_DMTN_PRPS_GRADE', payPlan);
            } */
			
        }

        // manage data population and display of read-only fields and disabled fields since they cannot be controlled by event handler
        var firstRendering = true;

        function render() {
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'erlr_performance_issue::render START');

            var genEmployeeFormState = FormState.getState('GEN_EMPLOYEE');
            var genCaseTypeFormState = FormState.getState('GEN_CASE_TYPE');
            if (genEmployeeFormState && genCaseTypeFormState && (genEmployeeFormState.dirty || genCaseTypeFormState.dirty)) {
                var genCaseTypeSelTxt = $('#GEN_CASE_TYPE option[value="' + genCaseTypeFormState.value + '"]').text();
                if (genCaseTypeSelTxt === 'Performance Issue') {
                    populateNextWgiDueDate();
                    var piActionTypeSelVal = FormState.getElementValue('PI_ACTION_TYPE');
                    var piActionTypeSelTxt = $('#PI_ACTION_TYPE option[value="' + piActionTypeSelVal + '"]').text();
                    if (piActionTypeSelTxt === 'Demotion') {
                        populatePiDemotionCurPosnData();
                    } else if (piActionTypeSelTxt === 'Reassignment') {
                        populatePiReassignCurInfo();
                    }
                }
            }

            PI_PIP_EXT_DT_LIST_group.render();

            var PI_PIP_EXT_DT_LIST = FormState.getState('PI_PIP_EXT_DT_LIST');
            if (PI_PIP_EXT_DT_LIST && PI_PIP_EXT_DT_LIST.dirty) {
                var extDt = FormState.getElementValue('PI_PIP_EXT_DT_LIST');
                try {
                    extDt = JSON.parse(extDt);
                } catch (e) {
                    extDt = null;
                }
                if (typeof extDt === 'undefined' || extDt == null || extDt.length <= 0) {
                    hyf.util.enableComponent('PI_PIP_END_DT');
                } else {
                    hyf.util.disableComponent('PI_PIP_END_DT');
                }
            }

            if (firstRendering || FormState.isDirty('PI_DMTN_PRPS_PAY_PLAN')) {
                var payPlan = FormState.getElementValue('PI_DMTN_PRPS_PAY_PLAN');
                if (_.isEmpty(payPlan)) {
                    CommonOpUtil.showHideLayoutGroup('PI_DMTN_PRPS_GRADE', false);
                    CommonOpUtil.showHideLayoutGroup('PI_DMTN_PRPS_STEP', false);
                } else {
                    populateGradesByPayPlan('PI_DMTN_PRPS_GRADE', payPlan);
                }
            }
            if (firstRendering || FormState.isDirty('PI_DMTN_FIN_PAY_PLAN')) {
                var payPlan = FormState.getElementValue('PI_DMTN_FIN_PAY_PLAN');
                if (_.isEmpty(payPlan)) {
                    CommonOpUtil.showHideLayoutGroup('PI_DMTN_FIN_GRADE', false);
                    CommonOpUtil.showHideLayoutGroup('PI_DMTN_FIN_STEP', false);
                } else {
                    populateGradesByPayPlan('PI_DMTN_FIN_GRADE', payPlan);
                }
            }
            if (firstRendering || FormState.isDirty('PI_PIP_FIN_AGCY_DECISION')) {
                var decision = FormState.getElementValue('PI_PIP_FIN_AGCY_DECISION');
                if (_.isEmpty(decision)) {
                    CommonOpUtil.showHideLayoutGroup('pi_pip_final_decision_date_decision_group', false);
                    CommonOpUtil.showHideLayoutGroup('pi_pip_final_decision_effective_date_group', false);
                } else {
                    if(decision == '1663' || decision == '1664' || decision == '1665'){
                        CommonOpUtil.showHideLayoutGroup('pi_pip_final_decision_date_decision_group', true);
                        CommonOpUtil.showHideLayoutGroup('pi_pip_final_decision_effective_date_group', true);
                    }else if(decision == '1667'){
                        CommonOpUtil.showHideLayoutGroup('pi_pip_final_decision_date_decision_group', true);
                        CommonOpUtil.showHideLayoutGroup('pi_pip_final_decision_effective_date_group', false);
                    }else if(decision == '1666') {
                        CommonOpUtil.showHideLayoutGroup('pi_pip_final_decision_date_decision_group', false);
                        CommonOpUtil.showHideLayoutGroup('pi_pip_final_decision_effective_date_group', false);
                    }
                }
            }
            var state = FormState.getState('PI_PIP_APPEAL_DECISION');
            if(!_.isUndefined(state) && state.dirty){
                var appeal = FormState.getElementBooleanValue('PI_PIP_APPEAL_DECISION', false);
                if(appeal){
                    FormState.updateSelectValue('PI_PIP_EMPL_GRIEVANCE', 'No', 'No', false);
                    $('#PI_PIP_EMPL_GRIEVANCE').val('No');
                    hyf.validation.validateField('PI_PIP_EMPL_GRIEVANCE');
                }
            }

            state = FormState.getState('PI_PIP_EMPL_GRIEVANCE');
            if(_.isUndefined(state)){
                CommonOpUtil.showHideLayoutGroup('pi_pip_empl_grievance_output_group', false);
            }else if(state.dirty){
                var grievance = FormState.getElementBooleanValue('PI_PIP_EMPL_GRIEVANCE', false);
                if (grievance) {
                    FormState.updateSelectValue('PI_PIP_APPEAL_DECISION', 'No', 'No', false);
                    $('#PI_PIP_APPEAL_DECISION').val('No');
                    hyf.validation.validateField('PI_PIP_APPEAL_DECISION');
                }

                CommonOpUtil.showHideLayoutGroup('pi_pip_empl_grievance_output_group', grievance);
            }
			//career ladder
			careerLadder();
			initAdminLeaveDynamic();
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'erlr_performance_issue::render END');
            firstRendering = false;
        }
		function careerLadder() {
            var state = FormState.getState('PI_CLPD_PRE_WITHHELD');
            if(state && state.dirty){
                var val = FormState.getElementBooleanValue('PI_CLPD_PRE_WITHHELD');
                if(_.isUndefined(val)){
                    CommonOpUtil.showHideLayoutGroup('PI_CLPD_NO_PRE_WITHHELD_layout_group', false);
                    CommonOpUtil.showHideLayoutGroup('PI_CLPD_YES_PRE_WITHHELD_layout_group', false);
                }else if(val === true){                
                    CommonOpUtil.showHideLayoutGroup('PI_CLPD_NO_PRE_WITHHELD_layout_group', false);
                    CommonOpUtil.showHideLayoutGroup('PI_CLPD_YES_PRE_WITHHELD_layout_group', true);
                }else{                                 
                    CommonOpUtil.showHideLayoutGroup('PI_CLPD_NO_PRE_WITHHELD_layout_group', true);
                    CommonOpUtil.showHideLayoutGroup('PI_CLPD_YES_PRE_WITHHELD_layout_group', false);
                }
            }
            state = FormState.getState('PI_CLPD_DETER_FAV');
            if(state && state.dirty){
                var val = FormState.getElementBooleanValue('PI_CLPD_DETER_FAV');
                if(_.isUndefined(val)){
                    CommonOpUtil.showHideLayoutGroup('PI_CLPD_NO_DETER_FAV_layout_group', false);
                    CommonOpUtil.showHideLayoutGroup('PI_CLPD_FINAL_DECISION_layout_group', false);
                }else if(val === true){                 
                    CommonOpUtil.showHideLayoutGroup('PI_CLPD_NO_DETER_FAV_layout_group', false);
                    CommonOpUtil.showHideLayoutGroup('PI_CLPD_FINAL_DECISION_layout_group', false);
                }else{                                  
                    CommonOpUtil.showHideLayoutGroup('PI_CLPD_NO_DETER_FAV_layout_group', true);
                    CommonOpUtil.showHideLayoutGroup('PI_CLPD_FINAL_DECISION_layout_group', true);
                }
            }


            state = FormState.getState('PI_CLPD_EMP_APPEAL_DECISION');
            if(state && state.dirty) {
                var appeal = FormState.getElementBooleanValue('PI_CLPD_EMP_APPEAL_DECISION', false);

                if(appeal){
                    FormState.updateSelectValue('PI_CLPD_EMP_GRIEVANCE', 'No', 'No', false);
                    $('#PI_CLPD_EMP_GRIEVANCE').val('No');
                    hyf.validation.validateField('PI_CLPD_EMP_GRIEVANCE');
                }
            }


            state = FormState.getState('PI_CLPD_EMP_GRIEVANCE');
            if(state && state.dirty){
                var grievance = FormState.getElementBooleanValue('PI_CLPD_EMP_GRIEVANCE', false);
                if (grievance) {
                    state.dirty = false;
                    FormState.updateSelectValue('PI_CLPD_EMP_APPEAL_DECISION', 'No', 'No', true);
                    $('#PI_CLPD_EMP_APPEAL_DECISION').val('No');
                    hyf.validation.validateField('PI_CLPD_EMP_APPEAL_DECISION');
                }

                CommonOpUtil.showHideLayoutGroup('PI_CLPD_TRIGGER_GRIEVANCE_layout_group', grievance);
            }

            // Employee Decision Group
            val = FormState.getElementBooleanValue('PI_CLPD_PRE_WITHHELD');
            if(val === false){
                CommonOpUtil.showHideLayoutGroup('PI_CLPD_EMP_DECISION_layout_group', true);
            }else{
                val = FormState.getElementBooleanValue('PI_CLPD_DETER_FAV');
                if(_.isUndefined(val)){
                    CommonOpUtil.showHideLayoutGroup('PI_CLPD_EMP_DECISION_layout_group', false);
                }else{
                    CommonOpUtil.showHideLayoutGroup('PI_CLPD_EMP_DECISION_layout_group', true);
                }
            }

            state = FormState.getState('PI_CLPD_SERVICE_COMP_DT');
            if(state && state.dirty){
                var eod = FormState.getElementValue('PI_CLPD_SERVICE_COMP_DT');
                var nextDue = FormState.getElementValue('PI_CLPD_NEXT_CLP_DUE_DT');
                if(_.isEmpty(nextDue)){
                    var eodDt = new Date(eod);
                    eodDt.setFullYear(eodDt.getFullYear()+1);
                    var nextDueDt = formatDate(eodDt, 'MM/dd/yyyy');
                    $('#PI_CLPD_NEXT_CLP_DUE_DT').val(nextDueDt);
                    FormState.updateDateValue('PI_CLPD_NEXT_CLP_DUE_DT', nextDueDt, false);
                    hyf.validation.validateField('PI_CLPD_NEXT_CLP_DUE_DT');
                }
            }

            state = FormState.getState('PI_CLPD_FIRST_WITHHELD_DT');
            if(state && state.dirty) {
                var dt = FormState.getElementValue('PI_CLPD_FIRST_WITHHELD_DT');
                if(!_.isEmpty(dt)){
                    var minDate = new Date(dt);
                    minDate.setDate(minDate.getDate()-1);
                    var minDateStr = formatDate(minDate, 'MM/dd/yyyy');
                    hyf.calendar.setDateConstraint('PI_CLPD_SECOND_WNI_DT', 'Minimum', minDateStr);
                }else{
                    hyf.calendar.setDateConstraint('PI_CLPD_SECOND_WNI_DT', 'Minimum', '01/01/2000');
                }
            }

            var dt1 = FormState.getElementValue('PI_CLPD_FIRST_WITHHELD_DT');
            var dt2 = FormState.getElementValue('PI_CLPD_SECOND_WNI_DT');
            if (dt2 && dt1) {
                var m1 = new Date(dt1);
                var m2 = new Date(dt2);
                if (m2.getTime() < m1.getTime()) {
                    bootbox.alert({
                        message: 'Date Second Withholding Notice Issued must come after Date Career Ladder Promotion First Withheld.',
                        callback: function () {
                            $('#PI_CLPD_SECOND_WNI_DT').val('');
                            FormState.updateDateValue('PI_CLPD_SECOND_WNI_DT', '', false);
                        }
                    });
                }
            }



            var dt1 = FormState.getElementValue('PI_CLPD_FIRST_WNI_DT');
            var dt2 = FormState.getElementValue('PI_CLPD_DAPI_DT');
            if (dt2 && dt1) {
                var m1 = new Date(dt1);
                var m2 = new Date(dt2);
                if (m2.getTime() < m1.getTime()) {
                    bootbox.alert({
                        message: 'Date Developmental Assistance Plan Issued must come after Date First Withholding Notice Issued.',
                        callback: function () {
                            $('#PI_CLPD_DAPI_DT').val('');
                            FormState.updateDateValue('PI_CLPD_DAPI_DT', '', false);
                        }
                    });
                }
            }
        

        
    }
	
        return {
            initialized: initialized,
            reqFieldForActivity: reqFieldForActivity,
            clearAllContentCustom: clearAllContentCustom,
            render: render,
            init: init,
			careerLadder : careerLadder
        };
    };

    var _initializer = window.cms_perf_issue || (window.cms_perf_issue = cms_perf_issue());
})(window);

 

