(function (window) {
    function cms_erlr_prob_period() {
        var initialized = false;
        var groups = [
            'ppa_termination_type_pre_employment_group',
            'ppa_termination_type_probation_group',
            'ppa_written_response_group',
            'ppa_pre_emp_termination_oral_presentation_group',
            'ppa_pre_emp_termination_response_group',
            'ppa_oral_presentation_date_group',
            'ppa_written_response_group',
            'ppa_pre_emp_termination_oral_presentation_group',
            'ppa_pre_emp_termination_response_group',
            'ppa_reassignment_date_notice_issued',
            'ppa_emp_appeal_decision_group',
            'ppa_action_Demotion_group',
            'ppa_action_Reassignment_group',
            'ppa_action_Termination_group',
            'ppa_termination_type_group',
            'ppa_demo_final_decision_detail_by_agency',
            'ppa_term_final_decision_detail_by_agency',
			'PPA_DEMO_SETTLMNT_AGMNT_group',
			'PPA_TERM_SETTLMNT_AGMNT_group'
        ];
        var actionTypes = [
            'alt_discipline'
        ];
        var grades = {
            'GP': ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15'],
            'GR': ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15'],
            'GS': ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12', '13', '14', '15'],
            'ES': ['01', '02', '03', '04', '05', '06'],
            'WG': ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10']
        };
        var dateFields = [
            'PPA_PROP_ACTION_ISSUED_DT',
            'PPA_ORAL_PREZ_DT',
            'PPA_WRITTEN_RESPONSE_SUBMITTED_DT',
            'PPA_DECISION_ISSUED_DT',
            'PPA_NOTICE_ISSUED_DT',
            'PPA_WRITTEN_RESPONSE_DUE_DT',
            'PPA_WRITTEN_SUBMITTED_DT',
            'PPA_REMOVAL_EFFECTIVE_DT',
            'PPA_TERM_PROP_ACTION_DT',
            'PPA_TERM_ORAL_PREZ_DT',
            'PPA_TERM_WRITTEN_RESP_DT',
            'PPA_TERM_DECISION_ISSUED_DT',
            'PPA_PRE_PROBATION_TERMINATION_DECISION_ISSUED_DT',
            'PPA_REPRIMAND_ISSUE_DT',
            'PPA_PROBATION_TERMINATION_DECISION_ISSUED_DT'
        ];

        var PPAAdminCodeAutoComplete;
		function ppaTermReason(){
			if((ActivityManager.getActivityName() === globalVars.actCaseComplete)){
				$('#ppa_checkbox').show();
				$('#PPA_PROBATION_CONDUCT').attr('_required', 'true');
				$('#PPA_PROBATION_PERFORMANCE').attr('_required', 'true');				
			}else{
				$('#ppa_checkbox').hide();
				$('#PPA_PROBATION_CONDUCT').attr('_required', 'false');
				$('#PPA_PROBATION_PERFORMANCE').attr('_required', 'false');
			}
		}
		function terminationReason(e){
			var activity = ActivityManager.getActivityName();
			if(activity === globalVars.actCaseComplete){
				if($('#PPA_PROBATION_CONDUCT').is(':checked')){
					$('#PPA_PROBATION_PERFORMANCE').attr('_required', 'false');
				}else if($('#PPA_PROBATION_PERFORMANCE').is(':checked')){
					$('#PPA_PROBATION_CONDUCT').attr('_required', 'false');
				}else{
					$('#PPA_PROBATION_CONDUCT').attr('_required', 'true');
					$('#PPA_PROBATION_PERFORMANCE').attr('_required', 'true');
				}
			}	
		}
        function init() {
            groups.forEach(function (el, index) {
                hyf.util.hideComponent(el);
            });
            var reqFieldForActivity =
                [
                    {
                        actName: globalVars.actAll,
                        reqFieldIds:
                            []
                    },
                    {
                        actName: globalVars.actCaseCreation,
                        reqFieldIds:
                            []
                    },
                    {
                        actName: globalVars.actCaseComplete,
                        reqFieldIds:
                            [
                                'PPA_ACTION_TYPE',
                                'PPA_PROP_ACTION_ISSUED_DT',
                                'PPA_EMP_APPEAL_DECISION',
                                'PPA_ORAL_PREZ_REQUESTED',
                                'PPA_ORAL_PREZ_DT',
                                'PPA_ORAL_RESPONSE_SUBMITTED',
                                'PPA_RESPONSE_DUE_DT',
                                'PPA_WRITTEN_RESPONSE_SUBMITTED_DT',
                                'PPA_PROPOSED_POS_TITLE',
                                'PPA_PROPOSED_PPLAN',
                                'PPA_PROPOSED_SERIES',
                                'PPA_PROPOSED_INFO_GRADE',
                                'PPA_PROPOSED_INFO_STEP',
                                'PPA_FINAL_POS_TITLE',
                                'PPA_FINAL_PPLAN',
                                'PPA_FINAL_SERIES',
                                'PPA_FINAL_INFO_GRADE',
                                'PPA_FINAL_INFO_STEP',
                                'PPA_DEMO_FINAL_AGENCY_DECISION',
                                'PPA_DECIDING_OFFCL_SEARCH',
                                'PPA_DECISION_ISSUED_DT',
                                'PPA_DEMO_FINAL_AGENCY_EFF_DT',
                                'PPA_NOTICE_ISSUED_DT',
                                'PPA_EFFECTIVE_DT',
                                'PPA_TERMINATION_TYPE',
                                'PPA_TERM_PROP_ACTION_DT',
                                'PPA_TERM_ORAL_PREZ_REQUESTED',
                                'PPA_TERM_ORAL_PREZ_DT',
                                'PPA_TERM_WRITTEN_RESP',
                                'PPA_TERM_WRITTEN_RESP_DUE_DT',
                                'PPA_TERM_WRITTEN_RESP_DT',
                                'PPA_TERM_AGENCY_DECISION',
                                'PPA_TERM_DECIDING_OFFCL_NAME_SEARCH',
                                'PPA_TERM_DECISION_ISSUED_DT',
                                'PPA_TERM_EFFECTIVE_DECISION_DT',
                                'PPA_FINAL_ADMIN_CODE_SEARCH',
                                'PPA_APPEAL_GRIEVANCE_DEADLINE',
                                'PPA_PROBATION_TERMINATION_DECISION_ISSUED_DT',
                                'PPA_NUMB_DAYS'
                            ]
                    }
                ];

            $('#PPA_ACTION_TYPE').on('change', actionTypeEvent);
            //$('#PPA_TERM_PROP_ACTION_DT,#PPA_DECISION_ISSUED_DT,#PPA_PROP_ACTION_ISSUED_DT').on('change', dateChangeEventConduct);
            $('#PPA_TERMINATION_TYPE').on('change', terminationType);
            $('#PPA_PROPOSED_PPLAN,#PPA_FINAL_PPLAN').on('change', populateGrades);
            $('#PPA_DEMO_FINAL_AGENCY_DECISION,#PPA_TERM_AGENCY_DECISION').on('change', finalAgencyDecision);
			$('#PPA_PROBATION_PERFORMANCE,#PPA_PROBATION_CONDUCT').on('change',terminationReason);
			
            CommonOpUtil.setDateConstraintMaximumToday(dateFields);

            PPAAutoCompleteOptions('PPA_DECIDING_OFFCL');
            PPAAutoCompleteOptions('PPA_TERM_DECIDING_OFFCL_NAME');
            PPAAdminCodeAutoComplete = PPAAdminCodeAutoCompleteOptions('PPA_FINAL_ADMIN_CODE');
            ppaTermReason();
            var name = FormState.getElementValue('PPA_RE_ASSIGNMENT_FINAL_ORG');
            CommonOpUtil.showHideLayoutGroup('ppa_reassignment_final_org_name_group', !_.isEmpty(name));


            CommonOpUtil.dynamicMandatory(reqFieldForActivity);
            populateCIDemotionCurPosnData();
            hyf.util.hideComponent('ppa_action_Demotion_group');
            hyf.util.hideComponent('ppa_action_Reassignment_group');
            hyf.util.hideComponent('ppa_action_Termination_group');

            var payPlan = FormState.getElementValue('PPA_PROPOSED_PPLAN');
            if (_.isEmpty(payPlan)) {
                CommonOpUtil.showHideLayoutGroup('PPA_PROPOSED_INFO_STEP', false);
                CommonOpUtil.showHideLayoutGroup('PPA_PROPOSED_INFO_GRADE', false);
            } else {
                populateGradesByPayPlan('PPA_PROPOSED_INFO_GRADE', payPlan);
            }

            payPlan = FormState.getElementValue('PPA_FINAL_PPLAN');
            if (_.isEmpty(payPlan)) {
                CommonOpUtil.showHideLayoutGroup('PPA_FINAL_INFO_STEP', false);
                CommonOpUtil.showHideLayoutGroup('PPA_FINAL_INFO_GRADE', false);
            } else {
                populateGradesByPayPlan('PPA_FINAL_INFO_GRADE', payPlan);
            }

            populateEmployeeData();

        }

        function render() {
            var actionType = FormState.getState('PPA_ACTION_TYPE');
            var terminationActionType = FormState.getState('PPA_TERMINATION_TYPE');
            if (actionType && actionType.dirty) {
                if (actionType.value === 'Demotion') {
                    CommonOpUtil.showHideLayoutGroup('ppa_action_Demotion_group', true);
                    hyf.util.hideComponent('ppa_action_Reassignment_group');
                    hyf.util.hideComponent('ppa_action_Termination_group');
                    CommonOpUtil.showHideLayoutGroup('ppa_emp_appeal_decision_group', true);
                    hyf.util.hideComponent('ppa_termination_type_group');
                } else if (actionType.value === 'Reassignment') {
                    CommonOpUtil.showHideLayoutGroup('ppa_action_Reassignment_group', true);
                    hyf.util.hideComponent('ppa_action_Demotion_group');
                    hyf.util.hideComponent('ppa_action_Termination_group');
                    CommonOpUtil.showHideLayoutGroup('ppa_emp_appeal_decision_group', true);
                    hyf.util.hideComponent('ppa_termination_type_group');
                } else if (actionType.value === 'Termination') {
                    CommonOpUtil.showHideLayoutGroup('ppa_action_Termination_group', true);
                    hyf.util.hideComponent('ppa_action_Demotion_group');
                    hyf.util.hideComponent('ppa_action_Reassignment_group');
                    CommonOpUtil.showHideLayoutGroup('ppa_emp_appeal_decision_group', true);
                    CommonOpUtil.showHideLayoutGroup('ppa_termination_type_group', true)
                } else {
                    hyf.util.hideComponent('ppa_action_Demotion_group');
                    hyf.util.hideComponent('ppa_action_Reassignment_group');
                    hyf.util.hideComponent('ppa_action_Termination_group');
                    hyf.util.hideComponent('ppa_emp_appeal_decision_group');
                    hyf.util.hideComponent('ppa_termination_type_group')
                }
            }
            if (terminationActionType && terminationActionType.dirty) {
                if (terminationActionType.value === 'pre_emp') {
                    CommonOpUtil.showHideLayoutGroup('ppa_termination_type_pre_employment_group', true);
                    hyf.util.hideComponent('ppa_termination_type_probation_group');
                } else if (terminationActionType.value === 'probation') {
                    CommonOpUtil.showHideLayoutGroup('ppa_termination_type_probation_group', true);
                    hyf.util.hideComponent('ppa_termination_type_pre_employment_group');
                } else {
                    hyf.util.hideComponent('ppa_termination_type_probation_group');
                    hyf.util.hideComponent('ppa_termination_type_pre_employment_group');
                }
            }
            var dmnpFinalAgency = FormState.getElementValue('PPA_DEMO_FINAL_AGENCY_DECISION');
            if (dmnpFinalAgency === 'undefined') {
                finalAgencyDecisionHelper('PPA_DEMO_FINAL_AGENCY_DECISION', dmnpFinalAgency);
            }


            if (FormState.isDirty('PPA_ORAL_PREZ_REQUESTED')) {
                CommonOpUtil.showHideLayoutGroup('ppa_oral_presentation_date_group', FormState.getElementBooleanValue('PPA_ORAL_PREZ_REQUESTED'))
            }
            if (FormState.isDirty('PPA_ORAL_RESPONSE_SUBMITTED')) {
                CommonOpUtil.showHideLayoutGroup('ppa_written_response_group', FormState.getElementBooleanValue('PPA_ORAL_RESPONSE_SUBMITTED'))
            }
            if (FormState.isDirty('PPA_TERM_ORAL_PREZ_REQUESTED')) {
                CommonOpUtil.showHideLayoutGroup('ppa_pre_emp_termination_oral_presentation_group', FormState.getElementBooleanValue('PPA_TERM_ORAL_PREZ_REQUESTED'))
            }
            if (FormState.isDirty('PPA_TERM_WRITTEN_RESP')) {
                CommonOpUtil.showHideLayoutGroup('ppa_pre_emp_termination_response_group', FormState.getElementBooleanValue('PPA_TERM_WRITTEN_RESP'))
            }

            populateEmployeeData();
        }


        function PPAAutoCompleteOptions(id) {
            FormAutoComplete.makeAutoCompletion(FormMain.getAutoCompleteOptionForEmployee(id + '_SEARCH', id));
        }

        function PPAAdminCodeAutoCompleteOptions(id) {
            var optionConfig = {
                id: id + '_SEARCH',
                baseURL: '/bizflowwebmaker/StratCon_AUT',
                targetURL: '/bizflowwebmaker/StratCon_AUT/SearchAdmOffOrg.do?searchAdmOff=',
                minLength: 2,
                minSelectionCount: 0,
                maxSelectionCount: 1,
                mapFunction: function (context) {
                    return {
                        id: $("AC_ADMIN_CD", context).text(),
                        adminCd: $("AC_ADMIN_CD", context).text(),
                        adminCdDesc: $("AC_ADMIN_CD_DESCR", context).text(),
                        value: $("AC_ADMIN_CD", context).text()
                    };
                },
                getSelectionLabel: function (item) {
                    return item.adminCd;
                },
                getCandidateLabel: function (item) {
                    return item.adminCd + ' - ' + item.adminCdDesc;
                },
                getItemID: function (item) {
                    return item.id;
                },
                setDataToForm: function (values) {
                    if (typeof values == 'undefined' || values == null) return;
                    var item = null;
                    if ($.isArray(values)) {
                        item = values[0];
                    } else {
                        item = values;
                    }

                    if (typeof item === 'object' && item != null
                        && typeof item.adminCd != 'undefined' && item.adminCd != null && item.adminCd.trim().length > 0
                        && typeof item.adminCdDesc != 'undefined' && item.adminCdDesc != null && item.adminCdDesc.trim().length > 0) {
                        CommonOpUtil.showHideLayoutGroup('ppa_reassignment_final_org_name_group', true);
                        $('#PPA_RE_ASSIGNMENT_FINAL_ORG').text(item.adminCdDesc);
                        FormState.updateObjectValue('PPA_FINAL_ADMIN_CODE', values);
                        FormState.updateVariableValue('PPA_RE_ASSIGNMENT_FINAL_ORG', item.adminCdDesc, false);
                    } else {
                        CommonOpUtil.showHideLayoutGroup('ppa_reassignment_final_org_name_group', false);
                        $('#PPA_RE_ASSIGNMENT_FINAL_ORG').text('');
                        FormState.updateObjectValue('PPA_FINAL_ADMIN_CODE', []);
                        FormState.updateVariableValue('PPA_RE_ASSIGNMENT_FINAL_ORG', '', false);
                    }
                },
                // initialize
                initialItems: FormState.getElementArrayValue(id, []),
            };
            return FormAutoComplete.makeAutoCompletion(optionConfig);
        }

        function PPADecidingOfficeNameAutoCompleteOptions(id) {//TODO: make AutoCompletion work
            var optionConfig = {
                id: '_SEARCH',
                baseURL: '/bizflowwebmaker/StratCon_AUT',
                targetURL: '/bizflowwebmaker/StratCon_AUT/SearchAdmOffOrg.do?searchString=',
                minLength: 2,
                minSelectionCount: 0,
                maxSelectionCount: 1,
                mapFunction: function (context) {
                    return {
                        id: $("AC_ADMIN_CD", context).text(),
                        adminCd: $("AC_ADMIN_CD", context).text(),
                        adminCdDesc: $("AC_ADMIN_CD_DESCR", context).text(),
                        value: $("AC_ADMIN_CD", context).text()
                    };
                },
                getSelectionLabel: function (item) {
                    return item.adminCd;
                },
                getCandidateLabel: function (item) {
                    return item.adminCd + ' - ' + item.adminCdDesc;
                },
                getItemID: function (item) {
                    return item;
                },
                setDataToForm: function (values) {
                    if (typeof values == 'undefined' || values == null) return;
                    var item = undefined;
                    if ($.isArray(values)) {
                        item = values[0];
                    } else {
                        item = values;
                    }

                    if (typeof item === 'object' && typeof item.value != 'undefined') {
                        FormState.updateObjectValue(id, item.adminCd, false);
                        FormState.updateObjectValue(id + '_SEARCH', item.adminCd, false);
                    } else {
                        FormState.updateObjectValue(id, '', false);
                        FormState.updateObjectValue(id + '_SEARCH', '', false);
                    }
                },
                // initialize
                initialItems: FormState.getElementArrayValue(id, []),
            };
            FormAutoComplete.makeAutoCompletion(optionConfig);
        }

        function dateChangeEventConduct(e) {
            var id = e.target.id;
            var dt1 = '';
            var dt2 = '';
            switch (id) {
                case 'PPA_TERM_PROP_ACTION_DT':
                    dateValidateHelper('PPA_TERM_PROP_ACTION_DT', 'PPA_TERM_DECISION_ISSUED_DT', 'PPA_TERM_DECISION_ISSUED_DT');
                    break;
                case 'PPA_DECISION_ISSUED_DT':
                    dateValidateHelper('PPA_DECISION_ISSUED_DT', 'PPA_PROPOSE_ACTION_ISSUED_DT', 'PPA_PROP_ACTION_ISSUED_DT');
                    break;
            }

        }

        function clearAll() {
            CommonOpUtil.clearGroupContent('ppa_emp_appeal_decision_group');
        }

        function terminationType(e) {
            var val;
            try {
                val = e.target.options[e.target.options.selectedIndex].value;
                if (val === 'pre_emp') {
                    CommonOpUtil.showHideLayoutGroup('ppa_termination_type_pre_employment_group', true);
                    CommonOpUtil.showHideLayoutGroup('ppa_termination_type_probation_group');
                    clearAll();
                } else if (val === 'probation') {
                    CommonOpUtil.showHideLayoutGroup('ppa_termination_type_probation_group', true);
                    CommonOpUtil.showHideLayoutGroup('ppa_termination_type_pre_employment_group');
                    clearAll();
                } else {
                    CommonOpUtil.showHideLayoutGroup('ppa_termination_type_pre_employment_group');
                    CommonOpUtil.showHideLayoutGroup('ppa_termination_type_probation_group');
                    clearAll();
                }
            } catch (err) {

            }

            $('#ppa_action_Termination_group input').val('');
            $('#ppa_action_Termination_group input[type=checkbox]').prop('checked', false);
            $('#ppa_action_Termination_group select').not('#PPA_TERMINATION_TYPE').val('');
            $('#ppa_pre_emp_termination_oral_presentation_group').hide();
            $('#ppa_pre_emp_termination_response_group').hide();
        }

        function actionTypeEvent(e) {
            var val = '';
            try {
                val = e.target.options[e.target.options.selectedIndex].value;
                if (val === 'Demotion') {
                    CommonOpUtil.showHideLayoutGroup('ppa_action_Demotion_group', true);
                    CommonOpUtil.showHideLayoutGroup('ppa_action_Reassignment_group');
                    CommonOpUtil.showHideLayoutGroup('ppa_action_Termination_group');
                } else if (val === 'Reassignment') {
                    CommonOpUtil.showHideLayoutGroup('ppa_action_Reassignment_group', true);
                    CommonOpUtil.showHideLayoutGroup('ppa_action_Demotion_group');
                    CommonOpUtil.showHideLayoutGroup('ppa_action_Termination_group');
                } else if (val === 'Termination') {
                    CommonOpUtil.showHideLayoutGroup('ppa_action_Termination_group', true);
                    CommonOpUtil.showHideLayoutGroup('ppa_action_Demotion_group');
                    CommonOpUtil.showHideLayoutGroup('ppa_action_Reassignment_group');
                } else {
                    CommonOpUtil.showHideLayoutGroup('ppa_action_Demotion_group');
                    CommonOpUtil.showHideLayoutGroup('ppa_action_Reassignment_group');
                    CommonOpUtil.showHideLayoutGroup('ppa_action_Termination_group');
                }
                clearAll();
				$('PPA_TERM_SETTLMNT_AGMNT').val('');
				$('PPA_DMTN_SETTLMNT_AGMNT').val('');
				CommonOpUtil.showHideLayoutGroup('PPA_TERM_SETTLMNT_AGMNT_group', false);
				CommonOpUtil.showHideLayoutGroup('PPA_DEMO_SETTLMNT_AGMNT_group', false);
                /* if (val&& val !== undefined) {
                    $('#PPA_EMP_APPEAL_DECISION').val('');
                    FormState.updateObjectValue('PPA_EMP_APPEAL_DECISION', '');
                    if (val !== '' && actions.includes(value2)) {
                        CommonOpUtil.showHideLayoutGroup('emp_appeal_decision_group', true);
                    } else {
                        CommonOpUtil.showHideLayoutGroup('emp_appeal_decision_group');
                    }
                    $('#conduct_issue_layout input[type="text"]').val('');
                    $('#conduct_issue_layout input[type="checkbox"]').prop('checked', false);
                    $('#conduct_issue_layout select[id!="PPA_ACTION_TYPE"]').val('');
                } */
            } catch (err) {
            }
        }

        function appendAdminCode(item) {
            var admin_code = item.adminCode + ' - ' + item.description;
            return '<a role="option">' + admin_code + '</a>'
        }

        function populateAdminCode(item) {
            $('#PPA_FINAL_ADMIN_CODE').val(item.adminCode);
            $('#PPA_RE_ASSIGNMENT_FINAL_ORG').text(item.description);
        }


        function dateAutoPopulate(targetId, sourceValue) {
            if (sourceValue !== '') {
                $('#' + targetId).val(sourceValue);
            }
        }


        function populateGrades(e) {
            var source = e.target.id;
            var target = '';
            var payPlan = e.target.options[e.target.options.selectedIndex].value;

            if (source === 'PPA_PROPOSED_PPLAN') {
                target = 'PPA_PROPOSED_INFO_GRADE';
            } else {
                target = 'PPA_FINAL_INFO_GRADE';
            }

            populateGradesByPayPlan(target, payPlan);
        }

        function populateGradesByPayPlan(target, payPlan) {
            var showGradeStepField = false;
            $('#' + target).html('');
            if (payPlan !== 'default' && PayPlanGrade[payPlan] !== undefined) {
                $('#' + target).append('<option value="default">Select one </option>');
                PayPlanGrade[payPlan].forEach(function (val) {
                    $('#' + target).append('<option value="' + val + '">' + val + '</option>');
                });

                CommonOpUtil.showHideLayoutGroup(target, true);
                showGradeStepField = true;
            } else {
                CommonOpUtil.showHideLayoutGroup(target, false, false);
            }

            if (target === 'PPA_PROPOSED_INFO_GRADE') {
                CommonOpUtil.showHideLayoutGroup('PPA_PROPOSED_INFO_STEP', showGradeStepField);
                CommonOpUtil.showHideLayoutGroup('PPA_PROPOSED_INFO_GRADE', showGradeStepField);
            } else if (target === 'PPA_FINAL_INFO_GRADE') {
                CommonOpUtil.showHideLayoutGroup('PPA_FINAL_INFO_STEP', showGradeStepField);
                CommonOpUtil.showHideLayoutGroup('PPA_FINAL_INFO_GRADE', showGradeStepField);
            }
        }

        function populateEmployeeData() {
            var genEmployee = FormState.getElementJSONValue('GEN_EMPLOYEE');
            if (_.isEmpty(genEmployee)){
                $('#PPA_POS_TITLE').text('');
                $('#PPA_PPLAN').text('');
                $('#PPA_SERIES').text('');
                $('#PPA_CURRENT_INFO_STEP').text('');
                $('#PPA_CURRENT_INFO_GRADE').text('');
                CommonOpUtil.showHideLayoutGroup('PPA_CURRENT_INFO_STEP', false);
                CommonOpUtil.showHideLayoutGroup('PPA_CURRENT_INFO_GRADE', false);

                FormState.updateVariableValue('PPA_POS_TITLE', '', false);
                FormState.updateVariableValue('PPA_PPLAN', '', false);
                FormState.updateVariableValue('PPA_SERIES', '', false);
                FormState.updateVariableValue('PPA_CURRENT_INFO_STEP', '', false);
                FormState.updateVariableValue('PPA_CURRENT_INFO_GRADE', '', false);

                $('#PPA_CURRENT_ADMIN_CODE').text('');
                $('#PPA_RE_ASSIGNMENT_CURR_ORG').text('');
                FormState.updateTextValue('PPA_CURRENT_ADMIN_CODE', '', false);
                FormState.updateTextValue('PPA_RE_ASSIGNMENT_CURR_ORG', '', false);
                $('#PPA_FINAL_ADMIN_CODE_SEARCH').val('');
                PPAAdminCodeAutoComplete.deleteAllItems();
            }else{
                $('#PPA_POS_TITLE').text(genEmployee.positionTitle);
                $('#PPA_PPLAN').text(genEmployee.payPlan);
                $('#PPA_SERIES').text(genEmployee.series);
                $('#PPA_CURRENT_INFO_STEP').text(genEmployee.grade);
                $('#PPA_CURRENT_INFO_GRADE').text(genEmployee.step);
                CommonOpUtil.showHideLayoutGroup('PPA_CURRENT_INFO_STEP', !_.isEmpty(genEmployee.step));
                CommonOpUtil.showHideLayoutGroup('PPA_CURRENT_INFO_GRADE', !_.isEmpty(genEmployee.grade));

                FormState.updateVariableValue('PPA_POS_TITLE', genEmployee.positionTitle, false);
                FormState.updateVariableValue('PPA_PPLAN', genEmployee.payPlan, false);
                FormState.updateVariableValue('PPA_SERIES', genEmployee.series, false);
                FormState.updateVariableValue('PPA_CURRENT_INFO_STEP', genEmployee.grade, false);
                FormState.updateVariableValue('PPA_CURRENT_INFO_GRADE', genEmployee.step, false);

                $('#PPA_CURRENT_ADMIN_CODE').text(genEmployee.adminCode);
                $('#PPA_RE_ASSIGNMENT_CURR_ORG').text(genEmployee.adminCodeDesc);
                FormState.updateTextValue('PPA_CURRENT_ADMIN_CODE', genEmployee.adminCode, false);
                FormState.updateTextValue('PPA_RE_ASSIGNMENT_CURR_ORG', genEmployee.adminCodeDesc, false);
            }
        }

//TODO: dynamically hide/show fields based on
        function finalAgencyDecision(e) {
            var id = '';
            var value;
            try {
                id = e.target.id;
                value = e.target.options[e.target.options.selectedIndex].value;
                finalAgencyDecisionHelper(id, value);
            } catch (err) {

            }
        }

        function finalAgencyDecisionHelper(id, value) {
            if (id === 'PPA_DEMO_FINAL_AGENCY_DECISION') {
                if (value === 'Demotion Upheld' || value === 'Reassignment' || value === 'Reprimand' || value === 'Written Counseling') {
                    CommonOpUtil.showHideLayoutGroup('ppa_demo_final_decision_detail_by_agency', true);
                    CommonOpUtil.showHideLayoutGroup('ppa_demo_final_decision_effdt_group', true);
                    CommonOpUtil.showHideLayoutGroup('ppa_demo_final_decision_suspend_days_group', false);
					CommonOpUtil.showHideLayoutGroup('PPA_DEMO_SETTLMNT_AGMNT_group', false);
                } else if (value === 'Demotion Rescinded') {
                    CommonOpUtil.showHideLayoutGroup('ppa_demo_final_decision_detail_by_agency', true);
                    CommonOpUtil.showHideLayoutGroup('ppa_demo_final_decision_effdt_group', false);
                    CommonOpUtil.showHideLayoutGroup('ppa_demo_final_decision_suspend_days_group', false);
					CommonOpUtil.showHideLayoutGroup('PPA_DEMO_SETTLMNT_AGMNT_group', false);
                } else if (value === 'Suspension') {
                    CommonOpUtil.showHideLayoutGroup('ppa_demo_final_decision_detail_by_agency', true);
                    CommonOpUtil.showHideLayoutGroup('ppa_demo_final_decision_effdt_group', true);
                    CommonOpUtil.showHideLayoutGroup('ppa_demo_final_decision_suspend_days_group', true);
					CommonOpUtil.showHideLayoutGroup('PPA_DEMO_SETTLMNT_AGMNT_group', false);
                } else if (value === 'Settlement Agreement') {
                    CommonOpUtil.showHideLayoutGroup('ppa_demo_final_decision_detail_by_agency', false);
                    CommonOpUtil.showHideLayoutGroup('ppa_demo_final_decision_effdt_group', false);
                    CommonOpUtil.showHideLayoutGroup('ppa_demo_final_decision_suspend_days_group', false);
                    CommonOpUtil.showHideLayoutGroup('PPA_DEMO_SETTLMNT_AGMNT_group', true);
                } else {
                    // default or No Action Taken
                    CommonOpUtil.showHideLayoutGroup('ppa_demo_final_decision_detail_by_agency', false);
                    CommonOpUtil.showHideLayoutGroup('ppa_demo_final_decision_effdt_group', false);
                    CommonOpUtil.showHideLayoutGroup('ppa_demo_final_decision_suspend_days_group', false);
                }
            }
            else if (id === 'PPA_TERM_AGENCY_DECISION') {
                if (value === 'Termination Upheld') {
                    CommonOpUtil.showHideLayoutGroup('ppa_term_final_decision_detail_by_agency', true);
                    CommonOpUtil.showHideLayoutGroup('ppa_term_final_decision_effdt_group', true);
                    CommonOpUtil.showHideLayoutGroup('ppa_term_final_decision_suspend_days_group', false);
					CommonOpUtil.showHideLayoutGroup('PPA_TERM_SETTLMNT_AGMNT_group', false);
                } else if (value === 'Termination Rescinded') {
                    CommonOpUtil.showHideLayoutGroup('ppa_term_final_decision_detail_by_agency', true);
                    CommonOpUtil.showHideLayoutGroup('ppa_term_final_decision_effdt_group', false);
                    CommonOpUtil.showHideLayoutGroup('ppa_term_final_decision_suspend_days_group', false);
					CommonOpUtil.showHideLayoutGroup('PPA_TERM_SETTLMNT_AGMNT_group', false);
                } else if (value === 'Settlement Agreement') {
                    CommonOpUtil.showHideLayoutGroup('ppa_term_final_decision_detail_by_agency', false);
                    CommonOpUtil.showHideLayoutGroup('ppa_term_final_decision_effdt_group', false);
                    CommonOpUtil.showHideLayoutGroup('ppa_term_final_decision_suspend_days_group', false);
					CommonOpUtil.showHideLayoutGroup('PPA_TERM_SETTLMNT_AGMNT_group', true);
                } else {
                    // default or No Action Taken
                    CommonOpUtil.showHideLayoutGroup('ppa_term_final_decision_detail_by_agency', false);
                    CommonOpUtil.showHideLayoutGroup('ppa_term_final_decision_effdt_group', false);
                    CommonOpUtil.showHideLayoutGroup('ppa_term_final_decision_suspend_days_group', false);
                }
            }

        }

        return {
            init: init,
            render: render
        }
    }

    (window.cms_erlr_prob_period != undefined ? window.cms_erlr_prob_period : (window.cms_erlr_prob_period = cms_erlr_prob_period()));
})
(window)