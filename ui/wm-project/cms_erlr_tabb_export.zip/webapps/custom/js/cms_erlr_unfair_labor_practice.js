'use strict';
(function (window) {
    var cms_erlr_unfair_labor_practice = function () {

        var initialized = false;

        var dateFieldsPastPresent =
            [
                'ULP_DOCUMENT_SUBMISSION_FLRA_DT',
                'ULP_EXCEPTION_FILED_DT',
                'ULP_AGENCY_ANSWER_FILED_DT'
            ];

        var dateFieldsPresentFuture =
            [];

        var reqFieldForActivity =
            [
                {
                    actName: globalVars.actAll,
                    reqFieldIds:
                        []
                },
                {
                    actName: globalVars.actCaseCreation,
                    reqFieldIds:
                        []
                },
                {
                    actName: globalVars.actCaseComplete,
                    reqFieldIds:
                        [
                            'ULP_RECEIPT_CHARGE_DT',
                            'ULP_FLRA_DOCUMENT_REUQESTED',
                            'ULP_DOCUMENT_SUBMISSION_FLRA_DT',
                            'ULP_DISPOSITION_DT',
                            'ULP_DISPOSITION_TYPE',
                            'ULP_EXCEPTION_FILED',
                            'ULP_EXCEPTION_FILED_DT',
                            'ULP_COMPLAINT_DT',
                            'ULP_AGENCY_ANSWER_DT',
                            'ULP_AGENCY_ANSWER_FILED_DT',
                            'ULP_HEARING_DT',
                            'ULP_DECISION_DT'
                        ]
                }
            ];

        function initVisibility() {
            controlFLRADocumentVisibility();
            controlHearingInfoVisibility();
            controlExceptionVisibility();
            controlExceptionDateVisibility();
        }

        function setSelectElemValue(selElem) {
            if (typeof selElem == 'undefined' || selElem == null
                || typeof selElem.id == 'undefined' || selElem.id == null
                || typeof selElem.options == 'undefined' || selElem.options == null) {
                return;
            }
            var selectedVal = selElem.options[selElem.options.selectedIndex].value;
            var selectedTxt = selElem.options[selElem.options.selectedIndex].text;
            FormState.updateSelectValue(selElem.id, selectedVal, selectedTxt);
        }

        function controlHearingInfoVisibility() {
            var elemVal = FormState.getElementValue('ULP_DISPOSITION_TYPE');
            CommonOpUtil.showHideLayoutGroup('ulp_hearing_info_layout_frame', (elemVal === 'Complaint'));
            CommonOpUtil.clearGroupContent('ulp_hearing_info_layout');
            CommonOpUtil.clearGroupContent('ulp_exception_layout');
        }

        function controlFLRADocumentVisibility() {
            var elemVal = FormState.getElementValue('ULP_FLRA_DOCUMENT_REUQESTED');
            CommonOpUtil.showHideLayoutGroup('ulp_flra_document_layout', (elemVal === 'Yes'));
            CommonOpUtil.clearGroupContent('ulp_flra_document_layout');
        }

        function controlExceptionDateVisibility() {
            var elemVal = FormState.getElementValue('ULP_EXCEPTION_FILED');
            CommonOpUtil.showHideLayoutGroup('ulp_exception_date_layout', (elemVal === 'Yes'));
            CommonOpUtil.clearGroupContent('ulp_exception_date_layout');
        }

        function controlExceptionVisibility() {
            var elemVal = FormState.getElementValue('ULP_DISPOSITION_TYPE');
            CommonOpUtil.showHideLayoutGroup('ulp_exception_layout', (elemVal === 'Complaint' || elemVal === 'Dismissal' || elemVal === 'Withdrawal'));
            CommonOpUtil.clearGroupContent('ulp_exception_layout');
        }

        function initEventHandlers() {
            $('#ULP_DISPOSITION_TYPE').on('change', function (e) {
                setSelectElemValue(e.target);
                controlHearingInfoVisibility();
                controlExceptionVisibility();
            });
            $('#ULP_FLRA_DOCUMENT_REUQESTED').on('change', function (e) {
                setSelectElemValue(e.target);
                controlFLRADocumentVisibility();
            });
            $('#ULP_EXCEPTION_FILED').on('change', function (e) {
                setSelectElemValue(e.target);
                controlExceptionDateVisibility();
            });
        }

        function setupCustomWidget() {
        }


        function init() {
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_unfair_labor_practice::init START');

            //-----------------------------------
            // visibility configuration
            //-----------------------------------
            initVisibility();


            //-----------------------------------
            // validation configuration
            //-----------------------------------
            CommonOpUtil.setDateConstraintMaximumToday(dateFieldsPastPresent);
            CommonOpUtil.setDateConstraintMinimumToday(dateFieldsPresentFuture);
            CommonOpUtil.dynamicMandatory(reqFieldForActivity);


            //-----------------------------------
            // event handler configuration
            //-----------------------------------
            initEventHandlers();


            //-----------------------------------
            // custom ui element initialization
            //-----------------------------------
            setupCustomWidget();

            initialized = true;
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_unfair_labor_practice::init END');
        }

        function render() {
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_unfair_labor_practice::render START');

            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_unfair_labor_practice::render END');
        }

        return {
            initialized: initialized,
            render: render,
            init: init
        };
    };

    var _initializer = window.cms_erlr_unfair_labor_practice || (window.cms_erlr_unfair_labor_practice = cms_erlr_unfair_labor_practice());
})(window);
