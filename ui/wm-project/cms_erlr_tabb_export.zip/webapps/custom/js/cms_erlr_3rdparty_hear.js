(function (window) {
    function cms_erlr_3rdparty_hear() {
        initialized = false;
        var reqFieldForActivity =
            [
                {
                    actName: globalVars.actAll,
                    reqFieldIds:
                        []
                },
                {
                    actName: globalVars.actCaseCreation,
                    reqFieldIds:
                        []
                },
                {
                    actName: globalVars.actCaseComplete,
                    reqFieldIds:
                        [
                            'THRD_PRTY_APPEAL_TYPE',
                            'THRD_PRTY_APPEAL_FILE_DT',
                            'THRD_PRTY_ASSISTANCE_REQ_DT',
                            'THRD_PRTY_HEARING_TIMING',
                            'THRD_PRTY_HEARING_REQUESTED',
                            'THRD_PRTY_STEP_DECISION_DT',
                            'THRD_PRTY_ARBITRATION_INVOKED',
                            'THRD_PRTY_ARBITRATOR_LAST_NAME',
                            'THRD_PRTY_ARBITRATOR_FIRST_NAME',
                            'THRD_PRTY_ARBITRATOR_MIDDLE_NAME',
                            'THRD_PRTY_ARBITRATOR_EMAIL',
                            'THRD_ERLR_ARBITRATOR_PHONE_NUMBER',
                            'THRD_PRTY_ARBITRATION_ORGANIZATION_AFFILIATION',
                            'THRD_PRTY_ARBITRATION_MAILING_ADDR',
                            'THRD_PRTY_ARBITRATOR_LAST_NAME_3',
                            'THRD_PRTY_ARBITRATOR_FIRST_NAME_3',
                            'THRD_PRTY_ARBITRATOR_MIDDLE_NAME_3',
                            'THRD_PRTY_ARBITRATOR_EMAIL_3',
                            'THRD_ERLR_ARBITRATOR_PHONE_NUMBER_3',
                            'THRD_PRTY_ARBITRATION_ORGANIZATION_AFFILIATION_3',
                            'THRD_PRTY_ARBITRATION_MAILING_ADDR_3',
                            'THRD_PRTY_ARBITRATOR_LAST_NAME_4',
                            'THRD_PRTY_ARBITRATOR_FIRST_NAME_4',
                            'THRD_PRTY_ARBITRATOR_MIDDLE_NAME_4',
                            'THRD_PRTY_ARBITRATOR_EMAIL_4',
                            'THRD_ERLR_ARBITRATOR_PHONE_NUMBER_4',
                            'THRD_PRTY_ARBITRATION_ORGANIZATION_AFFILIATION_4',
                            'THRD_PRTY_ARBITRATION_MAILING_ADDR_4',
                            'THRD_PRTY_EXCEPTION_FILED_2',
                            'THRD_PRTY_EXCEPTION_FILE_DT_2',
                            'THRD_PRTY_RESPONSE_TO_EXCEPTIONS_DUE_2',
                            'THRD_PRTY_FINAL_FLRA_DECISION_DT_2',
                            'THRD_PRTY_EXCEPTION_FILE_DT',
                            'THRD_PRTY_FINAL_FLRA_DECISION_DT',
                            'THRD_PRTY_DT_SETTLEMENT_DISCUSSION',
                            'THRD_PRTY_DT_PREHEARING_DISCLOSURE',
                            'THRD_PRTY_DT_AGENCY_FILE_RESPONSE_DUE',
                            'THRD_PRTY_WAS_DISCOVERY_INITIATED',
                            'THRD_PRTY_DT_DISCOVERY_DUE',
                            'THRD_PRTY_INITIAL_DECISION_DT_MSPB',
                            'THRD_PRTY_WAS_PETITION_FILED_MSPB',
                            'THRD_PRTY_FINAL_BOARD_DECISION_DT_MSPB',
                            'THRD_PRTY_TIMELY_REQ',
                            'THRD_PRTY_PROC_ORDER_SEL',
							'THRD_PRTY_PETITION_RV_DT',
							'THRD_PRTY_MSPB_DT2',
							'THRD_PRTY_FINAL_ARBITRATOR_DECISION_DT',
							'THRD_PRTY_EXCEPTION_FILED',
							'THRD_PRTY_RESPONSE_TO_EXCEPTIONS_DUE'
                        ]
                }
            ];

        var dateFields = [
            'THRD_PRTY_PREHEARING_DT',
            'THRD_PRTY_HEARING_DT',
            'THRD_PRTY_POSTHEARING_BRIEF_DUE',
            'THRD_PRTY_FINAL_ARBITRATOR_DECISION_DT',
            'THRD_PRTY_EXCEPTION_FILE_DT',
            'THRD_PRTY_RESPONSE_TO_EXCEPTIONS_DUE',
            'THRD_PRTY_FINAL_FLRA_DECISION_DT',
            'THRD_PRTY_PREHEARING_DT_2',
            'THRD_PRTY_HEARING_DT_2',
            'THRD_PRTY_POSTHEARING_BRIEF_DUE_2',
            'THRD_PRTY_FINAL_ARBITRATOR_DECISION_DT_2',
            'THRD_PRTY_EXCEPTION_FILE_DT_2',
            'THRD_PRTY_FINAL_FLRA_DECISION_DT_2',
            'THRD_PRTY_DT_SETTLEMENT_DISCUSSION',
            'THRD_PRTY_DT_AGENCY_FILE_RESPONSE_DUE',
            'THRD_PRTY_PREHEARING_DT_MSPB',
            'THRD_PRTY_DT_DISCOVERY_DUE',
            'THRD_PRTY_HEARING_DT_MSPB',
            'THRD_PRTY_INITIAL_DECISION_DT_MSPB',
            'THRD_PRTY_FINAL_BOARD_DECISION_DT_MSPB',
            'THRD_PRTY_PETITION_RV_DT',
			'THRD_PRTY_MSPB_DT2',
			'THRD_PRTY_ASSISTANCE_REQ_DT',
			'THRD_PRTY_APPEAL_FILE_DT',
			'THRD_PRTY_STEP_DECISION_DT',
			'THRD_PRTY_DT_SETTLEMENT_DISCUSSION_2',
			'THRD_PRTY_DT_PREHEARING_DISCLOSURE_2',
			'THRD_PRTY_PREHEARING_CONF',
			'THRD_PRTY_DECISION_DT_FLRA',
			'THRD_PRTY_HEARING_DT_FLRA'
        ];

        function init() {
            CommonOpUtil.showHideLayoutGroup('thrd_prty_Exception_info_group');
            CommonOpUtil.showHideLayoutGroup('thrd_prty_Exception_info_group_2');
            CommonOpUtil.showHideLayoutGroup('thrd_prty_discovery_due_group');
            CommonOpUtil.showHideLayoutGroup('thrd_prty_questions_group');
            CommonOpUtil.showHideLayoutGroup('THRD_PRTY_ASSISTANCE_REQ_DT_group');
            CommonOpUtil.showHideLayoutGroup('THRD_PRTY_APPEAL_FILE_DT_group');
            CommonOpUtil.showHideLayoutGroup('thrd_prty_petition_review_date_group');
            $('#THRD_PRTY_APPEAL_TYPE').on('change', appealTypeEvent);
            $('#thrd_prty_group select,#thrd_prty_group input[type="text"]').on('change', updateEvent);
            var appealType = FormState.getElementValue('THRD_PRTY_APPEAL_TYPE');
            layoutByAppealType(appealType);
            thirdPartyHearingProcdureOrderOptions('THRD_PRTY_PROC_ORDER');
            hyf.calendar.setDateConstraint('THRD_PRTY_ASSISTANCE_REQ_DT', 'Maximum', 'Today');
            CommonOpUtil.setDateConstraintMaximumToday(dateFields);

            CommonOpUtil.showHideLayoutGroup('thrd_prty_Arbitration_group_Grievance', FormState.getElementBooleanValue('THRD_PRTY_ARBITRATION_INVOKED') );
            CommonOpUtil.showHideLayoutGroup('thrd_prty_Exception_info_group', FormState.getElementBooleanValue('THRD_PRTY_EXCEPTION_FILED') );
            CommonOpUtil.showHideLayoutGroup('thrd_prty_Exception_info_group_2', FormState.getElementBooleanValue('THRD_PRTY_EXCEPTION_FILED_2') );
            CommonOpUtil.showHideLayoutGroup('thrd_prty_discovery_due_group', FormState.getElementBooleanValue('THRD_PRTY_WAS_DISCOVERY_INITIATED') );
            CommonOpUtil.showHideLayoutGroup('thrd_prty_petition_review_date_group', FormState.getElementBooleanValue('THRD_PRTY_WAS_PETITION_FILED_MSPB') );

            CommonOpUtil.dynamicMandatory(reqFieldForActivity);
        }

        function render() {

        }

        function layoutByAppealType(appealType) {
            if (appealType && appealType !== 'undefined') {
                if (appealType === 'Arbitration') {
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_Arbitration_group', true);
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_questions_group', true);
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_FSIP_group');
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_Grievance_group');
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_MSPB_group');
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_FLRA_group');
                    CommonOpUtil.showHideLayoutGroup('THRD_PRTY_ASSISTANCE_REQ_DT_group');
                    CommonOpUtil.showHideLayoutGroup('THRD_PRTY_APPEAL_FILE_DT_group', true);
                }
                else if (appealType === 'FSIP') {
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_Arbitration_group');
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_FSIP_group', true);
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_Grievance_group');
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_questions_group');
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_MSPB_group');
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_FLRA_group');
                    CommonOpUtil.showHideLayoutGroup('THRD_PRTY_ASSISTANCE_REQ_DT_group', true);
                    CommonOpUtil.showHideLayoutGroup('THRD_PRTY_APPEAL_FILE_DT_group', false);
                }
                else if (appealType === 'Grievance') {
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_Arbitration_group');
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_FSIP_group');
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_Grievance_group', true);
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_questions_group', true);
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_FLRA_group');
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_MSPB_group');
                    CommonOpUtil.showHideLayoutGroup('THRD_PRTY_ASSISTANCE_REQ_DT_group', false);
                    CommonOpUtil.showHideLayoutGroup('THRD_PRTY_APPEAL_FILE_DT_group', true);
                }
                else if (appealType === 'MSPB') {
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_Arbitration_group');
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_FSIP_group');
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_Grievance_group');
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_FLRA_group');
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_MSPB_group', true);
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_questions_group', true);
                    CommonOpUtil.showHideLayoutGroup('THRD_PRTY_ASSISTANCE_REQ_DT_group', false);
                    CommonOpUtil.showHideLayoutGroup('THRD_PRTY_APPEAL_FILE_DT_group', true);
                }
                else if (appealType === 'FLRA') {
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_Arbitration_group');
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_FSIP_group');
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_Grievance_group');
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_MSPB_group');
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_FLRA_group', true);
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_questions_group', true);
                    CommonOpUtil.showHideLayoutGroup('THRD_PRTY_ASSISTANCE_REQ_DT_group', false);
                    CommonOpUtil.showHideLayoutGroup('THRD_PRTY_APPEAL_FILE_DT_group', true);
                }
                else {
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_Arbitration_group');
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_FSIP_group');
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_Grievance_group');
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_MSPB_group');
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_FLRA_group');
                    CommonOpUtil.showHideLayoutGroup('thrd_prty_questions_group');
                    CommonOpUtil.showHideLayoutGroup('THRD_PRTY_ASSISTANCE_REQ_DT_group', false);
                    CommonOpUtil.showHideLayoutGroup('THRD_PRTY_APPEAL_FILE_DT_group', false);
                }
            }
        }

        function dateValidate(e, msg, targetId) {
            var days = 0
            var dt1 = '';
            var dt2 = ''
            if (e.value1 != undefined || e.value2 != undefined) {
                dt1 = e.value1;
                dt2 = e.value2;
            }
            if ((dt2 && dt2 !== '') || (dt1 && dt1 !== '')) {
                var m1 = moment(dt1);
                var m2 = moment(dt2);
                days = m2.diff(m1, 'days');
                if (days < 0) {
                    bootbox.alert({
                        message: msg,
                        callback: function () {
                            FormState.doAction(StateAction.changeDate(targetId, ''), false);
                            $('#' + targetId).val('');
                        }
                    });
                }
            }
        }

        function thirdPartyHearingProcdureOrderOptions(dropdownID) {
            var activityName = ActivityManager.getActivityName();
            var optionsMinSelection = (activityName === 'Complete Case') ? 1 : 0;
            var optionsInitialData = [];
            var optionsIdString = FormState.getElementValue(dropdownID);
            var optionsIds = ((optionsIdString != null && optionsIdString.length > 0) ? optionsIdString.split(',') : []);
            var count = optionsIds.length;
            for (var index = 0; index < count; index++) {
                var itemLabel = $('#' + dropdownID + '_SEL option[value="' + optionsIds[index] + '"]').text();
                optionsInitialData.push({
                    id: optionsIds[index].replace(/\s/g, ''),
                    label: itemLabel
                });
            }
            var multiSelectOptions = {
                id: dropdownID,
                tabindex: 0,
                minSelectionCount: optionsMinSelection,
                maxSelectionCount: 10,
                getSelectionLabel: function (item) {
                    return item.label
                },
                getItemID: function (item) {
                    return item.id.replace(/\s/g, '');
                },
                initialItems: optionsInitialData,
                setDataToForm: function (values) {
                    if (typeof values == 'undefined') return;
                    var selectedIds = '';
                    if (values != null && $.isArray(values)) {
                        selectedIds = values.reduce(function (accumulator, currentValue, currentIndex, array) {
                            return (accumulator && accumulator.length > 0) ? accumulator + ',' + currentValue.id : currentValue.id;
                        }, '');
                    }
                    FormState.updateObjectValue(dropdownID, selectedIds);
                }
            };
            MultiSelectDropdown.setupMultiSelectDropdown(multiSelectOptions);
        }

        function appealTypeEvent(e) {
            var appealType = '';//e.target.options[e.target.options.selectedIndex].value;
            if (e === 'undefined') {
                return;
            } else if (typeof e === 'object') {
                if (e.target !== 'undefined') {
                    appealType = e.target.options[e.target.options.selectedIndex].value;
                }
            }
            layoutByAppealType(appealType);
            $('#thrd_prty_group select,#thrd_prty_group input[type="text"]').not('#THRD_PRTY_APPEAL_TYPE').val('');
        }

        function updateEvent(e) {
            var eventSource = '';
            var val = '';//e.target.options[e.target.options.selectedIndex].value;
            if (e === 'undefined') {
                return;
            } else if (typeof e === 'object') {
                if (e.target !== 'undefined') {
                    val = e.target.options[e.target.options.selectedIndex].value;
                    eventSource = e.target.id;
                }
            }
            if (eventSource && eventSource === 'THRD_PRTY_EXCEPTION_FILED') {
                CommonOpUtil.showHideLayoutGroup('thrd_prty_Exception_info_group', val === 'Yes');
            }

            if (eventSource && eventSource === 'THRD_PRTY_EXCEPTION_FILED_2') {
                CommonOpUtil.showHideLayoutGroup('thrd_prty_Exception_info_group_2', val === 'Yes');
            }

            if (eventSource && eventSource === 'THRD_PRTY_ARBITRATION_INVOKED') {
                CommonOpUtil.showHideLayoutGroup('thrd_prty_Arbitration_group_Grievance', val === 'Yes');
            }

            if (eventSource && eventSource === 'THRD_PRTY_WAS_DISCOVERY_INITIATED') {
                CommonOpUtil.showHideLayoutGroup('thrd_prty_discovery_due_group', val === 'Yes');
            }
            if (eventSource && eventSource === 'THRD_PRTY_WAS_PETITION_FILED_MSPB') {
                CommonOpUtil.showHideLayoutGroup('thrd_prty_petition_review_date_group', val === 'Yes');
            }
        }

        function appealDateEvents(e) {
            var eventSource = e.target.id;
            var val = $('#' + eventSource).val();
            if (eventSource && eventSource === 'THRD_PRTY_PREHEARING_DT') {
                var hearingDate = FormState.getElementValue('THRD_PRTY_HEARING_DT');
                dateValidate({
                    value1: val,
                    value2: hearingDate
                }, 'Date of Hearing must be after the Date of Prehearing Conference.', 'THRD_PRTY_PREHEARING_DT');
            }

            if (eventSource && eventSource === 'THRD_PRTY_HEARING_DT') {
                var phearingDt = FormState.getElementValue('THRD_PRTY_PREHEARING_DT');
                dateValidate({
                    value1: phearingDt,
                    value2: val
                }, 'Date of Hearing must be after the Date of Prehearing Conference.', 'THRD_PRTY_HEARING_DT');
            }

            if (eventSource && eventSource === 'THRD_PRTY_PREHEARING_DT_MSPB') {//prehearingDateMSPB
                var hearing = FormState.getElementValue('THRD_PRTY_HEARING_DT_MSPB');
                dateValidate({
                    value1: val,
                    value2: hearing
                }, 'Date of Hearing must be after the Date of Prehearing Conference.', 'THRD_PRTY_PREHEARING_DT_MSPB');
            }

            if (eventSource && eventSource === 'THRD_PRTY_HEARING_DT_MSPB') {//hearingDateMSPB
                var hearingMSPB = FormState.getState('THRD_PRTY_PREHEARING_DT_MSPB');
                dateValidate({
                    value1: val,
                    value2: hearingMSPB
                }, 'Date of Hearing must be after the Date of Prehearing Conference.', 'THRD_PRTY_HEARING_DT_MSPB');
            }

            if (eventSource && eventSource == 'THRD_PRTY_PREHEARING_DT_SC') {
                var phearingDTSC = FormState.getState('THRD_PRTY_HEARING_DT_SC');
                dateValidate({
                    value1: val,
                    value2: phearingDTSC
                }, 'Date of Hearing must be after the Date of Prehearing Conference.', 'THRD_PRTY_PREHEARING_DT_SC');
            }

            if (eventSource && eventSource === 'THRD_PRTY_HEARING_DT_SC') {
                var phearingSC = FormState.getState('THRD_PRTY_PREHEARING_DT_SC');
                dateValidate({
                    value1: val,
                    value2: phearingSC
                }, 'Date of Hearing must be after the Date of Prehearing Conference.', 'THRD_PRTY_HEARING_DT_SC');
            }
        }

        return {
            appealDateEvents: appealDateEvents,
            updateEvent: updateEvent,
            appealTypeEvent: appealTypeEvent,
            dateValidate: dateValidate,
            init: init,
            render: render
        }
    }

    (window.cms_erlr_3rdparty_hear !== undefined ? window.cms_erlr_3rdparty_hear : (window.cms_erlr_3rdparty_hear = cms_erlr_3rdparty_hear()));
})(window)






