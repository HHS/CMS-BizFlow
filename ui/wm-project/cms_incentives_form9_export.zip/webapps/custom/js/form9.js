(function (window) {
    var cms_incentives_sam_justification = function () {
        var _readOnly = false;
        var _initialized = false;
        var _dialog_justificationModificationReason_ac = null;

        function setDialogJustificationModificationReasonAutoCompletion() {
            FormState.updateObjectValue("dialog_justificationModificationReason", [], false);
            var option = {
                id: 'dialog_justificationModificationReason',
                useAddButton: true,
                addButtonTooltip: "Click the button to add a selection to the Modification Reason list",
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                minSelectionCount: 1,
                maxSelectionCount: 3,
                readOnly: _readOnly,

                mapFunction: function (context) {
                },
                getSelectionLabel: function (item) {
                    return item.text;
                },
                getCandidateLabel: function (item) {
                    return item.value;
                },
                getItemID: function (item) {
                    return item.value;
                },
                setDataToForm: function (values) {
                    FormState.updateObjectValue('dialog_justificationModificationReason', values);
                },
                sortSelectedValues: function (values) {
                    var other = null;
                    for (var i = 0; i < values.length; i++) {
                        var item = values[i];
                        if (item.value === 'Other') {
                            other = item;
                            values.splice(i, 1);
                            break;
                        }
                    }

                    values.sort(function (a, b) {
                        return a.value > b.value;
                    });

                    if (other !== null) {
                        values.push(item);
                    }

                    return values;
                },
                isValidListItem: function (item, target) {
                    return item.value !== "";
                },
                afterItemDisplayed: function (containerId, item) {
                    FormUtility.removeSelectOption(item.value, "dialog_justificationModificationReason");
                },
                afterItemDeleted: function (containerId, targetId, item, values) {
                    var target = FormUtility.addSelectionAndSortExceptLast(item.text, item.value, "dialog_justificationModificationReason", "Other");
                    target.selectedIndex = values.length === 0 ? 0 : -1;
                },
                initialItems: FormState.getElementArrayValue('dialog_justificationModificationReason', [])
            };

            _dialog_justificationModificationReason_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        function setJustificationModificationReason() {
            var reasons = FormState.getElementArrayValue('dialog_justificationModificationReason', []);
            var mergedReason = "";
            var reasonArray = [];
            var i = 0;
            if (reasons.length > 0) {
                for (i = 0; i < reasons.length; i++) {
                    reasonArray.push(reasons[i].text);
                }
                mergedReason = reasonArray.join(", ");
            }
            FormState.updateTextValue("justificationModificationReason", mergedReason, false);
        }

        function initEventHandlers() {
            initModifyJustification();
            initJustificationHistory();
            setDialogJustificationModificationReasonAutoCompletion();
        }

        function setModifiedInfo(eleId, dateEleId) {
            var currentUserName = myInfo.getMyName();
            var currentUserId = myInfo.getMyMemberId();
            var currentDate = FormUtility.getDateString(false, "mm/dd/yyyy HH:MM:ss", new Date());

            $("#" + eleId).val(currentUserName);
            $("#" + dateEleId).val(currentDate);

            FormState.updateTextValue(eleId, currentUserName, false);
            FormState.updateTextValue(eleId + "Id", currentUserId, false);
            FormState.updateDateValue(dateEleId, currentDate, false);
        }

        function modifyJustification() {
            FormState.updateObjectValue("dialog_justificationModificationReason", [], false);
            _dialog_justificationModificationReason_ac.deleteAllItems();

            $("#dialog_justificationModificationSummary").val("");
            $("#dialog_justificationSuperQualificationDesc_modify").val($("#justificationSuperQualificationDesc").val());
            $("#dialog_justificationQualificationComparedDesc_modify").val($("#justificationQualificationComparedDesc").val());
            $("#dialog_justificationPayEquityDesc_modify").val($("#justificationPayEquityDesc").val());

            var cancelCallbackHandler = function() {
                $("#dialog_justificationSuperQualificationDesc_modify").val($("#justificationSuperQualificationDesc").val());
                $("#dialog_justificationQualificationComparedDesc_modify").val($("#justificationQualificationComparedDesc").val());
                $("#dialog_justificationPayEquityDesc_modify").val($("#justificationPayEquityDesc").val());

                $("#dialog_justificationModifyContent_group_parent").empty();
                $("#dialog_justificationModifyContent_group").addClass('hide');
                $("#dialog_justificationModifyContent_group").appendTo("#dialog_justificationModifyContent_group_parent");
             };

            var inputDialogOption = {
                onEscape: cancelCallbackHandler,
                animate: false,
                size: "large",
                buttons: {
                    cancel:{
                        label: 'Cancel',
                        className: 'btn-default',
                        callback: cancelCallbackHandler
                    },
                    confirm: {
                        label: 'Update',
                        className: 'btn-primary',
                        callback: function(){
                            var valid = true;
                            var $dialogForm = $('#dialog_justificationModifyContent_group');
                            $dialogForm.find('INPUT,SELECT.select,textarea.textbox').each(function(i,v){
                                var fieldId = $(this).attr("id");
                                if(fieldId){
                                    valid = hyf.validation.validateField(fieldId, false);
                                    if(!valid){
                                        return false;
                                    }
                                }
                            });

                            if(valid) {
                                setJustificationModificationReason();
                                FormState.updateTextValue("justificationModificationSummary", $("#dialog_justificationModificationSummary").val(), false);

                                FormState.updateTextValue("justificationSuperQualificationDesc", $("#dialog_justificationSuperQualificationDesc_modify").val(), true);
                                FormState.updateTextValue("justificationQualificationComparedDesc", $("#dialog_justificationQualificationComparedDesc_modify").val(), true);
                                FormState.updateTextValue("justificationPayEquityDesc", $("#dialog_justificationPayEquityDesc_modify").val(), true);

                                setModifiedInfo("justificationModifier", "justificationModified");

                                $("#dialog_justificationModifyContent_group_parent").empty();
                                $("#dialog_justificationModifyContent_group").addClass('hide');
                                $("#dialog_justificationModifyContent_group").appendTo("#dialog_justificationModifyContent_group_parent");
                            }else{
                                return false;
                            }
                        }
                    }
                }
            };
            $("#dialog_justificationModifyContent_group").removeClass('hide');
            inputDialogOption.title = "Modify Justification";
            inputDialogOption.message = $("#dialog_justificationModifyContent_group")[0];
            inputDialogOption.layoutGroupId = $("#dialog_justificationModifyContent_group").attr("id");

            $('#dialog_justificationModificationReason > option').eq(0).attr('selected','selected');
            $("#dialog_justificationModificationSummary").attr("rows", "3");
            $("#dialog_justificationSuperQualificationDesc_modify").attr("rows", "5");
            $("#dialog_justificationQualificationComparedDesc_modify").attr("rows", "5");
            $("#dialog_justificationPayEquityDesc_modify").attr("rows", "5");

            var dialog = bootbox.dialog(inputDialogOption);
            dialog.init(function(){
                // dialog.find(".modal-body").css({"height": "720px", "overflow-y": "auto"});
            });
        }

        function setJustificationHistory() {
            var procId = FormUtility.getInputElementValue('h_procid');
            var url = '/bizflowwebmaker/cms_incentives_service/searchIncentivesJustHistory.do?l=100&q=' + procId;
            var mapFunction = function (context) {
                return {
                    ver: $("JUSTIFICATION_VER", context).text(),
                    modReason: $("JUSTIFICATION_MOD_REASON", context).text(),
                    modSummary: $("JUSTIFICATION_MOD_SUMMARY", context).text(),
                    creatorName: $("JUSTIFICATION_MODIFIER_NAME", context).text(),
                    creatorId: $("JUSTIFICATION_MODIFIER_ID", context).text(),
                    createdDate: $("JUSTIFICATION_MODIFIED_DATE", context).text(),
                    superQualDesc: $("JUSTIFICATION_SUPER_QUAL_DESC", context).text(),
                    qualCompDesc: $("JUSTIFICATION_QUAL_COMP_DESC", context).text(),
                    payEquityDesc: $("JUSTIFICATION_PAY_EQUITY_DESC", context).text()
                };
            };
            var openJustificationHistory = function(values) {
                var $inputDialog = $("<div class='layoutContainer alignVertical alignLeft alignTop expandWidth fitHeight hide'></div>");
                //var $tmplElem = $($("#sam-justification-history-template")[0].content); // <template> tag didn't work with IE11
                var $tmplElem = $("<div></div>").append($("#sam-justification-history-template").children().clone(true));
                var $currentJustification = $tmplElem.clone(true);

                $currentJustification.find(".justification-history-header").css({"background-color": "white"});
                $currentJustification.find(".justification-history-heading-label").html("Current Justification");
                $currentJustification.find(".justification-history-modifier-name-label").html("Modified by:");
                $currentJustification.find(".justification-history-modifier-name").html(FormState.getElementValue("justificationModifier", ""));

                $currentJustification.find(".justification-history-modified-date-label").html("Date Modified:");
                $currentJustification.find(".justification-history-modified-date").html(FormState.getElementValue("justificationModified", ""));

                $currentJustification.find(".justification-history-modification-reason-label").html("Modification Reason(s):");
                $currentJustification.find(".justification-history-modification-reason").html(FormState.getElementValue("justificationModificationReason", ""));

                $currentJustification.find(".justification-history-modification-summary-label").html("Summary of Modification(s):");
                var justificationModificationSummary = FormState.getElementValue("justificationModificationSummary", "");
                if(justificationModificationSummary == "") {
                    justificationModificationSummary = "No summary of modifications provided.";
                }
                $currentJustification.find(".justification-history-modification-summary").html(justificationModificationSummary);

                $currentJustification.find(".justification-history-modification-superQualificationDesc").html(FormState.getElementValue("justificationSuperQualificationDesc", ""));
                $currentJustification.find(".justification-history-modification-qualificationComparedDesc").html(FormState.getElementValue("justificationQualificationComparedDesc", ""));
                $currentJustification.find(".justification-history-modification-payEquityDesc").html(FormState.getElementValue("justificationPayEquityDesc", ""));
                $inputDialog.append($currentJustification);

                if(values && values.length > 0) {
                    for (var i = 0; i < values.length; i++) {
                        var $item = $tmplElem.clone(true);
                        var justificationModificationSummary = values[i].modSummary;
                        if(justificationModificationSummary == "") {
                            justificationModificationSummary = "No summary of modifications provided.";
                        }
                        $item.find(".justification-history-header").css({"background-color": "lightgray"});
                        if (values[i].ver == 1) {
                            $item.find(".justification-history-heading-label").html("Original Justification");
                            $item.find(".justification-history-modifier-name-label").html("Created by:");
                            $item.find(".justification-history-modifier-name").html(values[i].creatorName);

                            $item.find(".justification-history-modified-date-label").html("Date Created:");
                            $item.find(".justification-history-modified-date").html(values[i].createdDate);

                            $item.find(".justification-history-modification-reason-label").closest(".layoutContainerContent").addClass("hide");
                            $item.find(".justification-history-modification-summary-label").closest(".layoutContainerContent").addClass("hide");

                            $item.find(".justification-history-modification-superQualificationDesc").html(values[i].superQualDesc);
                            $item.find(".justification-history-modification-qualificationComparedDesc").html(values[i].qualCompDesc);
                            $item.find(".justification-history-modification-payEquityDesc").html(values[i].payEquityDesc);
                        } else {
                            $item.find(".justification-history-heading-label").html("Justification Modification " + (values[i].ver - 1));
                            $item.find(".justification-history-modifier-name-label").html("Modified by:");
                            $item.find(".justification-history-modifier-name").html(values[i].creatorName);

                            $item.find(".justification-history-modified-date-label").html("Date Modified:");
                            $item.find(".justification-history-modified-date").html(values[i].createdDate);

                            $item.find(".justification-history-modification-reason-label").html("Modification Reason(s):");
                            $item.find(".justification-history-modification-reason").html(values[i].modReason);

                            $item.find(".justification-history-modification-summary-label").html("Summary of Modification(s):");
                            $item.find(".justification-history-modification-summary").html(justificationModificationSummary);

                            $item.find(".justification-history-modification-superQualificationDesc").html(values[i].superQualDesc);
                            $item.find(".justification-history-modification-qualificationComparedDesc").html(values[i].qualCompDesc);
                            $item.find(".justification-history-modification-payEquityDesc").html(values[i].payEquityDesc);
                        }
                        $inputDialog.append($item);
                    }
                }

                var inputDialogOption = {
                    onEscape: true,
                    animate: false,
                    size: "large",
                    buttons: {
                        cancel:{
                            label: 'Close',
                            className: 'btn-default'
                        }
                    }
                };

                $inputDialog.removeClass('hide');
                inputDialogOption.title = "Justification History";
                inputDialogOption.message = $inputDialog[0];
                inputDialogOption.layoutGroupId = $inputDialog.attr("id");

                var dialog = bootbox.dialog(inputDialogOption);
                dialog.init(function(){
                    dialog.find(".modal-body").css({"height": "520px", "overflow-y": "auto"});
                    var width = dialog.find(".bootbox-body").width();
                    dialog.find(".wrapContent").css({"width": (width - 20), "word-wrap": "break-word"});
                });
            };

            $.ajax({
                url: url,
                dataType: "xml",
                cache: false,
                success: function (xmlResponse) {
                    var data = $("record", xmlResponse).map(function () {
                        return mapFunction(this);
                    }).get();
                    openJustificationHistory(data);
                }
            });
        }

        function initModifyJustification() {
            $('#justification_modify_button').off('click').click(function (e) {
                modifyJustification();
            });
        }
        function initJustificationHistory() {
            $('#justification_history_button').off('click').click(function (e) {
                setJustificationHistory();
            });
        }
        function initComponents() {
            var visible1 = activityStep.isHRSReview() || activityStep.isDGHOReview() || activityStep.isTABGReview() || activityStep.isOHCReview() || activityStep.isHRSRecordConclusion();
            FormMain.setComponentVisibility("justificationExistingCompensationPkgDesc_group", visible1);
            FormMain.setComponentVisibility("justificationExplainIncentiveConsideration_group", visible1);

            hyf.util.setMandatoryConstraint("justificationSuperQualificationDesc", activityStep.isSOReview() || activityStep.isHRSReview() || activityStep.isDGHOReview() || activityStep.isCOMPReviewForModification());
            hyf.util.setMandatoryConstraint("justificationQualificationComparedDesc", activityStep.isSOReview() || activityStep.isHRSReview() || activityStep.isDGHOReview() || activityStep.isCOMPReviewForModification());
            hyf.util.setMandatoryConstraint("justificationPayEquityDesc", activityStep.isSOReview() || activityStep.isHRSReview() || activityStep.isDGHOReview() || activityStep.isCOMPReviewForModification());
            hyf.util.setMandatoryConstraint("justificationExistingCompensationPkgDesc", activityStep.isHRSReview() || activityStep.isDGHOReview());
            hyf.util.setMandatoryConstraint("justificationExplainIncentiveConsideration", activityStep.isHRSReview() || activityStep.isDGHOReview());

            var editable = activityStep.isCOMPReview() || activityStep.isCOMPReviewForModification() || activityStep.isSOReview();

            hyf.util.setComponentUsability("justificationSuperQualificationDesc", editable);
            hyf.util.setComponentUsability("justificationQualificationComparedDesc", editable);
            hyf.util.setComponentUsability("justificationPayEquityDesc", editable);

            editable = activityStep.isHRSReview() || activityStep.isDGHOReview();
            hyf.util.setComponentUsability("justificationExistingCompensationPkgDesc", editable);
            hyf.util.setComponentUsability("justificationExplainIncentiveConsideration", editable);

            if(myInfo.isHRS() && activityStep.isHRSReview()) {
                hyf.util.setComponentVisibility("justification_modify_button", true);
            } else {
                hyf.util.setComponentVisibility("justification_modify_button", false);
            }
            var justificationModifier = FormState.getElementValue("justificationModifier", "");
            if(justificationModifier == "") {
                hyf.util.setComponentVisibility("justification_history_button", false);
            } else {
                hyf.util.setComponentVisibility("justification_history_button", true);
            }

            FormState.updateTextValue("currentUser", myInfo.getMyName(), false);
            FormState.updateTextValue("currentUserId", myInfo.getMyMemberId(), false);
            FormState.updateDateValue("currentDate", FormUtility.getDateString(false, "mm/dd/yyyy HH:MM:ss", new Date()), false);
        }

        function init(readOnly, tabObject) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();
            FormMain.resetMandatoryMark(tabObject);

            _initialized = true;
        }

        function render(action) {
        }


        return {
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_sam_justification || (window.cms_incentives_sam_justification = cms_incentives_sam_justification());
})(window);
