(function (window) {
    var cms_incentives_sam_justification = function () {
        var _readOnly = false;
        var _initialized = false;

        function initEventHandlers() {
        }

        function initComponents() {
            var visible1 = activityStep.isHRSReview() || activityStep.isDGHOReview() || activityStep.isTABGReview() || activityStep.isOHCReview();
            hyf.util.setComponentVisibility("justificationExistingCompensationPkgDesc_group", visible1);
            hyf.util.setComponentVisibility("justificationExplainIncentiveConsideration_group", visible1);

            hyf.util.setMandatoryConstraint("justificationSuperQualificationDesc", activityStep.isSOReview() || activityStep.isHRSReview() || activityStep.isDGHOReview());
            hyf.util.setMandatoryConstraint("justificationQualificationComparedDesc", activityStep.isSOReview() || activityStep.isHRSReview() || activityStep.isDGHOReview());
            hyf.util.setMandatoryConstraint("justificationPayEquityDesc", activityStep.isSOReview() || activityStep.isHRSReview() || activityStep.isDGHOReview());
            hyf.util.setMandatoryConstraint("justificationExistingCompensationPkgDesc", activityStep.isHRSReview() || activityStep.isDGHOReview());
            hyf.util.setMandatoryConstraint("justificationExplainIncentiveConsideration", activityStep.isHRSReview() || activityStep.isDGHOReview());

            var editable = !activityStep.isHRSReview() && !activityStep.isDGHOReview() && !activityStep.isTABGReview() && !activityStep.isOHCReview();

            hyf.util.setComponentUsability("justificationSuperQualificationDesc", editable);
            hyf.util.setComponentUsability("justificationQualificationComparedDesc", editable);
            hyf.util.setComponentUsability("justificationPayEquityDesc", editable);

            editable = activityStep.isHRSReview() || activityStep.isDGHOReview();
            hyf.util.setComponentUsability("justificationExistingCompensationPkgDesc", editable);
            hyf.util.setComponentUsability("justificationExplainIncentiveConsideration", editable);
        }

        function init(readOnly) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();

            _initialized = true;
        }

        function render(action) {
        }

        return {
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_sam_justification || (window.cms_incentives_sam_justification = cms_incentives_sam_justification());
})(window);
