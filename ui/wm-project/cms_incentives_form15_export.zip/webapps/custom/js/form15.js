(function (window) {
    var cms_incentives_pdp_details = function () {
        var _readOnly = false;
        var _initialized = false;
        var _dutyStation_ac = null;

        // function setGradeOptions(grades) {
        //     var selObj = $('#currentPayInfoGrade');
        //     selObj.children('option:not(:first)').remove();
        //     if (grades) {
        //         var selectedGrade = "";
        //         var cnt = 0;
        //         for (var g = 0; g < grades.length; g++) {
        //             var grade = grades[g];
        //             if (grade) {
        //                 cnt++;
        //                 if (typeof grade === 'number' && grade < 10) {
        //                     grade = '0' + grade;
        //                 }
        //                 selObj.append($("<option></option>").attr("value", grade).text(grade));
        //                 if (cnt === 1) {
        //                     selectedGrade = grade;
        //                 }
        //             }
        //         }
        //
        //         if (_initialized) {
        //             if (cnt > 1) {
        //                 selectedGrade = "";
        //             }
        //             FormState.updateSelectValue("currentPayInfoGrade", selectedGrade, selectedGrade, true);
        //             onGradeChanged(selectedGrade);
        //         }
        //     }
        // }
        //
        // function setGradeSelectBoxWithRequestGrade(item) {
        //     if (item && item.position) {
        //         setGradeOptions(item.position.grade.slice(0).sort());
        //     }
        // }
        //
        // function isValidGrades(grades) {
        //     for (var g = 0; g < grades.length; g++) {
        //         if (grades[g]) return true;
        //     }
        //
        //     return false;
        // }
        //
        // function getGradeIndex(item, grade) {
        //     for (var i = 0; i < item.position.grade.length; i++) {
        //         if (item.position.grade[i] === grade) {
        //             return i;
        //         }
        //     }
        //
        //     return -1;
        // }
        //
        // function setPositionDescriptionNumber(grade) {
        //     var descNum = "";
        //     var item = FormState.getElementSingleValue('associatedNEILRequest');
        //     if (item) {
        //         var idx = getGradeIndex(item, grade);
        //         if (idx > -1) {
        //             descNum = item.position.descNum[idx];
        //         }
        //     }
        //     if (_initialized) {
        //         FormState.updateTextValue("posDescNumbePDPPCA", descNum || "", true);
        //     }
        // }
        //
        // function setGradeSelectBox(incentiveType, payPlan, item) {
        //     if (INCENTIVES_TYPE.SAM === incentiveType && "ES" === payPlan) {
        //         var grade = "00";
        //         setGradeOptions([grade]);
        //         FormMain.setComponentUsability("grade", false);
        //         if (_initialized) {
        //             FormState.updateSelectValue("grade", grade, grade, true);
        //             setGradeVisibility(true);
        //             onGradeChanged(grade);
        //         }
        //     } else {
        //         setGradeSelectBoxWithRequestGrade(item);
        //         setGradeSelectBoxByPayPlan(payPlan, item, true);
        //         FormMain.setComponentUsability("grade", true);
        //     }
        // }

        function initEventHandlers() {

            for (var i = 1; i <= 5; i++) {
              $('#excepQualAmountRequested_' + i).on('change', function () {
                var excepQualSum = 0;
                for (var i = 1; i <= 5; i++) {
                  excepQualSum += $('#excepQualAmountRequested_' + i).val();
                }
                $('#excepQualTotalAmount').val(excepQualSum);
              });
            }

            // $('#gradePDPPCA').on('change', function (e) {
            //     var target = e.target;
            //     var grade = target.options[target.options.selectedIndex].value;
            //     onGradeChanged(grade);
            // });
            //
            // $('#payPlanPDPPCA').on('change', function (e) {
            //     var target = e.target;
            //     var payPlan = target.options[target.options.selectedIndex].value;
            //     setGradeSelectBoxByPayPlan(payPlan);
            //     if(cms_incentives_pca_details) {
            //         cms_incentives_pca_details.onPayPlanChanged(payPlan);
            //     }
            //     if(_initialized) {
            //         if(cms_incentives_sam_details) {
            //             cms_incentives_sam_details.onPayPlanChanged(payPlan);
            //         }
            //     }
            // });
            //
            // $('#workSchedulePDPPCA').on('change', function (e) {
            //     var target = e.target;
            //     var workSchedule = target.options[target.options.selectedIndex].value;
            //     setHoursPerWeek(workSchedule);
            // });
            //
            // $('#requireBoardCertPDPPCA').on('change', function (e) {
            //     var target = e.target;
            //     var requireBoardCert = target.options[target.options.selectedIndex].value;
            //     if(cms_incentives_pca_details) {
            //         cms_incentives_pca_details.onRequireBoardCertChanged(requireBoardCert);
            //     }
            // });
        }

        // function postDisableTab(afterAllTabLoaded, tab) {
        //     if (afterAllTabLoaded) {
        //         if (activityStep.isSOReview()) {
        //             if (tab.readOnly) {
        //                 hyf.util.enableComponent("numOfInterviewed");
        //             }
        //         }
        //     }
        // }

        function initComponents() {

        }

        function init(readOnly, tabObject) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();
            FormMain.resetMandatoryMark(tabObject);

            _initialized = true;
        }

        function render(action) {
        }

        return {
            init: init,
            render: render//,
            // populateRelatedFields: populateRelatedFields,
            // onIncentiveTypeChange: onIncentiveTypeChanged,
            // postDisableTab: postDisableTab
        }
    };

    var _initializer = window.cms_incentives_pdp_details || (window.cms_incentives_pdp_details = cms_incentives_pdp_details());
})(window);
