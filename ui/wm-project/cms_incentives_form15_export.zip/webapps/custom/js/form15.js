(function (window) {
  var cms_incentives_pdp_details = function () {
    var _readOnly = false;
    var _initialized = false;
    var _currentPayInfoSpecialtyCertification_ac = null;

    var all_incentivesLookupObjArr = [];
    var level_incentivesLookupObjArr = [];
    var factor_incentivesLookupObjArr = [];
    var payTable_incentivesLookupObjArr = [];

    var positionRequireBoardCert;

    var selectedSpecialties;

    var _proposedPayInfoTABG_ac = null;

    function initLookupData(populate) {
      $.ajax({
        url: '/bizflowwebmaker/cms_incentives_service/incentivesLookup.do?retrieveValues=' + populate,
        dataType: 'xml',
        async: false,
        cache: false,
        success: function (xmlResponse) {
          var data = $('record', xmlResponse).map(function () {
            var lookupObj = {
              lookupType: $('LOOKUP_TYPE', this).text(),
              lookupTypeValue: $('LOOKUP_TYPE_VALUE', this).text(),
              tier: $('TIER', this).text(),
              minRange: $('MIN_RANGE', this).text(),
              maxRange: $('MAX_RANGE', this).text(),
              rangeLabel: $('MONETARY_RANGE_LABEL', this).text(),
            };
            all_incentivesLookupObjArr.push(lookupObj);
          }).get();
        }
      });
      initIncentivesRangesArrays();
    }

    function initIncentivesRangesArrays() {
      if (all_incentivesLookupObjArr.length > 0) {
        all_incentivesLookupObjArr.forEach(function (obj) {
          switch (obj.lookupType) {
            case 'LevelOfExecutiveResponsability':
              level_incentivesLookupObjArr.push(obj);
              break;
            case 'ExceptionalQualificationFactor':
              factor_incentivesLookupObjArr.push(obj);
              break;
            case 'PayTable':
              payTable_incentivesLookupObjArr.push(obj);
              break;
            default:
              break;
          }
        });
      }
    }

    function initDropdowns() {
      if (level_incentivesLookupObjArr.length > 0) {
        level_incentivesLookupObjArr.forEach(function (obj) {
          $('#execRespLevelOfResponsibility').append($("<option></option>").attr("value", obj.lookupTypeValue).text(obj.lookupTypeValue));
        });
      }

      var payTableDropdown = new Array();
      payTable_incentivesLookupObjArr.forEach(function (obj) {
        if (!(payTableDropdown.indexOf(obj.lookupTypeValue) >= 0)) {
          payTableDropdown.push(obj.lookupTypeValue);
          $('#currentPayInfoTable').append($("<option></option>").attr("value", obj.lookupTypeValue).text(obj.lookupTypeValue));
          $('#proposedPayInfoTable').append($("<option></option>").attr("value", obj.lookupTypeValue).text(obj.lookupTypeValue));
        }
      });
    }

    function initCurrentFedEmpRelatedFields(isCurrentFedEmp) {
      if (isCurrentFedEmp === 'N') {
        FormMain.setMandatoryConstraint("currentPayInfoGrade", false);
        FormMain.setComponentVisibility("currentPayInfoGrade_group", false);

        FormMain.setMandatoryConstraint("currentPayInfoStep", false);
        FormMain.setComponentVisibility("currentPayInfoStep_group", false);

        FormMain.setMandatoryConstraint("currentPayInfoTable", false);
        FormMain.setComponentVisibility("currentPayInfoTable_group", false);

        FormMain.setMandatoryConstraint("currentPayInfoTier", false);
        FormMain.setComponentVisibility("currentPayInfoTier_group", false);
      } else {
        FormMain.setMandatoryConstraint("currentPayInfoGrade", true);
        FormMain.setComponentVisibility("currentPayInfoGrade_group", true);

        FormMain.setMandatoryConstraint("currentPayInfoStep", true);
        FormMain.setComponentVisibility("currentPayInfoStep_group", true);

        FormMain.setMandatoryConstraint("currentPayInfoTable", true);
        FormMain.setComponentVisibility("currentPayInfoTable_group", true);

        FormMain.setMandatoryConstraint("currentPayInfoTier", true);
        FormMain.setComponentVisibility("currentPayInfoTier_group", true);
      }
    }

    function initFactorRelatedFields() {
      if (factor_incentivesLookupObjArr.length > 0) {
        factor_incentivesLookupObjArr.forEach(function (obj) {
          var factor = obj.lookupTypeValue;
          FormState.updateTextValue("excepQualMonetaryRange_" + factor, obj.rangeLabel, true);
          setRangeConstraint("excepQualAmountRequested_" + factor, obj.minRange, obj.maxRange);
        });
      }

    }

    function setDetailsGradeOptions(grades) {
      var selObj = $('#currentPayInfoGrade');
      selObj.children('option:not(:first)').remove();
      if (grades) {
        var selectedGrade = "";
        var cnt = 0;
        for (var g = 0; g < grades.length; g++) {
          var grade = grades[g];
          if (grade) {
            cnt++;
            if (typeof grade === 'number' && grade < 10) {
              grade = '0' + grade;
            }
            selObj.append($("<option></option>").attr("value", grade).text(grade));
            if (cnt === 1) {
              selectedGrade = grade;
            }
          }
        }
        if (_initialized) {
          if (cnt > 1) {
            selectedGrade = "";
          }
          FormState.updateSelectValue("currentPayInfoGrade", selectedGrade, selectedGrade, true);
          // onGradeChanged(selectedGrade);
        }
      }
    }

    function initLevelOfResponsabilityRelatedFields(levelSelected) {
      if (levelSelected && levelSelected != '') {
        FormState.updateSelectValue("execRespLevelOfResponsibility", levelSelected, levelSelected, true);
        FormMain.setMandatoryConstraint("execRespJustification", true);
        levelSelectedValues = getLevelSelectedValues(levelSelected);
        if (levelSelectedValues.levelTier == '1') {
          FormMain.setComponentUsability("execRespAmountRequested", false);
          FormMain.setComponentUsability("execRespJustification", false);
        } else {
          setRangeConstraint("execRespAmountRequested", levelSelectedValues.levelMin, levelSelectedValues.levelMax);
        }
      }
    }

    function initCurrentPayInfoTable(tableSelected) {
      if (tableSelected && tableSelected != '') {
        FormState.updateSelectValue("currentPayInfoTable", tableSelected, tableSelected, true);
      } else {
        FormState.updateSelectValue("currentPayInfoTable", "1", "1", true);
      }
    }

    function initProposedPayInfoTable(tableSelected) {
      if (tableSelected && tableSelected != '') {
        FormState.updateSelectValue("proposedPayInfoTable", tableSelected, tableSelected, true);
      } else {
        FormState.updateSelectValue("proposedPayInfoTable", "1", "1", true);
      }
    }

    function onLevelOfResponsabilityChanged(levelSelected) {
      if (levelSelected != '') {
        FormMain.setMandatoryConstraint("execRespJustification", true);

        populateLevelOfResponsabilityRelatedFields(getLevelSelectedValues(levelSelected));
      } else {
        FormMain.setMandatoryConstraint("execRespJustification", false);

        resetLevelOfResponsabilityRelatedFields();
      }
      calculateProposedMarketPay();
    }

    function getLevelSelectedValues(levelSelected) {
      var levelSelectedValues = {
        levelTier: '',
        levelMin: '',
        levelMax: '',
        levelRangeLabel: ''
      };
      if (level_incentivesLookupObjArr.length > 0) {
        level_incentivesLookupObjArr.forEach(function (obj) {
          if (obj.lookupTypeValue == levelSelected) {
            levelSelectedValues.levelTier = obj.tier;
            levelSelectedValues.levelMin = obj.minRange;
            levelSelectedValues.levelMax = obj.maxRange;
            levelSelectedValues.levelRangeLabel = obj.rangeLabel;
          }
        });
      }

      return levelSelectedValues;
    }

    function populateLevelOfResponsabilityRelatedFields(levelSelectedValues) {
      if (levelSelectedValues.levelTier == '1') {
        FormState.updateTextValue("execRespAmountRequested", "$" + levelSelectedValues.levelMax, true);
        FormMain.setComponentUsability("execRespAmountRequested", false);

        FormState.updateTextValue("execRespJustification", "Non-supervisory Position", true);
        FormMain.setComponentUsability("execRespJustification", false);
      } else {
        resetLevelOfResponsabilityRelatedFields();
        setRangeConstraint("execRespAmountRequested", levelSelectedValues.levelMin, levelSelectedValues.levelMax);
      }
      FormState.updateTextValue("proposedPayInfoTier", levelSelectedValues.levelTier.toUpperCase(), true);
      FormState.updateTextValue("execRespMonetaryRange", levelSelectedValues.levelRangeLabel, true);
    }

    function resetLevelOfResponsabilityRelatedFields() {
      FormState.updateTextValue("execRespMonetaryRange", "", true);

      FormState.updateTextValue("execRespAmountRequested", "", true);
      FormMain.setComponentUsability("execRespAmountRequested", true);
      $('#execRespAmountRequested').attr("data-wm-error-msg", " This field is invalid.");
      var field = document.getElementById('execRespAmountRequested');
      FormUtility.setInclusiveRangeConstraint(field, -0.001, 999999999999);

      FormState.updateTextValue("execRespJustification", "", true);
      FormMain.setComponentUsability("execRespJustification", true);

      FormState.updateTextValue("proposedPayInfoTier", "", true);
    }

    function setRangeConstraint(id, min, max) {
      var field = document.getElementById(id);
      var minRangeInt = parseInt(min);
      var maxRangeInt = parseInt(max);
      field.setAttribute("data-wm-error-msg", "The Amount Requested must be between the values of $" + minRangeInt.format(0)
        + " and $" + maxRangeInt.format(0));
      FormUtility.setInclusiveRangeConstraint(field, minRangeInt - 0.001, maxRangeInt);
    }

    function calculateExcepQualTotalAmount(factor, amount) {
      var excepQualAmountRequested_1 = FormUtility
        .moneyToNumber("1" == factor ? amount : FormState.getElementValue("excepQualAmountRequested_1"), 0);
      var excepQualAmountRequested_2 = FormUtility
        .moneyToNumber("2" == factor ? amount : FormState.getElementValue("excepQualAmountRequested_2"), 0);
      var excepQualAmountRequested_3 = FormUtility
        .moneyToNumber("3" == factor ? amount : FormState.getElementValue("excepQualAmountRequested_3"), 0);
      var excepQualAmountRequested_4 = FormUtility
        .moneyToNumber("4" == factor ? amount : FormState.getElementValue("excepQualAmountRequested_4"), 0);
      var excepQualAmountRequested_5 = FormUtility
        .moneyToNumber("5" == factor ? amount : FormState.getElementValue("excepQualAmountRequested_5"), 0);

      var total = "$" + (excepQualAmountRequested_1 + excepQualAmountRequested_2 + excepQualAmountRequested_3 + excepQualAmountRequested_4 + excepQualAmountRequested_5).format();
      FormState.updateDijitInputInner("excepQualTotalAmount", total);
      calculateProposedMarketPay("excepQualTotalAmount", total);
    }

    function onCurrentFedEmpChanged(isCurrentFedEmp) {
      if (isCurrentFedEmp === 'N') {
        FormMain.setMandatoryConstraint("currentPayInfoGrade", false);
        FormState.updateSelectValue("currentPayInfoGrade", "", "Select One", true);
        FormMain.setComponentVisibility("currentPayInfoGrade_group", false);

        FormMain.setMandatoryConstraint("currentPayInfoStep", false);
        FormState.updateSelectValue("currentPayInfoStep", "", "Select One", true);
        FormMain.setComponentVisibility("currentPayInfoStep_group", false);

        FormMain.setMandatoryConstraint("currentPayInfoTable", false);
        FormState.updateSelectValue("currentPayInfoTable", "1", "1", true);
        FormMain.setComponentVisibility("currentPayInfoTable_group", false);

        FormMain.setMandatoryConstraint("currentPayInfoTier", false);
        FormState.updateSelectValue("currentPayInfoTier", "", "Select One", true);
        FormMain.setComponentVisibility("currentPayInfoTier_group", false);
      } else {
        FormMain.setMandatoryConstraint("currentPayInfoGrade", true);
        FormMain.setComponentVisibility("currentPayInfoGrade_group", true);

        FormMain.setMandatoryConstraint("currentPayInfoStep", true);
        FormMain.setComponentVisibility("currentPayInfoStep_group", true);

        FormMain.setMandatoryConstraint("currentPayInfoTable", true);
        FormMain.setComponentVisibility("currentPayInfoTable_group", true);

        FormMain.setMandatoryConstraint("currentPayInfoTier", true);
        FormMain.setComponentVisibility("currentPayInfoTier_group", true);
      }
    }

    function setSpecialtyCertificationAutoCompletion() {
      var option = {
        id: 'currentPayInfoSpecialtyCertification',
        useAddButton: true,
        addButtonTooltip: "Click the button to add a selection to the Clinical Specialty/Board Certification list",
        baseURL: '/bizflowwebmaker/cms_incentives_main',
        minSelectionCount: 1,
        maxSelectionCount: 3,
        readOnly: _readOnly,
        mapFunction: function (context) {
        },
        getSelectionLabel: function (item) {
          return item.text;
        },
        getCandidateLabel: function (item) {
          return item.value;
        },
        getItemID: function (item) {
          return item.value;
        },
        setDataToForm: function (values) {
          FormState.updateObjectValue('currentPayInfoSpecialtyCertification', values);
          handleOtherSpecialty(values);
          setProposedPaySpecialties(values, '');
          selectedSpecialties = values;
        },
        sortSelectedValues: function (values) {
          var other = null;
          for (var i = 0; i < values.length; i++) {
            var item = values[i];
            if (item.value === 'Other') {
              other = item;
              values.splice(i, 1);
              break;
            }
          }

          values.sort(function (a, b) {
            return a.value > b.value;
          });

          if (other !== null) {
            values.push(item);
          }

          return values;
        },
        isValidListItem: function (item, target) {
          return item.value !== "";
        },
        afterItemDisplayed: function (containerId, item) {
          FormUtility.removeSelectOption(item.value, "currentPayInfoSpecialtyCertification");
        },
        afterItemDeleted: function (containerId, targetId, item, values) {
          var target = FormUtility.addSelectionAndSortExceptLast(item.text, item.value, "currentPayInfoSpecialtyCertification", "Other");
          target.selectedIndex = values.length === 0 ? 0 : -1;
        },
        initialItems: FormState.getElementArrayValue('currentPayInfoSpecialtyCertification', [])
      };
      setProposedPaySpecialties(option.initialItems, FormState.getElementValue("currentPayOtherSpecialty"));
      selectedSpecialties = option.initialItems;
      _currentPayInfoSpecialtyCertification_ac = FormAutoComplete.makeAutoCompletion(option);
    }

    function handleSpecialtyCertification(requireBoardCert) {
      requireBoardCert = "Yes" === (undefined !== requireBoardCert ? requireBoardCert : FormState.getElementValue("requireBoardCert"));
      hyf.util.setMandatoryConstraint("currentPayInfoSpecialtyCertification", requireBoardCert);
      _currentPayInfoSpecialtyCertification_ac.setMinSelectionCount(requireBoardCert ? 1 : 0);
    }

    function handleOtherSpecialty(boardCertSpecialties) {
      var currentPayOtherSpecialty = false;
      for (var i = 0; i < boardCertSpecialties.length; i++) {
        var item = boardCertSpecialties[i];
        if (item.value === 'Other') {
          currentPayOtherSpecialty = true;
          if (i < boardCertSpecialties.length - 1) {
            boardCertSpecialties.splice(i, 1);
            boardCertSpecialties.push(item);
          }
          break;
        }
      }
      if (true === currentPayOtherSpecialty) {
        hyf.util.showComponent("currentPayOtherSpecialty_group");
        var field = document.getElementById("currentPayOtherSpecialty");
        if (field.value === "") {
          field.focus();
        }
      } else {
        var field = document.getElementById("currentPayOtherSpecialty");
        field.value = "";
        hyf.util.hideComponent("currentPayOtherSpecialty_group");
      }
    }

    function setProposedPaySpecialties(specialties, otherSpecialtyValue) {
      $('#proposedPayInfoSpecialtyCertification_container').children().children().remove();
      if (specialties.length > 0) {
        var specialtiesList = '<div class="customControl"><ul class="" style="padding-left: 15px;">';
        specialties.forEach(function (specialty) {
          var item = '<li>';
          if (specialty.value == 'Other') {
            item += specialty.value + ': ' + otherSpecialtyValue + '</li>';
          } else {
            item += specialty.value + '</li>';
          }
          specialtiesList += item;
        });
        specialtiesList += '</ul></div>'
        $('#proposedPayInfoSpecialtyCertification_container').children().append(specialtiesList);
      } else {
        var emptyItem = '<span class="output " id="proposedPayInfoSpecialtyCertification" style="width: 480px;" _type="string" _use="output">&nbsp;</span>'
        $('#proposedPayInfoSpecialtyCertification_container').children().append(emptyItem);
      }
    }

    function calculateCurrentPay(id, value) {
      var currentPayInfoRecruitment = FormUtility
        .moneyToNumber("currentPayInfoRecruitment" == id ? value : FormState.getElementValue("currentPayInfoRecruitment"), 0);
      var currentPayInfoRelocation = FormUtility
        .moneyToNumber("currentPayInfoRelocation" == id ? value : FormState.getElementValue("currentPayInfoRelocation"), 0);
      var currentPayInfoRetention = FormUtility
        .moneyToNumber("currentPayInfoRetention" == id ? value : FormState.getElementValue("currentPayInfoRetention"), 0);
      var currentPayInfoBasePay = FormUtility
        .moneyToNumber("currentPayInfoBasePay" == id ? value : FormState.getElementValue("currentPayInfoBasePay"), 0);
      var currentPayInfoLocality = FormUtility
        .moneyToNumber("currentPayInfoLocality" == id ? value : FormState.getElementValue("currentPayInfoLocality"), 0);

      var total3Rs = "$" + (currentPayInfoRecruitment + currentPayInfoRelocation + currentPayInfoRetention).format();
      FormState.updateDijitInputInner("currentPayInfoTotal3R", total3Rs);
      var totalAnnual = "$" + (currentPayInfoBasePay + currentPayInfoLocality).format();
      FormState.updateDijitInputInner("currentPayInfoTotalAnnualPay", totalAnnual);
      var total = "$" + (currentPayInfoRecruitment + currentPayInfoRelocation + currentPayInfoRetention + currentPayInfoBasePay + currentPayInfoLocality).format();
      FormState.updateDijitInputInner("currentPayInfoTotalAnnualComp", total);
    }

    function calculateProposedPay(id, value) {
      var proposedPayInfoRecruitment = FormUtility
        .moneyToNumber("proposedPayInfoRecruitment" == id ? value : FormState.getElementValue("proposedPayInfoRecruitment"), 0);
      var proposedPayInfoRelocation = FormUtility
        .moneyToNumber("proposedPayInfoRelocation" == id ? value : FormState.getElementValue("proposedPayInfoRelocation"), 0);
      var proposedPayInfoRetention = FormUtility
        .moneyToNumber("proposedPayInfoRetention" == id ? value : FormState.getElementValue("proposedPayInfoRetention"), 0);
      var proposedPayInfoGSBasePay = FormUtility
        .moneyToNumber("proposedPayInfoGSBasePay" == id ? value : FormState.getElementValue("proposedPayInfoGSBasePay"), 0);
      var proposedPayInfoMarketPay = FormUtility
        .moneyToNumber("proposedPayInfoMarketPay" == id ? value : FormState.getElementValue("proposedPayInfoMarketPay"), 0);

      var total3Rs = "$" + (proposedPayInfoRecruitment + proposedPayInfoRelocation + proposedPayInfoRetention).format();
      FormState.updateDijitInputInner("proposedPayInfoTotal3R", total3Rs);
      var totalAnnual = "$" + (proposedPayInfoGSBasePay + proposedPayInfoMarketPay).format();
      FormState.updateDijitInputInner("proposedPayInfoTotalAnnualPay", totalAnnual);
      var total = "$" + (proposedPayInfoRecruitment + proposedPayInfoRelocation + proposedPayInfoRetention + proposedPayInfoGSBasePay + proposedPayInfoMarketPay).format();
      FormState.updateDijitInputInner("proposedPayInfoTotalAnnualComp", total);
      if (cms_incentives_pdp_panel) {
        cms_incentives_pdp_panel.onProposedPayInfoTotalAnnualCompChanged(total)
      }
    }

    function calculateProposedMarketPay(id, value) {
      var execRespAmountRequested = FormUtility
        .moneyToNumber("execRespAmountRequested" == id ? value : FormState.getElementValue("execRespAmountRequested"), 0);
      var excepQualTotalAmount = FormUtility
        .moneyToNumber("excepQualTotalAmount" == id ? value : FormState.getElementValue("excepQualTotalAmount"), 0);
      var boardCertAmount = positionRequireBoardCert == 'Yes' ? 3000 : 0;

      var proposedMarketPay = "$" + (execRespAmountRequested + excepQualTotalAmount + boardCertAmount).format();
      FormState.updateDijitInputInner("proposedPayInfoMarketPay", proposedMarketPay);
      calculateProposedPay("proposedPayInfoMarketPay", proposedMarketPay);
    }

    function onRequireBoardCertChanged(requireBoardCert) {
      handleSpecialtyCertification(requireBoardCert);
      positionRequireBoardCert = requireBoardCert;
      calculateProposedMarketPay();
    }

    function onGradeChanged(grade) {
      FormState.updateTextValue("proposedPayInfoGrade", grade, true);
      setProposedPayInfoStep(grade);
    }

    function setProposedPayInfoStep(grade) {
      if (grade == '00') {
        FormMain.setMandatoryConstraint("proposedPayInfoStep", false);
        FormState.updateSelectValue("proposedPayInfoStep", "", "Select One", true);
        FormMain.setComponentVisibility("proposedPayInfoStep_group", false);
      } else {
        FormMain.setMandatoryConstraint("proposedPayInfoStep", true);
        FormMain.setComponentVisibility("proposedPayInfoStep_group", true);
      }
    }

    function onPositionTitleChanged(positionTitle) {
      FormState.updateTextValue("proposedPayInfoPositionTitle", positionTitle, true);
    }

    function setIncentivesApprovedByTABGAutoCompletion() {
      var option = {
        id: 'proposedPayInfoIncentivesApprTABG',
        useAddButton: true,
        addButtonTooltip: "Click the button to add a selection to the Incentives Approved by TABG list",
        baseURL: '/bizflowwebmaker/cms_incentives_main',
        minSelectionCount: 0,
        maxSelectionCount: 2,
        readOnly: _readOnly,
        mapFunction: function (context) {
        },
        getSelectionLabel: function (item) {
          return item.text;
        },
        getCandidateLabel: function (item) {
          return item.value;
        },
        getItemID: function (item) {
          return item.value;
        },
        setDataToForm: function (values) {
          FormState.updateObjectValue('proposedPayInfoIncentivesApprTABG', values);
        },
        sortSelectedValues: function (values) {
          var other = null;
          for (var i = 0; i < values.length; i++) {
            var item = values[i];
            if (item.value === 'Other') {
              other = item;
              values.splice(i, 1);
              break;
            }
          }

          values.sort(function (a, b) {
            return a.value > b.value;
          });

          if (other !== null) {
            values.push(item);
          }

          return values;
        },
        isValidListItem: function (item, target) {
          return item.value !== "";
        },
        afterItemDisplayed: function (containerId, item) {
          FormUtility.removeSelectOption(item.value, "proposedPayInfoIncentivesApprTABG");
        },
        afterItemDeleted: function (containerId, targetId, item, values) {
          var target = FormUtility.addSelectionAndSortExceptLast(item.text, item.value, "proposedPayInfoIncentivesApprTABG", "Other");
          target.selectedIndex = values.length === 0 ? 0 : -1;
        },
        initialItems: FormState.getElementArrayValue('proposedPayInfoIncentivesApprTABG', [])
      };

      _proposedPayInfoTABG_ac = FormAutoComplete.makeAutoCompletion(option);
    }

    function clearExceptionalQualificationsFields() {
      FormState.updateTextValue("excepQualAmountRequested_1", "", true);
      FormState.updateTextValue("excepQualJustification_1", "", true);
      FormState.updateTextValue("excepQualAmountRequested_2", "", true);
      FormState.updateTextValue("excepQualJustification_2", "", true);
      FormState.updateTextValue("excepQualAmountRequested_3", "", true);
      FormState.updateTextValue("excepQualJustification_3", "", true);
      FormState.updateTextValue("excepQualAmountRequested_4", "", true);
      FormState.updateTextValue("excepQualJustification_4", "", true);
      FormState.updateTextValue("excepQualAmountRequested_5", "", true);
      FormState.updateTextValue("excepQualJustification_5", "", true);
      calculateExcepQualTotalAmount();
    }

    function clearCurrentPayInfoFields() {
      FormState.updateSelectValue("currentPayInfoGrade", "", "Select One", true);
      FormState.updateSelectValue("currentPayInfoStep", "", "Select One", true);
      FormState.updateSelectValue("currentPayInfoTable", "1", "1", true);
      FormState.updateSelectValue("currentPayInfoTier", "", "Select One", true);
      FormState.updateTextValue("currentPayInfoPositionTitle", "", true);
      if (_currentPayInfoSpecialtyCertification_ac) {
        _currentPayInfoSpecialtyCertification_ac.deleteAllItems();     
      }
      handleOtherSpecialty([]);
      FormState.updateTextValue("currentPayInfoRecruitment", "", true);
      FormState.updateTextValue("currentPayInfoRelocation", "", true);
      FormState.updateTextValue("currentPayInfoRetention", "", true);
      FormState.updateTextValue("currentPayInfoBasePay", "", true);
      FormState.updateTextValue("currentPayInfoLocality", "", true);
      FormState.updateTextValue("currentPayInfoNotes", "", true);
      calculateCurrentPay();
    }

    function clearProposedPayInfoFields() {
      FormState.updateSelectValue("proposedPayInfoStep", "", "Select One", true);
      FormState.updateSelectValue("proposedPayInfoTable", "1", "1", true);
      setProposedPaySpecialties([], '');    
      FormState.updateTextValue("proposedPayInfoRecruitment", "", true);
      FormState.updateTextValue("proposedPayInfoRelocation", "", true);
      FormState.updateTextValue("proposedPayInfoRetention", "", true);
      FormState.updateTextValue("proposedPayInfoGSBasePay", "", true);
      if (_proposedPayInfoTABG_ac) {
        _proposedPayInfoTABG_ac.deleteAllItems();
      }
      FormState.updateTextValue("proposedPayInfoNotes", "", true);
      calculateProposedMarketPay();
    }

    function clearAllPdpDetailsValues() {
      FormState.updateSelectValue("marketPayRate", "", "Select One", true);
      FormState.updateSelectValue("currentFederalEmployee", "", "Select One", true);
      onCurrentFedEmpChanged('');

      FormState.updateSelectValue("execRespLevelOfResponsibility", "", "Select One", true);
      onLevelOfResponsabilityChanged('');

      clearExceptionalQualificationsFields();
      clearCurrentPayInfoFields();
      clearProposedPayInfoFields();
    }

    function onIncentiveTypeChanged(incentiveType) {
      clearAllPdpDetailsValues();
    }

    function addMandatoryConstraints() {
      if (factor_incentivesLookupObjArr.length > 0) {
        factor_incentivesLookupObjArr.forEach(function (obj) {
          var factor = obj.lookupTypeValue;
          FormMain.setMandatoryConstraint('excepQualAmountRequested_' + factor, true);
          FormMain.setMandatoryConstraint('excepQualJustification_' + factor, true);
        });
      }
    }

    function initEventHandlers() {

      $('#currentFederalEmployee').change(function (e) {
        var target = e.target;
        var isCurrentFedEmp = target.options[target.options.selectedIndex].value;
        onCurrentFedEmpChanged(isCurrentFedEmp);
      });

      $('#execRespLevelOfResponsibility').change(function (e) {
        var target = e.target;
        var levelSelected = target.options[target.options.selectedIndex].value;
        onLevelOfResponsabilityChanged(levelSelected);
      });

      if (factor_incentivesLookupObjArr.length > 0) {
        factor_incentivesLookupObjArr.forEach(function (obj) {
          var factor = obj.lookupTypeValue;
          $('#excepQualAmountRequested_' + factor).on('keyup', function (e) {
            var target = e.target;
            var amount = target.value;
            calculateExcepQualTotalAmount(factor, amount);
          });
        });
      }

      $('#currentPayInfoRecruitment,#currentPayInfoRelocation,#currentPayInfoRetention,#currentPayInfoBasePay,#currentPayInfoLocality').keyup(function (e) {
        var id = e.target.id;
        var value = e.target.value;
        calculateCurrentPay(id, value);
      });

      $('#proposedPayInfoRecruitment,#proposedPayInfoRelocation,#proposedPayInfoRetention,#proposedPayInfoGSBasePay,#proposedPayInfoMarketPay').keyup(function (e) {
        var id = e.target.id;
        var value = e.target.value;
        calculateProposedPay(id, value);
      });

      $('#currentPayOtherSpecialty').keyup(function (e) {
        var value = e.target.value;
        setProposedPaySpecialties(selectedSpecialties, value);
      })

      $('#execRespAmountRequested').keyup(function (e) {
        var id = e.target.id;
        var value = e.target.value;
        calculateProposedMarketPay(id, value);
      })
    }

    function initFormData() {
      setDetailsGradeOptions([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]);
      initLookupData('populate');
      initDropdowns();

      initLevelOfResponsabilityRelatedFields(FormState.getElementValue("execRespLevelOfResponsibility"));  
      initCurrentPayInfoTable(FormState.getElementValue("currentPayInfoTable"));
      initProposedPayInfoTable(FormState.getElementValue("proposedPayInfoTable"));
      initFactorRelatedFields();
      initCurrentFedEmpRelatedFields(FormState.getElementValue("currentFederalEmployee"));
    }
    
    function runCalculations() {
      calculateExcepQualTotalAmount();
      calculateCurrentPay();
      calculateProposedMarketPay();
    }

    function setAutoCompletionFields() {
      setSpecialtyCertificationAutoCompletion();
      handleOtherSpecialty(FormState.getElementArrayValue('currentPayInfoSpecialtyCertification', []));
      handleSpecialtyCertification();

      setIncentivesApprovedByTABGAutoCompletion();
    }

    function setPositionRelatedFields() {
      positionRequireBoardCert = FormState.getElementValue("requireBoardCert");

      FormState.updateTextValue("proposedPayInfoGrade", FormState.getElementValue("grade"), true);
      setProposedPayInfoStep(FormState.getElementValue("proposedPayInfoGrade"));
      FormState.updateTextValue("proposedPayInfoPositionTitle", FormState.getElementValue("positionTitle"), true);
    }

    function initComponents() {
      initFormData();

      if (activityStep.isSOReview() || activityStep.isHR_REVIEW_APPROVAL() || activityStep.isSOReviewForModification()) {
        addMandatoryConstraints();  
      }

      setPositionRelatedFields();
      runCalculations();
      setAutoCompletionFields();
    }

    function init(readOnly, tabObject) {
      _readOnly = readOnly;

      initComponents();
      initEventHandlers();
      FormMain.resetMandatoryMark(tabObject);

      _initialized = true;
    }

    function render(action) {
    }

    return {
      init: init
      , render: render
      , onRequireBoardCertChanged: onRequireBoardCertChanged
      , onPositionTitleChanged: onPositionTitleChanged
      , onGradeChanged: onGradeChanged
      , onIncentiveTypeChanged: onIncentiveTypeChanged
    }
  };

  var _initializer = window.cms_incentives_pdp_details || (window.cms_incentives_pdp_details = cms_incentives_pdp_details());
})(window);
