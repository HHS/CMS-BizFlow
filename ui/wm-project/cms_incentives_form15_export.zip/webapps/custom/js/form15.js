(function (window) {
  var cms_incentives_pdp_details = function () {
    var _readOnly = false;
    var _initialized = false;

    var all_incentivesLookupObjArr = [];
    var level_incentivesLookupObjArr = [];
    var factor_incentivesLookupObjArr = [];
    var payTable_incentivesLookupObjArr = [];


    function initLookupData(populate) {
      $.ajax({
        url: '/bizflowwebmaker/cms_incentives_service/incentivesLookup.do?retrieveValues=' + populate,
        dataType: 'xml',
        async: false,
        cache: false,
        success: function (xmlResponse) {
          var data = $('record', xmlResponse).map(function () {
            var lookupObj = {
              lookupType: $('LOOKUP_TYPE', this).text(),
              lookupTypeValue: $('LOOKUP_TYPE_VALUE', this).text(),
              tier: $('TIER', this).text(),
              minRange: $('MIN_RANGE', this).text(),
              maxRange: $('MAX_RANGE', this).text(),
              rangeLabel: $('MONETARY_RANGE_LABEL', this).text(),
            };
            all_incentivesLookupObjArr.push(lookupObj);
          }).get();
        }
      });
      initArrays();
    }

    function initArrays() {
      if (all_incentivesLookupObjArr.length > 0) {
        all_incentivesLookupObjArr.forEach(function (obj) {
          switch (obj.lookupType) {
            case 'LevelOfExecutiveResponsability':
              level_incentivesLookupObjArr.push(obj);
              break;
            case 'ExceptionalQualificationFactor':
              factor_incentivesLookupObjArr.push(obj);
              break;
            case 'PayTable':
              payTable_incentivesLookupObjArr.push(obj);
              break;
            default:
              break;
          }
        });
      }
    }

    function initDropdowns() {
      if (level_incentivesLookupObjArr.length > 0) {
        level_incentivesLookupObjArr.forEach(function (obj) {
          $('#execRespLevelOfResponsability').append($("<option></option>").attr("value", obj.lookupTypeValue).text(obj.lookupTypeValue));
        });
      }
      // var payTableDropdown = [];
      // payTable_incentivesLookupObjArr.forEach(function (obj) {
      //   if (!payTableDropdown.includes(obj.lookupTypeValue)) {
      //     payTableDropdown.push(obj.lookupTypeValue);
      //     $('#proposedPayInfoTable').append($("<option></option>").attr("value", obj.lookupTypeValue).text(obj.lookupTypeValue));
      //   }     
      // });
    }

    function initCurrentFedEmpRelatedFields(isCurrentFedEmp) {
      if (isCurrentFedEmp === 'No') {
        FormMain.setMandatoryConstraint("currentPayInfoGrade", false);
        FormMain.setComponentVisibility("currentPayInfoGrade_group", false);

        FormMain.setMandatoryConstraint("currentPayInfoStep", false);
        FormMain.setComponentVisibility("currentPayInfoStep_group", false);

        FormMain.setComponentVisibility("currentPayInfoTable_group", false);

        FormMain.setComponentVisibility("currentPayInfoTier_group", false);
      } else {
        FormMain.setMandatoryConstraint("currentPayInfoGrade", true);
        FormMain.setComponentVisibility("currentPayInfoGrade_group", true);

        FormMain.setMandatoryConstraint("currentPayInfoStep", true);
        FormMain.setComponentVisibility("currentPayInfoStep_group", true);

        FormMain.setComponentVisibility("currentPayInfoTable_group", true);

        FormMain.setComponentVisibility("currentPayInfoTier_group", true);
      }
    }

    function initFactorRelatedFields() {
      if (factor_incentivesLookupObjArr.length > 0) {
        factor_incentivesLookupObjArr.forEach(function (obj) {
          var factor = obj.lookupTypeValue;
          FormState.updateTextValue("excepQualMonetaryRange_" + factor, obj.rangeLabel, true);
          setRangeConstraint("excepQualAmountRequested_" + factor, obj.minRange, obj.maxRange);
        });
      }

    }

    function setDetailsGradeOptions(grades) {
      var selObj = $('#currentPayInfoGrade');
      selObj.children('option:not(:first)').remove();
      if (grades) {
        var selectedGrade = "";
        var cnt = 0;
        for (var g = 0; g < grades.length; g++) {
          var grade = grades[g];
          if (grade) {
            cnt++;
            if (typeof grade === 'number' && grade < 10) {
              grade = '0' + grade;
            }
            selObj.append($("<option></option>").attr("value", grade).text(grade));
            if (cnt === 1) {
              selectedGrade = grade;
            }
          }
        }
        if (_initialized) {
          if (cnt > 1) {
            selectedGrade = "";
          }
          FormState.updateSelectValue("currentPayInfoGrade", selectedGrade, selectedGrade, true);
          // onGradeChanged(selectedGrade);
        }
      }
    }

    function initLevelOfResponsabilityRelatedFields(levelSelected) {
      if (levelSelected && levelSelected != '') {
        FormState.updateSelectValue("execRespLevelOfResponsability", levelSelected, levelSelected, true);
        FormMain.setMandatoryConstraint("execRespAmountRequested", true);
        FormMain.setMandatoryConstraint("execRespJustification", true);
        levelSelectedValues = getLevelSelectedValues(levelSelected);
        if (levelSelectedValues.levelTier == '1') {
          FormMain.setComponentUsability("execRespAmountRequested", false);
          FormMain.setComponentUsability("execRespJustification", false);
        } else {
          setRangeConstraint("execRespAmountRequested", levelSelectedValues.levelMin, levelSelectedValues.levelMax);
        }
      }
    }

    function onLevelOfResponsabilityChanged(levelSelected) {
      if (levelSelected != '') {
        FormMain.setMandatoryConstraint("execRespAmountRequested", true);
        FormMain.setMandatoryConstraint("execRespJustification", true);

        populateLevelOfResponsabilityRelatedFields(getLevelSelectedValues(levelSelected));
      } else {
        FormMain.setMandatoryConstraint("execRespAmountRequested", false);
        FormMain.setMandatoryConstraint("execRespJustification", false);

        resetLevelOfResponsabilityRelatedFields();
      }
    }

    function getLevelSelectedValues(levelSelected) {
      var levelSelectedValues = {
        levelTier: '',
        levelMin: '',
        levelMax: '',
        levelRangeLabel: ''
      };
      if (level_incentivesLookupObjArr.length > 0) {
        level_incentivesLookupObjArr.forEach(function (obj) {
          if (obj.lookupTypeValue == levelSelected) {
            levelSelectedValues.levelTier = obj.tier;
            levelSelectedValues.levelMin = obj.minRange;
            levelSelectedValues.levelMax = obj.maxRange;
            levelSelectedValues.levelRangeLabel = obj.rangeLabel;
          }
        });
      }

      return levelSelectedValues;
    }

    function populateLevelOfResponsabilityRelatedFields(levelSelectedValues) {
      if (levelSelectedValues.levelTier == '1') {
        FormState.updateTextValue("execRespAmountRequested", "$" + levelSelectedValues.levelMax, true);
        FormMain.setComponentUsability("execRespAmountRequested", false);

        FormState.updateTextValue("execRespJustification", "Non-supervisory Position", true);
        FormMain.setComponentUsability("execRespJustification", false);
      } else {
        resetLevelOfResponsabilityRelatedFields();
        setRangeConstraint("execRespAmountRequested", levelSelectedValues.levelMin, levelSelectedValues.levelMax);
      }
      FormState.updateTextValue("currentPayInfoTier", levelSelectedValues.levelTier.toUpperCase(), true);
      FormState.updateTextValue("execRespMonetaryRange", levelSelectedValues.levelRangeLabel, true);
    }

    function resetLevelOfResponsabilityRelatedFields() {
      FormState.updateTextValue("execRespMonetaryRange", "", true);

      FormState.updateTextValue("execRespAmountRequested", "", true);
      FormMain.setComponentUsability("execRespAmountRequested", true);
      $('#execRespAmountRequested').attr("data-wm-error-msg", " This field is invalid.");

      FormState.updateTextValue("execRespJustification", "", true);
      FormMain.setComponentUsability("execRespJustification", true);

      FormState.updateTextValue("currentPayInfoTier", "", true);
    }

    function setRangeConstraint(id, min, max) {
      var field = document.getElementById(id);
      var minRangeInt = parseInt(min);
      var maxRangeInt = parseInt(max);
      field.setAttribute("data-wm-error-msg", "The Amount Requested must be between the values of $" + minRangeInt.format(0)
        + " and $" + maxRangeInt.format(0));
      FormUtility.setInclusiveRangeConstraint(field, minRangeInt - 0.001, maxRangeInt);
    }

    function onGradeChanged(grade) {
    }

    function onCurrentFedEmpChanged(isCurrentFedEmp) {
      if (isCurrentFedEmp === 'No') {
        FormMain.setMandatoryConstraint("currentPayInfoGrade", false);
        FormState.updateSelectValue("currentPayInfoGrade", "", "Select One", true);
        FormMain.setComponentVisibility("currentPayInfoGrade_group", false);

        FormMain.setMandatoryConstraint("currentPayInfoStep", false);
        FormState.updateSelectValue("currentPayInfoStep", "", "Select One", true);
        FormMain.setComponentVisibility("currentPayInfoStep_group", false);

        FormMain.setComponentVisibility("currentPayInfoTable_group", false);

        FormMain.setComponentVisibility("currentPayInfoTier_group", false);
      } else {
        FormMain.setMandatoryConstraint("currentPayInfoGrade", true);
        FormMain.setComponentVisibility("currentPayInfoGrade_group", true);

        FormMain.setMandatoryConstraint("currentPayInfoStep", true);
        FormMain.setComponentVisibility("currentPayInfoStep_group", true);

        FormMain.setComponentVisibility("currentPayInfoTable_group", true);

        FormMain.setComponentVisibility("currentPayInfoTier_group", true);
      }
    }

    function calculateCurrentPay(opt) {
      // opt = opt || {};
      // var currentPayInfoRecruitment = FormUtility
      //   .moneyToNumber(undefined !== opt.currentPayInfoRecruitment ? opt.currentPayInfoRecruitment : FormState.getElementValue("currentPayInfoRecruitment"), 0);
      // var currentPayInfoRelocation = FormUtility
      //   .moneyToNumber(undefined !== opt.currentPayInfoRelocation ? opt.currentPayInfoRelocation : FormState.getElementValue("currentPayInfoRelocation"), 0);
      // var currentPayInfoRetention = FormUtility
      //   .moneyToNumber(undefined !== opt.currentPayInfoRetention ? opt.currentPayInfoRetention : FormState.getElementValue("currentPayInfoRetention"), 0);
      // var currentPayInfoBasePay = FormUtility
      //   .moneyToNumber(undefined !== opt.currentPayInfoBasePay ? opt.currentPayInfoBasePay : FormState.getElementValue("currentPayInfoBasePay"), 0);
      // var currentPayInfoLocality = FormUtility
      //   .moneyToNumber(undefined !== opt.currentPayInfoLocality ? opt.currentPayInfoLocality : FormState.getElementValue("currentPayInfoLocality"), 0);
      //
      // var total3Rs = "$" + (currentPayInfoRecruitment + currentPayInfoRelocation + currentPayInfoRetention).format();
      // FormState.updateDijitInputInner("currentPayInfoTotal3R", total3Rs);
      // var totalAnnual = "$" + (currentPayInfoBasePay + currentPayInfoLocality).format();
      // FormState.updateDijitInputInner("currentPayInfoTotalAnnualPay", totalAnnual);
      // var total = "$" + (currentPayInfoRecruitment + currentPayInfoRelocation + currentPayInfoRetention + currentPayInfoBasePay + currentPayInfoLocality).format();
      // FormState.updateDijitInputInner("currentPayInfoTotalAnnualComp", total);
    }

    function initEventHandlers() {

      $('#currentFederalEmployee').change(function (e) {
        var target = e.target;
        var isCurrentFedEmp = target.options[target.options.selectedIndex].value;
        onCurrentFedEmpChanged(isCurrentFedEmp);
      });

      $('#execRespLevelOfResponsability').change(function (e) {
        var target = e.target;
        var levelSelected = target.options[target.options.selectedIndex].value;
        onLevelOfResponsabilityChanged(levelSelected);
      });

      // THIS IS FOR THE 3RS TOTAL SUM
      $('#currentPayInfoRecruitment').on('blur', function (e) {
        var target = e.target;
        var value = target.value;
        calculateCurrentPay({ currentPayInfoRecruitment: value });
      });
      $('#currentPayInfoRelocation').on('blur', function (e) {
        var target = e.target;
        var value = target.value;
        calculateCurrentPay({ currentPayInfoRelocation: value });
      });
      $('#currentPayInfoRetention').on('blur', function (e) {
        var target = e.target;
        var value = target.value;
        calculateCurrentPay({ currentPayInfoRetention: value });
      });
      $('#currentPayInfoBasePay').on('blur', function (e) {
        var target = e.target;
        var value = target.value;
        calculateCurrentPay({ currentPayInfoBasePay: value });
      });
      $('#currentPayInfoLocality').on('blur', function (e) {
        var target = e.target;
        var value = target.value;
        calculateCurrentPay({ currentPayInfoLocality: value });
      });

    }

    function initComponents() {
      setDetailsGradeOptions([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]);
      initLookupData('populate');
      initDropdowns();
      initLevelOfResponsabilityRelatedFields(FormState.getElementValue("execRespLevelOfResponsability"));
      initFactorRelatedFields();
      initCurrentFedEmpRelatedFields(FormState.getElementValue("currentFederalEmployee"));
      //THIS IS FOR THE 3RS TOTAL SUM
      calculateCurrentPay({
        currentPayInfoRecruitment: FormState.getElementValue("currentPayInfoRecruitment"),
        currentPayInfoRelocation: FormState.getElementValue("currentPayInfoRelocation"),
        currentPayInfoRetention: FormState.getElementValue("currentPayInfoRetention"),
        currentPayInfoBasePay: FormState.getElementValue("currentPayInfoBasePay"),
        currentPayInfoLocality: FormState.getElementValue("currentPayInfoLocality")
      });
    }

    function init(readOnly, tabObject) {
      _readOnly = readOnly;

      initComponents();
      initEventHandlers();
      FormMain.resetMandatoryMark(tabObject);

      _initialized = true;
    }

    function render(action) {
    }

    return {
      init: init,
      render: render//,
      // populateRelatedFields: populateRelatedFields,
      // onIncentiveTypeChange: onIncentiveTypeChanged,
      // postDisableTab: postDisableTab
    }
  };

  var _initializer = window.cms_incentives_pdp_details || (window.cms_incentives_pdp_details = cms_incentives_pdp_details());
})(window);
