(function (window) {
  var cms_incentives_pdp_details = function () {
    var _readOnly = false;
    var _initialized = false;
    var _dutyStation_ac = null;

    function onCurrentFedEmpChanged(isCurrentFedEmp) {
      if (isCurrentFedEmp === 'No') {
        FormMain.setMandatoryConstraint("currentPayInfoGrade", false);
        FormState.updateSelectValue("currentPayInfoGrade", "", "Select One", true);
        FormMain.setComponentVisibility("currentPayInfoGrade_group", false);

        FormMain.setMandatoryConstraint("currentPayInfoStep", false);
        FormState.updateSelectValue("currentPayInfoStep", "", "Select One", true);
        FormMain.setComponentVisibility("currentPayInfoStep_group", false);

        FormMain.setComponentVisibility("currentPayInfoTable_group", false);

        FormMain.setComponentVisibility("currentPayInfoTier_group", false);
      } else {
        FormMain.setMandatoryConstraint("currentPayInfoGrade", true);
        FormMain.setComponentVisibility("currentPayInfoGrade_group", true);

        FormMain.setMandatoryConstraint("currentPayInfoStep", true);
        FormMain.setComponentVisibility("currentPayInfoStep_group", true);

        FormMain.setComponentVisibility("currentPayInfoTable_group", true);

        FormMain.setComponentVisibility("currentPayInfoTier_group", true);
      }
    }

    function setDropdownValues(populate) {
      //var selObj = $('#execRespLevelOfResponsability');
      // selObj.children('option:not(:first)').remove();
      //             if ($( 'LOOKUP_TYPE', this ).text() == 'LevelOfExecutiveResponsability') {
      //               selObj.append($("<option></option>").attr("value", $( 'LOOKUP_TYPE_VALUE', this ).text()).text($( 'LOOKUP_TYPE_VALUE', this ).text()));
      // $('#OWNING_ORG_CODE').append('<option value=\"' + $( 'LOOKUP_TYPE_VALUE', this ).text() + '\">' + $( 'LOOKUP_TYPE_VALUE', this ).text() + '</option>');
      //             }
      // $.ajax({
      //   url: '/bizflowwebmaker/cms_incentives_service/incentivesLookup.do?dropdownValues=' + populate,
      //   dataType: 'xml',
      //   cache: false,
      //   success: function (xmlResponse) {
      //     var data = $('record', xmlResponse).map(function () {
      //       $('#execRespLevelOfResponsability').children('option:not(:first)').remove();
      //       if ($('LOOKUP_TYPE', this).text() == 'LevelOfExecutiveResponsability') {              
      //         $('#execRespLevelOfResponsability').append('<option value=\"' + $('LOOKUP_TYPE_VALUE', this).text() + '\">' + $('LOOKUP_TYPE_VALUE', this).text() + '</option>');
      //       }

      //     }).get();
      //   }
      // });
    }

    function onLevelOfResponsabilityChanged(levelSelected) {
      if (levelSelected != '') {
        FormMain.setMandatoryConstraint("execRespAmountRequested", true);
        FormMain.setMandatoryConstraint("execRespJustification", true);

        populateLevelOfResponsabilityRelatedFields(callLkpServiceLevelSelected("LevelOfExecutiveResponsability", levelSelected));
      } else {
        FormMain.setMandatoryConstraint("execRespAmountRequested", false);
        FormMain.setMandatoryConstraint("execRespJustification", false);

        resetLevelOfResponsabilityRelatedFields();
      }
    }

    function populateLevelOfResponsabilityRelatedFields(incentivesLookupData) {
      if (incentivesLookupData.tier == '1') {
        FormState.updateTextValue("execRespAmountRequested", "$" + incentivesLookupData.maxRange, true);
        FormMain.setComponentUsability("execRespAmountRequested", false);

        FormState.updateTextValue("execRespJustification", "Non-supervisory Position", true);
        FormMain.setComponentUsability("execRespJustification", false);
      } else {
        resetLevelOfResponsabilityRelatedFields();
        var field = document.getElementById("execRespAmountRequested");
        var maxRangeInt = parseInt(incentivesLookupData.maxRange);
        var minRangeInt = parseInt(incentivesLookupData.minRange);
        field.setAttribute("data-wm-error-msg", "The Amount Requested must be between the values of $" + minRangeInt.format(0)
          + " and $" + maxRangeInt.format(0));
        FormUtility.setInclusiveRangeConstraint(field, minRangeInt, maxRangeInt);
      }
      FormState.updateTextValue("currentPayInfoTier", incentivesLookupData.tier, true);
      FormState.updateTextValue("execRespMonetaryRange", incentivesLookupData.rangeLabel, true);
    }

    function resetLevelOfResponsabilityRelatedFields() {
      FormState.updateTextValue("execRespMonetaryRange", "", true);

      FormState.updateTextValue("execRespAmountRequested", "", true);
      FormMain.setComponentUsability("execRespAmountRequested", true);

      FormState.updateTextValue("execRespJustification", "", true);
      FormMain.setComponentUsability("execRespJustification", true);

      FormState.updateTextValue("currentPayInfoTier", "", true);
    }

    function callLkpServiceLevelSelected(lookupType, levelSelected) {
      //delete this code to call ajax without tier and using
      var incentivesLookupData = {};
      // switch (levelSelected) {
      //   case "Staff_Physician_or_Dentist":
      //   case "Non_Supervisory_Regional_Office_Chief_Physician_or_Dentist":
      //     incentivesLookupData = getIncentivesLkpData(lookupType, levelSelected, "1");
      //     break;
      //   case "Supervisor":
      //   case "Division_Director":
      //   case "Deputy_Division_Director":
      //     incentivesLookupData = getIncentivesLkpData(lookupType, levelSelected, "2");
      //     break;
      //   case "Group_Director":
      //   case "Deputy_Group_Director":
      //     incentivesLookupData = getIncentivesLkpData(lookupType, levelSelected, "3a");
      //     break;
      //   case "Center_or_Office_Director":
      //   case "Center_or_Office_Deputy_Director":
      //   case "CMS_Chief_Physician_or_Dentist":
      //   case "CMS Deputy Chief Physician or Dentist":
      //     incentivesLookupData = getIncentivesLkpData(lookupType, levelSelected, "3b");
      //     break;
      //   default:

      // }
      return incentivesLookupData;
    }

    // function getIncentivesLkpData(lookupType, lookupTypeValue, opt) {
    //   var incentivesLookupData = {
    //     lookupType: lookupType,
    //     lookupTypeValue: lookupTypeValue,
    //     tier: tier,
    //     minRange: '',
    //     maxRange: '',
    //     rangeLabel: ''
    //   };

    //   var url;
    //   url = '/bizflowwebmaker/cms_incentives_service/incentivesLookup.do?LookupTypeValue=' + lookupTypeValue + '&LookupType=' + lookupType + '&Tier=' + tier;
    //   $.ajax({
    //       url: url,
    //       dataType: 'xml',
    //       cache: false,
    //       async: false,
    //       success: function (xmlResponse) {
    //         var data = $('record', xmlResponse ).map(function() {
    // 					incentivesLookupData.minRange = $( 'MIN_RANGE', this ).text();
    // 					incentivesLookupData.maxRange = $( 'MAX_RANGE', this ).text();
    // 					incentivesLookupData.rangeLabel =  $( 'MONETARY_RANGE_LABEL', this ).text();
    // 				}).get();
    //       }
    //   });
    //   return incentivesLookupData;
    // }

    function setGradeOptions(grades) {
      var selObj = $('#currentPayInfoGrade');
      selObj.children('option:not(:first)').remove();
      if (grades) {
        var selectedGrade = "";
        var cnt = 0;
        for (var g = 0; g < grades.length; g++) {
          var grade = grades[g];
          if (grade) {
            cnt++;
            if (typeof grade === 'number' && grade < 10) {
              grade = '0' + grade;
            }
            selObj.append($("<option></option>").attr("value", grade).text(grade));
            if (cnt === 1) {
              selectedGrade = grade;
            }
          }
        }
        if (_initialized) {
          if (cnt > 1) {
            selectedGrade = "";
          }
          FormState.updateSelectValue("currentPayInfoGrade", selectedGrade, selectedGrade, true);
          onGradeChanged(selectedGrade);
        }
      }
    }

    function onGradeChanged(grade) {
      // setPVPayPlanSeriesGrade(FormState.getElementValue('payPlan', ''), FormState.getElementValue('series', ''), grade);
      // setPositionDescriptionNumber(grade);
      // if (_initialized) {
      //     if (cms_incentives_pca_details) {
      //         cms_incentives_pca_details.onGradeChanged(grade);
      //     }
      //     if (cms_incentives_sam_details) {
      //         cms_incentives_sam_details.onGradeChanged(grade);
      //     }
      //     if(cms_incentives_sam_review) {
      //         cms_incentives_sam_review.onGradeChanged(grade);
      //     }
      // }
    }

    function calculateCurrentPay(opt) {
      // opt = opt || {};
      // var currentPayInfoRecruitment = FormUtility
      //   .moneyToNumber(undefined !== opt.currentPayInfoRecruitment ? opt.currentPayInfoRecruitment : FormState.getElementValue("currentPayInfoRecruitment"), 0);
      // var currentPayInfoRelocation = FormUtility
      //   .moneyToNumber(undefined !== opt.currentPayInfoRelocation ? opt.currentPayInfoRelocation : FormState.getElementValue("currentPayInfoRelocation"), 0);
      // var currentPayInfoRetention = FormUtility
      //   .moneyToNumber(undefined !== opt.currentPayInfoRetention ? opt.currentPayInfoRetention : FormState.getElementValue("currentPayInfoRetention"), 0);
      // var currentPayInfoBasePay = FormUtility
      //   .moneyToNumber(undefined !== opt.currentPayInfoBasePay ? opt.currentPayInfoBasePay : FormState.getElementValue("currentPayInfoBasePay"), 0);
      // var currentPayInfoLocality = FormUtility
      //   .moneyToNumber(undefined !== opt.currentPayInfoLocality ? opt.currentPayInfoLocality : FormState.getElementValue("currentPayInfoLocality"), 0);
      //
      // var total3Rs = "$" + (currentPayInfoRecruitment + currentPayInfoRelocation + currentPayInfoRetention).format();
      // FormState.updateDijitInputInner("currentPayInfoTotal3R", total3Rs);
      // var totalAnnual = "$" + (currentPayInfoBasePay + currentPayInfoLocality).format();
      // FormState.updateDijitInputInner("currentPayInfoTotalAnnualPay", totalAnnual);
      // var total = "$" + (currentPayInfoRecruitment + currentPayInfoRelocation + currentPayInfoRetention + currentPayInfoBasePay + currentPayInfoLocality).format();
      // FormState.updateDijitInputInner("currentPayInfoTotalAnnualComp", total);
    }

    function initEventHandlers() {

      $('#currentFederalEmployee').change(function (e) {
        var target = e.target;
        var isCurrentFedEmp = target.options[target.options.selectedIndex].value;
        onCurrentFedEmpChanged(isCurrentFedEmp);
      });

      $('#execRespLevelOfResponsability').change(function (e) {
        var target = e.target;
        var levelSelected = target.options[target.options.selectedIndex].value;
        onLevelOfResponsabilityChanged(levelSelected);
      });

      // THIS IS FOR THE 3RS TOTAL SUM
      $('#currentPayInfoRecruitment').on('blur', function (e) {
        var target = e.target;
        var value = target.value;
        calculateCurrentPay({ currentPayInfoRecruitment: value });
      });
      $('#currentPayInfoRelocation').on('blur', function (e) {
        var target = e.target;
        var value = target.value;
        calculateCurrentPay({ currentPayInfoRelocation: value });
      });
      $('#currentPayInfoRetention').on('blur', function (e) {
        var target = e.target;
        var value = target.value;
        calculateCurrentPay({ currentPayInfoRetention: value });
      });
      $('#currentPayInfoBasePay').on('blur', function (e) {
        var target = e.target;
        var value = target.value;
        calculateCurrentPay({ currentPayInfoBasePay: value });
      });
      $('#currentPayInfoLocality').on('blur', function (e) {
        var target = e.target;
        var value = target.value;
        calculateCurrentPay({ currentPayInfoLocality: value });
      });

    }

    function initComponents() {
      setGradeOptions([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]);
      setDropdownValues('populate');
      onCurrentFedEmpChanged(FormState.getElementValue("currentFederalEmployee"));
      onLevelOfResponsabilityChanged(FormState.getElementValue("execRespLevelOfResponsability"));
      //THIS IS FOR THE 3RS TOTAL SUM
      calculateCurrentPay({
        currentPayInfoRecruitment: FormState.getElementValue("currentPayInfoRecruitment"),
        currentPayInfoRelocation: FormState.getElementValue("currentPayInfoRelocation"),
        currentPayInfoRetention: FormState.getElementValue("currentPayInfoRetention"),
        currentPayInfoBasePay: FormState.getElementValue("currentPayInfoBasePay"),
        currentPayInfoLocality: FormState.getElementValue("currentPayInfoLocality")
      });
    }

    function init(readOnly, tabObject) {
      _readOnly = readOnly;

      initComponents();
      initEventHandlers();
      FormMain.resetMandatoryMark(tabObject);

      _initialized = true;
    }

    function render(action) {
    }

    return {
      init: init,
      render: render//,
      // populateRelatedFields: populateRelatedFields,
      // onIncentiveTypeChange: onIncentiveTypeChanged,
      // postDisableTab: postDisableTab
    }
  };

  var _initializer = window.cms_incentives_pdp_details || (window.cms_incentives_pdp_details = cms_incentives_pdp_details());
})(window);
