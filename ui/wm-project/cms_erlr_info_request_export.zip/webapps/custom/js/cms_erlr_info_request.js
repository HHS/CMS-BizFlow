'use strict';
(function (window) {
    var cms_erlr_info_request = function () {
	
		var initialized = false;
		
		var dateFieldsPastPresent = 
		[
			'_IR_PROVIDE_DT',
			'IR_SUBMIT_DT',
			'_IR_DENIAL_NOTICE_DT'
		];
		
		var dateFieldsPresentFuture = 
		[
		];
		
		var reqFieldForActivity = 
		[
			{
				actName: globalVars.actAll,
				reqFieldIds: 
				[
				]
			},
			{
				actName: globalVars.actCaseCreation,
				reqFieldIds: 
				[
				]
			},
			{
				actName: globalVars.actCaseComplete,
				reqFieldIds: 
				[
				]
			}
		];

		var irProvideDtGroup, irDenialNoticeDtGroup;

		function initVisibility() {
            controlIrRequesterVisibility();
            controlIrApprovedVisibility();
            controlIrRequesterAppealDenialVisibility();
		}

		function setSelectElemValue(selElem) {
			if ( typeof selElem == 'undefined' || selElem == null 
					|| typeof selElem.id == 'undefined' || selElem.id == null 
					|| typeof selElem.options == 'undefined' || selElem.options == null ) {
				return;
			}
			var selectedVal = selElem.options[selElem.options.selectedIndex].value;
			var selectedTxt = selElem.options[selElem.options.selectedIndex].text;
			FormState.updateSelectValue(selElem.id, selectedVal, selectedTxt);
		}
		
		function controlIrRequesterVisibility() {
            var elemVal = FormState.getElementValue('IR_REQUESTER');
			CommonOpUtil.showHideLayoutGroup('ir_cms_requester_layout_group', ('CMS' === elemVal));
			CommonOpUtil.showHideLayoutGroup('ir_non_cms_requester_layout_group', ('NONCMS' === elemVal));
        }

        function controlIrApprovedVisibility() {
            var elemVal = FormState.getElementValue('IR_APPROVE');
            CommonOpUtil.showHideLayoutGroup('ir_provide_dt_group', ('Y' === elemVal));
            CommonOpUtil.showHideLayoutGroup('ir_not_approved_layout_group', ('N' === elemVal));
        }

        function controlIrRequesterAppealDenialVisibility() {
            var elemVal = FormState.getElementValue('IR_APPEAL_DENIAL');
            CommonOpUtil.showHideLayoutGroup('ir_appeal_denial_note_group', ('Y' === elemVal));
        }


		function initEventHandlers() {
			$('#IR_REQUESTER').on('change', function(e) {
				setSelectElemValue(e.target);
				controlIrRequesterVisibility();
			});
            $('#IR_APPROVE').on('change', function(e) {
                setSelectElemValue(e.target);
                controlIrApprovedVisibility();
            });
            $('#IR_APPEAL_DENIAL').on('change', function(e) {
                setSelectElemValue(e.target);
                controlIrRequesterAppealDenialVisibility();
            });


            irProvideDtGroup = MultiDataSelectField.init({ layoutGroupId: 'ir_provide_dt_group',
                                                                mandatory: true,
																dataFieldId: 'IR_PROVIDE_DT_LIST',
																sort: {fieldId:'IR_PROVIDE_DT', valueType: 'date', order: 'desc'},
																recordFields: ['IR_PROVIDE_DT']});

            irDenialNoticeDtGroup= MultiDataSelectField.init({ layoutGroupId: 'ir_denial_notice_dt_group',
                                                                mandatory: true,
																dataFieldId: 'IR_DENIAL_NOTICE_DT_LIST',
																sort: {fieldId:'IR_DENIAL_NOTICE_DT', valueType: 'date', order: 'desc'},
																recordFields: ['IR_DENIAL_NOTICE_DT','IR_DENIAL_NOTICE_REASON'],
                                                                dialog:{ input:{
                                                                                    init: function(){
                                                                                        $('#_IR_DENIAL_NOTICE_SELECT_REASON').on('change', function(e) {
                                                                                            var selElem = e.target;
                                                                                            var txt = '• ' + selElem.options[selElem.options.selectedIndex].text;
                                                                                            var val = $('#_IR_DENIAL_NOTICE_REASON').val().trim();
                                                                                            $('#_IR_DENIAL_NOTICE_REASON').val(val.length===0? txt : val + '\n' + txt);
                                                                                        });
                                                                                    }
                                                                                }
                                                                        }});

        }

        function setupCustomWidget() {
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_info_request::setupCustomWidget START');

            var searchRequesterNameOption = {
                id: 'IR_CMS_REQUESTER_NAME_SEARCH',
                baseURL: '/bizflowwebmaker/StratCon_AUT',
                targetURL: '/bizflowwebmaker/cms_erlr_service/contactInfo.do?emp=',
                minLength: 3,
                minSelectionCount: 0,
                maxSelectionCount: 1,
                mapFunction: function(context){
                    return {
                        email: $("EMAIL_ADDR", context).text(),
                        name:  $("LAST_NAME", context).text() + ', '+$("FIRST_NAME", context).text()+' '+$("MIDDLE_NAME", context).text()
                    }
                },
                getSelectionLabel: function(item){
                    return item.name + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '');
                },
                getCandidateLabel: function(item){
                    return item.name + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '');
                },
                getItemID:  function(item){
                    return item.email;
                },
                setDataToForm: function (values) {
                    FormState.updateObjectValue('IR_CMS_REQUESTER_NAME', values);
                },

                // initialize
                initialItems: FormState.getElementArrayValue('IR_CMS_REQUESTER_NAME', [])
            };
            FormAutoComplete.makeAutoCompletion(searchRequesterNameOption);

            // var SLRevDtObj = MultiDateSelection.setupMultiDateSelection({ dataElemId: 'rv_dt_selected',
			// 															dispElemId: 'rv_indecator',
			// 															inputElemId: 'IR_PROVIDE_DT',
			// 															btnElemId: 'btnIRProvideAddDt' });
			//

            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_info_request::setupCustomWidget END');
        }


        function init() {
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_info_request::init START');
			
			//-----------------------------------
			// visibility configuration
			//-----------------------------------
			initVisibility();
			
			
			//-----------------------------------
			// validation configuration
			//-----------------------------------
			dateFieldsPastPresent.forEach(function(item){
				hyf.calendar.setDateConstraint(item, 'Maximum', 'Today');
			});
			dateFieldsPresentFuture.forEach(function(item){
				hyf.calendar.setDateConstraint(item, 'Minimum', 'Today');
			});
			CommonOpUtil.dynamicMandatory(reqFieldForActivity);
			
			
			//-----------------------------------
			// event handler configuration
			//-----------------------------------
			initEventHandlers();
			
			
			//-----------------------------------
			// custom ui element initialization
			//-----------------------------------
			setupCustomWidget();
			
			initialized = true;
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_info_request::init END');
		}
		
		function render() {
            irProvideDtGroup.render();
            irDenialNoticeDtGroup.render();
		}

		return {
			initialized: initialized,
			render: render,
			init: init
		};
	};
	
    var _initializer = window.cms_erlr_info_request || (window.cms_erlr_info_request = cms_erlr_info_request());
})(window);

(function(window){
    'use strict';

    var MultiDataSelectField = function(){

        var init = function(config) {
            config = _.assignIn({unique:true,mandatory:false},config);
            var inputDialogSelector          = '#' + config.dataFieldId + '_input_dialog';
            var historyDialogSelector        = '#' + config.dataFieldId + '_history_dialog';
            var addButtonSelector            = '#' + config.dataFieldId + '_add_button';
            var historyLinkSelector          = '#' + config.dataFieldId + '_history_link';
            var historyTemplateSelector      = '#' + config.dataFieldId + '_history_template';
            var displayFieldGroupSelector    = '#' + config.dataFieldId + '_display_field_group';
            var historyTableSelector         = '#' + config.dataFieldId + '_history_table';

            var $multipleDataFieldGroup     = $('#'+config.layoutGroupId);
            $multipleDataFieldGroup.attr("_dataFieldId", config.dataFieldId);
            $multipleDataFieldGroup.addClass("multipleDataFieldLayoutGroup");
            if(config.mandatory){
                $multipleDataFieldGroup.addClass("isMandatory");
            }

            var $inputDialog = $(inputDialogSelector);

            var resetData = function(){
                $('#'+config.dataFieldId).val('');
                FormState.updateTextValue(config.dataFieldId, '', false);
            };
            var getJSONData = function(){
                var val = $('#'+config.dataFieldId).val();
                if(val.length === 0){
                    return [];
                }
                return JSON.parse(val);
            };
            var setData = function(data){
                var str = JSON.stringify(data);
                $('#'+config.dataFieldId).val(str);
                FormState.updateTextValue(config.dataFieldId, str, true);
            };
            var pushData = function(value, fieldID){
                var data = getJSONData();

                if(typeof (value) === 'object'){
                    data.push(value);
                }else{
                    var obj = {};
                    obj[fieldID] = value;
                    data.push(obj);
                }

                if(config.unique.fieldId){
                    data = _.uniqBy(data, config.unique.fieldId);
                }else if (typeof (config.unique) === 'boolean' && config.unique){
                    data = _.uniqBy(data, function(o){return JSON.stringify(o);});
                }

                if(config.sort){
                    data = _.sortBy(data, [function(o){
                        if(typeof(config.sort.valueType) !== 'undefined' && config.sort.valueType === 'date'){
                            return getDateFromFormat(o[config.sort.fieldId], 'MM/dd/yyyy');
                        }else{
                            return o[config.sort.fieldId];
                        }
                    }]);
                    if(config.sort.order && config.sort.order === 'desc'){
                        data = data.reverse();
                    }
                }

                setData(data);

                return data;
            };
            var toggleButtonLabel = function(show){
                var $addButton = $(addButtonSelector);
                var labelId = $addButton.attr("id") + "_label";
                if(show) {
                    $('#'+labelId).css("visibility", "visible");
                }else{
                    $('#'+labelId).css("visibility", "hidden");
                }
            };

            var render = function(){
                var data = getJSONData();
                if(0<data.length){
                    var firstItem = data[0];
                    $.each(config.recordFields, function(i, fieldId){
                    	$('#' + fieldId).text(firstItem[fieldId]);
					});
				}

                $(displayFieldGroupSelector).toggle(0<data.length);
                $(addButtonSelector).show();
                $(historyLinkSelector).toggle(0<data.length);
                toggleButtonLabel(0===data.length);
            };
            var addCallbackFunc = function(){
                var valid = true;
                var dialogId = $inputDialog.attr('id');
                var $dialogForm = $('#' + dialogId);
                $dialogForm.find('INPUT.textbox,SELECT.select,textarea.textbox').each(function(i,v){
                    var fieldId = $(this).attr("id");
                    if(fieldId){
                        valid = hyf.validation.validateField(fieldId, false);
                        if(!valid){
                            return false;
                        }
                    }
                });

                if(valid) {
                    var obj = getNewValue();
                    pushData(obj);
                }else{
                    return false;
                }
            };
            var getNewValue = function(){
                var ret = {};
                $('#'+inputDialogOption.layoutGroupId).find("input.textbox, select.select, textarea.textbox").each(function(){
                    var $this = $(this);
                    var tmpId = $this.attr('id');
                    if(tmpId && tmpId.indexOf('_') === 0){
                        var id = tmpId.substring(1);
                        if(config.recordFields && -1<config.recordFields.indexOf(id)){
                            ret[id] = $this.val();
                        }
                    }
                });
                return ret;
            };
            var inputDialogOption = {
                onEscape: true,
                buttons: {
                    confirm: {
                        label: 'Add',
                        className: 'btn-primary',
                        callback: addCallbackFunc
                    },
                    cancel:{
                        label: 'Cancel',
                        className: 'btn-default'
                    }
                }
            };

            // button label
            var $addButton = $(addButtonSelector);
            if(config.mandatory){
                var labelId = $addButton.attr("id") + "_label";
                var $label = $('#'+labelId);
                $label.html($label.text()+'<span class="mandatory" style="" title="Mandatory field"> * </span>');
                $addButton.parent().append('<i class="feedbackIcon" style="font-size: 13px; font-weight: 400;position:relative;right:-2px"></i>');
            }

            $addButton.on('click', function(e){
                if(typeof(inputDialogOption.message) === 'undefined'){
                    $inputDialog.removeClass('hide');
                    inputDialogOption.title = $inputDialog.attr("_title");
                    inputDialogOption.message = $inputDialog[0];
                    inputDialogOption.layoutGroupId = $inputDialog.attr("id");
                }

                var dialog = bootbox.dialog(inputDialogOption);
                dialog.init(function(){
                    CommonOpUtil.clearGroupContent(inputDialogOption.layoutGroupId);
                    if(config.dialog && config.dialog.input && config.dialog.input.init){
                        config.dialog.input.init();
                    }
                });
            });

            var deleteItemByIndex = function(index){
                var data = getJSONData();
                data.splice(index,1);
                setData(data);
                return data;
            };

            var displayHistory = function(){
                var data = getJSONData();
                $.each(data, function(idx, item){
                    item['dataFieldId'] = config.dataFieldId;
                    item['index'] = idx;
                });
                var view = {dataFieldId: config.dataFieldId, items:data};
                var historyData;
                if(0<data.length){
                    var template = $(historyTemplateSelector).text();
                    Mustache.parse(template, ['[[',']]']);
                    historyData = Mustache.render(template, view);

                }else{
                    historyData = "<h4>There is no historical record.</h4>"
                }

                var $historyDialog = $(historyDialogSelector);
                var dialog = bootbox.dialog({
                    title: $historyDialog.attr("_title"),
                    message: historyData,
                    onEscape: true,
                    buttons: {
                        cancel:{
                            label: 'Close',
                            className: 'btn-primary'
                        }
                    }
                });
                setTimeout(function(){
                    dialog.init(function(){
                        $(historyTableSelector + ' a.deleteAction').on('click', function(e){
                            var index = $(this).attr("_index");
                            var data = deleteItemByIndex(index);
                            bootbox.hideAll();
                            if(0<data.length){
                                displayHistory();
                            }
                        });
                    });
                }, 500);
			};

            $(historyLinkSelector).on('click', displayHistory);

            return {
                render:    render
            };
        };

        return {
            init: init
        };

    };

    var _initializer = window.MultiDataSelectField || (window.MultiDataSelectField = MultiDataSelectField());
})(window);
