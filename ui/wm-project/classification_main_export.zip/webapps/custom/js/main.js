// Required javascript files
//  lookupManager.js
var BFActivityOption = {
    _activityName: null,
    _currentActivity: null,
    _currentTabs: null,

    getCurrentActivityOption: function(activityName) {
        if (activityName != this._activityName) {
            this._currentActivity = null;
            this._currentTabs = null;
            this._activityName = activityName;
        }

        if (this._currentActivity == null) {
            if (activityName == null || activityName.length == 0) {
                activityName = "_Archive_";
            }

            // Find current activity name and tab information associated with current activity name
            var currentActList = [];  // using array since filter returns array, but we will have one or none in reality
            currentActList = BFActivityOption.actList.filter(function(node, index) {
                var memberCount = 0;
                if (node.usergroup.length > 0) {
                    node.usergroup.forEach(function(group) {
                        if (isCurrentUserMemberOf(group) == true) {
                            memberCount++;
                        }
                    })
                }
                return node.name == activityName && (memberCount == node.usergroup.length || memberCount > 0);
            });
            // If current activity is not in the BFActivityOption, add _Archive_ configuration
            if (currentActList.length == 0) {
                currentActList.push(BFActivityOption.actList[BFActivityOption.actList.length - 1]);
            }
            this._currentActivity = currentActList[0];
            this._currentTabs = this._currentActivity.tabs.slice();
        }
        return this._currentActivity;
    },
    getActiveTabList: function(activityName) {
        if (this._currentTabs == null) {
            var activityOption = this.getCurrentActivityOption(activityName);
        }
        return this._currentTabs;
    },
    addTabToCurrentActivity: function(activityName, tabID) {
        if (this._currentTabs != null) {
            for (var index = 0; index < this._currentTabs.length; index++) {
                if (this._currentTabs[index] == tabID) {
                    return; // Already exists.
                }
            }
            for (var index = 0; index < this._currentTabs.length; index++) {
                if (this._currentTabs[index] > tabID) {
                    this._currentTabs.splice(index, 0, tabID);
                    break;
                }
            }
        }
    },
    removeTabFromCurrentActivity: function(activityName, tabID) {
        if (this._currentTabs != null) {
            for (var index = 0; index < this._currentTabs.length; index++) {
                if (this._currentTabs[index] == tabID) {
                    this._currentTabs.splice(index, 1);
                    break;
                }
            }
        }
    },
    getCurrentTabID: function() {
        var currentTabs = $('#tab_control_container a.selectedTab');
        var tabCount = currentTabs.length;

        if (currentTabs.length > 0) {
            var tabAnchorID = currentTabs[0].attributes["id"].value;
            var tabID = CMSUtility.getTabIDFromAnchorID(tabAnchorID);
            return tabID;
        }
        return null;
    },
    getNextTabID: function(currentTabID) {
        if (this._currentTabs != null) {
            for (var index = 0; index < this._currentTabs.length; index++) {
                if (this._currentTabs[index] == currentTabID) {
                    if (index < this._currentTabs.length - 1) {
                        return this._currentTabs[index + 1];
                    }
                }
            }
        }
        return null;
    },
    getPreviousTabID: function(currentTabID) {
        if (this._currentTabs != null) {
            for (var index = 0; index < this._currentTabs.length; index++) {
                if (this._currentTabs[index] == currentTabID) {
                    if (index > 0) {
                        return this._currentTabs[index - 1];
                    }
                }
            }
        }
        return null;
    },

	//-------------------------------------------------------------------------
	// Activity List must be maintained as the target process definition changes
	//-------------------------------------------------------------------------
	// 1. Complete PD Coversheet and Classification Analysis
	// 2. Confirm Classification Analysis
	// 3. Confirm BUS Code
	// 4. Review DWC Entry
	// 5. Approve PD Coversheet - SO
	// 6. Approve Coversheet and Create Final Pkg
    actList: [
		{
            name: "Complete PD Coversheet and Classification Analysis",
            usergroup: [],
            tabs: ["tab1", "tab2", "tab3", "tab4", "tab6"],
            readonly: []
        }
		,{
            name: "Confirm Classification Analysis",
            usergroup: [],
            tabs: ["tab1", "tab2", "tab3", "tab4", "tab6"],
            readonly: ["tab1", "tab2", "tab3", "tab4"]
        }
		,{
            name: "Confirm BUS Code",
            usergroup: [],
            tabs: ["tab1", "tab2", "tab3", "tab4", "tab6"],
            readonly: ["tab1", "tab2", "tab3", "tab4"]
        }
		,{
            name: "Review DWC Entry",
            usergroup: [],
            tabs: ["tab1", "tab2", "tab3", "tab4", "tab6"],
            readonly: []
        }
		,{
            name: "Approve PD Coversheet - SO",
            usergroup: [],
            //tabs: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6"],
            //readonly: ["tab1", "tab2", "tab3", "tab4", "tab6"]
            tabs: ["tab5", "tab6"],
            readonly: []
        }
		,{
            name: "Approve Coversheet and Create Final Pkg",
            usergroup: [],
            tabs: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6"],
            readonly: ["tab1", "tab2", "tab3", "tab4"]
        }
		,{
            name: "_Archive_",
            usergroup: [],
            tabs: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6"],
            readonly: ["tab1", "tab2", "tab3", "tab4", "tab5", "tab6"]
        }
    ]
};

// Caution: Clear dependency is important.
// TabManager can call BFActivityOption, but BFActivityOption cannot call TabManager.
var TabManager = {
    totalLoadedTabCount: 0,
    getTab: function(tabID) {
        var selectedTabs = this.tabList.filter(function(node, index) {
            return node.id == tabID;
        });
        var foundTab = null;
        if (selectedTabs.length == 1) {
            foundTab = selectedTabs[0];
        }
        return foundTab;
    },
    loadTabFromAnchor: function(node) {
        var currentTabID = BFActivityOption.getCurrentTabID();
        var tabID = CMSUtility.getTabIDFromAnchor(node);
        var tab = this.getTab(tabID);

        if (tab.disabledHeader == false) {
            if (tabID == 'tab6' || TabManager.isTabCompleted(currentTabID) == true) {
                this.loadTab(tabID);
            } else {
                console.log("CLSFMAIN - TabManager.loadTabFromAnchor() - current tab is not completed. Canceled tab-change-request!");
            }
        }
        // Tab click on disabled tab should be ignored.
    },
    loadTab: function(tabID) {
        var selectedTab = this.getTab(tabID)
        if (selectedTab != null) {
            if (selectedTab.loaded == false) {
                callPartialPage(null, selectedTab.targetUrl, "system", selectedTab.targetGroup);
                selectedTab.loaded = true;
            }
        }
    },
    showTabHeader: function(tabID) {
        if ($('#' + CMSUtility.getAnchorID(tabID) + ':hidden').length > 0) {
            hyf.util.showComponent("tab_control_tab_" + tabID, null, null, null);
        }
    },
    hideTabHeader: function(tabID) {
        if ($('#' + CMSUtility.getAnchorID(tabID) + ':visible').length > 0) {
            hyf.util.hideComponent("tab_control_tab_" + tabID, null, null, null);
        }
    },
    enableTab: function(tabID) {
        hyf.util.enableComponent(tabID);
        $('#' + tabID + ' img[src="/bizflowwebmaker/StratCon_AUT/custom/images/delete-icon.png"]').show();
    },
    disableTab: function(tabID) {
        hyf.util.disableComponent(tabID);
        $('#' + tabID + ' img[src="/bizflowwebmaker/StratCon_AUT/custom/images/delete-icon.png"]').hide();
    },
    enableTabHeader: function(tabID) {
        var tab = this.getTab(tabID);
        if (tab != null) {
            tab.disabledHeader = false;
            var anchorID = CMSUtility.getAnchorID(tabID);
            $('#' + anchorID).removeClass('disabledTab');
            $('#' + anchorID).addClass('unselectedTab');
        } else {
            console.log("CLSFMAIN - TabManager.enableTabHeader() - tabID is null");
        }
    },
    disableTabHeader: function(tabID) {
        var tab = this.getTab(tabID);
        if (tab != null) {
            tab.disabledHeader = true;
            var anchorID = CMSUtility.getAnchorID(tabID);
            $('#' + anchorID).removeClass('unselectedTab');
            $('#' + anchorID).addClass('disabledTab');
        } else {
            console.log("CLSFMAIN - TabManager.disabledTabHeader() - tabID is null");
        }
    },
    allPreviousTabCompleted: function(tabID) {
        for (var index = 0; index < this.tabList.length; index++) {
            if (this.tabList[index].id == tabID) {
                break;
            }
            if (this.tabList[index].completed == false) {
                return false;
            }
        }
        return true;
    },
    validateTab: function(tabID) {
        var validationResultTab = true;
        if (tabID == 'tab2') {
            validationResultTab = validateClsfCodeCustom();
        } else if (tabID == 'tab3') {
            validationResultTab = validateFlsaExCustom();
        } 
		var validationResult = hyf.validation.validateContainer(document.getElementById(tabID));
        return validationResult && validationResultTab;
    },
    loadNextTab: function() {
        var currentTabID = BFActivityOption.getCurrentTabID();
        if (currentTabID != null) {
            var nextTabID = BFActivityOption.getNextTabID(currentTabID);
            if (nextTabID != null) {
                if (this.validateTab(currentTabID) == true) {
                    var nextTabID = BFActivityOption.getNextTabID(currentTabID);
                    while (nextTabID != null) {
                        this.enableTabHeader(nextTabID);
                        if (this.isTabCompleted(nextTabID) == true) {
                            nextTabID = BFActivityOption.getNextTabID(nextTabID);
                        } else {
                            break;
                        }
                    }
                    nextTabID = BFActivityOption.getNextTabID(currentTabID);
                    $('#' + CMSUtility.getAnchorID(nextTabID)).click();
                } else {
                    var nextTabID = BFActivityOption.getNextTabID(currentTabID);
                    while (nextTabID != null) {
                        if (nextTabID != 'tab6') {
                            this.disableTabHeader(nextTabID);
                            nextTabID = BFActivityOption.getNextTabID(nextTabID);
                        } else {
                            nextTabID = null;
                        }
                    }
                }
            }
        }
    },
    loadPreviousTab: function() {
        var currentTabID = BFActivityOption.getCurrentTabID();
        if (currentTabID != null) {
            var previousTabID = BFActivityOption.getPreviousTabID(currentTabID);
            while(previousTabID != null) {
                var tab = this.getTab(previousTabID);
                if (tab.disabledHeader == false) {
                    $('#' + CMSUtility.getAnchorID(previousTabID)).click();
                    break;
                } else {
                    previousTabID = BFActivityOption.getPreviousTabID(previousTabID);
                }
            }
        }
    },
    isTabCompleted: function(tabID) {
        var tab = this.getTab(tabID);
        var container = document.getElementById(tabID);
        var fv = hyf.FMAction.getFormValidator();
        var errors = fv.checkContainer(container);
        if (errors.length > 0) {
            tab.completed = false;
        } else {
            tab.completed = true;
        }
        return tab.completed;
    },
    // This function will be called after each tab is loaded.
    initTabAfterLoad: function(totalTabCount, tabID, activityName) {
        // var tab = this.getTab(tabID);
        // if (tab.onInit != null) {
        //     tab.onInit();
        // }
        // tab.completed = this.isTabCompleted(tabID);

        console.log('Tab loading is completed [' + tabID + '] -> ' + (this.totalLoadedTabCount + 1) + '/' + totalTabCount);
        this.totalLoadedTabCount += 1;
        if (this.totalLoadedTabCount == totalTabCount) {
            this.initTabsAfterAllTabLoaded();
        }
    },
    resetTabs : function() {
        var activeTabID = BFActivityOption.getCurrentTabID();
        hyf.util.setFieldValue('tab_control', activeTabID);

        var activeTabs = BFActivityOption.getActiveTabList(getActivityName());
        var leftTabNotCompleted = false;
        for (var index = 0; index < activeTabs.length; index++) {
            var currentTabCompleted = this.isTabCompleted(activeTabs[index]);
            var previousTabCompleted = (index > 0) ? this.isTabCompleted(activeTabs[index - 1]) : true;

            if (index == 0) {
                this.enableTabHeader(activeTabs[index]);
                document.getElementById(CMSUtility.getAnchorID(activeTabs[index])).className = 'selectedTab';
            } else {
                if (leftTabNotCompleted == true) {
                    if (activeTabs[index] == 'tab6') {
                        this.enableTabHeader(activeTabs[index]);
                    } else {
                        this.disableTabHeader(activeTabs[index]);
                    }

                } else {
                    this.enableTabHeader(activeTabs[index]);
                }
            }
            if (currentTabCompleted == false) {
                leftTabNotCompleted = true;
            }
        }
    },

    enableTabsForModification : function() {
        var activityName = getActivityName();
        var option = BFActivityOption.getCurrentActivityOption(activityName);
        option.readonly = [];

        var currentTabID = BFActivityOption.getCurrentTabID();
        this.enableTab(currentTabID);

		// call each tab's custom field enable/disable method
		// approval tab
		if (currentTabID == "tab5"){
			enableDisableClsfAprContent();
		}

        //hyf.util.enableComponent("button_apscm_return_2");
        CMSUtility.disableComponents(["btnApproveClsSpc","btnCancelReq_3", "btnModifyWorksheet"]);

        $('#h_modifyRequested').val('true');
    },

    // This function will be called after all tabs are loaded.
    initTabsAfterAllTabLoaded: function() {
        initMaxSize();
        
        $(document).trigger('CMS_ALL_TAB_LOADED');
        this.tabList.forEach(function(tab, index) {
            tab.onInit();
        });        

        this.resetTabs();

        // Disable tab based on BFActivityOption
        var activityName = getActivityName();
        var foundActivity = BFActivityOption.actList.filter(function(node, index) {
            return node.name == activityName;
        })
        if (foundActivity.length > 0) {
            foundActivity[0].readonly.forEach(function (tabID) {
                TabManager.disableTab(tabID);
            });
        }

        // Active previously selected tab if there is any
		var storedTabID = $('#currentTabID').val();
		if (storedTabID && storedTabID.length > 0) {
			var tab = this.getTab(storedTabID);
			if (tab.disabledHeader == false) {
				this.tabChanger(storedTabID);
				this.showHidePreNextButtons();
				$('#' + CMSUtility.getAnchorID(storedTabID)).focus();
			}
			$('#currentTabID').val(''); // clear current tab for closing page
        }
        
        greyOutScreen(false);

        var modificationRequested = $('#h_modifyRequested').val();
        if (modificationRequested == 'true') {
            this.enableTabsForModification();
        }

        var alertMessage = $('#pv_alertMessage').val();
        if (alertMessage != null && alertMessage.length > 0) {
            showAlertMessage(alertMessage);
            $('#pv_alertMessage').val("");
        }
    },
    // This function should be called before loading tabs.
    // This function is to add TabManager.initTabAFterLoad function to each tabs so that inittabAFterLoad can be called.
    initResponseHandler: function(totalTabCount) {
        if (window != null) {
            var activityName = getActivityName();
            this.tabList.forEach(function(tab) {
                window[tab.targetGroup + "ManipulateResponse"] = function(content, flag) {
                    content = content + '<div><script type="text/javascript">function ' + tab.targetGroup +
                        '_processAfterLoad() {TabManager.initTabAfterLoad(' + totalTabCount + ',"' + tab.id + '","' + activityName + '" );};' +
                        'hyf.attachEventHandler(window, "onload",' + tab.targetGroup + '_processAfterLoad);</script></div>';
                    return content;
                }
            });
        } else {
            console.log("CLSFMAIN - initResponseHandler() - window is null.");
        }
    },

    _currentTab: '',

    // Sometimes webmaker loses _hyfCondDisplayIds property that affects tab behavior.
    // If it is not found, this property should be reinitialized to have the array of numbers from 0 to 8.
    ensureTabControlPropertyPopulated: function() {
        try {
            var hyfCondDisplayIDs = $('#tab_control')[0]._hyfCondDisplayIds;
            if (!hyfCondDisplayIDs) {
                $('#tab_control')[0]._hyfCondDisplayIds = [0, 1, 2, 3, 4, 5];
            } else {
                if (hyfCondDisplayIDs.length <= 0) {
                    $('#tab_control')[0]._hyfCondDisplayIds = [0, 1, 2, 3, 4, 5];
                }
            }
        } catch (e) {
        }
    },

    // This function is called whenever webmaker tab is clicked.
    // WebMaker form has default tabChanger function and this is custom one.
    tabChanger: function(value) {
        if (this._currentTab == value) {
            return;
        };
        _currentTab = value;
        this.ensureTabControlPropertyPopulated();

        this.resetTabs();

        var currentTabID = BFActivityOption.getCurrentTabID();
        var activeTabs = BFActivityOption.getActiveTabList(getActivityName());
		//debug
		console.log("tabChanger()"
			+ "\n value = " + value
			+ "\n currentTabID = " + currentTabID
			+ "\n activeTabs = " + activeTabs
			+ "\n isTabCompleted = " + this.isTabCompleted(currentTabID)
		);
        if (this.isTabCompleted(currentTabID) == true) {
            hyf.util.setFieldValue('tab_control', value);
            this.tabList.forEach(function(tab) {
                if (tab.disabledHeader == false) {
                    document.getElementById(CMSUtility.getAnchorID(tab.id)).className = 'unselectedTab';
                }
            });
            document.getElementById(CMSUtility.getAnchorID(value)).className = 'selectedTab';
        } else {
            if (isReadOnly() == false) {
                var nextTabID = BFActivityOption.getNextTabID(currentTabID);
                while (nextTabID != null) {
                    if (nextTabID != 'tab6') {
                        this.disableTabHeader(nextTabID);
                        nextTabID = BFActivityOption.getNextTabID(nextTabID);
                    } else {
                        hyf.util.setFieldValue('tab_control', value);
                        this.tabList.forEach(function(tab) {
                            if (tab.disabledHeader != true) {
                                document.getElementById(CMSUtility.getAnchorID(tab.id)).className = 'unselectedTab';
                            }
                        });
                        document.getElementById(CMSUtility.getAnchorID(value)).className = 'selectedTab';
                        nextTabID = null;
                    }
                }
                // If destination tab is in left side
                if (value < currentTabID) {
                    hyf.util.setFieldValue('tab_control', value);
                    this.tabList.forEach(function(tab) {
                        if (tab.disabledHeader == false) {
                            document.getElementById(CMSUtility.getAnchorID(tab.id)).className = 'unselectedTab';
                        }
                    });

                    document.getElementById(CMSUtility.getAnchorID(value)).className = 'selectedTab';
                } else {
    				if (typeof event != "undefined" && event != null){
    					event.preventDefault();
    				}
                }
            }
        }

        // Broadcast ON_TAB_CHANGE event.
        // Attachment controller in document tab is using this event to update mandatory document type list.
        $(document).trigger("ON_TAB_CHANGE");
        return false;
    },

    showHidePreNextButtons: function() {
        var selectedTabID = BFActivityOption.getCurrentTabID();
        var activeTabs = BFActivityOption.getActiveTabList();

        var currentTabIndex = 0;
        for (var index = 0; index < activeTabs.length; index++) {
            if (activeTabs[index] == selectedTabID) {
                currentTabIndex = index;
                break;
            }
        }

        if (currentTabIndex == 0) {
            hyf.util.disableComponent("button_Previous");
            hyf.util.enableComponent("button_Next");
        } else if (currentTabIndex == activeTabs.length - 1) {
            hyf.util.enableComponent("button_Previous");
            hyf.util.disableComponent("button_Next");
        } else {
            CMSUtility.enableComponents(["button_Previous","button_Next"])
        }
    },
    originalTabChanger: null,
    installCustomTabChanger: function() {
        if (window.tab_controlTabChange != null) {
            this.originalTabChanger = window.tab_controlTabChange;
            window.tab_controlTabChange = function(value) {
                var tab = TabManager.getTab(value);
                if (tab.disabledHeader == false) {
                    TabManager.tabChanger(value);
                    TabManager.showHidePreNextButtons();
                    if (!isReadOnly()) {
                        // save for tab change
                        enableTabsForSubmission();
                        captureSelDispVal();
                        callPartialPage(null, "saveTabContent.do", null, "async_save_pp_group");
                        rollbackTabsAfterSubmission();
                    }
                }
            }
        }
    },
    initTab: function() {
        var activityName = getActivityName();
        var currentActivityOption = BFActivityOption.getCurrentActivityOption(activityName);
        this.initResponseHandler(this.tabList.length);

        this.totalLoadedTabCount = 0;
        this.tabList.forEach(function(tab, index) {
			if (index == 0){
				hyf.util.setFieldValue('tab_control', tab.id);
			} else {
                // Enable document tab always
                if (tab.id != 'tab6') {
                    TabManager.disableTabHeader(tab.id);
                }
            }
            setTimeout(TabManager.loadTab(tab.id), 0);
        });

        var firstTab = true;
        // Hide Tabs
        this.tabList.forEach(function(item, tidx) {
			// set tabindex for each tab
			document.getElementById(CMSUtility.getAnchorID(item.id)).tabIndex = tidx + 10;  // start tabindex from 10 for tabs

            var showTabs = currentActivityOption.tabs.filter(function(showTabName, index) {
                return showTabName == item.id;
            })
            if (showTabs.length == 0) {
                TabManager.hideTabHeader(item.id);
            } else {
                TabManager.showTabHeader(item.id);
                if (firstTab == true) {
                    document.getElementById(CMSUtility.getAnchorID(item.id)).className = 'selectedTab';
                    if (item.id != 'tab1') {
                        document.getElementById(CMSUtility.getAnchorID('tab1')).className = 'unselectedTab';
                    }
                    firstTab = false;
					// calling click() will call tab save function, which is unnecessary and causing error
                    //$('#' + CMSUtility.getAnchorID(item.id)).click();
					var tab = TabManager.getTab(item.id);
					if (tab.disabledHeader == false) {
						TabManager.tabChanger(item.id);
						TabManager.showHidePreNextButtons();
					}
                }
            }
        });

        $(".tabContainer a").off("click").click(function(e) {
            e.preventDefault();
            TabManager.loadTabFromAnchor(this);
        });
        $('#button_Previous').off("click").click(function() {
            TabManager.loadPreviousTab();
        });
        $('#button_Next').off("click").click(function() {
            TabManager.loadNextTab();
        });
    },


	//-------------------------------------------------------------------------
	// tab list must be maintained per WebMaker project setting for target application
	//-------------------------------------------------------------------------
    tabList: [{
        id: "tab1",
        targetUrl: "/classification_main/general.do",
        targetGroup: "partial_tab1",
        name: "General",
        loaded: false,
        completed: false,
        disabledHeader: false,
        onInit: function() {
            $("select[id^=CS_FLSA_DETERM_ID_]").on("change", function() {
                showHidelFlsaTabs();
            });
            $("input[type=button][id^=RMV_GR_ID_]").on("click", function() {
				// clear FLSA determination value selected at the time Remove button is clicked
				var rmvBtnId = $(this)[0].id;
				if (typeof rmvBtnId != "undefined" && rmvBtnId != null && rmvBtnId.length > 1) {
					$("#CS_FLSA_DETERM_ID_" + rmvBtnId.substring(rmvBtnId.length - 1)).val("");
				}
                showHidelFlsaTabs();
            });
            showHidelFlsaTabs();
            classificationGEN.init();
        }
    }, {
        id: "tab2",
        targetUrl: "/classification_main/code.do",
        targetGroup: "partial_tab2",
        name: "Codes",
        loaded: false,
        completed: false,
        disabledHeader: false,
        onInit: function() {
            initCodeTab();
        }
    }, {
        id: "tab3",
        targetUrl: "/classification_main/flsa_ex.do",
        targetGroup: "partial_tab3",
        name: "FLSA - Exempt",
        loaded: false,
        completed: false,
        disabledHeader: false,
        onInit: function() {
            classificationFLSA.initExempt();
        }
    }, {
        id: "tab4",
        targetUrl: "/classification_main/flsa_nonex.do",
        targetGroup: "partial_tab4",
        name: "FLSA - Non-Exempt",
        loaded: false,
        completed: false,
        disabledHeader: false,
        onInit: function() {
            classificationFLSA.initNonExempt();
        }
    }, {
        id: "tab5",
		targetUrl: "/classification_main/approval.do",
        targetGroup: "partial_tab5",
        name: "Approvals",
        loaded: false,
        completed: false,
        disabledHeader: false,
        onInit: function() {
			$("#PD_SUPV_CERT").change(function() {
                if ($(this).prop("checked")) {
                    hyf.util.enableComponent("btnApproveSelOfc");
                    hyf.util.disableComponent("btnReturnToModify_2");
                } else {
                    hyf.util.enableComponent("btnReturnToModify_2");
                    hyf.util.disableComponent("btnApproveSelOfc");
                }
            });
            $("#PD_SUPV_CERT").trigger("change");
			
            $("#PD_CLS_SPEC_CERT").change(function() {
                if ($(this).prop("checked")) {
                    //CMSUtility.disableComponents(["btnSendToSelOfcReapprove", "btnModifyWorksheet", "btnCancelReq_3"])
					//hyf.util.enableComponent("btnApproveClsSpc");
					CMSUtility.disableComponents(["btnModifyWorksheet", "btnCancelReq_3"])
					if ($("#h_modifyRequested").val() != "true"){
						hyf.util.enableComponent("btnApproveClsSpc");
						hyf.util.disableComponent("btnSendToSelOfcReapprove");
					}
                } else {
                    CMSUtility.enableComponents(["btnSendToSelOfcReapprove", "btnModifyWorksheet", "btnCancelReq_3"])
                    hyf.util.disableComponent("btnApproveClsSpc");
                }
            });
            $("#PD_CLS_SPEC_CERT").trigger("change");

            initApproveTab();
        }
    }, {
        id: "tab6",
		targetUrl: "/cmscommon/showAttachment.do",
        targetGroup: "partial_tab6",
        name: "Documents",
        loaded: false,
        completed: false,
        disabledHeader: false,
        onInit: function() {            
        }
    }]
};

// UserGroup {
//      Name: GroupName,
//      ID: 0000000101,
//      Path: /root/GroupName }
var _CMS_myUserGroups = null;
function isCurrentUserMemberOf(userGroupName) {
    if (userGroupName == null || userGroupName.length == 0) {
        console.log("CLSFMAIN - isCurrentUserMemberOf() - userGroupName is null or empty.");
    }
    if (_CMS_myUserGroups == null) {
        var rawMyUserGroups = getCurrentUserGroupData();
        if (rawMyUserGroups != null && rawMyUserGroups.length > 0) {
            var x2js = new X2JS();
            _CMS_myUserGroups = x2js.xml_str2json(rawMyUserGroups);
            x2js = null;
        } else {
            _CMS_myUserGroups = {UserGroups: {}};
        }
    }

    if (_CMS_myUserGroups != null && _CMS_myUserGroups.UserGroups != null && _CMS_myUserGroups.UserGroups.UserGroup != null) {
        var foundGroups = _CMS_myUserGroups.UserGroups.UserGroup.filter(function(node, index) {
            return node.Name == userGroupName
        });
        return foundGroups.length > 0;
    } else {
        return false;
    }
}


/**
 * Enables active tabs before submitting the form.
 *
 * This is necessary because disabled field values will be blanked out when submitted.
 */
function enableTabsForSubmission() {
    TabManager.tabList.forEach(function(tab) {
        TabManager.enableTab(tab.id);
    })
}

function rollbackTabsAfterSubmission() {
    var activityName = getActivityName();
    var foundActivity = BFActivityOption.actList.filter(function(node, index) {
        return node.name == activityName;
    });
    if (foundActivity.length > 0) {
        var readonlyTabs = foundActivity[0].readonly;
        if (readonlyTabs.length > 0) {
            readonlyTabs.forEach(function(tab) {
                TabManager.disableTab(tab);
            })
        }

        if (activityName == 'Confirm BUS Code') {
            CMSUtility.enableComponents(["dwc_group"]);
        }

		// call each tab's custom field enable/disable method
		// approval tab
		if (foundActivity[0].tabs.filter(function(item){ return item == "tab5" }).length > 0){
			enableDisableClsfAprContent();
		}
    }
}

function submitTheFormToProceed(buttonID) {
    greyOutScreen(true);
    enableTabsForSubmission();
    captureSelDispVal();
    //$('#h_modifyRequested').val('');
    submitFormPage(buttonID, "saveNewForm");
}

/**
 * Sets up button event handlers.
 *
 * @param buttonID - String value of element ID for the button
 * @param validationRequired - Boolean value (true/false) to indicate whether validation is required as part of the button action
 * @param buttonOptions - Array of button options.  The object in array should be id/value pair.
 *         [{id: "requestStatus", value: "Started"}, {id: "requestNum", value: "20170305-0001"}]
 *         The id is used to identify the element, and the value is set to the element.
 * @param confirmMessage - The confirmation message content.
 *         If specified, confirmation dialog will popup as part of the button action
 *         before submitting form for save.
 */
function addButtonHandler(buttonID, validationRequired, buttonOptions, confirmMessage) {
    if (buttonID != null && buttonOptions != null) {
        $('#' + buttonID).off('click').click(function() {
            if (validationRequired == true) {
                //if (hyf.validation.validateForm() != true) {
                //    return;
                //}
				var activeTabs = BFActivityOption.getActiveTabList(getActivityName());
				for (var tabIndex = 0; tabIndex < activeTabs.length; tabIndex++) {
					var validated = TabManager.validateTab(activeTabs[tabIndex]);
					if (validated == false) {
						return;
					}
				}

                var mandatoryDocumentsValid = $('#h_mandatoryDocumentsValid').val();
				// We want to check document validation for any button click
                //if (mandatoryDocumentsValid != "true" && buttonID == "btnApproveClsSpc") {
				if (mandatoryDocumentsValid != "true") {
                    $('#' + CMSUtility.getAnchorID('tab6')).click();
                    bootbox.alert("Please upload the missing required document(s).");
                    return;
                }
            }

            if (confirmMessage != null && confirmMessage.length > 0) {
				bootbox.dialog({
					message: '<p class="bootbox-body">' + confirmMessage + '</p>',
					onEscape: true,
					buttons: [{
						label: 'Yes',
						className: 'btn-success',
						callback: function() {
							buttonOptions.forEach(function(option) {
								if (option.id == 'pv_requestStatusDate') {
									option.value = CMSUtility.getNowUTCString();
								}
								$('#' + option.id).val(option.value);
							})
                            submitTheFormToProceed(buttonID);
						}
					}, {
						label: 'No',
						className: 'btn-danger'
					}]
				});
            } else {
                buttonOptions.forEach(function(option) {
                    if (option.id == 'pv_requestStatusDate') {
                        option.value = CMSUtility.getNowUTCString();
                    }
                    $('#' + option.id).val(option.value);
                })
                submitTheFormToProceed(buttonID);
            }
        });
    } else {
        console.log("CLSFMAIN - addButtonHandler() - buttonID or buttonOption is null.");
    }
} // end addButtonHandler()


/**
 * Initializes the page layout per activity.
 * Depending on the activity, some sections may be displayed or hidden, different action buttons are presented, etc.
 */
function initLayoutPerActivity() {
    if (isReadOnly() == true) {
        $('#buttonSection').hide();
        $('#actionButtonCommonBottom').hide();
        return;
    }
	// 1. Complete PD Coversheet and Classification Analysis
	// 2. Confirm Classification Analysis
	// 3. Confirm BUS Code
	// 4. Review DWC Entry
	// 5. Approve PD Coversheet - SO
	// 6. Approve Coversheet and Create Final Pkg
	var activityName = getActivityName();
	if (activityName == "Complete PD Coversheet and Classification Analysis") {
		// CLS SPC
		// action [send, cancel]
		// requestStatus == "Request Cancelled" -> cancel, otherwise, move forward
		addButtonHandler("btnSendToSelOfc", true
			, [
				{id: "WIH_complete_requested", value: "true"}
				, {id: "pv_requestStatusDate", value: ""}
			]
		);
		$("#btnCancelReq_1").off("click").on("click", function() {
			popupCancellation();
		});
		$("#actionButtonPerActivityBottom").removeClass("hide");
		$("#init_pdc_clsf_action_group").removeClass("hide");
    } else if (activityName == "Confirm Classification Analysis") {
		// selectOfficial
		// action [send, modify]
		// coversheetApprovedBySO == "Yes" -> move forward, otherwise, back to CLS SPC
		addButtonHandler("btnSendToDwc", true
			, [
				{id: "WIH_complete_requested", value: "true"}
				, {id: "pv_coversheetApprovedBySO", value: "Yes"}
				, {id: "pv_requestStatusDate", value: ""}
			]
		);
		$("#btnReturnToModify_1").off("click").on("click", function(){
			sendBackForModification();
		});
		$("#actionButtonPerActivityBottom").removeClass("hide");
        $("#confirm_pdc_clsf_action_group").removeClass("hide");
    } else if (activityName == "Confirm BUS Code") {
		// DWC, but temporarily set as CLS SPC
		// action [send]
		// no reject, just move forward
		addButtonHandler("btnConfirmBus", true
			, [
				{id: "WIH_complete_requested", value: "true"}
				, {id: "pv_requestStatusDate", value: ""}
			]
		);
		$("#actionButtonPerActivityBottom").removeClass("hide");
		$("#dwc_action_group").removeClass("hide");
    } else if (activityName == "Review DWC Entry") {
		// classSpecialist
		// action [send, cancel]
		// requestStatus == "Request Cancelled" -> cancel, otherwise, move forward
		addButtonHandler("btnSendToSelOfcAprove", true
			, [
				{id: "WIH_complete_requested", value: "true"}
				, {id: "pv_requestStatusDate", value: ""}
			]
		);
		$("#btnCancelReq_2").off("click").on("click", function() {
			popupCancellation();
		});
		$("#actionButtonPerActivityBottom").removeClass("hide");
		$("#review_dwc_action_group").removeClass("hide");
    } else if (activityName == "Approve PD Coversheet - SO") {
		// selectOfficial
		// action [send, modify]
		// finalPackageApprovedSO == "Yes" -> move forward, otherwise, back to classSpecialist
		addButtonHandler("btnApproveSelOfc", true
			, [
				{id: "WIH_complete_requested", value: "true"}
				, {id: "pv_finalPackageApprovedSO", value: "Yes"}
				, {id: "pv_requestStatusDate", value: ""}
			]
		);
		$("#btnReturnToModify_2").off("click").on("click", function(){
			sendBackForModification();
		});
		$("#actionButtonPerActivityBottom").removeClass("hide");
		$("#aprove_pdc_action_group").removeClass("hide");
    } else if (activityName == "Approve Coversheet and Create Final Pkg") {
		// classSpecialist
		// action [send, reapprove, cancel]
		// requestStatus == "Request Cancelled" -> cancel, otherwise, move forward
		addButtonHandler("btnApproveClsSpc", true
			, [
				{id: "WIH_complete_requested", value: "true"}
				, {id: "pv_requestStatusDate", value: ""}
				, {id: "pv_returnToSO", value: "No"}
			]
			, "Are you sure that you want to end the Classification workflow?"
		);

        $('#btnSendToSelOfcReapprove').off("click").on("click", function() {
            sendBackForModification();
        });

        $('#btnModifyWorksheet').on('click', function() {
            popupModifyRequest();
        });

		$("#btnCancelReq_3").off("click").on("click", function() {
			popupCancellation();
		});
		$("#actionButtonPerActivityBottom").removeClass("hide");
		$("#aprove_final_action_group").removeClass("hide");
    } else {
		console.log("CLSFMAIN - initLayoutPerActivity() - No activity name matched [" + activityName + "]");
    }

	$("#button_cancel").off("click").on("click", function() {
		popupCancellation();
	});

}; // end initLayoutPerActivity()


//
// Form Cell Raw API
//
var _activityName = null;
function getActivityName() {
    if (_activityName == null) {
        _activityName = $('#h_activityName').attr('value');
        if (_activityName == null || _activityName.length == 0) {
            console.log("CLSFMAIN - getActivityName() - ActivityName is null or empty.")
        }
    }
    return _activityName;
}
var _readOnly = null;
function isReadOnly() {
    if (_readOnly == null) {
        _readOnly = $('#h_readOnly').val();
        if (_readOnly == 'y') {
            _readOnly = true;
        } else {
            _readOnly = false;
        }
    }
    return _readOnly;
}

var _currentUserGroupData = null;
function getCurrentUserGroupData() {
    if (_currentUserGroupData == null) {
        _currentUserGroupData = $('#h_userGroups').attr('value');
        if (_currentUserGroupData == null || _currentUserGroupData.length == 0) {
            console.log("CLSFMAIN - getCurrentUserGroupData() - ActivityName is null or empty.")
        }
    }
    return _currentUserGroupData;
}


function showAlertMessage(message) {
    var dialog = bootbox.dialog({
        title: 'Requested Changes',
        message: '<textarea disabled rows="5" class="bootbox-input bootbox-input-text form-control">' + message + '</textarea>',
        onEscape: true,
        buttons: {
            confirm: {
                label: 'OK',
                className: 'btn-success',
            }
        }
    });
}

/**
 * Opens Modify Classification Confirmation dialog.
 */
function popupModifyRequest() {
    bootbox.dialog({
        message: "Are you sure you want to modify classification?",
        onEscape: true,
        buttons: [{
            label: 'Yes',
            className: 'btn-success',
            callback: function() {
                TabManager.enableTabsForModification();
            }
        }, {
            label: 'No',
            className: 'btn-danger'
        }]
    });
}

/**
 * Opens Return for Modification of Classification dialog.
 */
function sendBackForModification() {
    var dialog = bootbox.dialog({
        title: "Please state the requested changes below",
        message: '<textarea rows="5" class="bootbox-input bootbox-input-text form-control"></textarea>',
        onEscape: true,
        buttons: {
            confirm: {
                label: 'OK',
                className: 'btn-success',
                callback: function() {
                    var message = $('div.bootbox textarea').val();
                    if (message != null && message.length > 0) {
                        setTimeout(function() {
                            $("#WIH_complete_requested").val("true");
							if ("Confirm Classification Analysis" == getActivityName()){
								$("#pv_requestStatus").val("Modify Coversheet and Classification Analysis");
								$("#pv_coversheetApprovedBySO").val("No");
								$("#pv_modifyCoversheetFeedback").val(message);
                                $('#pv_alertMessage').val(message);
							} else if ("Approve PD Coversheet - SO" == getActivityName()){
								$("#pv_requestStatus").val("Modify and Generate Final PD Package");
								$("#pv_finalPackageApprovedSO").val("No");
								$("#pv_modifyFinalPackageFeedback").val(message);
                                $('#pv_alertMessage').val(message);
							} else if ("Approve Coversheet and Create Final Pkg" == getActivityName()) {
								$("#pv_returnToSO").val("Yes");
								$("#pv_modifyFinalPackageClass").val(message);
                                $('#pv_alertMessage').val(message);
								$("#h_modifyRequested").val(""); // unset modify flag after witem send back is initiated
								clearClassificationApprovalForModification();
                            }
                            submitTheFormToProceed('button_modify');
                        }, 0);
                    } else {
                        return false;
                    }
                }
            },
            cancel: {
                label: 'Cancel',
                className: 'btn-danger'
            }
        }
    });

	$("div.bootbox button.btn-success").prop("disabled", true);

    $('div.bootbox textarea').on("change keyup paste", function() {
        var message = $(this).val();
        if (message.length > 500) {
            $(this).val(message.substring(0, 500));
        }

		if (message.length == 0) {
			$("div.bootbox button.btn-success").prop("disabled", true);
		} else {
			$("div.bootbox button.btn-success").prop("disabled", false);
		}
    });
} // end sendBackForModification()


/**
 * Opens Cancel Classification dialog.
 */
function popupCancellation() {
    var isUserSO = isCurrentUserMemberOf('Selecting Officials');
    var isUserLiaison = isCurrentUserMemberOf('HR Liaison');
    var isXO = isCurrentUserMemberOf('Executive Officers');
    var isClassificationSpecialist = isCurrentUserMemberOf('HR Classification Specialists');
    var isStaffingSpecialist = isCurrentUserMemberOf('HR Staffing Specialists');

    var reasons = [];

    if (isClassificationSpecialist == true) {
        reasons = LookupManager.findByLTYPE('UserGroup[HR Classification Specialists]/CancellationReason');
    } else if (isUserSO == true) {
        reasons = LookupManager.findByLTYPE('UserGroup[Selecting Officials]/CancellationReason');
    } else if (isUserLiaison == true) {
        reasons = LookupManager.findByLTYPE('UserGroup[HR Liaison]/CancellationReason');
    } else if (isXO == true) {
        reasons = LookupManager.findByLTYPE('UserGroup[Executive Officers]/CancellationReason');
    } else if (isStaffingSpecialist == true) {
        reasons = LookupManager.findByLTYPE('UserGroup[HR Staffing Specialists]/CancellationReason');
    } else {
        reasons = LookupManager.findByLTYPE('UserGroup[Default]/CancellationReason');
    }

    var options = '<option value>Select one</option>';
    reasons.forEach(function(reason) {
        options = options + '<option value=' + reason.LABEL + '>' + reason.LABEL + '</option>';
    });

    var dialog = bootbox.dialog({
        title: 'Reason for Cancellation',
        message: '<span>Cancellation Reason:&nbsp;</span><select name="CancellationReason">' + options + '</select>',
        onEscape: true,
        buttons: {
            confirm: {
                label: 'OK',
                className: 'btn-success',
                callback: function() {
                    var message = $('div.bootbox select option:selected').text();
                    if (message == null || message.length == 0) {
                        return false;
                    }

                    setTimeout(function() {
                        $('#WIH_complete_requested').val('true');
                        $('#pv_requestStatus').val('Request Cancelled');
                        $('#pv_requestStatusDate').val(CMSUtility.getNowUTCString());
                        $("#pv_cancelReason").val(message);
                        submitTheFormToProceed('button_cancel');
                    }, 0);
                }
            },
            cancel: {
                label: 'Cancel',
                className: 'btn-danger'
            }
        }
    });

    $('div.bootbox button.btn-success').prop('disabled', true);

    $('div.bootbox select').on("change keyup", function() {
        var message = $('div.bootbox select option:selected').val();
        if (message == "") {
            $('div.bootbox button.btn-success').prop('disabled', true);
        } else {
            $('div.bootbox button.btn-success').prop('disabled', false);
        }
    });
} // end popupCancellation()


/**
 * Capture display value for selected fields.
 *
 * The selected value fields are mapped to stored value (usually numeric id value).
 * In order to reduce DB call to figure out the display value that is associated with the stored value,
 * some display values are captured.
 */
function captureSelDispVal(){
	$("#h_CS_AC_DISP").val($("#CS_ADMIN_CD").val());
	$("#h_PD_SUB_ORG_1_DSP").val($("#PD_SUB_ORG_1_DSP").text());
	$("#h_PD_SUB_ORG_2_DSP").val($("#PD_SUB_ORG_2_DSP").text());
	$("#h_PD_SUB_ORG_3_DSP").val($("#PD_SUB_ORG_3_DSP").text());
	$("#h_PD_SUB_ORG_4_DSP").val($("#PD_SUB_ORG_4_DSP").text());
	$("#h_PD_SUB_ORG_5_DSP").val($("#PD_SUB_ORG_5_DSP").text());
}

/**
 * Controls show/hide FLSA tabs depending on the FLSA Determination fields in General tab.
 */
function showHidelFlsaTabs(){
	//debug
	//console.log("showHidelFlsaTabs() "
	//	+ "\n FLSA ex count = " + $("select[id^=CS_FLSA_DETERM_ID_] option:selected").filter(function(){ return $(this).text() == "Exempt"; }).length
	//	+ "\n FLSA nonex count = " + $("select[id^=CS_FLSA_DETERM_ID_] option:selected").filter(function(){ return $(this).text() == "Non-exempt"; }).length
	//);

    var currentActivityOption = BFActivityOption.getCurrentActivityOption(getActivityName());
    var foundTab3 = false;
    var foundTab4 = false;
    currentActivityOption.tabs.forEach(function(tab) {
        if (tab == 'tab3') {
            foundTab3 = true;
        }
        if (tab == 'tab4') {
            foundTab4 = true;
        }
    });

    if (foundTab3 && foundTab4) {
    	// show/hide FLSA - Exempt tab
		var flsaExTabId = "tab3";
    	if ($("select[id^=CS_FLSA_DETERM_ID_] option:selected").filter(function(){ return $(this).text() == "Exempt"; }).length > 0){
    		BFActivityOption.addTabToCurrentActivity(getActivityName(), flsaExTabId);
    		TabManager.showTabHeader(flsaExTabId);
    		if (TabManager.allPreviousTabCompleted(flsaExTabId)){
				TabManager.enableTabHeader(flsaExTabId);
			} else {
				TabManager.disableTabHeader(flsaExTabId);
			}
    	} else {
    		TabManager.hideTabHeader(flsaExTabId);
    		BFActivityOption.removeTabFromCurrentActivity(getActivityName(), flsaExTabId);
    	}

    	// show/hide FLSA - Non-Exempt tab
		var flsaNonExTabId = "tab4";
    	if ($("select[id^=CS_FLSA_DETERM_ID_] option:selected").filter(function(){ return $(this).text() == "Non-exempt"; }).length > 0){
    		BFActivityOption.addTabToCurrentActivity(getActivityName(), flsaNonExTabId);
    		TabManager.showTabHeader(flsaNonExTabId);
    		if (TabManager.allPreviousTabCompleted(flsaNonExTabId)){
				TabManager.enableTabHeader(flsaNonExTabId);
			} else {
				TabManager.disableTabHeader(flsaNonExTabId);
			}
    	} else {
    		TabManager.hideTabHeader(flsaNonExTabId);
    		BFActivityOption.removeTabFromCurrentActivity(getActivityName(), flsaNonExTabId);
    	}
    }
}

/**
 * Event handler code generated by WebMaker when exit WIH action is used in Event tab of the WM Studio.
 *
 * Moved the implementation here so as to have better development control over the event handler.
 *
 * @param btnId - element id of the exit button
 */
function exitWih(btnId){
	var evt = (window.event) ? window.event : e;
	var sourceComponent = null;
	if ((evt != null) && (typeof(evt) != 'undefined')){
		sourceComponent = (evt.target) ? evt.target : evt.srcElement;
		if ((sourceComponent != null) && (sourceComponent.nodeType == 3)){ // defeat Safari bug
			sourceComponent = sourceComponent.parentNode;
		}
	}
	var objEventSource = {
		name: 'EventSource'
		, option: 'field'
		, event: evt
		, component: sourceComponent
		, value: btnId
		, field: document.getElementById(btnId)
	};

	return dojo.hitch(objEventSource.field, function(){
		var objWIHAction = {name: 'WIHAction', option: 'WIHAction', value: 'exit'};
		var objResponse = {name: 'Response', option: 'Default', value: ''};
		hyf.HSGAction.handleWIHAction(objWIHAction, objResponse, objEventSource);
	})();
}

function initMaxSize() {
    var inputControls = $('input[size]');
    $.each(inputControls, function(index, control) {
        var maxSize = $(control).attr('size');
        var id = $(control).attr('id');
        var controlType = $(control).attr('_type');

        // Skip if the control is date control
        if (controlType != 'date' && typeof id != 'undefined') {
            if ($(control).parent().length == 1
                && $(control).parent().parent().length == 1
                && $(control).parent().parent().parent().length == 1) {
                var initialMessage = $(control).val();

                var target;
                if ($(control).hasClass('dijitInputInner')) {
                    target = $(control).parent().parent().parent();
                } else {
                    target = $(control).parent().parent();
                }

                target.append('<p id="' + (id + '_sizeLabel' ) + '" class="sizeLabel" debugMessage="' + initialMessage + '">(Now: ' + initialMessage.length + ' / Max: ' + maxSize + ')</p>');

                $('#' + id + '_sizeLabel').hide();

                $(control).on('focus', function() {
                    $('#' + id + '_sizeLabel').show();
                });

                $(control).on('blur', function() {
                    $('#' + id + '_sizeLabel').hide();
                });

                $(control).on('keyup paste blur change', function() {
                    var message = $(control).val();
                    if (message.length > maxSize) {
                        $(control).val(message.substring(0, maxSize));
                    }
                    $('#' + id + '_sizeLabel').text('(Now: ' + message.length + ' / Max: ' + maxSize + ')');
                })
            }
        }
    });

    var inputControls = $('textarea.textbox[maxlength]');
    $.each(inputControls, function(index, control) {
        var maxSize = $(control).attr('maxlength');
        var id = $(control).attr('id');

        if ($(control).parent().length == 1 && typeof id != 'undefined') {
            var initialMessage = $(control).val();

            $(control).parent().append('<p id="' + (id + '_sizeLabel' ) + '" class="sizeLabel">(Now: ' + initialMessage.length + ' / Max: ' + maxSize + ')</p>');

            $('#' + id + '_sizeLabel').hide();

            $(control).on('focus', function() {
                $('#' + id + '_sizeLabel').show();
            });

            $(control).on('blur', function() {
                $('#' + id + '_sizeLabel').hide();
            });

            $(control).on('keyup keypress blur change', function() {
                var message = $(control).val();
                $('#' + id + '_sizeLabel').text('(Now: ' + message.length + ' / Max: ' + maxSize + ')');
            })
        }
    });
}

/**
 * onload event handler for Classification Main page.
 */
function initClsfMainForm() {
    if (isReadOnly() == true) {
        var activityName = getActivityName();
        var option = BFActivityOption.getCurrentActivityOption(activityName);
        option.readonly = ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab6'];

        var currentTabID = BFActivityOption.getCurrentTabID();
        TabManager.disableTab(currentTabID);
    }

    LookupManager.init();
    //CMSUtility.restoreBizFlowParameter();
    TabManager.installCustomTabChanger();
    TabManager.initTab();

    // Request Date
    var requestedDateString = $('#h_creationdate').val();
	if (requestedDateString != null && requestedDateString.length > 0) {
		var requestedDate = new Date(requestedDateString);  // requestedDateString is GMT
		var newDate = new Date(requestedDate.getTime() - requestedDate.getTimezoneOffset() * 60000); // Adjust to local time
		var requestedDateLabel = CMSUtility.getDateString({isUTC: false, dateFormat: 'mm/dd/yyyy'}, newDate);
		$('#initiatedDate').text(requestedDateLabel);
	}

    // Request Number
    var requestNumber = $('#h_requestNumber').val();
    $('#requestNumber').text(requestNumber);

    // Request Type
    var requestType = $('#pv_requestType').val();
    $('#requestType').text(requestType);

    // Request Status
    var requestStatus = $('#pv_requestStatus').val();
    $('#output_requestStatus').text(requestStatus);

    hyf.util.disableComponent("button_Previous");
    hyf.util.enableComponent("button_Next");

    initLayoutPerActivity();

	//----------------------------------------
	// static button event handler
	//----------------------------------------
	// save
	$("#btnSaveBottom").on("click", function(){
        $('#currentTabID').val(BFActivityOption.getCurrentTabID());
		enableTabsForSubmission();
		captureSelDispVal();
		//$("#h_modifyRequested").val("");
		submitFormPage("btnSaveBottom", "saveNewForm");
	});

	// exit
	$("#btnExitBottom").on("click", function(){
		enableTabsForSubmission();
		captureSelDispVal();
		// saveTabContent.do action should not generate any partial page content but async_save_pp_group is there to confirm the usage pattern
		//callPartialPage(null, "saveTabContent.do", "system", "async_save_pp_group");
		exitWih("btnExitBottom");
	});

    // Cancellation Popup Initialization
    hyf.util.hideComponent("cancellationOtherReasonSection", null, null, null);
    $('#select_cancellation_reason').off('change').change(function() {
        var selectedText = $('#select_cancellation_reason option:selected').text();
        if (selectedText == 'Other') {
            hyf.util.showComponent("cancellationOtherReasonSection", null, null, null);
        } else {
            hyf.util.hideComponent("cancellationOtherReasonSection", null, null, null);
        }
    });

    // Reset Refresh PD Coversheet requested value
    $('#h_refreshPDCoversheetRequested').val('false');
}
