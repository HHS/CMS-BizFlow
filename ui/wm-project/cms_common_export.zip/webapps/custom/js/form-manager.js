'use strict';

function ActivityManagerException(message) {
    this.message = message;
    this.name = 'ActivityManager Exception';
}

function Activity(name, tabIds, activeTabIds_, readOnlyTabIds_) {
    this.name = name;
    this.tabIds = tabIds;
    this.activeTabIds = activeTabIds_ || tabIds;
    this.readOnlyTabIds = readOnlyTabIds_ || [];
    this.getReadOnlyTabIds = readOnlyTabIds_;
}

function Tab(id, name, targetUrl, targetGroup, validationOnLoadNextTab_, javaScripts_, onInit_, renderer_, postEnableTab_, postDisableTab_, postClearTabContents_) {
    this.id = id;
    this.name = name;
    this.targetUrl = targetUrl;
    this.targetGroup = targetGroup;
    this.validationOnLoadNextTab = validationOnLoadNextTab_ || false;
    this.javaScripts = javaScripts_;
    this.displayMissingRequiredFields = true;
    this.loaded = false;
    this.completed = false;
    this.hidden = false;
    this.disabledHeader = false;
    this.readOnly = false;
    this.onInit = onInit_ || function () {
    };
    this.renderer = renderer_ || function (action) {
    };
    this.postEnableTab = postEnableTab_ || function () {
    };
    this.postDisableTab = postDisableTab_ || function () {
    };
    this.postClearTabContents = postClearTabContents_ || function () {
    };
    this.validator = null; // if this is a function, it is called to validate a tab. Define a function if a custom validation needs.
}

/***
 * ActivityTabDefinition Class
 * @param tabs This has the information of the available tab on a form
 * @param activities this has the information of the activities where a form is used and what tabs are used on each activity
 */
function ActivityTabDefinition(tabs, activities) {
    this.tabs = tabs;
    this.activities = activities;
}

(function (window) {
    var FORM_EVENT = {
        ALL_TABS_LOADED: 'ALL_TABS_LOADED',
        TAB_CHANGE: 'ON_TAB_CHANGE',
        DOCUMENT_CHANGE: 'ON_DOCUMENT_CHANGE'
    };

    var _initializer = window.FORM_EVENT || (window.FORM_EVENT = FORM_EVENT);
})(window);

(function (window) {
    var Activities = function () {
        var _activities = null;    // all available activities
        var _activityMap = [];

        function getActivities() {
            return _activities;
        }

        function getActivity(activityName) {
            var activity = _activityMap[activityName];
            if (null == activity) {
                var activities = _activities.filter(function (node, index) {
                    node.index = index;
                    return node.name === activityName;
                });

                activity = activities.length > 0 ? activities[0] : null;
                _activityMap[activityName] = activity;
            }

            return activity;
        }

        /**
         * Initialize
         * @param activities all available activities
         */
        function init(activities) {
            _activities = activities;
        }

        return {
            init: init,
            getActivity: getActivity,
            getActivities: getActivities
        }
    };

    var _initializer = window.Activities || (window.Activities = Activities());
})(window);

(function (window) {
    var ActivityManager = function () {
        var _activityName = null;   // current activity name
        var _activity = null;    // current activity

        function getActivityName() {
            return _activityName;
        }

        function getActivity() {
            return _activity;
        }

        function getTabIdList() {
            return _activity.tabIds;
        }

        function getActiveTabIdList() {
            return _activity.activeTabIds;
        }

        function getReadOnlyTabIdList() {
            if ('function' === typeof _activity.getReadOnlyTabIds) {
                return _activity.getReadOnlyTabIds();
            } else {
                return _activity.readOnlyTabIds;
            }
        }

        function getNextTabID(currentTabID) {
            var tabs = getTabIdList();
            for (var index = 0; index < tabs.length; index++) {
                if (tabs[index] === currentTabID) {
                    if (index < tabs.length - 1) {
                        return tabs[index + 1];
                    }
                }
            }
            return null;
        }

        function getPreviousTabID(currentTabID) {
            var tabs = getTabIdList();
            for (var index = 0; index < tabs.length; index++) {
                if (tabs[index] === currentTabID) {
                    if (index > 0) {
                        return tabs[index - 1];
                    }
                }
            }
            return null;
        }

        /**
         * Initialize
         * @param activityName activity name
         * @param activity activity for the activity name
         */
        function init(activityName, activity) {
            if (typeof activityName === 'undefined' || activityName === null) {
                throw new ActivityManagerException('ActivityManager.init - Parameter activityName is invalid. It should be a valid activity name');
            }
            if (typeof activity === 'undefined' || activity === null) {
                throw new ActivityManagerException('ActivityManager.init - Parameter activity is invalid. It should have an activity for ' + activityName);
            }

            _activityName = activityName;
            _activity = activity;
        }

        return {
            getActivityName: getActivityName,
            getNextTabID: getNextTabID,
            getPreviousTabID: getPreviousTabID,
            getReadOnlyTabIdList: getReadOnlyTabIdList,
            getTabIdList: getTabIdList,
            getActivity: getActivity,
            getActiveTabIdList: getActiveTabIdList,
            init: init
        };
    };

    var _initializer = window.ActivityManager || (window.ActivityManager = ActivityManager());
})(window);

(function (window) {
    var Tabs = function () {
        var _tabs = null;

        function getTab(id) {
            var a = $.grep(_tabs, function (v) {
                return v.id === id;
            });
            return typeof a === 'undefined' ? a : a[0];
        }

        function _getTabs(tabIdList) {
            var tabs = [];
            $.each(_tabs, function (tabIndex, tab) {
                if (-1 !== tabIdList.indexOf(tab.id)) {
                    tabs.push(tab);
                }
            });

            return tabs;
        }

        function getTabs(tabIdList) {
            return tabIdList ? _getTabs(tabIdList) : _tabs;
        }

        /**
         * Initialize
         * @param tabs all available tabs
         */
        function init(tabs) {
            _tabs = tabs;
        }

        return {
            init: init,
            getTab: getTab,
            getTabs: getTabs
        }
    };

    var _initializer = window.Tabs || (window.Tabs = Tabs());
})(window);

(function (window) {
    var TabManager = function () {
        var _previousTabElementId = 'button_Previous';
        var _nextTabElementId = 'button_Next';
        var _activityName;
        var _tabList = [];
        var _tabIndexList = []; // This will be used by ensureTabControlPropertyPopulated.
        var _totalLoadedTabCount = 0;
        var _currentTabId = '';
        var _activeTabIdList = null;
        var _initFormsFunction = null;   // a function that is called after all forms are loaded
        var _originalTabChanger = null;
        var _tabControlTabPrefix = 'tab_control_tab_';
        var _tabControlFieldName = 'tab_control';

        function getAnchorID(tab) {
            if (typeof tab === 'string') {
                return _tabControlTabPrefix + tab;
            } else if (tab.id) {
                return _tabControlTabPrefix + tab.id;
            }
        }

        function getTabIDFromAnchorID(anchorId) {
            var tabId = null;
            if (anchorId != null && anchorId.length > _tabControlTabPrefix.length) {
                tabId = anchorId.substring(_tabControlTabPrefix.length);
            }
            return tabId;
        }

        function getTab(tabId) {
            var tab = tabId;
            if (typeof tabId === 'string') {
                var selectedTabs = _tabList.filter(function (node, index) {
                    return node.id === tabId;
                });

                tab = selectedTabs.length === 1 ? selectedTabs[0] : null;
            }

            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "TabManager::getTab - tabId, tab ==> ", tabId, tab);
            return tab;
        }

        function getSelectedTabID() {
            var tabId = null;
            var currentTabs = $('#tab_control_container a.selectedTab');
            if (currentTabs.length > 0) {
                var tabAnchorId = currentTabs[0].attributes['id'].value;
                tabId = getTabIDFromAnchorID(tabAnchorId);
            }

            return tabId;
        }

        function loadTab(tabId) {
            var selectedTab = getTab(tabId);
            if (selectedTab != null) {
                if (selectedTab.loaded === false) {
                    FormUtility.loadPartialPage(selectedTab.targetUrl, 'system', selectedTab.targetGroup);
                    selectedTab.loaded = true;
                }
            }
        }

        function isTabCompleted(tabId) {
            var tab = getTab(tabId);
            var container = document.getElementById(tab.id);
            var fv = hyf.FMAction.getFormValidator();
            var errors = fv.checkContainer(container);

            tab.completed = errors.length <= 0;

            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'TabManager::isTabCompleted - Tab, Errors ==>', tab, errors);
            return tab.completed;
        }

        function loadTabFromAnchor(node) {
            var currentTabId = getSelectedTabID();
            var tabAnchorId = $(node).attr('id');
            var tabId = getTabIDFromAnchorID(tabAnchorId);
            var tab = getTab(tabId);

            if (tab.disabledHeader === false) { // Tab click on disabled tab should be ignored.
                if (_.includes(_activeTabIdList, tabId) || isTabCompleted(currentTabId) === true) {
                    loadTab(tabId);
                }
            }
        }

        function showTabHeader(tabId, force) {
            if (force || $('#' + getAnchorID(tabId) + ':hidden').length > 0) {
                hyf.util.showComponent(getAnchorID(tabId), null, null, null);
                var tab = getTab(tabId);
                tab.hidden = false;
            }
        }

        function hideTabHeader(tabId, force) {
            if (force || $('#' + getAnchorID(tabId) + ':visible').length > 0) {
                hyf.util.hideComponent(getAnchorID(tabId), null, null, null);
                var tab = getTab(tabId);
                tab.hidden = true;
            }
        }

        function setTabHeaderVisibility(tabId, visible) {   // You man need to call resetTabs to enable/disable next tab as hiding a tab
            if (visible) showTabHeader(tabId, true);
            else hideTabHeader(tabId, true);
        }

        function enableTab(tabId) {
            var selectedTab = getTab(tabId);
            hyf.util.enableComponent(tabId);
            selectedTab.readOnly = false;

            if (typeof selectedTab.postEnableTab === 'function') {
                selectedTab.postEnableTab();
            }

            var disabledComponents = $('#' + tabId).find('input, select, textarea');
            $.each(disabledComponents, function (index, component) {
                var alwaysDisabled = $(component).attr('alwaysDisabled');
                var alwaysReadonly = $(component).attr('alwaysReadonly');
                var doNotSubmit = $(component).attr('donotsubmit');

                if (doNotSubmit === 'true') {
                    $(component).attr('disabled', true);
                }
                if (alwaysDisabled === 'true') {
                    $(component).attr('disabled', true);
                }
                if (alwaysReadonly === 'true') {
                    $(component).prop('readonly', 'true');
                }
            });

            return selectedTab;
        }

        function disableTab(tabId) {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'TabManager::disableTab - tabId ==>', tabId);
            var selectedTab = getTab(tabId);
            hyf.util.disableComponent(tabId);
            selectedTab.readOnly = true;
            if (typeof selectedTab.postDisableTab === 'function') {
                selectedTab.postDisableTab();
            }

            return selectedTab;
        }

        function setTabUsability(tabId, enable) {
            if (enable) enableTab(tabId);
            else disableTab(tabId);
        }

        function disableTabBasedOnActivity(tabId) {
            var readOnly = FormUtility.isReadOnly();
            if (readOnly) {
                disableTab(tabId);
            } else {
                var readonlyTabs = ActivityManager.getReadOnlyTabIdList();
                if (readonlyTabs !== null && readonlyTabs.length > 0) {
                    for (var index = 0; index < readonlyTabs.length; index++) {
                        if (readonlyTabs[index] === tabId) {
                            disableTab(tabId);
                            readOnly = true;
                            break;
                        }
                    }
                }
            }

            return readOnly;
        }

        function clearTabContent(tabId) {
            $.each($('#' + tabId + ' input.checkbox'), function (component) {
                var value = $(this).prop('checked');
                if (value === true) {
                    $(this).prop('checked', false);
                    $(this).trigger('change');
                }
            });

            $.each($('#' + tabId + ' input.textbox'), function (component) {
                var value = $(this).val();
                if (value && value.length > 0) {
                    $(this).val('');
                }
            });

            // For Outreach tab
            $.each($('#' + tabId + ' input[type=checkbox]'), function (component) {
                $(this).prop('checked', false);
                var value = $(this).val();
                if (value && value.length > 0) {
                    $(this).trigger('change');
                }
            });

            $.each($('#' + tabId + ' select'), function (component) {
                var value = $(this).val();
                if (value && value.length > 0) {
                    $(this).val('');
                    $(this).trigger('change');
                }
            });

            $.each($('#' + tabId + ' textarea'), function (component) {
                var value = $(this).val();
                if (value && value.length > 0) {
                    $(this).val('');
                }
            });

            var selectedTab = getTab(tabId);
            if (typeof selectedTab.postClearTabContents === 'function') {
                selectedTab.postClearTabContents();
            }
        }

        function enableTabHeader(tabId) {
            var tab = getTab(tabId);
            if (tab != null) {
                tab.disabledHeader = false;
                var anchorID = getAnchorID(tabId);
                $('#' + anchorID).removeClass('disabledTab');
                $('#' + anchorID).addClass('unselectedTab');
            } else {
                FormLog.log(FormLog.LOG_LEVEL.ERROR, 'TabManager::enableTabHeader - tabId is null');
            }
        }

        function disableTabHeader(tabId) {
            var tab = getTab(tabId);
            if (tab != null) {
                tab.disabledHeader = true;
                var anchorID = getAnchorID(tabId);
                $('#' + anchorID).removeClass('unselectedTab');
                $('#' + anchorID).addClass('disabledTab');
            } else {
                FormLog.log(FormLog.LOG_LEVEL.ERROR, 'TabManager::disableTabHeader - tab is null ==> tabId', tabId);
            }
        }

        function validateTab(tabId) {
            if (FormUtility.isReadOnly() === false) {
                var tab = getTab(tabId);
                var validationResult = true;
                var extraValidationResult = true;
                if (!tab.hidden && !tab.readOnly) {
                    validationResult = hyf.validation.validateContainer(document.getElementById(tabId));
                    if (validationResult && typeof tab.validator === 'function') {
                        extraValidationResult = tab.validator();
                    }
                }
                return validationResult && extraValidationResult === true;
            } else {
                return true;
            }
        }

        function showHidePreviousNextButtons() {
            var selectedTabID = getSelectedTabID();
            var currentTabIndex = 0;
            for (var index = 0; index < _tabList.length; index++) {
                if (_tabList[index].id == selectedTabID) {
                    currentTabIndex = index;
                    break;
                }
            }

            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "TabManager::showHidePreviousNextButtons - selectedTabID, currentTabIndex ==> ", selectedTabID, currentTabIndex);

            if (currentTabIndex == 0) {
                hyf.util.disableComponent(_previousTabElementId);
                hyf.util.enableComponent(_nextTabElementId);
            } else if (currentTabIndex == _tabList.length - 1) {
                hyf.util.enableComponent(_previousTabElementId);
                hyf.util.disableComponent(_nextTabElementId);
            } else {
                hyf.util.enableComponent(_previousTabElementId);
                hyf.util.enableComponent(_nextTabElementId);
            }
        }

        function loadNextTab() {
            var currentTabId = getSelectedTabID();
            if (currentTabId != null) {
                var nextTabID = ActivityManager.getNextTabID(currentTabId);
                if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "TabManager::loadNextTab - currentTabId, nextTabId ==> ", currentTabId, nextTabID);
                if (nextTabID != null) {
                    var currentTab = getTab(currentTabId);
                    if ((typeof(currentTab.validationOnLoadNextTab) !== 'undefined' && currentTab.validationOnLoadNextTab === false)) {
                        nextTabID = ActivityManager.getNextTabID(currentTabId);
                        enableTabHeader(nextTabID);
                        $('#' + getAnchorID(nextTabID)).click();
                    } else {
                        if (validateTab(currentTabId) === true) {
                            nextTabID = ActivityManager.getNextTabID(currentTabId);
                            while (nextTabID != null) {
                                enableTabHeader(nextTabID);
                                if (isTabCompleted(nextTabID) === true) {
                                    nextTabID = ActivityManager.getNextTabID(nextTabID);
                                } else {
                                    break;
                                }
                            }
                            nextTabID = ActivityManager.getNextTabID(currentTabId);
                            // skip hidden tab
                            do {
                                var nextTab = getTab(nextTabID);
                                if (nextTab.hidden === false) break;
                                nextTabID = ActivityManager.getNextTabID(nextTabID);
                            } while (nextTabID != null);
                            if (nextTabID != null) {
                                enableTabHeader(nextTabID);
                                $('#' + getAnchorID(nextTabID)).click();
                            }
                        } else {
                            nextTabID = ActivityManager.getNextTabID(currentTabId);
                            while (nextTabID != null) {
                                if (_.includes(_activeTabIdList, nextTabID)) {
                                    nextTabID = null; // All the tabs in the activeTabIDList should be at the end of tabs
                                } else {
                                    disableTabHeader(nextTabID);
                                    nextTabID = ActivityManager.getNextTabID(nextTabID);
                                }
                            }
                        }
                    }
                }
            }
        }

        function loadPreviousTab() {
            var currentTabId = getSelectedTabID();
            if (currentTabId != null) {
                var previousTabID = ActivityManager.getPreviousTabID(currentTabId);
                if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "TabManager::loadPreviousTab - currentTabId, previousTabId ==> ", currentTabId, previousTabID);
                while (previousTabID != null) {
                    var tab = getTab(previousTabID);
                    if (tab != null && tab.disabledHeader === false && tab.hidden === false) {
                        $('#' + getAnchorID(previousTabID)).click();
                        break;
                    } else {
                        previousTabID = ActivityManager.getPreviousTabID(previousTabID);
                    }
                }
            }
        }

        function resetTabs() {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "TabManager::resetTabs");
            var activeTabId = getSelectedTabID();
            hyf.util.setFieldValue(_tabControlFieldName, activeTabId);

            var leftTabNotCompleted = false;

            for (var index = 0; index < _tabList.length; index++) {
                var tab = _tabList[index];
                if (!tab.hidden) {
                    var currentTabCompleted = isTabCompleted(tab);

                    if (index === 0) {
                        enableTabHeader(tab);
                        document.getElementById(getAnchorID(tab.id)).className = 'selectedTab';
                    } else {
                        if (leftTabNotCompleted === true) {
                            if (_.includes(_activeTabIdList, tab.id)) {
                                enableTabHeader(tab);
                            } else {
                                disableTabHeader(tab);
                            }
                        } else {
                            enableTabHeader(tab);
                        }
                    }

                    if (currentTabCompleted === false) {
                        leftTabNotCompleted = true;
                    }
                }
            }
        }

        // This function is called whenever WebMaker tab is clicked.
        // WebMaker form has default tabChanger function and this is custom one.
        function tabChanger(tabId) {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "TabManager::tabChanger - currentTabId, tabId ==> ", _currentTabId, tabId);
            if (_currentTabId !== tabId) {
                _currentTabId = tabId;

                ensureTabControlPropertyPopulated();
                // resetTabs();

                var currentTabId = getSelectedTabID();
                if (isTabCompleted(currentTabId) === true) {
                    hyf.util.setFieldValue(_tabControlFieldName, tabId);
                    _tabList.forEach(function (tab) {
                        if (tab.disabledHeader === false) {
                            document.getElementById(getAnchorID(tab.id)).className = 'unselectedTab';
                        }
                    });

                    document.getElementById(getAnchorID(tabId)).className = 'selectedTab';
                } else {
                    if (FormUtility.isReadOnly() === false) {
                        var nextTabID = ActivityManager.getNextTabID(currentTabId);
                        while (nextTabID != null) {
                            if (_.includes(_activeTabIdList, nextTabID) === false) {
                                disableTabHeader(nextTabID);
                                nextTabID = ActivityManager.getNextTabID(nextTabID);
                            } else {
                                hyf.util.setFieldValue(_tabControlFieldName, tabId);
                                _tabList.forEach(function (tab) {
                                    if (tab.disabledHeader !== true) {
                                        document.getElementById(getAnchorID(tab.id)).className = 'unselectedTab';
                                    }
                                });
                                document.getElementById(getAnchorID(tabId)).className = 'selectedTab';
                                nextTabID = null;
                            }
                        }
                        // If destination tab is in left side
                        if (tabId < currentTabId) {
                            hyf.util.setFieldValue(_tabControlFieldName, tabId);
                            _tabList.forEach(function (tab) {
                                if (tab.disabledHeader === false) {
                                    document.getElementById(getAnchorID(tab.id)).className = 'unselectedTab';
                                }
                            });
                            document.getElementById(getAnchorID(tabId)).className = 'selectedTab';
                        } else {
                            if (typeof event !== 'undefined' && event != null) {
                                event.preventDefault();
                            }
                        }
                    }
                }

                $(document).trigger(FORM_EVENT.TAB_CHANGE);
                if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "TabManager::tabChanger - trigger ON_TAB_CHANGE event - tabId ==>", tabId);
            }
        }

        // This function will be called after all tabs are loaded.
        function initTabsAfterAllTabLoaded() {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "TabManager::initTabsAfterAllTabLoaded");

            if (typeof _initFormsFunction === 'function') {
                _initFormsFunction();
            }

            _tabList.forEach(function (tab) {
                disableTabBasedOnActivity(tab.id);
            });

            resetTabs();

            // keep the current tab selection
            var storedTabId = FormUtility.getInputElementValue('h_currentTabID');
            if (storedTabId) {
                var tab = getTab(storedTabId);
                if (tab.disabledHeader === false) {
                    tabChanger(storedTabId);
                    showHidePreviousNextButtons();

                    $('#' + getAnchorID(storedTabId)).focus();
                }
                FormUtility.setInputElementValue('h_currentTabID', ''); // clear current tab for closing page
            }

            FormUtility.greyOutScreen(false);

            $(document).trigger(FORM_EVENT.ALL_TABS_LOADED);
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'TabManager:: initTabsAfterAllTabLoaded - trigger ALL_TABS_LOADED event');
        }

        // This function will be called after each tab is loaded.
        function initAfterLoad(totalTabCount, tabId) {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'TabManager:: initAfterLoad - totalTabCount, tabId ==> ', totalTabCount, tabId);
            var readOnly = disableTabBasedOnActivity(tabId);

            var tab = getTab(tabId);
            if (tab.onInit != null) {
                if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'TabManager:: initAfterLoad - call tab.onInit ==> ', tab);
                tab.onInit(readOnly);
            }

            tab.completed = isTabCompleted(tabId);
            _totalLoadedTabCount += 1;

            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'TabManager:: initAfterLoad - load tabs=' + _totalLoadedTabCount + '/' + totalTabCount);

            if (_totalLoadedTabCount === totalTabCount) {
                initTabsAfterAllTabLoaded();
            }
        }

        // This function should be called before loading tabs.
        // This function is to add TabManager.initTabAfterLoad function to each tabs so that initTabAfterLoad can be called.
        function initResponseHandler() {
            if (window != null) {
                _tabList.forEach(function (tab) {
                    window[tab.targetGroup + 'ManipulateResponse'] = function (content, flag) {
                        content = content + '<div><script type="text/javascript">function ' + tab.targetGroup + '_processAfterLoad() {TabManager.initAfterLoad('
                            + _tabList.length + ',"' + tab.id + '","' + _activityName + '" );};'
                            + 'hyf.attachEventHandler(window, "onload",' + tab.targetGroup + '_processAfterLoad);</script></div>';
                        return content;
                    }
                });
            } else {
                FormLog.log(FormLog.LOG_LEVEL.ERROR, 'TabManager::initResponseHandler - window is null');
            }
        }

        // Sometimes WebMaker loses _hyfCondDisplayIds property that affects tab behavior.
        // If it is not found, this property should be reinitialized to have the array of numbers from 0 to 8.
        function ensureTabControlPropertyPopulated() {
            try {
                var hyfCondDisplayIds = $('#tab_control')[0]._hyfCondDisplayIds;
                if (!hyfCondDisplayIds) {
                    $('#tab_control')[0]._hyfCondDisplayIds = _tabIndexList;
                } else {
                    if (hyfCondDisplayIds.length <= 0) {
                        $('#tab_control')[0]._hyfCondDisplayIds = _tabIndexList;
                    }
                }
            } catch (e) {
            }
        }

        function installCustomTabChanger() {
            if (window.tab_controlTabChange != null) {
                _originalTabChanger = window.tab_controlTabChange;
                window.tab_controlTabChange = function (value) {
                    var tab = getTab(value);
                    if (tab.disabledHeader === false) {
                        tabChanger(value);
                        showHidePreviousNextButtons();
                    }
                }
            }
        }

        function setTabList(tabList) {
            var activityTabIdList = [];
            if (tabList != null && tabList.length > 0) {
                _tabList = tabList;
                _tabList.forEach(function (tab, index) {
                    _tabIndexList.push(index);
                    activityTabIdList.push(tab.id);
                });

                _activeTabIdList = _activeTabIdList || activityTabIdList;
                if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'TabManager::setTabList - ActivityName, ActiveTabIdList ==>', _activityName, _activeTabIdList);
            } else {
                FormLog.log(FormLog.LOG_LEVEL.ERROR, 'TabManager::setTabList - Tab list is null or empty')
            }
        }

        function getTabList() {
            return _tabList;
        }

        function initPreviousNextButtons() {
            hyf.util.disableComponent(_previousTabElementId);
            hyf.util.enableComponent(_nextTabElementId);
        }

        /**
         * Initialize
         * @param activityName activity name
         * @param tabList tab list of the activity name
         * @param initFormsFunction a function that is called
         * @param activityTabIdList_ (Optional) activity tab id list
         * @param previousTabElementId_ (Optional) the element id of previous button.
         * @param nextTabElementId_ (Optional) the element id of next button.
         */
        function init(activityName, tabList, initFormsFunction, activityTabIdList_, previousTabElementId_, nextTabElementId_) {
            _activityName = activityName;
            _activeTabIdList = activityTabIdList_;
            _previousTabElementId = previousTabElementId_ || _previousTabElementId;
            _nextTabElementId = nextTabElementId_ || _nextTabElementId;
            _initFormsFunction = initFormsFunction;
            _totalLoadedTabCount = 0;

            initPreviousNextButtons();
            installCustomTabChanger();
            setTabList(tabList);
            initResponseHandler();

            _tabList.forEach(function (tab, index) {
                $('#' + getAnchorID(tab.id)).attr('tabindex', index + 1);
                if (index === 0) {
                    hyf.util.setFieldValue(_tabControlFieldName, tab.id);
                } else {
                    // Enable document tab always
                    if (_.includes(_activeTabIdList, tab.id) === false) {
                        disableTabHeader(tab.id);
                    }
                }
                setTimeout(loadTab(tab.id), 0);
            });

            var firstTab = true;
            // Hide Tabs
            var visibleTabsOnForm = [];
            $.each($("#tab_control_container a[id^=_tabControlIdPrefix]"), function (i, v) {
                visibleTabsOnForm.push(v.id.substring(_tabControlTabPrefix.length))
            });

            visibleTabsOnForm.forEach(function (tabId) {
                var showTab = false;
                for (var index = 0; index < _tabList.length; index++) {
                    if (_tabList[index].id === tabId) {
                        showTab = true;
                        break;
                    }
                }

                if (showTab === false) {
                    hideTabHeader(tabId);
                } else {
                    showTabHeader(tabId);
                    if (firstTab === true) {
                        firstTab = false;
                        document.getElementById(getAnchorID(tabId)).className = 'selectedTab';
                        if (tabId !== 'tab1') {
                            document.getElementById(getAnchorID('tab1')).className = 'unselectedTab';
                        }
                    } else {
                        document.getElementById(getAnchorID(tabId)).className = 'unselectedTab';
                    }
                }
            });

            $('.tabContainer a').off('click').click(function (e) {
                e.preventDefault();
                loadTabFromAnchor(this);
            });

            $('#' + _previousTabElementId).off('click').on('click', function () {
                loadPreviousTab();
            });
            $('#' + _nextTabElementId).off('click').on('click', function () {
                loadNextTab();
            });
        }

        return {
            getAnchorID: getAnchorID,
            getSelectedTabID: getSelectedTabID,
            getTab: getTab,
            getTabList: getTabList,
            initAfterLoad: initAfterLoad,
            init: init,
            validateTab: validateTab,
            loadTabFromAnchor: loadTabFromAnchor,
            enableTabHeader: enableTabHeader,
            disableTabHeader: disableTabHeader,
            showTabHeader: showTabHeader,
            hideTabHeader: hideTabHeader,
            setTabHeaderVisibility: setTabHeaderVisibility,
            enableTab: enableTab,
            disableTab: disableTab,
            setTabUsability: setTabUsability,
            clearTabContent: clearTabContent,
            loadNextTab: loadNextTab,
            loadPreviousTab: loadPreviousTab,
            isTabCompleted: isTabCompleted,
            resetTabs: resetTabs
        }
    };

    var _initializer = window.TabManager || (window.TabManager = TabManager());
})(window);

(function (window) {
    var FormManager = function () {
        var _formTabList;

        function getFormTabList() {
            return _formTabList;
        }

        /**
         * Initialize Form Manager
         * @param activityName activity name
         * @param activityTabDefinition activity tab definition
         * @param formData_ (Optional) form data
         * @param formRenderer_ (Optional) form renderer
         */
        function init(activityName, activityTabDefinition, formData_, formRenderer_) {
            Activities.init(activityTabDefinition.activities);
            Tabs.init(activityTabDefinition.tabs);
            ActivityManager.init(activityName, Activities.getActivity(activityName));
            _formTabList = Tabs.getTabs(ActivityManager.getTabIdList());
            FormState.init(formData_, formRenderer_);
            TabManager.init(activityName, _formTabList, function () {
                FormState.registerTabRendersAndBindElements(_formTabList);
                FormState.runRenderers();
                if (typeof FormSection508 !== "undefined") {
                    FormSection508.init();
                }
            }, ActivityManager.getActiveTabIdList());
        }

        return {
            getFormTabList: getFormTabList,
            init: init
        }
    };

    var _initializer = window.FormManager || (window.FormManager = FormManager());
})(window);
