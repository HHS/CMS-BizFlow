if (typeof define === 'function' && define.amd){
    define.amd = undefined;
}
