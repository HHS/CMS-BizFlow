'use strict';

function FormStateException(message) {
    this.message = message;
    this.name = 'FormState Exception';
}

(function (window) {
    var ELEMENT_TYPE = {
        CHECKBOX: 'checkbox',
        DATE: 'date',
        PVARIABLE: 'pvariable',
        RADIO: 'radio',
        SELECT: 'select',
        TEXTBOX: 'textbox',
        DIJITINPUTINNER: 'dijitInputInner',
        VARIABLE: 'variable',
        OBJECT: 'object'
    };
    var _initializer = window.ETYPE || (window.ETYPE = ELEMENT_TYPE);
})(window);

(function (window) {
    function FormStateAction() {
        this.clearAllFlag = function () {
            return {type: 'CLEAR_ALL_FLAG'};
        };
        this.makeAllDirty = function () {
            return {type: 'MAKE_ALL_DIRTY'};
        };
        this.changeVariable = function (id, value) {
            return {type: 'CHANGE_VALUE', id: id, etype: ETYPE.VARIABLE, value: value};
        };
        this.changePVariable = function (id, value) {
            return {type: 'CHANGE_VALUE', id: id, etype: ETYPE.PVARIABLE, value: value};
        };
        this.changeSelect = function (id, value, text) {
            return {type: 'CHANGE_VALUE', id: id, etype: ETYPE.SELECT, value: value, text: text};
        };
        this.changeCheckbox = function (id, value, text) {
            return {type: 'CHANGE_VALUE', id: id, etype: ETYPE.CHECKBOX, value: value, text: text};
        };
        this.changeRadio = function (id, value, text) {
            return {type: 'CHANGE_VALUE', id: id, etype: ETYPE.RADIO, value: value, text: text};
        };
        this.changeText = function (id, value) {
            return {type: 'CHANGE_VALUE', id: id, etype: ETYPE.TEXTBOX, value: value};
        };
        this.changeDijitInputInner = function (id, value) {
            return {type: 'CHANGE_VALUE', id: id, etype: ETYPE.DIJITINPUTINNER, value: value};
        };
        this.changeDate = function (id, value) {
            return {type: 'CHANGE_VALUE', id: id, etype: ETYPE.DATE, value: value};
        };
        this.changeObject = function (id, value) {
            return {type: 'CHANGE_VALUE', id: id, etype: ETYPE.OBJECT, value: value};
        };
        this.reset = function (id, etype, value, text) {
            etype = etype || ETYPE.TEXTBOX;

            var state = {
                type: 'CHANGE_VALUE',
                id: id,
                etype: etype,
                value: value || ''
            };

            if (etype === ETYPE.SELECT) {
                state['text'] = text || '';
            } else if (etype === ETYPE.CHECKBOX) {
                state['value'] = text || 'false';
            }
            return state;
        };
    }

    var _initializer = window.FormStateAction || (window.FormStateAction = new FormStateAction());
})(window);

(function (window) {
    var FormStateReducer = function (trackHistory) {
        function addHistory(entry, newEntry) {
            if (entry.value !== newEntry.value) {
                var historyItem = _.assign({}, entry);
                if (!_.isUndefined(historyItem.history)) {
                    delete historyItem.history;
                }
                if (_.isUndefined(newEntry.history)) {
                    newEntry.history = [];
                }
                newEntry.history.push(historyItem);
            }
        }

        function changeState(state, action, needRender, dirty) {
            var targetState = _.find(state.items, function (o) {
                return o.id === action.id;
            });

            var newItems;
            var newEntry = {};

            if (!_.isUndefined(targetState)) {
                newItems = state.items.map(function (entry, id) {
                    if (entry.id === action.id) {
                        if (entry.etype === ETYPE.SELECT || entry.etype === ETYPE.CHECKBOX || entry.etype === ETYPE.RADIO) {
                            newEntry = _.assign({}, entry, {value: action.value, text: action.text, needRender: needRender, dirty: dirty});
                        } else {
                            newEntry = _.assign({}, entry, {value: action.value, needRender: needRender, dirty: dirty});
                        }

                        if (trackHistory) {
                            addHistory(entry, newEntry);
                        }

                        return newEntry;
                    } else {
                        return entry;
                    }
                });
            } else {
                var initialEntry = {};
                if (action.etype === ETYPE.SELECT || action.etype === ETYPE.CHECKBOX || action.etype === ETYPE.RADIO) {
                    initialEntry = {id: action.id, etype: action.etype, value: '', text: '', needRender: needRender, dirty: dirty};
                    newEntry = {id: action.id, etype: action.etype, value: action.value, text: action.text, needRender: needRender, dirty: dirty};
                } else {
                    initialEntry = {id: action.id, etype: action.etype, value: '', needRender: needRender, dirty: dirty};
                    newEntry = {id: action.id, etype: action.etype, value: action.value, needRender: needRender, dirty: dirty};
                }

                if (trackHistory) {
                    addHistory(initialEntry, newEntry);
                }
                newItems = state.items.concat([newEntry]);
            }

            return {items: newItems, history: state.history};
        }

        function clearAllFlag(state, needRender, dirty) {
            var newItems = state.items.map(function (entry, id) {
                return _.assign({}, entry, {id: entry.id, needRender: needRender, dirty: dirty});
            });
            var newState = {items: newItems, history: state.history};
            return newState;
        }

        function formReducer(state, action) {
            var newState;
            state = state || {items: [], history: []};

            switch (action.type) {
                case 'CHANGE_VALUE': {
                    newState = changeState(state, action, true, true);
                    break;
                }
                case 'CLEAR_ALL_FLAG': {
                    newState = clearAllFlag(state, false, false);
                    break;
                }
                case 'MAKE_ALL_DIRTY': {
                    newState = clearAllFlag(state, true, true);
                    break;
                }
                default: {
                    newState = state;
                }
            }

            return newState;
        }

        return {
            formReducer: formReducer
        }
    };

    var FormState = function () {
        var _stateXML = '';
        var _trackHistory = true;

        var _x2js = new X2JS();
        var _defaultState = {items: [], history: []};
        var _store;
        var _rendererTabIds = [];
        var _renderers = [];
        var _formStateReducer = FormStateReducer(_trackHistory);
        var _original_CP_dateSelected = CP_dateSelected || function () {
        };

        function isTrue(val) {
            if (typeof val === 'boolean') {
                return val;
            } else if (typeof val === 'string' && val.toLowerCase() === 'true') {
                return true;
            }
            return false;
        }

        function removeAllRenderers() {
            _renderers = [];
            _rendererTabIds = [];
        }

        function registerRenderer(renderer, tabId) {
            if (typeof renderer === 'function') {
                var rendererItem = _.find(_renderers, function (o) {
                    return o === renderer;
                });
                if (_.isUndefined(rendererItem)) {
                    _renderers.push(renderer);
                    _rendererTabIds.push(tabId || 'UNKNOWN');
                }
            } else {
                throw new FormStateException('renderer should be a function.');
            }
        }

        function getFinalState(config) {
            if (_store) {
                var config = _.assign({includeEmptyValue: true, history: true, activityName: '', memberID: '', memberName: ''}, config);
                var state = _store.getState();
                var finalState = _.assign({}, state);
                finalState.items = _.filter(finalState.items, function(o){
                    if(config.includeEmptyValue){
                        return !_.isEmpty(o.id);
                    }else{
                        if(typeof(o.value) === 'string') {
                            o.value = _.trim(o.value);
                        }
                        return !_.isEmpty(o.id) && !(typeof(o.value) !== 'boolean' && _.isEmpty(o.value));
                    }
                });

                if (_.isUndefined(finalState.history)) {
                    finalState.history = [];
                } else {
                    if (!(finalState.history instanceof Array)) {
                        var historyItem = finalState.history;
                        finalState.history = [];
                        finalState.history.push(historyItem);
                    }
                }

                if (config.history) {
                    var changedItems = [];
                    _.forEach(finalState.items, function (o) {
                        if (o.history && o.history.length > 0) {
                            if (o.history[o.history.length - 1].value !== o.value) {
                                delete o.history;
                                changedItems.push(o);
                            }
                        }
                    });

                    if (changedItems.length > 0) {
                        finalState.history.push({date: new Date(), activityName: config.activityName, memberID: config.memberID, memberName: config.memberName, changedItems: changedItems});
                    }
                }
                return finalState;
            } else {
                throw new FormStateException('FormState is not initialized. FormState.store is null');
            }
        }

        function getFinalStateXML() {
            var config = {history: false};
            if (arguments.length === 3) {
                config['activityName'] = arguments[0];
                config['memberID'] = arguments[1];
                config['memberName'] = arguments[2];
                if (_.isUndefined(arguments[0]) && _.isUndefined(arguments[1]) && _.isUndefined(arguments[2])) {
                    config.history = false;
                } else {
                    config.history = true;
                }
            } else if (arguments.length === 1 && typeof arguments[0] === 'object') {
                config = _.assign(config, arguments[0]);
            }

            var state = getFinalState(config);
            _.forEach(state.items, function (node) {
                delete node.history;
                delete node.needRender;
                delete node.dirty;
            });

            _.forEach(state.history, function (node) {
                if (node.changedItems != null) {
                    _.forEach(node.changedItems, function (changedNode) {
                        delete changedNode.needRender;
                        delete changedNode.dirty;
                    })
                }
            });

            state.items = {item: state.items};
            state.history = {item: state.history};

            var jsonWrapperObject = {formData: state};
            return _x2js.json2xml_str(jsonWrapperObject);
        }

        function getFormState() {
            if (_store) {
                return _store.getState();
            } else {
                var e = new FormStateException('Form Store is not initialized');
                FormLog.log(FormLog.LOG_LEVEL.ERROR, "FormState::getFormState", e);
                throw e;
            }
        }

        function getElementState(elementId) {
            var state = getFormState();
            var item = _.find(state.items, function (o) {
                return o.id === elementId;
            });

            return item;
        }

        function getState(elementId) {
            if (_.isUndefined(elementId)) {
                return getFormState();
            } else {
                return getElementState(elementId);
            }
        }

        function isDirty(elementId) {
            var es = getElementState(elementId);
            return (es && es.dirty);
        }

        function updateForm() {
            var state = getState();
            _.forEach(state.items, function (o) {
                if (o.needRender) {
                    if (o.etype === ETYPE.CHECKBOX) {
                        $('#' + o.id).prop('checked', isTrue(o.value));
                    } else if (o.etype === ETYPE.RADIO) {
                        var radios = $('input:radio[name=' + o.id + ']');
                        radios.filter('[value="' + o.value + '"]').prop('checked', true);
                    } else if (o.etype !== ETYPE.VARIABLE && o.etype !== ETYPE.PVARIABLE) {
                        var ele = $('#' + o.id);
                        var tagName = ("" + ele.prop("tagName")).toUpperCase();
                        if (tagName === "SPAN" || tagName === "DIV" || tagName === "P") {
                            if(typeof(o.value) !== 'object'){
                                ele.text(o.value);
                            }else{
                                // SKIP
                            }
                        } else if (o.etype === ETYPE.SELECT) {
                            if ($("#" + o.id + " option[value='" + o.value + "']").length === 0 && (FormUtility.isReadOnly())) {
                                ele.append($("<option></option>").attr("value", o.value).text(o.text));
                            }
                            ele.val(o.value);
                        } else {
                            ele.val(o.value);
                        }
                    }
                }
            });
        }

        function runRenderers(action) {
            updateForm();
            if (_renderers && _renderers.length > 0) {
                _.forEach(_renderers, function (renderer) {
                    if (typeof renderer === 'function') {
                        renderer(action);
                    } else {
                        throw new FormStateException('registered renderer is not a function.');
                    }
                });
            }
            dispatchAction(FormStateAction.clearAllFlag(), false); // it should be false when calling doAction from runRenderers
        }

        function dispatchAction(action, needRender) {
            _store.dispatch(action);
            if (_.isUndefined(needRender) || needRender === true) {
                runRenderers(action);
            }
        }

        function dispatchActionNoRender(action) {
            dispatchAction(action, false);
        }

        function updateCheckboxValue(id, value, needRender, text) {
            dispatchAction(FormStateAction.changeCheckbox(id, value, text), needRender);
        }

        function updateDateValue(id, value, needRender) {
            dispatchAction(FormStateAction.changeDate(id, value), needRender);
        }

        function updateObjectValue(id, value, needRender) {
            dispatchAction(FormStateAction.changeObject(id, value), needRender || false);
        }

        function updatePVariableValue(id, value, needRender) {
            dispatchAction(FormStateAction.changePVariable(id, value), needRender);
        }

        function updateRadioValue(id, value, needRender, text) {
            dispatchAction(FormStateAction.changeRadio(id, value, text), needRender);
        }

        function updateSelectValue(id, value, text, needRender) {
            dispatchAction(FormStateAction.changeSelect(id, value, text), needRender);
        }

        function updateTextValue(id, value, needRender) {
            dispatchAction(FormStateAction.changeText(id, value), needRender);
        }

        function updateDijitInputInner(id, value, needRender) {
            dispatchAction(FormStateAction.changeDijitInputInner(id, value), needRender);
        }

        function updateVariableValue(id, value, needRender) {
            dispatchAction(FormStateAction.changeVariable(id, value), needRender);
        }

        function getElementValue(elementId, defaultValue) {
            var savedState = getState(elementId);
            return savedState ? savedState.value : defaultValue;
        }

        function getElementSelectValue(elementId, defaultValue) {
            var value = defaultValue;
            var savedState = getState(elementId);
            if (savedState) {
                if (savedState.etype === "select" && savedState.text) {
                    value = {value: savedState.value, text: savedState.text};
                } else {
                    value = savedState.value;
                }
            }
            return value;
        }

        function getElementSingleValue(elementId, defaultValue, index_) {
            index_ = index_ || 0;
            var value = defaultValue;
            var values = getElementValue(elementId, null);
            if (null != values) {
                if (Array.isArray(values)) {
                    if (values.length > index_) {
                        value = values[index_];
                    }
                } else {
                    value = values;
                }
            }

            return value;
        }

        function getElementArrayValue(elementId, defaultValue) {
            var value = getElementValue(elementId, defaultValue);
            if (!Array.isArray(value)) {
                value = [value];
            }

            return value;
        }

        function getElementSelectArrayValue(elementId, defaultValue) {
            var value = getElementSelectValue(elementId, defaultValue);
            if (!Array.isArray(value)) {
                value = [value];
            }

            return value;
        }

        function getElementJSONValue(elementId, defaultValue) {
            var value = getElementValue(elementId, null);
            var json = defaultValue;
            if(!_.isEmpty(value)){
                try{
                    json = JSON.parse(value);
                }catch (e) {
                    FormLog.log(FormLog.LOG_LEVEL.ERROR, "FormState::getElementJSONValue", elementId, e);
                }
            }
            return json;
        }

        function getElementBooleanValue(elementId, defaultValue) {
            var value = getElementValue(elementId, defaultValue);
            if(typeof value === 'undefined' || value === ""){
                return typeof defaultValue === 'undefined' ? undefined : defaultValue;
            }else if(typeof value === 'boolean'){
                return value;
            }else{
                value = value.toUpperCase();
                return (value === "Y" || value === "YES" || value === 'T' || value === 'TRUE')
            }
        }

        function setCheckboxValueIfNoValue(id, value, needRender, text) {
            if (!getElementValue(id, null)) {
                updateCheckboxValue(id, value, needRender, text);
            }
        }

        function setDateValueIfNoValue(id, value, needRender) {
            if (!getElementValue(id, null)) {
                updateDateValue(id, value, needRender);
            }
        }

        function setObjectValueIfNoValue(id, value, needRender) {
            if (!getElementValue(id, null)) {
                updateObjectValue(id, value, needRender);
            }
        }

        function setPVariableValueIfNoValue(id, value, needRender) {
            if (!getElementValue(id, null)) {
                updatePVariableValue(id, value, needRender);
            }
        }

        function setRadioValueIfNoValue(id, value, needRender, text) {
            if (!getElementValue(id, null)) {
                updateRadioValue(id, value, needRender, text);
            }
        }

        function setSelectValueIfNoValue(id, value, text, needRender) {
            if (!getElementValue(id, null)) {
                updateSelectValue(id, value, needRender);
            }
        }

        function setTextValueIfNoValue(id, value, needRender) {
            if (!getElementValue(id, null)) {
                updateTextValue(id, value, needRender);
            }
        }

        function setVariableValueIfNoValue(id, value, needRender) {
            if (!getElementValue(id, null)) {
                updateVariableValue(id, value, needRender);
            }
        }

        function hasValueChanged(e) {
            var newValue = e.target.value;
            var savedState = getState(e.target.id);
            return (_.isUndefined(savedState) || savedState.value !== newValue);
        }

        function dispatchActionOnChangeText(e) {
            if (hasValueChanged(e)) {
                dispatchAction(FormStateAction.changeText(e.target.id, e.target.value));
            }
        }

        function dispatchActionOnChangeDijitInputInner(e) {
            if (hasValueChanged(e)) {
                dispatchAction(FormStateAction.changeDijitInputInner(e.target.id, e.target.value));
            }
        }

        function bindElements() {
            // CP_dateSelected is a javascript function provided by WebMaker.
            // This function is called whenever clicking on date in calendar.
            // Below code is hooking this function so that we can change date state after date is selected.
            CP_dateSelected = function (index, year, month, day) {
                _original_CP_dateSelected(index, year, month, day);
                var value = $('#' + index).val();
                dispatchAction(FormStateAction.changeDate(index, value));
            };

            $('select').on('change', function (e) {
                var target = e.target;
                var selectedIndex = target.options.selectedIndex;
                if (selectedIndex !== -1) {
                    var opt = target.options[selectedIndex];
                    dispatchAction(FormStateAction.changeSelect(target.id, opt.value, opt.text));
                }
            });

            $('textarea').on('blur', dispatchActionOnChangeText);
            $('input.textbox[_type="string"]').not('.ui-autocomplete-input').on('blur', dispatchActionOnChangeText);
            $('input.textbox[_type="number"]').not('.ui-autocomplete-input').on('blur', dispatchActionOnChangeText);
            $('input.dijitInputInner[type="text"]').not('.ui-autocomplete-input').on('blur', dispatchActionOnChangeDijitInputInner);

            $('input.textbox[_type="date"]').on('blur', function (e) {
                if (hasValueChanged(e)) {
                    dispatchAction(FormStateAction.changeDate(e.target.id, e.target.value));
                }
            });

            $('input.checkbox').on('click', function (e) {
                var checked = $('#' + e.target.id).prop('checked');
                dispatchAction(FormStateAction.changeCheckbox(e.target.id, checked));
            });

            $('input[type="checkbox"]').not('.checkbox').on('click', function (e) {
                var checked = $('#' + e.target.id).prop('checked');
                var value = $('#' + e.target.id).prop('value');
                dispatchAction(FormStateAction.changeCheckbox(e.target.id, checked, value));
            });

            $('input:radio').on('click', function (e) {
                if (hasValueChanged(e)) {
                    dispatchAction(FormStateAction.changeRadio(e.target.name, e.target.value));
                }
            });
        }

        function initStore() {
            _store = Redux.createStore(_formStateReducer.formReducer, _defaultState);
        }

        function initState() {
            if (_stateXML != null && _stateXML.length > 0) {
                var formDataObject = _x2js.xml_str2json(_stateXML);
                if (typeof formDataObject.formData.history !== 'object' || formDataObject.formData.history === '') {
                    formDataObject.formData.history = [];
                }
                _defaultState.history = formDataObject.formData.history.item;
                if (formDataObject.formData.items.item instanceof Array) {
                    _defaultState.items = formDataObject.formData.items.item;
                } else {
                    var item = formDataObject.formData.items.item;
                    _defaultState.items = [];
                    _defaultState.items.push(item);
                }
            }
        }

        function registerTabRenderers(tabList) {
            _.forEach(tabList, function (tab) {
                if (typeof tab.renderer === 'function') {
                    registerRenderer(tab.renderer, tab.id);
                }
            });
        }

        /** * Register Tab renders and bind elements. * This should be called after all forms are loaded. */
        function registerTabRendersAndBindElements(tabList) {
            registerTabRenderers(tabList);
            bindElements();
            dispatchActionNoRender(FormStateAction.makeAllDirty());
        }

        /**
         * Initialize FormState
         * @param stateXML_ (Optional) state xml of current form, default value is ""
         * @param renderer_ (Optional) a renderer of a main form
         * @param trackHistory_ (Optional) if this value is true, track history in state. default value is true
         */
        function init(stateXML_, renderer_, trackHistory_) {
            if (typeof Redux !== 'object') {
                throw new FormStateException('Redux is not initialized. Check whether you include redux.js');
            }
            if (typeof _ !== 'function') {
                throw new FormStateException('lodash is not initialized. Check whether you include lodash.min.js');
            }

            _stateXML = stateXML_ || '';
            _trackHistory = trackHistory_ || true;

            initState();
            initStore();

            removeAllRenderers();
            if (renderer_) {
                registerRenderer(renderer_, 'main');
            }
        }

        return {
            registerRenderer: registerRenderer,
            dispatchAction: dispatchAction,
            dispatchActionNoRender: dispatchActionNoRender,
            runRenderers: runRenderers,
            getElementValue: getElementValue,
            getElementSelectValue: getElementSelectValue,
            getElementSingleValue: getElementSingleValue,
            getElementArrayValue: getElementArrayValue,
            getElementBooleanValue: getElementBooleanValue,
            getElementJSONValue: getElementJSONValue,
            getElementSelectArrayValue: getElementSelectArrayValue,
            getFinalStateXML: getFinalStateXML,
            getState: getState,
            isDirty: isDirty,
            init: init,
            registerTabRendersAndBindElements: registerTabRendersAndBindElements,
            updateCheckboxValue: updateCheckboxValue,
            updateDateValue: updateDateValue,
            updateObjectValue: updateObjectValue,
            updatePVariableValue: updatePVariableValue,
            updateRadioValue: updateRadioValue,
            updateSelectValue: updateSelectValue,
            updateTextValue: updateTextValue,
            updateDijitInputInner: updateDijitInputInner,
            updateVariableValue: updateVariableValue,
            setCheckboxValueIfNoValue: setCheckboxValueIfNoValue,
            setDateValueIfNoValue: setDateValueIfNoValue,
            setObjectValueIfNoValue: setObjectValueIfNoValue,
            setPVariableValueIfNoValue: setPVariableValueIfNoValue,
            setRadioValueIfNoValue: setRadioValueIfNoValue,
            setSelectValueIfNoValue: setSelectValueIfNoValue,
            setTextValueIfNoValue: setTextValueIfNoValue,
            setVariableValueIfNoValue: setVariableValueIfNoValue
        };
    };

    var _initializer = window.FormState || (window.FormState = FormState());
})(window);
