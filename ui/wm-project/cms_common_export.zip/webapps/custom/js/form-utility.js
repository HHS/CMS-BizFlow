'use strict';

/**
 * Number.prototype.format(n, x, s, c)
 *
 * @param integer n: length of decimal
 * @param integer x: length of whole part
 * @param mixed   s: sections delimiter
 * @param mixed   c: decimal delimiter
 */
if (!Number.prototype.format) {
    Number.prototype.format = function (n, x, s, c) {
        n = (typeof n === "undefined") ? 2 : n;
        x = x || 3;
        s = s || ",";
        c = c || ".";

        var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\D' : '$') + ')';
        var num = this.toFixed(Math.max(0, ~~n));

        return (c ? num.replace('.', c) : num).replace(new RegExp(re, 'g'), '$&' + (s || ','));
    };
}

if (!String.prototype.endsWith) {
    String.prototype.endsWith = function (search, this_len) {
        if (this_len === undefined || this_len > this.length) {
            this_len = this.length;
        }
        return this.substring(this_len - search.length, this_len) === search;
    };
}

if (!hyf.util.setComponentUsability) {
    hyf.util.setComponentUsability = function (component, enable) {
        if (enable) hyf.util.enableComponent(component);
        else hyf.util.disableComponent(component);
    };
}

if (!hyf.util.setComponentVisibility) {
    hyf.util.setComponentVisibility = function (component, visible) {
        if (visible) hyf.util.showComponent(component);
        else hyf.util.hideComponent(component);
    };
}

(function (window) {
    var FormUtility = function () {
        // dateFormat can include yyyy mm dd hh MM ss pattern and these pattern will be replaced by real values.
        // yyyy - 4 digit year, mm - month, dd - day, hh - hours, MM - minutes, ss - seconds
        function formatDateString(dateFormat, yyyy, mm, dd, hh, MM, ss) {
            if (dateFormat == null || dateFormat.length === 0) {
                dateFormat = 'mm/dd/yyyy';
            }
            var dateString = dateFormat;
            if (yyyy != null && yyyy.length > 0) {
                dateString = dateString.replace(/yyyy/, yyyy);
            }
            if (mm != null && mm.length > 0) {
                dateString = dateString.replace(/mm/, mm);
            }
            if (dd != null && dd.length > 0) {
                dateString = dateString.replace(/dd/, dd);
            }
            if (hh != null && hh.length > 0) {
                var amPM = 'AM';
                dateString = dateString.replace(/HH/, hh);
                var hh12 = hh;
                if (hh12 >= 12) {
                    amPM = 'PM';
                    hh12 = (hh12 > 12) ? (hh12 - 12) : hh12;
                    hh12 = '' + hh12;
                    hh12 = (hh12.length === 1) ? ('0' + hh12) : hh12;
                }
                dateString = dateString.replace(/hh/, hh12);
                dateString = dateString.replace(/a/, amPM);
            }
            if (MM != null && MM.length > 0) {
                dateString = dateString.replace(/MM/, MM);
            }
            if (ss != null && ss.length > 0) {
                dateString = dateString.replace(/ss/, ss);
            }
            dateString = dateString.replace(/yyyy/, '');
            dateString = dateString.replace(/mm/, '');
            dateString = dateString.replace(/dd/, '');
            dateString = dateString.replace(/hh/, '');
            dateString = dateString.replace(/MM/, '');
            dateString = dateString.replace(/ss/, '');
            return dateString;
        }

        function getDateString(isUTC, dateFormat, when) {
            var year, month, day, hours, minutes, seconds;
            if (isUTC === true) {
                year = when.getUTCFullYear();
                month = when.getUTCMonth() + 1;
                day = when.getUTCDate();
                hours = when.getUTCHours();
                minutes = when.getUTCMinutes();
                seconds = when.getUTCSeconds();
            } else {
                year = when.getFullYear();
                month = when.getMonth() + 1;
                day = when.getDate();
                hours = when.getHours();
                minutes = when.getMinutes();
                seconds = when.getSeconds();
            }
            if (month < 10) {
                month = '0' + month;
            }
            if (day < 10) {
                day = '0' + day;
            }
            if (hours < 10) {
                hours = '0' + hours;
            }
            if (minutes < 10) {
                minutes = '0' + minutes;
            }
            if (seconds < 10) {
                seconds = '0' + seconds;
            }
            year = '' + year;
            month = '' + month;
            day = '' + day;
            hours = '' + hours;
            minutes = '' + minutes;
            seconds = '' + seconds;
            return formatDateString(dateFormat, year, month, day, hours, minutes, seconds);
        }

        function getNowUTCString() {
            return getDateString(true, 'yyyy/mm/dd HH:MM:ss', new Date());
        }

        function convertDateToLocalTime(dateString) {
            var newDate = null;
            if (null != dateString && dateString.length > 0) {
                var date = new Date(dateString);
                newDate = new Date(date.getTime() - date.getTimezoneOffset() * 60000); // Adjust to local time
            }

            return newDate;
        }

        function getLocalDateString(dateString, format) {
            var newDate = convertDateToLocalTime(dateString);
            return newDate ? getDateString(false, format, newDate) : "";
        }

        // The parameter "components" is array of component IDs.
        function enableComponents(components) {
            if (components != null && components.length > 0) {
                components.forEach(function (component) {
                    hyf.util.enableComponent(component);
                });
            }
        }

        // The parameter "components" is array of component IDs.
        function disableComponents(components) {
            if (components != null && components.length > 0) {
                components.forEach(function (component) {
                    hyf.util.disableComponent(component);
                });
            }
        }

        /**
         * Event handler code generated by WebMaker when exit WIH action is used in Event tab of the WM Studio.
         * Moved the implementation here so as to have better development control over the event handler.
         * @param btnId - element id of the exit button
         */
        function exitWitemHandler(btnId) {
            var evt = window.event;
            var target = document.getElementById(btnId);
            var sourceComponent = target;
            if ((sourceComponent != null) && (sourceComponent.nodeType === 3)) { // defeat Safari bug
                sourceComponent = sourceComponent.parentNode;
            }

            var objEventSource = {
                name: 'EventSource',
                option: 'field',
                event: evt,
                component: sourceComponent,
                value: btnId,
                field: target
            };
            return dojo.hitch(objEventSource.field, function () {
                var objWIHAction = {name: 'WIHAction', option: 'WIHAction', value: 'exit'};
                var objResponse = {name: 'Response', option: 'Default', value: ''};
                hyf.HSGAction.handleWIHAction(objWIHAction, objResponse, objEventSource);
            })();
        }

        function initMaxSizePerTab(tabID, where) {
            var inputControls = $('#' + tabID + ' input[size]');
            $.each(inputControls, function (index, control) {
                var maxSize = $(control).attr('size');
                var id = $(control).attr('id');
                var controlType = $(control).attr('_type');
                var alwaysReadonly = $('control').attr('alwaysReadonly');
                var alwaysDisabled = $('control').attr('alwaysDisabled');

                // Skip if the control is date control
                if (controlType !== 'date' && typeof id !== 'undefined' && !alwaysReadonly && !alwaysDisabled) {
                    if ($(control).parent().length === 1
                        && $(control).parent().parent().length === 1
                        && $(control).parent().parent().parent().length === 1) {
                        var initialMessage = $(control).val();
                        var target;
                        if ($(control).hasClass('dijitInputInner')) {
                            target = $(control).parent().parent().parent();
                        } else {
                            target = $(control).parent().parent();
                        }
                        if (target.find('span.sizeLabel').length === 0) {
                            var sizeLabelId = '_sizeLabel';
                            if (where === 'bottom') {
                                target.append('<div id="' + (id + '_sizeLabelDiv') + '"><span id="' + (id + '_sizeLabel') + '" class="sizeLabel" debugMessage="' + initialMessage + '">' + (maxSize - initialMessage.length) + ' characters remaining</span></div>');
                                sizeLabelId = '_sizeLabelDiv';
                            } else {
                                target.append('<span id="' + (id + '_sizeLabel') + '" class="sizeLabel" debugMessage="' + initialMessage + '">' + (maxSize - initialMessage.length) + ' characters remaining</span>');
                            }
                            $('#' + id + sizeLabelId).hide();
                            $(control).on('focus', function () {
                                var disabled = $(this).attr('disabled');
                                var readonly = $(this).prop('readonly');
                                if (!disabled && !readonly) {
                                    var message = $(control).val();
                                    if (message.length > maxSize) {
                                        $(control).val(message.substring(0, maxSize));
                                    }
                                    $('#' + id + '_sizeLabel').html('&nbsp;&nbsp;' + (maxSize - message.length) + ' characters remaining');
                                    $('#' + id + sizeLabelId).show("slow");
                                }
                            });
                            $(control).on('blur', function () {
                                $('#' + id + sizeLabelId).hide();
                            });
                            $(control).on('keyup paste blur change', function () {
                                var message = $(control).val();
                                if (message.length > maxSize) {
                                    $(control).val(message.substring(0, maxSize));
                                }
                                $('#' + id + '_sizeLabel').html('&nbsp;&nbsp;' + (maxSize - message.length) + ' characters remaining');
                            })
                        }
                    }
                }
            });

            inputControls = $('#' + tabID + ' textarea.textbox[maxlength]');
            $.each(inputControls, function (index, control) {
                var maxSize = $(control).attr('maxlength');
                var id = $(control).attr('id');
                var alwaysReadonly = $('control').attr('alwaysReadonly');
                var alwaysDisabled = $('control').attr('alwaysDisabled');
                if ($(control).parent().length === 1 && typeof id !== 'undefined' && !alwaysReadonly && !alwaysDisabled) {
                    var initialMessage = $(control).val();
                    if ($(control).parent().find('span.sizeLabel').length === 0) {
                        var sizeLabelId = '_sizeLabel';
                        if (where === 'bottom') {
                            $(control).parent().append('<div id="' + (id + '_sizeLabelDiv') + '"><span id="' + (id + '_sizeLabel') + '" class="sizeLabel">' + (maxSize - initialMessage.length) + ' characters remaining</span></div>');
                            sizeLabelId = '_sizeLabelDiv';
                        } else {
                            $(control).parent().append('<span id="' + (id + '_sizeLabel') + '" class="sizeLabel">' + (maxSize - initialMessage.length) + ' characters remaining</span>');
                        }
                        $('#' + id + sizeLabelId).hide();
                        $(control).on('focus', function () {
                            var disabled = $(this).attr('disabled');
                            var readonly = $(this).prop('readonly');
                            if (!disabled && !readonly) {
                                var message = $(control).val();
                                $('#' + id + '_sizeLabel').html('&nbsp;&nbsp;' + (maxSize - message.length) + ' characters remaining');
                                $('#' + id + sizeLabelId).show("slow");
                            }
                        });
                        $(control).on('blur', function () {
                            $('#' + id + sizeLabelId).hide();
                        });
                        $(control).on('keyup keypress blur change', function () {
                            var message = $(control).val();
                            $('#' + id + '_sizeLabel').html('&nbsp;&nbsp;' + (maxSize - message.length) + ' characters remaining');
                        })
                    }
                }
            });
        }

        function setDateIconTabOrderPerTab(tabID) {
            var dateTextBoxes = $('#' + tabID + ' input.textbox[_type=date]');
            $.each(dateTextBoxes, function (index, control) {
                var tabIndex = $(control).attr('tabindex');
                if ($.isNumeric(tabIndex) === true && tabIndex > 0) {
                    var controlID = $(control).attr('id');
                    var newTabIndex = tabIndex * 1 + 1;
                    $('#' + controlID + '_calendar_anchor').attr('tabindex', newTabIndex);
                }
            });
        }

        function setDateIconTabOrder(tabs) {
            _.forEach(tabs, function (tab) {
                setDateIconTabOrderPerTab(tab);
            });
        }

        function loadPartialPage(action, sourceGroup, targetGroup) {
            if (window.location.pathname.indexOf('bizflowwebmaker') > -1 && action.indexOf('/') === 0) {
                action = '/bizflowwebmaker' + action;
            }
            var objEventSource5 = {
                name: 'EventSource',
                optio: 'field',
                even: null,
                componen: null,
                value: targetGroup,
                field: dojo.byId(targetGroup)
            };
            var objAction = {
                name: 'Action',
                option: 'Action',
                value: action
            };
            var objSourceGroup = null;
            if (null === sourceGroup || '' === sourceGroup || 'all' === sourceGroup || 'ALL' === sourceGroup) {
                objSourceGroup = {name: 'SourceGroup', option: 'AllFormData', value: ''};
            } else {
                objSourceGroup = {name: 'SourceGroup', option: 'PageGroup', value: sourceGroup};
            }
            var objTargetGroup = {
                name: 'TargetGroup',
                option: 'PageGroup',
                value: targetGroup
            };
            var objValidate = {
                name: 'Validate',
                option: 'Static',
                value: 'false'
            };
            hyf.FMAction.handleAjaxSubmission(objAction, objSourceGroup, objTargetGroup, objValidate, objEventSource5);
        }

        function callPartialPage(o, action, sourceGroup, targetGroup) {
            loadPartialPage(action, sourceGroup, targetGroup);
        }

        function submitFormPage(o, action) {
            var e = (typeof (event) !== 'undefined') ? event : arguments[0];
            var evt = (window.event) ? window.event : e;
            var sourceComponent = null;
            if ((evt != null) && (typeof (evt) !== 'undefined')) {
                sourceComponent = (evt.target) ? evt.target : evt.srcElement;
                if ((sourceComponent != null) && (sourceComponent.nodeType === 3)) { // defeat Safari bug
                    sourceComponent = sourceComponent.parentNode;
                }
            }
            var objId = null;
            if (o !== 'undefined' && o != null && o.id !== 'undefined' && o.id != null) {
                objId = o.id;
            }
            var objEventSource = {
                name: 'EventSource',
                option: 'field',
                event: evt,
                component: sourceComponent,
                value: objId,
                field: document.getElementById(objId)
            };
            return dojo.hitch(objEventSource.field, function () {
                var objAction = {
                    name: 'Action',
                    option: 'Action',
                    value: action
                };
                var objValidate = {
                    name: 'Validate',
                    option: 'Static',
                    value: 'false'
                };
                hyf.FMAction.handleFormSubmission(objAction, objValidate, objEventSource);
            })();
        }

        // Grey out screen and prevent from user input
        function greyOutScreen(mode, messageBody) {
            try {
                if (mode) {
                    if (null == messageBody || '' === messageBody) {
                        messageBody = "<p style='font-size:30px;color:white;'>Please wait...</p>";
                    }
                    blockScreen(messageBody);
                } else {
                    unblockScreen();
                }
            } catch (e) {
            }
        }

        function blockScreen(messageContent) {
            messageContent = messageContent || 'Please wait...';
            $.blockUI({
                message: messageContent,
                css: {
                    border: 'none',
                    padding: '20px',
                    backgroundColor: '#000',
                    '-webkit-border-radius': '15px',
                    '-moz-border-radius': '15px',
                    opacity: 0.5,
                    color: '#000'
                }
            });
        }

        function unblockScreen(waitTime) {
            waitTime = waitTime || 500;
            $.unblockUI({fadeOut: waitTime});
        }

        function removeSizeLabel(element) {
            var target = null;
            var nodeName = $(element).get(0).tagName;
            if (nodeName === 'input') {
                if ($(element).hasClass('dijitInputInner')) {
                    target = $(element).parent().parent().parent();
                } else {
                    target = $(element).parent().parent();
                }
            } else if (nodeName === 'textarea') {
                target = $(element).parent();
            }

            if (target != null && target.length > 0) {
                $(target).find('p.sizeLabel').remove();
            }
        }

        var _readOnly = null;

        function isReadOnly(readOnlyEleId_) {
            if (null === _readOnly) {
                _readOnly = 'y' === getInputElementValue(readOnlyEleId_ || 'h_readOnly');
            }
            return _readOnly;
        }

        function initMaxSize(tabs, where) {
            tabs.forEach(function (tab) {
                initMaxSizePerTab(tab, where);
            });
        }

        function saveForm(event) {
            var evt = (window.event) ? window.event : event;
            var sourceComponent = null;
            if ((evt != null) && (typeof (evt) !== 'undefined')) {
                sourceComponent = (evt.target) ? evt.target : evt.srcElement;
                if ((sourceComponent != null) && (sourceComponent.nodeType === 3)) { // defeat Safari bug
                    sourceComponent = sourceComponent.parentNode;
                }
            }
            var objEventSource = {name: 'EventSource', option: 'field', event: evt, component: sourceComponent, value: evt.target.id, field: document.getElementById(evt.target.id)};

            return dojo.hitch(objEventSource.field, function () {
                var objAction = {name: 'Action', option: 'Action', value: 'saveNewForm'};
                var objValidate = {name: 'Validate', option: 'Static', value: 'false'};
                hyf.FMAction.handleFormSubmission(objAction, objValidate, objEventSource);
            })();
        }

        function getUuid() {
            return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
                return v.toString(16);
            })
        }

        function setSelectValue(selector, value) {
            if (null != value && undefined != typeof(value)) {
                $(selector).val(value);
            }
        }

        function arrayToObjects(array, key) {
            var obj = {};
            if (array) {
                for (var i = 0; i < array.length; i++) {
                    var item = array[i];
                    var keyValue = item[key];
                    obj[keyValue] = item;
                }
            }

            return obj;
        }

        function parseInt(value, defaultValue) {
            var int = defaultValue;
            try {
                int = window.parseInt(value);
            } catch (e) {
            }

            return int;
        }

        function moneyToNumber(value, defaultValue) {
            var num = defaultValue;
            if (typeof value === 'string' && value && value.length > 0) {
                value = value.replace(/[^0-9.]/g, "");
                try {
                    num = window.parseFloat(value)
                } catch (e) {
                }
            } else if (typeof value === 'number') {
                num = value;
            }

            return num;
        }

        function addSuffix(string, suffix) {
            if (!string.endsWith(suffix)) {
                string += suffix;
            }

            return string;
        }

        function getInputElementValue(eleId, defaultValue, resetValue) {
            var value;
            var ele = document.getElementById(eleId);
            if (ele) {
                value = ele.value;
                if (undefined !== resetValue) {
                    ele.value = resetValue;
                }
            }
            return value ? value : (defaultValue ? defaultValue : '');
        }

        function setInputElementValue(eleId, value) {
            var ele = document.getElementById(eleId);
            if (ele) {
                ele.value = value;
            }
        }

        function setElementAttribute(eleId, name, value) {
            var ele = document.getElementById(eleId);
            if (ele) {
                ele.setAttribute(name, value);
            }
        }

        function getElement(element) {
            return typeof element === "string" ? document.getElementById(element) : element;
        }

        function addElementSuffixTooltip(element, suffixTooltip) {
            element = getElement(element);
            if(element) {
                var bak = element.getAttribute("title-bak");
                if (!bak && bak !== '') {
                    bak = element.getAttribute("title") || '';
                    element.setAttribute("title-bak", bak);
                }
                element.setAttribute("title", bak + suffixTooltip);
            }
        }

        function getBizFlowModalPopupTop() {
            var _top = null;
            try {
                if (null != top && "undefined" != typeof(top)) {
                    if ("undefined" != typeof(top.getUserClientType) && "undefined" != typeof(top.openModalPopupWindow)) {
                        _top = top;
                    } else if (null != top.opener && "undefined" != typeof(top.opener)) {
                        if ("undefined" != typeof(top.opener.getUserClientType) && "undefined" != typeof(top.opener.openModalPopupWindow)) {
                            _top = top.opener;
                        } else if (null != top.opener.top && "undefined" != typeof(top.opener.top)) {
                            if ("undefined" != typeof(top.opener.top.getUserClientType) && "undefined" != typeof(top.opener.top.openModalPopupWindow)) {
                                _top = top.opener.top;
                            }
                        }
                    }
                } else if (parent) {
                    if (null != parent.top && "undefined" != typeof(parent.top)) {
                        if (typeof(parent.top.getUserClientType) != "undefined" && "undefined" != typeof(parent.top.openModalPopupWindow)) {
                            _top = parent.top;
                        } else if (null != parent.top.opener && "undefined" != typeof(parent.top.opener)) {
                            if ("undefined" != typeof(parent.top.opener.getUserClientType) && "undefined" != typeof(parent.top.opener.openModalPopupWindow)) {
                                _top = parent.top.opener;
                            } else if (null != parent.top.opener.top && "undefined" != typeof(parent.top.opener.top)) {
                                if ("undefined" != typeof(parent.top.opener.top.getUserClientType) && "undefined" != typeof(parent.top.opener.top.openModalPopupWindow)) {
                                    _top = parent.top.opener.top;
                                }
                            }
                        }
                    }
                }

                if (null == _top) {
                    if (top && "undefined" != typeof(top.WIH_information)) {
                        _top = top.WIH_information;
                    }
                }
            } catch (e) {
            }

            return _top;
        }

        function getUserAccessibilityPreference() {
            var top = getBizFlowModalPopupTop();
            var workAreaFrame = top.document.getElementById("workAreaFrame");
            var doc = workAreaFrame.contentWindow.document || workAreaFrame.document;
            var imgs = doc.getElementsByTagName("img");
            for (var i = 0; i < imgs.length; i++) {
                var src = "" + imgs[i].src;
                if (src.indexOf("icon_user_dis.gif") !== -1) {
                    return true;
                }
            }

            return false;
        }

        var _accessibilityOn = undefined;

        function isAccessibilityOn() {
            if (undefined === _accessibilityOn) {
                _accessibilityOn = getUserAccessibilityPreference();
            }
            return _accessibilityOn;
        }

        function removeSelectOption(value, elementId, target) {
            target = target || document.getElementById(elementId);
            for (var i = 0; i < target.options.length; i++) {
                if (target.options[i].value === value) {
                    target.remove(i);
                    break;
                }
            }
        }

        function addSelectOption(text, value, elementId, target) {
            target = target || document.getElementById(elementId);
            var opt = new Option();
            opt.text = text;
            opt.value = value;
            target.add(opt);

            return target;
        }

        function sortSelectOptions(elementId) {
            $("#" + elementId).html($("#" + elementId + " option").sort(function (a, b) {
                return a.text == b.text ? 0 : a.text < b.text ? -1 : 1
            }));
        }

        function sortSelectOptionsExceptFirst(elementId, target) {
            target = target || document.getElementById(elementId);
            var opt = target.options[0];

            target.remove(0);
            sortSelectOptions(elementId);
            target.add(opt, 0);

            return target;
        }

        function addSelectionAndSortExceptLast(text, value, elementId, alwaysLastValue) {
            var target = addSelectOption(text, value, elementId);
            var last = null;
            for (var i = 0; i < target.options.length; i++) {
                var opt = target.options[i];
                if (opt.value === alwaysLastValue) {
                    last = opt;
                    target.remove(i);
                    break;
                }
            }

            sortSelectOptionsExceptFirst(elementId, target);

            if (last !== null) {
                target.add(last);
            }

            return target;
        }

        function focusElement(elementId) {
            if (elementId) {
                var ele = document.getElementById(elementId);
                if (ele) {
                    ele.focus();
                }
            }
        }

        function setInclusiveRangeConstraint(field, minInclusive, maxInclusive) {
            try {
                hyf.util.setInclusiveRangeConstraint(field, minInclusive, maxInclusive);
            } catch (e) {
            }
        }

        return {
            blockScreen: blockScreen,
            callPartialPage: callPartialPage,
            loadPartialPage: loadPartialPage,
            disableComponents: disableComponents,
            enableComponents: enableComponents,
            exitWitemHandler: exitWitemHandler,
            getDateString: getDateString,
            getNowUTCString: getNowUTCString,
            getUuid: getUuid,
            greyOutScreen: greyOutScreen,
            initMaxSize: initMaxSize,
            isReadOnly: isReadOnly,
            removeSizeLabel: removeSizeLabel,
            saveForm: saveForm,
            setDateIconTabOrder: setDateIconTabOrder,
            submitFormPage: submitFormPage,
            unblockScreen: unblockScreen,
            convertDateToLocalTime: convertDateToLocalTime,
            getLocalDateString: getLocalDateString,
            setSelectValue: setSelectValue,
            arrayToObjects: arrayToObjects,
            parseInt: parseInt,
            moneyToNumber: moneyToNumber,
            addSuffix: addSuffix,
            getInputElementValue: getInputElementValue,
            setInputElementValue: setInputElementValue,
            setElementAttribute: setElementAttribute,
            getElement: getElement,
            addElementSuffixTooltip: addElementSuffixTooltip,
            getBizFlowModalPopupTop: getBizFlowModalPopupTop,
            isAccessibilityOn: isAccessibilityOn,
            removeSelectOption: removeSelectOption,
            addSelectOption: addSelectOption,
            sortSelectOptions: sortSelectOptions,
            sortSelectOptionsExceptFirst: sortSelectOptionsExceptFirst,
            addSelectionAndSortExceptLast: addSelectionAndSortExceptLast,
            focusElement: focusElement,
            setInclusiveRangeConstraint: setInclusiveRangeConstraint
        }
    };

    var _initializer = window.FormUtility || (window.FormUtility = FormUtility());
})(window);


