'use strict';

function LookupManagerException(message) {
    this.message = message;
    this.name = 'LookupManager Exception';
}

(function (window) {
    var LookupManager = function () {
        var _x2js = new X2JS();
        var _jsonObject = null;
        var _lookupDataSelector;

        function _generateHierarchy() {
            try {
                var items = _jsonObject.lookup.record;
                if (items != null) {
                    var index = 0;
                    var len = items.length;
                    for (; index < len; index++) {
                        var item = items[index];
                        if (item.PARENTID !== '0') {
                            var parentItem = _findByID(items, item.PARENTID);
                            if (parentItem != null) {
                                parentItem.children = parentItem.children || [];
                                parentItem.children.push(JSON.parse(JSON.stringify(item)));
                                item.movedToParent = true;
                            } else {
                                FormLog.log(FormLog.LOG_LEVEL.WARNING, 'LookupManager::generateHierarchy - Not found parent item - item ==>', items[index]);
                            }
                        }
                    }

                    for (index = items.length - 1; index >= 0; index--) {
                        if (items[index].movedToParent === true) {
                            items.splice(index, 1);
                        }
                    }
                }
            } catch (e) {
                FormLog.log(FormLog.LOG_LEVEL.ERROR, 'LookupManager::generateHierarchy - Failed to generate hierarchy', e);
            }
        }

        function init(lookupDataSelector_) {
            _lookupDataSelector = lookupDataSelector_ || '#h_lookupXMLString';
            if (_jsonObject == null) {
                var lookupXML = $(_lookupDataSelector).val();
                if (lookupXML == null || lookupXML.length === 0) {
                    FormLog.log(FormLog.LOG_LEVEL.ERROR, 'LookupManager::init - no lookup items found from the form - lookupDataSelector ==>', _lookupDataSelector);
                    throw new LookupManagerException("No lookup items found");
                } else {
                    $(_lookupDataSelector).val('');
                }
                _jsonObject = _x2js.xml_str2json(lookupXML);
                if (undefined === _jsonObject.lookup.record || null == _jsonObject.lookup.record) {
                    FormLog.log(FormLog.LOG_LEVEL.ERROR, 'LookupManager::init - no lookup items found from the form - lookupJsonObject ==>', _jsonObject);
                    var msg = "No lookup items found";
                    if (_jsonObject.lookup.status && _jsonObject.lookup.status.message) {
                        msg += " - " + _jsonObject.lookup.status.message;
                    }
                    throw new LookupManagerException(msg);
                }
                _generateHierarchy();
            } else {
                FormLog.log(FormLog.LOG_LEVEL.INFO, 'LookupManager::init - Already initialized.');
            }
        }

        function _findByID(items, ID) {
            if (items != null) {
                var len = items.length;
                for (var index = 0; index < len; index++) {
                    var item = items[index];
                    if (item.ID === ID) {
                        return item;
                    }

                    if (item.children != null && item.children.length > 0) {
                        var foundItem = _findByID(item.children, ID);
                        if (foundItem != null) {
                            return foundItem;
                        }
                    }
                }
                return null;
            }
        }

        function findByID(ID) {
            if (_jsonObject == null) {
                FormLog.log(FormLog.LOG_LEVEL.ERROR, 'LookupManager::findByID - LookupManager is not initialized. Call LookupManager.init() first');
                return null;
            }
            return _findByID(_jsonObject.lookup.record, ID);
        }

        function _findByLType(items, pathArray) {
            if (undefined === items || items === null || items.length === null || pathArray === null || pathArray.length === 0) {
                return null;
            }

            var targetPath = null;
            var targetLabel = null;
            var path = pathArray[0];
            var startIndex = path.indexOf('[');
            if (startIndex === -1) {
                targetPath = pathArray[0];
                targetLabel = null;
            } else {
                targetPath = path.substring(0, startIndex);
                targetLabel = path.substring(startIndex + 1, path.length - 1);
            }

            var foundItems = [];
            var len = items.length;
            for (var index = 0; index < len; index++) {
                var item = items[index];
                if (item.LTYPE === targetPath) {
                    if (targetLabel != null) {
                        if (item.LABEL !== targetLabel) {
                            continue;
                        }
                    }
                    if (pathArray.length === 1) {
                        foundItems.push(item);
                    } else {
                        var pathArrayClone = pathArray.slice();
                        pathArrayClone.splice(0, 1);
                        var foundItemsFromSub = _findByLType(item.children, pathArrayClone);
                        if (foundItemsFromSub != null && foundItemsFromSub.length > 0) {
                            foundItems.push.apply(foundItems, foundItemsFromSub);
                        }
                    }
                }
            }

            return foundItems;
        }

        function findByLTYPE(LTYPEPath) {
            if (_jsonObject == null) {
                FormLog.log(FormLog.LOG_LEVEL.ERROR, 'LookupManager::findByLTYPE() - LookupManager is not initialized. Call LookupManager.init() first');
                return null;
            }
            var translatedLTYPEPath = LTYPEPath.split('*/*').join('*_*');
            var paths = translatedLTYPEPath.split('/');
            var translatedPaths = [];
            for (var index = 0; index < paths.length; index++) {
                var newPath = paths[index].split('*_*').join('/');
                translatedPaths.push(newPath);
            }

            return _findByLType(_jsonObject.lookup.record, translatedPaths);
        }

        function checkForm() {
            if ($(_lookupDataSelector).length !== 0) {
                FormLog.log(FormLog.LOG_LEVEL.ERROR, 'LookupManager::checkForm - Cannot find lookup data - lookupDataSelector ==>', _lookupDataSelector);
            }
        }

        checkForm();

        return {
            findByID: findByID,
            findByLTYPE: findByLTYPE,
            init: init
        }
    };

    var _initializer = window.LookupManager || (window.LookupManager = LookupManager());
})(window);

