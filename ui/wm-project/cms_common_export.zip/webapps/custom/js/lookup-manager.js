/* eslint no-unused-vars:0 */

/*
    Lookup Manager object
    This object will manage lookup values in client side.

    Example of LookupItem Object
    {
        ACTIVE: "1",
        DISPORDER: "",
        ID: "500",
        LABEL: "Existing Position Description (PD)",
        LTYPE: "MDDocumentType",
        PARENTID: "477",
        children: null
    }
*/

(function (window) {
    'use strict';

    var LookupManager = function () {
        var _x2js = new X2JS();
        var _jsonObject = null;
        var _lookupDataSelector;

        function _generateHierarchy() {
            try {
                var items = _jsonObject.lookup.record;
                if (items != null) {
                    var index = 0;
                    for (; index < items.length; index++) {
                        if (items[index].PARENTID !== '0') {
                            var parentItem = _findByID(items, items[index].PARENTID);
                            if (parentItem != null) {
                                if (parentItem.children == null) {
                                    parentItem.children = [];
                                }
                                parentItem.children.push(JSON.parse(JSON.stringify(items[index])));
                                items[index].movedToParent = true;
                            } else {
                                FormLog.log(FormLog.LOG_LEVEL.WARNING, 'LookupManager::generateHierarchy - Not found parent item - item ==>', items[index]);
                            }
                        }
                    }

                    for (index = items.length - 1; index >= 0; index--) {
                        if (items[index].movedToParent === true) {
                            items.splice(index, 1);
                        }
                    }
                }
            } catch (e) {
                FormLog.log(FormLog.LOG_LEVEL.ERROR, 'LookupManager::generateHierarchy - Failed to generate hierarchy', e);
            }
        }

        /*
            Initialize lookup manager object. This function should be called before using LookupManager.
            This function will retrieve XML String from h_lookupXMLString element and coverts to JSON object.
        */
        function initWithXML(lookupXML) {
            _jsonObject = _x2js.xml_str2json(lookupXML);
            _generateHierarchy();
        }

        function init(lookupDataSelector_) {
            _lookupDataSelector = lookupDataSelector_ || '#h_lookupXMLString';
            if (_jsonObject == null) {
                var lookupXML = $(_lookupDataSelector).val();
                if (lookupXML == null || lookupXML.length === 0) {
                    FormLog.log(FormLog.LOG_LEVEL.ERROR, 'LookupManager::init - no lookup items found from the form - lookupDataSelector ==>', _lookupDataSelector);
                } else {
                    $(_lookupDataSelector).val('');
                }
                _jsonObject = _x2js.xml_str2json(lookupXML);
                _generateHierarchy();
            } else {
                FormLog.log(FormLog.LOG_LEVEL.INFO, 'LookupManager::init - Already initialized.');
            }
        }

        function _findByID(items, ID) {
            if (items != null) {
                for (var index = 0; index < items.length; index++) {
                    if (items[index].ID === ID) {
                        return items[index];
                    }

                    if (items[index].children != null && items[index].children.length > 0) {
                        var foundItem = _findByID(items[index].children, ID);
                        if (foundItem != null) {
                            return foundItem;
                        }
                    }
                }
                return null;
            }
        }

        /*
            Find lookup value with ID
            @param {string} ID
            @return {lookupItem}
        */
        function findByID(ID) {
            if (_jsonObject == null) {
                FormLog.log(FormLog.LOG_LEVEL.ERROR, 'LookupManager::findByID - LookupManager is not initialized. Call LookupManager.init() first');
                return null;
            }
            return _findByID(_jsonObject.lookup.record, ID);
        }

        function _findByLType(items, pathArray) {
            if (items === null || items.length === null || pathArray === null || pathArray.length === 0) {
                return null;
            }

            var targetPath = null;
            var targetLabel = null;
            var startIndex = pathArray[0].indexOf('[');
            if (startIndex === -1) {
                targetPath = pathArray[0];
                targetLabel = null;
            } else {
                targetPath = pathArray[0].substring(0, startIndex);
                targetLabel = pathArray[0].substring(startIndex + 1, pathArray[0].length - 1);
            }

            var foundItems = [];
            for (var index = 0; index < items.length; index++) {
                if (items[index].LTYPE === targetPath) {
                    if (targetLabel != null) {
                        if (items[index].LABEL !== targetLabel) {
                            continue;
                        }
                    }
                    if (pathArray.length === 1) {
                        foundItems.push(items[index]);
                    } else {
                        var pathArrayClone = pathArray.slice();
                        pathArrayClone.splice(0, 1);
                        var foundItemsFromSub = _findByLType(items[index].children, pathArrayClone);
                        if (foundItemsFromSub != null && foundItemsFromSub.length > 0) {
                            foundItems.push.apply(foundItems, foundItemsFromSub);
                        }
                    }
                }
            }

            return foundItems;
        }

        /*
            Find lookup values with the path of LType
            @param {string} LTYPEPath - Path of LType. Ex) 'RequestType[Appointment]/ClassificationType' or 'RequestType'
            @return {Array}, an item looks like below
            {
                ACTIVE: "1"
                DISPORDER: ""
                ID: "36"
                LABEL: "AD - Administratively Determined"
                LTYPE: "PayPlan"
                NAME: "AD"
                PARENTID: "0"
            }
        */
        // If LTYPEPath contains '/' as a value, not LTYPE Seperator, then '/' should be decorated as '*/*'
        // '*/*' will be translated to '/' after separating paths.
        function findByLTYPE(LTYPEPath) {
            if (_jsonObject == null) {
                FormLog.log(FormLog.LOG_LEVEL.ERROR, 'LookupManager::findByLTYPE() - LookupManager is not initialized. Call LookupManager.init() first');
                return null;
            }
            var translatedLTYPEPath = LTYPEPath.split('*/*').join('*_*');
            var paths = translatedLTYPEPath.split('/');
            var translatedPaths = [];
            for (var index = 0; index < paths.length; index++) {
                var newPath = paths[index].split('*_*').join('/');
                translatedPaths.push(newPath);
            }

            var result = _findByLType(_jsonObject.lookup.record, translatedPaths);
            return result;
        }

        function checkForm() {
            if ($(_lookupDataSelector).length !== 0) {
                FormLog.log(FormLog.LOG_LEVEL.ERROR, 'LookupManager::checkForm - Cannot find lookup data - lookupDataSelector ==>', _lookupDataSelector);
            }
        }

        checkForm();

        return {
            findByID: findByID,
            findByLTYPE: findByLTYPE,
            init: init,
            initWithXML: initWithXML
        }
    };

    var _initializer = window.LookupManager || (window.LookupManager = LookupManager());
})(window);

