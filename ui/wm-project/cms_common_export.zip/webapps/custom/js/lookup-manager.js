'use strict';

function LookupManagerException(message) {
    this.message = message;
    this.name = 'LookupManager Exception';
}

(function (window) {
    var LookupManager = function () {
        var _x2js = new X2JS();
        var _lookupDataSelector;
        var _tree;

        function _generateHierarchy( array, parent, tree ){

            tree = typeof tree !== 'undefined' ? tree : [];
            parent = typeof parent !== 'undefined' ? parent : { ID: '0' };

            var children = _.filter( array, function(child){ return child.PARENTID == parent.ID; });

            if( !_.isEmpty( children )  ){
                if( parent.ID == '0' ){
                    tree = children;
                }else{
                    parent['children'] = children;
                }
                _.each( children, function( child ){ _generateHierarchy( array, child ) } );
            }
            else {
                parent['children'] = [];
            }

            return tree;
        }

        function init(lookupDataSelector_) {
            _lookupDataSelector = lookupDataSelector_ || '#h_lookupXMLString';
            if (_tree == null) {
                var lookupXML = $(_lookupDataSelector).val();
                if (lookupXML == null || lookupXML.length === 0) {
                    FormLog.log(FormLog.LOG_LEVEL.ERROR, 'LookupManager::init - no lookup items found from the form - lookupDataSelector ==>', _lookupDataSelector);
                    throw new LookupManagerException("No lookup items found");
                } else {
                    $(_lookupDataSelector).val('');
                }
                var _jsonObject = _x2js.xml_str2json(lookupXML);
                if (undefined === _jsonObject.lookup.record || null == _jsonObject.lookup.record) {
                    FormLog.log(FormLog.LOG_LEVEL.ERROR, 'LookupManager::init - no lookup items found from the form - lookupJsonObject ==>', _jsonObject);
                    var msg = "No lookup items found";
                    if (_jsonObject.lookup.status && _jsonObject.lookup.status.message) {
                        msg += " - " + _jsonObject.lookup.status.message;
                    }
                    throw new LookupManagerException(msg);
                }
                var items = _jsonObject.lookup.record;
                _tree = _generateHierarchy(items);
            } else {
                FormLog.log(FormLog.LOG_LEVEL.INFO, 'LookupManager::init - Already initialized.');
            }
        }

        function _findByID(items, ID) {
            if (items != null) {
                var len = items.length;
                for (var index = 0; index < len; index++) {
                    var item = items[index];
                    if (item.ID === ID) {
                        return item;
                    }

                    if (item.children != null && item.children.length > 0) {
                        var foundItem = _findByID(item.children, ID);
                        if (foundItem != null) {
                            return foundItem;
                        }
                    }
                }
                return null;
            }
        }

        function findByID(ID) {
            if (_tree == null) {
                FormLog.log(FormLog.LOG_LEVEL.ERROR, 'LookupManager::findByID - LookupManager is not initialized. Call LookupManager.init() first');
                return null;
            }
            return _findByID(_tree, ID);
        }

        function _findByLType(items, pathArray) {
            if (undefined === items || items === null || items.length === null || pathArray === null || pathArray.length === 0) {
                return null;
            }

            var targetPath = null;
            var targetLabel = null;
            var path = pathArray[0];
            var startIndex = path.indexOf('[');
            if (startIndex === -1) {
                targetPath = pathArray[0];
                targetLabel = null;
            } else {
                targetPath = path.substring(0, startIndex);
                targetLabel = path.substring(startIndex + 1, path.length - 1);
            }


            var foundItems = [];
            var len = items.length;
            for (var index = 0; index < len; index++) {
                var item = items[index];
                if (item.LTYPE === targetPath) {
                    if (targetLabel != null) {
                        if (item.LABEL !== targetLabel) {
                            continue;
                        }
                    }
                    if (pathArray.length === 1) {
                        foundItems.push(item);
                    } else {
                        var pathArrayClone = pathArray.slice();
                        pathArrayClone.splice(0, 1);
                        var foundItemsFromSub = _findByLType(item.children, pathArrayClone);
                        if (foundItemsFromSub != null && foundItemsFromSub.length > 0) {
                            foundItems.push.apply(foundItems, foundItemsFromSub);
                        }
                    }
                }
            }

            return foundItems;
        }

        function findByLTYPE(LTYPEPath) {
            if (_tree == null) {
                FormLog.log(FormLog.LOG_LEVEL.ERROR, 'LookupManager::findByLTYPE() - LookupManager is not initialized. Call LookupManager.init() first');
                return null;
            }

            var savedValue = bfLRU.get(LTYPEPath);

            if(typeof savedValue === 'undefined'){
                var translatedLTYPEPath = LTYPEPath.split('*/*').join('*_*');
                var paths = translatedLTYPEPath.split('/');
                var translatedPaths = [];
                for (var index = 0; index < paths.length; index++) {
                    var newPath = paths[index].split('*_*').join('/');
                    translatedPaths.push(newPath);
                }

                savedValue = _findByLType(_tree, translatedPaths);
                bfLRU.set(LTYPEPath, savedValue);
            }

            return savedValue;
        }

        function checkForm() {
            if ($(_lookupDataSelector).length !== 0) {
                FormLog.log(FormLog.LOG_LEVEL.ERROR, 'LookupManager::checkForm - Cannot find lookup data - lookupDataSelector ==>', _lookupDataSelector);
            }
        }

        function fillListBox(elementId, lType, keepFirst) {
            var lookupData = findByLTYPE(lType);
            var selObj = $("#" + elementId);

            if (undefined === keepFirst || keepFirst) {
                selObj.children('option:not(:first)').remove();
            } else {
                selObj.children('option').remove();
            }

            if (lookupData.length > 0) {
                for (var i = 0; i < lookupData.length; i++) {
                    var item = lookupData[i];
                    if (item) {
                        selObj.append($("<option></option>").attr("value", item.NAME).text(item.LABEL));
                    }
                }
            }
        }

        checkForm();

        return {
            fillListBox: fillListBox,
            findByID: findByID,
            findByLTYPE: findByLTYPE,
            init: init
        }
    };

    var _initializer = window.LookupManager || (window.LookupManager = LookupManager());
})(window);

(function (window) {

    var bfLRU = function() {
        var size = 0;
        var limit = 20;
        var map = {};
        var head = null;
        var tail = null;

        function setLimit(length){
            (typeof length == "number") ? limit = length : limit = 20;
        }

        function lrunode(key, value) {
            if (typeof key != "undefined" && key !== null) {
                this.key = key;
            }
            if (typeof value != "undefined" && value !== null) {
                this.value = value;
            }
            this.prev = null;
            this.next = null;
        }

        function setHead(node) {
            node.next = head;
            node.prev = null;
            if (head !== null) {
                head.prev = node;
            }
            head = node;
            if (tail === null) {
                tail = node;
            }
            size++;
            map[node.key] = node;
        }

        function set(key, value) {
            var node = new lrunode(key, value);
            if (map[key]) {
                map[key].value = node.value;
                remove(node.key);
            } else {
                if (size >= limit) {
                    delete map[tail.key];
                    size--;
                    tail = tail.prev;
                    tail.next = null;
                }
            }
            setHead(node);
        }

        function get(key) {
            if (map[key]) {
                var value = map[key].value;
                var node = new lrunode(key, value);
                remove(key);
                setHead(node);
                return value;
            } else {
                console.log("Key " + key + " does not exist in the cache.")
            }
        }

        function remove(key) {
            var node = map[key];
            if (node.prev !== null) {
                node.prev.next = node.next;
            } else {
                head = node.next;
            }
            if (node.next !== null) {
                node.next.prev = node.prev;
            } else {
                tail = node.prev;
            }
            delete map[key];
            size--;
        }

        return {
            set: set,
            get: get,
            setLimit: setLimit
        }
    }

    var _initializer = window.bfLRU || (window.bfLRU = bfLRU());
})(window);
