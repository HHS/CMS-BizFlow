(function (window, document) {
    'use strict';

    function FormRequire() {
        var options = undefined;
        var version = undefined;

        function getOptions() {
            options = [];
            var scripts = document.getElementsByTagName("script");
            for (var i = 0; i < scripts.length; i++) {
                var script = scripts[i];
                var src = script.getAttribute("src");
                if (null != src) {
                    var str = "form-require.js?";
                    var idx = src.indexOf(str);
                    if (-1 != idx) {
                        var paramStr = src.substring(idx + str.length);
                        var params = paramStr.split('&');
                        for (var p = 0; p < params.length; p++) {
                            var paramKeyVal = params[p].split('=');
                            if (paramKeyVal.length == 2) {
                                var name = paramKeyVal[0];
                                options[name] = decodeURIComponent(paramKeyVal[1].replace(/\+/g, " "));
                            }
                        }
                        break;
                    }
                }
            }
        }

        function getAppVersion(defaultVersion) {
            var ver = defaultVersion;
            if ('undefined' != typeof Form$Version$) {
                ver = Form$Version$.version;
            }

            return ver;
        }

        this.detectVersion = function () {
            if (undefined == options) {
                getOptions();
            }
            version = getAppVersion(options["v"]);
            return version;
        };
        this.getVersion = function (alwaysNew) {
            if ('undefined' == typeof alwaysNew || false == alwaysNew) {
                if (undefined == version) {
                    this.detectVersion();
                }
                return version;
            } else {
                return (new Date()).getTime();
            }
        };
        this.getContextPath = function () {
            var loc = location;
            var offset = loc.href.indexOf(loc.host) + loc.host.length;
            var idx = loc.href.indexOf('/', offset + 1);
            if (-1 == idx) idx = loc.href.length;
            return loc.href.substring(offset, idx);
        };
        this.makeVersionUrl = function (url, alwaysNew) {
            var ver = this.getVersion(alwaysNew);
            if (null != ver && undefined != ver) {
                var prefix = "&";
                var idx = url.indexOf("?");
                if (-1 == idx) {
                    prefix = "?";
                }
                url += prefix + "v=" + ver;
            }

            return url;
        };

        function linkHtml(href) {
            return '<link rel="stylesheet" href="' + href + '"/>';
        }

        function scriptHtml(src) {
            return '<script src="' + src + '"><\/script>';
        }

        function writeBase(base) {
            document.write('<base href="' + base + '/" />');
        }

        function writeLink(href) {
            document.write(linkHtml(href));
        }

        function writeScript(src) {
            document.write(scriptHtml(src));
        }

        this.baseHref = function () {
            writeBase(this.getContextPath());
        };
        this.link = function (css, alwaysNew) {
            writeLink(this.makeVersionUrl(css, alwaysNew));
        };
        this.script = function (js, alwaysNew) {
            writeScript(this.makeVersionUrl(js, alwaysNew));
        };
        this.linkWithoutVersion = function (css) {
            writeLink(css);
        };
        this.scriptWithoutVersion = function (js) {
            writeScript(js);
        };
        this.appendLink = function (css) {
            var link = document.createElement("link");
            link.href = this.makeVersionUrl(css);
            link.rel = 'stylesheet';
            document.getElementsByTagName("head")[0].appendChild(link);
        };
        this.appendScript = function (js) {
            var ss = document.createElement("script");
            ss.src = this.makeVersionUrl(js);
            document.getElementsByTagName("head")[0].appendChild(ss);
        };
        this.loadScripts = function (info) {
            for (var i = 0; i < info.length; i++) {
                if (info[i].javaScripts) {
                    var scripts = info[i].javaScripts;
                    FormLog.log(FormLog.LOG_LEVEL.DEBUG, "FormRequire::loadScripts - Loading scripts ==>", scripts);
                    for (var j = 0; j < scripts.length; j++) {
                        var url = this.getContextPath() + scripts[j];
                        FormLog.log(FormLog.LOG_LEVEL.DEBUG, "FormRequire::loadScripts - Loading script ==>", url);
                        this.scriptWithoutVersion(url);
                    }
                }
            }
        };
        this.loadCssFiles= function (info) {
            for (var i = 0; i < info.length; i++) {
                if (info[i].cssFiles) {
                    var cssFiles = info[i].cssFiles;
                    FormLog.log(FormLog.LOG_LEVEL.DEBUG, "FormRequire::loadCssFiles - Loading css files ==>", cssFiles);
                    for (var j = 0; j < cssFiles.length; j++) {
                        var url = this.getContextPath() + cssFiles[j];
                        FormLog.log(FormLog.LOG_LEVEL.DEBUG, "FormRequire::loadCssFiles - Loading css file ==>", url);
                        this.linkWithoutVersion(url);
                    }
                }
            }
        }
    }

    var _initializer = window.FormRequire || (window.FormRequire = new FormRequire());
})(window, document);