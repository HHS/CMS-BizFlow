'use strict';

function UserGroupManager(name_) {
    var _name = name_ || "UserGroupManager";
    var _userGroups;
    var _userGroupMapping = {};
    var _x2js = null;

    function initUserGroup(userGroupString) {
        if (userGroupString) {
            _userGroups = _x2js.xml_str2json(userGroupString);
        } else {
            _userGroups = {UserGroups: {}};
        }

        if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, _name + "::initUserGroupMapping - userGroups ==> ", _userGroups);
    }

    function initUserGroupMapping(userGroupMappingString) {
        if (userGroupMappingString) {
            var userGroupMapping = _x2js.xml_str2json(userGroupMappingString);
            if (userGroupMapping && userGroupMapping.userGroupMapping) {
                _userGroupMapping = FormUtility.arrayToObjects(userGroupMapping.userGroupMapping.record, "KEY");
            }
        }
        if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, _name + "::initUserGroupMapping - userGroupMapping ==> ", _userGroupMapping);
    }

    this.getCurrentUserGroupName = function (userGroupName) {
        var name = userGroupName;
        var ug = _userGroupMapping[userGroupName];
        if (ug) {
            name = ug.NAME;
        }

        return name || userGroupName;
    };

    this.isUserMemberOf = function (userGroupName) {
        var rc = false;
        var currentUserGroupName = this.getCurrentUserGroupName(userGroupName);
        if (_userGroups && _userGroups.UserGroups && _userGroups.UserGroups.UserGroup) {
            var foundGroups = _userGroups.UserGroups.UserGroup.filter(function (node, index) {
                return node.Name == currentUserGroupName
            });
            rc = foundGroups.length > 0;
        }
        if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, _name + "::isUserMemberOf - userGroupName, CurrentUserGroupName, isMember? ==> ", userGroupName, currentUserGroupName, rc);
        return rc;
    };

    this.init = function (userGroupString, userGroupMappingString) {
        _x2js = new X2JS();
        initUserGroup(userGroupString);
        initUserGroupMapping(userGroupMappingString);
        _x2js = null;
    };
}

(function (window) {
    var _initializer = window.MyUserGroupManager || (window.MyUserGroupManager = new UserGroupManager('MyUserGroupManager'));
})(window);