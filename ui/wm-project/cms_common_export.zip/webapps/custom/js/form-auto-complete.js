(function (window) {
    'use strict';

    var FormAutoComplete = function () {
        /**
         * using a generic function to handle all autocomplete features is better practice, than repeating same logic all over the place for different autocomplete controls
         * @param id keys represent the keys to be extracted from ajax response
         * @param url url represents the endpoint for the ajax call, eg : /bizflowwebmaker/someAutocompleteProject/somePartialPage.do'
         * @param selectionCallBack a function that is called when an item is selected; It is called with two parameters item and id
         * @param responseProcessor a function that is called when an ajax call to get data is done. It is called with a parameter xmlResponse
         * @param appender
         */
        function setAutoComplete(id, url, selectionCallBack, responseProcessor, appender) {
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'FormAutoComplete::setAutoComplete - id, url ==>', id, url);
            if (id != undefined && url != undefined) {
                //var arrCopy = keys.slice();
                $('#' + id).autocomplete({
                    source: function (request, response) {
                        $.ajax({
                            url: url + $('#' + id).val(),
                            dataType: 'xml',
                            cache: false,
                            success: function (xmlResponse) {
                                var data = responseProcessor(xmlResponse);
                                response(data);
                            }
                        });
                    },
                    minLength: 2,
                    change: function (e, u) {
                        var pos = $(this).position();
                        if (u.item == null) {
                            $(this).val('');
                            return false;
                        }
                    },
                    select: function (event, ui) {
                        event.preventDefault();
                        //call a function passing in the selected item
                        selectionCallBack(ui.item, id);
                    },
                    open: function () {
                        $('.ui-autocomplete').css('z-index', 5000);
                    },
                    close: function () {
                        $('.ui-autocomplete').css('z-index', 1);
                    }
                }).autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
                    ul.attr('role', 'listbox');
                    var el = '' + appender(item);
                    return $('<li>')
                        .append(el)
                        .appendTo(ul);
                };
            }
        }

        function makeAutoCompletion(option) {
            if (option == null) {
                FormLog.log(FormLog.LOG_LEVEL.ERROR, 'FormAutoComplete::initAutoCompletion - Invalid option. Option is null.');
                return;
            }
            if (option.id == null || typeof option.id !== 'string') {
                FormLog.log(FormLog.LOG_LEVEL.ERROR, 'FormAutoComplete::initAutoCompletion - Invalid option. option.id should be string ==> ', option);
                return;
            }
            if (option.mapFunction == null || typeof option.mapFunction !== 'function') {
                FormLog.log(FormLog.LOG_LEVEL.ERROR, 'FormAutoComplete::initAutoCompletion - Invalid option. option.mapFunction is required and mandatory ==> ', option);
                return;
            }
            if (option.getItemID == null || typeof option.getItemID !== 'function') {
                FormLog.log(FormLog.LOG_LEVEL.ERROR, 'FormAutoComplete::initAutoCompletion - Invalid option. option.getItemID is required and mandatory ==> ', option);
                return;
            }
            if (option.getSelectionLabel == null || typeof option.getSelectionLabel !== 'function') {
                FormLog.log(FormLog.LOG_LEVEL.ERROR, 'FormAutoComplete::initAutoCompletion - Invalid option. option.getSelectionLabel is required and mandatory ==> ', option);
                return;
            }
            if (option.getCandidateLabel == null || typeof option.getCandidateLabel !== 'function') {
                FormLog.log(FormLog.LOG_LEVEL.ERROR, 'FormAutoComplete::initAutoCompletion - Invalid option. option.getCandidateLabel is required and mandatory ==> ', option);
                return;
            }
            if (option.setDataToForm == null || typeof option.setDataToForm !== 'function') {
                FormLog.log(FormLog.LOG_LEVEL.ERROR, 'FormAutoComplete::initAutoCompletion - Invalid option. option.setDataToForm is required and mandatory ==> ', option);
                return;
            }

            var _option = option;
            var _baseURL = _option.baseURL || '';
            var _inputID = _option.id;
            var _listElementID = _inputID + '_LIST';
            var _noMatchElementID = _inputID + '_NOMATCH';
            var _selectedElementID = _inputID + '_DISP';
            var _inputContainer = _inputID + '_container';
            var _selectedValues = [];

            _option.minSelectionCount = undefined !== _option.minSelectionCount ? _option.minSelectionCount : 1;
            _option.maxSelectionCount = undefined !== _option.maxSelectionCount ? _option.maxSelectionCount : 1;

            var footerHTML = '<div class="customControl"><ul class="hidden nobullet autocomplete_ul" id="___UL___" /></div><div id="___LIST___"></div>';
            footerHTML = footerHTML.replace('___LIST___', _listElementID);
            footerHTML = footerHTML.replace('___UL___', _selectedElementID);
            $('#' + _inputContainer).parent().parent().append(footerHTML);

            function getListItemHTML(targetID, targetLabel, tabIndex, containerId) {
                var elementString = "";
                if (FormUtility.isReadOnly() == true) {
                    elementString = '<li id="' + targetID + '">' + targetLabel + '</li>';
                } else {
                    elementString = "<li id=\"" + targetID + "\"><img src=\"" + _baseURL + "/custom/images/delete-icon.png"
                        + "\" id=\"delete-" + targetID + "\" deleteId=\"" + targetID + "\" containerId =\"" + containerId
                        + "\" title=\"Remove " + targetLabel + "\" tabindex=\"" + tabIndex + "\" />" + targetLabel + "</li>";
                }
                return elementString;
            }

            function sortSelectedValues() {
                if (_selectedValues && _selectedValues.length > 1) {
                    if (_option.compare != null && typeof _option.compare === 'function') {
                        _selectedValues.sort(_option.compare);
                    } else {
                        _selectedValues.sort(function (a, b) {
                            return _option.getSelectionLabel(a) > _option.getSelectionLabel(b);
                        });
                    }
                }
            }

            function setDataToForm(deletedItem) {
                _option.setDataToForm(_selectedValues, deletedItem);
            }

            function getItemIndex(itemId) {
                var itemIndex = -1;

                for (var valueIndex = 0; valueIndex < _selectedValues.length; valueIndex++) {
                    var id = _option.getItemID(_selectedValues[valueIndex]);
                    if (id === itemId) {
                        itemIndex = valueIndex;
                        break;
                    }
                }

                return itemIndex;
            }

            function processSelectData(event, ui, saveData) {
                var id = _option.getItemID(ui.item);
                var itemIndex = getItemIndex(id);

                if (-1 == itemIndex) {
                    var count = _selectedValues.length;
                    if (_option.getDisplayItemContainerId) {
                        if (_option.beforeDisplayItems) {
                            _option.beforeDisplayItems(_selectedValues);
                        }
                    } else if (count > 0) {
                        $('#' + _selectedElementID + ' li').each(function () {
                            $(this).remove();
                        })
                    }

                    _selectedValues.push(ui.item);
                    count = _selectedValues.length;
                    sortSelectedValues();

                    // Display
                    for (var index = 0; index < count; index++) {
                        var item = _selectedValues[index];
                        var containerId = _option.getDisplayItemContainerId ? _option.getDisplayItemContainerId(index) : _selectedElementID;
                        var itemID = _option.getItemID(item);
                        var itemLabel = _option.getSelectionLabel(item);
                        var listItemHTML = getListItemHTML(itemID, itemLabel, _option.tabindex, containerId);
                        $('#' + containerId).append(listItemHTML);
                        if (_option.getDisplayItemContainerId && _option.afterDisplayItem) {
                            _option.afterDisplayItem(containerId, item);
                        }
                    }

                    if (_option.getDisplayItemContainerId) {
                        if (_option.afterDisplayItems) {
                            _option.afterDisplayItems(_selectedValues);
                        }
                    } else {
                        $('#' + _selectedElementID).removeClass('hidden');
                    }

                    // Call form to save selected values
                    if (saveData) {
                        setDataToForm();
                    }

                    if (count >= _option.maxSelectionCount) {
                        $('#' + _inputContainer).addClass('hidden');
                    }
                    if (count >= _option.minSelectionCount) {
                        $('#' + _inputID).attr('_required', 'false');
                        hyf.validation.validateField(_inputID, true);
                    }

                    // Remove candidate
                    $('#' + _listElementID + ' ul li').each(function () {
                        $(this).remove();
                    });
                }
            }

            function select(event, ui) {
                processSelectData(event, ui, true);
            }

            function initializeItems(initialItems_) {
                if (initialItems_) {
                    deleteAllItems();
                    _option.initialItems = initialItems_;
                }
                if (_option.initialItems && typeof _option.initialItems === 'object') {
                    var count = _option.initialItems.length;

                    for (var index = 0; index < count; index++) {
                        var ui = {};
                        ui.item = _option.initialItems[index];

                        var isEmpty = true;
                        for (var key in ui.item) {
                            if (ui.item.hasOwnProperty(key)) {
                                var data = ui.item[key];
                                if (typeof data == 'string' && data.length > 0) {
                                    isEmpty = false;
                                    break;
                                }
                            }
                        }
                        if (isEmpty != true) {
                            processSelectData(null, ui, false);
                        }
                    }
                }
            }

            function deleteItemByIndex(itemIndex, targetId, containerId) {
                if (itemIndex > -1) {
                    var item = _selectedValues[itemIndex];
                    containerId = containerId || _selectedElementID;
                    targetId = targetId || _option.getItemID(item);
                    _selectedValues.splice(itemIndex, 1);

                    $('#' + containerId + ' li[id="' + targetId + '"]').remove();

                    // Call form to save selected values
                    setDataToForm(item);

                    var count = _selectedValues.length;
                    if (_option.getDisplayItemContainerId) {
                        if (_option.afterDeleteDisplayItem) {
                            _option.afterDeleteDisplayItem(containerId, targetId, item);
                        }
                    } else if (count == 0) {
                        $('#' + containerId).addClass('hidden').empty();
                    }

                    $('#' + _inputContainer).removeClass('hidden');

                    if (_option.minSelectionCount > 0 && count < _option.minSelectionCount) {
                        $('#' + _inputID).attr('_required', 'true');
                    }
                }
            }

            function deleteItem(targetId, containerId) {
                deleteItemByIndex(getItemIndex(targetId), targetId, containerId);
            }

            function deleteItemByEvent(e) {
                e = e || window.event;
                if (e.type == 'click' || (e.type == 'keyup' && (e.key == ' ' || e.key == 'Enter'))) {
                    var target = $(e.currentTarget);
                    var containerId = target.attr('containerId');
                    deleteItem(target.attr('deleteid'), containerId);
                    if (_option.postDelete && typeof _option.postDelete === 'function') {
                        _option.postDelete(e, _selectedValues, target, containerId);
                    }
                }
            }

            function deleteAllItems() {
                var count = _selectedValues.length;
                for (var i = 0; i < count; i++) {
                    deleteItemByIndex(0);
                }
            }

            function getItem(id) {
                var item;
                var idx = getItemIndex(id);
                if (idx > -1) {
                    item = _selectedValues[idx];
                }

                return item;
            }

            function updateItem(id, item) {
                var idx = getItemIndex(id);
                if (idx > -1) {
                    _selectedValues[idx] = item;
                }
            }

            $('#' + _inputID).autocomplete({
                appendTo: '#' + _listElementID,
                source: function (request, response) {
                    var userInput = request.term;
                    if (typeof _option.targetURL != 'undefined' && _option.targetURL != null && _option.targetURL.length > 0) {
                        var url = _option.targetURL + encodeURIComponent(userInput);
                        FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'FormAutoComplete::initAutoCompletion::autocomplete - url ==>', url);
                        $.ajax({
                            url: url,
                            dataType: "xml",
                            cache: false,
                            success: function (xmlResponse) {
                                var data = $("record", xmlResponse).map(function () {
                                    return _option.mapFunction(this);
                                }).get();
                                response(data);
                            }
                        });
                    } else {
                        // source to statically loaded dropdown field (select input element)
                        FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'srcSelectElemId = ' + _option.srcSelectElemId + '  userInput = ' + userInput);
                        var data = $('#' + _option.srcSelectElemId + ' option')
                            .filter(function () {
                                // filter by matching label (displayed value) of each drop down option against user input
                                var itemLabel = $(this).text();
                                if (typeof itemLabel == 'undefined' || itemLabel == null || itemLabel.length <= 0) {
                                    return false;
                                }
                                return itemLabel.toUpperCase().indexOf(userInput) >= 0;
                            })
                            .map(function () {
                                return _option.mapFunction(this);
                            })
                            .get();
                        response(data);
                    }
                },
                minLength: _option.minLength || 2,
                change: function (event, ui) {
                    if (!_option.changeFunction || typeof _option.changeFunction !== 'function') {
                        //If the No match found" u.item will return null, clear the TextBox.
                        if (ui.item == null) {
                            //Clear the AutoComplete TextBox.
                            var pos = $(this).position();
                            $('#' + _noMatchElementID).remove();

                            var errorMessage = 'Invalid Selection:<br />Item must be selected from the available options.';
                            if (_option.validationMessage && _option.validationMessage.length > 0) {
                                errorMessage = _option.validationMessage;
                            }

                            var noMatchClass = 'acNoMatch';
                            if (_option.noMatchClass && _option.noMatchClass.length > 0) {
                                noMatchClass = _option.noMatchClass;
                            }
                            $(this).after('<span id="' + _noMatchElementID + '" class="' + noMatchClass + '">' + errorMessage + '</span>');

                            $('#' + _noMatchElementID).css({top: pos.top + 20, left: pos.left + 30, position: 'absolute'});
                            setTimeout(function () {
                                $('#' + _noMatchElementID).remove();
                            }, 2000);

                            $('#' + _inputID).val("");
                            $('#' + _inputID).trigger('keydown');
                            $(this).autocomplete('close');
                        }
                    } else {
                        _option.changeFunction(e, u);
                    }
                },
                select: function (event, ui) {
                    select(event, ui);
                    if (_option.postSelect && typeof _option.postSelect === 'function') {
                        _option.postSelect(event, ui, _selectedValues);
                    }
                    // clear the search textbox once selection is made
                    this.value = '';
                    return false;
                },
                open: function () {
                    $(".ui-autocomplete").css("z-index", 5000);
                },
                close: function () {
                    $(".ui-autocomplete").css("z-index", 1);
                }
            })
                .autocomplete().data("ui-autocomplete")._renderItem = function (ul, item) {
                var itemLabel = _option.getCandidateLabel(item);
                itemLabel = '<a>' + itemLabel + '</a>';
                return $("<li>").append(itemLabel).appendTo(ul);
            };

            if (FormUtility.isReadOnly() == false) {
                $('#' + _selectedElementID).delegate("img", "click keyup", deleteItemByEvent);
            }

            initializeItems();

            if (FormUtility.isReadOnly() == true) {
                $('#' + _inputContainer).addClass('hidden');
            }

            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'AutoCompletion is initialized!! - ' + _option.id);
            return {
                option: _option,
                baseURL: _baseURL,

                inputID: _inputID,
                listElementID: _listElementID,
                noMatchElementID: _noMatchElementID,
                selectedElementID: _selectedElementID,
                inputContainer: _inputContainer,

                selectedValues: _selectedValues,

                initializeItems: initializeItems,
                select: select,
                deleteItemByIndex: deleteItemByIndex,
                deleteAllItems: deleteAllItems,
                deleteItem: deleteItem,
                deleteItemByEvent: deleteItemByEvent,
                getItem: getItem,
                updateItem: updateItem
            }
        }

        return {
            setAutoComplete: setAutoComplete,
            makeAutoCompletion: makeAutoCompletion
        }
    };

    var _initializer = window.FormAutoComplete || (window.FormAutoComplete = FormAutoComplete());
})(window);

