(function (window) {
	var cms_incentives_pdp_review = function () {
        var _readOnly = false;
        var _initialized = false;

        function setReviewerAndReviewDate(reviewerEleId, reviewDateEleId, checked) {
            var currentUserName = "";
            var currentUserId = "";
            var currentDate = "";
            if (checked) {
                currentUserName = myInfo.getMyName();
                currentUserId = myInfo.getMyMemberId();
                currentDate = FormUtility.getDateString(false, "mm/dd/yyyy", new Date());
            }

            $("#" + reviewerEleId).val(currentUserName);
            $("#" + reviewDateEleId).val(currentDate);

            FormState.updateTextValue(reviewerEleId, currentUserName, false);
            FormState.updateTextValue(reviewerEleId + "Id", currentUserId, false);
            FormState.updateDateValue(reviewDateEleId, currentDate, false);
        }

        function initEventHandlers() {
            $('#pdp_reviewSOCheck').on('change', function (e) {
                var target = e.target;
                setReviewerAndReviewDate("pdp_reviewSO", "pdp_reviewSODate", target.checked);
            });
        }

        function setSignUsability() {
			var isSO = accessControl.isDesignatedSO();
			if ((activityStep.isStartNew() && myInfo.isSO()) ||
				((activityStep.isSOReview() || activityStep.isSOReviewForModification()) && isSO)) {
				hyf.util.setComponentUsability("pdp_reviewSOCheck", true);
				hyf.util.setMandatoryConstraint("pdp_reviewSOCheck", true);
			}
			else if (activityStep.isStartNew() && !myInfo.isSO()) {
				hyf.util.setComponentUsability("pdp_reviewSOCheck", false);
				hyf.util.setMandatoryConstraint("pdp_reviewSOCheck", false);	
			}
			if (activityStep.isHR_REVIEW_APPROVAL() && myInfo.isINCENTIVEHRS()) {
				hyf.util.setComponentUsability("pdp_reviewSOCheck", false);
				hyf.util.setMandatoryConstraint("pdp_reviewSOCheck", false);	
				hyf.util.enableComponent("pdp_reviewDGODate");
				hyf.util.enableComponent("pdp_reviewCPDate");
				hyf.util.enableComponent("pdp_reviewOFMDate");
				hyf.util.enableComponent("pdp_reviewTABGDate");
				hyf.util.enableComponent("pdp_reviewOHCDate");

				hyf.util.setMandatoryConstraint("pdp_reviewDGODate", true);
				hyf.util.setMandatoryConstraint("pdp_reviewCPDate", true);
				hyf.util.setMandatoryConstraint("pdp_reviewOFMDate", true);
				hyf.util.setMandatoryConstraint("pdp_reviewTABGDate", true);
				hyf.util.setMandatoryConstraint("pdp_reviewOHCDate", true);

				hyf.calendar.setDateConstraint("pdp_reviewDGODate", 'Maximum', 'Today');
				hyf.calendar.setDateConstraint("pdp_reviewCPDate", 'Maximum', 'Today');
                hyf.calendar.setDateConstraint("pdp_reviewOFMDate", 'Maximum', 'Today');
                hyf.calendar.setDateConstraint("pdp_reviewTABGDate", 'Maximum', 'Today');
                hyf.calendar.setDateConstraint("pdp_reviewOHCDate", 'Maximum', 'Today');
			}

        }

		function setSignClear() {
            if (_initialized) {
				$( "#pdp_reviewSOCheck" ).prop( "checked", false);
				FormState.updateCheckboxValue('pdp_reviewSOCheck', false, false, '') 
				setReviewerAndReviewDate("pdp_reviewSO", "pdp_reviewSODate", false);
            }
        }

        function initComponents() {
            hyf.util.disableComponent("pdp_reviewSODate");
            hyf.util.disableComponent("pdp_reviewDGODate");
            hyf.util.disableComponent("pdp_reviewCPDate");
            hyf.util.disableComponent("pdp_reviewOFMDate");
            hyf.util.disableComponent("pdp_reviewTABGDate");
            hyf.util.disableComponent("pdp_reviewOHCDate");

            setSignUsability();
            setSignClear();
            
        }

        function init(readOnly, tabObject) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();
            FormMain.resetMandatoryMark(tabObject);

            _initialized = true;
        }

        function render(action) {
        }

        return {
            init: init
            , render: render
            , setSignClear: setSignClear
        }
    };

    var _initializer = window.cms_incentives_pdp_review || (window.cms_incentives_pdp_review = cms_incentives_pdp_review());
})(window);
