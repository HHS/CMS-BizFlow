var eligQualSel = {
	
	getSelectionFlag: function(){
		var selectionFlag = null;
		var result = 'No';
		
		selectionFlag = $('#SEL_DETERM option:selected').text();
		if (selectionFlag == 'Selected'){
			result = 'Yes';
		} 
		
		return result;
	},
	
	init: function(){
	
	}
}