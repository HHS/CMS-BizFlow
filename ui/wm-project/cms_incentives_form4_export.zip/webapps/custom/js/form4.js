(function (window) {
    var cms_incentives_pca_review = function () {
        var _readOnly = false;
        var _initialized = false;

        function setVisibilityAsRequireAdminApproval(requireAdminApproval) {
            var isRequireAdminApproval = "Yes" === requireAdminApproval;

            FormMain.setComponentVisibility("reviewTABGCheck_group", isRequireAdminApproval);
            FormMain.setComponentVisibility("reviewOHCCheck_group", isRequireAdminApproval);

			if(!isRequireAdminApproval) {
				$('#reviewTABGDate').val('');
				FormState.updateTextValue("reviewTABGDate", "", true);
				$('#reviewOHCDate').val('');
				FormState.updateTextValue("reviewOHCDate", "", true);
			}
        }

        function onRequireAdminApprovalChanged(requireAdminApproval) {
            setVisibilityAsRequireAdminApproval(requireAdminApproval);
        }

        function setReviewerAndReviewDate(reviewerEleId, reviewDateEleId, checked) {
            var currentUserName = "";
            var currentUserId = "";
            var currentDate = "";
            if (checked) {
                currentUserName = myInfo.getMyName();
                currentUserId = myInfo.getMyMemberId();
                currentDate = FormUtility.getDateString(false, "mm/dd/yyyy", new Date());
            }

            $("#" + reviewerEleId).val(currentUserName);
            $("#" + reviewDateEleId).val(currentDate);

            FormState.updateTextValue(reviewerEleId, currentUserName, false);
            FormState.updateTextValue(reviewerEleId + "Id", currentUserId, false);
            FormState.updateDateValue(reviewDateEleId, currentDate, false);
        }

        function initEventHandlers() {
            $('#reviewSOCheck').on('change', function (e) {
                var target = e.target;
                setReviewerAndReviewDate("reviewSO", "reviewSODate", target.checked);
            });
			/* no longer using
            $('#reviewDGOCheck').on('change', function (e) {
                var target = e.target;
                setReviewerAndReviewDate("reviewDGO", "reviewDGODate", target.checked);
            });
            $('#reviewCPCheck').on('change', function (e) {
                var target = e.target;
                setReviewerAndReviewDate("reviewCP", "reviewCPDate", target.checked);
            });
            $('#reviewOFMCheck').on('change', function (e) {
                var target = e.target;
                setReviewerAndReviewDate("reviewOFM", "reviewOFMDate", target.checked);
            });
            $('#reviewTABGCheck').on('change', function (e) {
                var target = e.target;
                setReviewerAndReviewDate("reviewTABG", "reviewTABGDate", target.checked);
            });
            $('#reviewOHCCheck').on('change', function (e) {
                var target = e.target;
                setReviewerAndReviewDate("reviewOHC", "reviewOHCDate", target.checked);
            });
			*/
        }
		
        function setSignUsability() {
			var isSO = accessControl.isDesignatedSO();
			if ((activityStep.isStartNew() && myInfo.isSO()) ||
				((activityStep.isSOReview() || activityStep.isSOReviewForModification()) && isSO)) {
				hyf.util.setComponentUsability("reviewSOCheck", true);
				hyf.util.setMandatoryConstraint("reviewSOCheck", true);
			}
			else if (activityStep.isStartNew() && !myInfo.isSO()) {
				hyf.util.setComponentUsability("reviewSOCheck", false);
				hyf.util.setMandatoryConstraint("reviewSOCheck", false);	
			}
			if (activityStep.isHR_REVIEW_APPROVAL()) {
				hyf.util.setComponentUsability("reviewSOCheck", false);
				hyf.util.setMandatoryConstraint("reviewSOCheck", false);	
				hyf.util.enableComponent("reviewDGODate");
				hyf.util.enableComponent("reviewCPDate");
				hyf.util.enableComponent("reviewOFMDate");
				hyf.util.enableComponent("reviewTABGDate");
				hyf.util.enableComponent("reviewOHCDate");

				hyf.util.setMandatoryConstraint("reviewDGODate", true);
				hyf.util.setMandatoryConstraint("reviewCPDate", true);
				hyf.util.setMandatoryConstraint("reviewOFMDate", true);
				hyf.util.setMandatoryConstraint("reviewTABGDate", true);
				hyf.util.setMandatoryConstraint("reviewOHCDate", true);

				hyf.calendar.setDateConstraint("reviewDGODate", 'Maximum', 'Today');
				hyf.calendar.setDateConstraint("reviewCPDate", 'Maximum', 'Today');
				hyf.calendar.setDateConstraint("reviewOFMDate", 'Maximum', 'Today');
				hyf.calendar.setDateConstraint("reviewTABGDate", 'Maximum', 'Today');
				hyf.calendar.setDateConstraint("reviewOHCDate", 'Maximum', 'Today');
			}

        }

		function setSignClear() {
            if (_initialized) {
				$( "#reviewSOCheck" ).prop( "checked", false);
				FormState.updateCheckboxValue('reviewSOCheck', false, false, '') 
				setReviewerAndReviewDate("reviewSO", "reviewSODate", false);
            }
        }

        function initComponents() {
            hyf.util.disableComponent("reviewSODate");
            hyf.util.disableComponent("reviewDGODate");
            hyf.util.disableComponent("reviewCPDate");
            hyf.util.disableComponent("reviewOFMDate");
            hyf.util.disableComponent("reviewTABGDate");
            hyf.util.disableComponent("reviewOHCDate");
			
            setSignUsability();
			setSignClear();
        }

        function init(readOnly, tabObject) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();
	
            setVisibilityAsRequireAdminApproval(FormState.getElementValue("requireAdminApproval"));
            FormMain.resetMandatoryMark(tabObject);

            _initialized = true;
        }

        function render(action) {
        }

        return {
            init: init,
            render: render,
			setSignClear: setSignClear,
            onRequireAdminApprovalChanged: onRequireAdminApprovalChanged 
        }
    };

    var _initializer = window.cms_incentives_pca_review || (window.cms_incentives_pca_review = cms_incentives_pca_review());
})(window);
