(function (window) {
    var cms_incentives_pca_review = function () {
        var _readOnly = false;
        var _initialized = false;

        function setVisibilityAsRequireAdminApproval(requireAdminApproval) {
            requireAdminApproval = requireAdminApproval || FormState.getElementValue("requireAdminApproval");
            var isRequireAdminApproval = "Yes" === requireAdminApproval;

            hyf.util.setComponentVisibility("reviewTABGCheck_group", isRequireAdminApproval);
            hyf.util.setComponentVisibility("reviewOHCCheck_group", isRequireAdminApproval);
        }

        function onRequireAdminApprovalChanged(requireAdminApproval) {
            setVisibilityAsRequireAdminApproval(requireAdminApproval);
        }

        function setReviewerAndReviewDate(reviewerEleId, reviewDateEleId, checked) {
            var currentUserName = "";
            var currentUserId = "";
            var currentDate = "";
            if (checked) {
                currentUserName = myInfo.getMyName();
                currentUserId = myInfo.getMyMemberId();
                currentDate = FormUtility.getDateString(false, "mm/dd/yyyy", new Date());
            }

            $("#" + reviewerEleId).val(currentUserName);
            $("#" + reviewDateEleId).val(currentDate);

            FormState.updateTextValue(reviewerEleId, currentUserName, false);
            FormState.updateTextValue(reviewerEleId + "Id", currentUserId, false);
            FormState.updateDateValue(reviewDateEleId, currentDate, false);
        }

        function initEventHandlers() {
            $('#reviewSOCheck').on('change', function (e) {
                var target = e.target;
                setReviewerAndReviewDate("reviewSO", "reviewSODate", target.checked);
            });
            $('#reviewDGOCheck').on('change', function (e) {
                var target = e.target;
                setReviewerAndReviewDate("reviewDGO", "reviewDGODate", target.checked);
            });
            $('#reviewCPCheck').on('change', function (e) {
                var target = e.target;
                setReviewerAndReviewDate("reviewCP", "reviewCPDate", target.checked);
            });
            $('#reviewOFMCheck').on('change', function (e) {
                var target = e.target;
                setReviewerAndReviewDate("reviewOFM", "reviewOFMDate", target.checked);
            });
            $('#reviewTABGCheck').on('change', function (e) {
                var target = e.target;
                setReviewerAndReviewDate("reviewTABG", "reviewTABGDate", target.checked);
            });
            $('#reviewOHCCheck').on('change', function (e) {
                var target = e.target;
                setReviewerAndReviewDate("reviewOHC", "reviewOHCDate", target.checked);
            });
        }

        function setSignUsability() {
            var isSO = accessControl.isDesignatedSO();
            hyf.util.setComponentUsability("reviewSOCheck", isSO);
            hyf.util.setMandatoryConstraint("reviewSOCheck", isSO);

            var isDGO = accessControl.isDesignatedDGHO();
            hyf.util.setComponentUsability("reviewDGOCheck", isDGO);
            hyf.util.setMandatoryConstraint("reviewDGOCheck", isDGO);

            var isCP = accessControl.isDesignatedCP();
            hyf.util.setComponentUsability("reviewCPCheck", isCP);
            hyf.util.setMandatoryConstraint("reviewCPCheck", isCP);

            var isOFM = accessControl.isDesignatedOFM();
            hyf.util.setComponentUsability("reviewOFMCheck", isOFM);
            hyf.util.setMandatoryConstraint("reviewOFMCheck", isOFM);

            var isTABG = accessControl.isDesignatedTABG();
            hyf.util.setComponentUsability("reviewTABGCheck", isTABG);
            hyf.util.setMandatoryConstraint("reviewTABGCheck", isTABG);

            var isOHC = accessControl.isDesignatedOHC();
            hyf.util.setComponentUsability("reviewOHCCheck", isOHC);
            hyf.util.setMandatoryConstraint("reviewOHCCheck", isOHC);
        }

        function initComponents() {
            hyf.util.disableComponent("reviewSODate");
            hyf.util.disableComponent("reviewDGODate");
            hyf.util.disableComponent("reviewCPDate");
            hyf.util.disableComponent("reviewOFMDate");
            hyf.util.disableComponent("reviewTABGDate");
            hyf.util.disableComponent("reviewOHCDate");

            setSignUsability();
        }

        function init(readOnly) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();

            setVisibilityAsRequireAdminApproval();

            _initialized = true;
        }

        function render(action) {
        }

        return {
            init: init,
            render: render,
            onRequireAdminApprovalChanged: onRequireAdminApprovalChanged
        }
    };

    var _initializer = window.cms_incentives_pca_review || (window.cms_incentives_pca_review = cms_incentives_pca_review());
})(window);
