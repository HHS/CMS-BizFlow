(function (window) {
    var cms_incentives_review = function () {
        var _initialized = false;

        function init() {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_review::init...");

            _initialized = true;
        }

        function render() {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_review::render...");
        }

        return {
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_review || (window.cms_incentives_review = cms_incentives_review());
})(window);
