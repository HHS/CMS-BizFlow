(function (window) {
    var cms_incentives_pdppca_position = function () {
        var _readOnly = false;
        var _initialized = false;
        var _dutyStation_ac = null;

        function setDutyStationAutoCompletion() {
            var option = {
                id: 'dutyStationPDPPCA_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchDutyStations.do?l=100&q=',
                minLength: 2,
                minSelectionCount: 1,
                maxSelectionCount: 1,
                readOnly: _readOnly,
                // onChangeInputContainerVisibility: function(visible) {
                //     var $mandatoryMark = $("#dutyStation_ac_label > span.mandatory").show();
                //     if ($mandatoryMark.length > 0) {
                //         if (visible) {
                //             $mandatoryMark.show();
                //         } else {
                //             $mandatoryMark.hide();
                //         }
                //     }
                // },
                mapFunction: function (context) {
                    return {
                        id: $("LOC_ID", context).text(),
                        state: $("LOC_STATE", context).text(),
                        city: $("LOC_CITY", context).text()
                    };
                },
                getSelectionLabel: function (item) {
                    return item.city + ", " + item.state
                },
                getCandidateLabel: function (item) {
                    return item.city + ", " + item.state
                },
                getItemID: function (item) {
                    return item.id;
                },
                setDataToForm: function (values) {
                    FormState.updateObjectValue('dutyStationPDPPCA', values);
                },
                // initialize
                initialItems: FormState.getElementArrayValue('dutyStation', [])
            };

            _dutyStation_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        function setGradeOptions(grades) {
            var selObj = $('#gradePDPPCA');
            selObj.children('option:not(:first)').remove();
            if (grades) {
                var selectedGrade = "";
                var cnt = 0;
                for (var g = 0; g < grades.length; g++) {
                    var grade = grades[g];
                    if (grade) {
                        cnt++;
                        if (typeof grade === 'number' && grade < 10) {
                            grade = '0' + grade;
                        }
                        selObj.append($("<option></option>").attr("value", grade).text(grade));
                        if (cnt === 1) {
                            selectedGrade = grade;
                        }
                    }
                }

                if (_initialized) {
                    if (cnt > 1) {
                        selectedGrade = "";
                    }
                    FormState.updateSelectValue("gradePDPPCA", selectedGrade, selectedGrade, true);
                    onGradeChanged(selectedGrade);
                }
            }
        }

        function setGradeSelectBoxWithRequestGrade(item) {
            if (item && item.position) {
                setGradeOptions(item.position.grade.slice(0).sort());
            }
        }

        function isValidGrades(grades) {
            for (var g = 0; g < grades.length; g++) {
                if (grades[g]) return true;
            }

            return false;
        }

        function setGradeVisibility(visible) {
            FormMain.setComponentVisibility('gradePDPPCA_group', visible);
            if (!visible) {
                onGradeChanged("");
            }
            if (_initialized) {
                if(cms_incentives_sam_details) {
                    cms_incentives_sam_details.onGradeHidden(visible);
                }
            }
        }

        function setGradeSelectBoxByPayPlan(payPlan, item) {
            if (payPlan && 'ES, GP, GR, GS, WG'.indexOf(payPlan) !== -1) {
                setGradeVisibility(true);
                item = item || FormState.getElementSingleValue('associatedNEILRequest');
                if (item) {
                    if (!isValidGrades(item.position.grade)) {
                        if ('ES' === payPlan) {
                            setGradeOptions([1, 2, 3, 4, 5, 6]);
                        } else if ('WG' === payPlan) {
                            setGradeOptions([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
                        } else if ('GP, GR, GS'.indexOf(payPlan) !== -1) {
                            setGradeOptions([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]);
                        }
                    }
                }
            } else {
                setGradeVisibility(false);
            }
        }

        function getGradeIndex(item, grade) {
            for (var i = 0; i < item.position.grade.length; i++) {
                if (item.position.grade[i] === grade) {
                    return i;
                }
            }

            return -1;
        }

        function setPositionDescriptionNumber(grade) {
            var descNum = "";
            var item = FormState.getElementSingleValue('associatedNEILRequest');
            if (item) {
                var idx = getGradeIndex(item, grade);
                if (idx > -1) {
                    descNum = item.position.descNum[idx];
                }
            }
            if (_initialized) {
                FormState.updateTextValue("posDescNumbePDPPCA", descNum || "", true);
            }
        }

        function setGradeSelectBox(incentiveType, payPlan, item) {
            if (INCENTIVES_TYPE.SAM === incentiveType && "ES" === payPlan) {
                var grade = "00";
                setGradeOptions([grade]);
                FormMain.setComponentUsability("grade", false);
                if (_initialized) {
                    FormState.updateSelectValue("grade", grade, grade, true);
                    setGradeVisibility(true);
                    onGradeChanged(grade);
                }
            } else {
                setGradeSelectBoxWithRequestGrade(item);
                setGradeSelectBoxByPayPlan(payPlan, item, true);
                FormMain.setComponentUsability("grade", true);
            }
        }

        function populateRelatedFields(item) {
            if (item) {
                item.position = item.position || {title: '', payPlan: {desc: ''}, series: {desc: ''}};
                var payPlan = item.position.payPlan.desc;

                // var series = item.position.series.desc;
                var series = null == item.id ? '' : '0602';  // automatically populate as 0602 by user story 212170
                FormState.updateTextValue("positionTitlePDPPCA", item.position.title, true);
                FormState.updateTextValue("payPlanPDPPCA", payPlan, true);
                FormState.updateTextValue("seriesPDPPCA", series, true);

                if(cms_incentives_sam_details) {
                    cms_incentives_sam_details.onPayPlanChanged(payPlan);
                }

                var typeOfAppointment = item.position.typeOfAppointment;
                FormState.updateTextValue("typeOfAppointmentPDPPCA", typeOfAppointment, true);
                FormState.updateTextValue("notToExceedDatePDPPCA", item.position.notToExceedDate, true);
                setNotToExceedDate(typeOfAppointment);

                if (item.position.workSchedule) {
                    var workSchedule = item.position.workSchedule.desc;
                    FormState.updateTextValue("workSchedulePDPPCA", workSchedule, true);
                    setHoursPerWeek(workSchedule);
                }
                FormState.updateTextValue("hoursPerWeekPDPPCA", item.position.hoursPerWeek, true);

                var incentiveType = FormState.getElementValue('incentiveType');

                setGradeSelectBox(incentiveType, payPlan, item);
                setPVPayPlanSeriesGrade(payPlan, series, '');

                item.license = item.license || {info: ''};
                FormState.updateTextValue("licenseInfoPDPPCA", item.license.info, true);

                if (null == item.id) {   // clean
                    _dutyStation_ac.deleteAllItems();
                    FormState.updateTextValue("posDescNumberPDPPCA", "", true);
                    FormState.updateTextValue("typeOfAppointmentPDPPCA", "", true);
                    FormState.updateSelectValue("requireBoardCertPDPPCA", "", "Select One", true);
                    //SAM FormState.updateSelectValue("posHardToFill", "", "Select One", true);
                    //SAM FormState.updateTextValue("numOfInterviewed", "", true);
                }
            }
        }

        function setPVPayPlanSeriesGrade(payPlan, series, grade) {
            var value = "";
            if (payPlan && payPlan.length > 0) {
                value = payPlan;
            }
            if (series && series.length > 0) {
                value += '/' + series;
            }
            if (grade && grade.length > 0) {
                value += '/' + grade;
            }
            FormState.updateObjectValue('payPlanSeriesGrade', value);
        }

        function setHoursPerWeek(workSchedule) {
            workSchedule = workSchedule || FormState.getElementValue("workSchedulePDPPCA");
            if ("Full-Time" === workSchedule) {
                if (_initialized) {
                    FormState.updateTextValue("hoursPerWeekPDPPCA", 40, true);
                }
                hyf.util.showComponent('hoursPerWeekPDPPCA_group');
                hyf.util.disableComponent("hoursPerWeekPDPPCA");
            } else if ("Part-Time" === workSchedule) {
                hyf.util.showComponent('hoursPerWeekPDPPCA_group');
                hyf.util.enableComponent("hoursPerWeekPDPPCA");
                if (_initialized) {
                    FormState.updateTextValue("hoursPerWeekPDPPCA", '', true);
                }
            } else {
                hyf.util.hideComponent('hoursPerWeekPDPPCA_group');
            }
        }

        function setPayPlanSelectBox() {
            LookupManager.fillListBox("payPlanPDPPCA", "PayPlan");
        }

        function setNotToExceedDate(typeOfAppointment) {
            typeOfAppointment = typeOfAppointment || FormState.getElementValue("typeOfAppointmentPDPPCA");
            if ("" !== typeOfAppointment && "Term, Temporary Promotion, Temporary".indexOf(typeOfAppointment) !== -1) {
                hyf.util.showComponent('notToExceedDatePDPPCA_group');
            } else {
                hyf.util.hideComponent('notToExceedDatePDPPCA_group');
            }
        }

        function setWorkScheduleSelectBox() {
            LookupManager.fillListBox("workSchedulePDPPCA", "WorkSchedule");
        }

        function onIncentiveTypeChanged(incentiveType) {
            FormMain.setComponentVisibility("PDPPCA_fields_group", "PCA" === incentiveType);
            // FormMain.setComponentVisibility("SAM_fields_group", "SAM" === incentiveType);

            var item = FormState.getElementSingleValue('associatedNEILRequest');
            var payPlan = FormState.getElementValue('payPlanPDPPCA');
            setGradeSelectBox(incentiveType, payPlan, item);
        }

        function onGradeChanged(grade) {
            setPVPayPlanSeriesGrade(FormState.getElementValue('payPlanPDPPCA', ''), FormState.getElementValue('seriesPDPPCA', ''), grade);
            setPositionDescriptionNumber(grade);
            if (_initialized) {
                if (cms_incentives_pca_details) {
                    cms_incentives_pca_details.onGradeChanged(grade);
                }
                if (cms_incentives_sam_details) {
                    cms_incentives_sam_details.onGradeChanged(grade);
                }
                if(cms_incentives_sam_review) {
                    cms_incentives_sam_review.onGradeChanged(grade);
                }
            }
        }

        function initEventHandlers() {
            $('#gradePDPPCA').on('change', function (e) {
                var target = e.target;
                var grade = target.options[target.options.selectedIndex].value;
                onGradeChanged(grade);
            });

            $('#payPlanPDPPCA').on('change', function (e) {
                var target = e.target;
                var payPlan = target.options[target.options.selectedIndex].value;
                setGradeSelectBoxByPayPlan(payPlan);
                if(cms_incentives_pca_details) {
                    cms_incentives_pca_details.onPayPlanChanged(payPlan);
                }
                if(_initialized) {
                    if(cms_incentives_sam_details) {
                        cms_incentives_sam_details.onPayPlanChanged(payPlan);
                    }
                }
            });

            $('#workSchedulePDPPCA').on('change', function (e) {
                var target = e.target;
                var workSchedule = target.options[target.options.selectedIndex].value;
                setHoursPerWeek(workSchedule);
            });

            $('#requireBoardCertPDPPCA').on('change', function (e) {
                var target = e.target;
                var requireBoardCert = target.options[target.options.selectedIndex].value;
                if(cms_incentives_pca_details) {
                    cms_incentives_pca_details.onRequireBoardCertChanged(requireBoardCert);
                }
            });
        }

        function postDisableTab(afterAllTabLoaded, tab) {
            if (afterAllTabLoaded) {
                if (activityStep.isSOReview()) {
                    if (tab.readOnly) {
                        hyf.util.enableComponent("numOfInterviewed");
                    }
                }
            }
        }

        function initComponents() {
            onIncentiveTypeChanged(FormState.getElementValue("incentiveType"));

            if (activityStep.isSOReview()) {
                hyf.util.setMandatoryConstraint("gradePDPPCA", false);
                hyf.util.setMandatoryConstraint("posDescNumberPDPPCA", false);
                hyf.util.setMandatoryConstraint("dutyStationPDPPCA_ac", false);
            }

            setPayPlanSelectBox();
            setNotToExceedDate();
            setWorkScheduleSelectBox();
            setHoursPerWeek();

            setDutyStationAutoCompletion();
        }

        function init(readOnly, tabObject) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();
            FormMain.resetMandatoryMark(tabObject);

            _initialized = true;
        }

        function render(action) {
        }

        return {
            init: init,
            render: render,
            populateRelatedFields: populateRelatedFields,
            onIncentiveTypeChange: onIncentiveTypeChanged,
            postDisableTab: postDisableTab
        }
    };

    var _initializer = window.cms_incentives_pdppca_position || (window.cms_incentives_pdppca_position = cms_incentives_pdppca_position());
})(window);
