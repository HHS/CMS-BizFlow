(function (window) {
    var cms_incentives_pdp_approval = function () {
        var _readOnly = false;
        var _initialized = false;

        function setApprovalDate(_readOnly){
            var currentDate = "";
            var pdp_adminApprovalDateObj = FormState.getState('pdp_adminApprovalDate');

            if( pdp_adminApprovalDateObj && pdp_adminApprovalDateObj.value != ""){
                currentDate = FormState.getState('pdp_adminApprovalDate').value;
            } else {
                currentDate = FormUtility.getDateString(false, "mm/dd/yyyy", new Date());                
            }
            hyf.calendar.setDateConstraint('adminApprovalDate', 'Maximum', 'Today');
            FormState.updateDateValue('pdp_adminApprovalDate', currentDate, false);
            if (activityStep.isHR_REVIEW_APPROVAL() && myInfo.isINCENTIVEHRS() && _readOnly == false) {
                hyf.util.enableComponent("pdp_adminApprovalDate");
            }
        }

        function initEventHandlers() {
        }
        
        function initComponents() {
            hyf.util.disableComponent("pdp_adminApprovalDate");            
            setApprovalDate(_readOnly);
        }

        function init(readOnly, tabObject) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();
            FormMain.resetMandatoryMark(tabObject);

            _initialized = true;
        }

        function render(action) {
        }

        return {
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_pdp_approval || (window.cms_incentives_pdp_approval = cms_incentives_pdp_approval());
})(window);
