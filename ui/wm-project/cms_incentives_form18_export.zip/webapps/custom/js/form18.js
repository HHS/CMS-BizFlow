(function (window) {
    var cms_incentives_pdp_approval = function () {
        var _readOnly = false;
        var _initialized = false;

        function setApprovalDate(){
            
            var currentDate = FormUtility.getDateString(false, "mm/dd/yyyy", new Date());
            
            if (activityStep.isHR_REVIEW_APPROVAL() && myInfo.isINCENTIVEHRS()) {
				hyf.util.enableComponent("adminApprovalDate");
				hyf.util.setMandatoryConstraint("adminApprovalDate", true);
                hyf.calendar.setDateConstraint("adminApprovalDate", 'Maximum', 'Today');
                $('#adminApprovalDate').val(currentDate);                
			} else {
                hyf.util.disableComponent("adminApprovalDate");
            }
        }

        function initEventHandlers() {
        }
        
        function initComponents() {
            hyf.util.disableComponent("adminApprovalDate");            
            setApprovalDate();
        }

        function init(readOnly, tabObject) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();
            FormMain.resetMandatoryMark(tabObject);

            _initialized = true;
        }

        function render(action) {
        }

        return {
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_pdp_approval || (window.cms_incentives_pdp_approval = cms_incentives_pdp_approval());
})(window);
