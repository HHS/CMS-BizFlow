(function (window) {
    var cms_incentives_pdp_approval = function () {
        var _readOnly = false;
        var _initialized = false;

        function setApprovalDate(){
            var currentDate = "";
            var pdp_adminApprovalDateObj = FormState.getState('pdp_adminApprovalDate');

            if( pdp_adminApprovalDateObj && pdp_adminApprovalDateObj.value != ""){
                currentDate = FormState.getState('pdp_adminApprovalDate').value;
            } else {
                currentDate = FormUtility.getDateString(false, "mm/dd/yyyy", new Date());                
            }

            if (activityStep.isHR_REVIEW_APPROVAL() && myInfo.isINCENTIVEHRS() && _readOnly == false) {
                hyf.util.enableComponent("pdp_adminApprovalDate");
                hyf.calendar.setDateConstraint('adminApprovalDate', 'Maximum', 'Today');
                FormState.updateDateValue('pdp_adminApprovalDate', currentDate, false);                
            }
        }

        function initEventHandlers() {

			$('#adminApprovalDate').on('change', function (e) {
                var target = e.target;
				var value = target.value;
				if(value == "") {
					hyf.util.setComponentUsability('button_SubmitWorkitem', false); 
				}
				else {
					hyf.util.setComponentUsability('button_SubmitWorkitem', true); 
				}
			});

        }
        
        function initComponents() {
            hyf.util.disableComponent("pdp_adminApprovalDate");            
            setApprovalDate();
        }

        function init(readOnly, tabObject) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();
            FormMain.resetMandatoryMark(tabObject);

            _initialized = true;
        }

        function render(action) {
        }

        return {
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_pdp_approval || (window.cms_incentives_pdp_approval = cms_incentives_pdp_approval());
})(window);
