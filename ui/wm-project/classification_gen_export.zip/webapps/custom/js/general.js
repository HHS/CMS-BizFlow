var classificationGEN = {
	// Field used to store base URL used by AutoComplete
	baseURL: '/bizflowwebmaker/StratCon_AUT/',

	// Field used to store indicator whether currently a Restricted Grade is selected or not
	prevRestricatedGrade: false,
    
	// Field used to store maximum allowed charaters in Remarks Field
    remarksMaxChars: 500,
	
	// Array of objects used throughout the grade related functions
	grades: [
		{ id: '#CS_GR_ID_1', lbl: '#CS_GR_ID_1_label', pdn: '#CS_PD_NUMBER_JOBCD_1', pdnl: '#CS_PD_NUMBER_JOBCD_1_label', cdt: '#CS_CLASSIFICATION_DT_1', cdtl: '#CS_CLASSIFICATION_DT_1_label', cdta: '#CS_CLASSIFICATION_DT_1_calendar_anchor', flsa: '#CS_FLSA_DETERM_ID_1'},
		{ id: '#CS_GR_ID_2', lbl: '#CS_GR_ID_2_label', pdn: '#CS_PD_NUMBER_JOBCD_2', pdnl: '#CS_PD_NUMBER_JOBCD_2_label', cdt: '#CS_CLASSIFICATION_DT_2', cdtl: '#CS_CLASSIFICATION_DT_2_label', cdta: '#CS_CLASSIFICATION_DT_2_calendar_anchor', flsa: '#CS_FLSA_DETERM_ID_2'},
		{ id: '#CS_GR_ID_3', lbl: '#CS_GR_ID_3_label', pdn: '#CS_PD_NUMBER_JOBCD_3', pdnl: '#CS_PD_NUMBER_JOBCD_3_label', cdt: '#CS_CLASSIFICATION_DT_3', cdtl: '#CS_CLASSIFICATION_DT_3_label', cdta: '#CS_CLASSIFICATION_DT_3_calendar_anchor', flsa: '#CS_FLSA_DETERM_ID_3'},
		{ id: '#CS_GR_ID_4', lbl: '#CS_GR_ID_4_label', pdn: '#CS_PD_NUMBER_JOBCD_4', pdnl: '#CS_PD_NUMBER_JOBCD_4_label', cdt: '#CS_CLASSIFICATION_DT_4', cdtl: '#CS_CLASSIFICATION_DT_4_label', cdta: '#CS_CLASSIFICATION_DT_4_calendar_anchor', flsa: '#CS_FLSA_DETERM_ID_4'},
		{ id: '#CS_GR_ID_5', lbl: '#CS_GR_ID_5_label', pdn: '#CS_PD_NUMBER_JOBCD_5', pdnl: '#CS_PD_NUMBER_JOBCD_5_label', cdt: '#CS_CLASSIFICATION_DT_5', cdtl: '#CS_CLASSIFICATION_DT_5_label', cdta: '#CS_CLASSIFICATION_DT_5_calendar_anchor', flsa: '#CS_FLSA_DETERM_ID_5'}
	],
	
	// Object Containing properties to store Pay Plan Details; contents are refreshed using the method setPayPlanDetails when Pay Plan is changed by the user
	payPlanDetails: {
		payPlan: "",
		gradeRequired: 0,
		minGrade: 0,
		maxGrade: 0,
		restrictGradeAt: 0
	},
	
	/**
	 * This method/function sets payPlanDetails object (above)
	 *
	 * @param: selectedPlay - pay plan (GS, ES, WG, etc.) selected by the user
	 */
	setPayPlanDetails: function (selectedPayPlan) {
		this.payPlanDetails.payPlan = "",
		this.payPlanDetails.gradeRequired = 0;
		this.payPlanDetails.minGrade = 0;
		this.payPlanDetails.maxGrade = 0;
		this.payPlanDetails.restrictGradeAt = 0;
		if (selectedPayPlan != "") {
			var ppDetail = $('#GRADE_SOURCE option[value="' + selectedPayPlan + '"]').attr('selected',true).text().split(',');
			this.payPlanDetails.payPlan = selectedPayPlan,
			this.payPlanDetails.gradeRequired = parseInt(ppDetail[0])
			this.payPlanDetails.minGrade = parseInt(ppDetail[1]);
			this.payPlanDetails.maxGrade = parseInt(ppDetail[2]);
			this.payPlanDetails.restrictGradeAt = parseInt(ppDetail[3]);
		}
	},
    
    separator: ',',
    longSeparator: '_/~',
	// Utility method for autocompletion of user with dept/title info
	getUserObjectForAC: function(userID) {
		var userObject = [];
		var userFromSource = $('#group_user_info option[value="' +  userID + '"]');
		if (userFromSource && userFromSource.length > 0) {
			var userText = userFromSource.text();
			if (userText && userText.length > 0) {
				var userInfo = userText.split(classificationGEN.longSeparator);
				// userInfo[0] - memberid // userInfo[1] - name // userInfo[2] - email // userInfo[3] - deptname // userInfo[4] - jobtitlename
				userObject.push({
					id: userID,
					name: userInfo[1],
					deptname: userInfo[3],
					jobtitle: userInfo[4]
				});
			}
		}
		return userObject;
    },
    getXOObjectForAC: function() {
        var userObject = [];

        var IDString = $('#XO_ID').val();
        var IDs = IDString.split(classificationGEN.separator);
        var count = IDs.length;

        for (var i = 0; i < count; i++) {
            var userInfo = classificationGEN.getUserObjectForAC(IDs[i]);
            if (userInfo.length == 1) {
                userObject.push(userInfo[0]);
            }
        }
        return userObject;
    },    
	
	/**
	 * This method/function sets auto complete for Admin Code 
	 */
	setAutoComplete: function () {
		//Displays previously selected Admin Code
		if($("#CS_ADMIN_CD").val() != ""){
            var li_admin_cd = "<li id=\"" + $("#CS_ADMIN_CD").val() + "\">";
            if($('#h_readOnly').val() != 'y'){
                li_admin_cd += "<img src=\"" + classificationGEN.baseURL + "custom/images/delete-icon.png" + "\" id=\"delete-" + $("#CS_ADMIN_CD").val() + "\" deleteId=\"" + $("#CS_ADMIN_CD").val() + "\" title=\"Remove " + $("#CS_ADMIN_CD").val() + "\" tabindex=\"0\" />";
            }
            li_admin_cd += $("#CS_ADMIN_CD").val() + "</li>";
            $("#CS_AC_DISP").append(li_admin_cd).removeClass('hidden');
			$("#CS_ADMIN_CD_INPUT_container").addClass('hidden');
			$("#CS_ADMIN_CD_INPUT").attr('_required', 'false');
		}
		$("#CS_ADMIN_CD_INPUT").autocomplete({
			source: function (request, response) {
				$.ajax({
					url: classificationGEN.baseURL + "SearchAdmOffOrg.do?searchAdmOff=" + $('#CS_ADMIN_CD_INPUT').val(),
					dataType: "xml",
					cache: false,
					success: function (xmlResponse) {
						var data = $("record", xmlResponse ).map(function() {
							return {
								//ac_id: $( "AC_ID", this ).text(),
								admin_cd: $( "AC_ADMIN_CD", this ).text(),
								admin_desc: $( "AC_ADMIN_CD_DESCR", this ).text()
							};
						}).get();
						response(data);
					}
				})
			},
			minLength: 2,
			change: function (e, u) {
				//If the No match found" u.item will return null, clear the TextBox.
				if (u.item == null) {
					//Clear the AutoComplete TextBox.
					var pos = $(this).position();
					$('#CS_ADMIN_CD_INPUT_noMatch').remove();
					$(this).after("<span id='CS_ADMIN_CD_INPUT_noMatch' class='acNoMatch'>Invalid Selection:<br />Item must be selected from the available options.</span>");
					$('#CS_ADMIN_CD_INPUT_noMatch').css({top: pos.top + 20, left: pos.left + 30, position:'absolute'});
					setTimeout(function() {
						$('#CS_ADMIN_CD_INPUT_noMatch').remove();
					}, 2000);
					$(this).val("");
					return false;
				}
			},
			select: function (event, ui) {
				var li_admin_cd = "<li id=\"" + ui.item.admin_cd + "\"><img src=\"" + classificationGEN.baseURL + "custom/images/delete-icon.png" + "\" id=\"delete-" + ui.item.admin_cd + "\" deleteId=\"" + ui.item.admin_cd + "\" title=\"Remove " + ui.item.admin_cd + "\" tabindex=\"0\" /> " + ui.item.admin_cd + "</li>";
				$("#CS_AC_DISP").append(li_admin_cd).removeClass('hidden');	
				$("#CS_ADMIN_CD_INPUT_container").addClass('hidden');
				$("#CS_ADMIN_CD_INPUT").attr('_required', 'false');
				$('#CS_ADMIN_CD').val(ui.item.admin_cd);
				classificationGEN.manageOrganization();
			}
		})
		.autocomplete().data("ui-autocomplete")._renderItem = function (ul, item) {
			return $("<li>")
			.append("<a>" + item.admin_cd + " - "  + item.admin_desc + "</a>")
			.appendTo(ul);
		};
	
		// SO Auto Completion
		var soID = $('#SO_ID').val();
		var soInitialData = classificationGEN.getUserObjectForAC(soID);
		var soOption = {
			id: 'soSearch',
			//tabindex: 0,
			targetURL: 'SearchPeopleUGNameTitle.do',
			targetParam: 'userGroupName=Selecting Officials&searchString',
			searchMode: 'include',
			minLength: 2,
			minSelectionCount: 1,
			maxSelectionCount: 1,
			mapFunction: function(context) {
				return {
					id: $( "MEMBERID", context ).text(),
					name: $( "NAME", context ).text(),
					deptname: $( "DEPTNAME", context ).text(),
					jobtitle: $( "JOBTITLENAME", context ).text()
				};            
			},
			getSelectionLabel: function(item) {
				var selectionLabel = '';
				selectionLabel = item.name;
				if ((item.deptname && item.deptname.length > 0) || (item.jobtitle && item.jobtitle.length > 0)) {
					selectionLabel += (' (' + item.deptname);
					if (item.jobtitle && item.jobtitle.length > 0) {
						selectionLabel += ('/' + item.jobtitle)
					}
					selectionLabel += ')'
				}
				return selectionLabel;
			},
			getCandidateLabel: function(item) {
				var selectionLabel = '';
				selectionLabel = item.name;
				if ((item.deptname && item.deptname.length > 0) || (item.jobtitle && item.jobtitle.length > 0)) {
					selectionLabel += (' (' + item.deptname);
					if (item.jobtitle && item.jobtitle.length > 0) {
						selectionLabel += ('/' + item.jobtitle)
					}
					selectionLabel += ')'
				}
				return selectionLabel;
			},
			getItemID: function(item) {
				return item.id;
			},
			setDataToForm: function(values) {
				if (values && values.length == 1) {
					$('#SO_ID').val(values[0].id);
					$('#SO_TITLE').val(values[0].jobtitle);
					$('#SO_ORG').val(values[0].deptname);
				}
			},
			initialItems: soInitialData
		}
		var soAC = initAutoCompletion(soOption);

		// XO Auto Completion
		var xoOption = Object.create(soOption);
        xoOption.id = 'xoSearch';
        xoOption.minSelectionCount = 1;
        xoOption.maxSelectionCount = 3;
    
		//xoOption.tabindex = 0;
		xoOption.targetParam = 'userGroupName=Executive Officers&searchString';
		xoOption.setDataToForm = function(values) {
            var count = values.length;
            var IDs = '';
            var titles = '';
            var orgs = '';

            for (var i = 0; i < count; i++) {
                if (i != 0) {
                    IDs = IDs + classificationGEN.separator;
                    titles = titles + classificationGEN.longSeparator;
                    orgs = orgs + classificationGEN.longSeparator;
                }
                IDs = IDs + values[i].id;
                titles = titles + values[i].jobtitle;
                orgs = orgs + values[i].deptname;
            }

            $('#XO_ID').val(IDs);
            $('#XO_TITLE').val(titles);
            $('#XO_ORG').val(orgs);

		};
		xoOption.initialItems = classificationGEN.getXOObjectForAC();
		var xoAC = initAutoCompletion(xoOption);

		// HR Liaison Auto Completion
		var hrID = $('#HRL_ID').val();
		var hrInitialData = [];
		if (hrID == '0000000000') {
			hrInitialData.push({
				id: '0000000000',
				name: 'N/A',
				deptname: '',
				jobtitle: ''
			});
		} else {
			hrInitialData = classificationGEN.getUserObjectForAC(hrID);
		}
		
		var hrOption = Object.create(soOption);
		hrOption.id = 'hrSearch';
		//hrOption.tabindex = 103;
		hrOption.targetParam = 'userGroupName=HR Liaison&searchString';
		hrOption.setDataToForm = function(values) {
			if (values && values.length == 1) {
				$('#HRL_ID').val(values[0].id);
				$('#HRL_TITLE').val(values[0].jobtitle);
				$('#HRL_ORG').val(values[0].deptname);
			}
		};
		hrOption.initialItems = hrInitialData;
		hrOption.addCandidateItems = function(candidates) {
			candidates.push({
				id: '0000000000',
				name: 'N/A',
				deptname: '',
				jobtitle: ''
			});
		};
		var hrAC = initAutoCompletion(hrOption);

		// Staff Specialist Auto Completion
		var ssID = $('#SS_ID').val();
		var ssInitialData = classificationGEN.getUserObjectForAC(ssID);
		var ssOption = Object.create(soOption);
		ssOption.id = 'ssSearch';
		//ssOption.tabindex = 104;
		ssOption.targetParam = 'userGroupName=HR Staffing Specialists&searchString';
		ssOption.setDataToForm = function(values) {
			if (values && values.length == 1) {
				$('#SS_ID').val(values[0].id)
			}
		};
		ssOption.initialItems = ssInitialData;
		var ssAC = initAutoCompletion(ssOption);

		// Special Program Specialist Auto Completion
		/*var spID = $('#SP_ID').val();
		var spInitialData = classificationGEN.getUserObjectForAC(spID);
		var spOption = Object.create(soOption);
		spOption.id = 'spSearch';
		spOption.tabindex = 105;
		spOption.targetParam = 'userGroupName=HR Special Programs&searchString';
		spOption.setDataToForm = function(values) {
			if (values && values.length == 1) {
				$('#SP_ID').val(values[0].id)
			}
		};
		spOption.initialItems = spInitialData;
		var spAC = initAutoCompletion(spOption);
*/
		// Classification Specialist Auto Completion
		var csID = $('#CS_ID').val();
		var csInitialData = classificationGEN.getUserObjectForAC(csID);
		var csOption = Object.create(soOption);
		csOption.id = 'csSearch';
		//csOption.tabindex = 106;
		csOption.targetParam = 'userGroupName=HR Classification Specialists&searchString';
		csOption.setDataToForm = function(values) {
			if (values && values.length == 1) {
				$('#CS_ID').val(values[0].id)
			}
		};
		csOption.initialItems = csInitialData;
		var csAC = initAutoCompletion(csOption);
	},
	
	showHideStaffSpecialistGroup: function() {
		var requestType = $("#pv_requestType").val();
		var appointmentType = $("#pv_appointmentType").val();
		var isSpecial = CMSUtility.isSpecialProgramValue(requestType, appointmentType);
		if (isSpecial == true) {
			hyf.util.disableComponent('SS_ID');
			$('#SS_ID').attr('donotsubmit', 'true');
			
			//hyf.util.enableComponent('SP_ID');
			//$('#SP_ID').removeAttr('donotsubmit');
			
			hyf.util.hideComponent('staff_prticipant_group', null, null, null);
			//hyf.util.showComponent('spcprg_prticipant_group', null, null, null);			
			//$('#pv_specialProgram').val('Yes');
		} else {
			//hyf.util.disableComponent('SP_ID');
			//$('#SP_ID').attr('donotsubmit', 'true');

			hyf.util.enableComponent('SS_ID');
			$('#SS_ID').removeAttr('donotsubmit');

			if (requestType == 'Classification Only') {
				$('#SS_ID').val('');
				hyf.util.hideComponent('staff_prticipant_group', null, null, null);
			} else if (requestType == 'Recruitment') {
				hyf.util.showComponent('staff_prticipant_group', null, null, null);
			} else if (requestType == 'Appointment') {
				if (appointmentType == 'Intergovernmental Personnel Act (IPA)') {
					$('#SS_ID').val('');
					hyf.util.hideComponent('staff_prticipant_group', null, null, null);
				} else {
					hyf.util.showComponent('staff_prticipant_group', null, null, null);
				}
			} else {
				hyf.util.showComponent('staff_prticipant_group', null, null, null);
			}
			//hyf.util.hideComponent('spcprg_prticipant_group', null, null, null);
			//$('#pv_specialProgram').val('No');
		}
	},
	
	showHideClassificationSpecialistGroup: function() {
		var requestType = $("#pv_requestType").val();
		var appointmentType = $("#pv_appointmentType").val();

		if (requestType != 'Appointment'
			|| (appointmentType != 'Volunteer'
				&& appointmentType != 'Intergovernmental Personnel Act (IPA)'
				&& appointmentType != 'Expert/Consultant')) {
			hyf.util.showComponent('clsf_prticipant_group', null, null, null);
		} else {
			$('#CS_ID').val('');
			hyf.util.hideComponent('clsf_prticipant_group', null, null, null);
		}
	},

	
	// This function/method uses the value from the CS_PAY_PLAN_ID field to manage grade options.
	payPlanChange: function(){   
		classificationGEN.setPayPlanDetails($(this).val());
        $(classificationGEN.grades[0].id).attr('_required', false);
		if(classificationGEN.payPlanDetails.payPlan != ''){
			if(classificationGEN.payPlanDetails.gradeRequired == 1){
				$(classificationGEN.grades[0].lbl).removeClass('hidden');
				$(classificationGEN.grades[0].id).attr('_required', true).removeClass('hidden');
				$(classificationGEN.grades[0].pdn).on('keyup keypress blur change', function(){
					var pos = $(this).position();
					if($(this).val().length == 10){
						$('#CS_DESC_NUMBER_MAX').remove();
						$(this).after("<span id='CS_DESC_NUMBER_MAX' class='limitAlert'>10 Character Max Reached</span>");
						$('#CS_DESC_NUMBER_MAX').css({top: pos.top + 20, left: pos.left + 30, position:'absolute'});
						setTimeout(function() {
							$('#CS_DESC_NUMBER_MAX').remove();
						}, 1000);
					}
				});
				classificationGEN.toggleAddGrade(true);
				classificationGEN.manageGrades();
				
				$("#CS_PERFORMANCE_LEVEL").attr('_required', true).removeClass('hidden');
				$("#CS_PERFORMANCE_LEVEL_label").removeClass('hidden');
			}else{
				classificationGEN.removeGrade();
				classificationGEN.toggleAddGrade(false);
				classificationGEN.removeFpl();
			}
		}else{
			classificationGEN.removeGrade();
			classificationGEN.toggleAddGrade(false);
			classificationGEN.removeFpl();
		}
		$(classificationGEN.grades[0].id).attr('_required', true).on('change', classificationGEN.setGradeOptions).trigger('change');
		for(var i = 1; i < classificationGEN.grades.length; i++) {
			$(classificationGEN.grades[i].id).on('change', classificationGEN.setGradeOptions);
		}
		classificationGEN.showHidePcaPdp();
	},
	
	// This function uses the value from the CS_SR_ID field to handle change event.
	occupationSeriesChange: function(){
		classificationGEN.showHidePcaPdp();
	}
	,

	// This function/method displays the grades based on them having a value this is needed to display data returned from the DB.  If no grades are displayed, a default empty grade is displayed.
	manageGrades: function(){
		var numOfGrades = 0;
		for(var i=1;i<classificationGEN.grades.length;i++){
			classificationGEN.toggleGradeRow(i,false);
			$(classificationGEN.grades[i].id).attr('_required', 'false');
			if($(classificationGEN.grades[i].id).val() > 0){
				numOfGrades++;
				$(classificationGEN.grades[i].id).attr('_required', 'true');
				classificationGEN.toggleGradeRow(i,true);
				$(classificationGEN.grades[i].pdn).on('keyup keypress blur change', function(){
					var pos = $(this).position();
					if($(this).val().length == 10){
						$('#CS_DESC_NUMBER_MAX').remove();
						$(this).after("<span id='CS_DESC_NUMBER_MAX' class='limitAlert'>10 Character Max Reached</span>");
						$('#CS_DESC_NUMBER_MAX').css({top: pos.top + 20, left: pos.left + 30, position:'absolute'});
						setTimeout(function() {
							$('#CS_DESC_NUMBER_MAX').remove();
						}, 1000);
					}
				});
			}
		}
		if (numOfGrades == 4) {
			classificationGEN.toggleAddGrade(false);
		}
	},

	// This function/method sets the available options in each of the Grade dropdowns. The function removes selected values and uses the classificationGEN.payPlanDetails.restrictGradeAt value to detirmine the available options
	setGradeOptions: function(){
		var minFPL = 1;
		for(var i = 0; i < classificationGEN.grades.length; i++) {
			var gradeCurrentValue = $(classificationGEN.grades[i].id).val();
			var maxgrade = i == 0 ? classificationGEN.payPlanDetails.maxGrade : (classificationGEN.payPlanDetails.restrictGradeAt - 1);
			var options = "<option value selected>Select One</option>";
			for (var g = classificationGEN.payPlanDetails.minGrade; g <= maxgrade; g++) {
				options += "<option value=\"" + g + "\">" + (g > 9 ? "" : "0") + g + "</option>";
			}
			$(classificationGEN.grades[i].id)
				.find('option')
				.remove()
				.end()
				.append(options);
			if ($.isNumeric(gradeCurrentValue)) {
				$(classificationGEN.grades[i].id).val(gradeCurrentValue);
			}
		}
		for(var i = 0; i < classificationGEN.grades.length; i++) {
			var checkValue = $(classificationGEN.grades[i].id).val();
			if ($.isNumeric(checkValue)) {
				if (parseInt(minFPL) < parseInt(checkValue)) {
					minFPL = parseInt(checkValue);
				}
				for(var j = 0; j < classificationGEN.grades.length; j++) {
					if (i != j) {
						$(classificationGEN.grades[j].id + " option").each( function() {
							var gradeValue = $(this).val();
							if ($.isNumeric(gradeValue) && checkValue == gradeValue) {
								$(classificationGEN.grades[j].id + " option[value='" + gradeValue +"']").remove();
							}
						})
					}
				}
			}
		}
		if (parseInt(minFPL) < parseInt(classificationGEN.payPlanDetails.restrictGradeAt)) {
			var fplValue = $("#CS_PERFORMANCE_LEVEL").val();
			var options = "<option value selected>Select One</option>";
			for (var g = minFPL; g < classificationGEN.payPlanDetails.restrictGradeAt; g++) {
				options += "<option value=\"" + g + "\">" + (g > 9 ? "" : "0") + g + "</option>";
			}
			$("#CS_PERFORMANCE_LEVEL")
				.find('option')
				.remove()
				.end()
				.append(options);
			if ($.isNumeric(fplValue) && parseInt(minFPL) <= parseInt(fplValue)  && parseInt(fplValue) < classificationGEN.payPlanDetails.restrictGradeAt) {
				$("#CS_PERFORMANCE_LEVEL").val(fplValue);
			}
			if (classificationGEN.prevRestricatedGrade) {
				classificationGEN.toggleAddGrade(true);
				classificationGEN.prevRestricatedGrade = false;
			}
		}else{
			for(var i = 1; i < classificationGEN.grades.length; i++){
				classificationGEN.clearGrade(i);
				classificationGEN.toggleGradeRow(i);
			}
			// Clear FPL field option when there is no grade and FPL should be hidden
			// However, if there is at least one grade, and the grade value exceeds the restricted value, display only that option.
			var options;
			if (classificationGEN.payPlanDetails.gradeRequired == 1){
				options = '<option selected value="' + minFPL + '">' + (minFPL > 9 ? "" : "0") + minFPL + '</option>';
			} else {
				options = "<option value selected>Select One</option>";
			}
			$("#CS_PERFORMANCE_LEVEL")
				.find('option')
				.remove()
				.end()
				.append(options);
			classificationGEN.prevRestricatedGrade = true;
			classificationGEN.toggleAddGrade(false);
		}
	},
	
	// This function/method removes grade from the screen and clears all values. If no argumments are passed all rows are removed otherwise the idx value passed is removed.
	removeGrade: function(){
		var idx = arguments[0];
		if(idx !== undefined){
			classificationGEN.clearGrade(idx);
			classificationGEN.toggleGradeRow(idx);
		}else{
			$(classificationGEN.grades[0].lbl).addClass('hidden');
			$(classificationGEN.grades[0].id).attr('_required', false).addClass('hidden');
			for(var i = 1; i < classificationGEN.grades.length; i++){
				classificationGEN.clearGrade(i);
				classificationGEN.toggleGradeRow(i);
			}
		}
		classificationGEN.setGradeOptions();
		classificationGEN.toggleAddGrade(true);
	},
	
	// This function/method adds the first available grade row to the screen.
	addGrade: function(){
		var i = 0;
		var added = false;
		while(!added && i < classificationGEN.grades.length){
			if($(classificationGEN.grades[i].id).attr('_required') != 'true'){
				classificationGEN.toggleGradeRow(i,true);
				added = true;
			}
			i++;
		}
		if(i == classificationGEN.grades.length){
			classificationGEN.toggleAddGrade(false);
		}
	},

	/**
	 * This function/method sets all the values related to grade to null based on the index
	 * 
	 * @param idx - index value of the grade to clear
	 *
	 */
	clearGrade: function(idx){
		$(classificationGEN.grades[idx].id).val('').attr('_required', false);
		$(classificationGEN.grades[idx].id + 'option[text="Select One"]').attr('selected', true);
		$(classificationGEN.grades[idx].cdt).val('').attr('_required', false);
		$(classificationGEN.grades[idx].pdn).val('').attr('_required', false);
		$(classificationGEN.grades[idx].flsa).val('').attr('_required', false);
		$(classificationGEN.grades[idx].flsa + 'option[text="Select One"]').attr('selected', true);
	},
	
	// This function/method removes Full Performanc Level field from the screen.
	removeFpl: function(){
		$("#CS_PERFORMANCE_LEVEL").attr("_required", false).addClass("hidden");
		$("#CS_PERFORMANCE_LEVEL_label").addClass("hidden");
	},
	
	// This function/method sets the display values of the Organization/Sub-organization as well as the related data fields
	manageOrganization: function(){
		var AC = $('#CS_ADMIN_CD').val();
		var acLvl = AC.length;
        var end = 3;
		$("#PD_ORGANIZATION_DSP").text("DEPARTMENT OF HEALTH AND HUMAN SERVICES"); // admin code table from EHRP does not have HHS entry, so hard code it.
		var pdSubOrg1Dsp = $('#ORGANIZATION_SOURCE option[value="F"]').text();
		// suborg1 text pulled from EHRP is stored as mixed case -> make it upper case
		$("#PD_SUB_ORG_1_DSP").text((typeof pdSubOrg1Dsp != "undefined" && pdSubOrg1Dsp != null ? pdSubOrg1Dsp.toUpperCase() : ""));
		$('#PD_SUB_ORG_1').val($('#ORGANIZATION_SOURCE option[value="F"]').val());
        if(AC.substring(0,3) == 'FCM' && AC != 'FCM2'){
            end = 4;
            acLvl = acLvl-1;
        }
        $('#PD_SUB_ORG_2_DSP').text($('#ORGANIZATION_SOURCE option[value="' + AC.substring(0,end) + '"]').text());
        $('#PD_SUB_ORG_2').val($('#ORGANIZATION_SOURCE option[value="' + AC.substring(0,end) + '"]').val());
		end++;
        $('#PD_SUB_ORG_3_DSP').text("");
        $('#PD_SUB_ORG_3').val("");
        if(acLvl >= 4){
            $('#PD_SUB_ORG_3_DSP').text($('#ORGANIZATION_SOURCE option[value="' + AC.substring(0,end) + '"]').text());
            $('#PD_SUB_ORG_3').val($('#ORGANIZATION_SOURCE option[value="' + AC.substring(0,end) + '"]').val());
        }
        end++;
        $('#PD_SUB_ORG_4_DSP').text("");
        $('#PD_SUB_ORG_4').val("");
        if(acLvl >= 5){
            $('#PD_SUB_ORG_4_DSP').text($('#ORGANIZATION_SOURCE option[value="' + AC.substring(0,end) + '"]').text());
            $('#PD_SUB_ORG_4').val($('#ORGANIZATION_SOURCE option[value="' + AC.substring(0,end) + '"]').val());
        }
        end++;
        $('#PD_SUB_ORG_5_DSP').text("");
        $('#PD_SUB_ORG_5').val("");
        if(acLvl >= 6){
            $('#PD_SUB_ORG_5_DSP').text($('#ORGANIZATION_SOURCE option[value="' + AC.substring(0,end) + '"]').text());
            $('#PD_SUB_ORG_5').val($('#ORGANIZATION_SOURCE option[value="' + AC.substring(0,end) + '"]').val());
        }
	},
	
	// This function/method shows and hides the Add Grade button
	toggleAddGrade: function(show){
		$('#GRADE_GRID input.addGrade').addClass('hidden');
		if(show){
			$('#GRADE_GRID input.addGrade').removeClass('hidden');
		}
	},
	
	/**
	 * This function/method shows and hides Grade Rows
	 * 
	 * @param idx - index of row
	 * @param show - Bollean value to show (true) hide (false, null)
	 *
	 */
	toggleGradeRow: function(idx,show){
		var $lblRow = $(classificationGEN.grades[idx].lbl).closest('tr');
		var $fldRow = $lblRow.next('tr');
		if(show){
			var sel = $(classificationGEN.grades[idx].id).val();
			$lblRow.removeClass('hidden');
			$fldRow.removeClass('hidden');
			$(classificationGEN.grades[idx].id).attr('_required', true).on('change', classificationGEN.setGradeOptions).trigger('change');

		}else{
			$lblRow.addClass('hidden');
			$fldRow.addClass('hidden');
		}
	},
	
	// Hides and shows the Classification date based on the PD Number/Job Code having a value
	toggleClassDate: function($fld){
		var idx = $fld.attr('id').slice(-1) -1;
		if($(classificationGEN.grades[idx].pdn).val().length > 0){
			$(classificationGEN.grades[idx].cdtl).removeClass('hidden');
			$(classificationGEN.grades[idx].cdta).removeClass('hidden');
			$(classificationGEN.grades[idx].cdt).removeClass('hidden').attr('_required',true);
		}else{
			$(classificationGEN.grades[idx].cdtl).addClass('hidden');
			$(classificationGEN.grades[idx].cdta).addClass('hidden');
			$(classificationGEN.grades[idx].cdt).addClass('hidden').attr('_required',false).val('');
		}
	},

	// This function/method toggles the disable flag for PCA/PDP to brevent selection of both 
	togglePCAPDP: function(){
		$('#PD_PCA').attr('disabled', false);
		$('#PD_PDP').attr('disabled', false);
		if($('#PD_PDP')[0].checked){
			$('#PD_PCA').attr('checked',false).attr('disabled', true);
		}
		if($('#PD_PCA')[0].checked){
			$('#PD_PDP').attr('checked',false).attr('disabled', true);
		}
	},
	// Show or hide PCA, PDP checkboxes depending on Pay Plan and Occupational Series. Show for GS-0602 or GS-0680.  Hide otherwise.
	showHidePcaPdp: function(){
        if ( $("#CS_PAY_PLAN_ID").val() == "GS"
				&& ($("#CS_SR_ID").val() == "0602" || $("#CS_SR_ID").val() == "0680") ) {
			$("#pca_group").show();
			$("#pdp_group").show();
		} else {
			$("#pca_group").hide();
			$("#pdp_group").hide();
			// clear value when hiding the field
			$("#PD_PCA").prop("checked", false);
			$("#PD_PDP").prop("checked", false);
			classificationGEN.togglePCAPDP();
		}
	}
	,
	toggleFTTOUTSTATION: function(){
		$('#FTT').attr('disabled', false);
		$('#OUTSTATION').attr('disabled', false);
		if($('#FTT')[0].checked){
			$('#OUTSTATION').attr('checked',false).attr('disabled', true);
		}
		if($('#OUTSTATION')[0].checked){
			$('#FTT').attr('checked',false).attr('disabled', true);
		}
	},
	
	// Sets default option for certain select elements.
	setDefaultSelect: function(){
		// set default for Employing Office Location select box
		if ($("#EMPLOYING_OFFICE_LOCATION option:selected").length <= 0 || $("#EMPLOYING_OFFICE_LOCATION option:selected").text() == "Select One"){
			$("#EMPLOYING_OFFICE_LOCATION option").filter(function(){ return $(this).text() == "Woodlawn, MD"; }).prop("selected", true);
		}
	},

	// Sets tabindex of datePickerIcon relative to the associated textbox's.
	// * Note: This function should be called after the page is loaded completely, i.e. all available date fields are created.
	// * Assumption: The tabindex of the elements after the date field should be set with this increment in mind. 
	setDateIconTabOrder: function(){
		var dateTextBoxes = $("input.textbox[_type=date]");
		$.each(dateTextBoxes, function(index, control) {
			var tabIndex = $(control).attr("tabindex");
			if ($.isNumeric(tabIndex) && tabIndex > 0) {
				var controlID = $(control).attr("id");
				var newTabIndex = tabIndex * 1 + 1;
				$("#" + controlID + "_calendar_anchor").attr("tabindex", newTabIndex);
			}
		});
	},

	// Init function/method called from On PageLoad; performs various activities to setup the page UI, hide/show fields
	init: function(){
		this.setDefaultSelect();
		classificationGEN.setAutoComplete();
		classificationGEN.manageOrganization();
        $('#general_group').on('focus','input.disabled',$(this).blur());
		$('#CS_PAY_PLAN_ID').on('change', classificationGEN.payPlanChange);
		$("#CS_SR_ID").on("change", classificationGEN.occupationSeriesChange);
		$('#GRADE_GRID').on('click','input.removeGrade' ,function(){
			classificationGEN.removeGrade($(this).attr('id').slice(-1) -1);
		});
		$('#GRADE_GRID').on('click', 'input.addGrade',classificationGEN.addGrade);
		$("#CS_AC_DISP").on("click keyup", "img", function () {
			if (event.type == "keyup" && !(event.key == " " || event.key == "Enter")) return; 
			$("#CS_AC_DISP").addClass('hidden').empty();;	
			$("#CS_ADMIN_CD_INPUT_container").removeClass('hidden');
			$("#CS_ADMIN_CD_INPUT").attr('_required', 'true');
			$('#CS_ADMIN_CD').val('');
			classificationGEN.manageOrganization();
			$("#CS_ADMIN_CD_INPUT").focus(); // after current selection value is removed, set focus to autocomplete field
		});
		$('#PD_PDP').on('click',classificationGEN.togglePCAPDP);
		$('#PD_PCA').on('click',classificationGEN.togglePCAPDP);
		$('#FTT').on('click',classificationGEN.toggleFTTOUTSTATION);
		$('#OUTSTATION').on('click',classificationGEN.toggleFTTOUTSTATION);
        
		$('#GRADE_GRID').on('change', 'input, select', function(){
			$("#flsa_ex_main_lg").trigger('FLSAUpdate');
			$("#flsa_noex_main_lg").trigger('FLSAUpdate');
		});
		$('#CS_TITLE, #PD_ORG_POS_TITLE').on('keyup keypress blur change', function(){
            var pos = $(this).position();
            if($(this).val().length == 140){
                $('#TITLE_MAX').remove();
                $(this).after("<span id='TITLE_MAX' class='limitAlert'>140 Character Max Reached</span>");
                $('#TITLE_MAX').css({top: pos.top + 20, left: pos.left + 30, position:'absolute'});
                setTimeout(function() {
                    $('#TITLE_MAX').remove();
                }, 1000);
            }
        });
        $("#PD_REMARKS").on('keyup keypress blur change', function() { 
   			var currRemarkLength = $(this).val().length;
   			if (currRemarkLength > classificationGEN.remarksMaxChars) {
   				$(this).val($(this).val().substring(0, classificationGEN.remarksMaxChars));
  			}	
		});
		$('#CS_PAY_PLAN_ID').trigger('change');
		this.togglePCAPDP();
		classificationGEN.showHidePcaPdp();
		//this.setDateIconTabOrder();
		classificationGEN.showHideStaffSpecialistGroup();
		classificationGEN.showHideClassificationSpecialistGroup();
	}
}
