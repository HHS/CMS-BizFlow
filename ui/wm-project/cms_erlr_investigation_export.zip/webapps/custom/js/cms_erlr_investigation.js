(function(window){
	'use strict';
	function cms_investigation(){
		
	 function init(){
		$('#I_MISCONDUCT_FOUND').on('change',function(e){
			var value;
				try{
					 value = e.target.options[e.target.options.selectedIndex].value;
					 if(value !== 'undefined' && value === 'No'){
						 $('#tab_control_tab_tab7').show();
					 }else if(value !== 'undefined' && value === 'Yes'){
						$('#CC_CONDUCT_FOUND').show(); 
					 }else{
						 $('#tab_control_tab_tab7').hide();
						 $('#CC_CONDUCT_FOUND').hide(); 
					 }
				}catch(error){
					console.log('Error:',error);
				}
		});
	 }
	 function render(){
		 var misconduct = FormState.getElementValue('I_MISCONDUCT_FOUND');
		 if(misconduct !== 'undefined' && misconduct === 'No'){
				$('#tab_control_tab_tab7').show();
			 }else if(misconduct !== 'undefined' && misconduct === 'Yes'){
				$('#CC_CONDUCT_FOUND').show(); 
			 }else{
				 $('#tab_control_tab_tab7').hide();
				 $('#CC_CONDUCT_FOUND').hide(); 
			 }
	 }
		return{
			init : init,
			render : render
		}
	}
	(window.cms_investigation !== undefined ? window.cms_investigation : (window.cms_investigation = cms_investigation()));
})(window)