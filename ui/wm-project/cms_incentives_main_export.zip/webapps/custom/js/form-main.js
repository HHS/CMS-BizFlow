'use strict';

(function (window) {
    var USER_GROUP_KEY = {
        HR_CLASSIFICATION_SPECIALISTS: 'HR Classification Specialists',
        EXECUTIVE_OFFICERS: 'Executive Officers',
        HR_LIAISON: 'HR Liaison',
        HR_STAFFING_SPECIALISTS: 'HR Staffing Specialists',
        SELECTING_OFFICIALS: 'Selecting Officials',
        STANDARD_USER_GROUP: 'Standard User Group',
        DWC: 'DWC',
        ADMIN_STEAM: 'Admin Team',
        HR_SPECIAL_PROGRAMS: 'HR Special Programs',
        DCO_MANAGERS_AND_LEADS: 'DCO Managers and Leads',
        DCO_MANAGERS_ONLY: 'DCO Managers Only',
        REPORT_PILOT_TESTERS: 'Report Pilot Testers',
        HR_SPECIALISTS: 'HR Specialists',
        TABG_DIRECTORS: 'TABG Directors',
        OHC_DIRECTORS: 'OHC Directors',
        OFM_DIRECTORS: 'OFM Directors',
        CHIEF_PHYSICIANS: 'Chief Physicians',
        OFFICE_OF_THE_ADMINISTRATORS: 'Office of the Administrators',
        DGHO_DIRECTORS: 'DGHO Directors'
    };

    var ACTIVITY_NAME = {
        START_NEW: 'Start New',
        SO_REVIEW: 'Selecting Official Reviews Request',
        HRS_REVIEW: 'HR Specialist Reviews Request',
        DGHO_REVIEW: 'DGHO Director/Deputy Director Reviews Request',
        CP_REVIEW: 'CP Reviews Request',
        OFM_REVIEW: 'OFM Director/Deputy Director Reviews Request',
        TABG_REVIEW: 'TABG Director/Deputy Director Reviews Request',
        OHC_REVIEW: 'OHC Director/Deputy Director Reviews Request',
        OA_REVIEW: 'OA Reviews Request',
        HRS_RECORD_CONCLUSION: 'HR Specialist Records Candidate Acceptance or Rejection'
    };

    var ATTACHMENT_CATEGORY = {
        PCA_COVERSHEET: 'PD Coversheet/OF-8'
    };

    var NOT_DELETABLEATT_ACHMENT_CATEGORY = [
        ATTACHMENT_CATEGORY.PCA_COVERSHEET
    ];

    function MyInfo() {
        var myName = null;
        var myId = null;

        this.getMyName = function () {
            myName = myName || $("#h_currentUserName").val();
            return myName;
        };
        this.getMyMemberId = function () {
            myId = myId || $("#h_currentUserMemberID").val();
            return myId;
        };
        this.isSO = function () {
            return MyUserGroupManager.isUserMemberOf(USER_GROUP_KEY.SELECTING_OFFICIALS);
        };
        this.isXO = function () {
            return MyUserGroupManager.isUserMemberOf(USER_GROUP_KEY.EXECUTIVE_OFFICERS);
        };
        this.isHRL = function () {
            return MyUserGroupManager.isUserMemberOf(USER_GROUP_KEY.HR_LIAISON);
        };
        this.isHRS = function () {
            return MyUserGroupManager.isUserMemberOf(USER_GROUP_KEY.HR_SPECIALISTS);
        };
        this.isDGHO = function () {
            return MyUserGroupManager.isUserMemberOf(USER_GROUP_KEY.DGHO_DIRECTORS);
        };
        this.isCP = function () {
            return MyUserGroupManager.isUserMemberOf(USER_GROUP_KEY.CHIEF_PHYSICIANS);
        };
        this.isOFM = function () {
            return MyUserGroupManager.isUserMemberOf(USER_GROUP_KEY.OFM_DIRECTORS);
        };
        this.isTABG = function () {
            return MyUserGroupManager.isUserMemberOf(USER_GROUP_KEY.TABG_DIRECTORS);
        };
        this.isOHC = function () {
            return MyUserGroupManager.isUserMemberOf(USER_GROUP_KEY.OHC_DIRECTORS);
        };
        this.isOffAdmin = function () {
            return MyUserGroupManager.isUserMemberOf(USER_GROUP_KEY.OFFICE_OF_THE_ADMINISTRATORS);
        };
        this.isComponent = function () {
            return this.isHRL() || this.isXO() || this.isSO();
        }
    }

    function AccessControl() {
        this.isDesignator = function (name) {
            var designator = FormState.getElementSingleValue(name);
            return designator && designator.id === myInfo.getMyMemberId();
        };
        this.isDesignatedSO = function () {
            return this.isDesignator("selectingOfficial");
        };
        this.isDesignatedDGHO = function () {
            return this.isDesignator("dghoDirector");
        };
        this.isDesignatedCP = function () {
            return this.isDesignator("chiefPhysician");
        };
        this.isDesignatedOHC = function () {
            return this.isDesignator("ohcDirector");
        };
        this.isDesignatedOFM = function () {
            return this.isDesignator("ofmDirector");
        };
        this.isDesignatedOffAdmin = function () {
            return this.isDesignator("offAdmin");
        };
        this.isDesignatedTABG = function () {
            return this.isDesignator("tabgDirector");
        };
    }

    var _initializer1 = window.USER_GROUP_KEY || (window.USER_GROUP_KEY = USER_GROUP_KEY);
    var _initializer2 = window.ACTIVITY_NAME || (window.ACTIVITY_NAME = ACTIVITY_NAME);
    var _initializer3 = window.ATTACHMENT_CATEGORY || (window.ATTACHMENT_CATEGORY = ATTACHMENT_CATEGORY);
    var _initializer4 = window.NOT_DELETABLEATT_ACHMENT_CATEGORY || (window.NOT_DELETABLEATT_ACHMENT_CATEGORY = NOT_DELETABLEATT_ACHMENT_CATEGORY);
    var _initializer5 = window.myInfo || (window.myInfo = new MyInfo());
    var _initializer6 = window.accessControl || (window.accessControl = new AccessControl());
})(window);

/** * Define Tabs and Activities */
(function (window) {
    var tab1 = new Tab('tab1', 'General', '/cms_incentives_form1/loadGeneralForm.do', 'partial_tab1', true, ['/cms_incentives_form1/custom/js/form1.js']);

    tab1.onInit = function (readOnly) {
        cms_incentives_general.init(readOnly);
    };
    tab1.renderer = function () {
        cms_incentives_general.render();
    };

    var tab2 = new Tab('tab2', 'Position', '/cms_incentives_form2/loadPositionForm.do', 'partial_tab2', true, ['/cms_incentives_form2/custom/js/form2.js']);
    tab2.onInit = function (readOnly) {
        cms_incentives_position.init(readOnly);
    };
    tab2.renderer = function () {
        cms_incentives_position.render();
    };

    var tab3 = new Tab('tab3', 'PCADetails', '/cms_incentives_form3/loadPCADetails.do', 'partial_tab3', true, ['/cms_incentives_form3/custom/js/form3.js']);
    tab3.onInit = function (readOnly) {
        cms_incentives_pca_details.init(readOnly);
    };
    tab3.renderer = function () {
        cms_incentives_pca_details.render();
    };

    var tab4 = new Tab('tab4', 'Review', '/cms_incentives_form4/loadReview.do', 'partial_tab4', true, ['/cms_incentives_form4/custom/js/form4.js']);
    tab4.onInit = function (readOnly) {
        cms_incentives_review.init(readOnly);
    };
    tab4.renderer = function () {
        cms_incentives_review.render();
    };

    var tab5 = new Tab('tab5', 'Approve', '/cms_incentives_form5/loadApprove.do', 'partial_tab5', true, ['/cms_incentives_form5/custom/js/form5.js']);
    tab5.onInit = function (readOnly) {
        cms_incentives_approve.init(readOnly);
    };
    tab5.renderer = function () {
        cms_incentives_approve.render();
    };

    var tab9 = new Tab('tab9', 'Documents', '/cms_common/showAttachment.do', 'partial_tab9');
    tab9.validator = function () {
        return 'false' !== $('#h_mandatoryDocumentsValid').val();
    };

    var tabs = [tab1, tab2, tab3, tab4, tab5, tab9];

    function getActivityReadOnlyTabIds() {
        var activity = ActivityManager.getActivity();
        var readOnlyTabIds = [];

        if (myInfo.isHRS()) {

        } else if (myInfo.isComponent()) {
            if (activity.index > 0) {
                readOnlyTabIds = ['tab1', 'tab2', 'tab3', 'tab5', 'tab9'];
            }
        } else {
            if (activity.index > 0) {
                readOnlyTabIds = ['tab1', 'tab2', 'tab3', 'tab9'];
            }
        }

        return readOnlyTabIds;

    }

    /** * Define Activities */
    var activity1 = new Activity(ACTIVITY_NAME.START_NEW, ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab9'], ['tab9'], ['tab4', 'tab5']);
    var activity2 = new Activity(ACTIVITY_NAME.SO_REVIEW, ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab9'], ['tab9'], getActivityReadOnlyTabIds);
    var activity3 = new Activity(ACTIVITY_NAME.HRS_REVIEW, ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab9'], ['tab9'], getActivityReadOnlyTabIds);
    var activity4 = new Activity(ACTIVITY_NAME.DGHO_REVIEW, ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab9'], ['tab9'], getActivityReadOnlyTabIds);
    var activity5 = new Activity(ACTIVITY_NAME.CP_REVIEW, ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab9'], ['tab9'], getActivityReadOnlyTabIds);
    var activity6 = new Activity(ACTIVITY_NAME.OFM_REVIEW, ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab9'], ['tab9'], getActivityReadOnlyTabIds);
    var activity7 = new Activity(ACTIVITY_NAME.TABG_REVIEW, ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab9'], ['tab9'], getActivityReadOnlyTabIds);
    var activity8 = new Activity(ACTIVITY_NAME.OHC_REVIEW, ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab9'], ['tab9'], getActivityReadOnlyTabIds);
    var activity9 = new Activity(ACTIVITY_NAME.OA_REVIEW, ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab9'], ['tab9'], getActivityReadOnlyTabIds);
    var activity10 = new Activity(ACTIVITY_NAME.HRS_RECORD_CONCLUSION, ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab9'], ['tab9'], getActivityReadOnlyTabIds);
    var activities = [activity1, activity2, activity3, activity4, activity5, activity6, activity7, activity8, activity9, activity10];

    /** * Creating activityTabDefinition and initialize */
    var activityTabDefinition = window.activityTabDefinition || (window.activityTabDefinition = new ActivityTabDefinition(tabs, activities));
    FormLog.setLogLevel(FormLog.LOG_LEVEL.INFO);
    FormRequire.loadScripts(activityTabDefinition.tabs);
})(window);

(function (window) {
    /** * Form Main Object. This is main object that starts a form. */
    var FormMain = function () {
        function formRenderer() {
        }

        function updateStatusBar(requestNumber, requestDate, incentiveType, requestStatus) {
            $('#output_requestNumber').text(requestNumber);
            $('#output_requestDate').text(requestDate);
            $('#output_incentiveType').text(incentiveType);
            $('#output_requestStatus').text(requestStatus);
        }

        function initStatusBar() {
            var requestNumber = FormState.getElementValue('requestNumber');
            var requestDate = FormUtility.getLocalDateString(FormState.getElementValue('requestDate'), 'mm/dd/yyyy');
            var incentiveType = FormState.getElementValue('incentiveType');
            var requestStatus = FormState.getElementValue('requestStatus');
            updateStatusBar(requestNumber, requestDate, incentiveType, requestStatus);
        }

        function setSubmitButtonLabel(opt) {
            if (ActivityManager.getActivity().index > 0) {
                opt = opt || {};
                var button = document.getElementById("button_SubmitWorkitem");
                var incentiveType = undefined !== opt.incentiveType ? opt.incentiveType : FormState.getElementValue('incentiveType');
                var label = "Submit";
                if ("PCA" === incentiveType) {
                    label = "Send to HR";
                    var activity = ActivityManager.getActivityName();
                    var requireAdminApproval = undefined !== opt.requireAdminApproval ? opt.requireAdminApproval : FormState.getElementValue('requireAdminApproval');
                    var isRequireAdminApproval = "Yes" === requireAdminApproval;
                    if (activity === ACTIVITY_NAME.HRS_REVIEW) {
                        var returnFrom = FormUtility.getInputElementValue("pv_returnFrom", '');
                        if (returnFrom === "") {
                            returnFrom = "DGHO";
                        } else if (returnFrom === "CP") {
                            returnFrom = "Chief Physician";
                        } else if (returnFrom === "OA") {
                            returnFrom = "Administrator";
                        }

                        label = "Send to " + returnFrom;

                    } else if (activity === ACTIVITY_NAME.DGHO_REVIEW) {
                        label = "Send to Chief Physician";
                    } else if (activity === ACTIVITY_NAME.CP_REVIEW) {
                        label = "Send to OFM";
                    } else if (activity === ACTIVITY_NAME.OFM_REVIEW) {
                        label = "Send to TABG";
                    } else if (activity === ACTIVITY_NAME.TABG_REVIEW) {
                        if (isRequireAdminApproval) {
                            label = "Send to OHC";
                        }
                    } else if (activity === ACTIVITY_NAME.OHC_REVIEW) {
                        label = "Send to Administrator";
                    }
                }
                button.value = label;
            }
        }

        function setButtonVisibility() {
            var activity = ActivityManager.getActivityName();
            var show = activity === ACTIVITY_NAME.DGHO_REVIEW
                || activity === ACTIVITY_NAME.CP_REVIEW
                || activity === ACTIVITY_NAME.OFM_REVIEW
                || activity === ACTIVITY_NAME.TABG_REVIEW
                || activity === ACTIVITY_NAME.OHC_REVIEW
                || activity === ACTIVITY_NAME.OA_REVIEW;

            hyf.util.setComponentVisibility('button_ReturnForModification', show);
        }

        function initForm() {
            initStatusBar();
            setSubmitButtonLabel();
            setButtonVisibility();
        }

        function onTabChange(e) {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "FormMain::onTabChange, e ==> ", e);

            if (FormUtility.isReadOnly() == false) {
                var requestNumber = FormState.getElementValue('requestNumber');
                if (requestNumber == null || requestNumber.length == 0) {
                    $('#h_now').val(FormUtility.getNowUTCString());
                    FormUtility.loadPartialPage('getRequestNumber.do', "system", 'layoutForResponse');
                }
            }
        }

        function getProcessInfo() {
            return {
                user: {
                    id: FormUtility.getInputElementValue('h_currentUserMemberID'),
                    name: FormUtility.getInputElementValue('h_currentUserName')
                },
                process: {
                    id: FormUtility.getInputElementValue('h_procid'),
                    definitionName: FormUtility.getInputElementValue('h_definitionName')
                },
                activity: {
                    name: FormUtility.getInputElementValue('h_activityName'),
                    sequence: FormUtility.getInputElementValue('h_activitySeq')
                },
                workitem: {
                    participantId: FormUtility.getInputElementValue('h_witemParticipantID'),
                    participantName: FormUtility.getInputElementValue('h_witemParticipantName'),
                    sequence: FormUtility.getInputElementValue('h_witemSeq')
                }
            };
        }

        function saveProcessInfo(processInfo) {
            FormState.updateObjectValue("processName", processInfo.process.definitionName);
            FormState.updateObjectValue("processInfo", processInfo);
        }

        function init() {
            $('#main_buttons_layout_group').css('visibility', 'hidden');
            if (FormUtility.getInputElementValue('WIH_exit_requested') === 'true') {
                basicWIHActionClient.exit({confirmMsg: null});
            }
            $(document).on('ALL_TABS_LOADED', function () {
                $(document).on('ON_TAB_CHANGE', onTabChange);
            });

            var processInfo = getProcessInfo();
            var activityName = processInfo.activity.name;
            var formData = FormUtility.getInputElementValue('h_formData');
            var userGroups = FormUtility.getInputElementValue('h_userGroups', '', '');
            var userGroupMapping = FormUtility.getInputElementValue('h_userGroupMappingString', '', '');

            MyUserGroupManager.init(userGroups, userGroupMapping);
            LookupManager.init();
            FormManager.init(activityName, activityTabDefinition, formData, formRenderer);
            FormMainHandler.init(processInfo);
            DocumentRuleManager.init('cms-incentives-document-rules', 'Incentives', function () {
                return [{
                    "fieldId": "rule",
                    "fieldValue": "PCARequiredDocuments"
                }, {
                    "fieldId": "incentiveType",
                    "fieldValue": FormState.getElementValue('incentiveType', '')
                }, {
                    "fieldId": "requestType",
                    "fieldValue": FormState.getElementValue('requestType', '')
                }, {
                    "fieldId": "pcaType",
                    "fieldValue": FormState.getElementValue('pcaType', '')
                }, {
                    "fieldId": "requireBoardCert",
                    "fieldValue": FormState.getElementValue('requireBoardCert', '')
                }, {
                    "fieldId": "candiAgreeRenewal",
                    "fieldValue": FormState.getElementValue('candiAgreeRenewal', '')
                }];
            });

            saveProcessInfo(processInfo);
            initForm();

            $('a.selectedTab').focus();
        }

        // This function will be called after getRequestNumber.do is completed.
        function resetRequestNumber() {
            var requestNumber = FormUtility.getInputElementValue('h_response_requestNumber');
            var requestDate = FormUtility.getInputElementValue('h_now');
            var requestStatus = 'Request Created';

            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "FormMain::resetRequestNumber - requestNumber, requestDate, requestStatus ==> ", requestNumber, requestDate, requestStatus);

            FormState.updateObjectValue('requestNumber', requestNumber);
            FormState.updateObjectValue('requestDate', requestDate);
            FormState.updateObjectValue('requestStatus', requestStatus);

            FormMainHandler.saveFormData();

            initStatusBar();
        }

        return {
            init: init,
            resetRequestNumber: resetRequestNumber,
            setSubmitButtonLabel: setSubmitButtonLabel
        }
    };

    var _initializer = window.FormMain || (window.FormMain = FormMain());
})(window);

/** * An error message that shows up when there is any errors. */
var SYSTEM_ERROR_MESSAGE = "<h3 style='color:red'>Something went wrong</h3><p><h4>The system has encountered an error. Please try again, and if it still doesn't work, contact EWITS 2.0 help desk.</h4>";

$(document).ready(function () {
    try {
        FormMain.init();
    } catch (e) {
        FormLog.log(FormLog.LOG_LEVEL.ERROR, 'FormMain::init ==>', e);
        bootbox.alert({
            message: SYSTEM_ERROR_MESSAGE,
            callback: function () {
                basicWIHActionClient.exit({confirmMsg: null});
            }
        });
    }
});

$(document).ajaxError(function (event, request, settings, thrownError) {
    FormLog.log(FormLog.LOG_LEVEL.ERROR, 'ajaxError ==>', thrownError, request, settings);
    bootbox.alert(SYSTEM_ERROR_MESSAGE);
});

