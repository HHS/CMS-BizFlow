'use strict';

(function (window) {
    var USER_GROUP_KEY = {
        ADMIN_STEAM: 'Admin Team',
        DCO_MANAGERS_AND_LEADS: 'DCO Managers and Leads',
        DCO_MANAGERS_ONLY: 'DCO Managers Only',
        DWC: 'DWC',
        HR_SPECIAL_PROGRAMS: 'HR Special Programs',
        HR_STAFFING_SPECIALISTS: 'HR Staffing Specialists',
        REPORT_PILOT_TESTERS: 'Report Pilot Testers',
        STANDARD_USER_GROUP: 'Standard User Group',
        HR_CLASSIFICATION_SPECIALISTS: 'HR Classification Specialists',
        // Below are user groups Incentives use
        SELECTING_OFFICIALS: 'Selecting Officials',
        EXECUTIVE_OFFICERS: 'Executive Officers',
        HR_LIAISON: 'HR Liaison',
        HR_SPECIALISTS: 'HR Specialists',
        DGHO_DIRECTORS: 'DGHO Directors',
        CHIEF_PHYSICIANS: 'Chief Physicians',
        OFM_DIRECTORS: 'OFM Directors',
        TABG_DIRECTORS: 'TABG Directors',
        OHC_DIRECTORS: 'OHC Directors',
        OFFICE_OF_THE_ADMINISTRATORS: 'Office of the Administrators'
    };

    var PROCESS_NAME = {
        REQUEST: "Incentives Request",
        PCA: "PCA Incentives",
        SAM: "SAM Incentives",
        LE: "LE Incentives"
    };

    var ACTIVITY_NAME = {
        START_NEW: 'Start New',
        SO_REVIEW: 'Selecting Official Reviews Request',
        HRS_REVIEW: 'HR Specialist Reviews Request',
        DGHO_REVIEW: 'TABG Division Director Reviews Request',
        CP_REVIEW: 'CP Reviews Request',
        OFM_REVIEW: 'OFM Director/Deputy Director Reviews Request',
        TABG_REVIEW: 'TABG Director/Deputy Director Reviews Request',
        OHC_REVIEW: 'OHC Director/Deputy Director Reviews Request',
        OA_REVIEW: 'OA Reviews Request',
        HRS_RECORD_CONCLUSION: 'HR Specialist Records Candidate Acceptance or Rejection'
    };

    var ATTACHMENT_CATEGORY = {
        PCA_COVERSHEET: 'PD Coversheet/OF-8',
        FINAL_PD_PACKAGE: 'Final Position Description Package',
        OTHER: 'Other'
    };

    var NOT_DELETABLE_ATTACHMENT_CATEGORY = [
        ATTACHMENT_CATEGORY.PCA_COVERSHEET
    ];

    var NOT_ADDABLE_ATTACHMENT_CATEGORY = [
        ATTACHMENT_CATEGORY.PCA_COVERSHEET
        // , ATTACHMENT_CATEGORY.FINAL_PD_PACKAGE
    ];

    var LAST_ENTRY_ATTACHMENT_CATEGORY = [
        ATTACHMENT_CATEGORY.OTHER
    ];

    var INCENTIVES_TYPE = {
        PCA: "PCA",
        LE: "LE",
        SAM: "SAM"
    };

    var PCA_TYPE = {
        NEW: "New",
        RENEWAL: "Renewal"
    };

    var REQUEST_STATUS = {
        NEW: "Start New",
        CREATED: "Request Created"
    };

    var _initializer1 = window.USER_GROUP_KEY || (window.USER_GROUP_KEY = USER_GROUP_KEY);
    var _initializer2 = window.PROCESS_NAME || (window.PROCESS_NAME = PROCESS_NAME);
    var _initializer3 = window.ACTIVITY_NAME || (window.ACTIVITY_NAME = ACTIVITY_NAME);
    var _initializer4 = window.ATTACHMENT_CATEGORY || (window.ATTACHMENT_CATEGORY = ATTACHMENT_CATEGORY);
    var _initializer5 = window.NOT_DELETABLE_ATTACHMENT_CATEGORY || (window.NOT_DELETABLE_ATTACHMENT_CATEGORY = NOT_DELETABLE_ATTACHMENT_CATEGORY);
    var _initializer6 = window.NOT_ADDABLE_ATTACHMENT_CATEGORY || (window.NOT_ADDABLE_ATTACHMENT_CATEGORY = NOT_ADDABLE_ATTACHMENT_CATEGORY);
    var _initializer7 = window.LAST_ENTRY_ATTACHMENT_CATEGORY || (window.LAST_ENTRY_ATTACHMENT_CATEGORY = LAST_ENTRY_ATTACHMENT_CATEGORY);
    var _initializer8 = window.INCENTIVES_TYPE || (window.INCENTIVES_TYPE = INCENTIVES_TYPE);
    var _initializer9 = window.PCA_TYPE || (window.PCA_TYPE = PCA_TYPE);
    var _initializer10 = window.REQUEST_STATUS || (window.REQUEST_STATUS = REQUEST_STATUS);
})(window);

(function (window) {
    function MyInfo() {
        var myName = null;
        var myId = null;

        this.getMyName = function () {
            myName = myName || $("#h_currentUserName").val();
            return myName;
        };
        this.getMyMemberId = function () {
            myId = myId || $("#h_currentUserMemberID").val();
            return myId;
        };
        this.isSO = function () {
            return MyUserGroupManager.isUserMemberOf(USER_GROUP_KEY.SELECTING_OFFICIALS);
        };
        this.isXO = function () {
            return MyUserGroupManager.isUserMemberOf(USER_GROUP_KEY.EXECUTIVE_OFFICERS);
        };
        this.isHRL = function () {
            return MyUserGroupManager.isUserMemberOf(USER_GROUP_KEY.HR_LIAISON);
        };
        this.isHRS = function () {
            return MyUserGroupManager.isUserMemberOf(USER_GROUP_KEY.HR_SPECIALISTS);
        };
        this.isDGHO = function () {
            return MyUserGroupManager.isUserMemberOf(USER_GROUP_KEY.DGHO_DIRECTORS);
        };
        this.isCP = function () {
            return MyUserGroupManager.isUserMemberOf(USER_GROUP_KEY.CHIEF_PHYSICIANS);
        };
        this.isOFM = function () {
            return MyUserGroupManager.isUserMemberOf(USER_GROUP_KEY.OFM_DIRECTORS);
        };
        this.isTABG = function () {
            return MyUserGroupManager.isUserMemberOf(USER_GROUP_KEY.TABG_DIRECTORS);
        };
        this.isOHC = function () {
            return MyUserGroupManager.isUserMemberOf(USER_GROUP_KEY.OHC_DIRECTORS);
        };
        this.isOffAdmin = function () {
            return MyUserGroupManager.isUserMemberOf(USER_GROUP_KEY.OFFICE_OF_THE_ADMINISTRATORS);
        };
        this.isComponent = function () {
            return this.isHRL() || this.isXO() || this.isSO();
        }
    }

    var _initializer = window.myInfo || (window.myInfo = new MyInfo());
})(window);

(function (window) {
    function AccessControl() {
        this.isDesignator = function (name) {
            var designator = FormState.getElementSingleValue(name);
            return designator && designator.id === myInfo.getMyMemberId();
        };
        this.isDesignatedSO = function () {
            return this.isDesignator("selectingOfficial");
        };
        this.isDesignatedDGHO = function () {
            return this.isDesignator("dghoDirector");
        };
        this.isDesignatedCP = function () {
            return this.isDesignator("chiefPhysician");
        };
        this.isDesignatedOHC = function () {
            return this.isDesignator("ohcDirector");
        };
        this.isDesignatedOFM = function () {
            return this.isDesignator("ofmDirector");
        };
        this.isDesignatedOffAdmin = function () {
            return this.isDesignator("offAdmin");
        };
        this.isDesignatedTABG = function () {
            return this.isDesignator("tabgDirector");
        };
    }

    var _initializer = window.accessControl || (window.accessControl = new AccessControl());
})(window);

/** * Define Tabs and Activities */
(function (window) {
    var tab1 = new Tab('tab1', 'General', '/cms_incentives_form1/loadGeneralForm.do', 'partial_tab1', true, ['/cms_incentives_form1/custom/js/form1.js']);

    tab1.onInit = function (readOnly) {
        cms_incentives_general.init(readOnly);
    };
    tab1.renderer = function (action) {
        cms_incentives_general.render(action);
    };
    tab1.postDisableTab = function (afterAllTabLoaded) {
        cms_incentives_general.postDisableTab(afterAllTabLoaded);
    };

    var tab2 = new Tab('tab2', 'Position', '/cms_incentives_form2/loadPositionForm.do', 'partial_tab2', true, ['/cms_incentives_form2/custom/js/form2.js']);
    tab2.onInit = function (readOnly) {
        cms_incentives_position.init(readOnly);
    };
    tab2.renderer = function (action) {
        cms_incentives_position.render(action);
    };

    var tab3 = new Tab('tab3', 'PCADetails', '/cms_incentives_form3/loadPCADetails.do', 'partial_tab3', true, ['/cms_incentives_form3/custom/js/form3.js']);
    tab3.onInit = function (readOnly) {
        cms_incentives_pca_details.init(readOnly);
    };
    tab3.renderer = function (action) {
        cms_incentives_pca_details.render(action);
    };

    var tab4 = new Tab('tab4', 'PCAReview', '/cms_incentives_form4/loadPCAReview.do', 'partial_tab4', true, ['/cms_incentives_form4/custom/js/form4.js']);
    tab4.onInit = function (readOnly) {
        cms_incentives_pca_review.init(readOnly);
    };
    tab4.renderer = function (action) {
        cms_incentives_pca_review.render(action);
    };

    var tab5 = new Tab('tab5', 'PCAApproval', '/cms_incentives_form5/loadPCAApproval.do', 'partial_tab5', true, ['/cms_incentives_form5/custom/js/form5.js']);
    tab5.onInit = function (readOnly) {
        cms_incentives_pca_approval.init(readOnly);
    };
    tab5.renderer = function (action) {
        cms_incentives_pca_approval.render(action);
    };

    var tab6 = new Tab('tab6', 'SAMDetails', '/cms_incentives_form6/loadSAMDetails.do', 'partial_tab6', true, ['/cms_incentives_form6/custom/js/form6.js']);
    tab6.onInit = function (readOnly) {
        cms_incentives_sam_details.init(readOnly);
    };
    tab6.renderer = function (action) {
        cms_incentives_sam_details.render(action);
    };

    var tab7 = new Tab('tab7', 'Review', '/cms_incentives_form7/loadSAMReview.do', 'partial_tab7', true, ['/cms_incentives_form7/custom/js/form7.js']);
    tab7.onInit = function (readOnly) {
        cms_incentives_sam_review.init(readOnly);
    };
    tab7.renderer = function (action) {
        cms_incentives_sam_review.render(action);
    };

    var tab8 = new Tab('tab8', 'Review', '/cms_incentives_form8/loadSAMApproval.do', 'partial_tab8', true, ['/cms_incentives_form8/custom/js/form8.js']);
    tab8.onInit = function (readOnly) {
        cms_incentives_sam_approval.init(readOnly);
    };
    tab8.renderer = function (action) {
        cms_incentives_sam_approval.render(action);
    };

    var tab9 = new Tab('tab9', 'Documents', '/cms_common/showAttachment.do', 'partial_tab9');
    tab9.displayMissingRequiredFields = false;
    tab9.validator = function () {
        return 'true' === $('#h_mandatoryDocumentsValid').val();
    };

    var tabs = [tab1, tab2, tab3, tab4, tab5, tab6, tab7, tab8, tab9];

    function getActivityReadOnlyTabIds() {
        var activity = ActivityManager.getActivity();
        var readOnlyTabIds = [];

        if (myInfo.isHRS()) {

        } else if (myInfo.isComponent()) {
            if (activity.index > 0) {
                readOnlyTabIds = ['tab1', 'tab2', 'tab3', 'tab5', 'tab9'];
            }
        } else {
            if (activity.index > 0) {
                readOnlyTabIds = ['tab1', 'tab2', 'tab3', 'tab9'];
            }
        }

        return readOnlyTabIds;
    }

    /** * Define Activities */
    var activity1 = new Activity(ACTIVITY_NAME.START_NEW, ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab6', 'tab7', 'tab8', 'tab9'], ['tab9'], ['tab4', 'tab5']);
    var activity2 = new Activity(ACTIVITY_NAME.SO_REVIEW, ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab6', 'tab7', 'tab8', 'tab9'], ['tab9'], getActivityReadOnlyTabIds);
    var activity3 = new Activity(ACTIVITY_NAME.HRS_REVIEW, ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab6', 'tab7', 'tab8', 'tab9'], ['tab9'], getActivityReadOnlyTabIds);
    var activity4 = new Activity(ACTIVITY_NAME.DGHO_REVIEW, ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab6', 'tab7', 'tab8', 'tab9'], ['tab9'], getActivityReadOnlyTabIds);
    var activity5 = new Activity(ACTIVITY_NAME.CP_REVIEW, ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab6', 'tab7', 'tab8', 'tab9'], ['tab9'], getActivityReadOnlyTabIds);
    var activity6 = new Activity(ACTIVITY_NAME.OFM_REVIEW, ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab6', 'tab7', 'tab8', 'tab9'], ['tab9'], getActivityReadOnlyTabIds);
    var activity7 = new Activity(ACTIVITY_NAME.TABG_REVIEW, ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab6', 'tab7', 'tab8', 'tab9'], ['tab9'], getActivityReadOnlyTabIds);
    var activity8 = new Activity(ACTIVITY_NAME.OHC_REVIEW, ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab6', 'tab7', 'tab8', 'tab9'], ['tab9'], getActivityReadOnlyTabIds);
    var activity9 = new Activity(ACTIVITY_NAME.OA_REVIEW, ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab6', 'tab7', 'tab8', 'tab9'], ['tab9'], getActivityReadOnlyTabIds);
    var activity10 = new Activity(ACTIVITY_NAME.HRS_RECORD_CONCLUSION, ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab6', 'tab7', 'tab8', 'tab9'], ['tab9'], getActivityReadOnlyTabIds);
    var activities = [activity1, activity2, activity3, activity4, activity5, activity6, activity7, activity8, activity9, activity10];

    /** * Creating activityTabDefinition and initialize */
    var activityTabDefinition = window.activityTabDefinition || (window.activityTabDefinition = new ActivityTabDefinition(tabs, activities));
    FormLog.setLogLevel(FormLog.LOG_LEVEL.INFO);
    FormRequire.loadScripts(activityTabDefinition.tabs);
})(window);

(function (window) {
    /** * Form Main Object. This is main object that starts a form. */
    var FormMain = function () {
        var _processInfo;

        function formRenderer() {
        }

        function updateIncentiveTypeOutput(incentiveType) {
            $('#output_incentiveType').text(incentiveType);
        }

        function updateStatusBar(requestNumber, requestDate, incentiveType, requestStatus) {
            $('#output_requestNumber').text(requestNumber);
            $('#output_requestDate').text(requestDate);
            $('#output_requestStatus').text(requestStatus);
            updateIncentiveTypeOutput(incentiveType);
        }

        function initStatusBar() {
            var requestNumber = FormState.getElementValue('requestNumber');
            var requestDate = FormUtility.getLocalDateString(FormState.getElementValue('requestDate'), 'mm/dd/yyyy');
            var incentiveType = FormState.getElementValue('incentiveType');
            var requestStatus = FormState.getElementValue('requestStatus');
            updateStatusBar(requestNumber, requestDate, incentiveType, requestStatus);
        }

        function setSubmitButtonLabel(opt) {
            opt = opt || {};
            var button = document.getElementById("button_SubmitWorkitem");
            var incentiveType = undefined !== opt.incentiveType ? opt.incentiveType : FormState.getElementValue('incentiveType');
            var label = "Submit";
            var activity = ActivityManager.getActivityName();

            if (INCENTIVES_TYPE.PCA === incentiveType) {
                label = "Send to HR";
                var requireAdminApproval = undefined !== opt.requireAdminApproval ? opt.requireAdminApproval : FormState.getElementValue('requireAdminApproval');
                var isRequireAdminApproval = "Yes" === requireAdminApproval;
                if (activity === ACTIVITY_NAME.START_NEW) {
                    label = "Send to Selecting Official";
                } else if (activity === ACTIVITY_NAME.HRS_REVIEW) {
                    var returnFrom = FormUtility.getInputElementValue("pv_returnFrom", '');
                    if (returnFrom === "" || returnFrom === "DGHO") {
                        returnFrom = "Division Director";
                    } else if (returnFrom === "CP") {
                        returnFrom = "Chief Physician";
                    } else if (returnFrom === "OA") {
                        returnFrom = "Administrator";
                    }

                    label = "Send to " + returnFrom;
                } else if (activity === ACTIVITY_NAME.DGHO_REVIEW) {
                    label = "Send to Chief Physician";
                } else if (activity === ACTIVITY_NAME.CP_REVIEW) {
                    label = "Send to OFM";
                } else if (activity === ACTIVITY_NAME.OFM_REVIEW) {
                    label = "Send to TABG";
                } else if (activity === ACTIVITY_NAME.TABG_REVIEW) {
                    if (isRequireAdminApproval) {
                        label = "Send to OHC";
                    }
                } else if (activity === ACTIVITY_NAME.OHC_REVIEW) {
                    label = "Send to Administrator";
                } else if (activity === ACTIVITY_NAME.HRS_RECORD_CONCLUSION) {
                    label = "Send to Offer";
                }
            } else if (INCENTIVES_TYPE.SAM === incentiveType) {
                label = "Send to HR";
                if (activity === ACTIVITY_NAME.START_NEW) {
                    label = "Send to Component";
                } else if (activity === ACTIVITY_NAME.HRS_REVIEW) {
                    var returnFrom = FormUtility.getInputElementValue("pv_returnFrom", '');
                    if (returnFrom === "" || returnFrom === "TABG Div") {
                        returnFrom = "Division Director";
                    }

                    label = "Send to " + returnFrom;
                } else if (activity === ACTIVITY_NAME.DGHO_REVIEW) {
                    label = "Send to TABG";
                } else if (activity === ACTIVITY_NAME.TABG_REVIEW) {
                    label = "Send to OHC";
                } else if (activity === ACTIVITY_NAME.HRS_RECORD_CONCLUSION) {
                    label = "Send to Offer";
                }
            }
            button.value = label;
        }

        function setButtonVisibility() {
            var activity = ActivityManager.getActivityName();
            var show = activity === ACTIVITY_NAME.DGHO_REVIEW
                || activity === ACTIVITY_NAME.CP_REVIEW
                || activity === ACTIVITY_NAME.OFM_REVIEW
                || activity === ACTIVITY_NAME.TABG_REVIEW
                || activity === ACTIVITY_NAME.OHC_REVIEW
                || activity === ACTIVITY_NAME.OA_REVIEW;

            hyf.util.setComponentVisibility('button_ReturnForModification', show);
        }

        function showReturnReason() {
            var returnFrom = FormUtility.getInputElementValue("pv_returnFrom", '');
            var returnReason = FormState.getElementValue("returnReason");
            var returnedBy = FormState.getElementValue("returnedBy");
            if ('' !== returnFrom && returnReason && returnedBy) {
                var activity = ActivityManager.getActivityName();
                if (activity === ACTIVITY_NAME.HRS_REVIEW) {
                    bootbox.dialog({
                        title: 'Requested Changes by ' + returnedBy,
                        message: '<textarea disabled rows="5" class="bootbox-input bootbox-input-text form-control">' + returnReason + '</textarea>',
                        onEscape: true,
                        buttons: {
                            confirm: {
                                label: 'Close',
                                className: 'btn-success'
                            }
                        }
                    });
                }
            }
        }

        function initForm() {
            initStatusBar();
            setSubmitButtonLabel();
            setButtonVisibility();
        }

        function onSaveFormData() {
            if (FormUtility.isReadOnly() === false) {    // comment out by US219984
                var requestNumber = FormState.getElementValue('requestNumber');
                var associatedNEILRequest = FormState.getElementSingleValue("associatedNEILRequest", {requestNumber: ''});
                if (requestNumber !== associatedNEILRequest.requestNumber) {
                    FormState.updateObjectValue('requestNumber', associatedNEILRequest.requestNumber);
                    FormState.updateObjectValue('requestDate', associatedNEILRequest.requestNumber ? FormUtility.getNowUTCString() : '');
                    FormState.updateObjectValue('requestStatus', associatedNEILRequest.requestNumber ? REQUEST_STATUS.CREATED : REQUEST_STATUS.NEW);

                    initStatusBar();
                }
            }
        }

        function getProcessInfo() {
            if (_processInfo) return _processInfo;
            else {
                return {
                    user: {
                        id: FormUtility.getInputElementValue('h_currentUserMemberID'),
                        name: FormUtility.getInputElementValue('h_currentUserName')
                    },
                    process: {
                        id: FormUtility.getInputElementValue('h_procid'),
                        definitionName: FormUtility.getInputElementValue('h_definitionName')
                    },
                    activity: {
                        name: FormUtility.getInputElementValue('h_activityName'),
                        sequence: FormUtility.getInputElementValue('h_activitySeq')
                    },
                    workitem: {
                        participantId: FormUtility.getInputElementValue('h_witemParticipantID'),
                        participantName: FormUtility.getInputElementValue('h_witemParticipantName'),
                        sequence: FormUtility.getInputElementValue('h_witemSeq')
                    }
                };
            }
        }

        function saveProcessInfo(processInfo) {
            FormState.updateObjectValue("processName", processInfo.process.definitionName);
            FormState.updateObjectValue("processInfo", processInfo);
        }

        function init() {
            $('#main_buttons_layout_group').css('visibility', 'hidden');
            if (FormUtility.getInputElementValue('WIH_exit_requested') === 'true') {
                basicWIHActionClient.exit({confirmMsg: null});
            }

            _processInfo = getProcessInfo();
            var formData = FormUtility.getInputElementValue('h_formData');
            var userGroups = FormUtility.getInputElementValue('h_userGroups', '', '');
            var userGroupMapping = FormUtility.getInputElementValue('h_userGroupMappingString', '', '');

            MyUserGroupManager.init(userGroups, userGroupMapping);
            LookupManager.init();
            FormManager.init(_processInfo.activity.name, activityTabDefinition, formData, formRenderer);
            FormMainHandler.init(_processInfo);
            DocumentRuleManager.init('cms-incentives-document-rules', 'Incentives', function () {
                return [{
                    "fieldId": "rule",
                    "fieldValue": "PCARequiredDocuments"
                }, {
                    "fieldId": "incentiveType",
                    "fieldValue": FormState.getElementValue('incentiveType', '')
                }, {
                    "fieldId": "requestType",
                    "fieldValue": FormState.getElementValue('requestType', '')
                }, {
                    "fieldId": "pcaType",
                    "fieldValue": FormState.getElementValue('pcaType', '')
                }, {
                    "fieldId": "requireBoardCert",
                    "fieldValue": FormState.getElementValue('requireBoardCert', '')
                }, {
                    "fieldId": "candiAgreeRenewal",
                    "fieldValue": FormState.getElementValue('candiAgreeRenewal', '')
                }];
            });

            setTimeout(function () {
                showReturnReason();
            }, 10);

            saveProcessInfo(_processInfo);
            initForm();

            $('a.selectedTab').focus();
        }

        // This function will be called after getRequestNumber.do is completed.
        function resetRequestNumber() {
            var requestNumber = FormUtility.getInputElementValue('h_response_requestNumber');
            var requestDate = FormUtility.getInputElementValue('h_now');
            var requestStatus = REQUEST_STATUS.CREATED;

            FormState.updateObjectValue('requestNumber', requestNumber);
            FormState.updateObjectValue('requestDate', requestDate);
            FormState.updateObjectValue('requestStatus', requestStatus);

            FormMainHandler.saveFormData();

            initStatusBar();
        }

        return {
            init: init,
            getProcessInfo: getProcessInfo,
            onSaveFormData: onSaveFormData,
            resetRequestNumber: resetRequestNumber,
            setSubmitButtonLabel: setSubmitButtonLabel,
            updateIncentiveTypeOutput: updateIncentiveTypeOutput
        }
    };

    var _initializer = window.FormMain || (window.FormMain = FormMain());
})(window);

/** * An error message that shows up when there is any errors. */
var SYSTEM_ERROR_MESSAGE = "<h3 style='color:red'>Something went wrong</h3><p><h4>The system has encountered an error. Please try again, and if it still doesn't work, contact EWITS 2.0 help desk.</h4>";

$(document).ready(function () {
    try {
        FormMain.init();
    } catch (e) {
        FormLog.log(FormLog.LOG_LEVEL.ERROR, 'FormMain::init ==>', e);
        bootbox.alert({
            message: SYSTEM_ERROR_MESSAGE,
            callback: function () {
                basicWIHActionClient.exit({confirmMsg: null});
            }
        });
    }
});

$(document).ajaxError(function (event, request, settings, thrownError) {
    FormLog.log(FormLog.LOG_LEVEL.ERROR, 'ajaxError ==>', thrownError, request, settings);
    bootbox.alert(SYSTEM_ERROR_MESSAGE);
});

