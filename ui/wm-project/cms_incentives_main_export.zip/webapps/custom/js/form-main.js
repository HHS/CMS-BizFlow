'use strict';

(function (window) {
    'use strict';
    var USER_GROUP_KEY = {
        HR_CLASSIFICATION_SPECIALISTS: 'HR Classification Specialists',
        EXECUTIVE_OFFICERS: 'Executive Officers',
        HR_LIAISON: 'HR Liaison',
        HR_STAFFING_SPECIALISTS: 'HR Staffing Specialists',
        SELECTING_OFFICIALS: 'Selecting Officials',
        STANDARD_USER_GROUP: 'Standard User Group',
        DWC: 'DWC',
        ADMIN_STEAM: 'Admin Team',
        HR_SPECIAL_PROGRAMS: 'HR Special Programs',
        DCO_MANAGERS_AND_LEADS: 'DCO Managers and Leads',
        DCO_MANAGERS_ONLY: 'DCO Managers Only',
        REPORT_PILOT_TESTERS: 'Report Pilot Testers',
        HR_SPECIALISTS: 'HR Specialists',
        TABG_DIRECTORS: 'TABG Directors',
        OHC_DIRECTORS: 'OHC Directors',
        OFM_DIRECTORS: 'OFM Directors',
        CHIEF_MEDICAL_OFFICERS: 'Chief Medical Officers',
        OFFICE_OF_THE_ADMINISTRATORS: 'Office of the Administrators',
        DGO_DIRECTORS: 'DGO Directors'
    };
    var _initializer = window.USER_GROUP_KEY || (window.USER_GROUP_KEY = USER_GROUP_KEY);
})(window);

/**
 * Define Tabs and Activities
 * Set log level
 * Loading script files for tabs
 */
(function (window) {
    /**
     * Define tabs
     * @type {Tab}
     */
    var tab1 = new Tab('tab1', 'General', '/cms_incentives_form1/loadGeneralForm.do', 'partial_tab1', true, ['/cms_incentives_form1/custom/js/form1.js']);

    tab1.onInit = function () {
        cms_incentives_general.init();
    };
    tab1.renderer = function () {
        cms_incentives_general.render();
    };

    var tab2 = new Tab('tab2', 'Position', '/cms_incentives_form2/loadPositionForm.do', 'partial_tab2', true, ['/cms_incentives_form2/custom/js/form2.js']);
    tab2.onInit = function () {
        cms_incentives_position.init();
    };
    tab2.renderer = function () {
        cms_incentives_position.render();
    };

    var tab3 = new Tab('tab3', 'PCADetails', '/cms_incentives_form3/loadPCADetails.do', 'partial_tab3', true, ['/cms_incentives_form3/custom/js/form3.js']);
    tab3.onInit = function () {
        cms_incentives_pca_details.init();
    };
    tab3.renderer = function () {
        cms_incentives_pca_details.render();
    };

    var tab4 = new Tab('tab4', 'Review', '/cms_incentives_form4/loadReview.do', 'partial_tab4', true, ['/cms_incentives_form4/custom/js/form4.js']);
    tab4.onInit = function () {
        cms_incentives_review.init();
    };
    tab4.renderer = function () {
        cms_incentives_review.render();
    };

    var tab5 = new Tab('tab5', 'Approve', '/cms_incentives_form5/loadApprove.do', 'partial_tab5', true, ['/cms_incentives_form5/custom/js/form5.js']);
    tab5.onInit = function () {
        cms_incentives_approve.init();
    };
    tab5.renderer = function () {
        cms_incentives_approve.render();
    };

    var tab9 = new Tab('tab9', 'Documents', '/cms_common/showAttachment.do', 'partial_tab9');
    tab9.validator = function() {
        return 'true' === $('#h_mandatoryDocumentsValid').val();
    };

    var tabs = [tab1, tab2, tab3, tab4, tab5, tab9];

    /**
     * Define Activities
     * @type {Activity}
     */
    var activity1 = new Activity('Start New', ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab9'], ['tab9']);
    var activity2 = new Activity('Selecting Official Reviews Request', ['tab1', 'tab2', 'tab3', 'tab4', 'tab5', 'tab9'], ['tab9']);
    var activities = [activity1, activity2];

    /**
     * Creating activityTabDefinition and initialize
     * @type {ActivityTabDefinition}
     */
    var activityTabDefinition = window.activityTabDefinition || (window.activityTabDefinition = new ActivityTabDefinition(tabs, activities));
    // Set log level
    FormLog.setLogLevel(FormLog.LOG_LEVEL.INFO);
    // FormLog.setLogLevel(FormLog.LOG_LEVEL.DEBUG);
    // Load script files for each tab
    FormRequire.loadScripts(activityTabDefinition.tabs);
})(window);

(function (window) {
    'use strict';

    /**
     * Form Main Object. This is main object that starts a form.
     */
    var FormMain = function () {
        function formRenderer() {
        }

        function updateStatusBar(requestNumber, requestDate, incentiveType, requestStatus) {
            $('#output_requestNumber').text(requestNumber);
            $('#output_requestDate').text(requestDate);
            $('#output_incentiveType').text(incentiveType);
            $('#output_requestStatus').text(requestStatus);
        }

        function initStatusBar() {
            var requestNumber = FormState.getElementValue('requestNumber');
            var requestDate = FormUtility.getLocalDateString(FormState.getElementValue('requestDate'), 'mm/dd/yyyy');
            var incentiveType = FormState.getElementValue('incentiveType');
            var requestStatus = FormState.getElementValue('requestStatus');
            updateStatusBar(requestNumber, requestDate, incentiveType, requestStatus);
        }

        function initForm() {
            initStatusBar();
        }

        function controlButtonVisibility() {
            var tabId = TabManager.getSelectedTabID();

            if ('tab3' === tabId) {
                hyf.util.showComponent('button_GeneratePCACoversheet');
            } else {
                hyf.util.hideComponent('button_GeneratePCACoversheet');
            }

            if ('tab4' === tabId || 'tab5' === tabId) {
                hyf.util.showComponent('button_ReturnForModification');
            } else {
                hyf.util.hideComponent('button_ReturnForModification');
            }
        }

        function onTabChange(e) {
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, "FormMain::onTabChange, e ==> ", e);

            controlButtonVisibility();

            if (FormUtility.isReadOnly() == false) {
                var requestNumber = FormState.getElementValue('requestNumber');
                if (requestNumber == null || requestNumber.length == 0) {
                    $('#h_now').val(FormUtility.getNowUTCString());
                    FormUtility.loadPartialPage('getRequestNumber.do', "system", 'layoutForResponse');
                }
            }
        }

        function init() {
            // Hide main buttons while loading forms.
            $('#main_buttons_layout_group').css('visibility', 'hidden');
            // Initialize WIH exit option.
            if ($('#WIH_exit_requested').val() == 'true') {
                basicWIHActionClient.exit({confirmMsg: null});
            }
            // Register an event handler for ALL_TABS_LOADED
            $(document).on('ALL_TABS_LOADED', function () {
                $(document).on('ON_TAB_CHANGE', onTabChange);
            });

            // Get activity name
            var activityName = $('#h_activityName').val();
            // Set Title with activity name
            // $('#formTitle').text(activityName);
            // Get saved form data in db
            var formData = $('#h_formData').val();
            // Get current user's user groups
            var userGroups = $('#h_userGroups').val();
            $('#h_userGroups').val('');
            // Get user group mapping
            var userGroupMapping = $('#h_userGroupMappingString').val();

            // Initialize My User Group Manager
            MyUserGroupManager.init(userGroups, userGroupMapping);
            // Initialize Lookup Manager
            LookupManager.init();
            // Initialize Form Manager
            FormManager.init(activityName, activityTabDefinition, formData, formRenderer);
            // Initialize Form Main Handler
            FormMainHandler.init();
            // initialize DocumentRuleManager
            DocumentRuleManager.init('cms-incentives-document-rules', 'Incentives', function () {
                return [{
                    "fieldId": "rule",
                    "fieldValue": "PCARequiredDocuments"
                }, {
                    "fieldId": "incentiveType",
                    "fieldValue": FormState.getElementValue('incentiveType', '')
                }, {
                    "fieldId": "requestType",
                    "fieldValue": FormState.getElementValue('requestType', '')
                }, {
                    "fieldId": "pcaType",
                    "fieldValue": FormState.getElementValue('pcaType', '')
                }];
            });
            // Initialize form
            initForm();
            // Set focus to selected tab
            $('a.selectedTab').focus();
        }

        // This function will be called after getRequestNumber.do is completed.
        function resetRequestNumber() {
            var requestNumber = $('#h_response_requestNumber').val();
            var requestDate = $('#h_now').val();
            var requestStatus = 'Request Created';

            FormLog.log(FormLog.LOG_LEVEL.DEBUG, "FormMain::resetRequestNumber - requestNumber, requestDate, requestStatus ==> ", requestNumber, requestDate, requestStatus);

            FormState.updateObjectValue('requestNumber', requestNumber);
            FormState.updateObjectValue('requestDate', requestDate);
            FormState.updateObjectValue('requestStatus', requestStatus);

            initStatusBar();
        }

        return {
            init: init,
            resetRequestNumber: resetRequestNumber
        }
    };

    var _initializer = window.FormMain || (window.FormMain = FormMain());
})(window);

/**
 * An error message that shows up when there is any errors.
 * @type {string}
 */
var SYSTEM_ERROR_MESSAGE = "<h3 style='color:red'>Something went wrong</h3><p><h4>The system has encountered an error. Please try again, and if it still doesn't work, contact EWITS 2.0 help desk.</h4>";

$(document).ready(function () {
    try {
        FormMain.init();
    } catch (e) {
        FormLog.log(FormLog.LOG_LEVEL.ERROR, 'FormMain::init ==>', e);
        bootbox.alert({
            message: SYSTEM_ERROR_MESSAGE,
            callback: function () {
                basicWIHActionClient.exit({confirmMsg: null});
            }
        });
    }
});

$(document).ajaxError(function (event, request, settings, thrownError) {
    FormLog.log(FormLog.LOG_LEVEL.ERROR, 'ajaxError ==>', thrownError, request, settings);
    bootbox.alert(SYSTEM_ERROR_MESSAGE);
});

