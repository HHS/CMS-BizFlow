'use strict';

/** * This function to be called when the partial page is loaded. */
function onLoadResultActionWorkitem() {
    var errorMessage = $('#ResultActionWorkitemtErrorMessage').val();
    if (errorMessage && 0 < errorMessage.length) {
        if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.ERROR, 'onLoadResultActionWorkitem - ERROR ==>', errorMessage);
        bootbox.alert(SYSTEM_ERROR_MESSAGE);
    } else {
        basicWIHActionClient.setWIHOption('formSaved', true);
        var action = basicWIHActionClient.getWIHOption('requestAction');
        if (action === 'complete') {
            basicWIHActionClient.setContinue();
            basicWIHActionClient.setWIHOption('closeWihOnComplete', true);
            basicWIHActionClient.setWIHOption('completionWindow', false);
            basicWIHActionClient.complete();
        } else if (action === 'tabChange') {

        } else if (action === 'saveDraft') {
            basicWIHActionClient.notify('Your data has been successfully saved.', 3000);
        } else if (action === 'exit') {
            basicWIHActionClient.exit({confirmMsg: null});
        }

        basicWIHActionClient.setWIHOption('formSaved', undefined);
        basicWIHActionClient.setWIHOption('requestAction', undefined);
    }

    FormUtility.greyOutScreen(false);
}

(function (window) {
    /** * Form Main Handler. */
    var FormMainHandler = function () {
        var _contextPath = '/bizflowwebmaker';
        var _actionWorkitemDo = 'actionWorkitem.do';

        function ajaxSubmission(action, sourceGroup, targetGroup, validate) {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "FormMainHandler::ajaxSubmission - action, sourceGroup, targetGroup, validate ==>", action, sourceGroup, targetGroup, validate);
            if (window.location.pathname.indexOf(_contextPath) > -1 && action.indexOf('/') === 0) {
                action = _contextPath + action;
            }
            var objAction = {
                name: 'Action',
                option: 'Action',
                value: action
            };
            var objSourceGroup = null;
            if (typeof sourceGroup === 'undefined' || null === sourceGroup || '' === sourceGroup
                || 'all' === sourceGroup || 'ALL' === sourceGroup) {
                objSourceGroup = {name: 'SourceGroup', option: 'AllFormData', value: ''};
            } else {
                objSourceGroup = {name: 'SourceGroup', option: 'PageGroup', value: sourceGroup};
            }

            var partialPageContainerId = '_hidden_partial_page_container_';
            if (typeof targetGroup === 'undefined') {
                var partialPageContainer = document.createElement('div');
                if (document.getElementById(partialPageContainerId) === null) {
                    partialPageContainer.id = partialPageContainerId;
                    partialPageContainer.style.display = "none";
                    document.getElementsByTagName('body')[0].appendChild(partialPageContainer);
                }
            } else {
                partialPageContainerId = targetGroup;
            }

            var objTargetGroup = {
                name: 'TargetGroup',
                option: 'PageGroup',
                value: partialPageContainerId
            };
            var objValidate = {
                name: 'Validate',
                option: 'Static',
                value: validate ? validate : false
            };
            hyf.FMAction.handleAjaxSubmission(objAction, objSourceGroup, objTargetGroup, objValidate, {value: targetGroup});
        }

        function completeWorkitem(responseName, formValidation, formDataSelector_) {
            formDataSelector_ = formDataSelector_ || '#h_formData';
            var xml = FormState.getFinalStateXML();
            $(formDataSelector_).val(xml);

            if (typeof responseName !== 'undefined') {
                basicWIHActionClient.setResponseByName(responseName);
            }
            basicWIHActionClient.setWIHOption('requestAction', 'complete');
            if (!basicWIHActionClient.getWIHOption('formSaved')) {
                basicWIHActionClient.setWait();
                ajaxSubmission(_actionWorkitemDo + '?requestAction=' + responseName, 'all', undefined, formValidation);
            }
        }

        function initWIHPane(time_) {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'FormMainHandler::initWIHPane');
            setTimeout(function () {
                var ui = basicWIHActionClient.getUI();
                ui.getPane(ui.PANE_TOOL).open();
                ui.getPane(ui.PANE_TOOL).close();
                ui.getPane(ui.PANE_ATTACHMENT).hide();
                ui.getPane(ui.PANE_INTERNAL_DISCUSSION).open();
            }, time_ || 100);
        }

        function saveFormData() {
            $('#h_formData').val(FormState.getFinalStateXML());
            ajaxSubmission(_actionWorkitemDo);
        }

        function onTabChange(e) {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'FormMainHandler::onTabChange -  element ==>', e);

            if (FormUtility.isReadOnly() === false) {
                basicWIHActionClient.setWIHOption('requestAction', 'tabChange');
                saveFormData();
            }
        }

        function onAllTabLoaded() {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'FormMainHandler::onAllTabLoaded');
            if (!FormUtility.isReadOnly()) {
                hyf.util.showComponent('main_buttons_layout_group');
                hyf.util.showComponent('tab_container_group');

                var tabIdList = ActivityManager.getTabIdList();
                FormUtility.initMaxSize(tabIdList);
                FormUtility.setDateIconTabOrder(tabIdList);
                $(document).on('ON_TAB_CHANGE', onTabChange);
                if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'FormMainHandler::onAllTabLoaded - attach ON_TAB_CHANGE event to onTabChange');

                $('.datePickerIcon').each(function () {
                    var refId = $(this).attr('id').slice(0, -16);
                    var title = "Calendar icon used to select " + $('#' + refId + '_label').text() + " value";
                    $(this).attr('title', title);
                });

                initWIHPane();
            }
        }

        function saveForm(requestAction, currentTabIdSelector_) {
            currentTabIdSelector_ = currentTabIdSelector_ || '#h_currentTabID';
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'FormMainHandler::saveForm - requestAction, currentTabIdSelector ==>', requestAction, currentTabIdSelector_);

            $(currentTabIdSelector_).val(TabManager.getSelectedTabID()); // store current tabId to reset after page reload

            $('#h_formData').val(FormState.getFinalStateXML());

            if (typeof requestAction === 'string') {
                basicWIHActionClient.setWIHOption('requestAction', requestAction);
            }

            ajaxSubmission(_actionWorkitemDo);
        }

        function confirmClose(alertMsg_) {
            alertMsg_ = alertMsg_ || 'Would you like to save your entries before exit?';
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'FormMainHandler::confirmClose - msg ==>', alertMsg_);

            bootbox.dialog({
                message: '<p class="bootbox-body">' + alertMsg_ + '</p>',
                onEscape: true,
                buttons: [{
                    label: 'No',
                    callback: function () {
                        basicWIHActionClient.exit({confirmMsg: null});
                    }
                },
                    {
                        label: 'Yes, save and exit',
                        className: 'btn-primary',
                        callback: function () {
                            $('#WIH_exit_requested').val(true);
                            saveForm('exit');
                        }
                    }]
            });
        }

        function confirmCancel(reasonLookupType_, title_, msgWhenNotSelectReason_) {
            title_ = title_ || 'What is the reason for canceling this request?';
            msgWhenNotSelectReason_ = msgWhenNotSelectReason_ || 'Please select a cancellation reason';
            if (!reasonLookupType_) {
                if (myInfo.isHRS()) reasonLookupType_ = 'Incentives-CancellationReason';
                else if (myInfo.isComponent()) reasonLookupType_ = 'Incentives-CancellationReason2';
            }

            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'FormMainHandler::confirmCancel - reasonLookupType, title,msgWhenNotSelectReason ==>', reasonLookupType_, title_, msgWhenNotSelectReason_);

            var cancelReasons = reasonLookupType_ ? LookupManager.findByLTYPE(reasonLookupType_) : [];
            if (cancelReasons.length > 0) {
                var selectHTML = '<select class="form-control" id="cancelReason" name="cancelReason"><option value="">Select One</option>';
                for (var i = 0; i < cancelReasons.length; i++) {
                    selectHTML += '<option value="' + cancelReasons[i].NAME + '">' + cancelReasons[i].NAME + '</option>';
                }
                selectHTML += '</select>';

                bootbox.confirm({
                    title: title_,
                    message: selectHTML,
                    buttons: {
                        confirm: {
                            label: 'OK',
                            className: 'btn-success'
                        }
                    },
                    callback: function (result) {
                        if (result) {
                            var cancelReasonValue = $('#cancelReason').val();
                            if ('' === cancelReasonValue) {
                                bootbox.alert(msgWhenNotSelectReason_);
                            } else {
                                FormState.updateObjectValue('CancellationReason', cancelReasonValue);
                                completeWorkitem('Cancel', false);
                            }
                        }
                    }
                });
            } else {
                title_ = 'Are you sure you want to cancel this request?';
                $('#cancelReason').val('N/A');
                if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'FormMainHandler::confirmCancel - No CancellationReason lookup data, title ==> ', title_);

                bootbox.confirm(title_, function (result) {
                    if (result) {
                        FormState.updateObjectValue('CancellationReason', "N/A");
                        completeWorkitem('Cancel', false);
                    }
                });
            }
        }

        function attachClickToSaveWorkItem() {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'FormMainHandler::attachClickToSaveWorkItem');
            $('#button_SaveWorkitem').on('click', function () {
                saveForm('saveDraft');
            });
        }

        function attachClickToSubmitWorkItem(showAlertMsg_, alertMsg_) {
            showAlertMsg_ = showAlertMsg_ || true;
            alertMsg_ = alertMsg_ || 'Please fill in all the required fields before submit';
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'FormMainHandler::attachClickToSubmitWorkItem - showAlertMsg, alertMsg ==>', showAlertMsg_, alertMsg_);

            $('#button_SubmitWorkitem').off('click').click(function () {
                var isValidForm = true;
                var watchTabId = null;
                var activeTabs = ActivityManager.getTabIdList(ActivityManager.getActivityName());
                for (var tabIndex = 0; tabIndex < activeTabs.length; tabIndex++) {
                    watchTabId = activeTabs[tabIndex];
                    isValidForm = TabManager.validateTab(watchTabId);
                    if (isValidForm === false) {
                        break;
                    }
                }
                if (isValidForm) {
                    completeWorkitem('Submit', false);
                } else {
                    if (showAlertMsg_) {
                        bootbox.alert(alertMsg_);
                    }
                    $('#' + TabManager.getAnchorID(watchTabId)).click();
                }
            });
        }

        function attachClickToExitWIH() {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'FormMainHandler::attachClickToExitWIH');
            $('#button_ExitWIH').off('click').click(function (e) {
                confirmClose();
            });
        }

        function attachClickToCancelWIH() {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'FormMainHandler::attachClickToCancelWIH');
            $('#button_CancelWorkitem').off('click').click(function (e) {
                confirmCancel();
            });
        }

        function attachClickToPDF(alertMsg_) {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'FormMainHandler::attachClickToPDF');
            $('#button_PDF').off('click').click(function (e) {
                // Form validation
                var isValidForm = true;
                var watchTabId = null;
                var activeTabs = ActivityManager.getTabIdList(ActivityManager.getActivityName());
                for (var tabIndex = 0; tabIndex < activeTabs.length; tabIndex++) {
                    watchTabId = activeTabs[tabIndex];
                    isValidForm = TabManager.validateTab(watchTabId);
                    if (isValidForm === false) {
                        break;
                    }
                }
                if (isValidForm) {
                    completeWorkitem('Close', false);
                } else {
                    if (alertMsg_) {
                        bootbox.alert(alertMsg_);
                    }
                    $('#' + TabManager.getAnchorID(watchTabId)).click();
                }
            });
        }

        function init() {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "FormMainHandler::init");
            $(document).on('ALL_TABS_LOADED', onAllTabLoaded);

            hyf.util.showComponent('button_ExitWIH');
            hyf.util.showComponent('button_SaveWorkitem');
            hyf.util.showComponent('button_SubmitWorkitem');
            if (myInfo.isHRS() || (myInfo.isComponent() && ActivityManager.getActivity().index === 0)) {
                hyf.util.showComponent('button_CancelWorkitem');
            }

            attachClickToSaveWorkItem();
            attachClickToSubmitWorkItem();
            attachClickToExitWIH();
            attachClickToCancelWIH();
            attachClickToPDF();
        }

        return {
            contextPath: _contextPath,
            ajaxSubmission: ajaxSubmission,
            completeWorkitem: completeWorkitem,
            initWIHPane: initWIHPane,
            saveFormData: saveFormData,
            onTabChange: onTabChange,
            onAllTabLoaded: onAllTabLoaded,
            saveForm: saveForm,
            confirmClose: confirmClose,
            confirmCancel: confirmCancel,
            attachClickToSaveWorkItem: attachClickToSubmitWorkItem,
            attachClickToSubmitWorkItem: attachClickToSubmitWorkItem,
            attachClickToExitWIH: attachClickToExitWIH,
            attachClickToPDF: attachClickToPDF,
            init: init
        }
    };

    var _initializer = window.FormMainHandler || (window.FormMainHandler = FormMainHandler());
})(window);

