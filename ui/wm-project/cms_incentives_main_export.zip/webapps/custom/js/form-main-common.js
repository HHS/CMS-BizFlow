'use strict';

/** * This function to be called when the partial page is loaded. */
function onLoadResultActionWorkitem() {
    var errorMessage = $('#ResultActionWorkitemtErrorMessage').val();
    if (errorMessage && 0 < errorMessage.length) {
        bootbox.alert(SYSTEM_ERROR_MESSAGE);
    } else {
        basicWIHActionClient.setWIHOption('formSaved', true);
        var action = basicWIHActionClient.getWIHOption('requestAction');
        if (action === 'complete') {
            basicWIHActionClient.setContinue();
            basicWIHActionClient.setWIHOption('closeWihOnComplete', true);
            basicWIHActionClient.setWIHOption('completionWindow', false);
            basicWIHActionClient.complete();
        } else if (action === 'tabChange') {

        } else if (action === 'saveDraft') {
            basicWIHActionClient.notify('Your data has been successfully saved.', 3000);
        } else if (action === 'exit') {
            basicWIHActionClient.exit({confirmMsg: null});
        }

        basicWIHActionClient.setWIHOption('formSaved', undefined);
        basicWIHActionClient.setWIHOption('requestAction', undefined);
    }

    FormUtility.greyOutScreen(false);
}

(function (window) {
    /** * Form Attachment Handler. */
    var FormAttachmentHandler = function () {
        var _ctrl;
        var pcaButtons = [
            {
                id: "generate-pca-justification-worksheet",
                title: "Generate PCA Justification Worksheet",
                tooltip: "Click button to generate a PCA justification worksheet",
                style: "btn btn-primary btn-md",
                icon: "glyphicon glyphicon-file",
                handler: function () {
                    generatePCAJustificationWorksheet('PCA Justification Worksheet has been successfully added.');
                }
            }
        ];
        var samButtons = [
            {
                id: "generate-sam-justification-worksheet",
                title: "Generate SAM Justification Worksheet",
                tooltip: "Click button to generate a SAM justification worksheet",
                style: "btn btn-primary btn-md",
                icon: "glyphicon glyphicon-file",
                handler: function () {
                    generateSAMJustificationWorksheet('SAM Justification Worksheet has been successfully added.');
                }
            }
        ];
        var samchecklistButton = {
            id: "generate-sam-checklist",
            title: "Generate SAM Checklist",
            tooltip: "Click button to generate a SAM Checklist",
            style: "btn btn-primary btn-md",
            icon: "glyphicon glyphicon-file",
            handler: function () {
                generateSAMChecklist('SAM Checklist has been successfully added.');
            }
        };
        var leButtons = [
            {
                id: "generate-le-justification-worksheet",
                title: "Generate LE Justification Worksheet",
                tooltip: "Click button to generate a LE justification worksheet",
                style: "btn btn-primary btn-md",
                icon: "glyphicon glyphicon-file",
                handler: function () {
                    generateLEJustificationWorksheet('LE Justification Worksheet has been successfully added.');
                }
            }
        ];
        var lesaButton = {
            id: "generate-le-service-agreement",
            title: "Generate LE Service Agreement",
            tooltip: "Click button to generate a LE service agreement",
            style: "btn btn-primary btn-md",
            icon: "glyphicon glyphicon-file",
            handler: function () {
                generateLEServiceAgreement('LE Service Agreement has been successfully added.');
            }
        };

        function getAssociatedAttachmentCategories() {
            var categories = [];
            var associatedAttachments = FormState.getElementValue("associatedAttachments");
            if (associatedAttachments) {
                for (var i = 0; i < associatedAttachments.attachments.length; i++) {
                    var attachment = associatedAttachments.attachments[i];
                    categories.push(attachment.CATEGORY);
                }
            }

            return categories;
        }

        function doesHaveAssociatedAttachmentCategory(category) {
            var associatedAttachments = FormState.getElementValue("associatedAttachments");
            if (associatedAttachments) {
                for (var i = 0; i < associatedAttachments.attachments.length; i++) {
                    var attachment = associatedAttachments.attachments[i];
                    if (category === attachment.CATEGORY) {
                        return true;
                    }
                }
            }

            return false;
        }

        function initAssociatedAttachments() {
            if (_ctrl) {
                var associatedAttachments = FormState.getElementValue("associatedAttachments");
                if (associatedAttachments) {
                    if (associatedAttachments.attachments) {
                        if (!Array.isArray(associatedAttachments.attachments)) {
                            associatedAttachments.attachments = [associatedAttachments.attachments];
                        }
                        for (var i = 0; i < associatedAttachments.attachments.length; i++) {
                            var attachment = associatedAttachments.attachments[i];
                            attachment._creationDate = FormUtility.parseInt(attachment._creationDate, 0);
                            attachment.reviewed = "true" === attachment.reviewed;
                        }
                    }

                    associatedAttachments.readOnly = true;
                    associatedAttachments.showReviewed = true;
                    associatedAttachments.readOnlyReviewed = !activityStep.isHRSReview() && !activityStep.isHRSReviewForModification();
                    // associatedAttachments.enableCollapse = true;
                    _ctrl.associatedAttachments = JSON.parse(JSON.stringify(associatedAttachments));
                }
            }
        }

        function setAngularControl(ctrl) {
            _ctrl = ctrl;
        }

        function onInit() {
            initAssociatedAttachments();
        }

        function generatePCAJustificationWorksheet(msg, callback) {
            if (_ctrl) {
                var item = _ctrl.getBizFlowWih().getWorkitemContext();
                _ctrl.callGenerateDocument('/solutions/cms/incentives/generate_pca_justification_worksheet.jsp',
                    {
                        pid: item.Process.ID,
                        aseq: item.Activity.Sequence,
                        wseq: item.Workitem.Sequence,
                        p1: item.Process.ID
                    }, msg, callback);
            }
        }

        function generateSAMJustificationWorksheet(msg, callback) {
            if (_ctrl) {
                var item = _ctrl.getBizFlowWih().getWorkitemContext();
                _ctrl.callGenerateDocument('/solutions/cms/incentives/generate_sam_justification_worksheet.jsp',
                    {
                        pid: item.Process.ID,
                        aseq: item.Activity.Sequence,
                        wseq: item.Workitem.Sequence,
                        p1: item.Process.ID
                    }, msg, callback);
            }
        }

        function generateSAMChecklist(msg, callback) {
            if (_ctrl) {
                var item = _ctrl.getBizFlowWih().getWorkitemContext();
                _ctrl.callGenerateDocument('/solutions/cms/incentives/generate_sam_checklist.jsp',
                    {
                        pid: item.Process.ID,
                        aseq: item.Activity.Sequence,
                        wseq: item.Workitem.Sequence,
                        p1: item.Process.ID
                    }, msg, callback);
            }
        }

        function generateLEJustificationWorksheet(msg, callback) {
            if (_ctrl) {
                var item = _ctrl.getBizFlowWih().getWorkitemContext();
                _ctrl.callGenerateDocument('/solutions/cms/incentives/generate_le_justification_worksheet.jsp',
                    {
                        pid: item.Process.ID,
                        aseq: item.Activity.Sequence,
                        wseq: item.Workitem.Sequence,
                        p1: item.Process.ID
                    }, msg, callback);
            }
        }

        function generateLEServiceAgreement(msg, callback) {
            if (_ctrl) {
                var item = _ctrl.getBizFlowWih().getWorkitemContext();
                _ctrl.callGenerateDocument('/solutions/cms/incentives/generate_le_service_agreement.jsp',
                    {
                        pid: item.Process.ID,
                        aseq: item.Activity.Sequence,
                        wseq: item.Workitem.Sequence,
                        p1: item.Process.ID
                    }, msg, callback);
            }
        }

        function saveAssociatedAttachmentList(associatedAttachments) {
            _ctrl.associatedAttachments = associatedAttachments;
            FormState.updateObjectValue("associatedAttachments", JSON.parse(angular.toJson(_ctrl.associatedAttachments)));
        }

        function clearAssociatedAttachmentList() {
            if (_ctrl) {
                _ctrl.associatedAttachments = undefined;
            }
            FormState.updateObjectValue("associatedAttachments");
        }


        function getAssociatedAttachmentList(opt) {
            if (_ctrl) {
                clearAssociatedAttachmentList();
                _ctrl.callAttachmentService('/solutions/cms/incentives/get_attachment_list.jsp',
                    {
                        pid: opt.srcProcId
                    }, null, function (response) {
                        var associatedAttachments = response;
                        associatedAttachments.readOnly = true;
                        associatedAttachments.showReviewed = true;
                        associatedAttachments.readOnlyReviewed = !activityStep.isHRSReview() && !activityStep.isHRSReviewForModification();
                        saveAssociatedAttachmentList(associatedAttachments);
                    });
            }
        }

        function clickAttachmentReviewed(attachment) {
            FormState.updateObjectValue("associatedAttachments", JSON.parse(angular.toJson(_ctrl.associatedAttachments)));
        }

        function getCustomButtons() {
            if (!activityStep.isStartNew()) {
                if (INCENTIVES_TYPE.PCA === FormState.getElementValue("incentiveType")) {
                    return pcaButtons;
                } else if (INCENTIVES_TYPE.SAM === FormState.getElementValue("incentiveType")) {
                    var samCustomButtons = samButtons;
                    var supportSAM = FormState.getElementValue("approvalSOValue", "");
                    if ( "Approve" == supportSAM) {
                        samCustomButtons.push(samchecklistButton);
                    }
                    return samCustomButtons;
                } else if (INCENTIVES_TYPE.LE === FormState.getElementValue("incentiveType")) {
                    var leCustomButtons = leButtons;
                    if (activityStep.isHRSRecordConclusion()) {
                        leCustomButtons.push(lesaButton);
                    }
                    return leCustomButtons;
                }
            }
            return [];
        }

        function refreshCustomButtons(opt) {
            if (_ctrl) {
                opt = opt || {};
                var incentiveType = undefined !== opt.incentiveType ? opt.incentiveType : FormState.getElementValue('incentiveType');
                var buttons = [];
                if (!activityStep.isStartNew()) {
                    if (INCENTIVES_TYPE.PCA === incentiveType) {
                        buttons = pcaButtons;
                    } else if (INCENTIVES_TYPE.SAM === incentiveType) {
                        var samCustomButtons = samButtons;
                        var supportSAM = FormState.getElementValue("approvalSOValue", "");
                        if ( "Approve" == supportSAM) {
                            samCustomButtons.push(samchecklistButton);
                        }
                        buttons = samCustomButtons;
                    } else if (INCENTIVES_TYPE.LE === incentiveType) {
                        var leCustomButtons = leButtons;
                        if (activityStep.isHRSRecordConclusion()) {
                            leCustomButtons.push(lesaButton);
                        }
                        buttons = leCustomButtons;
                    }
                }
                _ctrl.updateCustomButtons(buttons);
            }
        }

        function isAttachmentDeletable(attachment) {
            var len = NOT_DELETABLE_ATTACHMENT_CATEGORY.length;
            for (var i = 0; i < len; i++) {
                if (NOT_DELETABLE_ATTACHMENT_CATEGORY[i] === attachment.CATEGORY) {
                    return false;
                } else if (attachment.WORKITEMSEQUENCE) {
                    var processInfo = FormMain.getProcessInfo();
                    if (attachment.WORKITEMSEQUENCE != processInfo.workitem.sequence) {
                        return false;
                    }
                }
            }

            return true;
        }

        function isDocumentTypeNotAddable(docType) {
            var len = NOT_ADDABLE_ATTACHMENT_CATEGORY.length;
            for (var i = 0; i < len; i++) {
                if (NOT_ADDABLE_ATTACHMENT_CATEGORY[i] === docType.NAME || NOT_ADDABLE_ATTACHMENT_CATEGORY[i] === docType.Name) {
                    return true;
                }
            }

            return false;
        }

        function isLastEntryDocumentType(docType) {
            var len = LAST_ENTRY_ATTACHMENT_CATEGORY.length;
            for (var i = 0; i < len; i++) {
                var item = LAST_ENTRY_ATTACHMENT_CATEGORY[i];
                if (item && (item === docType.NAME || item === docType.Name)) {
                    return true;
                }
            }

            return false;
        }

        return {
            getAssociatedAttachmentCategories: getAssociatedAttachmentCategories,
            doesHaveAssociatedAttachmentCategory: doesHaveAssociatedAttachmentCategory,
            initAssociatedAttachments: initAssociatedAttachments,
            setAngularControl: setAngularControl,
            onInit: onInit,
            generatePCAJustificationWorksheet: generatePCAJustificationWorksheet,
            generateSAMJustificationWorksheet: generateSAMJustificationWorksheet,
            generateSAMChecklist: generateSAMChecklist,
            generateLEJustificationWorksheet: generateLEJustificationWorksheet,
            generateLEServiceAgreement: generateLEServiceAgreement,
            getAssociatedAttachmentList: getAssociatedAttachmentList,
            clearAssociatedAttachmentList: clearAssociatedAttachmentList,
            clickAttachmentReviewed: clickAttachmentReviewed,
            getCustomButtons: getCustomButtons,
            refreshCustomButtons: refreshCustomButtons,
            isAttachmentDeletable: isAttachmentDeletable,
            isDocumentTypeNotAddable: isDocumentTypeNotAddable,
            isLastEntryDocumentType: isLastEntryDocumentType
        };
    };

    var _initializer = window.FormAttachmentHandler || (window.FormAttachmentHandler = FormAttachmentHandler());
})(window);

(function (window) {
    /** * Form Main Handler. */
    var FormMainHandler = function () {
        var _contextPath = '/bizflowwebmaker';
        var _actionWorkitemDo = 'actionWorkitem.do';

        function ajaxSubmission(action, sourceGroup, targetGroup, validate) {
            if (window.location.pathname.indexOf(_contextPath) > -1 && action.indexOf('/') === 0) {
                action = _contextPath + action;
            }
            var objAction = {
                name: 'Action',
                option: 'Action',
                value: action
            };
            var objSourceGroup = null;
            if (typeof sourceGroup === 'undefined' || null === sourceGroup || '' === sourceGroup
                || 'all' === sourceGroup || 'ALL' === sourceGroup) {
                objSourceGroup = {name: 'SourceGroup', option: 'AllFormData', value: ''};
            } else {
                objSourceGroup = {name: 'SourceGroup', option: 'PageGroup', value: sourceGroup};
            }

            var partialPageContainerId = '_hidden_partial_page_container_';
            if (typeof targetGroup === 'undefined') {
                var partialPageContainer = document.createElement('div');
                if (document.getElementById(partialPageContainerId) === null) {
                    partialPageContainer.id = partialPageContainerId;
                    partialPageContainer.style.display = "none";
                    document.getElementsByTagName('body')[0].appendChild(partialPageContainer);
                }
            } else {
                partialPageContainerId = targetGroup;
            }

            var objTargetGroup = {
                name: 'TargetGroup',
                option: 'PageGroup',
                value: partialPageContainerId
            };
            var objValidate = {
                name: 'Validate',
                option: 'Static',
                value: validate ? validate : false
            };
            hyf.FMAction.handleAjaxSubmission(objAction, objSourceGroup, objTargetGroup, objValidate, {value: targetGroup});
        }

        function preCompleteWorkitem(callback) {
            if (!FormUtility.isReadOnly() && INCENTIVES_TYPE.PCA === FormState.getElementValue("incentiveType")) {
                var position = TabManager.getTab("tab2");
                var pcaDetails = TabManager.getTab("tab3");

                if (!position.readOnly && !position.hidden && !pcaDetails.readOnly && !pcaDetails.hidden && !activityStep.isStartNew()) {
                    FormAttachmentHandler.generatePCAJustificationWorksheet(null, callback);
                } else {
                    callback();
                }
            } else if (!FormUtility.isReadOnly() && INCENTIVES_TYPE.SAM === FormState.getElementValue("incentiveType")) {
                // var position = TabManager.getTab("tab2");
                // var samDetails = TabManager.getTab("tab6");
                // var documents = TabManager.getTab("tab99");
                var calledAttachmentHandler = false;

                if (!activityStep.isStartNew()) {
                // if (!documents.hidden && !activityStep.isStartNew()) {
                // if (!position.readOnly && !position.hidden && !samDetails.readOnly && !samDetails.hidden && !activityStep.isStartNew()) {
                    calledAttachmentHandler = true;
                    FormAttachmentHandler.generateSAMJustificationWorksheet(null, callback);
                }
                var supportSAM = FormState.getElementValue("approvalSOValue", "");
                if ( "Approve" == supportSAM) {
                    calledAttachmentHandler = true;
                    FormAttachmentHandler.generateSAMChecklist(null, callback);
                }
                if(!calledAttachmentHandler) {
                    callback();
                }
            } else if (!FormUtility.isReadOnly() && INCENTIVES_TYPE.LE === FormState.getElementValue("incentiveType")) {
                // var position = TabManager.getTab("tab2");
                // var leDetails = TabManager.getTab("tab10");
                // var documents = TabManager.getTab("tab99");
                var calledAttachmentHandler = false;

                if (!activityStep.isStartNew()) {
                // if (!documents.hidden && !activityStep.isStartNew()) {
                // if (!position.readOnly && !position.hidden && !leDetails.readOnly && !leDetails.hidden && !activityStep.isStartNew()) {
                    calledAttachmentHandler = true;
                    FormAttachmentHandler.generateLEJustificationWorksheet(null, callback);
                }
                if (activityStep.isTABGReview()) {
                    calledAttachmentHandler = true;
                    FormAttachmentHandler.generateLEServiceAgreement(null, callback);
                }
                if(!calledAttachmentHandler) {
                    callback();
                }
            } else {
                callback();
            }
        }

        function completeWorkitem(responseName, formValidation, formDataSelector_) {
            FormUtility.greyOutScreen(true);
            formDataSelector_ = formDataSelector_ || '#h_formData';
            var xml = FormState.getFinalStateXML();
            $(formDataSelector_).val(xml);

            if (typeof responseName !== 'undefined') {
                basicWIHActionClient.setResponseByName(responseName);
            }
            basicWIHActionClient.setWIHOption('requestAction', 'complete');
            if (!basicWIHActionClient.getWIHOption('formSaved')) {
                basicWIHActionClient.setWait();
                hyf.util.hideComponent("main_buttons_layout_group");
                ajaxSubmission(_actionWorkitemDo + '?requestAction=' + responseName, 'all', undefined, formValidation);
                setTimeout(function () {
                    FormUtility.greyOutScreen(false);
                }, 2000)
            } else {
                FormUtility.greyOutScreen(false);
            }
        }

        function initWIHPane(time_) {
            setTimeout(function () {
                var ui = basicWIHActionClient.getUI();
                ui.getPane(ui.PANE_TOOL).open();
                ui.getPane(ui.PANE_TOOL).close();
                ui.getPane(ui.PANE_ATTACHMENT).hide();
                ui.getPane(ui.PANE_INTERNAL_DISCUSSION).open();
            }, time_ || 100);
        }

        function saveFormData(requestAction_) {
            if (typeof requestAction_ === 'string') {
                basicWIHActionClient.setWIHOption('requestAction', requestAction_);
            }

            FormMain.onSaveFormData();

            $('#h_formData').val(FormState.getFinalStateXML());
            ajaxSubmission(_actionWorkitemDo);
        }

        function initAssociatedAttachments() {
            var obj = document.getElementById("associatedAttachments");
            if (obj) {
                var innerText = "" + obj.innerText;
                if (innerText.indexOf("[object Object]") === 0) {
                    FormLog.log(FormLog.LOG_LEVEL.INFO, "Load documents...");
                    TabManager.loadTab(MENU_TAB.DOCUMENTS, true);
                }
            }
        }

        function onTabChange(e) {
            if (FormUtility.isReadOnly() === false) {
                saveFormData('tabChange');
            }

            initAssociatedAttachments();
        }

        function onAllTabLoaded() {
            if (!FormUtility.isReadOnly()) {
                hyf.util.showComponent('main_buttons_layout_group');
                hyf.util.showComponent('tab_container_group');

                var tabIdList = ActivityManager.getTabIdList();
                FormUtility.initMaxSize(tabIdList, 'bottom');
                FormUtility.setDateIconTabOrder(tabIdList);
                $(document).on(FORM_EVENT.TAB_CHANGE, onTabChange);

                $('.datePickerIcon').each(function () {
                    var refId = $(this).attr('id').slice(0, -16);
                    var title = "Calendar icon used to select " + $('#' + refId + '_label').text() + " value";
                    $(this).attr('title', title);
                });
            }
        }

        function saveForm(requestAction, currentTabIdSelector_) {
            currentTabIdSelector_ = currentTabIdSelector_ || '#h_currentTabID';

            $(currentTabIdSelector_).val(TabManager.getSelectedTabID()); // store current tabId to reset after page reload
            saveFormData(requestAction);
        }

        function confirmClose(alertMsg_) {
            alertMsg_ = alertMsg_ || 'Would you like to save your entries before exit?';

            bootbox.dialog({
                message: '<p class="bootbox-body">' + alertMsg_ + '</p>',
                onEscape: true,
                buttons: [{
                    label: 'No',
                    callback: function () {
                        basicWIHActionClient.exit({confirmMsg: null});
                    }
                },
                    {
                        label: 'Yes, save and exit',
                        className: 'btn-primary',
                        callback: function () {
                            $('#WIH_exit_requested').val(true);
                            saveForm('exit');
                        }
                    }]
            });
        }

        function confirmCancel(reasonLookupType_, title_, msgWhenNotSelectReason_) {
            title_ = title_ || 'What is the reason for canceling this request?';
            msgWhenNotSelectReason_ = msgWhenNotSelectReason_ || 'Please select a cancellation reason';
            if (!reasonLookupType_) {
                var incentiveType = FormState.getElementValue("incentiveType");

                if (INCENTIVES_TYPE.PCA === incentiveType) {
                    if (activityStep.isHRSReview()) reasonLookupType_ = 'Incentives-CancellationReason';
                    else if (activityStep.isSOReview()) reasonLookupType_ = 'Incentives-CancellationReason2';
                } else if (INCENTIVES_TYPE.SAM === incentiveType) {
                    reasonLookupType_ = 'Incentives-CancellationReason3';
                } else if (INCENTIVES_TYPE.LE === incentiveType) {
                    reasonLookupType_ = 'Incentives-CancellationReason3';
                }
            }

            var cancelReasons = reasonLookupType_ ? LookupManager.findByLTYPE(reasonLookupType_) : [];
            if (cancelReasons.length > 0) {
                var selectHTML = '<select class="form-control" id="cancelReason" name="cancelReason"><option value="">Select One</option>';
                for (var i = 0; i < cancelReasons.length; i++) {
                    selectHTML += '<option value="' + cancelReasons[i].NAME + '">' + cancelReasons[i].NAME + '</option>';
                }
                selectHTML += '</select>';

                bootbox.confirm({
                    title: title_,
                    message: selectHTML,
                    buttons: {
                        confirm: {
                            label: 'OK',
                            className: 'btn-success'
                        }
                    },
                    callback: function (result) {
                        if (result) {
                            var cancelReasonValue = $('#cancelReason').val();
                            if ('' === cancelReasonValue) {
                                bootbox.alert(msgWhenNotSelectReason_);
                            } else {
                                FormState.updateObjectValue('cancellationReason', cancelReasonValue);
                                FormState.updateObjectValue('cancellationUser', {name: myInfo.getMyName(), id: myInfo.getMyMemberId()});
                                completeWorkitem('Cancel', false);
                            }
                        }
                    }
                });
            } else {
                title_ = 'Are you sure you want to cancel this request?';
                $('#cancelReason').val('N/A');

                bootbox.confirm(title_, function (result) {
                    if (result) {
                        FormState.updateObjectValue('cancellationReason', "N/A");
                        FormState.updateObjectValue('cancellationUser', {name: myInfo.getMyName(), id: myInfo.getMyMemberId()});
                        completeWorkitem('Cancel', false);
                    }
                });
            }
        }

        function confirmReturnForModification(responseName) {
            bootbox.dialog({
                title: 'Please state the changes below',
                message: '<textarea rows="5" class="bootbox-input bootbox-input-text form-control" maxlength="250"></textarea>',
                onEscape: true,
                buttons: {
                    confirm: {
                        label: 'OK',
                        className: 'btn-success',
                        callback: function () {
                            var message = $('div.bootbox textarea').val();
                            FormState.updateObjectValue('returnReason', message);
                            FormState.updateObjectValue('returnedBy', myInfo.getMyName());
                            completeWorkitem(responseName, false);
                        }
                    },
                    cancel: {
                        label: 'Cancel',
                        className: 'btn-danger'
                    }
                }
            });
        }

        function attachClickToSaveWorkItem() {
            $('#button_SaveWorkitem').on('click', function () {
                saveForm('saveDraft');
            });
        }

        function attachClickToSubmitWorkItem(showAlertMsg_, alertMsg_) {
            if ("undefined" == typeof(showAlertMsg_)) {
                showAlertMsg_ = true;
            }
            alertMsg_ = alertMsg_ || 'Please fill in all the required fields before submit';

            $('#button_SubmitWorkitem').off('click').click(function () {
                FormUtility.greyOutScreen(true);
                var isValidForm = true;
                var watchTabId = null;
                var activeTabs = ActivityManager.getTabIdList(ActivityManager.getActivityName());
                for (var tabIndex = 0; tabIndex < activeTabs.length; tabIndex++) {
                    watchTabId = activeTabs[tabIndex];
                    isValidForm = TabManager.validateTab(watchTabId);
                    if (isValidForm === false) {
                        break;
                    }
                }
                if (isValidForm) {
                    preCompleteWorkitem(function () {
                        FormUtility.greyOutScreen(false);
                        completeWorkitem('OnGoing', false);
                    });
                } else {
                    FormUtility.greyOutScreen(false);
                    TabManager.goToTab(watchTabId);
                    if (showAlertMsg_) {
                        bootbox.alert(alertMsg_);
                    }
                }
            });
        }

        function attachClickToSendTo(buttonId, showAlertMsg_, alertMsg_) {
            if ("undefined" == typeof(showAlertMsg_)) {
                showAlertMsg_ = true;
            }
            alertMsg_ = alertMsg_ || 'Please fill in all the required fields before submit';

            $('#' + buttonId).off('click').click(function () {
                FormUtility.greyOutScreen(true);
                var isValidForm = true;
                var watchTabId = null;
                var activeTabs = ActivityManager.getTabIdList(ActivityManager.getActivityName());
                for (var tabIndex = 0; tabIndex < activeTabs.length; tabIndex++) {
                    watchTabId = activeTabs[tabIndex];
                    isValidForm = TabManager.validateTab(watchTabId);
                    if (isValidForm === false) {
                        break;
                    }
                }
                if (isValidForm) {
                    var responseName = $(this).attr("responseName");
                    preCompleteWorkitem(function () {
                        FormUtility.greyOutScreen(false);
                        completeWorkitem(responseName, false);
                    });
                } else {
                    FormUtility.greyOutScreen(false);
                    TabManager.goToTab(watchTabId);
                    if (showAlertMsg_) {
                        bootbox.alert(alertMsg_);
                    }
                }
            });
        }

        function attachClickToExitWIH() {
            $('#button_ExitWIH').off('click').click(function (e) {
                confirmClose();
            });
        }

        function attachClickToCancelWIH() {
            $('#button_CancelWorkitem').off('click').click(function (e) {
                confirmCancel();
            });
        }

        function attachClickToReturnForModification() {
            $('#button_ReturnForModification').off('click').click(function (e) {
                var responseName = $(this).attr("responseName");
                confirmReturnForModification(responseName);
            });
        }

        function attachClickToPDF(alertMsg_) {
            $('#button_PDF').off('click').click(function (e) {
                // Form validation
                var isValidForm = true;
                var watchTabId = null;
                var activeTabs = ActivityManager.getTabIdList(ActivityManager.getActivityName());
                for (var tabIndex = 0; tabIndex < activeTabs.length; tabIndex++) {
                    watchTabId = activeTabs[tabIndex];
                    isValidForm = TabManager.validateTab(watchTabId);
                    if (isValidForm === false) {
                        break;
                    }
                }
                if (isValidForm) {
                    completeWorkitem('Close', false);
                } else {
                    if (alertMsg_) {
                        bootbox.alert(alertMsg_);
                    }
                    $('#' + TabManager.getAnchorID(watchTabId)).click();
                }
            });
        }

        function init() {
            $(document).on(FORM_EVENT.ALL_TABS_LOADED, onAllTabLoaded);

            initWIHPane();

            hyf.util.showComponent('button_ExitWIH');
            hyf.util.showComponent('button_SaveWorkitem');
            hyf.util.showComponent('button_SubmitWorkitem');
            hyf.util.hideComponent('button_SendTo1');
            hyf.util.hideComponent('button_SendTo2');

            attachClickToSaveWorkItem();
            attachClickToSubmitWorkItem(false);
            attachClickToSendTo("button_SendTo1", false);
            attachClickToSendTo("button_SendTo2", false);
            attachClickToExitWIH();
            attachClickToCancelWIH();
            attachClickToReturnForModification();
            attachClickToPDF();
        }

        return {
            contextPath: _contextPath,
            ajaxSubmission: ajaxSubmission,
            completeWorkitem: completeWorkitem,
            initWIHPane: initWIHPane,
            saveFormData: saveFormData,
            onTabChange: onTabChange,
            onAllTabLoaded: onAllTabLoaded,
            saveForm: saveForm,
            confirmClose: confirmClose,
            confirmCancel: confirmCancel,
            attachClickToSaveWorkItem: attachClickToSubmitWorkItem,
            attachClickToSubmitWorkItem: attachClickToSubmitWorkItem,
            attachClickToExitWIH: attachClickToExitWIH,
            attachClickToPDF: attachClickToPDF,
            init: init
        }
    };

    var _initializer = window.FormMainHandler || (window.FormMainHandler = FormMainHandler());
})(window);

