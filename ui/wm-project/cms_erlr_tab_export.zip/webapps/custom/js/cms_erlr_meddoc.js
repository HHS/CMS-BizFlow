(function (window) {
    var cms_meddoc = function () {

        var initialized = false;
        var fmlaDisaprvReasonDropdown = null;


        var dateFieldsPastPresent =
            [
                'MD_FMLA_DOC_SBMT_DT',
                'MD_FMLA_BEGIN_DT',
                'MD_MEDEXAM_RECEIVED_DT',
                'MD_DOC_SBMT_DT'
            ];

        var dateFieldsPresentFuture =
            [];

        var reqFieldForActivity =
            [
                {
                    actName: globalVars.actAll,
                    reqFieldIds:
                        []
                },
                {
                    actName: globalVars.actCaseCreation,
                    reqFieldIds:
                        []
                },
                {
                    actName: globalVars.actCaseComplete,
                    reqFieldIds:
                        [
                            'MD_REQUEST_REASON',
                            'MD_FMLA_DOC_SBMT_DT',
                            'MD_FMLA_APROVED',
                            'MD_FMLA_GRIEVANCE',
                            'MD_MEDEXAM_EXTENDED',
                            'MD_DOC_SUBMITTED',
                            'MD_DOC_SBMT_DT',
                            'MD_DOC_ADMTV_REJECT_REASON',
                            'MD_FMLA_DISAPRV_REASON_SEL'
                        ]
                }
            ];


        function controlRequestReasonVisibility() {
            var requestReasonVal = FormState.getElementValue('MD_REQUEST_REASON');
            var requestReasonTxt = '';
            if (typeof requestReasonVal != 'undefined' && requestReasonVal != null && requestReasonVal.length > 0) {
                requestReasonTxt = $('#MD_REQUEST_REASON option[value="' + requestReasonVal + '"]').text();
            }
            CommonOpUtil.showHideLayoutGroup('md_reason_fmla_group', (requestReasonTxt === 'FMLA'));
            CommonOpUtil.showHideLayoutGroup('md_reason_non_fmla_group', (requestReasonTxt === 'Conduct Related' || requestReasonTxt === 'Health & Safety Concerns' || requestReasonTxt === 'Performance'));
            var prevSelTxt = $('#MD_REQUEST_REASON option selected').text();
            if ((requestReasonTxt === 'Conduct Related' || requestReasonTxt === 'Health & Safety Concerns' || requestReasonTxt === 'Performance')
                && requestReasonTxt != prevSelTxt) {
                // if the displayed section is not changed even though the selection is changed, explicitly call clear method
                CommonOpUtil.clearGroupContent('md_reason_non_fmla_group');
            }
        }

        function controlFmlaApprovedVisibility() {
            var selVal = FormState.getElementBooleanValue('MD_FMLA_APROVED', true);
            if (selVal) {
                clearDisaprvReason();
            }
            CommonOpUtil.showHideLayoutGroup('md_fmla_reason_group', !selVal);
            CommonOpUtil.showHideLayoutGroup('md_fmla_appeal_group', !selVal);
        }

        function controlFmlaGrievanceVisibility() {
            var selVal = FormState.getElementBooleanValue('MD_FMLA_GRIEVANCE');
            CommonOpUtil.showHideLayoutGroup('md_fmla_grievance_note_group', selVal);
        }

        function controlMedexamExtendedVisibility() {
            var selVal = FormState.getElementBooleanValue('MD_MEDEXAM_EXTENDED');
            CommonOpUtil.showHideLayoutGroup('md_offer_accept_group', selVal);
        }

        function controlMedexamAcceptedVisibility() {
            var selVal = FormState.getElementBooleanValue('MD_MEDEXAM_ACCEPTED');
            CommonOpUtil.showHideLayoutGroup('md_offer_received_group', selVal);
        }

        function controlDocSubmittedVisibility() {
            var selVal = FormState.getElementBooleanValue('MD_DOC_SUBMITTED');
            CommonOpUtil.showHideLayoutGroup('md_doc_submit_dt_group', selVal);
            CommonOpUtil.showHideLayoutGroup('md_doc_review_group', selVal);
        }

        function controlDocSubmittedFohVisibility() {
            var selVal = FormState.getElementBooleanValue('MD_DOC_SBMT_FOH');
            CommonOpUtil.showHideLayoutGroup('md_doc_review_detail_outcome_group', selVal);
        }

        function controlDocAdminAcceptableVisibility() {
            var selVal = FormState.getElementBooleanValue('MD_DOC_ADMTV_ACCEPTABLE');
            CommonOpUtil.showHideLayoutGroup('md_doc_review_result_reason_group', !selVal);
        }

        function initVisibility() {
            //FormState.updateTextValue('MD_FMLA_GRIEVANCE_NOTE', 'Note: Please Start a Grievance Case.');
            controlRequestReasonVisibility();
            controlFmlaApprovedVisibility();
            controlFmlaGrievanceVisibility();
            controlMedexamExtendedVisibility();
            controlMedexamAcceptedVisibility();
            controlDocSubmittedVisibility();
            controlDocSubmittedFohVisibility();
            controlDocAdminAcceptableVisibility();
        }


        function controlEnableDisable() {

        }


        function setSelectElemValue(selElem) {
            if (typeof selElem == 'undefined' || selElem == null
                || typeof selElem.id == 'undefined' || selElem.id == null
                || typeof selElem.options == 'undefined' || selElem.options == null) {
                return;
            }
            var selectedVal = selElem.options[selElem.options.selectedIndex].value;
            var selectedTxt = selElem.options[selElem.options.selectedIndex].text;
            FormState.updateSelectValue(selElem.id, selectedVal, selectedTxt);
        }

        function initEventHandlers() {
            $('#MD_REQUEST_REASON').on('change', function (e) {
                setSelectElemValue(e.target);
                controlRequestReasonVisibility();
            });

            $('#MD_FMLA_APROVED').on('change', function (e) {
                setSelectElemValue(e.target);
                controlFmlaApprovedVisibility();
            });

            $('#MD_FMLA_GRIEVANCE').on('change', function (e) {
                setSelectElemValue(e.target);
                controlFmlaGrievanceVisibility();
            });

            $('#MD_MEDEXAM_EXTENDED').on('change', function (e) {
                setSelectElemValue(e.target);
                controlMedexamExtendedVisibility();
            });

            $('#MD_MEDEXAM_ACCEPTED').on('change', function (e) {
                setSelectElemValue(e.target);
                controlMedexamAcceptedVisibility();
            });

            $('#MD_DOC_SUBMITTED').on('change', function (e) {
                setSelectElemValue(e.target);
                controlDocSubmittedVisibility();
            });

            $('#MD_DOC_SBMT_FOH').on('change', function (e) {
                setSelectElemValue(e.target);
                controlDocSubmittedFohVisibility();
            });

            $('#MD_DOC_ADMTV_ACCEPTABLE').on('change', function (e) {
                setSelectElemValue(e.target);
                controlDocAdminAcceptableVisibility();
            });
        }


        function setupCustomWidget() {
            var activityName = ActivityManager.getActivityName();

            // set up FMLA Disapproval Reason dropdown as multi-select widget
            var fmlaDisaprvReasonMinSelection = (activityName === 'Complete Case') ? 1 : 0;
            var fmlaDisaprvReasonInitialData = [];
            var fmlaDisaprvReasonIdString = FormState.getElementValue('MD_FMLA_DISAPRV_REASON');
            var fmlaDisaprvReasonIds = ((fmlaDisaprvReasonIdString != null && fmlaDisaprvReasonIdString.length > 0) ? fmlaDisaprvReasonIdString.split(',') : []);
            var count = fmlaDisaprvReasonIds.length;
            for (var index = 0; index < count; index++) {
                var itemLabel = $('#MD_FMLA_DISAPRV_REASON_SEL option[value="' + fmlaDisaprvReasonIds[index] + '"]').text();
                fmlaDisaprvReasonInitialData.push({
                    id: fmlaDisaprvReasonIds[index],
                    label: itemLabel
                });
            }
            var fmlaDisaprvReasonDropdownOption = {
                id: 'MD_FMLA_DISAPRV_REASON',
                tabindex: 0,
                minSelectionCount: fmlaDisaprvReasonMinSelection,
                maxSelectionCount: 7,
                getSelectionLabel: function (item) {
                    return item.label
                },
                getItemID: function (item) {
                    return item.id;
                },
                initialItems: fmlaDisaprvReasonInitialData,
                setDataToForm: function (values) {
                    if (typeof values == 'undefined') return;
                    var selectedIds = '';
                    if (values != null && $.isArray(values)) {
                        selectedIds = values.reduce(function (accumulator, currentValue, currentIndex, array) {
                            return (accumulator && accumulator.length > 0) ? accumulator + ',' + currentValue.id : currentValue.id;
                        }, '');
                    }
                    FormState.updateObjectValue('MD_FMLA_DISAPRV_REASON', selectedIds);
                }
            };
            fmlaDisaprvReasonDropdown = MultiSelectDropdown.setupMultiSelectDropdown(fmlaDisaprvReasonDropdownOption);
        }


        function clearDisaprvReason() {
            if (typeof fmlaDisaprvReasonDropdown != 'undefined' && fmlaDisaprvReasonDropdown != null) {
                fmlaDisaprvReasonDropdown.deleteAll();
            }
        }

        // Clear data for all custom widget in the tab.
        // Note: This function will be called by the main tab when subsequent tabs are
        function clearAllContentCustom() {
            clearDisaprvReason();
        }


        function init() {

            //-----------------------------------
            // visibility configuration
            //-----------------------------------
            initVisibility();

            //-----------------------------------
            // enable/disable configuration
            //-----------------------------------
            controlEnableDisable();

            //-----------------------------------
            // validation configuration
            //-----------------------------------
            dateFieldsPastPresent.forEach(function (item) {
                hyf.calendar.setDateConstraint(item, 'Maximum', 'Today');
            });
            //dateFieldsPresentFuture.forEach(function(item){
            //	hyf.calendar.setDateConstraint(item, 'Minimum', 'Today');
            //});
            CommonOpUtil.dynamicMandatory(reqFieldForActivity);


            //-----------------------------------
            // event handler configuration
            //-----------------------------------
            initEventHandlers();


            //-----------------------------------
            // custom ui element initialization
            //-----------------------------------
            setupCustomWidget();
        }

        // manage data population and display of read-only fields and disabled fields since they cannot be controlled by event handler
        function render() {
        }


        return {
            initialized: initialized,
            reqFieldForActivity: reqFieldForActivity,
            clearAllContentCustom: clearAllContentCustom,
            render: render,
            init: init
        };
    };

    var _initializer = window.cms_meddoc || (window.cms_meddoc = cms_meddoc());
})(window);
