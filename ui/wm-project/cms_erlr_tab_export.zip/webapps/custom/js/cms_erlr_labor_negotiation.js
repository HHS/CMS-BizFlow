'use strict';
(function (window) {
    var cms_erlr_labor_negotiation = function () {
	
		var initialized = false;
		
		var dateFieldsPastPresent = 
		[
		];
		var groups = 
		[
		'LN_UNION_GROUP'
		,'LN_UNION_PROPOSAL_INFO_GROUP'
		,'LN_UNION_PROPOSAL_NOT_SUBMITTED_GROUP'
		,'LN_UNION_PROPOSAL_SUBMITTED_GROUP'
		,'LN_UNION_NEGOTIABLE_PROPOSAL_GROUP'
		,'LN_UNION_NEGOTIABLE_SUBMITTED'
		,'LN_UNION_NEGOTIABLE_NOT_SUBMITTED'
		,'LN_MANAGEMENT_GROUP'
		,'LN_MNGMN_UNION_RESPOND_TO_NTC_GROUP'
		,'LN_UNION_LETTER_GROUP'
		,'LN_UNION_LETTER_SUB_GROUP'
		,'LN_MNGMNT_NOTICE_RESPONSE_GROUP'
		]
		var dateFields= 
		[
		 
		];
		
		var reqFieldForActivity = 
		[
			{
				actName: globalVars.actAll,
				reqFieldIds: 
				[
				]
			},
			{
				actName: globalVars.actCaseCreation,
				reqFieldIds: 
				[
				]
			},
			{
				actName: globalVars.actCaseComplete,
				reqFieldIds: 
				[
				'LN_NEGOTIATION_TYPE'
				,'LN_INITIATOR'
				,'LN_BRIEFING_REQUEST'
				,'LN_MNGMNT_BRIEFING_REQUEST'
				,'LN_PROPOSAL_SUBMISSION'
				,'LN_UNION_PROPOSAL_NEGOTIABLE'
				,'LN_UNION_NON_NEGOTIABLE_LETTER'
				,'LN_LETTER_PROVIDED_DT'
				,'LN_UNION_NEGOTIABLE_PROPOSAL'
				,'LN_UNION_FSIP_DECISION_DT'
				,'LN_MNGMNT_NOTICE_RESPONSE'
				]
			}
		];

		function initVisibility() {
            controlXXXVisibility();
		}

		function setSelectElemValue(selElem) {
			if ( typeof selElem == 'undefined' || selElem == null 
					|| typeof selElem.id == 'undefined' || selElem.id == null 
					|| typeof selElem.options == 'undefined' || selElem.options == null ) {
				return;
			}
			var selectedVal = selElem.options[selElem.options.selectedIndex].value;
			var selectedTxt = selElem.options[selElem.options.selectedIndex].text;
			FormState.updateSelectValue(selElem.id, selectedVal, selectedTxt);
		}
		
		function controlXXXVisibility(){
            var elemVal = FormState.getElementValue('XXX');
			CommonOpUtil.showHideLayoutGroup('ir_cms_requester_layout_group', ('CMS' === elemVal));
			CommonOpUtil.showHideLayoutGroup('ir_non_cms_requester_layout_group', ('NONCMS' === elemVal));
        }

		function initEventHandlers(){
			$('#XXX').on('change', function(e) {
				setSelectElemValue(e.target);
				controlXXXVisibility();
			});
			onLoadEventHandlers();
		}

        function initiatorEventHandler(e) 
		{
			var initiator;
			try
			{
				initiator = e.target.options[e.target.selectedIndex].value;
				if(initiator != undefined)
				{
					if(initiator ==='union')
					{
						hyf.util.showComponent('LN_UNION_GROUP');
						hyf.util.hideComponent('LN_MANAGEMENT_GROUP');
						CommonOpUtil.clearGroupContent('LN_MANAGEMENT_GROUP');
					}
					else if(initiator ==='management')
					{
						hyf.util.showComponent('LN_MANAGEMENT_GROUP');
						hyf.util.hideComponent('LN_UNION_GROUP');
						CommonOpUtil.clearGroupContent('LN_UNION_PROPOSAL_INFO_body');
					}
					else
					{
						hyf.util.hideComponent('LN_MANAGEMENT_GROUP');
						hyf.util.hideComponent('LN_UNION_GROUP');
					}
					
				}
			}
			catch(e){}
        }
		function proposalSubmissionEventHandler(e)
		{
			var val;
			try
			{
			  val = e.target.options[e.target.selectedIndex].value;
			  if(val ==='Y')
			  {
			   hyf.util.showComponent('LN_UNION_PROPOSAL_INFO_GROUP');
			  }
			  else{
			   hyf.util.hideComponent('LN_UNION_PROPOSAL_INFO_GROUP');
			  }
			}
			catch(err){
				
			}
		}
		function unionProposalNetiableEventHandler(e)
		{
			var val;
			try
			{
				val = e.target.options[e.target.selectedIndex].value;
				if(val ==='Y')
				{
				hyf.util.showComponent('LN_UNION_PROPOSAL_SUBMITTED_GROUP');
				hyf.util.hideComponent('LN_UNION_PROPOSAL_NOT_SUBMITTED_GROUP');
				}else if(val ==='N'){
					hyf.util.showComponent('LN_UNION_PROPOSAL_NOT_SUBMITTED_GROUP');
					hyf.util.hideComponent('LN_UNION_PROPOSAL_SUBMITTED_GROUP');
				}
				else{
				hyf.util.hideComponent('LN_UNION_PROPOSAL_SUBMITTED_GROUP');
				hyf.util.hideComponent('LN_UNION_PROPOSAL_SUBMITTED_GROUP');
				}
			}
			catch(err){
				
			}
		}
		function unionNonNegotiableLetterHandler(e)
		{
			var val;
			try
			{
				val = e.target.options[e.target.selectedIndex].value;
				if(val ==='Y')
				{
				 hyf.util.showComponent('LN_UNION_LETTER_GROUP');
				}
				else
				{
				 hyf.util.hideComponent('LN_UNION_LETTER_GROUP');
				}
			}
			catch(err){
				
			}
		}
		function unionLetterProvidedHandler(e)
		{
			var val;
			try
			{
				val = e.target.options[e.target.selectedIndex].value;
				if(val ==='Y')
				{
				 hyf.util.showComponent('LN_UNION_LETTER_SUB_GROUP');
				}
				else{
				 hyf.util.hideComponent('LN_UNION_LETTER_SUB_GROUP');
				}
			}
			catch(err){
				
			}
		}
		function unionNegotiableProposalHandler(e)
		{
			var val;
			try
			{
				val = e.target.options[e.target.selectedIndex].value;
				if(val ==='Y')
				{
				 hyf.util.showComponent('LN_UNION_NEGOTIABLE_PROPOSAL_GROUP');
				 hyf.util.showComponent('LN_UNION_NEGOTIABLE_SUBMITTED');
				 hyf.util.hideComponent('LN_UNION_NEGOTIABLE_NOT_SUBMITTED');
				}
				else if(val ==='N')
				{
				 hyf.util.showComponent('LN_UNION_NEGOTIABLE_PROPOSAL_GROUP');
				 hyf.util.showComponent('LN_UNION_NEGOTIABLE_NOT_SUBMITTED');
				 hyf.util.hideComponent('LN_UNION_NEGOTIABLE_SUBMITTED');
				}
				else
				{
				 hyf.util.hideComponent('LN_UNION_NEGOTIABLE_PROPOSAL_GROUP');
				 hyf.util.hideComponent('LN_UNION_NEGOTIABLE_NOT_SUBMITTED');
				 hyf.util.hideComponent('LN_UNION_NEGOTIABLE_SUBMITTED');
				}				
			}
			catch(err){
				
			}
		}
		function managementNoticeResponse(e)
		{
			try
			{
				val = e.target.options[e.target.selectedIndex].value;
				if(val ==='Y')
				{
				 hyf.util.showComponent('LN_MNGMNT_NOTICE_RESPONSE_GROUP');
				 hyf.util.showComponent('LN_MNGMN_UNION_RESPOND_TO_NTC_GROUP');
				}
				else
				{
				 hyf.util.hideComponent('LN_MNGMNT_NOTICE_RESPONSE_GROUP');
				 hyf.util.hideComponent('LN_MNGMN_UNION_RESPOND_TO_NTC_GROUP');
				}				
			}
			catch(err){
				
			}
		}
		function onLoadEventHandlers()
		{
			$('#LN_UNION_PROPOSAL_NEGOTIABLE').on('change',unionProposalNetiableEventHandler);
			$('#LN_UNION_PROPOSAL_NEGOTIABLE').on('change',proposalSubmissionEventHandler);
			$('#LN_UNION_NON_NEGOTIABLE_LETTER').on('change',unionNonNegotiableLetterHandler);
			$('#LN_UNION_LETTER_PROVIDED').on('change',unionLetterProvidedHandler);
			$('#LN_UNION_NEGOTIABLE_PROPOSAL').on('change',unionNegotiableProposalHandler);
			$('#LN_INITIATOR').on('change',initiatorEventHandler);
			$('#LN_MNGMNT_NOTICE_RESPONSE').on('change',managementNoticeResponse);
			//$('#LN_MNGMNT_NOTICE_RESPONSE').on('change',unionRespond2Notice);
		}
		function clearAll(){
			//CommonOpUtil.clearGroupContent('ulp_exception_layout');
		}
        function init() {
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_labor_negotiation::init START');
			 
			//-----------------------------------
			// visibility configuration
			//-----------------------------------
			initVisibility();
			
			groups.forEach((el)=>{
				hyf.util.hideComponent(el);
			});
			
			//-----------------------------------
			// validation configuration
			//-----------------------------------
			dateFieldsPastPresent.forEach(function(item){
				hyf.calendar.setDateConstraint(item, 'Maximum', 'Today');
			});
			dateFields.forEach(function(item){
				hyf.calendar.setDateConstraint(item, 'Minimum', 'Today');
			});
			CommonOpUtil.dynamicMandatory(reqFieldForActivity);
			
			
			//-----------------------------------
			// event handler configuration
			//-----------------------------------
			initEventHandlers();
			//onLoad();
			
			//-----------------------------------
			// custom ui element initialization
			//-----------------------------------
			//setupCustomWidget();
		
			initialized = true;
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_labor_negotiation::init END');
		}
		
		function render() 
		{
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_labor_negotiation::render START');
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_labor_negotiation::render END');
			var initiator = FormState.getElementValue('LN_INITIATOR');
			var proposalSubmission = FormState.getElementValue('LN_PROPOSAL_SUBMISSION');
			var unionNonNegotiableLetter = FormState.getElementValue('LN_UNION_NON_NEGOTIABLE_LETTER');
			var unionLetterProvided = FormState.getElementValue('LN_UNION_LETTER_PROVIDED');
			var unionNegotiableProposal = FormState.getElementValue('LN_UNION_NEGOTIABLE_PROPOSAL');
			var managementResponsenotice = FormState.getElementValue('LN_MNGMNT_NOTICE_RESPONSE');
			if(initiator != undefined)
			{
			if(initiator ==='union')
			{
				hyf.util.showComponent('LN_UNION_GROUP');
				hyf.util.hideComponent('LN_MANAGEMENT_GROUP');
			}
			else if(initiator ==='management')
			{
				hyf.util.showComponent('LN_MANAGEMENT_GROUP');
				hyf.util.hideComponent('LN_UNION_GROUP');
			}
			else
			{
				hyf.util.hideComponent('LN_MANAGEMENT_GROUP');
				hyf.util.hideComponent('LN_UNION_GROUP');
			}
					
			}
			if(proposalSubmission ==='Y')
			{
			 hyf.util.showComponent('LN_UNION_PROPOSAL_INFO_GROUP');
			}
			else
			{
			 hyf.util.hideComponent('LN_UNION_PROPOSAL_INFO_GROUP');
			}
			if(unionNonNegotiableLetter ==='Y')
			{
			hyf.util.showComponent('LN_UNION_LETTER_GROUP');
			}
			else
			{
			hyf.util.hideComponent('LN_UNION_LETTER_GROUP');
			}
			if(unionLetterProvided ==='Y')
			{
			 hyf.util.showComponent('LN_UNION_LETTER_SUB_GROUP');
			}
			else
			{
			 hyf.util.hideComponent('LN_UNION_LETTER_SUB_GROUP');
			}
			if(managementResponsenotice ==='Y')
			{
			 hyf.util.showComponent('LN_MNGMNT_NOTICE_RESPONSE_GROUP');
			 hyf.util.showComponent('LN_MNGMN_UNION_RESPOND_TO_NTC_GROUP');
			}
			else
			{
			 hyf.util.hideComponent('LN_MNGMNT_NOTICE_RESPONSE_GROUP');
			 hyf.util.hideComponent('LN_MNGMN_UNION_RESPOND_TO_NTC_GROUP');
			}
			if(unionNegotiableProposal ==='Y')
			{
			hyf.util.showComponent('LN_UNION_NEGOTIABLE_PROPOSAL_GROUP');
			hyf.util.showComponent('LN_UNION_NEGOTIABLE_SUBMITTED');
			hyf.util.hideComponent('LN_UNION_NEGOTIABLE_NOT_SUBMITTED');
			}
			else if(unionNegotiableProposal ==='N')
			{
			hyf.util.showComponent('LN_UNION_NEGOTIABLE_PROPOSAL_GROUP');
			hyf.util.showComponent('LN_UNION_NEGOTIABLE_NOT_SUBMITTED');
			hyf.util.hideComponent('LN_UNION_NEGOTIABLE_SUBMITTED');
			}
			else
			{
			hyf.util.hideComponent('LN_UNION_NEGOTIABLE_PROPOSAL_GROUP');
			hyf.util.hideComponent('LN_UNION_NEGOTIABLE_NOT_SUBMITTED');
			hyf.util.hideComponent('LN_UNION_NEGOTIABLE_SUBMITTED');
			}		
		}
		
		return {
			initialized: initialized,
			render: render,
			init: init
		};
	};
	
    var _initializer = window.cms_erlr_labor_negotiation || (window.cms_erlr_labor_negotiation = cms_erlr_labor_negotiation());
})(window);
