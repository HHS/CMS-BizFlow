var Appeal = {
    initialized: false,
    init: function () {
        hyf.util.hideComponent('Exception_info_group');
        hyf.util.hideComponent('Arbitration_group_Grievance');
        hyf.util.hideComponent('Exception_info_group_2');
        hyf.util.hideComponent('discovery_due_group');
        hyf.util.hideComponent('petition_review_date_group');

        var appealType = FormState.getElementValue('AP_ERLR_APPEAL_TYPE');
        controlLayoutByAppealType(appealType);

        $('#AP_ERLR_APPEAL_TYPE').on('change', appealTypeEvent);
        $('#Appeal_group select,#Appeal_group input[type="text"]').on('change', updateEvent);
        Appeal.dateFields.forEach(function (el) {
            if (el !== '') {
                try {
                    hyf.calendar.setDateConstraint(el, 'Maximum', 'Today');
                } catch (err) {
                }
            }
        })
    },
    dateFields: [
        'AP_ERLR_PREHEARING_DT',
        'AP_ERLR_HEARING_DT',
        'AP_ERLR_POSTHEARING_BRIEF_DUE',
        'AP_ERLR_FINAL_ARBITRATOR_DECISION_DT',
        'AP_ERLR_EXCEPTION_FILE_DT',
        'AP_ERLR_RESPONSE_TO_EXCEPTIONS_DUE',
        'AP_ERLR_FINAL_FLRA_DECISION_DT',
        'AP_ERLR_PREHEARING_DT_SC',
        'AP_ERLR_HEARING_DT_SC',
        'AP_ERLR_DT_STEP_DECISION',
        'AP_ERLR_PREHEARING_DT_2',
        'AP_ERLR_HEARING_DT_2',
        'AP_ERLR_POSTHEARING_BRIEF_DUE_2',
        'AP_ERLR_FINAL_ARBITRATOR_DECISION_DT_2',
        'AP_ERLR_EXCEPTION_FILE_DT_2',
        'AP_ERLR_RESPONSE_TO_EXCEPTIONS_DUE',
        'AP_ERLR_FINAL_FLRA_DECISION_DT_2',
        'AP_ERLR_APPEAL_FILE_DT',
        'AP_ERLR_DT_SETTLEMENT_DISCUSSION',
        'AP_ERLR_DT_AGENCY_FILE_RESPONSE_DUE',
        'AP_ERLR_PREHEARING_DT_MSPB',
        'AP_ERLR_DT_DISCOVERY_DUE',
        'AP_ERLR_HEARING_DT_MSPB',
        'AP_ERLR_INITIAL_DECISION_DT_MSPB',
        'AP_ERLR_PETITION_FILED_DT_MSPB',
        'AP_ERLR_FINAL_BOARD_DECISION_DT_MSPB'
    ],
    render: function () {

    },
    dateValidate: function (e, msg, targetId) {
        var days = 0
        var dt1 = '';
        var dt2 = ''
        if (e.value1 != undefined || e.value2 != undefined) {
            dt1 = e.value1;
            dt2 = e.value2;
        }
        if ((dt2 && dt2 !== '') || (dt1 && dt1 !== '')) {
            var m1 = moment(dt1);
            var m2 = moment(dt2);
            days = m2.diff(m1, 'days');
            if (days < 0) {
                bootbox.alert({
                    message: msg,
                    callback: function () {
                        FormState.doAction(StateAction.changeDate(targetId, ''), false);
                        $('#' + targetId).val('');
                    }
                });
            }
        }
    }/*,
    clearFields : function(targetFields){
        targetFields.forEach(fucntion(el){
			if(
			FormState.doAction(StateAction.changeText(el, ''), false);
        	FormState.doAction(StateAction.changeSelect('SME_INTERNAL_2', 'default'), false);
    		});	
        	
    }  */
}

function appealTypeEvent(e) {
    var appealType = '';//e.target.options[e.target.options.selectedIndex].value;
    if (e === 'undefined') {
        return;
    } else if (typeof e === 'object') {
        if (e.target !== 'undefined') {
            appealType = e.target.options[e.target.options.selectedIndex].value;
        }
    }
    controlLayoutByAppealType(appealType);
    FormState.updateSelectValue('AP_ERLR_APPEAL_TYPE', appealType, appealType);
}

function controlLayoutByAppealType(appealType) {
    if (appealType === 'Arbitration') {
        CommonOpUtil.showHideLayoutGroup('Arbitration_group', true);
        CommonOpUtil.showHideLayoutGroup('Special_Counsel_group', false);
        CommonOpUtil.showHideLayoutGroup('Grievance_group', false);
        CommonOpUtil.showHideLayoutGroup('AP_judge_info_group', false);
        CommonOpUtil.showHideLayoutGroup('AP_hearing_info_group', false);
    }
    else if (appealType === 'Special Counsel') {
        CommonOpUtil.showHideLayoutGroup('Arbitration_group', false);
        CommonOpUtil.showHideLayoutGroup('Special_Counsel_group', true);
        CommonOpUtil.showHideLayoutGroup('Grievance_group', false);
        CommonOpUtil.showHideLayoutGroup('AP_judge_info_group', false);
        CommonOpUtil.showHideLayoutGroup('AP_hearing_info_group', false);
    }
    else if (appealType === 'Grievance') {
        CommonOpUtil.showHideLayoutGroup('Arbitration_group', false);
        CommonOpUtil.showHideLayoutGroup('Special_Counsel_group', false);
        CommonOpUtil.showHideLayoutGroup('Grievance_group', true);
        CommonOpUtil.showHideLayoutGroup('AP_judge_info_group', false);
        CommonOpUtil.showHideLayoutGroup('AP_hearing_info_group', false);
    }
    else if (appealType === 'MSPB') {
        CommonOpUtil.showHideLayoutGroup('Arbitration_group', false);
        CommonOpUtil.showHideLayoutGroup('Special_Counsel_group', false);
        CommonOpUtil.showHideLayoutGroup('Grievance_group', false);
        CommonOpUtil.showHideLayoutGroup('AP_judge_info_group', true);
        CommonOpUtil.showHideLayoutGroup('AP_hearing_info_group', true);
    }
    else if (appealType === 'FLRA') {
        CommonOpUtil.showHideLayoutGroup('Arbitration_group', false);
        CommonOpUtil.showHideLayoutGroup('Special_Counsel_group', false);
        CommonOpUtil.showHideLayoutGroup('Grievance_group', false);
        CommonOpUtil.showHideLayoutGroup('AP_judge_info_group', false);
        CommonOpUtil.showHideLayoutGroup('AP_hearing_info_group', true);
    }
    else {
        CommonOpUtil.showHideLayoutGroup('Arbitration_group', false);
        CommonOpUtil.showHideLayoutGroup('Special_Counsel_group', false);
        CommonOpUtil.showHideLayoutGroup('Grievance_group', false);
        CommonOpUtil.showHideLayoutGroup('AP_judge_info_group', false);
        CommonOpUtil.showHideLayoutGroup('AP_hearing_info_group', false);
    }

    $('#Appeal_group select,#Appeal_group input[type="text"]').not('#AP_ERLR_APPEAL_TYPE').val('');
}

function updateEvent(e) {
    var eventSource = '';
    var val = '';//e.target.options[e.target.options.selectedIndex].value;
    if (e === 'undefined') {
        return;
    } else if (typeof e === 'object') {
        if (e.target !== 'undefined') {
            val = e.target.options[e.target.options.selectedIndex].value;
            eventSource = e.target.id;
        }
    }
    if (eventSource && eventSource === 'AP_ERLR_EXCEPTION_FILED') {
        if (val === 'Yes') {
            hyf.util.showComponent('Exception_info_group');
        }
        else {
            hyf.util.hideComponent('Exception_info_group');
        }
    }

    if (eventSource && eventSource === 'AP_ERLR_EXCEPTION_FILED_2') {
        if (val === 'Yes') {
            hyf.util.showComponent('Exception_info_group_2');
        }
        else {
            hyf.util.hideComponent('Exception_info_group_2');
        }
    }

    if (eventSource && eventSource === 'AP_ERLR_ARBITRATION_INVOKED') {
        if (val === 'Yes') {
            hyf.util.showComponent('Arbitration_group_Grievance');
        }
        else {
            hyf.util.hideComponent('Arbitration_group_Grievance');
        }
    }

    if (eventSource && eventSource === 'AP_ERLR_WAS_DISCOVERY_INITIATED') {
        if (val === 'Yes') {
            hyf.util.showComponent('discovery_due_group');
        }
        else {
            hyf.util.hideComponent('discovery_due_group');
        }
    }
    if (eventSource && eventSource === 'AP_ERLR_WAS_PETITION_FILED_MSPB') {
        if (val === 'Yes') {
            hyf.util.showComponent('petition_review_date_group');
        }
        else {
            hyf.util.hideComponent('petition_review_date_group');
        }
    }
}

function appealDateEvents(e) {
    var eventSource = e.target.id;
    var val = $('#' + eventSource).val();
    if (eventSource && eventSource === 'AP_ERLR_PREHEARING_DT') {
        var hearingDate = FormState.getElementValue('AP_ERLR_HEARING_DT');
        Appeal.dateValidate({
            value1: val,
            value2: hearingDate
        }, 'Date of Hearing must be after the Date of Prehearing Conference.', 'AP_ERLR_PREHEARING_DT');
    }

    if (eventSource && eventSource === 'AP_ERLR_HEARING_DT') {
        var phearingDt = FormState.getElementValue('AP_ERLR_PREHEARING_DT');
        Appeal.dateValidate({
            value1: phearingDt,
            value2: val
        }, 'Date of Hearing must be after the Date of Prehearing Conference.', 'AP_ERLR_HEARING_DT');
    }

    if (eventSource && eventSource === 'AP_ERLR_PREHEARING_DT_MSPB') {//prehearingDateMSPB
        var hearing = FormState.getElementValue('AP_ERLR_HEARING_DT_MSPB');
        Appeal.dateValidate({
            value1: val,
            value2: hearing
        }, 'Date of Hearing must be after the Date of Prehearing Conference.', 'AP_ERLR_PREHEARING_DT_MSPB');
    }

    if (eventSource && eventSource === 'AP_ERLR_HEARING_DT_MSPB') {//hearingDateMSPB
        var hearingMSPB = FormState.getState('AP_ERLR_PREHEARING_DT_MSPB');
        Appeal.dateValidate({
            value1: val,
            value2: hearingMSPB
        }, 'Date of Hearing must be after the Date of Prehearing Conference.', 'AP_ERLR_HEARING_DT_MSPB');
    }

    if (eventSource && eventSource == 'AP_ERLR_PREHEARING_DT_SC') {
        var phearingDTSC = FormState.getState('AP_ERLR_HEARING_DT_SC');
        Appeal.dateValidate({
            value1: val,
            value2: phearingDTSC
        }, 'Date of Hearing must be after the Date of Prehearing Conference.', 'AP_ERLR_PREHEARING_DT_SC');
    }

    if (eventSource && eventSource === 'AP_ERLR_HEARING_DT_SC') {
        var phearingSC = FormState.getState('AP_ERLR_PREHEARING_DT_SC');
        Appeal.dateValidate({
            value1: val,
            value2: phearingSC
        }, 'Date of Hearing must be after the Date of Prehearing Conference.', 'AP_ERLR_HEARING_DT_SC');
    }
}


