(function (window) {
    'use strict';

    function cms_investigation() {

        function init() {
            var reqFieldForActivity =
                [
                    {
                        actName: globalVars.actAll,
                        reqFieldIds:
                            []
                    },
                    {
                        actName: globalVars.actCaseCreation,
                        reqFieldIds:
                            []
                    },
                    {
                        actName: globalVars.actCaseComplete,
                        reqFieldIds:
                            [
                                'INVESTIGATION_TYPE',
                                'I_MISCONDUCT_FOUND'
                            ]
                    }
                ];
            CommonOpUtil.dynamicMandatory(reqFieldForActivity);
            $('#I_MISCONDUCT_FOUND').on('change', function (e) {
                var value;
                try {
                    value = e.target.options[e.target.options.selectedIndex].value;
                    if (value !== 'undefined' && value === 'No') {
                        $('#tab_control_tab_tab90').show();
                        $('#CC_CONDUCT_FOUND').hide();
                    } else if (value !== 'undefined' && value === 'Yes') {
                        $('#CC_CONDUCT_FOUND').show();
                        $('#tab_control_tab_tab90').hide();
                    } else {
                        $('#CC_CONDUCT_FOUND').hide();
                    }
                } catch (error) {
                    console.log('Error:', error);
                }
            });
            var misconduct = FormState.getElementValue('I_MISCONDUCT_FOUND');
            if (misconduct !== 'undefined' && misconduct === 'No') {
                $('#tab_control_tab_tab90').show();
                $('#CC_CONDUCT_FOUND').hide();
            } else if (misconduct !== 'undefined' && misconduct === 'Yes') {
                $('#CC_CONDUCT_FOUND').show();
                $('#tab_control_tab_tab90').hide();
            } else {
                $('#CC_CONDUCT_FOUND').hide();
            }
        }

        function render() {

        }

        return {
            init: init,
            render: render
        }
    }

    (window.cms_investigation !== undefined ? window.cms_investigation : (window.cms_investigation = cms_investigation()));
})(window)