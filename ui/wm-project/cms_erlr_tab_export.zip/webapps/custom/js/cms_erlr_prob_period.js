(function(window){
function cms_erlr_prob_period(){
    var initialized= false;
	var groups = [
	'ppa_termination_type_pre_employment_group',
	'ppa_termination_type_probation_group',
	'ppa_oral_presentation_date_group',
	'ppa_written_response_group',
	'ppa_pre_emp_termination_oral_presentation_group',
	'ppa_pre_emp_termination_response_group',
	'ppa_oral_presentation_date_group',
	'ppa_written_response_group',
	'ppa_pre_emp_termination_oral_presentation_group',
	'ppa_pre_emp_termination_response_group',
	'ppa_reassignment_date_notice_issued',
	'ppa_emp_appeal_decision_group',
	'ppa_action_Demotion_group',
	'ppa_action_Reassignment_group',
	'ppa_action_Termination_group',
	'ppa_termination_type_group'
	];
	var actionTypes =[
	'alt_discipline'
	];
	var grades ={'GP':['01','02','03','04','05','06','07','08','09','10','11','12','13','14','15'],
			'GR':['01','02','03','04','05','06','07','08','09','10','11','12','13','14','15'],
			'GS':['01','02','03','04','05','06','07','08','09','10','11','12','13','14','15'],
			'ES':['01','02','03','04','05','06'],
			'WG':['01','02','03','04','05','06','07','08','09','10']
	};
	var dateFields =[
		'PPA_PROP_ACTION_ISSUED_DT',
		'PPA_ORAL_PREZ_DT',
		'PPA_RESPONSE_DUE_DT',
		'PPA_WRITTEN_RESPONSE_SUBMITTED_DT',
		'PPA_DECISION_ISSUED_DT',
		'PPA_DEMO_FINAL_AGENCY_EFF_DT',
		'PPA_NOTICE_ISSUED_DT',
		'PPA_EFFECTIVE_DT',
		'PPA_WRITTEN_RESPONSE_DUE_DT',
		'PPA_WRITTEN_SUBMITTED_DT',
		'PPA_DECIDING_OFFCL_NAME',
		'PPA_REMOVAL_EFFECTIVE_DT',
		'PPA_TERM_PROP_ACTION_DT',
		'PPA_TERM_ORAL_PREZ_DT',
		'PPA_TERM_WRITTEN_RESP_DUE_DT',
		'PPA_TERM_WRITTEN_RESP_DT',
		'PPA_TERM_DECISION_ISSUED_DT',
		'PPA_TERM_EFFECTIVE_DECISION_DT',
		'PPA_PRE_PROBATION_TERMINATION_DECISION_ISSUED_DT',
		'PPA_REPRIMAND_ISSUE_DT'
	];
	var inputEvents = {
		/*I intend to have a list of dropdowns and their corresponding event hanlder helper functions, so that I can access the reference to the function, then call it 
		like dropdownTargets[event.target.id](),where event target id corresponds to the obj key*/
		
		 'PPA_ACTION_TYPE':actionTypeEvent,
		 'PPA_PROP_ACTION_ISSUED': {action:hyfToogle,target:''},
		 'PPA_ORAL_PREZ_REQUESTED':{action:hyfToogle,target:'oral_presentation_date_group'},
		 'PPA_ORAL_RESPONSE_SUBMITTED': {action:hyfToogle,target:'written_response_group'},	 
		 'PPA_TERM_ORAL_PREZ_REQUESTED' : {action:hyfToogle,target:'pre_emp_termination_oral_presentation_group'},
		 'PPA_TERM_WRITTEN_RESP' : {action:hyfToogle,target:'pre_emp_termination_response_group'},		 
	};
	function init(){
		groups.forEach(function(el,index){
			hyf.util.hideComponent(el);
		});
		var reqFieldForActivity = 
		[
			{
				actName: globalVars.actAll,
				reqFieldIds: 
				[
				
				
				]
			},
			{
				actName: globalVars.actCaseCreation,
				reqFieldIds: 
				[
					
				]
			},
			{
				actName: globalVars.actCaseComplete,
				reqFieldIds: 
				[
				'PPA_ACTION_TYPE',
				'PPA_PROP_ACTION_ISSUED_DT',
				'PPA_EMP_APPEAL_DECISION',
				'PPA_ORAL_PREZ_REQUESTED',
				'PPA_ORAL_PREZ_DT',
				'PPA_ORAL_RESPONSE_SUBMITTED',
				'PPA_RESPONSE_DUE_DT',
				'PPA_WRITTEN_RESPONSE_SUBMITTED_DT',
				'PPA_PROPOSED_POS_TITLE',
				'PPA_PROPOSED_PPLAN',
				'PPA_PROPOSED_SERIES',
				'PPA_PROPOSED_INFO_GRADE',
				'PPA_PROPOSED_INFO_STEP',
				'PPA_FINAL_INFO_STEP',
				'PPA_DEMO_FINAL_AGENCY_DECISION',
				'PPA_DECIDING_OFFCL_SRCH',
				'PPA_DECISION_ISSUED_DT',
				'PPA_DEMO_FINAL_AGENCY_EFF_DT',
				'PPA_NOTICE_ISSUED_DT',
				'PPA_EFFECTIVE_DT',
				'PPA_CURRENT_ADMIN_CODE',
				'PPA_RE_ASSIGNMENT_CURR_ORG',
				'PPA_RE_ASSIGNMENT_FINAL_ORG',
				'PPA_TERMINATION_TYPE',
				'PPA_TERM_PROP_ACTION_DT',
				'PPA_TERM_ORAL_PREZ_REQUESTED',
				'PPA_TERM_ORAL_PREZ_DT',
				'PPA_TERM_WRITTEN_RESP',
				'PPA_TERM_WRITTEN_RESP_DUE_DT',
				'PPA_TERM_WRITTEN_RESP_DT',
				'PPA_TERM_AGENCY_DECISION',
				'PPA_TERM_DECIDING_OFFCL_NAME_SRCH',
				'PPA_TERM_DECISION_ISSUED_DT',
				'PPA_TERM_EFFECTIVE_DECISION_DT'
				]
			}
		];

        populatePPADemotionCurPosnData();

		$('#PPA_ACTION_TYPE').on('change',actionTypeEvent);
		$('#PPA_TERM_PROP_ACTION_DT,#PPA_DECISION_ISSUED_DT,#PPA_PROP_ACTION_ISSUED_DT').on('change',dateChangeEventConduct);
		$('#PPA_TERMINATION_TYPE').on('change',terminationationTpe);
		$('#PPA_PROPOSED_PPLAN,#PPA_FINAL_PPLAN').on('change',populateGrades);
		$('#PPA_DEMO_FINAL_AGENCY_DECISION,#PPA_TERM_AGENCY_DECISION').on('change',finalAgencyDecision);
		dateFields.forEach(function(el){
			if(el !==''){
				try{hyf.calendar.setDateConstraint(el, 'Maximum', 'Today');}catch(err){}
			}
		});
		
		PPAAutoCompleteOptions('PPA_DECIDING_OFFCL');
		PPAAutoCompleteOptions('PPA_TERM_DECIDING_OFFCL_NAME');
		PPAAdminCodeAutoCompleteOptions('PPA_FINAL_ADMIN_CODE');
		PPAAdminCodeAutoCompleteOptions('PPA_TERM_DECIDING_OFFCL_NAME');	
		
		CommonOpUtil.dynamicMandatory(reqFieldForActivity);	
		hyf.util.hideComponent('tab_control_tab_tab4');
		populateCIDemotionCurPosnData(); 
		hyf.util.hideComponent('ppa_action_Demotion_group');
		hyf.util.hideComponent('ppa_action_Reassignment_group');
		hyf.util.hideComponent('ppa_action_Termination_group');
	}
	
function booleanCheckBox(group){
	var checked  = false;
	var list  = $('.' + group).get(); 
	if(list && Array.isArray(list)&& list.length > 0){
		list.forEach(function(el){
			if($(el).prop('checked')){
				checked = true;
			}
		});
	}
	return checked;
}
 function render(){
	var actionType = FormState.getState('PPA_ACTION_TYPE');
	var terminationActionType = FormState.getState('PPA_TERMINATION_TYPE');
	 if(actionType && actionType.dirty){
		if(actionType.value ==='Demotion'){
			hyf.util.showComponent('ppa_action_Demotion_group');
			hyf.util.hideComponent('ppa_action_Reassignment_group');
			hyf.util.hideComponent('ppa_action_Termination_group');
			hyf.util.showComponent('ppa_emp_appeal_decision_group');
			hyf.util.hideComponent('ppa_termination_type_group');
		}else if(actionType.value ==='Reassignment'){
			hyf.util.showComponent('ppa_action_Reassignment_group');
			hyf.util.hideComponent('ppa_action_Demotion_group');
			hyf.util.hideComponent('ppa_action_Termination_group');
			hyf.util.showComponent('ppa_emp_appeal_decision_group');
			hyf.util.hideComponent('ppa_termination_type_group');
		}else if(actionType.value === 'Termination'){
			hyf.util.showComponent('ppa_action_Termination_group');
			hyf.util.hideComponent('ppa_action_Demotion_group');
			hyf.util.hideComponent('ppa_action_Reassignment_group');
			hyf.util.showComponent('ppa_emp_appeal_decision_group');
			hyf.util.showComponent('ppa_termination_type_group')
		}else{
			hyf.util.hideComponent('ppa_action_Demotion_group');
			hyf.util.hideComponent('ppa_action_Reassignment_group');
			hyf.util.hideComponent('ppa_action_Termination_group');
			hyf.util.hideComponent('ppa_emp_appeal_decision_group');
			hyf.util.hideComponent('ppa_termination_type_group')
		}
	 }
	if(terminationActionType && terminationActionType.dirty){
		if(terminationActionType.value ==='pre_emp'){
			hyf.util.showComponent('ppa_termination_type_pre_employment_group');
			hyf.util.hideComponent('ppa_termination_type_probation_group');
		}else if(terminationActionType.value ==='probation'){
			hyf.util.showComponent('ppa_termination_type_probation_group');
			hyf.util.hideComponent('ppa_termination_type_pre_employment_group');
		}else{
			hyf.util.hideComponent('ppa_termination_type_probation_group');
			hyf.util.hideComponent('ppa_termination_type_pre_employment_group');
		}
	 }	 
	 var dmnOralPrez = FormState.getElementValue('PPA_ORAL_PREZ_REQUESTED');
	 var dmnOralResponse = FormState.getElementValue('PPA_ORAL_RESPONSE_SUBMITTED');
	 
	 var dmnpFinalAgency = FormState.getElementValue('PPA_DEMO_FINAL_AGENCY_DECISION');
	 if(dmnpFinalAgency === 'undefined'){
		finalAgencyDecisionHelper('PPA_DEMO_FINAL_AGENCY_DECISION',dmnpFinalAgency);
	 }

	 if(dmnOralPrez && dmnOralPrez === 'Y'){
		 hyf.util.showComponent('ppa_oral_presentation_date_group');
	 }else{
		 hyf.util.hideComponent('ppa_oral_presentation_date_group');
	 }
	 if(dmnOralResponse && dmnOralResponse === 'Y'){
		 hyf.util.showComponent('ppa_written_response_group');
	 }else{
		 hyf.util.hideComponent('ppa_written_response_group');
	 }
	 
    }

function PPAAutoCompleteOptions(id){
	var optionConfig = {
		id: id + '_SRCH',
		 baseURL: '/bizflowwebmaker/StratCon_AUT',
		 targetURL : '/bizflowwebmaker/cms_erlr_service/searchParticipants.do?g=&q=',
		 minLength: 2,
		 minSelectionCount: 0,
		 maxSelectionCount: 1,
		 mapFunction: function(context){
			return {
				id: $("MID", context).text(),
				participantId:  "[" + $("MTYPE", context).text() + "]" + $("MID", context).text(),
				name:  $("NAME", context).text(),
				email: $("EMAIL", context).text(),
				org:  $("DEPTNAME", context).text(),
				title: $("JOBTITLENAME", context).text()
			};
		},
		 getSelectionLabel: function(item){
			var label = item.name + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '');
			if (item.title) {
				label += '/' + item.title;
			}
			return label;
		},
		getCandidateLabel: function(item) {
			return item.name + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '');
		},
		 getItemID : function(item){
			 return item.id;
		 },
		 setDataToForm: function (values) {
             FormState.updateObjectValue(id, values);
         },
		  // initialize
         initialItems: FormState.getElementArrayValue(id, []),
		};
		FormAutoComplete.makeAutoCompletion(optionConfig);
}

function PPAAdminCodeAutoCompleteOptions(id){
	var optionConfig = {
		id: id + '_SEARCH',
		 baseURL: '/bizflowwebmaker/StratCon_AUT',
		 targetURL : '/bizflowwebmaker/StratCon_AUT/SearchAdmOffOrg.do?searchAdmOff=',
		 minLength: 2,
		 minSelectionCount: 0,
		 maxSelectionCount: 1,
		 mapFunction: function(context){
			return {
				adminCd:      $("AC_ADMIN_CD", context).text(),
				adminCdDesc:  $("AC_ADMIN_CD_DESCR", context).text()
			};
		},
		 getSelectionLabel: function(item){
			return item.adminCd;
		},
		getCandidateLabel: function(item) {
			return item.adminCd + ' - ' + item.adminCdDesc;// + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '');
		},
		 getItemID : function(item){
			 return item.id;
		 },
		 setDataToForm: function (values) {
             if (typeof values == 'undefined' || values == null) return;
			var item = null;
			if ($.isArray(values)) {
				item = values[0];
			} else {
				item = values;
			}
			
			if ( typeof item === 'object' && item != null 
					&& typeof item.adminCd != 'undefined' && item.adminCd != null && item.adminCd.trim().length > 0
					&& typeof item.adminCdDesc != 'undefined' && item.adminCdDesc != null && item.adminCdDesc.trim().length > 0 ) {
				$('#PPA_RE_ASSIGNMENT_FINAL_ORG').text(item.adminCdDesc);
				FormState.updateObjectValue('PPA_FINAL_ADMIN_CODE', values);
				FormState.updateVariableValue('PPA_RE_ASSIGNMENT_FINAL_ORG', item.adminCdDesc, false);
			} else {
				$('#PPA_RE_ASSIGNMENT_FINAL_ORG').text('');
				FormState.updateObjectValue('PPA_FINAL_ADMIN_CODE', []);
				FormState.updateVariableValue('PPA_RE_ASSIGNMENT_FINAL_ORG', '', false);
			}
         },
		  // initialize
         initialItems: FormState.getElementArrayValue(id, []),
		};
		//FormAutoComplete.makeAutoCompletion(optionConfig);
}
function dateChangeEventConduct(e){
	var id = e.target.id;
	var dt1 ='';
	var dt2 ='';
	switch(id){
		case 'PPA_TERM_PROP_ACTION_DT':
			dateValidateHelper('PPA_TERM_PROP_ACTION_DT','PPA_TERM_DECISION_ISSUED_DT','PPA_TERM_DECISION_ISSUED_DT');
		break;
		case 'PPA_DECISION_ISSUED_DT':
			dateValidateHelper('PPA_DECISION_ISSUED_DT','PPA_PROPOSE_ACTION_ISSUED_DT','PPA_PROP_ACTION_ISSUED_DT');
		break;	
	}
	
}

function terminationationTpe(e){
	var val;
	try{
		val = e.target.options[e.target.options.selectedIndex].value;
		if(val ==='pre_emp'){
		hyf.util.showComponent('ppa_termination_type_pre_employment_group');
		hyf.util.hideComponent('ppa_termination_type_probation_group');
		}else if(val==='probation'){
		hyf.util.showComponent('ppa_termination_type_probation_group');
		hyf.util.hideComponent('ppa_termination_type_pre_employment_group');
		}else{
		hyf.util.hideComponent('ppa_termination_type_pre_employment_group');
		hyf.util.hideComponent('ppa_termination_type_probation_group');
		}		
	}catch(err){
		
	}
	
	$('#ppa_action_Termination_group input').val('');
	$('#ppa_action_Termination_group input[type=checkbox]').prop('checked',false);
	$('#ppa_action_Termination_group select').not('#PPA_TERMINATION_TYPE').val('');
	$('#ppa_pre_emp_termination_oral_presentation_group').hide();
	$('#ppa_pre_emp_termination_response_group').hide();
}
function actionTypeEvent(e){
	var val ='';
	try{
		val = e.target.options[e.target.options.selectedIndex].value;
		if(val ==='Demotion'){
			hyf.util.showComponent('ppa_action_Demotion_group');
			hyf.util.hideComponent('ppa_action_Reassignment_group');
			hyf.util.hideComponent('ppa_action_Termination_group');
		}else if(val ==='Reassignment'){
			hyf.util.showComponent('ppa_action_Reassignment_group');
			hyf.util.hideComponent('ppa_action_Demotion_group');
			hyf.util.hideComponent('ppa_action_Termination_group');
		}else if(val ==='Termination'){
			hyf.util.showComponent('ppa_action_Termination_group');
			hyf.util.hideComponent('ppa_action_Demotion_group');
			hyf.util.hideComponent('ppa_action_Reassignment_group');
		}else{
			hyf.util.hideComponent('ppa_action_Demotion_group');
			hyf.util.hideComponent('ppa_action_Reassignment_group');
			hyf.util.hideComponent('ppa_action_Termination_group');
		}
		if(value2 && value2  !== undefined){
		$('#PPA_EMP_APPEAL_DECISION').val('');		
			FormState.updateObjectValue('PPA_EMP_APPEAL_DECISION','');
			if(value2 !== '' && actions.includes(value2)){
				hyf.util.showComponent('emp_appeal_decision_group');
			}else{
				hyf.util.hideComponent('emp_appeal_decision_group');
			}
			$('#conduct_issue_layout input[type="text"]').val('');
			$('#conduct_issue_layout input[type="checkbox"]').prop('checked',false);
			$('#conduct_issue_layout select[id!="PPA_ACTION_TYPE"]').val('');
		}
	}catch(err){}	
}
function dateDecisionIssued(e){
	var days = 0;
	var dt1 = $('#PPA_PROPOSE_ACTION_ISSUED_DT').val();
	var dt2 = $('#PPA_DECISION_ISSUED_DT').val();
	if(dt2 && dt1){
		var m1  = new Date(dt1);
		var m2 = new Date(dt2);
		if(m2.getTime() < m1.getTime()){
			bootbox.alert({
            message: 'Date must be greater than Date Proposed Action Issued to Employee Date.',
            callback: function(){
                $('#PPA_DECISION_ISSUED_DT').val('');
				FormState.updateObjectValue('PPA_DECISION_ISSUED_DT','');
            }
        });
	}
}
}
function helperEventHandler(e){
	var target = e.target;
	var dropdownAction = target.options[target.options.selectedIndex].value;
	FormState.updateObjectValue(target.id, dropdownAction);
	dropdownCallBack(target.id,dropdownAction);
}
function hyfToogle(val,id){
	CommonOpUtil.hyfShowOrHide({value:val},id);	
}

function dropdownCallBack(dropdownId, value){
	if(typeof dropdownId !=='undefined'){
		if(inputEvents[dropdownId] !=='undefined' && typeof inputEvents[dropdownId] === 'function'){
			inputEvents[dropdownId](dropdownId,value);
		}
		else if( typeof inputEvents[dropdownId] === 'object' && inputEvents[dropdownId].action !=='undefined'){
			var target = inputEvents[dropdownId].target;
			inputEvents[dropdownId].action(value,target);
		}		
	}
}


function appendAdminCode(item){
		var admin_code = item.adminCode +' - '+item.description;
	return '<a role="option">' + admin_code +'</a>'
}

function populateAdminCode(item){
	$('#PPA_FINAL_ADMIN_CODE').val(item.adminCode);
	$('#PPA_RE_ASSIGNMENT_FINAL_ORG').text(item.description);
}



function dateAutoPopulate(targetId,sourceValue){
	if(sourceValue !==''){
		$('#' +targetId).val(sourceValue);
	}
}
function populateGrades(e){
		var source = e.target.id;
		var target = '';
		var payPlan = e.target.options[e.target.options.selectedIndex].value;
		if(source === 'PPA_PROPOSED_PPLAN'){
			target ='PPA_PROPOSED_INFO_GRADE';
		}else{
			target = 'PPA_FINAL_INFO_GRADE';
		}
		$('#' +target).html('');
		if(payPlan !=='default' &&  ConductIssue.grades[payPlan] !== undefined){
		 $('#' + target).append('<option value="default">Select one </option>');
		 ConductIssue.grades[payPlan].forEach(function(val){	
			$('#' + target).append('<option value="' + val + '">' + val + '</option>');
		});
		hyf.util.showComponent(target);
	}else{
		hyf.util.hideComponent(target,null);
	}
}

function populatePPADemotionCurPosnData() {
    var genEmployee = FormState.getElementJSONValue('GEN_EMPLOYEE');
    if (typeof genEmployee === 'undefined') return;
    $('#PPA_POS_TITLE').text(genEmployee.positionTitle);
    $('#PPA_PPLAN').text(genEmployee.payPlan);
    $('#PPA_SERIES').text(genEmployee.series);
    $('#PPA_CURRENT_INFO_STEP').text(genEmployee.grade);
    $('#PPA_CURRENT_INFO_GRADE').text(genEmployee.step);
    FormState.updateVariableValue('PPA_POS_TITLE',  genEmployee.positionTitle, false);
    FormState.updateVariableValue('PPA_PPLAN',   genEmployee.payPlan, false);
    FormState.updateVariableValue('PPA_SERIES', genEmployee.series, false);
    FormState.updateVariableValue('PPA_CURRENT_INFO_STEP',      genEmployee.grade, false);
    FormState.updateVariableValue('PPA_CURRENT_INFO_GRADE',       genEmployee.step, false);

    $('#PPA_CURRENT_ADMIN_CODE').text(genEmployee.adminCode);
    $('#PPA_RE_ASSIGNMENT_CURR_ORG').text(genEmployee.adminCodeDesc);
    FormState.updateTextValue('PPA_CURRENT_ADMIN_CODE', genEmployee.adminCode, false);
    FormState.updateTextValue('PPA_RE_ASSIGNMENT_CURR_ORG', genEmployee.adminCodeDesc, false);
}
//TODO: dynamically hide/show fields based on
function finalAgencyDecision(e){
	var id = '';
	var value;
	try{
		id = e.target.id;
		value = e.target.options[e.target.options.selectedIndex].value;
		finalAgencyDecisionHelper(id,value);
	}catch(err){
		
	}	
}
function finalAgencyDecisionHelper(id,value){
	if(id ==='PPA_DEMO_FINAL_AGENCY_DECISION')
	{
		if(value ==='DemotionRescinded'){
			$('#PPA_DEMO_FINAL_AGENCY_EFF_DT').closest('.layoutContainerContent').hide();
			$('#PPA_NUMB_DAYS').closest('.layoutContainerContent').hide();
			$('#PPA_DEMO_DECISION_ISSUED_DT').closest('.layoutContainerContent').show();
		}else if(value ==='NoActionTaken'){
			$('#PPA_DEMO_FINAL_AGENCY_EFF_DT').closest('.layoutContainerContent').hide();
			$('#PPA_DEMO_DECISION_ISSUED_DT').closest('.layoutContainerContent').hide();
			$('#PPA_NUMB_DAYS').closest('.layoutContainerContent').hide();
		}else if(value === 'Suspension'){
			$('#PPA_DEMO_FINAL_AGENCY_EFF_DT').closest('.layoutContainerContent').show();
			$('#PPA_NUMB_DAYS').closest('.layoutContainerContent').show();
			$('#PPA_DEMO_DECISION_ISSUED_DT').closest('.layoutContainerContent').show();
		}else{
			$('#PPA_NUMB_DAYS').closest('.layoutContainerContent').hide();
			$('#PPA_DEMO_FINAL_AGENCY_EFF_DT').closest('.layoutContainerContent').show();
			$('#PPA_DEMO_DECISION_ISSUED_DT').closest('.layoutContainerContent').show();
		}		
		
	}
	if(id ==='PPA_TERM_AGENCY_DECISION')
	{
	  $('#PPA_TERM_NUMB_DAYS').closest('.layoutContainerContent').hide();
	
	}
		
}
return{
	init : init,
	render : render
}
}
(window.cms_erlr_prob_period !=undefined ? window.cms_erlr_prob_period : (window.cms_erlr_prob_period = cms_erlr_prob_period()));
})(window)