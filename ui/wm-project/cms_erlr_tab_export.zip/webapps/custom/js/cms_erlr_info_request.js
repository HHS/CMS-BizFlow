'use strict';
(function (window) {
    var cms_erlr_info_request = function () {
	
		var initialized = false;
		
		var dateFieldsPastPresent = 
		[
			'_IR_PROVIDE_DT',
			'IR_SUBMIT_DT',
			'_IR_DENIAL_NOTICE_DT'
		];
		
		var dateFieldsPresentFuture = 
		[
		];
		
		var reqFieldForActivity = 
		[
			{
				actName: globalVars.actAll,
				reqFieldIds: 
				[
				]
			},
			{
				actName: globalVars.actCaseCreation,
				reqFieldIds: 
				[
				]
			},
			{
				actName: globalVars.actCaseComplete,
				reqFieldIds: 
				[
				]
			}
		];

		var irProvideDtGroup, irDenialNoticeDtGroup;

		function initVisibility() {
            controlIrRequesterVisibility();
            controlIrApprovedVisibility();
            controlIrRequesterAppealDenialVisibility();
		}

		function setSelectElemValue(selElem) {
			if ( typeof selElem == 'undefined' || selElem == null 
					|| typeof selElem.id == 'undefined' || selElem.id == null 
					|| typeof selElem.options == 'undefined' || selElem.options == null ) {
				return;
			}
			var selectedVal = selElem.options[selElem.options.selectedIndex].value;
			var selectedTxt = selElem.options[selElem.options.selectedIndex].text;
			FormState.updateSelectValue(selElem.id, selectedVal, selectedTxt);
		}
		
		function controlIrRequesterVisibility() {
            var elemVal = FormState.getElementValue('IR_REQUESTER');
			CommonOpUtil.showHideLayoutGroup('ir_cms_requester_layout_group', ('CMS' === elemVal));
			CommonOpUtil.showHideLayoutGroup('ir_non_cms_requester_layout_group', ('NONCMS' === elemVal));
        }

        function controlIrApprovedVisibility() {
            var elemVal = FormState.getElementValue('IR_APPROVE');
            CommonOpUtil.showHideLayoutGroup('ir_provide_dt_group', ('Y' === elemVal));
            CommonOpUtil.showHideLayoutGroup('ir_not_approved_layout_group', ('N' === elemVal));
            CommonOpUtil.showHideLayoutGroup('ir_approved_in_part_layout_group', ('Approved in Part' === elemVal));
        }

        function controlIrRequesterAppealDenialVisibility() {
            var elemVal = FormState.getElementValue('IR_APPEAL_DENIAL');
            CommonOpUtil.showHideLayoutGroup('ir_appeal_denial_note_group', ('Y' === elemVal));
        }


		function initEventHandlers() {
			$('#IR_REQUESTER').on('change', function(e) {
				setSelectElemValue(e.target);
				controlIrRequesterVisibility();
			});
            $('#IR_APPROVE').on('change', function(e) {
                setSelectElemValue(e.target);
                controlIrApprovedVisibility();
            });
            $('#IR_APPEAL_DENIAL').on('change', function(e) {
                setSelectElemValue(e.target);
                controlIrRequesterAppealDenialVisibility();
            });


            irProvideDtGroup = MultiDataSelectField.init({ layoutGroupId: 'ir_provide_dt_group',
                                                                mandatory: true,
																dataFieldId: 'IR_PROVIDE_DT_LIST',
																sort: {fieldId:'IR_PROVIDE_DT', valueType: 'date', order: 'desc'},
																recordFields: ['IR_PROVIDE_DT']});

            irDenialNoticeDtGroup= MultiDataSelectField.init({ layoutGroupId: 'ir_denial_notice_dt_group',
                                                                mandatory: true,
																dataFieldId: 'IR_DENIAL_NOTICE_DT_LIST',
																sort: {fieldId:'IR_DENIAL_NOTICE_DT', valueType: 'date', order: 'desc'},
																recordFields: ['IR_DENIAL_NOTICE_DT','IR_DENIAL_NOTICE_REASON'],
                                                                dialog:{ input:{
                                                                                    init: function(){
                                                                                        $('#_IR_DENIAL_NOTICE_SELECT_REASON').on('change', function(e) {
                                                                                            var selElem = e.target;
                                                                                            if(0<selElem.options.selectedIndex){
                                                                                            	var selectedValue = selElem.options[selElem.options.selectedIndex].text;
                                                                                                var priorValue = $('#_IR_DENIAL_NOTICE_REASON').val();
                                                                                                if(-1 === priorValue.indexOf(selectedValue)){
                                                                                                    var txt = '• ' + selectedValue;
                                                                                                    var val = priorValue.trim();
                                                                                                    $('#_IR_DENIAL_NOTICE_REASON').val(val.length===0? txt : val + '\n' + txt);
																								}
																							}
                                                                                        });
                                                                                    }
                                                                                }
                                                                        }});

        }

        function setupCustomWidget() {
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_info_request::setupCustomWidget START');

            var searchRequesterNameOption = {
                id: 'IR_CMS_REQUESTER_NAME_SEARCH',
                baseURL: '/bizflowwebmaker/StratCon_AUT',
                targetURL: '/bizflowwebmaker/cms_erlr_service/contactInfo.do?emp=',
                minLength: 3,
                minSelectionCount: 0,
                maxSelectionCount: 1,
                mapFunction: function(context){
                    return {
                        email: $("EMAIL_ADDR", context).text(),
                        name:  $("LAST_NAME", context).text() + ', '+$("FIRST_NAME", context).text()+' '+$("MIDDLE_NAME", context).text()
                    }
                },
                getSelectionLabel: function(item){
                    return item.name + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '');
                },
                getCandidateLabel: function(item){
                    return item.name + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '');
                },
                getItemID:  function(item){
                    return item.email;
                },
                setDataToForm: function (values) {
                    FormState.updateObjectValue('IR_CMS_REQUESTER_NAME', values);
                },

                // initialize
                initialItems: FormState.getElementArrayValue('IR_CMS_REQUESTER_NAME', [])
            };
            FormAutoComplete.makeAutoCompletion(searchRequesterNameOption);

            FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_info_request::setupCustomWidget END');
        }


        function init() {
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_info_request::init START');
			
			//-----------------------------------
			// visibility configuration
			//-----------------------------------
			initVisibility();
			
			
			//-----------------------------------
			// validation configuration
			//-----------------------------------
			dateFieldsPastPresent.forEach(function(item){
				hyf.calendar.setDateConstraint(item, 'Maximum', 'Today');
			});
			dateFieldsPresentFuture.forEach(function(item){
				hyf.calendar.setDateConstraint(item, 'Minimum', 'Today');
			});
			CommonOpUtil.dynamicMandatory(reqFieldForActivity);
			
			
			//-----------------------------------
			// event handler configuration
			//-----------------------------------
			initEventHandlers();
			
			
			//-----------------------------------
			// custom ui element initialization
			//-----------------------------------
			setupCustomWidget();
			
			initialized = true;
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_erlr_info_request::init END');
		}
		
		function render() {
            irProvideDtGroup.render();
            irDenialNoticeDtGroup.render();
		}

		return {
			initialized: initialized,
			render: render,
			init: init
		};
	};
	
    var _initializer = window.cms_erlr_info_request || (window.cms_erlr_info_request = cms_erlr_info_request());
})(window);

