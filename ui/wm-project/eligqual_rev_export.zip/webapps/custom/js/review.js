var eligQualRev = {
	
	// event handler for CNDT_ELIGIBLE
	onChange_IsCandidateEligible: function(){
		var isCandidateEligible = $('#CNDT_ELIGIBLE').val();
		if (isCandidateEligible == 'Yes'){
			$('#inelig_reason_group').hide();
			clearElementsInContainer('inelig_reason_group');
			var apptTypeTxt = $('#SG_AT_ID option:selected').text();
			if (typeof apptTypeTxt != 'undefined' && apptTypeTxt != null && apptTypeTxt == 'Volunteer'){
				$('#qualification_group').hide();
				clearElementsInContainer('qualification_group');
			} else {
				$('#qualification_group').show();
				eligQualRev.onChange_IsCandidateQualified();
			}
		} else if (isCandidateEligible == 'No'){
			$('#inelig_reason_group').show();
			$('#qualification_group').hide();
			clearElementsInContainer('qualification_group');
		} else {
			$('#inelig_reason_group').hide();
			clearElementsInContainer('inelig_reason_group');
			$('#qualification_group').hide();
			clearElementsInContainer('qualification_group');
		}
	},
	
	// event handler for CNDT_QUALIFIED
	onChange_IsCandidateQualified: function(){
		var isCandidateQualified = $('#CNDT_QUALIFIED').val();
		if (isCandidateQualified == 'No'){
			$('#disqual_reason_group').show();
		} else {
			$('#disqual_reason_group').hide();
			clearElementsInContainer('disqual_reason_group');
		}
	},
	
	getEligQualFlag: function(){
		var eligFlag = null;
		var qualFlag = null;
		var result = 'No';
		
		eligFlag = $('#CNDT_ELIGIBLE option:selected').val();
		if (eligFlag == 'Yes'){
			qualFlag = $('#CNDT_QUALIFIED option:selected').val();
			if (qualFlag == 'Yes'){
				result = 'Yes';
			} else if (qualFlag == 'No'){
				result = 'No';
			} else {
				// if Appointment Type is Volunteer, CNDT_QUALIFIED will be hidden and value will be cleared, which should set result to Yes
				var apptTypeTxt = $('#SG_AT_ID option:selected').text();
				if (apptTypeTxt == 'Volunteer'){
					result = 'Yes';
				} else {
					result = 'No';
				}
			}
		}
		
		return result;
	},
	
	setIneligibilityReasonOptions: function(){
		var apptTypeTxt = $('#SG_AT_ID option:selected').text();
		if (typeof apptTypeTxt != 'undefined' && apptTypeTxt != null){
			// conditionally show/hide Schedule A
			if (apptTypeTxt == 'Schedule A'){
				// show schedule a options
				eligQualRev.showIneligReasonsForScheduleA();
			} else {
				// hide schedule a options
				eligQualRev.hideIneligReasonScheduleA();
			}
			// conditionally show/hide Volunteer - Student
			if (apptTypeTxt == 'Volunteer') {
				var volTypeTxt = $('#SG_VT_ID option:selected').text();
				if (typeof volTypeTxt != 'undefined' && volTypeTxt != null && volTypeTxt == 'Student Volunteer'){
					// show student volunteer options
					eligQualRev.showIneligReasonsForVolunteerStudent();
				} else {
					// hide student volunteer options
					eligQualRev.hideIneligReasonVolunteerStudent();
				}
			} else {
				// hide student volunteer options
				eligQualRev.hideIneligReasonVolunteerStudent();
			} 
		} else {
			// hide schedule a options
			eligQualRev.hideIneligReasonScheduleA();
			// hide student volunteer options
			eligQualRev.hideIneligReasonVolunteerStudent();
		}
	},
	
	showIneligReasonsForScheduleA: function(){
		$.each($('#INELIG_REASON hiddenOption').filter(function(){ return $(this).html().indexOf('Schedule A') >= 0; }), function(index, item) {
			$(this).replaceWith('<option value="' + $(this).attr('value') + '">' + $(this).html() + '</option>');
		});
	},
	
	hideIneligReasonScheduleA: function(){
		$.each($('#INELIG_REASON option').filter(function(){ return $(this).html().indexOf('Schedule A') >= 0; }), function(index, item) {
			$(this).replaceWith('<hiddenOption value="' + $(this).attr('value') + '">' + $(this).html() + '</hiddenOption>');
		});
	},
	
	showIneligReasonsForVolunteerStudent: function(){
		$.each($('#INELIG_REASON hiddenOption').filter(function(){ return $(this).html().indexOf('student volunteer program') >= 0; }), function(index, item) {
			$(this).replaceWith('<option value="' + $(this).attr('value') + '">' + $(this).html() + '</option>');
		});
	},
	
	hideIneligReasonVolunteerStudent: function(){
		$.each($('#INELIG_REASON option').filter(function(){ return $(this).html().indexOf('student volunteer program') >= 0; }), function(index, item) {
			$(this).replaceWith('<hiddenOption value="' + $(this).attr('value') + '">' + $(this).html() + '</hiddenOption>');
		});
	},
	
	
	// initialization function/method called from onload event of page; performs
	// various activities to setup the page UI, hide/show fields
	init: function() {
		CMSUtility.debugLog('eligQualRev - init START');
		
		$('#CNDT_ELIGIBLE').on('change', eligQualRev.onChange_IsCandidateEligible);
		$('#CNDT_QUALIFIED').on('change', eligQualRev.onChange_IsCandidateQualified);
		
		// just in case the dependent tabs are not fully loaded before accessing element in those tabs
		$(document).on('CMS_ALL_TAB_LOADED', function() {
			eligQualRev.onChange_IsCandidateEligible();
			eligQualRev.onChange_IsCandidateQualified();
			eligQualRev.setIneligibilityReasonOptions();
		});
		
		CMSUtility.debugLog('eligQualRev - init END');
	}
} // end of eligQualRev

function clearElementsInContainer(containerId){
	$('#' + containerId).find('input[type=text], input[type=checkbox], input[type=radio], textarea, select').each(function(){
		$(this).val('');
	});
}