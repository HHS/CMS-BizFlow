(function (window) {
    var cms_incentives_general = function () {
        var _initialized = false;
        var _selectingOfficial_ac = null;
        var _executiveOfficer_ac = null;
        var _hrLiaison_ac = null;
        var _hrSpecialist_ac = null;
        var _hrSpecialist2_ac = null;

        function setPVRelatedUserIds() {
            var ids = '';
            var so = FormState.getElementArrayValue('selectingOfficial', []);
            var xo = FormState.getElementArrayValue('executiveOfficers', []);
            var hrl = FormState.getElementArrayValue('hrLiaisons', []);
            var hrs = FormState.getElementArrayValue('hrSpecialist', []);
            var hrs2 = FormState.getElementArrayValue('hrSpecialist2', []);
            var i;

            for (i = 0; i < so.length; i++) {
                ids += '{S}' + so[i].id + ";";
            }
            for (i = 0; i < xo.length; i++) {
                ids += '{X}' + xo[i].id + ";";
            }
            for (i = 0; i < hrl.length; i++) {
                ids += '{L}' + hrl[i].id + ";";
            }
            for (i = 0; i < hrs.length; i++) {
                ids += '{P}' + hrs[i].id + ";";
            }
            for (i = 0; i < hrs2.length; i++) {
                ids += '{T}' + hrs2[i].id + ";";
            }

            FormState.updateObjectValue('relatedUserIds', ids);
        }

        function _mapFunction(context) {
            return {
                id: $("MID", context).text(),
                participantId: "[" + $("MTYPE", context).text() + "]" + $("MID", context).text(),
                name: $("NAME", context).text(),
                email: $("EMAIL", context).text(),
                org: $("DEPTNAME", context).text(),
                title: $("JOBTITLENAME", context).text()
            };
        }

        function _getSelectionLabel(item) {
            var label = item.name + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '') + ' ' + item.org;
            if (item.title) {
                label += '/' + item.title;
            }

            return label;
        }

        function _getCandidateLabel(item) {
            return item.name + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '');
        }

        function _getItemID(item) {
            return item.id;
        }

        function setSelectingOfficialAutoCompletion() {
            var option = {
                id: 'selectingOfficial_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchParticipants.do?g=Selecting+Officials&q=',
                minLength: 2,
                minSelectionCount: 1,
                maxSelectionCount: 1,

                mapFunction: _mapFunction,
                getSelectionLabel: _getSelectionLabel,
                getCandidateLabel: _getCandidateLabel,
                getItemID: _getItemID,
                setDataToForm: function (values) {
                    FormState.updateObjectValue('selectingOfficial', values);
                    setPVRelatedUserIds();
                },

                // initialize
                initialItems: FormState.getElementArrayValue('selectingOfficial', [])
            };

            _selectingOfficial_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        function setExecutiveOfficialAutoCompletion() {
            var option = {
                id: 'executiveOfficer_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchParticipants.do?g=Executive+Officers&q=',
                minLength: 3,
                minSelectionCount: 1,
                maxSelectionCount: 3,

                mapFunction: _mapFunction,
                getSelectionLabel: _getSelectionLabel,
                getCandidateLabel: _getCandidateLabel,
                getItemID: _getItemID,
                setDataToForm: function (values) {
                    FormState.updateObjectValue('executiveOfficers', values);
                    setPVRelatedUserIds();
                },

                initialItems: FormState.getElementArrayValue('executiveOfficers', [])
            };

            _executiveOfficer_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        function setHRLiaisonAutoCompletion() {
            var option = {
                id: 'hrLiaison_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchParticipants.do?g=HR+Liaison&q=',
                minLength: 3,
                minSelectionCount: 0,
                maxSelectionCount: 3,

                mapFunction: _mapFunction,
                getSelectionLabel: _getSelectionLabel,
                getCandidateLabel: _getCandidateLabel,
                getItemID: _getItemID,
                setDataToForm: function (values) {
                    FormState.updateObjectValue('hrLiaisons', values);
                    setPVRelatedUserIds();
                },

                initialItems: FormState.getElementArrayValue('hrLiaisons', [])
            };

            _hrLiaison_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        function setHRSpecialistAutoCompletion() {
            var option = {
                id: 'hrSpecialist_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchParticipants.do?g=Selecting+Officials&q=',
                minLength: 2,
                minSelectionCount: 1,
                maxSelectionCount: 1,

                mapFunction: _mapFunction,
                getSelectionLabel: _getSelectionLabel,
                getCandidateLabel: _getCandidateLabel,
                getItemID: _getItemID,
                setDataToForm: function (values) {
                    FormState.updateObjectValue('hrSpecialist', values);
                    setPVRelatedUserIds();
                },

                // initialize
                initialItems: FormState.getElementArrayValue('hrSpecialist', [])
            };

            _hrSpecialist_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        function setHRSpecialist2AutoCompletion() {
            var option = {
                id: 'hrSpecialist2_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchParticipants.do?g=Selecting+Officials&q=',
                minLength: 2,
                minSelectionCount: 0,
                maxSelectionCount: 1,

                mapFunction: _mapFunction,
                getSelectionLabel: _getSelectionLabel,
                getCandidateLabel: _getCandidateLabel,
                getItemID: _getItemID,
                setDataToForm: function (values) {
                    FormState.updateObjectValue('hrSpecialist2', values);
                    setPVRelatedUserIds();
                },

                // initialize
                initialItems: FormState.getElementArrayValue('hrSpecialist2', [])
            };

            _hrSpecialist2_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        function setAssociatedRequestNumberAutoCompletion() {
            var option = {
                id: 'associatedIncentives_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchRequestNumbers.do?q=',
                minLength: 4,
                minSelectionCount: 1,
                maxSelectionCount: 1,

                mapFunction: function (context) {
                    var item = {
                        id: $("REQ_ID", context).text(),
                        requestNumber: $("REQUEST_NUMBER", context).text(),
                        requestDate: $("REQUEST_DATE", context).text(),
                        requestType: $("REQUEST_TYPE", context).text(),
                        adminCode: $("ADMIN_CODE", context).text(),
                        adminCodeDesc: $("ADMIN_CODE_DESC", context).text(),
                        so: {
                            id: $("SO_ID", context).text(),
                            participantId: "[" + $("SO_TYPE", context).text() + "]" + $("SO_ID", context).text(),
                            name: $("SO_NAME", context).text(),
                            email: $("SO_EMAIL", context).text(),
                            title: $("SO_TITLE", context).text(),
                            org: $("SO_ORG", context).text(),
                            prtcp: $("SO_PRTCP", context).text()
                        },
                        xo: [{
                            id: $("XO_ID1", context).text(),
                            participantId: "[" + $("XO_TYPE1", context).text() + "]" + $("XO_ID1", context).text(),
                            name: $("XO_NAME1", context).text(),
                            email: $("XO_EMAIL1", context).text(),
                            title: $("XO_TITLE1", context).text(),
                            org: $("XO_ORG1", context).text(),
                            prtcp: $("XO_PRTCP1", context).text()
                        }],
                        hrl: {
                            id: $("HRL_ID", context).text(),
                            participantId: "[" + $("HRL_TYPE", context).text() + "]" + $("HRL_ID", context).text(),
                            name: $("HRL_NAME", context).text(),
                            email: $("HRL_EMAIL", context).text(),
                            title: $("HRL_TITLE", context).text(),
                            org: $("HRL_ORG", context).text(),
                            ptctp: $("HRL_PRTCP", context).text()
                        },
                        position: {
                            title: $("POS_TITLE", context).text(),
                            payPlan: {
                                id: $("PAY_PLAN_ID", context).text(),
                                desc: $("PAY_PLAN_DESC", context).text()
                            },
                            series: {
                                id: $("POS_SERIES_ID", context).text(),
                                desc: $("POS_SERIES_DESC", context).text()
                            },
                            grade: [
                                $("POS_GRADE1", context).text(),
                                $("POS_GRADE2", context).text(),
                                $("POS_GRADE3", context).text(),
                                $("POS_GRADE4", context).text(),
                                $("POS_GRADE5", context).text()
                            ],
                            descNum: [
                                $("POS_DESC_NUM1", context).text(),
                                $("POS_DESC_NUM2", context).text(),
                                $("POS_DESC_NUM3", context).text(),
                                $("POS_DESC_NUM4", context).text(),
                                $("POS_DESC_NUM5", context).text(),
                            ],
                            notToExceedDate: $("POS_NTE", context).text(),
                            workSchedule: {
                                id: $("POS_WORK_SCHED_ID", context).text(),
                                desc: $("POS_WORK_SCHED_DSCR", context).text(),
                            },
                            hoursPerWeek: $("POS_HOURS_PER_WEEK", context).text()

                        },
                        candidate: {
                            firstName: $("CANDI_FIRST_NAME", context).text(),
                            middleName: $("CANDI_MIDDLE_NAME", context).text(),
                            lastName: $("CANDI_LAST_NAME", context).text()
                        },
                        license: {
                            has: $("LICENSE", context).text(),
                            info: $("LICENSE_INFO", context).text()
                        }
                    };

                    if ($("XO_PRTCP2", context).text()) {
                        item.xo.push({
                            id: $("XO_ID2", context).text(),
                            participantId: "[" + $("XO_TYPE2", context).text() + "]" + $("XO_ID2", context).text(),
                            name: $("XO_NAME2", context).text(),
                            email: $("XO_EMAIL2", context).text(),
                            title: $("XO_TITLE2", context).text(),
                            org: $("XO_ORG2", context).text(),
                            prtcp: $("XO_PRTCP2", context).text()
                        });
                    }

                    if ($("XO_PRTCP3", context).text()) {
                        item.xo.push({
                            id: $("XO_ID3", context).text(),
                            participantId: "[" + $("XO_TYPE3", context).text() + "]" + $("XO_ID3", context).text(),
                            name: $("XO_NAME3", context).text(),
                            email: $("XO_EMAIL3", context).text(),
                            title: $("XO_TITLE3", context).text(),
                            org: $("XO_ORG3", context).text(),
                            prtcp: $("XO_PRTCP3", context).text()
                        });
                    }

                    return item;
                },
                getCandidateName: function (item) {
                    var name = item.candidate.lastName + ', ' + item.candidate.firstName;
                    if (item.candidate.middleName && item.candidate.middleName.length > 0) {
                        name += ' ' + item.candidate.middleName;
                    }

                    return name;
                },
                populateRelatedFields: function (item) {
                    if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_general::populateRelatedFields - item ==> ", item);
                    if (item) {
                        FormState.updateTextValue("organizationName", item.adminCodeDesc, true);
                        FormState.updateTextValue("candiFirstName", item.candidate.firstName, true);
                        FormState.updateTextValue("candiMiddleName", item.candidate.middleName, true);
                        FormState.updateTextValue("candiLastName", item.candidate.lastName, true);
                        FormState.updateTextValue("administrativeCode", item.adminCode, true);
                        FormState.updateTextValue("requestType", item.requestType, true);
                        FormState.updateObjectValue('candidateName', this.getCandidateName(item));

                        if (_selectingOfficial_ac) {
                            var soItems = [];
                            var so = item.so;
                            if (so && so.prtcp) {
                                soItems.push(so);
                            }
                            FormState.updateObjectValue('selectingOfficial', soItems);
                            _selectingOfficial_ac.initializeItems(soItems);
                        }
                        if (_executiveOfficer_ac) {
                            var xoItems = [];
                            var xos = item.xo;
                            if (xos) {
                                for (var i = 0; i < xos.length; i++) {
                                    var xo = xos[i];
                                    if (xo && xo.prtcp) {
                                        xoItems.push(xo);
                                    }
                                }
                            }

                            FormState.updateObjectValue('executiveOfficers', xoItems);
                            _executiveOfficer_ac.initializeItems(xoItems);
                        }
                        if (_hrLiaison_ac) {
                            var hrlItems = [];
                            var hrl = item.hrl;
                            if (hrl && hrl.prtcp) {
                                hrlItems.push(hrl);
                            }
                            FormState.updateObjectValue('hrLiaisons', hrlItems);
                            _hrLiaison_ac.initializeItems(hrlItems);
                        }

                        if (cms_incentives_position) {
                            cms_incentives_position.populateRelatedFields(item);
                        }
                    }

                },
                getSelectionLabel: function (item) {
                    return item.requestNumber;
                },
                getCandidateLabel: function (item) {
                    return item.requestNumber;
                },
                getItemID: function (item) {
                    return item.id;
                },
                setDataToForm: function (values) {
                    FormState.updateObjectValue('associatedIncentives', values);

                    var item = {
                        id: null,
                        requestNumber: '',
                        requestDate: '',
                        requestType: '',
                        adminCode: '',
                        adminCodeDesc: '',
                        position: {
                            title: '',
                            payPlan: {
                                id: '',
                                desc: ''
                            },
                            series: {
                                id: '',
                                desc: ''
                            },
                            grade: [],
                            descNum: [],
                            notToExceedDate: '',
                            workSchedule: {
                                id: '',
                                desc: ''
                            },
                            hoursPerWeek: ''
                        },
                        candidate: {
                            firstName: '',
                            middleName: '',
                            lastName: ''
                        },
                        license: {
                            has: '',
                            info: ''
                        }
                    };

                    if (values && values.length > 0) {
                        item = values[0];
                    } else {
                        _hrSpecialist_ac.deleteAllItems();
                        _hrSpecialist2_ac.deleteAllItems();
                    }

                    this.populateRelatedFields(item);
                },

                // initialize
                initialItems: FormState.getElementArrayValue('associatedIncentives', [])
            };

            FormAutoComplete.makeAutoCompletion(option);
        }

        function setCandidateName() {
            var name = '';
            var candiFirstName = $('#candiFirstName').val();
            var candiMiddleName = $('#candiMiddleName').val();
            var candiLastName = $('#candiLastName').val();

            if (candiLastName && candiLastName.length > 0 && candiFirstName && candiFirstName.length > 0) {
                name = candiLastName + ", " + candiFirstName;
                if (candiMiddleName && candiMiddleName.length > 0) {
                    name += ' ' + candiMiddleName;
                }
            }

            FormState.updateObjectValue('candidateName', name);
        }

        function initPCATypeVisibility() {
            var incentiveType = FormState.getElementValue('incentiveType');
            if ('PCA' === incentiveType) {
                hyf.util.showComponent('pcaType_group');
            } else {
                hyf.util.hideComponent('pcaType_group');
            }
        }

        function initEventHandlers() {
            $('#incentiveType').on('change', function (e) {
                var target = e.target;
                var incentiveType = target.options[target.options.selectedIndex].value;
                FormState.updateObjectValue('incentiveType', incentiveType);
                $('#output_incentiveType').text(incentiveType);
                if ('PCA' === incentiveType) {
                    hyf.util.showComponent('pcaType_group');
                } else {
                    FormState.updateSelectValue("pcaType", "", "Select One", true);
                    hyf.util.hideComponent('pcaType_group');
                }
            });

            $('#candiFirstName').on('change', setCandidateName);
            $('#candiMiddleName').on('change', setCandidateName);
            $('#candiLastName').on('change', setCandidateName);
        }

        function init() {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_general::init...");

            initPCATypeVisibility();

            if (MyUserGroupManager.isUserMemberOf(USER_GROUP_KEY.HR_SPECIALISTS)) {
                setHRSpecialist2AutoCompletion();
            } else {
                hyf.util.hideComponent('hrSpecialist2_group');
            }

            setAssociatedRequestNumberAutoCompletion();
            setSelectingOfficialAutoCompletion();
            setExecutiveOfficialAutoCompletion();
            setHRLiaisonAutoCompletion();
            setHRSpecialistAutoCompletion();

            initEventHandlers();

            _initialized = true;
        }

        function render() {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_general::render...");
        }

        return {
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_general || (window.cms_incentives_general = cms_incentives_general());
})(window);
