(function (window) {
    var cms_incentives_general = function () {
        var _readOnly = false;
        var _initialized = false;
        var _associatedNEILRequest_ac = null;
        var _selectingOfficial_ac = null;
        var _executiveOfficer_ac = null;
        var _hrLiaison_ac = null;
        var _hrSpecialist_ac = null;
        var _hrSpecialist2_ac = null;
        var _ohcDirector_ac = null;
        var _offAdmin_ac = null;
        var _designatorSetting = false;

        function setPVRelatedUserIds() {
            var ids = '';
            var so = FormState.getElementArrayValue('selectingOfficial', []);
            var xo = FormState.getElementArrayValue('executiveOfficers', []);
            var hrl = FormState.getElementArrayValue('hrLiaisons', []);
            var hrs = FormState.getElementArrayValue('hrSpecialist', []);
            var hrs2 = FormState.getElementArrayValue('hrSpecialist2', []);
            var i;

            ids += '{I}' + myInfo.getMyMemberId() + ";";

            for (i = 0; i < so.length; i++) {
                ids += '{S}' + so[i].id + ";";
            }
            for (i = 0; i < xo.length; i++) {
                ids += '{X}' + xo[i].id + ";";
            }
            for (i = 0; i < hrl.length; i++) {
                ids += '{L}' + hrl[i].id + ";";
            }
            for (i = 0; i < hrs.length; i++) {
                ids += '{P}' + hrs[i].id + ";";
            }
            for (i = 0; i < hrs2.length; i++) {
                ids += '{T}' + hrs2[i].id + ";";
            }

            FormState.updateObjectValue('relatedUserIds', ids);
        }

        function _mapFunction(context) {
            return {
                id: $("MID", context).text(),
                participantId: "[" + $("MTYPE", context).text() + "]" + $("MID", context).text(),
                name: $("NAME", context).text(),
                email: $("EMAIL", context).text(),
                org: $("DEPTNAME", context).text(),
                title: $("JOBTITLENAME", context).text()
            };
        }

        function _getSelectionLabel(item) {
            var label = item.name + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '') + ' ' + item.org;
            if (item.title) {
                label += '/' + item.title;
            }

            return label;
        }

        function _getCandidateLabel(item) {
            return item.name + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '');
        }

        function _getItemID(item) {
            return item.id;
        }

        function setSelectingOfficialAutoCompletion() {
            var option = {
                id: 'selectingOfficial_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchParticipants.do?g=' + encodeURIComponent(USER_GROUP_KEY.SELECTING_OFFICIALS) + '&q=',
                minLength: 2,
                minSelectionCount: 1,
                maxSelectionCount: 1,
                readOnly: _readOnly,

                mapFunction: _mapFunction,
                getSelectionLabel: _getSelectionLabel,
                getCandidateLabel: _getCandidateLabel,
                getItemID: _getItemID,
                setDataToForm: function (values) {
                    FormState.updateObjectValue('selectingOfficial', values);
                    setPVRelatedUserIds();
                },

                // initialize
                initialItems: FormState.getElementArrayValue('selectingOfficial', [])
            };

            _selectingOfficial_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        function setExecutiveOfficialAutoCompletion() {
            var option = {
                id: 'executiveOfficer_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchParticipants.do?g=' + encodeURIComponent(USER_GROUP_KEY.EXECUTIVE_OFFICERS) + '&q=',
                minLength: 3,
                minSelectionCount: 1,
                maxSelectionCount: 3,
                readOnly: _readOnly,

                mapFunction: _mapFunction,
                getSelectionLabel: _getSelectionLabel,
                getCandidateLabel: _getCandidateLabel,
                getItemID: _getItemID,
                setDataToForm: function (values) {
                    FormState.updateObjectValue('executiveOfficers', values);
                    setPVRelatedUserIds();
                },

                initialItems: FormState.getElementArrayValue('executiveOfficers', [])
            };

            _executiveOfficer_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        function setHRLiaisonAutoCompletion() {
            var option = {
                id: 'hrLiaison_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchParticipants.do?g=' + encodeURIComponent(USER_GROUP_KEY.HR_LIAISON) + '&q=',
                minLength: 3,
                minSelectionCount: 0,
                maxSelectionCount: 3,
                readOnly: _readOnly,

                mapFunction: _mapFunction,
                getSelectionLabel: _getSelectionLabel,
                getCandidateLabel: _getCandidateLabel,
                getItemID: _getItemID,
                setDataToForm: function (values) {
                    FormState.updateObjectValue('hrLiaisons', values);
                    setPVRelatedUserIds();
                },

                initialItems: FormState.getElementArrayValue('hrLiaisons', [])
            };

            _hrLiaison_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        function setHRSpecialistAutoCompletion() {
            var option = {
                id: 'hrSpecialist_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchParticipants.do?g=' + encodeURIComponent(USER_GROUP_KEY.HR_SPECIALISTS) + '&q=',
                minLength: 2,
                minSelectionCount: 1,
                maxSelectionCount: 1,
                readOnly: _readOnly,

                mapFunction: _mapFunction,
                getSelectionLabel: _getSelectionLabel,
                getCandidateLabel: _getCandidateLabel,
                getItemID: _getItemID,
                setDataToForm: function (values) {
                    FormState.updateObjectValue('hrSpecialist', values);
                    setPVRelatedUserIds();
                },

                // initialize
                initialItems: FormState.getElementArrayValue('hrSpecialist', [])
            };

            _hrSpecialist_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        function setHRSpecialist2AutoCompletion() {
            var option = {
                id: 'hrSpecialist2_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchParticipants.do?g=' + encodeURIComponent(USER_GROUP_KEY.HR_SPECIALISTS) + '&q=',
                minLength: 2,
                minSelectionCount: 0,
                maxSelectionCount: 1,
                readOnly: _readOnly,

                mapFunction: _mapFunction,
                getSelectionLabel: _getSelectionLabel,
                getCandidateLabel: _getCandidateLabel,
                getItemID: _getItemID,
                setDataToForm: function (values) {
                    FormState.updateObjectValue('hrSpecialist2', values);
                    setPVRelatedUserIds();
                },

                // initialize
                initialItems: FormState.getElementArrayValue('hrSpecialist2', [])
            };

            _hrSpecialist2_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        function setDesignatedUserAutoCompletion(eleId, ugName, min, max, fn_) {
            var option = {
                id: eleId + '_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchParticipants.do?g=' + encodeURIComponent(ugName) + '&q=',
                minLength: 2,
                minSelectionCount: min,
                maxSelectionCount: max,
                readOnly: _readOnly,

                mapFunction: _mapFunction,
                getSelectionLabel: _getSelectionLabel,
                getCandidateLabel: _getCandidateLabel,
                getItemID: _getItemID,
                setDataToForm: function (values) {
                    FormState.updateObjectValue(eleId, values);
                    if (typeof fn_ === "function") {
                        fn_(values);
                    }
                },

                // initialize
                initialItems: FormState.getElementArrayValue(eleId, [])
            };

            return FormAutoComplete.makeAutoCompletion(option);
        }

        function setDGHODirectorAutoCompletion() {
            setDesignatedUserAutoCompletion("dghoDirector", USER_GROUP_KEY.DGHO_DIRECTORS, 0, 1);
        }

        function setChielfPhysicianAutoCompletion() {
            setDesignatedUserAutoCompletion("chiefPhysician", USER_GROUP_KEY.CHIEF_PHYSICIANS, 0, 1);
        }

        function setOHCDirectorAutoCompletion() {
            _ohcDirector_ac = setDesignatedUserAutoCompletion("ohcDirector", USER_GROUP_KEY.OHC_DIRECTORS, 0, 1);
        }

        function setOFMDirectorAutoCompletion() {
            setDesignatedUserAutoCompletion("ofmDirector", USER_GROUP_KEY.OFM_DIRECTORS, 0, 1);
        }

        function setOFFAdminAutoCompletion() {
            _offAdmin_ac = setDesignatedUserAutoCompletion("offAdmin", USER_GROUP_KEY.OFFICE_OF_THE_ADMINISTRATORS, 0, 1);
        }

        function setTAGBDirectorAutoCompletion() {
            setDesignatedUserAutoCompletion("tabgDirector", USER_GROUP_KEY.TABG_DIRECTORS, 0, 1);
        }

        function preloadAttachments(item, incentiveType) {
            if (item) {
                if (item.procId) {
                    if (INCENTIVES_TYPE.PCA === incentiveType) {
                        setTimeout(function () {
                            FormAttachmentHandler.copyAttachments({
                                srcProcId: item.procId,
                                requestType: item.requestType
                            });
                        }, 5);
                    }
                } else {
                    setTimeout(function () {
                        FormAttachmentHandler.deleteAllAttachments();
                    }, 5);
                }
            }
        }

        function setAssociatedRequestNumberAutoCompletion() {
            var option = {
                id: 'associatedNEILRequest_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchRequestNumbers.do?q=',
                minLength: 4,
                minSelectionCount: 1,
                maxSelectionCount: 1,
                readOnly: _readOnly,

                mapFunction: function (context) {
                    var item = {
                        id: $("REQ_ID", context).text(),
                        procId: $("PROC_ID", context).text(),
                        procType: $("PROC_TYPE", context).text(),
                        requestNumber: $("REQUEST_NUMBER", context).text(),
                        requestDate: $("REQUEST_DATE", context).text(),
                        requestType: $("REQUEST_TYPE", context).text(),
                        adminCode: $("ADMIN_CODE", context).text(),
                        adminCodeDesc: $("ADMIN_CODE_DESC", context).text(),
                        so: {
                            id: $("SO_ID", context).text(),
                            participantId: "[" + $("SO_TYPE", context).text() + "]" + $("SO_ID", context).text(),
                            name: $("SO_NAME", context).text(),
                            email: $("SO_EMAIL", context).text(),
                            title: $("SO_TITLE", context).text(),
                            org: $("SO_ORG", context).text(),
                            prtcp: $("SO_PRTCP", context).text()
                        },
                        xo: [{
                            id: $("XO_ID1", context).text(),
                            participantId: "[" + $("XO_TYPE1", context).text() + "]" + $("XO_ID1", context).text(),
                            name: $("XO_NAME1", context).text(),
                            email: $("XO_EMAIL1", context).text(),
                            title: $("XO_TITLE1", context).text(),
                            org: $("XO_ORG1", context).text(),
                            prtcp: $("XO_PRTCP1", context).text()
                        }],
                        hrl: {
                            id: $("HRL_ID", context).text(),
                            participantId: "[" + $("HRL_TYPE", context).text() + "]" + $("HRL_ID", context).text(),
                            name: $("HRL_NAME", context).text(),
                            email: $("HRL_EMAIL", context).text(),
                            title: $("HRL_TITLE", context).text(),
                            org: $("HRL_ORG", context).text(),
                            ptctp: $("HRL_PRTCP", context).text()
                        },
                        position: {
                            title: $("POS_TITLE", context).text(),
                            payPlan: {
                                id: $("PAY_PLAN_ID", context).text(),
                                desc: $("PAY_PLAN_DESC", context).text()
                            },
                            series: {
                                id: $("POS_SERIES_ID", context).text(),
                                desc: $("POS_SERIES_DESC", context).text()
                            },
                            grade: [
                                $("POS_GRADE1", context).text(),
                                $("POS_GRADE2", context).text(),
                                $("POS_GRADE3", context).text(),
                                $("POS_GRADE4", context).text(),
                                $("POS_GRADE5", context).text()
                            ],
                            descNum: [
                                $("POS_DESC_NUM1", context).text(),
                                $("POS_DESC_NUM2", context).text(),
                                $("POS_DESC_NUM3", context).text(),
                                $("POS_DESC_NUM4", context).text(),
                                $("POS_DESC_NUM5", context).text(),
                            ],
                            notToExceedDate: $("POS_NTE", context).text(),
                            workSchedule: {
                                id: $("POS_WORK_SCHED_ID", context).text(),
                                desc: $("POS_WORK_SCHED_DSCR", context).text(),
                            },
                            hoursPerWeek: $("POS_HOURS_PER_WEEK", context).text()

                        },
                        candidate: {
                            firstName: $("CANDI_FIRST_NAME", context).text(),
                            middleName: $("CANDI_MIDDLE_NAME", context).text(),
                            lastName: $("CANDI_LAST_NAME", context).text()
                        },
                        license: {
                            has: $("LICENSE", context).text(),
                            info: $("LICENSE_INFO", context).text()
                        }
                    };

                    if ($("XO_PRTCP2", context).text()) {
                        item.xo.push({
                            id: $("XO_ID2", context).text(),
                            participantId: "[" + $("XO_TYPE2", context).text() + "]" + $("XO_ID2", context).text(),
                            name: $("XO_NAME2", context).text(),
                            email: $("XO_EMAIL2", context).text(),
                            title: $("XO_TITLE2", context).text(),
                            org: $("XO_ORG2", context).text(),
                            prtcp: $("XO_PRTCP2", context).text()
                        });
                    }

                    if ($("XO_PRTCP3", context).text()) {
                        item.xo.push({
                            id: $("XO_ID3", context).text(),
                            participantId: "[" + $("XO_TYPE3", context).text() + "]" + $("XO_ID3", context).text(),
                            name: $("XO_NAME3", context).text(),
                            email: $("XO_EMAIL3", context).text(),
                            title: $("XO_TITLE3", context).text(),
                            org: $("XO_ORG3", context).text(),
                            prtcp: $("XO_PRTCP3", context).text()
                        });
                    }

                    return item;
                },
                getCandidateName: function (item) {
                    var name = '';
                    if (item.candidate) {
                        if (item.candidate.lastName) name += item.candidate.lastName + ', ';
                        if (item.candidate.firstName) name += item.candidate.firstName;
                        if (item.candidate.middleName && item.candidate.middleName.length > 0) {
                            name += ' ' + item.candidate.middleName;
                        }
                    }

                    return name;
                },
                populateRelatedFields: function (item) {
                    if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_general::populateRelatedFields - item ==> ", item);
                    if (item) {
                        FormState.updateTextValue("organizationName", item.adminCodeDesc, true);
                        FormState.updateTextValue("candiFirstName", item.candidate.firstName, true);
                        FormState.updateTextValue("candiMiddleName", item.candidate.middleName, true);
                        FormState.updateTextValue("candiLastName", item.candidate.lastName, true);
                        FormState.updateTextValue("administrativeCode", item.adminCode, true);
                        FormState.updateTextValue("requestType", item.requestType, true);
                        FormState.updateObjectValue('candidateName', this.getCandidateName(item));

                        if (_selectingOfficial_ac) {
                            var soItems = [];
                            var so = item.so;
                            if (so && so.prtcp) {
                                soItems.push(so);
                            }
                            FormState.updateObjectValue('selectingOfficial', soItems);
                            _selectingOfficial_ac.initializeItems(soItems);
                        }
                        if (_executiveOfficer_ac) {
                            var xoItems = [];
                            var xos = item.xo;
                            if (xos) {
                                for (var i = 0; i < xos.length; i++) {
                                    var xo = xos[i];
                                    if (xo && xo.prtcp) {
                                        xoItems.push(xo);
                                    }
                                }
                            }

                            FormState.updateObjectValue('executiveOfficers', xoItems);
                            _executiveOfficer_ac.initializeItems(xoItems);
                        }
                        if (_hrLiaison_ac) {
                            var hrlItems = [];
                            var hrl = item.hrl;
                            if (hrl && hrl.prtcp) {
                                hrlItems.push(hrl);
                            }
                            FormState.updateObjectValue('hrLiaisons', hrlItems);
                            _hrLiaison_ac.initializeItems(hrlItems);
                        }

                        if (cms_incentives_position) {
                            cms_incentives_position.populateRelatedFields(item);
                        }

                        if (null == item.id) {   // clean
                            FormState.updateSelectValue("requireAdminApproval", "", "Select One", true);

                            if (cms_incentives_pca_details) {
                                cms_incentives_pca_details.reset();
                            }

                            TabManager.resetTabs();
                        }
                    }
                },
                getSelectionLabel: function (item) {
                    return item.requestNumber;
                },
                getCandidateLabel: function (item) {
                    return item.requestNumber;
                },
                getItemID: function (item) {
                    return item.id;
                },
                setDataToForm: function (values) {
                    FormState.updateObjectValue('associatedNEILRequest', values);
                    setPVRelatedUserIds();

                    var item = {
                        id: null,
                        requestNumber: '',
                        requestDate: '',
                        requestType: '',
                        adminCode: '',
                        adminCodeDesc: '',
                        position: {
                            title: '',
                            payPlan: {
                                id: '',
                                desc: ''
                            },
                            series: {
                                id: '',
                                desc: ''
                            },
                            grade: [],
                            descNum: [],
                            notToExceedDate: '',
                            workSchedule: {
                                id: '',
                                desc: ''
                            },
                            hoursPerWeek: ''
                        },
                        candidate: {
                            firstName: '',
                            middleName: '',
                            lastName: ''
                        },
                        license: {
                            has: '',
                            info: ''
                        }
                    };

                    if (values && values.length > 0) {
                        item = values[0];
                    } else {
                        if (_hrSpecialist_ac) _hrSpecialist_ac.deleteAllItems();
                        if (_hrSpecialist2_ac) _hrSpecialist2_ac.deleteAllItems();
                    }

                    preloadAttachments(item, FormState.getElementValue('incentiveType'));

                    this.populateRelatedFields(item);
                },

                // initialize
                initialItems: FormState.getElementArrayValue('associatedNEILRequest', [])
            };

            _associatedNEILRequest_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        function setAssociateIncentivesAutoCompletion() {
            var option = {
                id: 'associatedIncentives_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchIncentives.do?q=',
                minLength: 6,
                minSelectionCount: 0,
                maxSelectionCount: 3,
                readOnly: _readOnly,

                mapFunction: function (context) {
                    return {
                        requestNumber: $("REQ_NUM", context).text(),
                        incentiveType: $("INCEN_TYPE", context).text()
                    };
                },
                getSelectionLabel: function (item) {
                    return item.requestNumber + " - " + item.incentiveType;
                },
                getCandidateLabel: function (item) {
                    return item.requestNumber + " - " + item.incentiveType;
                },
                getItemID: function (item) {
                    return item.requestNumber;
                },
                setDataToForm: function (values) {
                    FormState.updateObjectValue('associatedIncentives', values);
                },
                // initialize
                initialItems: FormState.getElementArrayValue('associatedIncentives', [])
            };

            FormAutoComplete.makeAutoCompletion(option);
        }

        function setCandidateName() {
            var name = '';
            var candiFirstName = $('#candiFirstName').val();
            var candiMiddleName = $('#candiMiddleName').val();
            var candiLastName = $('#candiLastName').val();

            if (candiLastName && candiLastName.length > 0 && candiFirstName && candiFirstName.length > 0) {
                name = candiLastName + ", " + candiFirstName;
                if (candiMiddleName && candiMiddleName.length > 0) {
                    name += ' ' + candiMiddleName;
                }
            }

            FormState.updateObjectValue('candidateName', name);
        }

        function setTabVisibility(incentiveType, candiAgreeRenewal) {
            var pca = INCENTIVES_TYPE.PCA === incentiveType;
            var sam = INCENTIVES_TYPE.SAM === incentiveType;
            var agree = "No" !== candiAgreeRenewal;

            TabManager.setTabHeaderVisibility("tab2", agree);
            TabManager.setTabHeaderVisibility("tab3", pca && agree);
            TabManager.setTabHeaderVisibility("tab4", pca && agree);
            TabManager.setTabHeaderVisibility("tab5", pca && agree);
            TabManager.setTabHeaderVisibility("tab6", sam);
            TabManager.setTabHeaderVisibility("tab7", sam);
            TabManager.setTabHeaderVisibility("tab8", sam);

            TabManager.resetTabs();
        }

        function handleCandiAgreeRenewal(candiAgreeRenewal) {
            if (_initialized) {
                setTabVisibility(INCENTIVES_TYPE.PCA, candiAgreeRenewal);
            }
            var agree = "No" !== candiAgreeRenewal;
            hyf.util.setMandatoryConstraint("selectingOfficial_ac", agree);
            hyf.util.setMandatoryConstraint("executiveOfficer_ac", agree);
            _selectingOfficial_ac.setMinSelectionCount(agree ? 1 : 0);
            _executiveOfficer_ac.setMinSelectionCount(agree ? 1 : 0);
        }

        function setCandiAgreeVisibility(pcaType) {
            var renewal = "Renewal" === pcaType;
            hyf.util.setMandatoryConstraint("associatedNEILRequest_ac", !renewal);
            _associatedNEILRequest_ac.setMinSelectionCount(renewal ? 0 : 1);

            hyf.util.setComponentVisibility("associatedIncentives_group", !renewal);
            hyf.util.setComponentVisibility("candiAgreeRenewal_group", renewal);
            if (!renewal) {
                FormState.updateSelectValue("candiAgreeRenewal", "", "Select One", true);
            }
        }

        function setVisibilityByIncentiveType(incentiveType) {
            if (_initialized) {
                setTabVisibility(incentiveType);
            }
            var pca = INCENTIVES_TYPE.PCA === incentiveType;
            hyf.util.setComponentVisibility("pcaType_group", pca);
            if (!pca) {
                FormState.updateSelectValue("pcaType", "", "Select One", true);
                setCandiAgreeVisibility();
            }

            setDesignatorVisibility(incentiveType);
        }

        function setOhcDirectorVisibility(requireAdminApproval) {
            var isRequired = "Yes" === requireAdminApproval;
            hyf.util.setComponentVisibility("ohcDirector_group", isRequired);
            if (!isRequired) {
                _ohcDirector_ac.deleteAllItems();
            }
        }

        function setOffAdminVisibility(requireAdminApproval) {
            var isRequired = "Yes" === requireAdminApproval;
            hyf.util.setComponentVisibility("offAdmin_group", "Yes" === requireAdminApproval)
            if (!isRequired) {
                _offAdmin_ac.deleteAllItems();
            }
        }

        function onRequireAdminApprovalChanged(requireAdminApproval) {
            setOffAdminVisibility(requireAdminApproval);
            setOhcDirectorVisibility(requireAdminApproval);
        }

        function initEventHandlers() {
            $('#incentiveType').on('change', function (e) {
                var target = e.target;
                var incentiveType = target.options[target.options.selectedIndex].value;
                preloadAttachments(FormState.getElementSingleValue("associatedNEILRequest"), incentiveType);
                setVisibilityByIncentiveType(incentiveType);
                FormMain.updateIncentiveTypeOutput(incentiveType);
                FormMain.setSubmitButtonLabel({incentiveType: incentiveType});
                FormAttachmentHandler.refreshCustomButtons({incentiveType: incentiveType});
                if (cms_incentives_position) {
                    cms_incentives_position.onIncentiveTypeChange(incentiveType);
                }
            });

            $('#pcaType').on('change', function (e) {
                var target = e.target;
                var pcaType = target.options[target.options.selectedIndex].value;
                setCandiAgreeVisibility(pcaType);
                handleCandiAgreeRenewal(FormState.getElementValue("candiAgreeRenewal"));
            });

            $('#candiFirstName').on('change', setCandidateName);
            $('#candiMiddleName').on('change', setCandidateName);
            $('#candiLastName').on('change', setCandidateName);

            $('#requireAdminApproval').on('change', function (e) {
                var target = e.target;
                var requireAdminApproval = target.options[target.options.selectedIndex].value;

                FormMain.setSubmitButtonLabel({requireAdminApproval: requireAdminApproval});
                onRequireAdminApprovalChanged(requireAdminApproval);

                if (cms_incentives_pca_review) cms_incentives_pca_review.onRequireAdminApprovalChanged(requireAdminApproval);
                if (cms_incentives_pca_approval) cms_incentives_pca_approval.onRequireAdminApprovalChanged(requireAdminApproval);
            });

            $('#candiAgreeRenewal').on('change', function (e) {
                var target = e.target;
                handleCandiAgreeRenewal(target.value);
            });
        }

        function setDesignatorVisibility(incentiveType) {
            if (_designatorSetting) {
                var pca = "PCA" === incentiveType;

                hyf.util.setComponentVisibility("requireAdminApproval_group", pca);
                hyf.util.setComponentVisibility("cp_group", pca);

                if (!pca) {
                    FormState.updateSelectValue("requireAdminApproval", "", "Select One");
                    setOhcDirectorVisibility("");
                    setOffAdminVisibility("");
                }
            }
        }

        function initComponents() {
            var incentiveType = FormState.getElementValue('incentiveType');
            handleCandiAgreeRenewal(FormState.getElementValue("candiAgreeRenewal"));
            setVisibilityByIncentiveType(incentiveType);
            setCandiAgreeVisibility(FormState.getElementValue("pcaType"));

            if (myInfo.isHRS()) {

                setDGHODirectorAutoCompletion();
                setChielfPhysicianAutoCompletion();
                setOHCDirectorAutoCompletion();
                setOFMDirectorAutoCompletion();
                setOFFAdminAutoCompletion();
                setTAGBDirectorAutoCompletion();

                if (ActivityManager.getActivityName() === ACTIVITY_NAME.HRS_REVIEW) {
                    _designatorSetting = true;
                    hyf.util.showComponent("designatedUsers_group");
                    onRequireAdminApprovalChanged(FormState.getElementValue("requireAdminApproval"));
                    setDesignatorVisibility(incentiveType);
                }
            }
        }

        function init(readOnly) {
            _readOnly = readOnly;
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_general::init, readOnly ==> ", readOnly);

            setTabVisibility(FormState.getElementValue('incentiveType', INCENTIVES_TYPE.PCA), FormState.getElementValue("candiAgreeRenewal"));

            setAssociatedRequestNumberAutoCompletion();
            setAssociateIncentivesAutoCompletion();
            setSelectingOfficialAutoCompletion();
            setExecutiveOfficialAutoCompletion();
            setHRLiaisonAutoCompletion();
            setHRSpecialistAutoCompletion();
            setHRSpecialist2AutoCompletion();

            initComponents();
            initEventHandlers();

            _initialized = true;
        }

        function render(action) {
            if (FormLog.isDebugLevel(action)) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_general::render..., action ==> ", actionN);
        }

        return {
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_general || (window.cms_incentives_general = cms_incentives_general());
})(window);
