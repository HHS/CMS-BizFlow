(function (window) {
    var cms_incentives_general = function () {
        var _readOnly = false;
        var _initialized = false;
        var _associatedNEILRequest_ac = null;
        var _selectingOfficial_ac = null;
        var _executiveOfficer_ac = null;
        var _hrLiaison_ac = null;
        var _hrSpecialist_ac = null;
        var _hrSpecialist2_ac = null;
		var _staffingSpecialist_ac = null;
        // var _ohcDirector_ac = null;
        // var _offAdmin_ac = null;
        var _designatedSectionEnabled = false;
        // var _dghoDirector_ac = null;
        // var _chiefPhysician_ac = null;
        // var _ofmDirector_ac = null;
        // var _tabgDirector_ac = null;
        var _administrativeCode_ac = null;
        var _organizationName_ac = null;

        function setPVRelatedUserIds() {
            var ids = '';
            var so = FormState.getElementArrayValue('selectingOfficial', []);
            var xo = FormState.getElementArrayValue('executiveOfficers', []);
            var hrl = FormState.getElementArrayValue('hrLiaisons', []);
            var hrs = FormState.getElementArrayValue('hrSpecialist', []);
            var hrs2 = FormState.getElementArrayValue('hrSpecialist2', []);
			var hrss = FormState.getElementArrayValue('staffingSpecialist', []);
            var i;

            ids += '{I}' + myInfo.getMyMemberId() + ";";

            for (i = 0; i < so.length; i++) {
                ids += '{S}' + so[i].id + ";";
            }
            for (i = 0; i < xo.length; i++) {
                ids += '{X}' + xo[i].id + ";";
            }
            for (i = 0; i < hrl.length; i++) {
                ids += '{L}' + hrl[i].id + ";";
            }

            FormState.updateObjectValue('componentUserIds', ids);

            for (i = 0; i < hrs.length; i++) {
                ids += '{P}' + hrs[i].id + ";";
            }
            for (i = 0; i < hrs2.length; i++) {
                ids += '{T}' + hrs2[i].id + ";";
            }

            FormState.updateObjectValue('relatedUserIds', ids);
        }

        function _mapFunction(context) {
            return {
                id: $("MID", context).text(),
                participantId: "[" + $("MTYPE", context).text() + "]" + $("MID", context).text(),
                name: $("NAME", context).text(),
                email: $("EMAIL", context).text(),
                org: $("DEPTNAME", context).text(),
                title: $("JOBTITLENAME", context).text()
            };
        }

        function _getSelectionLabel(item) {
            return item.name + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '') + ' ' + item.org;
        }

        function _getCandidateLabel(item) {
            return item.name + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '');
        }

        function _getItemID(item) {
            return item.id;
        }

        function setSelectingOfficialAutoCompletion(readOnly_) {
            var option = {
                id: 'selectingOfficial_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchParticipants.do?g=' + encodeURIComponent(USER_GROUP_KEY.SELECTING_OFFICIALS) + '&q=',
                minLength: 2,
                minSelectionCount: 1,
                maxSelectionCount: 1,
                readOnly: undefined !== readOnly_ ? readOnly_ : _readOnly,
                mapFunction: _mapFunction,
                getSelectionLabel: _getSelectionLabel,
                getCandidateLabel: _getCandidateLabel,
                getItemID: _getItemID,
                setDataToForm: function (values) {
                    FormState.updateObjectValue('selectingOfficial', values);
                    setPVRelatedUserIds();
                },

                // initialize
                initialItems: FormState.getElementArrayValue('selectingOfficial', [])
            };

            _selectingOfficial_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        function setExecutiveOfficialAutoCompletion(readOnly_) {
            var option = {
                id: 'executiveOfficer_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchParticipants.do?g=' + encodeURIComponent(USER_GROUP_KEY.EXECUTIVE_OFFICERS) + '&q=',
                minLength: 3,
                minSelectionCount: 1,
                maxSelectionCount: 3,
                readOnly: undefined !== readOnly_ ? readOnly_ : _readOnly,
                mapFunction: _mapFunction,
                getSelectionLabel: _getSelectionLabel,
                getCandidateLabel: _getCandidateLabel,
                getItemID: _getItemID,
                setDataToForm: function (values) {
                    FormState.updateObjectValue('executiveOfficers', values);
                    setPVRelatedUserIds();
                },

                initialItems: FormState.getElementArrayValue('executiveOfficers', [])
            };

            _executiveOfficer_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        function setHRLiaisonAutoCompletion() {
            var option = {
                id: 'hrLiaison_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchParticipants.do?g=' + encodeURIComponent(USER_GROUP_KEY.HR_LIAISON) + '&q=',
                minLength: 3,
                minSelectionCount: 0,
                maxSelectionCount: 3,
                readOnly: _readOnly,
                mapFunction: _mapFunction,
                getSelectionLabel: _getSelectionLabel,
                getCandidateLabel: _getCandidateLabel,
                getItemID: _getItemID,
                setDataToForm: function (values) {
                    FormState.updateObjectValue('hrLiaisons', values);
                    setPVRelatedUserIds();
                },

                initialItems: FormState.getElementArrayValue('hrLiaisons', [])
            };

            _hrLiaison_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        function setHRSpecialistAutoCompletion() {
            var option = {
                id: 'hrSpecialist_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchParticipants.do?g=' + encodeURIComponent(USER_GROUP_KEY.HR_SPECIALISTS) + '&q=',
                minLength: 2,
                minSelectionCount: 1,
                maxSelectionCount: 1,
                readOnly: _readOnly,
                mapFunction: _mapFunction,
                getSelectionLabel: _getSelectionLabel,
                getCandidateLabel: _getCandidateLabel,
                getItemID: _getItemID,
                setDataToForm: function (values) {
                    FormState.updateObjectValue('hrSpecialist', values);
                    setPVRelatedUserIds();
                },

                // initialize
                initialItems: FormState.getElementArrayValue('hrSpecialist', [])
            };

            _hrSpecialist_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        function setHRSpecialist2AutoCompletion() {
            var option = {
                id: 'hrSpecialist2_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchParticipants.do?g=' + encodeURIComponent(USER_GROUP_KEY.HR_SPECIALISTS) + '&q=',
                minLength: 2,
                minSelectionCount: 0,
                maxSelectionCount: 1,
                readOnly: _readOnly,
                mapFunction: _mapFunction,
                getSelectionLabel: _getSelectionLabel,
                getCandidateLabel: _getCandidateLabel,
                getItemID: _getItemID,
                setDataToForm: function (values) {
                    FormState.updateObjectValue('hrSpecialist2', values);
                    setPVRelatedUserIds();
                },

                // initialize
                initialItems: FormState.getElementArrayValue('hrSpecialist2', [])
            };

            _hrSpecialist2_ac = FormAutoComplete.makeAutoCompletion(option);
        }
		
		function setHRStaffingSpecialistAutoCompletion() {
            var option = {
                id: 'staffingSpecialist_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchParticipants.do?g=' + encodeURIComponent(USER_GROUP_KEY.HR_STAFFING_SPECIALISTS) + '&q=',
                minLength: 2,
                minSelectionCount: 0,
                maxSelectionCount: 1,
                readOnly: _readOnly,
                mapFunction: _mapFunction,
                getSelectionLabel: _getSelectionLabel,
                getCandidateLabel: _getCandidateLabel,
                getItemID: _getItemID,
                setDataToForm: function (values) {
                    FormState.updateObjectValue('staffingSpecialist', values);
                    setPVRelatedUserIds();
                },

                // initialize
                initialItems: FormState.getElementArrayValue('staffingSpecialist', [])
            };

            _staffingSpecialist_ac = FormAutoComplete.makeAutoCompletion(option);
        }
        function setDesignatedUserAutoCompletion(eleId, ugName, min, max, readOnly_, fn_) {
            var option = {
                id: eleId + '_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchParticipants.do?g=' + encodeURIComponent(ugName) + '&q=',
                minLength: 2,
                minSelectionCount: min,
                maxSelectionCount: max,
                readOnly: undefined !== readOnly_ ? readOnly_ : _readOnly,
                mapFunction: _mapFunction,
                getSelectionLabel: _getSelectionLabel,
                getCandidateLabel: _getCandidateLabel,
                getItemID: _getItemID,
                setDataToForm: function (values) {
                    FormState.updateObjectValue(eleId, values);
                    if (typeof fn_ === "function") {
                        fn_(values);
                    }
                },

                // initialize
                initialItems: FormState.getElementArrayValue(eleId, [])
            };

            return FormAutoComplete.makeAutoCompletion(option);
        }

        // function setDGHODirectorAutoCompletion(readOnly_) {
        //     _dghoDirector_ac = setDesignatedUserAutoCompletion("dghoDirector", USER_GROUP_KEY.DGHO_DIRECTORS, 0, 1, readOnly_);
        // }

        // function setChielfPhysicianAutoCompletion(readOnly_) {
        //     _chiefPhysician_ac = setDesignatedUserAutoCompletion("chiefPhysician", USER_GROUP_KEY.CHIEF_PHYSICIANS, 0, 1, readOnly_);
        // }

        // function setOFMDirectorAutoCompletion(readOnly_) {
        //     _ofmDirector_ac = setDesignatedUserAutoCompletion("ofmDirector", USER_GROUP_KEY.OFM_DIRECTORS, 0, 1, readOnly_);
        // }

        // function setTAGBDirectorAutoCompletion(readOnly_) {
        //     _tabgDirector_ac = setDesignatedUserAutoCompletion("tabgDirector", USER_GROUP_KEY.TABG_DIRECTORS, 0, 1, readOnly_);
        // }

        // function setOHCDirectorAutoCompletion(readOnly_) {
        //     _ohcDirector_ac = setDesignatedUserAutoCompletion("ohcDirector", USER_GROUP_KEY.OHC_DIRECTORS, 0, 1, readOnly_);
        // }

        // function setOFFAdminAutoCompletion(readOnly_) {
        //     _offAdmin_ac = setDesignatedUserAutoCompletion("offAdmin", USER_GROUP_KEY.OFFICE_OF_THE_ADMINISTRATORS, 0, 1, readOnly_);
        // }

        function setAdministrativeCodeAutoCompletion(readOnly_) {
            var option = {
                id: 'administrativeCode_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/SearchAdmOffOrg.do?searchAdmOff=',
                minLength: 2,
                minSelectionCount: 1,
                maxSelectionCount: 1,
                readOnly: undefined !== readOnly_ ? readOnly_ : _readOnly,
                mapFunction: function(context) {
                    return { code: $( "CODE", context ).text(), name: $( "NAME", context ).text() }
                },
                getSelectionLabel: function(item) {
                    return item.code;
                },
                getCandidateLabel: function(item) {
                    return item.code + ' - ' + item.name;
                },
                getItemID: function(item) {
                    return item.code;
                },
                setDataToForm: function(values) {
                    var code = "";
                    var name = "";
                    if (values && values.length > 0) {
                        code = values[0].code;
                        name = values[0].name;
                    }
                    FormState.updateObjectValue('administrativeCode', code);
                    FormState.updateObjectValue('organizationName', name);
                },
                initialItems: [{
                    code: FormState.getElementValue('administrativeCode', ""),
                    name: FormState.getElementValue('organizationName', "")
                }]
            };
            _administrativeCode_ac = FormAutoComplete.makeAutoCompletion(option);

            var optionOrgName = {
                id: 'organizationName_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/SearchAdmOffOrg.do?searchOrg=',
                minLength: 2,
                minSelectionCount: 1,
                maxSelectionCount: 1,
                readOnly: undefined !== readOnly_ ? readOnly_ : _readOnly,
                mapFunction: function(context) {
                    return { code: $( "CODE", context ).text(), name: $( "NAME", context ).text() }
                },
                getSelectionLabel: function(item) {
                    return item.name;
                },
                getCandidateLabel: function(item) {
                    return item.name + ' - ' + item.code;
                },
                getItemID: function(item) {
                    return item.code;
                },
                postSelect: function(event, ui, selectedValues) {
                    _administrativeCode_ac.select(event, ui);
                },
                postDelete: function(e, selectedValues) {
                    _administrativeCode_ac.deleteAllItems();
                    try {
                        $("#organizationName_ac").focus();
                    } catch(e) {
                    }
                },
                setDataToForm: function(values) {
                    var code = "";
                    var name = "";
                    if (values && values.length > 0) {
                        code = values[0].code;
                        name = values[0].name;
                    }
                    FormState.updateObjectValue('administrativeCode', code);
                    FormState.updateObjectValue('organizationName', name);
                },
                initialItems: [{
                    code: FormState.getElementValue('administrativeCode', ""),
                    name: FormState.getElementValue('organizationName', "")
                }]
            };
            _organizationName_ac = FormAutoComplete.makeAutoCompletion(optionOrgName);

            _administrativeCode_ac.option.postSelect = function(event, ui, selectedValues) {
                _organizationName_ac.select(event, ui);
            };
            _administrativeCode_ac.option.postDelete = function(e, selectedValues) {
                _organizationName_ac.deleteAllItems();
                try {
                    $("#administrativeCode_ac").focus();
                } catch(e) {
                }
            };
        }

        function preloadAttachments(item, incentiveType) {
            if (item && item.procId) {
                setTimeout(function () {
                    FormAttachmentHandler.getAssociatedAttachmentList({
                        srcProcId: item.procId,
                        requestType: item.requestType
                    });
                }, 5);
            } else {
                setTimeout(function () {
                    FormAttachmentHandler.clearAssociatedAttachmentList();
                }, 5);
            }
        }

        function setAssociatedRequestNumberAutoCompletion(incentiveType) {
			incentiveType = incentiveType ? incentiveType : '';
            var option = {
                id: 'associatedNEILRequest_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                //targetURL: '/bizflowwebmaker/cms_incentives_service/searchRequestNumbers.do?q=',
				targetURL: '/bizflowwebmaker/cms_incentives_service/searchRequestNumbers.do?incentive_type=' + incentiveType + '&q=',
                minLength: 4,
                minSelectionCount: 1,
                maxSelectionCount: 1,
                readOnly: (!activityStep.isStartNew() && !activityStep.isSOReview()) || _readOnly,
                mapFunction: function (context) {
                    var item = {
                        id: $("REQ_ID", context).text(),
                        procId: $("PROC_ID", context).text(),
                        procType: $("PROC_TYPE", context).text(),
                        requestNumber: $("REQUEST_NUMBER", context).text(),
                        requestDate: $("REQUEST_DATE", context).text(),
                        requestType: $("REQUEST_TYPE", context).text(),
                        adminCode: $("ADMIN_CODE", context).text(),
                        adminCodeDesc: $("ADMIN_CODE_DESC", context).text(),
                        so: {
                            id: $("SO_ID", context).text(),
                            participantId: "[" + $("SO_TYPE", context).text() + "]" + $("SO_ID", context).text(),
                            name: $("SO_NAME", context).text(),
                            email: $("SO_EMAIL", context).text(),
                            title: $("SO_TITLE", context).text(),
                            org: $("SO_ORG", context).text(),
                            prtcp: $("SO_PRTCP", context).text()
                        },
                        xo: [{
                            id: $("XO_ID1", context).text(),
                            participantId: "[" + $("XO_TYPE1", context).text() + "]" + $("XO_ID1", context).text(),
                            name: $("XO_NAME1", context).text(),
                            email: $("XO_EMAIL1", context).text(),
                            title: $("XO_TITLE1", context).text(),
                            org: $("XO_ORG1", context).text(),
                            prtcp: $("XO_PRTCP1", context).text()
                        }],
                        hrl: {
                            id: $("HRL_ID", context).text(),
                            participantId: "[" + $("HRL_TYPE", context).text() + "]" + $("HRL_ID", context).text(),
                            name: $("HRL_NAME", context).text(),
                            email: $("HRL_EMAIL", context).text(),
                            title: $("HRL_TITLE", context).text(),
                            org: $("HRL_ORG", context).text(),
                            prtcp: $("HRL_PRTCP", context).text()
                        },
                        position: {
                            title: $("POS_TITLE", context).text(),
                            payPlan: {
                                id: $("PAY_PLAN_ID", context).text(),
                                desc: $("PAY_PLAN_DESC", context).text()
                            },
                            series: {
                                id: $("POS_SERIES_ID", context).text(),
                                desc: $("POS_SERIES_DESC", context).text()
                            },
                            grade: [
                                $("POS_GRADE1", context).text(),
                                $("POS_GRADE2", context).text(),
                                $("POS_GRADE3", context).text(),
                                $("POS_GRADE4", context).text(),
                                $("POS_GRADE5", context).text()
                            ],
                            descNum: [
                                $("POS_DESC_NUM1", context).text(),
                                $("POS_DESC_NUM2", context).text(),
                                $("POS_DESC_NUM3", context).text(),
                                $("POS_DESC_NUM4", context).text(),
                                $("POS_DESC_NUM5", context).text()
                            ],
                            typeOfAppointment: $("TYPE_OF_APPT", context).text(),
                            notToExceedDate: $("POS_NTE", context).text(),
                            workSchedule: {
                                id: $("POS_WORK_SCHED_ID", context).text(),
                                desc: $("POS_WORK_SCHED_DSCR", context).text()
                            },
                            hoursPerWeek: $("POS_HOURS_PER_WEEK", context).text()

                        },
                        candidate: {
                            firstName: $("CANDI_FIRST_NAME", context).text(),
                            middleName: $("CANDI_MIDDLE_NAME", context).text(),
                            lastName: $("CANDI_LAST_NAME", context).text()
                        },
                        license: {
                            has: $("LICENSE", context).text(),
                            info: $("LICENSE_INFO", context).text()
                        }
                    };

                    if ($("XO_PRTCP2", context).text()) {
                        item.xo.push({
                            id: $("XO_ID2", context).text(),
                            participantId: "[" + $("XO_TYPE2", context).text() + "]" + $("XO_ID2", context).text(),
                            name: $("XO_NAME2", context).text(),
                            email: $("XO_EMAIL2", context).text(),
                            title: $("XO_TITLE2", context).text(),
                            org: $("XO_ORG2", context).text(),
                            prtcp: $("XO_PRTCP2", context).text()
                        });
                    }

                    if ($("XO_PRTCP3", context).text()) {
                        item.xo.push({
                            id: $("XO_ID3", context).text(),
                            participantId: "[" + $("XO_TYPE3", context).text() + "]" + $("XO_ID3", context).text(),
                            name: $("XO_NAME3", context).text(),
                            email: $("XO_EMAIL3", context).text(),
                            title: $("XO_TITLE3", context).text(),
                            org: $("XO_ORG3", context).text(),
                            prtcp: $("XO_PRTCP3", context).text()
                        });
                    }

                    return item;
                },
                getCandidateName: function (item) {
                    var name = '';
                    if (item.candidate) {
                        if (item.candidate.lastName) name += item.candidate.lastName + ', ';
                        if (item.candidate.firstName) name += item.candidate.firstName;
                        if (item.candidate.middleName && item.candidate.middleName.length > 0) {
                            name += ' ' + item.candidate.middleName;
                        }
                    }

                    return name;
                },
                populateRelatedFields: function (item) {
                    if (item) {
                        FormState.updateObjectValue("organizationName", item.adminCodeDesc);
                        FormState.updateTextValue("organizationName1", item.adminCodeDesc, true);
                        FormState.updateTextValue("candiFirstName", item.candidate.firstName, true);
                        FormState.updateTextValue("candiMiddleName", item.candidate.middleName, true);
                        FormState.updateTextValue("candiLastName", item.candidate.lastName, true);
                        FormState.updateObjectValue("administrativeCode", item.adminCode);
                        FormState.updateTextValue("administrativeCode1", item.adminCode, true);
                        FormState.updateTextValue("requestType", item.requestType, true);
                        FormState.updateObjectValue('candidateName', this.getCandidateName(item));

                        if (_selectingOfficial_ac) {
                            var soItems = [];
                            var so = item.so;
                            if (so && so.prtcp) {
                                soItems.push(so);
                            }
                            FormState.updateObjectValue('selectingOfficial', soItems);
                            _selectingOfficial_ac.initializeItems(soItems);
                        }
                        if (_executiveOfficer_ac) {
                            var xoItems = [];
                            var xos = item.xo;
                            if (xos) {
                                for (var i = 0; i < xos.length; i++) {
                                    var xo = xos[i];
                                    if (xo && xo.prtcp) {
                                        xoItems.push(xo);
                                    }
                                }
                            }

                            FormState.updateObjectValue('executiveOfficers', xoItems);
                            _executiveOfficer_ac.initializeItems(xoItems);
                        }
                        if (_hrLiaison_ac) {
                            var hrlItems = [];
                            var hrl = item.hrl;
                            if (hrl && hrl.prtcp) {
                                hrlItems.push(hrl);
                            }
                            FormState.updateObjectValue('hrLiaisons', hrlItems);
                            _hrLiaison_ac.initializeItems(hrlItems);
                        }

                        if (cms_incentives_position) {
                            cms_incentives_position.populateRelatedFields(item);
                        }

                        if (null == item.id) {   // clean
                            FormState.updateSelectValue("requireAdminApproval", "", "Select One", true);

                            if (cms_incentives_pca_details) {
                                cms_incentives_pca_details.reset();
                            }

                            TabManager.resetTabs();
                        }

                        FormMain.updateStatusValues(item);
                    }
                },
                getSelectionLabel: function (item) {
                    return item.requestNumber;
                },
                getCandidateLabel: function (item) {
                    return item.requestNumber;
                },
                getItemID: function (item) {
                    return item.id;
                },
                setDataToForm: function (values) {
                    FormState.updateObjectValue('associatedNEILRequest', values);
                    setPVRelatedUserIds();

                    var item = {
                        id: null,
                        requestNumber: '',
                        requestDate: '',
                        requestType: '',
                        adminCode: '',
                        adminCodeDesc: '',
                        position: {
                            title: '',
                            payPlan: {
                                id: '',
                                desc: ''
                            },
                            series: {
                                id: '',
                                desc: ''
                            },
                            grade: [],
                            descNum: [],
                            typeOfAppointment: '',
                            notToExceedDate: '',
                            workSchedule: {
                                id: '',
                                desc: ''
                            },
                            hoursPerWeek: ''
                        },
                        candidate: {
                            firstName: '',
                            middleName: '',
                            lastName: ''
                        },
                        license: {
                            has: '',
                            info: ''
                        }
                    };

                    if (values && values.length > 0) {
                        item = values[0];
                    } else {
                        if (_hrSpecialist_ac) _hrSpecialist_ac.deleteAllItems();
                        if (_hrSpecialist2_ac) _hrSpecialist2_ac.deleteAllItems();
                    }

                    preloadAttachments(item, FormState.getElementValue('incentiveType'));

                    this.populateRelatedFields(item);
                },

                // initialize
                initialItems: FormState.getElementArrayValue('associatedNEILRequest', [])
            };

            _associatedNEILRequest_ac = FormAutoComplete.makeAutoCompletion(option);
			$('#associatedNEILRequest_ac_DISP li:not(:first)').remove();
        }

		function setRequestGenerated(incentiveType) {
			if (incentiveType == "PCA" ) {
				$("#pcaType option[value='New']").remove();
				$("#pcaType option[value='']").remove();
			}
			$("#associatedRequest option[value='Yes']").remove();
			$("#associatedRequest option[value='']").remove();
			
		}

        function setCandidateName() {
            var name = '';
            var candiFirstName = $('#candiFirstName').val();
            var candiMiddleName = $('#candiMiddleName').val();
            var candiLastName = $('#candiLastName').val();

            if (candiLastName && candiLastName.length > 0 && candiFirstName && candiFirstName.length > 0) {
                name = candiLastName + ", " + candiFirstName;
                if (candiMiddleName && candiMiddleName.length > 0) {
                    name += ' ' + candiMiddleName;
                }
            }

            FormState.updateObjectValue('candidateName', name);
        }

        function handleCandiAgreeRenewal(candiAgreeRenewal) {
            if (_initialized) {
                FormMain.setTabVisibility(INCENTIVES_TYPE.PCA, candiAgreeRenewal);
                setDesignatorMandatory(INCENTIVES_TYPE.PCA, PCA_TYPE.RENEWAL, candiAgreeRenewal);
            }

            var agree = "No" !== candiAgreeRenewal;
            _selectingOfficial_ac.setMandatoryConstraint(agree, agree ? 1 : 0);
            _executiveOfficer_ac.setMandatoryConstraint(agree, agree ? 1 : 0);
        }

        function setCandiAgreeVisibility(incentiveType, pcaType) {
            var renewal = "Renewal" === pcaType;
            //_associatedNEILRequest_ac.setMandatoryConstraint(!renewal, renewal ? 0 : 1);

            FormMain.setComponentVisibility("candiAgreeRenewal_group", renewal);
            if (renewal) {
				//f(!myInfo.isComponent()) {
				//	hyf.util.setMandatoryConstraint("staffingSpecialist_ac", false);
				//}
				if (_initialized) {
						FormUtility.focusElement("candiAgreeRenewal");
				}
            } else {
				//if(!myInfo.isComponent()) {
				//	hyf.util.setMandatoryConstraint("staffingSpecialist_ac", true);
				//}
                FormState.updateSelectValue("candiAgreeRenewal", "", "Select One", true);
            }
            if (incentiveType == INCENTIVES_TYPE.PCA) {
                FormMain.setComponentVisibility("associatedRequest_group", renewal);
            }
            // hyf.util.setComponentUsability("administrativeCode1", renewal);   // uncomment to allow edit when PCA type is Renewal
            // hyf.util.setComponentUsability("organizationName1", renewal);
        }

		function setPDPVisibility(pdpType) {
			if(pdpType == "Other") {
				FormMain.setComponentVisibility("pdpTypeOther_group", true);
				FormMain.setComponentVisibility("vacany_number_layout_group", true);
				FormUtility.focusElement("pdpTypeOther");
			}
			else if(pdpType == "New Hire") {
				FormMain.setComponentVisibility("vacany_number_layout_group", true);
				FormMain.setComponentVisibility("pdpTypeOther_group", false);
				FormState.updateObjectValue('pdpTypeOther', '');
				FormUtility.focusElement("vacancyNumber");
			}
			else {
				FormMain.setComponentVisibility("pdpTypeOther_group", false);
				FormMain.setComponentVisibility("vacany_number_layout_group", false);
				FormState.updateObjectValue('pdpTypeOther', '');
				FormState.updateObjectValue('vacancyNumber', '');
			}
		}
		
		function setStaffHRSByIncentiveType(_initialized) {
		if(_initialized) {
			var incentiveType = FormState.getElementValue('incentiveType');
			if("undefined" == typeof(incentiveType)) {
				if(activityStep.isStartNew() && (myInfo.isINCENTIVEHRS() || myInfo.isComponent())) {  
					FormMain.setComponentVisibility("staffingSpecialist_group",true);
					FormMain.setComponentVisibility('hrSpecialist_group',false);
					FormMain.setComponentVisibility('hrSpecialist2_group',false);
					if(myInfo.isINCENTIVEHRS()) {  
						FormMain.setComponentUsability("staffingSpecialist_ac", true);
						hyf.util.setMandatoryConstraint("staffingSpecialist_ac", true);
					} else {
						//FormMain.setComponentUsability("staffingSpecialist_ac", false);
						FormMain.setComponentUsability("staffingSpecialist_ac", false);
						hyf.util.setMandatoryConstraint("staffingSpecialist_ac", false);
					}
				}
				else if(activityStep.isStartNew() && myInfo.isHRS()) {
					FormMain.setComponentVisibility("staffingSpecialist_group",false);
					FormMain.setComponentVisibility('hrSpecialist_group',true);
					FormMain.setComponentVisibility('hrSpecialist2_group',true);
				}
			} 		
			else if(incentiveType == "PCA" || incentiveType == "PDP") {
				var pcaType = FormState.getElementValue("pcaType");
				FormMain.setComponentVisibility("staffingSpecialist_group",true);
				FormMain.setComponentVisibility('hrSpecialist_group',false);
				FormMain.setComponentVisibility('hrSpecialist2_group',false);
				if(activityStep.isStartNew()) {
					if(myInfo.isINCENTIVEHRS()) {  
						FormMain.setComponentUsability("staffingSpecialist_ac", true);
						if(pcaType == "Renewal") {
							hyf.util.setMandatoryConstraint("staffingSpecialist_ac", false);
						}
						else {
							hyf.util.setMandatoryConstraint("staffingSpecialist_ac", true);
						}
					} else {
						FormMain.setComponentUsability("staffingSpecialist_ac", false);
						hyf.util.setMandatoryConstraint("staffingSpecialist_ac", false);
					}
				}
				else {
					if(pcaType == "Renewal") {
							hyf.util.setMandatoryConstraint("staffingSpecialist_ac", false);
					}
					else {
						hyf.util.setMandatoryConstraint("staffingSpecialist_ac", true);
					}
				}
				
			}
			else {
				FormMain.setComponentVisibility("staffingSpecialist_group",false);
				FormMain.setComponentVisibility('hrSpecialist_group',true);
				FormMain.setComponentVisibility('hrSpecialist2_group',true);
			}
		}		
		}

        function setVisibilityByIncentiveType(incentiveType) {
            if (_initialized) {
                FormMain.setTabVisibility(incentiveType);
            }
            var pca = INCENTIVES_TYPE.PCA === incentiveType;
			var pdp = INCENTIVES_TYPE.PDP === incentiveType;
			var le = INCENTIVES_TYPE.LE === incentiveType;
			var sam = INCENTIVES_TYPE.SAM === incentiveType;
							
            FormMain.setComponentVisibility("pcaType_group", pca);
			FormMain.setComponentVisibility("pdpType_group", pdp);
			FormMain.setComponentVisibility("associatedRequest_group", pdp);
			
			var associatedRequest = FormState.getElementValue('associatedRequest');
			var pcaType = FormState.getElementValue("pcaType");
			var pdpType = FormState.getElementValue("pdpType");

            if (pca) {
                if (_initialized) {
                    FormUtility.focusElement("pcaType");
                }
				//if(pcaType == "New") {
				//		hyf.util.setMandatoryConstraint("staffingSpecialist_ac", true);
				//}
				//else {
				//	hyf.util.setMandatoryConstraint("staffingSpecialist_ac", false);
				//}
				FormMain.setComponentVisibility("vacany_number_layout_group",false);
				FormMain.setComponentVisibility("pdpTypeOther_group",false);

				/*
				FormMain.setComponentVisibility("staffingSpecialist_group",true);
				if(!myInfo.isHRS() && !myInfo.isINCENTIVEHRS() && myInfo.isComponent()) {  
					FormMain.setComponentUsability("staffingSpecialist_ac", false);
					hyf.util.setMandatoryConstraint("staffingSpecialist_ac", false);
				}
				else {
					FormMain.setComponentUsability("staffingSpecialist_ac", true);
					if(pcaType == "New") {
						hyf.util.setMandatoryConstraint("staffingSpecialist_ac", true);
					}
					else {
						hyf.util.setMandatoryConstraint("staffingSpecialist_ac", false);
					}
					
				}
  				FormMain.setComponentVisibility('hrSpecialist_group',false);
				FormMain.setComponentVisibility('hrSpecialist2_group',false);
				FormMain.setComponentVisibility("vacany_number_layout_group",false);
				FormMain.setComponentVisibility("pdpTypeOther_group",false);
				*/

            } else if (pdp) {
                FormMain.setComponentVisibility("vacany_number_layout_group", (pdpType ==='New Hire' || pdpType ==='Other'));
				FormMain.setComponentVisibility("pdpTypeOther_group", pdpType ==='Other');
                //FormMain.setComponentVisibility('candiAgreeRenewal_group',!pdp);
				 if (_initialized) {
                    FormUtility.focusElement("pdpType");
                }
				/*
				FormMain.setComponentVisibility("staffingSpecialist_group",true);
				if(!myInfo.isHRS() && !myInfo.isINCENTIVEHRS() && myInfo.isComponent()) {   
					FormMain.setComponentUsability("staffingSpecialist_ac", false );
					hyf.util.setMandatoryConstraint("staffingSpecialist_ac", false);
				}
				else {
					FormMain.setComponentUsability("staffingSpecialist_ac", true);
					hyf.util.setMandatoryConstraint("staffingSpecialist_ac", true);
				}
				FormMain.setComponentVisibility('hrSpecialist_group',false);
				FormMain.setComponentVisibility('hrSpecialist2_group',false);
				*/
            }else if (le || sam) {
				FormMain.setComponentVisibility("vacany_number_layout_group",false);
				FormMain.setComponentVisibility("pdpTypeOther_group",false);
				FormMain.setComponentVisibility("staffingSpecialist_group",false);
				FormMain.setComponentVisibility('hrSpecialist_group',true);
				FormMain.setComponentVisibility('hrSpecialist2_group',true);
            }

            var candiAgreeRenewal = FormState.getElementValue("candiAgreeRenewal");
			
            if (INCENTIVES_TYPE.PCA === incentiveType) {
                if (activityStep.isStartNew() || activityStep.isSOReview() || activityStep.isSOReviewForModification()) {
					disableDesignatedSection();
                } else {
                    enableDesignatedSection(incentiveType,pcaType,candiAgreeRenewal);
                }
            } else {
                disableDesignatedSection();
            }
			 setIncentiveElementVisibly(incentiveType, associatedRequest);
        }

        // function setOhcDirectorVisibility(requireAdminApproval) {
        //     var isRequired = "Yes" === requireAdminApproval;
        //     FormMain.setComponentVisibility("ohcDirector_group", isRequired);
        //     if (!isRequired) {
        //         _ohcDirector_ac.deleteAllItems();
        //     } else {
        //         $("#ohcDirector_ac_label > .mandatory").show();
        //     }
        // }

        // function setOffAdminVisibility(requireAdminApproval) {
        //     var isRequired = "Yes" === requireAdminApproval;
        //     FormMain.setComponentVisibility("offAdmin_group", "Yes" === requireAdminApproval)
        //     if (!isRequired) {
        //         _offAdmin_ac.deleteAllItems();
        //     } else {
        //         $("#offAdmin_ac_label > .mandatory").show();
        //     }
        // }



        function setDesignatorVisibility(incentiveType) {
            if (_designatedSectionEnabled) {
                var pca = INCENTIVES_TYPE.PCA === incentiveType;
				
                // FormMain.setComponentVisibility("tabgDivDirector_group", false);
                // FormMain.setComponentVisibility("tabgDirector_group", false);
                // FormMain.setComponentVisibility("cp_group", false);
                // FormMain.setComponentVisibility("ofmDirector_group", false);
                // FormMain.setComponentVisibility("requireAdminApproval_group", false);
                // FormMain.setComponentVisibility("ohcDirector_group", false);

                if (pca) {
                    FormMain.setComponentVisibility("requireAdminApproval_group", true);
                    // onRequireAdminApprovalChanged(FormState.getElementValue("requireAdminApproval"));
                } else {
                    FormMain.setComponentVisibility("requireAdminApproval_group", false);
                    FormState.updateSelectValue("requireAdminApproval", "", "Select One", true);
                    // setOhcDirectorVisibility("");
                    // setOffAdminVisibility("");
                }

            }
        }

        function setDesignatorMandatory(incentiveType, pcaType, candiAgreeRenewal) {
            if (_designatedSectionEnabled) {
                // var renewalYes = !(incentiveType === INCENTIVES_TYPE.PCA && pcaType === PCA_TYPE.RENEWAL && candiAgreeRenewal === "No");
                var renewalYes = (incentiveType === INCENTIVES_TYPE.PCA && pcaType === PCA_TYPE.RENEWAL && candiAgreeRenewal === "Yes");
                // _dghoDirector_ac.setMandatoryConstraint(renewalYes, renewalYes ? 1 : 0);
                // _chiefPhysician_ac.setMandatoryConstraint(renewalYes, renewalYes ? 1 : 0);
                // _ofmDirector_ac.setMandatoryConstraint(renewalYes, renewalYes ? 1 : 0);
                // _tabgDirector_ac.setMandatoryConstraint(renewalYes, renewalYes ? 1 : 0);
                hyf.util.setMandatoryConstraint("requireAdminApproval", renewalYes);
                // _ohcDirector_ac.setMandatoryConstraint(renewalYes, renewalYes ? 1 : 0);
                // _offAdmin_ac.setMandatoryConstraint(renewalYes, renewalYes ? 1 : 0);

                // hyf.util.setComponentVisibility("button_SubmitWorkitem", renewalYes);
            }
        }

        function disableDesignatedSection() {
            // hyf.util.hideComponent("designatedUsers_group");
            hyf.util.hideComponent("requireAdminApproval_group");
			//hyf.util.hideComponent("staffingSpecialist_group");

            if (_designatedSectionEnabled) {
                // _dghoDirector_ac.deleteAllItems();
                // _chiefPhysician_ac.deleteAllItems();
                // _ofmDirector_ac.deleteAllItems();
                // _tabgDirector_ac.deleteAllItems();
                FormState.updateSelectValue("requireAdminApproval", "", "Select One", true);
                // _ohcDirector_ac.deleteAllItems();
                // _offAdmin_ac.deleteAllItems();
            }
        }

        function enableDesignatedSection(incentiveType, pcaType, candiAgreeRenewal, readOnly_) {
            if (!_designatedSectionEnabled) {
                // setDGHODirectorAutoCompletion(readOnly_);
                // setChielfPhysicianAutoCompletion(readOnly_);
                // setOFMDirectorAutoCompletion(readOnly_);
                // setTAGBDirectorAutoCompletion(readOnly_);
                // setOHCDirectorAutoCompletion(readOnly_);
                // setOFFAdminAutoCompletion(readOnly_);

                _designatedSectionEnabled = true;
            }
            // hyf.util.showComponent("designatedUsers_group");
            hyf.util.showComponent("requireAdminApproval_group");
			//hyf.util.showComponent("staffingSpecialist_group");

            setDesignatorVisibility(incentiveType);
            setDesignatorMandatory(incentiveType, pcaType, candiAgreeRenewal);

            FormMain.setComponentUsability("requireAdminApproval", true);
        }

        function postDisableTab(afterAllTabLoaded, tab) {
            if (afterAllTabLoaded) {
                if (!activityStep.isHRSRecordConclusion()) {
                    var incentiveType = FormState.getElementValue('incentiveType');
                    if (tab.readOnly && (activityStep.isHRSReview() || activityStep.isDGHOReview())) {
                        var pcaType = FormState.getElementValue("pcaType");
                        var candiAgreeRenewal = FormState.getElementValue("candiAgreeRenewal");
                        enableDesignatedSection(incentiveType, pcaType, candiAgreeRenewal, false);
                    }
                }
            }
        }

        function initComponents() {
            var incentiveType = FormState.getElementValue('incentiveType', "");
            FormMain.setTabVisibility(incentiveType, FormState.getElementValue("candiAgreeRenewal"));

            setAssociatedRequestNumberAutoCompletion(incentiveType);
            setSelectingOfficialAutoCompletion();
            setExecutiveOfficialAutoCompletion();
            setHRLiaisonAutoCompletion();
            setHRSpecialistAutoCompletion();
            setHRSpecialist2AutoCompletion();
			setHRStaffingSpecialistAutoCompletion();
            setAdministrativeCodeAutoCompletion();

            var pcaType = FormState.getElementValue("pcaType");
			var pdpType = FormState.getElementValue("pdpType");
            var candiAgreeRenewal = FormState.getElementValue("candiAgreeRenewal");
            handleCandiAgreeRenewal(candiAgreeRenewal);

            setVisibilityByIncentiveType(incentiveType);
            setCandiAgreeVisibility(incentiveType, pcaType);
			setPDPVisibility(pdpType);
			
			var requestGenerated = FormState.getElementValue('requestGenerated');
			if((incentiveType == INCENTIVES_TYPE.PCA || incentiveType == INCENTIVES_TYPE.PDP) && requestGenerated == "Yes") {
				setRequestGenerated(incentiveType);
			}

            var processName = FormMain.getProcessInfo().process.definitionName;
            if (activityStep.isStartNew()) {
                var isV2MainProcess = (processName === PROCESS_NAME.REQUEST_V2);

                var disableIncentiveType = FormUtility.getInputElementValue("pv_disableIncentiveType", '');
                if(!isV2MainProcess) {
                    disableIncentiveType = "PDP,PCA";
                }
                if("" != disableIncentiveType) {
                    var disableArray = disableIncentiveType.split(",");
                    for (var i =0; i < disableArray.length; i++) {
                        var disableType = (disableArray[i]).trim();
                        if("" != disableType) {
                            $("#incentiveType option[value="+ disableType + "]").remove();
                        }
                    }
                }
				if(myInfo.isHRS()) {
					$("#incentiveType option[value=" + INCENTIVES_TYPE.PDP + "]").remove();
                    $("#incentiveType option[value=" + INCENTIVES_TYPE.PCA + "]").remove();
                    /*
					if($("#incentiveType option").length <= 1) {
                        bootbox.alert("You don't have an authority to open this request.", function () {
                            basicWIHActionClient.exit({confirmMsg: null});
                        });
                    }
					*/
				}
				else if(myInfo.isINCENTIVEHRS()) {
					$("#incentiveType option[value=" + INCENTIVES_TYPE.SAM + "]").remove();
                    $("#incentiveType option[value=" + INCENTIVES_TYPE.LE + "]").remove();
                    /*
					if($("#incentiveType option").length <= 1) {
                        bootbox.alert("You don't have an authority to open this request.", function () {
                            basicWIHActionClient.exit({confirmMsg: null});
                        });
                    }
					*/
				}
                else if(myInfo.isComponent()) {
                    $("#incentiveType option[value=" + INCENTIVES_TYPE.SAM + "]").remove();
                    $("#incentiveType option[value=" + INCENTIVES_TYPE.LE + "]").remove();
                    if($("#incentiveType option").length <= 1) {
                        bootbox.alert("You don't have an authority to open this request.", function () {
                            basicWIHActionClient.exit({confirmMsg: null});
                        });
                    }
                }
				
            } else {
                var isMainProcess = (processName === PROCESS_NAME.REQUEST) || (processName === PROCESS_NAME.REQUEST_V2);
                FormMain.setComponentUsability("incentiveType", isMainProcess);
                hyf.util.setMandatoryConstraint("incentiveType", isMainProcess);
				
				/*
				if (activityStep.isSOReview()) {
					hyf.util.setMandatoryConstraint("associatedNEILRequest_ac", false);
					hyf.util.setMandatoryConstraint("requestType", false);
					hyf.util.setMandatoryConstraint("candiLastName", false);
					hyf.util.setMandatoryConstraint("candiFirstName", false);
					hyf.util.setMandatoryConstraint("selectingOfficial_ac", false);
					hyf.util.setMandatoryConstraint("executiveOfficer_ac", false);
					hyf.util.setMandatoryConstraint("hrSpecialist_ac", false);
				}
				*/
				if(incentiveType===INCENTIVES_TYPE.PCA && !activityStep.isHR_REVIEW_APPROVAL()) {
					FormMain.setComponentUsability("pcaType", isMainProcess);
					FormMain.setComponentUsability("candiAgreeRenewal", isMainProcess);
					FormMain.setComponentUsability("associatedRequest", isMainProcess);
					FormMain.setComponentUsability("associatedNEILRequest_ac", isMainProcess);
					FormMain.setComponentUsability("requestType", isMainProcess);
					FormMain.setComponentUsability("pdpRequestType", isMainProcess);
					FormMain.setMandatoryConstraint("pcaType", isMainProcess);
					FormMain.setMandatoryConstraint("candiAgreeRenewal", isMainProcess);
					FormMain.setMandatoryConstraint("associatedRequest", isMainProcess);
					FormMain.setMandatoryConstraint("associatedNEILRequest_ac", isMainProcess);
					FormMain.setMandatoryConstraint("requestType", isMainProcess);
					FormMain.setMandatoryConstraint("pdpRequestType", isMainProcess);
				}
				else if(incentiveType===INCENTIVES_TYPE.PDP && !activityStep.isHR_REVIEW_APPROVAL()) {
					FormMain.setComponentUsability("pdpType", isMainProcess);
					FormMain.setComponentUsability("pdpTypeOther", isMainProcess);
					FormMain.setComponentUsability("associatedRequest", isMainProcess);
					FormMain.setComponentUsability("associatedNEILRequest_ac", isMainProcess);
					FormMain.setComponentUsability("requestType", isMainProcess);
					FormMain.setComponentUsability("pdpRequestType", isMainProcess);
					FormMain.setComponentUsability("vacancyNumber", isMainProcess);
					FormMain.setMandatoryConstraint("pdpType", isMainProcess);
					FormMain.setMandatoryConstraint("pdpTypeOther", isMainProcess);
					FormMain.setMandatoryConstraint("associatedRequest", isMainProcess);
					FormMain.setMandatoryConstraint("associatedNEILRequest_ac", isMainProcess);
					FormMain.setMandatoryConstraint("requestType", isMainProcess);
					FormMain.setMandatoryConstraint("pdpRequestType", isMainProcess);
					FormMain.setMandatoryConstraint("vacancyNumber", isMainProcess);

				}
				else {
					 if (activityStep.isSOReview()) {
						hyf.util.setMandatoryConstraint("associatedNEILRequest_ac", false);
						hyf.util.setMandatoryConstraint("requestType", false);
						hyf.util.setMandatoryConstraint("candiLastName", false);
						hyf.util.setMandatoryConstraint("candiFirstName", false);
						hyf.util.setMandatoryConstraint("selectingOfficial_ac", false);
						hyf.util.setMandatoryConstraint("executiveOfficer_ac", false);
						hyf.util.setMandatoryConstraint("hrSpecialist_ac", false);
					}
				}
				
                
            }
        }

        function initEventHandlers() {
            $('#incentiveType').on('change', function (e) {

                var target = e.target;
                var incentiveType = target.options[target.options.selectedIndex].value;
                // preloadAttachments(FormState.getElementSingleValue("associatedNEILRequest"), incentiveType);
                setVisibilityByIncentiveType(incentiveType);
                FormMain.updateIncentiveTypeOutput(incentiveType);
                FormMain.setSubmitButtonLabel({incentiveType: incentiveType});
                FormAttachmentHandler.refreshCustomButtons({incentiveType: incentiveType});

				//Dari's Changes start
				// clearGroupContent('designatedUsers_group');
				//clearGroupContent('associatedRequest_group');
				//clearGroupContent('candiAgreeRenewal_group');
				//clearGroupContent('pdpType_group');
				//var pdpType = FormState.getElementValue("pdpType");
				
				setClearDataByIncentiveType(incentiveType);
				FormMain.setComponentVisibility("associatedNEILRequest_group", true);
				//FormMain.setComponentVisibility("vacany_number_layout_group", (incentiveType ==='PDP' &&(pdpType ==='New Hire' || pdpType ==='Other')));

				existingRequestInitialLoad(incentiveType);
				setIncentiveElementVisibly(incentiveType);//set group not related to pdp invisible.
				//End of Dari's changes

                if (cms_incentives_position) {
                    cms_incentives_position.onIncentiveTypeChange(incentiveType);
                }
				if (cms_incentives_pdp_panel) {
					cms_incentives_pdp_panel.onIncentiveTypeChanged(incentiveType);
				}
				if (cms_incentives_pdp_details) {
                    cms_incentives_pdp_details.onIncentiveTypeChanged(incentiveType);
                }

                if (incentiveType == INCENTIVES_TYPE.PCA) {
                    var pcaType = $( "#pcaType option:checked" ).val();
                    setCandiAgreeVisibility(INCENTIVES_TYPE.PCA, pcaType);
					//FormMain.setComponentVisibility('hrSpecialist_group',false);
					//FormMain.setComponentVisibility('hrSpecialist2_group',false);
					if (_hrSpecialist_ac) _hrSpecialist_ac.deleteAllItems();
					if (_hrSpecialist2_ac) _hrSpecialist2_ac.deleteAllItems();
					//if(!myInfo.isHRS() && !myInfo.isINCENTIVEHRS() && myInfo.isComponent()) {  
					//	FormMain.setComponentUsability("staffingSpecialist_ac", false);
					//	hyf.util.setMandatoryConstraint("staffingSpecialist_ac", false);
					//}
					//else {
					//	FormMain.setComponentUsability("staffingSpecialist_ac", true);
					//	hyf.util.setMandatoryConstraint("staffingSpecialist_ac", true);
					//}
                }
				else if (incentiveType == INCENTIVES_TYPE.PDP) {
					//FormMain.setComponentVisibility('hrSpecialist_group',false);
					//FormMain.setComponentVisibility('hrSpecialist2_group',false);
					if (_hrSpecialist_ac) _hrSpecialist_ac.deleteAllItems();
					if (_hrSpecialist2_ac) _hrSpecialist2_ac.deleteAllItems();
					//if(!myInfo.isHRS() && !myInfo.isINCENTIVEHRS() && myInfo.isComponent()) {  
					//	FormMain.setComponentUsability("staffingSpecialist_ac", false);
					//	hyf.util.setMandatoryConstraint("staffingSpecialist_ac", false);
					//}
					//else {
					//	FormMain.setComponentUsability("staffingSpecialist_ac", true);
					//	hyf.util.setMandatoryConstraint("staffingSpecialist_ac", true);
					//}
                }
				else if (incentiveType == INCENTIVES_TYPE.LE) {
					//FormMain.setComponentVisibility('hrSpecialist_group',true);
					//FormMain.setComponentVisibility('hrSpecialist2_group',true);
					if (_staffingSpecialist_ac) _staffingSpecialist_ac.deleteAllItems();
					if (_staffingSpecialist_ac) _staffingSpecialist_ac.deleteAllItems();
                }
				else if (incentiveType == INCENTIVES_TYPE.SAM) {
					//FormMain.setComponentVisibility('hrSpecialist_group',true);
					//FormMain.setComponentVisibility('hrSpecialist2_group',true);
					if (_staffingSpecialist_ac) _staffingSpecialist_ac.deleteAllItems();
					if (_staffingSpecialist_ac) _staffingSpecialist_ac.deleteAllItems();
                }
				setAssociatedRequestNumberAutoCompletion(incentiveType);
            });
			
            $('#pcaType').on('change', function (e) {
                var target = e.target;
                var pcaType = target.options[target.options.selectedIndex].value;
                setCandiAgreeVisibility(INCENTIVES_TYPE.PCA, pcaType);
				handleCandiAgreeRenewal(FormState.getElementValue("candiAgreeRenewal"));
				FormMain.setSubmitButtonLabel({pcaType: pcaType});				
                FormState.updateSelectValue("candiAgreeRenewal", "", "Select One", true);
					
                if(activityStep.isStartNew()) {
					if(myInfo.isINCENTIVEHRS()) {  
						FormMain.setComponentUsability("staffingSpecialist_ac", true);
						if(pcaType == "Renewal") {
							hyf.util.setMandatoryConstraint("staffingSpecialist_ac", false);
						}
						else {
							hyf.util.setMandatoryConstraint("staffingSpecialist_ac", true);
						}
					} else {
						FormMain.setComponentUsability("staffingSpecialist_ac", false);
						hyf.util.setMandatoryConstraint("staffingSpecialist_ac", false);
					}
				}
				else {
					if(pcaType == "Renewal") {
							hyf.util.setMandatoryConstraint("staffingSpecialist_ac", false);
					}
					else {
						hyf.util.setMandatoryConstraint("staffingSpecialist_ac", true);
					}
				}
            });
			
			$('#pdpType').on('change', function (e) {
                var target = e.target;
                var pdpType = target.options[target.options.selectedIndex].value;
				setPDPVisibility(pdpType);
            });

            $('#candiFirstName').on('change', setCandidateName);
            $('#candiMiddleName').on('change', setCandidateName);
            $('#candiLastName').on('change', setCandidateName);

            $('#requireAdminApproval').on('change', function (e) {
                var target = e.target;
                var requireAdminApproval = target.options[target.options.selectedIndex].value;

                FormMain.setSubmitButtonLabel({requireAdminApproval: requireAdminApproval});
 
                if (cms_incentives_pca_review) cms_incentives_pca_review.onRequireAdminApprovalChanged(requireAdminApproval);
                if (cms_incentives_pca_approval) cms_incentives_pca_approval.onRequireAdminApprovalChanged(requireAdminApproval);
            });

            $('#candiAgreeRenewal').on('change', function (e) {
                var target = e.target;
                handleCandiAgreeRenewal(target.value);
                FormMain.setSubmitButtonLabel({candiAgreeRenewal: target.value});
            });

			$('#associatedRequest').on('change',existingRequest); //function (e) {
                //var target = e.target;
                //handleCandiAgreeRenewal(target.value);  YJ need work
                //FormMain.setSubmitButtonLabel({candiAgreeRenewal: target.value});
           // });
		  
        }

////////////////////
        //Dari's changes start here. TODO: request number generation needs to be implemented for NO scenario
        function existingRequest(e){
            var selection = e.target;
            var value = selection.options[selection.options.selectedIndex].value;
            var incentiveType = $( "#incentiveType option:checked" ).val();
            var pcaType = $( "#pcaType option:checked" ).val();
			var requestGenerated = FormState.getElementValue('requestGenerated');
			_administrativeCode_ac.initializeItems([]);
            _organizationName_ac.initializeItems([]);
			_associatedNEILRequest_ac.initializeItems([]);
			_staffingSpecialist_ac.initializeItems([]);
			if(incentiveType=="PDP" || incentiveType == "PCA") {
				FormState.updateObjectValue('vacancyNumber', '');
			}
            //if( (((incentiveType == "PCA") && ("Renewal" === pcaType) ) || incentiveType == "PDP") && (value === "No")) {		
			if(	value === "No") {
				FormState.updateSelectValue('pdpRequestType', "", "Select One",true);
                FormMain.setComponentVisibility('associatedNEILRequest_group',false);
                FormMain.setComponentVisibility('pdp_pca_requestType_layout_group',true);
                FormMain.setComponentVisibility('non_pca_pdp_requestType_layout_group',false);
                FormMain.setComponentVisibility('admin_code_org_name_section1',false);
				
                //FormState.updateObjectValue('administrativeCode', "");
                //FormState.updateObjectValue('organizationName', "");
                FormMain.setComponentVisibility('admin_code_org_name_section_ac',true);
            } else {
				if (requestGenerated=='Yes') {
					
					//return;
				}
                FormMain.setComponentVisibility("associatedNEILRequest_group", true);
                FormMain.setComponentVisibility("pdp_pca_requestType_layout_group", false);
                FormMain.setComponentVisibility('non_pca_pdp_requestType_layout_group',true);
                //FormState.updateObjectValue('administrativeCode', $("#administrativeCode1").val());
                //FormState.updateObjectValue('organizationName', $("#organizationName1").val());
                FormMain.setComponentVisibility('admin_code_org_name_section1',true);
                FormMain.setComponentVisibility('admin_code_org_name_section_ac',false);
                hyf.util.setMandatoryConstraint('associatedNEILRequest_ac', true);
				
				_selectingOfficial_ac.initializeItems([]);
				_executiveOfficer_ac.initializeItems([]);
				_hrLiaison_ac.initializeItems([]);
				//_hrSpecialist_ac.initializeItems([]);
				//_hrSpecialist2_ac.initializeItems([]);
				FormState.updateObjectValue('candiFirstName', '');
				FormState.updateObjectValue('candiMiddleName', '');
				FormState.updateObjectValue('candiLastName', '');
            }
            if(cms_incentives_position) {
                cms_incentives_position.onChangeAssociateRequest(incentiveType, value);
            }
        }
        function existingRequestInitialLoad(incentiveType, associatedRequest){
            if ("undefined" == typeof(associatedRequest)) {
                associatedRequest = FormState.getElementValue('associatedRequest');
            }
            var pcaType = FormState.getElementValue('pcaType');
            var pdpType = FormState.getElementValue("pdpType");

            if (((incentiveType == INCENTIVES_TYPE.PCA) && ("Renewal" === pcaType)) || incentiveType == INCENTIVES_TYPE.PDP) {
                if(associatedRequest === 'No') {
                    FormMain.setComponentVisibility('associatedNEILRequest_group', false);
                    FormMain.setComponentVisibility('admin_code_org_name_section1', false);
                    FormMain.setComponentVisibility('admin_code_org_name_section_ac', true);
                    FormMain.setComponentVisibility('non_pca_pdp_requestType_layout_group', false);
                    FormMain.setComponentVisibility('pdp_pca_requestType_layout_group', true);
                    return;
                }
            }

            FormMain.setComponentVisibility('associatedNEILRequest_group',true);
            FormMain.setComponentVisibility('non_pca_pdp_requestType_layout_group',true);
            FormMain.setComponentVisibility('pdp_pca_requestType_layout_group',false);
            FormMain.setComponentVisibility('admin_code_org_name_section1',true);
            FormMain.setComponentVisibility('admin_code_org_name_section_ac',false);
            hyf.util.setMandatoryConstraint('associatedNEILRequest_ac', true);

            FormMain.setComponentVisibility("vacany_number_layout_group", (incentiveType ==='PDP' &&(pdpType ==='New Hire' || pdpType ==='Other')));
        }

        function setIncentiveElementVisibly( incentiveType, associatedRequest ) {
            if ("undefined" == typeof(associatedRequest)) {
                associatedRequest = FormState.getElementValue('associatedRequest');
            }
            var candiAgreeRenewal = FormState.getElementValue('candiAgreeRenewal');
            if(incentiveType ==='PDP'){
                //FormMain.setComponentVisibility('non_pca_pdp_requestType_layout_group',(associatedRequest ==='Yes'));
                //FormMain.setComponentVisibility('pdp_pca_requestType_layout_group',(associatedRequest ==='No'));
                FormMain.setComponentVisibility('candiAgreeRenewal_group',false);
            }
            existingRequestInitialLoad(incentiveType, associatedRequest);
        }

		function setClearDataByIncentiveType(incentiveType) {
			FormState.updateObjectValue('pdpTypeOther', '');
			FormState.updateObjectValue('vacancyNumber', '');
			FormState.updateSelectValue("pcaType", "", "Select One", true);
			FormState.updateSelectValue("pdpType", "", "Select One", true);
			FormState.updateSelectValue("candiAgreeRenewal", "", "Select One", true);
			FormState.updateSelectValue("associatedRequest", "", "Select One", true);
		}

        // Clears content of elements that belongs to the group specified.
        // @param groupId - element id of the group layout (div tag)
        function clearGroupContent(groupId) {

            // TEXTBOX
            $.each($('#' + groupId + ' input.textbox'), function (index, value) {
                var value = $(this).val();
                if (value && value.length > 0) {
                    $(this).val('');
                    FormState.updateTextValue($(this)[0].id, '', false);
                }
            });

            // TEXTAREA
            $.each($('#' + groupId + ' textarea'), function (i, v) {
                var value = $(this).val();
                if (value && value.length > 0) {
                    $(this).val('');
                    FormState.updateTextValue($(this)[0].id, '', false);
                }
            });

            // CHECKBOX
            $.each($('#' + groupId + ' input[type=checkbox]'), function (i, v) {
                $(this).prop('checked', false);
                var value = $(this).val();
                if (value && value.length > 0) {
                    $(this).trigger('change');
                }
            });
            $.each($('#' + groupId + ' input.checkbox'), function (i, v) {
                var value = $(this).prop('checked');
                if (value === true) {
                    $(this).prop('checked', false);
                    $(this).trigger('change');
                }
            });

            // SELECT
            $.each($('#' + groupId + ' select'), function (i, v) {
                var value = $(this).val();
                if (value && value.length > 0) {
                    $(this).val('');
                    $(this).trigger('change');

                }
            });

            // OUTPUT
            $.each($('#' + groupId + ' span.output'), function (i, v) {
                var value = $(this).text();
                if (value && value.length > 0) {
                    $(this).text('');
                    FormState.updateTextValue($(this)[0].id, '', false);
                }
            });

            // HIDDEN
            $.each($('#' + groupId + ' input[type=hidden]'), function (index, value) {
                var value = $(this).val();
                if (value && value.length > 0) {
                    $(this).val('');
                    FormState.updateTextValue($(this)[0].id, '', false);
                }
            });


            // SELECTED - READONLY
            $('#'+groupId+'  ul.autocomplete_ul li img').trigger("click");
            // $.each($('#' + groupId + ' ul.autocomplete_ul li'), function (i, v) {
            // 	// remove elements created by autocomplete selection
            // 	$(this).remove();
            // });
        }


/////////////////////

        function init(readOnly, tabObject) {
            _readOnly = readOnly;

			
            initComponents();
            initEventHandlers();
			
            FormMain.resetMandatoryMark(tabObject);
			
            _initialized = true;
			setStaffHRSByIncentiveType(_initialized);
        }

        function render(action) {
        }

        return {
            postDisableTab: postDisableTab,
            setDesignatedUserAutoCompletion: setDesignatedUserAutoCompletion,
			setRequestGenerated: setRequestGenerated,
			init: init,
            render: render
        }
    };
    var _initializer = window.cms_incentives_general || (window.cms_incentives_general = cms_incentives_general());
})(window);
