var UG_SEL_OFC = "Selecing Official";
var UG_HR_CLS_SPC = "HR Classification Specialist";
var UG_HR_STF_SPC = "HR Staffing Specialist";


/**
 * onload event handler for Approvals page
 */
function initApproveTab(){

	var pdSupvCertChkElm        = $("#PD_SUPV_CERT");               // Selecing Official approval checkbox element
	var pdSupvNameElm           = $("#PD_SUPV_NAME");               // Selecing Official name element
	var pdSupvTitleElm          = $("#PD_SUPV_TITLE");              // Selecing Official title element
	var pdSupvTitleMarker       = $("#PD_SUPV_TITLE_marker");       // Selecing Official title marker
	var pdSupvSigElm            = $("#PD_SUPV_SIG");                // Selecing Official signature element
	var pdSupvSigDtElm          = $("#PD_SUPV_SIG_DT");             // Selecing Official certification date element
	var pdClsSpecChkElm         = $("#PD_CLS_SPEC_CERT");           // Classification Specialist approval checkbox element
	var pdClsSpecNameElm        = $("#PD_CLS_SPEC_NAME");           // Classification Specialist name element
	var pdClsSpecTitleElm       = $("#PD_CLS_SPEC_TITLE");          // Classification Specialist title element
	var pdClsSpecTitleMarker    = $("#PD_CLS_SPEC_TITLE_marker");   // Classification Specialist title marker
	var pdClsSpecSigElm         = $("#PD_CLS_SPEC_SIG");            // Classification Specialist signature element
	var pdClsSpecSigDtElm       = $("#PD_CLS_SPEC_DT");             // Classification Specialist certification date element
	
	enableDisableClsfAprContent();

	//-------------------------------------------------------------------------
	// When checkbox is checked, capture name and date for Selecing Official
	//-------------------------------------------------------------------------
	//debug
	//console.log("onload event, check status of PD_SUPV_CERT = " + pdSupvCertChkElm.prop("checked"));

	// add event handler for the parent checkbox to capture name and date onto the dependent text fields
	pdSupvCertChkElm.change(function() {
		//debug
		//console.log("change event, check status of PD_SUPV_CERT = " + $(this).prop("checked"));
		if ("Approve PD Coversheet - SO" == getActivityName()) {
			// set or clear dependent field values
			if ($(this).prop("checked")) {
				
				if (pdSupvSigElm.val() == null || pdSupvSigElm.val().length <= 0
					|| pdSupvNameElm.val() == null || pdSupvNameElm.val().length <= 0
					|| pdSupvSigDtElm.val() == null || pdSupvSigDtElm.val().length <= 0) {
					pdSupvSigElm.val($("#h_currentUserMemberID").val()); // set current user memberid for signature
					pdSupvNameElm.val($("#h_currentUserName").val());    // set current user name for signature
					pdSupvSigDtElm.val(getMMDDYYYYDateStr(new Date()));  // set current date for signature
				}
				pdSupvTitleElm.prop("readonly", false);
				pdSupvTitleElm.attr("_required", true);
				pdSupvTitleMarker.show();
			} else {
				pdSupvSigElm.val("");      // clear memberid
				pdSupvNameElm.val("");     // clear name
				pdSupvSigDtElm.val("");    // clear date
				pdSupvTitleElm.val("");    // clear title
				pdSupvTitleElm.prop("readonly", true);
				pdSupvTitleElm.attr("_required", false);
				pdSupvTitleMarker.hide();
			}
		}
	});

	//---------------------------------------------------------------------------------------
	// When checkbox is checked, capture name and date for Classification Specialist
	//---------------------------------------------------------------------------------------
	//debug
	//console.log("onload event, check status of PD_CLS_SPEC_CERT = " + pdClsSpecChkElm.prop("checked"));

	// add event handler for the parent checkbox to capture name and date onto the dependent text fields
	pdClsSpecChkElm.change(function() {
		//debug
		//console.log("change event, check status of PD_CLS_SPEC_CERT = " + $(this).prop("checked"));
		if ("Approve Coversheet and Create Final Pkg" == getActivityName()) {
			// set or clear dependent field values
			if ($(this).prop("checked")) {
				if (pdClsSpecSigElm.val() == null || pdClsSpecSigElm.val().length <= 0
					|| pdClsSpecNameElm.val() == null || pdClsSpecNameElm.val().length <= 0
					|| pdClsSpecSigDtElm.val() == null || pdClsSpecSigDtElm.val().length <= 0) {
					pdClsSpecSigElm.val($("#h_currentUserMemberID").val()); // set current user memberid for signature
					pdClsSpecNameElm.val($("#h_currentUserName").val());    // set current user name for signature
					pdClsSpecSigDtElm.val(getMMDDYYYYDateStr(new Date()));  // set current date for signature
				}
				pdClsSpecTitleElm.prop("readonly", false);
				pdClsSpecTitleElm.attr("_required", true);
				pdClsSpecTitleMarker.show();
			} else {
				pdClsSpecSigElm.val("");      // clear memberid
				pdClsSpecNameElm.val("");     // clear name
				pdClsSpecSigDtElm.val("");    // clear date
				pdClsSpecTitleElm.val("");    // clear title
				pdClsSpecTitleElm.prop("readonly", true);
				pdClsSpecTitleElm.attr("_required", false);
				pdClsSpecTitleMarker.hide();
			}
		}
	});

	//------------------------------------------
	// trigger events for initial processing
	//------------------------------------------
	pdSupvCertChkElm.trigger("change");
	pdClsSpecChkElm.trigger("change");

} // end initApproveTab()


/**
 * Gets date string in MM/dd/yyyy format.
 *
 * @param inputDt - Date object
 * @return - a string for the given date in MM/dd/yyyy format.
 *           In case of error, returns empty string.
 */
function getMMDDYYYYDateStr(inputDt){
	var lsYYYY;
	var lsMM;
	var lsDD;
	var curDateValToSet = "";
	if (inputDt != null && inputDt instanceof Date) {
		lsYYYY = inputDt.getFullYear().toString();
		lsMM = (inputDt.getMonth() + 1).toString();
		if (lsMM != null && lsMM.length == 1) lsMM = "0" + lsMM;  // 0-padding for month value
		lsDD = inputDt.getDate().toString();
		if (lsDD != null && lsDD.length == 1) lsDD = "0" + lsDD;  // 0-padding for date value
		if (lsYYYY != null && lsYYYY.length == 4 && lsMM != null && lsMM.length == 2 && lsDD != null && lsDD.length == 2) {
			curDateValToSet = lsMM + "/" + lsDD + "/" + lsYYYY;
		}
	}
	return curDateValToSet;
}


/**
 * Enable/disable elements in Classification Approval tab.
 *
 * Note: This function is designed to be called within onload event handler 
 *       function of the tab page as well as from the main page to control
 *       the partial page load.
 */
function enableDisableClsfAprContent(){
	
	var pdSupvCertChkElm        = $("#PD_SUPV_CERT");               // Selecing Official approval checkbox element
	var pdSupvNameElm           = $("#PD_SUPV_NAME");               // Selecing Official name element
	var pdSupvTitleElm          = $("#PD_SUPV_TITLE");              // Selecing Official title element
	var pdSupvTitleMarker       = $("#PD_SUPV_TITLE_marker");       // Selecing Official title marker
	var pdSupvSigElm            = $("#PD_SUPV_SIG");                // Selecing Official signature element
	var pdSupvSigDtElm          = $("#PD_SUPV_SIG_DT");             // Selecing Official certification date element
	var pdClsSpecChkElm         = $("#PD_CLS_SPEC_CERT");           // Classification Specialist approval checkbox element
	var pdClsSpecNameElm        = $("#PD_CLS_SPEC_NAME");           // Classification Specialist name element
	var pdClsSpecTitleElm       = $("#PD_CLS_SPEC_TITLE");          // Classification Specialist title element
	var pdClsSpecTitleMarker    = $("#PD_CLS_SPEC_TITLE_marker");   // Classification Specialist title marker
	var pdClsSpecSigElm         = $("#PD_CLS_SPEC_SIG");            // Classification Specialist signature element
	var pdClsSpecSigDtElm       = $("#PD_CLS_SPEC_DT");             // Classification Specialist certification date element

	// make all signature name/date fields readonly
	pdSupvNameElm.prop("readonly", true);
	pdSupvSigDtElm.prop("readonly", true);
	pdClsSpecNameElm.prop("readonly", true);
	pdClsSpecSigDtElm.prop("readonly", true);

	// enable/disable approval checkbox depending on activity
	if ("Approve PD Coversheet - SO" == getActivityName()){
		pdSupvCertChkElm.prop("disabled", false);
		pdSupvCertChkElm.attr("_required", true);
		pdSupvTitleElm.prop("readonly", false);
		pdSupvTitleElm.attr("_required", true);
		//pdSupvTitleMarker.show();
		
		pdClsSpecChkElm.prop("disabled", true);
		pdClsSpecChkElm.attr("_required", false);
		pdClsSpecTitleElm.prop("readonly", true);
		pdClsSpecTitleElm.attr("_required", false);
		// Checkbox should be unchecked and disabled.  Title is also blank and readonly.  
		// So, title should not have red asterisk.
		pdClsSpecTitleMarker.hide();  
	} else if ("Approve Coversheet and Create Final Pkg" == getActivityName()){
		pdSupvCertChkElm.prop("disabled", true);
		pdSupvCertChkElm.attr("_required", false);
		pdSupvTitleElm.prop("readonly", true);
		pdSupvTitleElm.attr("_required", false);
		// Checkbox should be checked and disabled.  Title should have value and readonly.
		// So, it is unnecessary to show red-asterisk.
		pdSupvTitleMarker.hide();
		
		pdClsSpecChkElm.prop("disabled", false);
		pdClsSpecChkElm.attr("_required", true);
		pdClsSpecTitleElm.prop("readonly", false);
		pdClsSpecTitleElm.attr("_required", true);
		//pdClsSpecTitleMarker.show();
	} else {
		pdSupvCertChkElm.prop("disabled", true);
		pdSupvCertChkElm.attr("_required", false);
		pdSupvTitleElm.prop("readonly", true);
		pdSupvTitleElm.attr("_required", false);
		pdSupvTitleMarker.hide();
		
		pdClsSpecChkElm.prop("disabled", true);
		pdClsSpecChkElm.attr("_required", false);
		pdClsSpecTitleElm.prop("readonly", true);
		pdClsSpecTitleElm.attr("_required", false);
		pdClsSpecTitleMarker.hide();
	}

} // end enableDisableClsfAprContent()


/**
 * Clears Selecting Official approval fields.
 *
 * Note: This function is designed to be called when the process is returned
 *       to Selecting Official for approval of the change in the final package.
 */
function clearClassificationApprovalForModification(){
	$("#PD_SUPV_CERT").prop("checked", false);
	$("#PD_SUPV_NAME").val("");
	$("#PD_SUPV_TITLE").val("");
	$("#PD_SUPV_SIG").val("");
	$("#PD_SUPV_SIG_DT").val("");
	$("#PD_CLS_SPEC_CERT").prop("checked", false);
	$("#PD_CLS_SPEC_NAME").val("");
	$("#PD_CLS_SPEC_TITLE").val("");
	$("#PD_CLS_SPEC_SIG").val("");
	$("#PD_CLS_SPEC_DT").val("");
} // end clearClassificationApprovalForModification()
