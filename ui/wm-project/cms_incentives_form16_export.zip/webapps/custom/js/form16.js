/**
* Panel tab in PDP Incentive form.	
* Taeho Lee <thlee@bizflow.com>
* Created on March 26th, 2019
* Last Updated on April 1st, 2019
*
*/

(function (window) {
    var cms_incentives_pdp_panel = function () {
        var _readOnly = false;
        var _initialized = false;

		//---------------------------------------------------------------------
		//Panel Search Typeahead Handlers
		//---------------------------------------------------------------------
        function selectionCallBackForContactInfo(items, id) {
            var item = null;
            if (typeof items != 'undefined' && items != null) {
                if ($.isArray(items) && items.length > 0) {
                    item = items[0];
                } else {
                    item = items;
                }
            }

			if (item) {
				var data = item.lastName + ', ' + item.firstName + ' ' + item.middleName;
				if (typeof item.adminCodeDesc != 'undefined' && item.adminCodeDesc != null && item.adminCodeDesc.length > 0) {
					data += ' / ' + item.adminCodeDesc;
				}
				$("#selectedPanelNameComponent").val(data);
				$("#selectedPanelMemberName").val(item.lastName + ', ' + item.firstName + ' ' + item.middleName);
				$("#selectedPanelComponent").val(item.adminCodeDesc);				
				$("#selectedPanelHHSID").val(item.employeeID);
				$("#selectedPanelAdminCode").val(item.adminCode);
				$("#selectedPanelEmail").val(item.email);
			}
			
			try {
				$("#selectedPanelRole").focus();
			} catch (e) {
			}
        }

        function responseProcessorForContactInfo(xmlResponse) {
            var data = $('record', xmlResponse).map(function () {
                return {
                    value: $('LAST_NAME', this).text() + ', ' + $('FIRST_NAME', this).text() + ' ' +$('MIDDLE_NAME', this).text(),
                    firstName: $('FIRST_NAME', this).text(),
                    middleName: $('MIDDLE_NAME', this).text(),
                    lastName: $('LAST_NAME', this).text(),
                    email: $('EMAIL_ADDR', this).text(),
                    adminCode: $('ORG_CD', this).text(),
                    adminCodeDesc: $('ADMIN_CODE_DESC', this).text(),
                    positionTitle: $('POSITION_TITLE_NAME', this).text(),
                    payPlan: $('PAY_PLAN', this).text(),
                    series: $('SERIES', this).text(),
                    grade: $('GRADE', this).text(),
                    step: $('STEP', this).text(),
                    wgiDueDate: $('GVT_WGI_DUE_DATE', this).text(),
                    busCode: $('BUS_CD', this).text(),
                    employeeID: $('HHSID', this).text()
                };
            }).get();
            return data;
        }

        function appenderForContactInfo(item) {
            var data = item.lastName + ', ' + item.firstName + ' ' + item.middleName;
			if (typeof item.email != 'undefined' && item.email != null && item.email.length > 0) {
				data += " (" +  item.email + ")";
			}
			if (typeof item.adminCodeDesc != 'undefined' && item.adminCodeDesc != null && item.adminCodeDesc.length > 0) {
                data += ' / ' + item.adminCodeDesc;
            }
			
            return '<a role="option">' + data + '</a>';
        }
		
		//---------------------------------------------------------------------
		//Panel Table Handlers
		//---------------------------------------------------------------------

        function addNewPanel() {
			//get user input
			var panelName = $("#selectedPanelMemberName").val().trim();
			var panelComponent = $("#selectedPanelComponent").val().trim();
			var panelRole = $("#selectedPanelRole").val();
			var panelVotingStatus = $("#selectedPanelVotingStatus").val();
			var panelCompensation = $("#selectedPanelRecommendedCompensation").val();
			var PanelHHSID = $("#selectedPanelHHSID").val();
			var PanelAdminCode = $("#selectedPanelAdminCode").val();
			var PanelEmail = $("#selectedPanelEmail").val();

			//check mandatory
			if (false) {
				bootbox.alert('Please enter a valid date into the "Start Date" field, "End Date" field, make a selection from the "Work Schedule" field, and enter a "Position Title"');
				
			//check duplicate
			} else if (true == checkDuplicatePanel(panelName, PanelEmail)) {
				bootbox.alert('The panel already exists. (' + panelName + ' ) ' + PanelEmail);
				
			} else {

				var panel = {
					name: panelName
					,component: panelComponent
					,role: panelRole
					,votingStatus: panelVotingStatus
					,recCompensation: panelCompensation
					,email: PanelEmail
					,HHSID: PanelHHSID
					,adminCode: PanelAdminCode
				};
				
                var panelItems = FormState.getElementArrayValue("panelItems", []);
                panelItems.push(panel);
                FormState.updateObjectValue("panelItems", panelItems);

                drawPanels(panelItems);
				
				//reset user input !!!
				$("#selectedPanelNameComponent").val("");
				$("#selectedPanelMemberName").val("");
				$("#selectedPanelHHSID").val("");
				$("#selectedPanelAdminCode").val("");
				$("#selectedPanelEmail").val("");
				$("#selectedPanelComponent").val("");
				$("#selectedPanelRole").val("");
				$("#selectedPanelVotingStatus").val("");
				$("#selectedPanelRecommendedCompensation").val("");
				hyf.util.disableComponent("button_AddPanel");
				
				$("#panelMemberNameSearch").focus();
			}
	    }

		//Delete a selected panel member
        function deletePanelFromTable(index, target) {
			
			var panelName = "";
			if (typeof target != "undefined") {
				panelName = (target.getAttribute("panelname") == null ? "" : "(" + target.getAttribute("panelname") + ")" );
			}
			
            bootbox.confirm("Do you want to delete the member " + panelName + "?", function (result) {
                if (result) {
					var panels = FormState.getElementArrayValue("panelItems", []);
					if (index >= 0 && index < panels.length) {
						panels.splice(index, 1);
						FormState.updateObjectValue("panels", panels);
						drawPanels(panels);
					}
                }
            });
        }
		
		//For consistency, we use same method to populate table dynamically in different Incentive projects.
		//It could be improved to use different method. for instance, WebMaker BasicTable\
		//or JavaScript library like Mustache for easier template management.
		function drawPanels(panelItems) {
            var table = document.getElementById("pdpPanelTable");
            cleanPanelFromTable(table);

            var noRow = document.getElementById("pdpPanelTableNoRecordRow");
            if (panelItems.length === 0) {
                noRow.style.display = "";
            } else {
                noRow.style.display = "none";
                for (var i = 0; i < panelItems.length; i++) {
                    var panel = panelItems[i];
                    if (panel) {
                        var tr$ = $("<tr id='panel" + i +"' data_type='panelItem'></tr>");
                        tr$.append(convertPanelToHTML(panel, i));
                        $(table).append(tr$);
                    }
                }
            }

			//attach Delete Panel button event handler
            $(table).find('input.button').on('click keyup', function (e) {
                e = e || window.event;
                if (e.type === 'click' || (e.type === 'keyup' && (e.key === ' ' || e.key === 'Enter'))) {
                    var target = e.target;
                    var index = FormUtility.parseInt(target.getAttribute("deletepanelbutton_index"), -1);
                    deletePanelFromTable(index, target);
                }
            });
			
			onPanelTableChanged(panelItems);
		}

		//Generate TR HTML markup code to populate a panel row in the panel table.
        function convertPanelToHTML(panel, index) {
            var html = "<td><span class='labelBackground labelControl' tabindex='0' title='" + panel.email + "'>" + panel.name + "</span></td>";
            html += "<td><span class='labelBackground labelControl' tabindex='0' title='" + panel.adminCode + "'>" + panel.component + "</span></td>";
            html += "<td><span class='labelBackground labelControl' tabindex='0'>" + panel.role + "</span></td>";
            html += "<td><span class='labelBackground labelControl' tabindex='0'>" + panel.votingStatus + "</span></td>";
			html += "<td><span class='labelBackground labelControl' tabindex='0'>" + panel.recCompensation + "</span></td>";
            html += "<td><span class='defaultBackground buttonControl buttonPanelDelete'>";
			html += "<input type='button' class='button' deletepanelbutton_index='" + index + "' value='Delete' alt='Delete a panel " + panel.name + "' panelname='" + panel.name + "'/></span></td>";
            return html;
        }
		
		//Delete all panel rows from the panel table except headers and footer of the table.
        function cleanPanelFromTable(table) {
            var trs = table.getElementsByTagName("tr");
            if (trs) {
                for (var i = trs.length - 1; i >= 0; i--) {
                    var tr = trs[i];
                    var type = tr.getAttribute("data_type");
                    if (type && type === "panelItem") {
                        tr.parentElement.removeChild(tr);
                    }
                }
            }
        }
		
		//Check if a panel already exists in the Panel table
		function checkDuplicatePanel(panelName, panelEmail) {
			var isDuplicate = false;
			var panelItems = FormState.getElementArrayValue("panelItems", []);
			for( var i = 0; i < panelItems.length; i++){ 
				if (typeof(panelItems[i].name) != "undefined" && typeof(panelItems[i].email) != "undefined"
					&& typeof(panelName) != "undefined" && typeof(panelEmail) != "undefined") {
						
					if (panelItems[i].name == panelName && panelItems[i].email == panelEmail) {
						isDuplicate = true;
						break;
					}
				}
			}
			return isDuplicate;
		}
		
		//Reset all fields in the Panel Search group
		function initPanelSearchConditions(includeMemberSearchField) {
			if (includeMemberSearchField === true) {
				$("#panelMemberNameSearch").val("");
			}
			$("#selectedPanelNameComponent").val("");
			$("#selectedPanelMemberName").val("");
			$("#selectedPanelHHSID").val("");
			$("#selectedPanelAdminCode").val("");
			$("#selectedPanelEmail").val("");
			$("#selectedPanelComponent").val("");
			$("#selectedPanelRole").val("");
			$("#selectedPanelVotingStatus").val("");
			$("#selectedPanelRecommendedCompensation").val("");
			
			FormState.updateTextValue('panelMemberNameSearch', "", false);
			FormState.updateTextValue('selectedPanelNameComponent', "", false);
			FormState.updateTextValue('selectedPanelMemberName', "", false);
			FormState.updateTextValue('selectedPanelHHSID', "", false);
			FormState.updateTextValue('selectedPanelAdminCode', "", false);
			FormState.updateTextValue('selectedPanelEmail', "", false);
			FormState.updateTextValue('selectedPanelComponent', "", false);
			FormState.updateTextValue('selectedPanelRole', "", false);
			FormState.updateTextValue('selectedPanelVotingStatus', "", false);
			FormState.updateTextValue('selectedPanelRecommendedCompensation', "", false);
			
		}
		
		//Custom event handler whenever a new panel is added or an existing panel is removed from the table.
		function onPanelTableChanged(panelItems) {
			var numberOfPanels = panelItems.length;
			
			if (numberOfPanels < 1) {
				$("#selectPanelQuorumReached").val("");
				hyf.util.disableComponent("selectPanelQuorumReached");
				$("#selectPanelQuorumReached_label").html("Quorum Reached <br/><i>(Please add a member first)</i>");
			} else {
				
				var numberOfVotingPanels = 0;
				var panelItems = FormState.getElementArrayValue("panelItems", []);
				for( var i = 0; i < panelItems.length; i++){
					if (panelItems[i].votingStatus == "Voting") {
						numberOfVotingPanels++
					}
				}
			
				$("#selectPanelQuorumReached_label").html("Quorum Reached <br/>(" + numberOfVotingPanels + " Voting Members)");
				//TODO: if not READONLY
				hyf.util.enableComponent("selectPanelQuorumReached");
			}
		}


		//---------------------------------------------------------------------
		//Auto-calculated, Auto-populated fields
		//---------------------------------------------------------------------		
		//Panel's Recommended Annual Salary is read only
		//The field displays the sum of the textbox for the "Current Salary -GP-" field and the "PDP in the amount of" field
		//If the user makes a change to either the "Current Salary -GP-" field or the "PDP in the amount of" field then the field recalculates
		//If the user clears out the values in the "Current Salary -GP-" field and the "PDP in the amount of" field 
		//then the value from "Proposed Total Annual Compensation" field is displayed in the "Panel's Recommended Annual Salary" field
		function calculatePanelRecommendedAnnualSalary(proposedPayInfoTotalAnnualComp) {
			if (typeof proposedPayInfoTotalAnnualComp == "undefined" || proposedPayInfoTotalAnnualComp == null) {
				proposedPayInfoTotalAnnualComp = FormState.getElementValue("proposedPayInfoTotalAnnualComp");		
			}
		
			var panelCurrentSalaryGP = FormUtility.moneyToNumber($("#panelCurrentSalaryGP").val(), 0);
			var panelPDPAmount = FormUtility.moneyToNumber($("#panelPDPAmount").val(), 0);
			var total = "";
			if (0 == panelCurrentSalaryGP + panelPDPAmount) {
				total = proposedPayInfoTotalAnnualComp;
				$("#panelRecommendedAnnualSalary").prop("title", "Auto-populated with 'Proposed Total Annual Compensation' field on Details tab");
			} else {
				total = "$" + (panelCurrentSalaryGP + panelPDPAmount).format();
				$("#panelRecommendedAnnualSalary").prop("title", "");
			}
			
			FormState.updateDijitInputInner("panelRecommendedAnnualSalary", total);
		}
	

		//---------------------------------------------------------------------
		//Tab initialization handlers
		//---------------------------------------------------------------------

		//Initialize data
		function initData() {
			var panelItems = FormState.getElementArrayValue("panelItems", []);
			//remove invalid items from panel list
			for( var i = panelItems.length -1; i >= 0; i--){ 
				if ( typeof(panelItems[i].name) == "undefined") {
					panelItems.splice(i, 1); 
				}
			}
			FormState.updateObjectValue("panelItems", panelItems);
		}

		//Initialize UI components
        function initComponents() {
			
			//reset panel search group
			initPanelSearchConditions(true);
			
			//draw panel table
			var panelItems = FormState.getElementArrayValue("panelItems", []);
			drawPanels(panelItems);
			
            //init panel search typeahead - searching against HHS_HR.EMPLOYEE_LOOKUP
			//notes: it reuses ER/LR service to search panel
            FormAutoComplete.setAutoComplete(
                'panelMemberNameSearch'
                , '/bizflowwebmaker/cms_erlr_service/contactInfo.do?emp='
                , selectionCallBackForContactInfo
                , responseProcessorForContactInfo
                , appenderForContactInfo
				,{delay: 500, minLength:4}
            );
			
			//enable or disable 'Panel Current Salary'
			var checkPanelCurrentSalary = FormState.getElementValue('checkPanelCurrentSalary', "");
			if(checkPanelCurrentSalary === "true") {
				hyf.util.enableComponent("panelCurrentSalaryGP");
			} else {
				hyf.util.disableComponent("panelCurrentSalaryGP");
			}
			
			//enable or disable 'PDP in the amount of'
			var checkPanelPDPAmount = FormState.getElementValue('checkPanelPDPAmount', "");
			if(checkPanelPDPAmount === "true") {
				hyf.util.enableComponent("panelPDPAmount");
			} else {
				hyf.util.disableComponent("panelPDPAmount");
			}
			
			//init UI field by activity
			initComponentsByActivity();
			
			//init Calender icon tooltip to match the Calender text field.
			//Calender is a Dojo UI control generating the calender icon dynamically at runtime.
			//It would be safer to update the icon's tooltip (title attribute) a few seconds later after page loaded.
			setTimeout(initComponentCalendars, 2000, "partial_tab16");
        }
		
		//show or hide, enable or disable UI controls based upon activity and role
		function initComponentsByActivity() {
			
			if (activityStep.isStartNew()) {
				
				showHideLayoutGroup("group_panel_dates", false, true);
				showHideLayoutGroup("group_panelMember", false, true);
				showHideLayoutGroup("group_panel_amounts", false, true);
				$("#lbl_panel_tab_info").html("<b>This tab is not enabled to users at the 'Start New' in 'Incentives Request'</b>");
				
			} else if (activityStep.isSOReview()) {

				hyf.util.disableComponent("group_panel_dates");
				showHideLayoutGroup("group_panelMember", false, false);
				showHideLayoutGroup("group_panel_amounts", false, false);				
				/*
				var bPanelDataExist = (panelItems.length > 0);
				if (bPanelDataExist) {
					hyf.util.disableComponent("group_panelMember");
					hyf.util.disableComponent("group_panel_salaries");
					$("#pdpPanelBox .buttonPanelDelete").hide();
					
				} else {
					hyf.util.hideComponent("group_panelMember");
					hyf.util.hideComponent("group_panel_amounts_label_container");
				}

				} else if (activityStep.isHR_REVIEW_APPROVAL()) {
				*/
				
			} else if (activityStep.isSOReviewForModification()) {
				hyf.util.disableComponent("group_panel_dates");
				showHideLayoutGroup("group_panelMember", false, false);
				showHideLayoutGroup("group_panel_amounts", false, false);				
				/*
				var panelItems = FormState.getElementArrayValue("panelItems", []);
				var bPanelDataExist = (panelItems.length > 0);
				if (bPanelDataExist) {
					hyf.util.disableComponent("group_panelMember");
					hyf.util.disableComponent("group_panel_salaries");
					$("#pdpPanelBox .buttonPanelDelete").hide();
					
				} else {
					hyf.util.hideComponent("group_panelMember");
					hyf.util.hideComponent("group_panel_amounts_label_container");
				}
				*/
				
				//display return for reason -- this should be handled by main form.
				/*
				var returnReason = FormState.getElementValue("returnReason", "");
				if (returnReason !== "") {
					$("#panel_mssage_header").html("<b>" + returnReason + "</b>");
				}
				*/
				
			}
		}
		
		function initComponentCalendars(containerId) {
			
			if (typeof containerId === "undefined") {
				containerId = "";
			} else {
				containerId = "#" + containerId;
			}
			
			$(containerId + " a.datePickerIcon").each(function (index, value) {
				var txtId = $(this).prop('id').replace("_calendar_anchor", "");
				var title = $("#" + txtId).prop('title');
				if (typeof title !== null && title !== null) {
					$(this).prop("title", title);
					console.log($(this).prop('id') + " title" + '=' + title);
				}
			});
		
		}
		
        function initEventHandlers() {
            $('#button_AddPanel').on('click', function (e) {
                addNewPanel();
            });
			
            $("#panel_selection_group [panelSearchField='true']").on('change', function (e) {
                console.log("Search Condition Changed");
				var panelMemberNameSearch = $("#panelMemberNameSearch").val();
				var selectedPanelMemberName = $("#selectedPanelMemberName").val();
				var selectedPanelComponent = $("#selectedPanelComponent").val();
				var selectedPanelRole = $("#selectedPanelRole").val();
				var selectedPanelVotingStatus = $("#selectedPanelVotingStatus").val();
				var selectedPanelRecommendedCompensation = $("#selectedPanelRecommendedCompensation").val();
				if (selectedPanelMemberName == "" || selectedPanelRole == "" || selectedPanelVotingStatus == "" || selectedPanelRecommendedCompensation == "") {
					hyf.util.disableComponent("button_AddPanel");
				} else {
					hyf.util.enableComponent("button_AddPanel");
				}
            });
			
			$("#checkPanelCurrentSalary").change(function() {
				if(this.checked) {
					hyf.util.enableComponent("panelCurrentSalaryGP");
				} else {
					hyf.util.disableComponent("panelCurrentSalaryGP");
					FormState.updateDijitInputInner("panelCurrentSalaryGP", "");
					calculatePanelRecommendedAnnualSalary();
				}
			});
			
			$("#checkPanelPDPAmount").change(function() {
				if(this.checked) {
					hyf.util.enableComponent("panelPDPAmount");
				} else {
					hyf.util.disableComponent("panelPDPAmount");
					FormState.updateDijitInputInner("panelPDPAmount", "");
					calculatePanelRecommendedAnnualSalary();
				}
			});
        
			$("#group_panel_salaries .currency_mask").keypress(function(event){
				if(event.which != 8 && event.which != 46 && isNaN(String.fromCharCode(event.which))){
					event.preventDefault(); //stop character from entering input
				}
			});		
		
			$("#group_panel_dates .calendar_mask").keypress(function(event){
				if(event.which != 8 && event.which != 47 && isNaN(String.fromCharCode(event.which))){
					event.preventDefault(); //stop character from entering input
				}
			});
			
			//proposedPayInfoTotalAnnualComp
			//The field displays the sum of the textbox for the "Current Salary -GP-" field and the "PDP in the amount of" field
			//If the user makes a change to either the "Current Salary -GP-" field or the "PDP in the amount of" field then the field recalculates
			//If the user clears out the values in the "Current Salary -GP-" field and the "PDP in the amount of" field 
			//then the value from "Proposed Total Annual Compensation" field on Details tab is displayed
			$('#panelCurrentSalaryGP').keyup(function (e) {
				calculatePanelRecommendedAnnualSalary();
			});			

			$('#panelPDPAmount').keyup('change', function (e) {
				calculatePanelRecommendedAnnualSalary();
			});
			
			//TODO:Subscribe events to monitor 
			//proposedPayInfoTotalAnnualComp in Details tab
		}

        function postDisableTab(afterAllTabLoaded, tab) {
        //     if (afterAllTabLoaded) {
        //         if (activityStep.isSOReview()) {
        //             if (tab.readOnly) {
        //                 hyf.util.enableComponent("numOfInterviewed");
        //             }
        //         }
        //     }
        }
		
        function init(readOnly, tabObject) {
            _readOnly = readOnly;
			
			initData();
            initComponents();
            initEventHandlers();
            
			FormMain.resetMandatoryMark(tabObject);

            _initialized = true;
        }

        function render(action) {
			console.log("cms_incentives_pdp_panel.render");
        }
		
		//Notes:
		//Using RENDERER is better design than creating individual event handler, and call it from different tabs.
		//Since it requires unnecessary interaction among modules.
		//But for consistency of Incentive form implementation, tt uses the existing design.
		function onIncentiveTypeChanged(newIncentiveType) {
			//clear all field values
			
		}
		
		function onProposedPayInfoTotalAnnualCompChanged(newAmount) {
			console.log("proposedPayInfoTotalAnnualComp=" + newAmount);
			calculatePanelRecommendedAnnualSalary(newAmount);
		}
		
		//---------------------------------------------------------------------
		//Utility functions
		//---------------------------------------------------------------------
		
		// Clears fields of a group on a tab.
		// @param groupId - element id of the group layout (div tag)
		// TODO: promote it to main or common code.
		function clearGroupContent(groupId) {

			// TEXTBOX
			$.each($('#' + groupId + ' input.textbox'), function (index, value) {
				var value = $(this).val();
				if (value && value.length > 0) {
					$(this).val('');
					FormState.updateTextValue($(this)[0].id, '', false);
				}
			});

			// TEXTAREA
			$.each($('#' + groupId + ' textarea'), function (i, v) {
				var value = $(this).val();
				if (value && value.length > 0) {
					$(this).val('');
					FormState.updateTextValue($(this)[0].id, '', false);
				}
			});

			// CHECKBOX
			$.each($('#' + groupId + ' input[type=checkbox]'), function (i, v) {
				$(this).prop('checked', false);
				var value = $(this).val();
				if (value && value.length > 0) {
					$(this).trigger('change');
				}
			});
			$.each($('#' + groupId + ' input.checkbox'), function (i, v) {
				var value = $(this).prop('checked');
				if (value === true) {
					$(this).prop('checked', false);
					$(this).trigger('change');
				}
			});

			// SELECT
			$.each($('#' + groupId + ' select'), function (i, v) {
				var value = $(this).val();
				if (value && value.length > 0) {
					$(this).val('');
					$(this).trigger('change');
					
				}
			});
			
			// OUTPUT
			$.each($('#' + groupId + ' span.output'), function (i, v) {
				var value = $(this).text();
				if (value && value.length > 0) {
					$(this).text('');
					FormState.updateTextValue($(this)[0].id, '', false);
				}
			});

			// HIDDEN
            $.each($('#' + groupId + ' input[type=hidden]'), function (index, value) {
                var value = $(this).val();
                if (value && value.length > 0) {
                    $(this).val('');
                    FormState.updateTextValue($(this)[0].id, '', false);
                }
            });

			// SELECTED - READONLY
            $('#'+groupId+'  ul.autocomplete_ul li img').trigger("click");
			// $.each($('#' + groupId + ' ul.autocomplete_ul li'), function (i, v) {
			// 	// remove elements created by autocomplete selection
			// 	$(this).remove();
			// });
		}
		
		// Show or hide a group and clear fields in the group
		// @groupId: unique group id
		// @isVisible: [true | false] true: show the group, false: hide the group
		// @clearWhenToHide: [true | false] true: clear the group if @isVisible == true
		// TODO: promote it to main or common code.		
		function showHideLayoutGroup(groupId, isVisible, clearWhenToHide) {
			if (isVisible === true) {
				hyf.util.showComponent(groupId+'_label_container');
                hyf.util.showComponent(groupId);
			} else {
				if (clearWhenToHide !== false) {
					// unless specifically set false, clear content when hiding
                    if($('#'+groupId).css('display') !== 'none'){
                        clearGroupContent(groupId);
                    }
				}
                hyf.util.hideComponent(groupId+'_label_container');
				hyf.util.hideComponent(groupId);
			}
		}		
		
		
		//---------------------------------------------------------------------
		//Expose interfaces to external
		//---------------------------------------------------------------------
        return {
            init: init
            ,render: render
            ,onIncentiveTypeChanged: onIncentiveTypeChanged
            ,onProposedPayInfoTotalAnnualCompChanged: onProposedPayInfoTotalAnnualCompChanged
            ,postDisableTab: postDisableTab
        }
    };

    var _initializer = window.cms_incentives_pdp_panel || (window.cms_incentives_pdp_panel = cms_incentives_pdp_panel());
})(window);
