(function (window) {
    var cms_incentives_pdp_panel = function () {
        var _readOnly = false;
        var _initialized = false;
        var _dutyStation_ac = null;
		var _panelMember_ac = null;

		function drawPanels(panelItems) {
            var table = document.getElementById("pdpPanelTable");
            cleanPanelFromTable(table);

            var noRow = document.getElementById("pdpPanelTableNoRecordRow");
            if (panelItems.length === 0) {
                noRow.style.display = "";
            } else {
                noRow.style.display = "none";
                for (var i = 0; i < panelItems.length; i++) {
                    var panel = panelItems[i];
                    if (panel) {
                        var tr$ = $("<tr id='panel" + i +"' data_type='panelItem'></tr>");
                        tr$.append(convertPanelToHTML(panel, i));
                        $(table).append(tr$);
                    }
                }
            }

			//attach Delete Panel button event handler
            $(table).find('input.button').on('click keyup', function (e) {
                e = e || window.event;
                if (e.type === 'click' || (e.type === 'keyup' && (e.key === ' ' || e.key === 'Enter'))) {
                    var target = e.target;
                    var index = FormUtility.parseInt(target.getAttribute("deletepanelbutton_index"), -1);
                    deletePanelFromTable(index);
                }
            });
			
			onPanelTableChanged(panelItems);
		}
		
        function cleanPanelFromTable(table) {
            var trs = table.getElementsByTagName("tr");
            if (trs) {
                for (var i = trs.length - 1; i >= 0; i--) {
                    var tr = trs[i];
                    var type = tr.getAttribute("data_type");
                    if (type && type === "panelItem") {
                        tr.parentElement.removeChild(tr);
                    }
                }
            }
        }
		
        function convertPanelToHTML(panel, index) {
            var html = "<td style='vertical-align:middle'><span class='labelBackground labelControl' title='" + panel.email + "'>" + panel.name + "</span></td>";
            html += "<td style='vertical-align:middle'><span class='labelBackground labelControl' title='" + panel.adminCode + "'>" + panel.component + "</span></td>";
            html += "<td style='vertical-align:middle'><span class='labelBackground labelControl'>" + panel.role + "</span></td>";
            html += "<td style='vertical-align:middle'><span class='labelBackground labelControl'>" + panel.votingStatus + "</span></td>";
			html += "<td style='vertical-align:middle'><span class='labelBackground labelControl'>" + panel.recCompensation + "</span></td>";
            html += "<td style='vertical-align:middle'><span class='defaultBackground buttonControl'><input type='button' class='button' deletepanelbutton_index='" + index + "' value='Delete' alt='Delete a panel'/></span></td>";
            return html;
        }
		
        function deletePanelFromTable(index) {
            bootbox.confirm('Do you want to delete the member?', function (result) {
                if (result) {
					var panels = FormState.getElementArrayValue("panelItems", []);
					if (index >= 0 && index < panels.length) {
						panels.splice(index, 1);
						FormState.updateObjectValue("panels", panels);
						drawPanels(panels);
					}
                }
            });
        }
		
        function addNewPanel() {
			//get user input
			var panelName = $("#selectedPanelMemberName").val().trim();
			var panelComponent = $("#selectedPanelComponent").val().trim();
			var panelRole = $("#selectedPanelRole").val();
			var panelVotingStatus = $("#selectedPanelVotingStatus").val();
			var panelCompensation = $("#selectedPanelRecommendedCompensation").val();
			var PanelHHSID = $("#selectedPanelHHSID").val();
			var PanelAdminCode = $("#selectedPanelAdminCode").val();
			var PanelEmail = $("#selectedPanelEmail").val();

			//check mandatory
			if (false) {
				bootbox.alert('Please enter a valid date into the "Start Date" field, "End Date" field, make a selection from the "Work Schedule" field, and enter a "Position Title"');
				
			//check duplicate
			} else if (true == checkDuplicatePanel(panelName, PanelEmail)) {
				bootbox.alert('The panel already exists. (' + panelName + ' ) ' + PanelEmail);
				
			} else {

				var panel = {
					name: panelName
					,component: panelComponent
					,role: panelRole
					,votingStatus: panelVotingStatus
					,recCompensation: panelCompensation
					,email: PanelEmail
					,HHSID: PanelHHSID
					,adminCode: PanelAdminCode
				};
				
                var panelItems = FormState.getElementArrayValue("panelItems", []);
                panelItems.push(panel);
                FormState.updateObjectValue("panelItems", panelItems);

                drawPanels(panelItems);
				
				//reset user input !!!
				$("#selectedPanelNameComponent").val("");
				$("#selectedPanelMemberName").val("");
				$("#selectedPanelHHSID").val("");
				$("#selectedPanelAdminCode").val("");
				$("#selectedPanelEmail").val("");
				$("#selectedPanelComponent").val("");
				$("#selectedPanelRole").val("");
				$("#selectedPanelVotingStatus").val("");
				$("#selectedPanelRecommendedCompensation").val("");
				hyf.util.disableComponent("button_AddPanel");
			}
	    }
		
		function checkDuplicatePanel(panelName, panelEmail) {
			var isDuplicate = false;
			var panelItems = FormState.getElementArrayValue("panelItems", []);
			for( var i = 0; i < panelItems.length; i++){ 
				if (typeof(panelItems[i].name) != "undefined" && typeof(panelItems[i].email) != "undefined"
					&& typeof(panelName) != "undefined" && typeof(panelEmail) != "undefined") {
						
					if (panelItems[i].name == panelName && panelItems[i].email == panelEmail) {
						isDuplicate = true;
						break;
					}
				}
			}
			return isDuplicate;
		}
		
		function resetMemberSearchConditions(includeMemberSearchField) {
			if (includeMemberSearchField === true) {
				$("#panelMemberNameSearch").val("");
			}
			$("#selectedPanelNameComponent").val("");
			$("#selectedPanelMemberName").val("");
			$("#selectedPanelHHSID").val("");
			$("#selectedPanelAdminCode").val("");
			$("#selectedPanelEmail").val("");
			$("#selectedPanelComponent").val("");
			$("#selectedPanelRole").val("");
			$("#selectedPanelVotingStatus").val("");
			$("#selectedPanelRecommendedCompensation").val("");
			
			FormState.updateTextValue('panelMemberNameSearch', "", false);
			FormState.updateTextValue('selectedPanelNameComponent', "", false);
			FormState.updateTextValue('selectedPanelMemberName', "", false);
			FormState.updateTextValue('selectedPanelHHSID', "", false);
			FormState.updateTextValue('selectedPanelAdminCode', "", false);
			FormState.updateTextValue('selectedPanelEmail', "", false);
			FormState.updateTextValue('selectedPanelComponent', "", false);
			FormState.updateTextValue('selectedPanelRole', "", false);
			FormState.updateTextValue('selectedPanelVotingStatus', "", false);
			FormState.updateTextValue('selectedPanelRecommendedCompensation', "", false);
			
		}
		
		function onPanelTableChanged(panelItems) {
			var numberOfPanels = panelItems.length;
			
			if (numberOfPanels < 1) {
				$("#selectPanelQuorumReached").val("");
				hyf.util.disableComponent("selectPanelQuorumReached");
				$("#selectPanelQuorumReached_label").html("Quorum Reached <br/><i>(Please add a member first)</i>");
			} else {
				$("#selectPanelQuorumReached_label").html("Quorum Reached <br/>(" + numberOfPanels + " Voting Members)");
				//TODO: if not READONLY
				hyf.util.enableComponent("selectPanelQuorumReached");
			}
		}
		
        function initEventHandlers() {
            $('#button_AddPanel').on('click', function (e) {
                addNewPanel();
            });
			
            $("#panel_selection_group [panelSearchField='true']").on('change', function (e) {
                console.log("Search Condition Changed");
				var panelMemberNameSearch = $("#panelMemberNameSearch").val();
				var selectedPanelMemberName = $("#selectedPanelMemberName").val();
				var selectedPanelComponent = $("#selectedPanelComponent").val();
				var selectedPanelRole = $("#selectedPanelRole").val();
				var selectedPanelVotingStatus = $("#selectedPanelVotingStatus").val();
				var selectedPanelRecommendedCompensation = $("#selectedPanelRecommendedCompensation").val();
				if (selectedPanelMemberName == "" || selectedPanelRole == "" || selectedPanelVotingStatus == "" || selectedPanelRecommendedCompensation == "") {
					hyf.util.disableComponent("button_AddPanel");
				} else {
					hyf.util.enableComponent("button_AddPanel");
				}
            });
			
			$("#checkPanelCurrentSalary").change(function() {
				if(this.checked) {
					hyf.util.enableComponent("currentPanelSalary");
				} else {
					hyf.util.disableComponent("currentPanelSalary");
					$("#currentPanelSalary").val("");
				}
			});
			
			$("#checkPanelPDPAmount").change(function() {
				if(this.checked) {
					hyf.util.enableComponent("panelPDPAmount");
				} else {
					hyf.util.disableComponent("panelPDPAmount");
					$("#panelPDPAmount").val("");
				}
			});
        
			$("#group_panel_salaries .currency_mask").keypress(function(event){
				if(event.which != 8 && event.which != 46 && isNaN(String.fromCharCode(event.which))){
					event.preventDefault(); //stop character from entering input
				}
			});		
		
			$("#panel_dates_group .calendar_mask").keypress(function(event){
				if(event.which != 8 && event.which != 47 && isNaN(String.fromCharCode(event.which))){
					event.preventDefault(); //stop character from entering input
				}
			});		
		}
		
        function initComponents() {
            var incentiveType = FormState.getElementValue('incentiveType', "");
            //FormMain.setTabVisibility(incentiveType, FormState.getElementValue("candiAgreeRenewal"));

			var panelItems = FormState.getElementArrayValue("panelItems", []);
			drawPanels(panelItems);
			
            //Search a member from Employee Lookup
            FormAutoComplete.setAutoComplete(
                'panelMemberNameSearch'
                , '/bizflowwebmaker/cms_erlr_service/contactInfo.do?emp='
                , selectionCallBackForContactInfo
                , responseProcessorForContactInfo
                , appenderForContactInfo
            );
			
			if($('#checkPanelCurrentSalary').prop('checked')) {
				hyf.util.enableComponent("currentPanelSalary");
			} else {
				hyf.util.disableComponent("currentPanelSalary");
			}

			if($("#checkPanelPDPAmount").prop('checked')) {
				hyf.util.enableComponent("panelPDPAmount");
			} else {
				hyf.util.disableComponent("panelPDPAmount");
			}
						
        }

        function selectionCallBackForContactInfo(items, id) {
            var item = null;
            if (typeof items != 'undefined' && items != null) {
                if ($.isArray(items) && items.length > 0) {
                    item = items[0];
                } else {
                    item = items;
                }
            }

			if (item) {
				var data = item.lastName + ', ' + item.firstName + ' ' + item.middleName;
				if (typeof item.adminCodeDesc != 'undefined' && item.adminCodeDesc != null && item.adminCodeDesc.length > 0) {
					data += ' - ' + item.adminCodeDesc;
				}
				$("#selectedPanelNameComponent").val(data);
				$("#selectedPanelMemberName").val(item.lastName + ', ' + item.firstName + ' ' + item.middleName);
				$("#selectedPanelComponent").val(item.adminCodeDesc);				
				$("#selectedPanelHHSID").val(item.employeeID);
				$("#selectedPanelAdminCode").val(item.adminCode);
				$("#selectedPanelEmail").val(item.email);
			}
			
			try {
				$("#selectedPanelRole").focus();
			} catch (e) {
			}
        }

        function responseProcessorForContactInfo(xmlResponse) {
            var data = $('record', xmlResponse).map(function () {
                return {
                    value: $('LAST_NAME', this).text() + ', ' + $('FIRST_NAME', this).text() + ' ' +$('MIDDLE_NAME', this).text(),
                    firstName: $('FIRST_NAME', this).text(),
                    middleName: $('MIDDLE_NAME', this).text(),
                    lastName: $('LAST_NAME', this).text(),
                    email: $('EMAIL_ADDR', this).text(),
                    adminCode: $('ORG_CD', this).text(),
                    adminCodeDesc: $('ADMIN_CODE_DESC', this).text(),
                    positionTitle: $('POSITION_TITLE_NAME', this).text(),
                    payPlan: $('PAY_PLAN', this).text(),
                    series: $('SERIES', this).text(),
                    grade: $('GRADE', this).text(),
                    step: $('STEP', this).text(),
                    wgiDueDate: $('GVT_WGI_DUE_DATE', this).text(),
                    busCode: $('BUS_CD', this).text(),
                    employeeID: $('HHSID', this).text()
                };
            }).get();
            return data;
        }

        function appenderForContactInfo(item) {
            var data = item.lastName + ', ' + item.firstName + ' ' + item.middleName;
            if (typeof item.adminCodeDesc != 'undefined' && item.adminCodeDesc != null && item.adminCodeDesc.length > 0) {
                data += ' - ' + item.adminCodeDesc;
            }
            return '<a role="option">' + data + '</a>';
        }
		
        function postDisableTab(afterAllTabLoaded, tab) {
        //     if (afterAllTabLoaded) {
        //         if (activityStep.isSOReview()) {
        //             if (tab.readOnly) {
        //                 hyf.util.enableComponent("numOfInterviewed");
        //             }
        //         }
        //     }
        }
		
		function initData() {
			var panelItems = FormState.getElementArrayValue("panelItems", []);
			for( var i = panelItems.length -1; i >= 0; i--){ 
				if ( typeof(panelItems[i].name) == "undefined") {
					panelItems.splice(i, 1); 
				}
			}
			FormState.updateObjectValue("panelItems", panelItems);
			
			resetMemberSearchConditions(true);
		}
		
        function init(readOnly, tabObject) {
            _readOnly = readOnly;
			
			initData();
            initComponents();
            initEventHandlers();
            
			FormMain.resetMandatoryMark(tabObject);

            _initialized = true;
        }

        function render(action) {
        }

        return {
            init: init
            ,render: render
            // populateRelatedFields: populateRelatedFields,
            // onIncentiveTypeChange: onIncentiveTypeChanged,
            ,postDisableTab: postDisableTab
        }
    };

    var _initializer = window.cms_incentives_pdp_panel || (window.cms_incentives_pdp_panel = cms_incentives_pdp_panel());
})(window);
