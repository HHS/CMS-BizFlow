
(function (window) {
    var cms_meddoc = function () {
	
		var initialized = false;
		var fmlaDisaprvReasonDropdown = null;
		
		
		var dateFieldsPastPresent = 
		[
			'MD_DOC_SBMT_DT',
			'MD_FMLA_BEGIN_DT'
		];
		
		var dateFieldsPresentFuture = 
		[
		];
		
		var reqFieldForActivity = 
		[
			{
				actName: globalVars.actAll,
				reqFieldIds: 
				[
				]
			},
			{
				actName: globalVars.actCaseCreation,
				reqFieldIds: 
				[
				]
			},
			{
				actName: globalVars.actCaseComplete,
				reqFieldIds: 
				[
					'MD_REQUEST_REASON',
					'MD_DOC_SBMT_DT',
					'MD_FMLA_APROVED',
					'MD_FMLA_DISAPRV_REASON',
					'MD_FMLA_GRIEVANCE'
				]
			}
		];
		
		
		
		function controlRequestReasonVisibility() {
			var requestReasonVal = FormState.getElementValue('MD_REQUEST_REASON');
			var requestReasonTxt = '';
			if (typeof requestReasonVal != 'undefined' && requestReasonVal != null && requestReasonVal.length > 0) {
				requestReasonTxt = $('#MD_REQUEST_REASON option[value="' + requestReasonVal + '"]').text();
			}
			CommonOpUtil.showHideLayoutGroup('md_reason_fmla_group', (requestReasonTxt === 'FMLA'));
			CommonOpUtil.showHideLayoutGroup('md_reason_non_fmla_group', (requestReasonTxt === 'Conduct Related' || requestReasonTxt === 'Health & Safety Concerns')); 
		}
		
		function controlFmlaApprovedVisibility() {
			var fmlaApprovedVal = FormState.getElementValue('MD_FMLA_APROVED');
			CommonOpUtil.showHideLayoutGroup('md_fmla_reason_group', (fmlaApprovedVal === 'No'));
			CommonOpUtil.showHideLayoutGroup('md_fmla_appeal_group', (fmlaApprovedVal === 'No'));
		}
		
		function controlFmlaGrievanceVisibility() {
			var fmlaGrievanceVal = FormState.getElementValue('MD_FMLA_GRIEVANCE');
			CommonOpUtil.showHideLayoutGroup('md_fmla_grievance_note_group', (fmlaGrievanceVal === 'Yes'));
		}
		
		
		function initVisibility() {
			//FormState.updateTextValue('MD_FMLA_GRIEVANCE_NOTE', 'Note: Please Start a Grievance Case.');
		}
		
		
		
		
		function controlEnableDisable() {
			
		}
		
		
		
		
		function initEventHandlers() {
			
		}
		
		
		
		
		function setupCustomWidget() {
			var activityName = ActivityManager.getActivityName();
			
			// set up FMLA Disapproval Reason dropdown as multi-select widget
			var fmlaDisaprvReasonMinSelection = (activityName === 'Complete Case') ? 1 : 0;
			var fmlaDisaprvReasonInitialData = [];
			var fmlaDisaprvReasonIdString = FormState.getElementValue('MD_FMLA_DISAPRV_REASON');
			var fmlaDisaprvReasonIds = ((fmlaDisaprvReasonIdString != null && fmlaDisaprvReasonIdString.length > 0) ? fmlaDisaprvReasonIdString.split(',') : []);
			var count = fmlaDisaprvReasonIds.length;
			for (var index = 0; index < count; index++) {
				var itemLabel = $('#MD_FMLA_DISAPRV_REASON_SEL option[value="' + fmlaDisaprvReasonIds[index] + '"]').text();
				fmlaDisaprvReasonInitialData.push({
					id: fmlaDisaprvReasonIds[index],
					label: itemLabel
				});
			}
			var fmlaDisaprvReasonDropdownOption = {
				id: 'MD_FMLA_DISAPRV_REASON',
				tabindex: 0,
				minSelectionCount: fmlaDisaprvReasonMinSelection,
				maxSelectionCount: 7, 
				getSelectionLabel: function(item) {
					return item.label
				},
				getItemID: function(item) {
					return item.id;
				},
				initialItems: fmlaDisaprvReasonInitialData,
				setDataToForm: function(values) {
					if (typeof values == 'undefined') return;
					var selectedIds = '';
					if (values != null && $.isArray(values)) {
						selectedIds = values.reduce(function(accumulator, currentValue, currentIndex, array) {
							return (accumulator && accumulator.length > 0) ? accumulator + ',' + currentValue.id : currentValue.id;
						}, '');
					}
					FormState.updateObjectValue('MD_FMLA_DISAPRV_REASON', selectedIds);
				}
			};
			fmlaDisaprvReasonDropdown = MultiSelectDropdown.setupMultiSelectDropdown(fmlaDisaprvReasonDropdownOption);
		}
		
		
		
		
		// Clear data for all custom widget in the tab.
		// Note: This function will be called by the main tab when subsequent tabs are 
		function clearAllContentCustom() {
			
		}
		
		
		
		
		function init() {
			
			//-----------------------------------
			// visibility configuration
			//-----------------------------------
			initVisibility();
			
			//-----------------------------------
			// enable/disable configuration
			//-----------------------------------
			controlEnableDisable();
			
			//-----------------------------------
			// validation configuration
			//-----------------------------------
			dateFieldsPastPresent.forEach(function(item){
				hyf.calendar.setDateConstraint(item, 'Maximum', 'Today');
			});
			//dateFieldsPresentFuture.forEach(function(item){
			//	hyf.calendar.setDateConstraint(item, 'Minimum', 'Today');
			//});
			CommonOpUtil.dynamicMandatory(reqFieldForActivity);
			
			
			//-----------------------------------
			// event handler configuration
			//-----------------------------------
			initEventHandlers();
			
			
			//-----------------------------------
			// custom ui element initialization
			//-----------------------------------
			setupCustomWidget();
		}
		
		// manage data population and display of read-only fields and disabled fields since they cannot be controlled by event handler
		function render() {
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_meddoc::render START');
			
			var mdRequestReasonState = FormState.getState('MD_REQUEST_REASON');
			if (mdRequestReasonState && mdRequestReasonState.dirty) {
				controlRequestReasonVisibility();
			}
			
			var fmlaApprovedState = FormState.getState('MD_FMLA_APROVED');
			if (fmlaApprovedState && fmlaApprovedState.dirty) {
				controlFmlaApprovedVisibility();
			}
			
			var fmlaGrievanceState = FormState.getState('MD_FMLA_GRIEVANCE');
			if (fmlaGrievanceState && fmlaGrievanceState.dirty) {
				controlFmlaGrievanceVisibility();
			}
			
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_meddoc::render END');
		}
		
		
		return {
			initialized: initialized,
			reqFieldForActivity: reqFieldForActivity,
			clearAllContentCustom: clearAllContentCustom,
			render: render,
			init: init
		};
	};

    var _initializer = window.cms_meddoc || (window.cms_meddoc = cms_meddoc());
})(window);
