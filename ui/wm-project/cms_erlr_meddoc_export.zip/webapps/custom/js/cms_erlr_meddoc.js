
(function (window) {
    var cms_meddoc = function () {
	
		var initialized = false;
		
		
		var dateFieldsPastPresent = 
		[
		];
		
		var dateFieldsPresentFuture = 
		[
		];
		
		var reqFieldForActivity = 
		[
			{
				actName: globalVars.actAll,
				reqFieldIds: 
				[
				]
			},
			{
				actName: globalVars.actCaseCreation,
				reqFieldIds: 
				[
				]
			},
			{
				actName: globalVars.actCaseComplete,
				reqFieldIds: 
				[
				]
			}
		];
		
		
		function initVisibility() {
			
		}
		
		
		
		
		function controlEnableDisable() {
			
		}
		
		
		
		
		function initEventHandlers() {
			
		}
		
		
		
		
		function setupCustomWidget() {
			
		}
		
		
		
		
		// Clear data for all custom widget in the tab.
		// Note: This function will be called by the main tab when subsequent tabs are 
		function clearAllContentCustom() {
			
		}
		
		
		
		
		function init() {
			
			//-----------------------------------
			// visibility configuration
			//-----------------------------------
			initVisibility();
			
			//-----------------------------------
			// enable/disable configuration
			//-----------------------------------
			controlEnableDisable();
			
			//-----------------------------------
			// validation configuration
			//-----------------------------------
			dateFieldsPastPresent.forEach(function(item){
				hyf.calendar.setDateConstraint(item, 'Maximum', 'Today');
			});
			//dateFieldsPresentFuture.forEach(function(item){
			//	hyf.calendar.setDateConstraint(item, 'Minimum', 'Today');
			//});
			CommonOpUtil.dynamicMandatory(reqFieldForActivity);
			
			
			//-----------------------------------
			// event handler configuration
			//-----------------------------------
			initEventHandlers();
			
			
			//-----------------------------------
			// custom ui element initialization
			//-----------------------------------
			setupCustomWidget();
		}
		
		// manage data population and display of read-only fields and disabled fields since they cannot be controlled by event handler
		function render() {
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_meddoc::render START');
			
			
			
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'cms_meddoc::render END');
		}
		
		
		return {
			initialized: initialized,
			reqFieldForActivity: reqFieldForActivity,
			clearAllContentCustom: clearAllContentCustom,
			render: render,
			init: init
		};
	};

    var _initializer = window.cms_meddoc || (window.cms_meddoc = cms_meddoc());
})(window);
