var cms_main_tab2 = {
    initialized: false,
    init: function () {
        //implementation of initialization logic
    },
    render: function () {
        //implementation of tab specific logic
    }
};