var PerformanceIssue = {
    initialized: false,
	layout_group: ['action_PI_Counseling_group', 'PI_PIP_group',
	'action_PI_WrittenNarrativeReview_group', 'PI_counseling_grievance_decision_note_group',
	,'action_PI_PIP_group','action_PI_Demotion_group','PI_Oral_pres_request_group','PI_written_resp_group'
	,'oral_presentation_date_group','written_response_group',
	'start_grievance_case_note','PIP_written_response_group',
	'PIP_oral_presn_group','PIP_succ_complete_rsn_group','pip_end_prior_to_plan','action_PI_Reassignment_group',
	'PI_removal_notice_group','PI_removal_oral_prezn_group','PI_removal_written_resp_group','action_PI_Removal_group'],
	dateFields :['PI_dt_wrtn_narrative_reviewed','PIP_start_dt','PIP_end_dt',
				'PIP_emp_notified','ext_pip_end_dt','actual_pip_dt','PMAP_signature',
				'PIP_oral_prop_dt','PIP_oral_pres_dt','PIP_dt_written_submit','PIP_written_resp_due',
				'PIP_final_agency_dt','PIP_decision_issued_dt','PIP_eff_action_dt','PI_proposed_action_dt',
				'PI_oral_pres_dt','PI_resp_due','PI_written_resp_submit_dt','PI_decision_dt',
				'PI_reassignment_notice_dt','PI_reassignment_eff_dt','PI_removal_ntc_end_dt',
				'PI_removal_ntc_start_dt','PI_removal_oral_prezn_dt','PI_removal_written_resp_submit_dt',
				'PI_removal_eff_dt','PI_removal_decision_issue_dt','PI_removal_prop_action_dt','PI_date_mngr_issued_review'
				,'PI_performance_counseling_issued_date','PI_removal_written_resp_due'],
    init: function () {     
        PerformanceIssue.layout_group.forEach(function(el,index){
            hyf.util.hideComponent(el);
        });
		PerformanceIssue.dateFields.forEach(function(el){
			hyf.calendar.setDateConstraint(el, 'Maximum', 'Today');
		});
		$('#PI_PIP_add_dte_btn').on('click',addDate);
    },
    render: function (){
        var actionType = FormState.getState('PI_action_type');
		var grievanceDecision = FormState.getState('PI_counseling_grievance_decision');
		var oral_presentation = FormState.getState('PIP_oral_pres_resq');
		var demotion_oral_presentation = FormState.getState('PI_oral_Request');
		var demotion_written_response = FormState.getState('PI_written_resp');
		var written_response_requested = FormState.getState('PIP_written_resp_submit');
		var PIP_end_prior = FormState.getState('PIP_end_prior');
		var PIP_succ_complete_rsn_group = FormState.getState('PIP_succ_completed');
		var employee_notice_leave_placed = FormState.getState('PI_emp_notice_resp');
		var removal_oral_presentaion_requested = FormState.getState('PI_removal_oral_prezn');
		var removal_written_response = FormState.getState('PI_removal_resp_submit');
		var emp = FormState.getState('empContact');
		var pip_grievance_note = FormState.getState('PIP_grievance');
		if(grievanceDecision && grievanceDecision.dirty){
			if(grievanceDecision.value === 'Y'){								
                hyf.util.showComponent('PI_counseling_grievance_decision_note_group');                
            }
			else{
				hyf.util.hideComponent('PI_counseling_grievance_decision_note_group');                
			}
		}
		if((emp && emp.dirty)){
			PI_populateCurrentPosition(emp.value);		
		}		
		if(actionType && actionType.dirty){
			showCaseView('action_PI_'+actionType.value.replace(/\s/g,'')+'_group',PerformanceIssue.layout_group);
        }
		if(oral_presentation && oral_presentation.dirty){
			hyfShowOrHide(oral_presentation,'PIP_oral_presn_group');
		}
		if(pip_grievance_note && pip_grievance_note.dirty){
			hyfShowOrHide(pip_grievance_note,'start_grievance_case_note');
		}
		if(demotion_oral_presentation && demotion_oral_presentation.dirty){
			hyfShowOrHide(demotion_oral_presentation,'PI_Oral_pres_request_group');
		}
		if(written_response_requested && written_response_requested.dirty){
			hyfShowOrHide(written_response_requested,'PIP_written_response_group');
		}
		if(PIP_end_prior && PIP_end_prior.dirty){
			hyfShowOrHide(PIP_end_prior,'pip_end_prior_to_plan');
		}
		if(PIP_succ_complete_rsn_group && PIP_succ_complete_rsn_group.dirty){
			hyfShowOrHide(PIP_succ_complete_rsn_group,'PIP_succ_complete_rsn_group');
		}
		if(demotion_written_response && demotion_written_response.dirty){
			hyfShowOrHide(demotion_written_response,'PI_written_resp_group');
		}
		if(employee_notice_leave_placed && employee_notice_leave_placed.dirty){
			hyfShowOrHide(employee_notice_leave_placed,'PI_removal_notice_group');
		}
		if(removal_written_response && removal_written_response.dirty){
			hyfShowOrHide(removal_written_response,'PI_removal_written_resp_group');
		}
		if(removal_oral_presentaion_requested && removal_oral_presentaion_requested.dirty){
			hyfShowOrHide(removal_oral_presentaion_requested,'PI_removal_oral_prezn_group');
		}
		if(!PerformanceIssue.initialized){
			FormAutoComplete.setAutoComplete('PIP_deciding_official','/bizflowwebmaker/erlr_AutoCompleteService/contactInfo.do?cust=',populateOfficial,responseMapper,appendInfo);
			FormAutoComplete.setAutoComplete('PI_demotion_official','/bizflowwebmaker/erlr_AutoCompleteService/contactInfo.do?cust=',populateOfficial,responseMapper,appendInfo);
			FormAutoComplete.setAutoComplete('PI_removal_official','/bizflowwebmaker/erlr_AutoCompleteService/contactInfo.do?cust=',populateOfficial,responseMapper,appendInfo);
			FormAutoComplete.setAutoComplete('PI_reassignment_final_code','/bizflowwebmaker/erlr_AutoCompleteService/contactInfo.do?admin=',populateAdminCode,adminCodeResponseMapper,appendAdminCode);
			dynamicMandatory('CompleteCase')
            PerformanceIssue.initialized = true;
		}
    }
};
function addDate(e){
	var hidden ='',selectionId= '',selected ='',date ='';
	var target = e.target ? e.target.id : e.id;
	if(target){
		if(target === 'PI_PIP_add_dte_btn'){
			hidden = 'pip_ext_dt_hidden';
			selectionId = 'pip_ext_dt';
			date =$('#ext_pip_end_dt').val();
			selected = e.value ? e.value: $('#' + hidden).val();
		}
	}		
		if( selected !=='' && selected.indexOf(',') > -1){
			var arr = selected.split(',');
			arr.push(date);
			var tempArr =[];
			arr.forEach(function(el){
				if($.inArray(el,tempArr)=== -1 && el !==''){
					tempArr.push(el);
				}
			});
			arr = null;
			$('#' + selectionId).html('');
			tempArr.forEach(function(el){
				$('#'+selectionId).append('<label id="'+el.replace(/\//g,'')+'"><span" onclick="removeItem('+el.replace(/\//g,'')+')" title="Remove date."><a href="#" style="color:red;padding:5px; onclick="onclick="removeItem('+date.replace(/\//g,'')+')">X</a></span>'+el+'</label><br/>');
			});
		$('#'+hidden).val(tempArr.join());
		FormState.doActionNoRender(StateAction.changeText(hidden,tempArr.join()));			
		}else{
			$('#'+selectionId).append('<label id="'+date.replace(/\//g,'')+'"><span" title="Remove date."><a href="#" style="color:red;padding:5px; onclick="removeItem('+date.replace(/\//g,'')+')">X</a></span>'+date+'</label><br/>');
			date = date +',';
			$('#'+hidden).val(date);
			FormState.doActionNoRender(StateAction.changeText(hidden,date));
		}
	}
function PI_populateCurrentPosition(item){
	var currentPosition = item.split(',');
	$('#PI_demotion_pos_title').text(currentPosition[8]);
	$('#PI_demotion_payplan').text(currentPosition[6]);
	$('#PI_demotion_job_series').text(currentPosition[7]);
	$('#PI_demotion_step').text(currentPosition[4]);
	$('#PI_demotion_grade').text(currentPosition[5]);//curr_admin_code
	$('#PI_reassignment_curr_code').text(currentPosition[2]);
}