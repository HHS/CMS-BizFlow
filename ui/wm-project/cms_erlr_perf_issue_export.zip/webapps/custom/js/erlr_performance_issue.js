//var PerformanceIssue = {
    
(function (window) {
    var cms_perf_issue = function () {
	
		var initialized = false;
		
		var layout_group = 
		[
			'pi_action_counseling_group',
			'pi_counseling_grievance_decision_note_group',
			'pi_action_written_narrative_review_group',
			'pi_action_pip_group',
			'pi_pip_written_resp_detail_group',
			'pi_pip_oral_present_detail_group',
			'pi_pip_not_completed_rsn_group',
			'pi_pip_end_prior_to_plan_group',
			'pi_action_demotion_group',
			'pi_demotion_oral_present_detail_group',
			'pi_demotion_written_resp_detail_group',
			'pi_action_reassignment_group',
			'pi_action_removal_group',
			'pi_removal_notice_leave_detail_group',
			'pi_removal_oral_present_detail_group',
			'pi_removal_written_resp_detail_group'
		]
		
		var dateFieldsPastPresent = 
		[
			'PI_PERF_COUNSEL_ISSUE_DT',
			'PI_DMTN_WRTN_RESP_DUE_DT',
			'PI_DMTN_WRTN_RESP_SBMT_DT',
			'PI_DMTN_DECISION_ISSUE_DT',
			'PI_DMTN_PRPS_ACTN_ISSUE_DT',
			'PI_DMTN_ORAL_PRSNT_DT',
			'PI_PIP_WGI_RVW_DT',
			'PI_PIP_START_DT',
			'PI_PIP_END_DT',
			//'PI_PIP_EMPL_NOTIF_DT',
			'PI_PIP_ACTUAL_DT',
			'PI_PIP_PMAP_RTNG_SIGN_DT',
			'PI_PIP_PMAP_RVW_SIGN_DT',
			'PI_PIP_PRPS_ISSUE_DT',
			'PI_PIP_ORAL_PRSNT_DT',
			'PI_PIP_WRTN_SBMT_DT',
			'PI_PIP_WRTN_RESP_DUE_DT',
			'PI_PIP_FIN_AGCY_DECISION_DT',
			'PI_PIP_DECISION_ISSUE_DT',
			'PI_PIP_EFF_ACTN_DT',
			'PI_REASGN_NOTICE_DT',
			'PI_REASGN_EFF_DT',
			'PI_RMV_NOTC_LEV_END_DT',
			'PI_RMV_NOTC_LEV_START_DT',
			'PI_RMV_ORAL_PRSNT_DT',
			'PI_RMV_WRTN_RESP_SBMT_DT',
			'PI_RMV_EFF_DT',
			'PI_RMV_DECISION_ISSUE_DT',
			'PI_RMV_PRPS_ACTN_ISSUE_DT',
			'PI_RMV_WRTN_RESP_DUE_DT',
			'PI_WNR_SPCLST_RVW_CMPLT_DT',
			'PI_WNR_MGR_RVW_RTNG_DT',
			'PI_WNR_RVW_OFC_CONCUR_DT',
			'PI_WNR_WGI_RVW_DT'
		];
		
		var dateFieldsPresentFuture = 
		[
			//'PI_PIP_EXT_END_DT'
		];
		
		var reqFieldForActivity = 
		[
			{
				actName: globalVars.actAll,
				reqFieldIds: 
				[
				]
			},
			{
				actName: globalVars.actCaseCreation,
				reqFieldIds: 
				[
				]
			},
			{
				actName: globalVars.actCaseComplete,
				reqFieldIds: 
				[
					'PI_ACTION_TYPE',
					'PI_DMTN_FIN_AGCY_DECISION',
					'PI_PIP_EMPL_SBMT_MEDDOC',
					'PI_PIP_DOC_SBMT_FOH_RVW',
					'PI_PIP_WGI_WTHLD',
					'PI_PIP_WGI_RVW_DT',
					//'PI_PIP_EMPL_NOTIF_DT',
					'PI_PIP_PRPS_ISSUE_DT',
					'PI_PIP_PMAP_RTNG_SIGN_DT',
					'PI_PIP_PMAP_RVW_SIGN_DT',
					'PI_PIP_FIN_AGCY_DECISION',
					'PI_PIP_EMPL_GRIEVANCE',
					'PI_PIP_APPEAL_DECISION',
					'PI_REASGN_NOTICE_DT',
					'PI_REASGN_EFF_DT',
					'PI_REASGN_FIN_ADMIN_CD_SEARCH',
					'PI_RMV_FIN_AGCY_DECISION',
					'PI_WRTN_NRTV_RVW_TYPE',
					'PI_WNR_MGR_RVW_RTNG_DT',
					'PI_WNR_WGI_WTHLD',
					'PI_WNR_WGI_RVW_DT'
				]
			}
		];
		
		var disabledElementIds = [
			'PI_PIP_EXT_END_DT', 
			'PI_PIP_EXT_REASON', 
			'PI_PIP_EXT_OTHR_RSN', 
			'PI_PIP_EMPL_NOTIF_DT'
		];
		
		
		// Object Containing properties to store Pay Plan Details; contents are refreshed
		// using the method setPayPlanDetails when Pay Plan is changed by the user
		//
		// [
		//		{
		//			payPlan: "",
		//			gradeRequired: 0,
		//			minGrade: 0,
		//			maxGrade: 0,
		//			restrictGradeAt: 0
		//		},
		//		...
		// ];
		var payPlanGradeDetails = [];
		
		
		
		var pipExtDialogOption = {
			dataDialogTitle:    'Date Extension Details',
			historyDialogTitle: 'Extended PIP End Date(s)',
			dataObjectId:       'PI_PIP_EXT',
			origDateElemId:     'PI_PIP_END_DT',
			extDateElemId:      'PI_PIP_EXT_END_DT',
			labelForDateElem:   'Extended PIP End Date',
			extSelectElemId:    'PI_PIP_EXT_REASON',
			labelForSelectElem: 'Reason',
			dropdownOptionType: 'ERLRPiPipExtReason',
			extTextElemId:      'PI_PIP_EXT_OTHR_RSN',
			labelForTextElem:   'Other Reason',
			notifDateElemId:    'PI_PIP_EMPL_NOTIF_DT',
			labelForDate2Elem:  'Date Employee Notified',
			date2Required:      true,
			extDetailGrpId:     'pi_pip_extension_detail_group',
			btnExtendId:        'btnExtendPipEndDt',
			btnAltExtendId:     'btnAltExtendPipEndDt',
			postDialogCallback: function() { 
				controlPiPipExtEndDtVisibility();
				controlPiPipExtOtherVisibility(); 
				controlPiPipEndDtEnableDisable();
			}
		};
		var pipExtDialog = null;
		
		
		
		
		function populatePiDemotionCurPosnData() {
			var genEmployee = FormState.getElementValue('GEN_EMPLOYEE');
			if (typeof genEmployee == 'undefined' || genEmployee == null || genEmployee.trim().length <= 0) return;
			var dataArray = genEmployee.split(',');
			if (!$.isArray(dataArray) || dataArray.length < 11) return;
			$('#PI_DMTN_CUR_POS_TITLE' ).text(dataArray[6]);
			$('#PI_DMTN_CUR_PAY_PLAN'  ).text(dataArray[7]);
			$('#PI_DMTN_CUR_JOB_SERIES').text(dataArray[8]);
			$('#PI_DMTN_CUR_STEP'      ).text(dataArray[9]);
			$('#PI_DMTN_CUR_GRADE'     ).text(dataArray[10]);
			FormState.updateVariableValue('PI_DMTN_CUR_POS_TITLE',  dataArray[6], false);
			FormState.updateVariableValue('PI_DMTN_CUR_PAY_PLAN',   dataArray[7], false);
			FormState.updateVariableValue('PI_DMTN_CUR_JOB_SERIES', dataArray[8], false);
			FormState.updateVariableValue('PI_DMTN_CUR_STEP',       dataArray[9], false);
			FormState.updateVariableValue('PI_DMTN_CUR_GRADE',      dataArray[10], false);
		}
		
		
		// initializes payPlanGradeDetails array.  
		// This function should be called when the page is initialized.
		function initPayPlanGradeDetails() {
			if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'erlr_performance_issue::setPayPlanDetails START');
			
			payPlanGradeDetails = [];
			$('#PI_GRADE_SOURCE option').each(function(index, elem){
				var ppDetail = $(this).text().split(',');
				var payPlanDetail = {
					payPlan: "",
					gradeRequired: 0,
					minGrade: 0,
					maxGrade: 0,
					restrictGradeAt: 0
				};
				payPlanDetail.payPlan = $(this).val(),
				payPlanDetail.gradeRequired = parseInt(ppDetail[0])
				payPlanDetail.minGrade = parseInt(ppDetail[1]);
				payPlanDetail.maxGrade = parseInt(ppDetail[2]);
				payPlanDetail.restrictGradeAt = parseInt(ppDetail[3]);
				payPlanGradeDetails.push(payPlanDetail);
			});
			
			if (FormLog.isDebugLevel()) {
				for (var i = 0; i < payPlanGradeDetails.length; i++) {
					var payPlanDetail = payPlanGradeDetails[i];
					FormLog.log(FormLog.LOG_LEVEL.DEBUG, '------------------------------------');
					FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'payPlan         [' + payPlanDetail.payPlan + ']');
					FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'gradeRequired   [' + payPlanDetail.gradeRequired + ']');
					FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'minGrade        [' + payPlanDetail.minGrade + ']');
					FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'maxGrade        [' + payPlanDetail.maxGrade + ']');
					FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'restrictGradeAt [' + payPlanDetail.restrictGradeAt + ']');
					FormLog.log(FormLog.LOG_LEVEL.DEBUG, '');
				}
			}
			
			if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'erlr_performance_issue::setPayPlanDetails END');
		}
		
		function getPayPlanDetail(payPlan) {
			if (typeof payPlan == 'undefined' || payPlan == null || payPlan.trim().length <= 0) return null;
			for (var i = 0; i < payPlanGradeDetails.length; i++) {
				var payPlanDetail = payPlanGradeDetails[i];
				if (payPlan === payPlanDetail.payPlan) {
					return payPlanDetail;
					break;
				}
			}
		}
		
		// sets the available options in Grade dropdown.
		// The function removes selected values and uses the restrict
		// value to detirmine the available options
		function setGradeOptions(payPlanElemId, gradeElemId) {
			if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'erlr_performance_issue::setGradeOptions(payPlanElemId = ' + payPlanElemId + ', gradeElemId = ' + gradeElemId + ') START');
			
			if (typeof gradeElemId == 'undefined' || gradeElemId == null || gradeElemId.trim().length <= 0) return;
			var gradeSelect = '#' + gradeElemId;
			var payPlanVal = FormState.getElementValue(payPlanElemId);
			var payPlanDetail = getPayPlanDetail(payPlanVal);
			if (payPlanDetail == null) return;
			var maxgrade = payPlanDetail.maxGrade;
			var options = "<option value selected>Select One</option>";
			for (var g = payPlanDetail.minGrade; g <= maxgrade; g++) {
				var gLabel = g < 10 ? ("0" + g) : ('' + g);
				options += "<option value=\"" + g + "\">" + gLabel + "</option>";
			}

			$(gradeSelect).find('option').remove().end().append(options); // refresh grade options

			var gradeCurrentValue = $(gradeSelect).val();
			if ($.isNumeric(gradeCurrentValue) && gradeCurrentValue <= payPlanDetail.minGrad) {
				$(gradeSelect).val(gradeCurrentValue);
			}
			
			if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'erlr_performance_issue::setGradeOptions END');
		}
		
		// Uses the value from the Pay Plan field to manage grade options.
		function payPlanChange(payPlanElemId, gradeElemId) {
			if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'erlr_performance_issue::payPlanChange START');
			
			var payPlanVal = FormState.getElementValue(payPlanElemId);
			var payPlanDetail = getPayPlanDetail(payPlanVal);
			if (payPlanDetail == null) return;
			setGradeOptions(payPlanElemId, gradeElemId);
			if (payPlanDetail.payPlan != '' && payPlanDetail.gradeRequired == 1 && payPlanDetail.minGrade > 0 && payPlanDetail.maxGrade > 0) {
				$('#' + gradeElemId).show();
			} else {
				$('#' + gradeElemId).hide();
			}
			
			if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'erlr_performance_issue::payPlanChange END');
		}
		
		function populatePiReassignCurInfo() {
			var genEmployee = FormState.getElementValue('GEN_EMPLOYEE');
			if (typeof genEmployee == 'undefined' || genEmployee == null || genEmployee.trim().length <= 0) return;
			var dataArray = genEmployee.split(',');
			if (!$.isArray(dataArray) || dataArray.length < 6) return;
			var genEmployeeAdminCd = dataArray[4];
			var genEmployeeAdminCdDesc = dataArray[5];
			$('#PI_REASGN_CUR_ADMIN_CD').text(genEmployeeAdminCd);
			$('#PI_REASGN_CUR_ORG_NM').text(genEmployeeAdminCdDesc);
			FormState.updateVariableValue('PI_REASGN_CUR_ADMIN_CD', genEmployeeAdminCd, false);
			FormState.updateVariableValue('PI_REASGN_CUR_ORG_NM', genEmployeeAdminCdDesc, false);
        }
		
		function populateReassignFinAdminCdDesc() {
			var item = FormState.getElementSingleValue('PI_REASGN_FIN_ADMIN_CD');
			if ( typeof item !== 'object' || item == null 
					|| typeof item.adminCdDesc == 'undefined' || item.adminCdDesc == null ) {
				return;
			}
			$('#PI_REASGN_FIN_ORG_NM').text(item.adminCdDesc);
			FormState.updateVariableValue('PI_REASGN_FIN_ORG_NM', item.adminCdDesc, false);
		}
		
		function showHideLayoutGroup(groupId, isShown) {
			if (isShown === true) {
				hyf.util.showComponent(groupId);
			} else {
				hyf.util.hideComponent(groupId);
			}
		}
		
		function controlPiActionTypeVisibility() {
            var piActionTypeSelVal = FormState.getElementValue('PI_ACTION_TYPE');
            var piActionTypeSelTxt = $('#PI_ACTION_TYPE option[value="' + piActionTypeSelVal + '"]').text();
			if (typeof piActionTypeSelTxt == 'undefined' || piActionTypeSelTxt == null || piActionTypeSelTxt.trim().length <= 0) {
				// hide all subsection of the tab unless Action Type is set
				$('#performance_issue_group div[id^="pi_action_"]').each(function(index, item){
					hyf.util.hideComponent(item.id);
				});
				return;
			}
			
			// layout group names maps to PI_ACTION_TYPE value: "pi_action_" + selected label in lower case, replacing space with underscore
			var selectedPiActionTypeGroupId = 'pi_action_' + piActionTypeSelTxt.toLowerCase().replace(/\s/g,'_') + '_group';
			$('#performance_issue_group div[id^="pi_action_"]').each(function(index, item){
				if (item.id === selectedPiActionTypeGroupId) {
					if (piActionTypeSelTxt == 'Reassignment') {
						populatePiReassignCurInfo();
						populateReassignFinAdminCdDesc();
					} else if (piActionTypeSelTxt == 'Demotion') {
						populatePiDemotionCurPosnData();
					}
					hyf.util.showComponent(item.id);
				} else {
					hyf.util.hideComponent(item.id);
				}
			});
        }
		
		function controlAppealVisibility() {
			var caseTypeState = FormState.getState('GEN_CASE_TYPE');
			if (typeof caseTypeState == 'undefined' || caseTypeState == null) return;
			var caseTypeTxt = caseTypeState.text;
			if ('Performance Issue' !== caseTypeTxt) return;
			var piPipAppealVal  = FormState.getElementValue('PI_PIP_APPEAL_DECISION');
			var piDmtnAppealVal = FormState.getElementValue('PI_DMTN_APPEAL_DECISION');
			var piRmvAppealVal  = FormState.getElementValue('PI_RMV_APPEAL_DECISION');
			FormMain.showHideAppealTab('Yes' === piPipAppealVal || 'Yes' === piDmtnAppealVal || 'Yes' === piRmvAppealVal);
		}
		
		function controlPiCounselGrievanceDecisionVisibility() {
            var elemVal = FormState.getElementValue('PI_CNSL_GRV_DECISION');
			showHideLayoutGroup('pi_counseling_grievance_decision_note_group', ('Yes' === elemVal));
        }
		
		function controlPiDemotionOralPresentReqVisibility() {
            var elemVal = FormState.getElementValue('PI_DMTN_ORAL_PRSNT_REQ');
			showHideLayoutGroup('pi_demotion_oral_present_detail_group', ('Yes' === elemVal));
        }
		
		function controlPiDemotionWrittenRespSubmitVisibility() {
            var elemVal = FormState.getElementValue('PI_DMTN_WRTN_RESP_SBMT');
			showHideLayoutGroup('pi_demotion_written_resp_detail_group', ('Yes' === elemVal));
        }
		
		function controlPiDemotionPayPlanGradeVisibility() {
			payPlanChange('PI_DMTN_PRPS_PAY_PLAN', 'PI_DMTN_PRPS_GRADE');
			payPlanChange('PI_DMTN_FIN_PAY_PLAN', 'PI_DMTN_FIN_GRADE');
		}
		
		function controlPiDemotionFinDecisionVisibility() {
            var elemVal = FormState.getElementValue('PI_DMTN_FIN_AGCY_DECISION');
			var elemTxt = null;
			if (typeof elemVal != 'undefined' && elemVal != null && elemVal.length > 0) {
				elemTxt = $('#PI_DMTN_FIN_AGCY_DECISION option[value="' + elemVal + '"]').text();
			}
			showHideLayoutGroup('pi_demotion_final_decision_detail_by_type_group', (null !== elemTxt && 'No Decision Issued' !== elemTxt));
			showHideLayoutGroup('pi_demotion_final_decision_effdt_group', ('Demotion Rescinded' !== elemTxt));
			showHideLayoutGroup('pi_demotion_final_decision_suspend_days_group', ('Suspension' === elemTxt));
        }
		
		function controlPiPipSubmitMeddocVisibility() {
            var elemVal = FormState.getElementValue('PI_PIP_EMPL_SBMT_MEDDOC');
			showHideLayoutGroup('pi_pip_meddoc_group', ('Yes' === elemVal));
        }
		
		function controlPiPipMeddocReviewVisibility() {
            var elemVal = FormState.getElementValue('PI_PIP_DOC_SBMT_FOH_RVW');
			showHideLayoutGroup('pi_pip_meddoc_review_group', ('Yes' === elemVal));
        }
		
		function controlPiPipWgiWithheldNoteVisibility() {
            var elemVal = FormState.getElementValue('PI_PIP_WGI_WTHLD');
			showHideLayoutGroup('pi_pip_wgi_withheld_note_group', ('Yes' === elemVal));
        }
		
		function controlPiPipExtEndDtVisibility() {
            var piPipExt = FormState.getElementValue('PI_PIP_EXT');
			if (typeof piPipExt != 'undefined' && piPipExt != null && piPipExt.length > 0) {
				$('#btnExtendPipEndDt').hide();
				hyf.util.showComponent('pi_pip_extension_detail_group');
				// when pip extension is displayed, further control history hyperlink
				showHideLayoutGroup('pi_pip_ext_history_group', ($.isArray(piPipExt) && piPipExt.length > 1));
			} else {
				$('#btnExtendPipEndDt').show();
				hyf.util.hideComponent('pi_pip_extension_detail_group');
			}
        }
		
		function controlPiPipExtOtherVisibility() {
            var elemVal = FormState.getElementValue('PI_PIP_EXT_REASON');
			var elemTxt = null;
			if (typeof elemVal != 'undefined' && elemVal != null && elemVal.length > 0) {
				elemTxt = $('#PI_PIP_EXT_REASON option[value="' + elemVal + '"]').text();
			}
			showHideLayoutGroup('pi_pip_ext_other_reason_group', ('Other' === elemTxt));
        }
		
		function controlPiPipSuccessfullyCompletedVisibility() {
            var piPipSucessCmpltSelVal = FormState.getElementValue('PI_PIP_SUCCESS_CMPLT');
			showHideLayoutGroup('pi_pip_not_success_group', ('No' === piPipSucessCmpltSelVal));
			showHideLayoutGroup('pi_pip_not_completed_rsn_group', ('No' === piPipSucessCmpltSelVal));
        }
		
		function controlPiPipNotCompletedOtherVisibility() {
            var elemVal = FormState.getElementValue('PI_PIP_NOT_CMPLT_RSN');
			var elemTxt = null;
			if (typeof elemVal != 'undefined' && elemVal != null && elemVal.length > 0) {
				elemTxt = $('#PI_PIP_NOT_CMPLT_RSN option[value="' + elemVal + '"]').text();
			}
			showHideLayoutGroup('pi_pip_not_completed_other_rsn_group', ('Other' === elemTxt));
        }
		
		function controlPiPipEndPriorToPlanVisibility() {
            var elemVal = FormState.getElementValue('PI_PIP_END_PRIOR_TO_PLAN');
			showHideLayoutGroup('pi_pip_end_prior_to_plan_group', ('Yes' === elemVal));
        }
		
		function controlPiPipOralPresentReqVisibility() {
            var elemVal = FormState.getElementValue('PI_PIP_ORAL_PRSNT_REQ');
			showHideLayoutGroup('pi_pip_oral_present_detail_group', ('Yes' === elemVal));
        }
		
		function controlPiPipWrittenRespSubmitVisibility() {
            var elemVal = FormState.getElementValue('PI_PIP_WRTN_RESP_SBMT');
			showHideLayoutGroup('pi_pip_written_resp_detail_group', ('Yes' === elemVal));
        }
		
		function controlPiPipEmplGrievanceVisibility() {
            var elemVal = FormState.getElementValue('PI_PIP_EMPL_GRIEVANCE');
			showHideLayoutGroup('pi_pip_empl_grievance_output_group', ('Yes' === elemVal));
        }
		
		function controlPiRemovalEmplPlacedNoticeLeaveVisibility() {
            var elemVal = FormState.getElementValue('PI_RMV_EMPL_NOTC_LEV');
			showHideLayoutGroup('pi_removal_notice_leave_detail_group', ('Yes' === elemVal));
        }
		
		function controlPiRemovalOralPresentReqVisibility() {
            var elemVal = FormState.getElementValue('PI_RMV_ORAL_PRSNT_REQ');
			showHideLayoutGroup('pi_removal_oral_present_detail_group', ('Yes' === elemVal));
        }
		
		function controlPiRemovalWrittenRespSubmitVisibility() {
            var elemVal = FormState.getElementValue('PI_RMV_WRTN_RESP_SBMT');
			showHideLayoutGroup('pi_removal_written_resp_detail_group', ('Yes' === elemVal));
        }
		
		function controlPiRemovalFinDecisionVisibility() {
            var elemVal = FormState.getElementValue('PI_RMV_FIN_AGCY_DECISION');
			var elemTxt = null;
			if (typeof elemVal != 'undefined' && elemVal != null && elemVal.length > 0) {
				elemTxt = $('#PI_RMV_FIN_AGCY_DECISION option[value="' + elemVal + '"]').text();
			}
			showHideLayoutGroup('pi_removal_final_decision_detail_by_type_group', (null !== elemTxt && 'No Decision Issued' !== elemTxt));
			showHideLayoutGroup('pi_removal_final_decision_effdt_group', ('Removal Rescinded' !== elemTxt));
			showHideLayoutGroup('pi_removal_final_decision_suspend_days_group', ('Suspension' === elemTxt));
        }
		
		function controlPiWrtnNartvRvwTypeVisibility() {
            var elemVal = FormState.getElementValue('PI_WRTN_NRTV_RVW_TYPE');
			var elemTxt = null;
			if (typeof elemVal != 'undefined' && elemVal != null && elemVal.length > 0) {
				elemTxt = $('#PI_WRTN_NRTV_RVW_TYPE option[value="' + elemVal + '"]').text();
			}
			showHideLayoutGroup('pi_wnr_final_review_group', ('End of Year' === elemTxt));
        }
		
		function controlPiWrtnNartvRvwWgiWithheldNoteVisibility() {
            var elemVal = FormState.getElementValue('PI_WNR_WGI_WTHLD');
			showHideLayoutGroup('pi_wnr_wgi_withheld_note_group', ('Yes' === elemVal));
        }
		
		function initVisibility() {
			controlPiActionTypeVisibility();
			controlAppealVisibility();
			controlPiCounselGrievanceDecisionVisibility();
			controlPiDemotionOralPresentReqVisibility();
			controlPiDemotionWrittenRespSubmitVisibility();
			controlPiDemotionPayPlanGradeVisibility();
			controlPiDemotionFinDecisionVisibility();
			controlPiPipSubmitMeddocVisibility();
			controlPiPipMeddocReviewVisibility();
			controlPiPipWgiWithheldNoteVisibility();
			controlPiPipExtEndDtVisibility();
			controlPiPipExtOtherVisibility();
			controlPiPipSuccessfullyCompletedVisibility();
			controlPiPipNotCompletedOtherVisibility();
			controlPiPipEndPriorToPlanVisibility();
			controlPiPipOralPresentReqVisibility();
			controlPiPipWrittenRespSubmitVisibility();
			controlPiPipEmplGrievanceVisibility();
			controlPiRemovalEmplPlacedNoticeLeaveVisibility();
			controlPiRemovalOralPresentReqVisibility();
			controlPiRemovalWrittenRespSubmitVisibility();
			controlPiRemovalFinDecisionVisibility();
			controlPiWrtnNartvRvwTypeVisibility();
			controlPiWrtnNartvRvwWgiWithheldNoteVisibility();
		}
		
		
		
		
		function controlPiPipEndDtEnableDisable() {
			
			var origDt = FormState.getElementValue('PI_PIP_END_DT');
			if (typeof origDt == 'undefined' || origDt == null || origDt.length <= 0) {
				hyf.util.disableComponent('btnExtendPipEndDt');
			} else {
				hyf.util.enableComponent('btnExtendPipEndDt');
			}
			
			var extDt = FormState.getElementValue('PI_PIP_EXT_END_DT');
			if (typeof extDt == 'undefined' || extDt == null || extDt.length <= 0) {
				hyf.util.enableComponent('PI_PIP_END_DT');
			} else {
				hyf.util.disableComponent('PI_PIP_END_DT');
			}
		}
		
		function controlEnableDisable() {
			disabledElementIds.forEach(function(item){
				hyf.util.disableComponent(item);
			});
			controlPiPipEndDtEnableDisable();
		}
		
		
		
		
		function setSelectElemValue(selElem) {
			if ( typeof selElem == 'undefined' || selElem == null 
					|| typeof selElem.id == 'undefined' || selElem.id == null 
					|| typeof selElem.options == 'undefined' || selElem.options == null ) {
				return;
			}
			var selectedVal = selElem.options[selElem.options.selectedIndex].value;
			var selectedTxt = selElem.options[selElem.options.selectedIndex].text;
			FormState.updateSelectValue(selElem.id, selectedVal, selectedTxt);
		}
		
		function initEventHandlers() {
			$('#PI_ACTION_TYPE').on('change', function(e) {
				setSelectElemValue(e.target);
				controlPiActionTypeVisibility();
			});
			
			$('#PI_CNSL_GRV_DECISION').on('change', function(e) {
				setSelectElemValue(e.target);
				controlPiCounselGrievanceDecisionVisibility();
			});
			
			$('#PI_DMTN_ORAL_PRSNT_REQ').on('change', function(e) {
				setSelectElemValue(e.target);
				controlPiDemotionOralPresentReqVisibility();
			});
			
			$('#PI_DMTN_WRTN_RESP_SBMT').on('change', function(e) {
				setSelectElemValue(e.target);
				controlPiDemotionWrittenRespSubmitVisibility();
			});
			
			$('#PI_DMTN_PRPS_PAY_PLAN').on('change', function(e) {
				setSelectElemValue(e.target);
				payPlanChange(e.target.id, 'PI_DMTN_PRPS_GRADE');
			});
			
			$('#PI_DMTN_FIN_PAY_PLAN').on('change', function(e) {
				setSelectElemValue(e.target);
				payPlanChange(e.target.id, 'PI_DMTN_FIN_GRADE');
			});
			
			$('#PI_DMTN_FIN_AGCY_DECISION').on('change', function(e) {
				setSelectElemValue(e.target);
				controlPiDemotionFinDecisionVisibility();
			});
			
			$('#PI_DMTN_APPEAL_DECISION').on('change', function(e) {
				setSelectElemValue(e.target);
				controlAppealVisibility();
			});
			
			$('#PI_PIP_EMPL_SBMT_MEDDOC').on('change', function(e) {
				setSelectElemValue(e.target);
				controlPiPipSubmitMeddocVisibility();
			});
			
			$('#PI_PIP_DOC_SBMT_FOH_RVW').on('change', function(e) {
				setSelectElemValue(e.target);
				controlPiPipMeddocReviewVisibility();
			});
			
			$('#PI_PIP_WGI_WTHLD').on('change', function(e) {
				setSelectElemValue(e.target);
				controlPiPipWgiWithheldNoteVisibility();
			});
			
			$('#PI_PIP_SUCCESS_CMPLT').on('change', function(e) {
				setSelectElemValue(e.target);
				controlPiPipSuccessfullyCompletedVisibility();
			});
			
			$('#PI_PIP_NOT_CMPLT_RSN').on('change', function(e) {
				setSelectElemValue(e.target);
				controlPiPipNotCompletedOtherVisibility();
			});
			
			$('#PI_PIP_END_DT').on('change', function(e) {
				FormState.updateDateValue(e.target.id, e.target.value);
				controlPiPipEndDtEnableDisable();
			});
			
			//$('#PI_PIP_EXT_REASON').on('change', function(e) {
			//	setSelectElemValue(e.target);
			//	controlPiPipExtOtherVisibility();
			//});
			
			//$('#PI_PIP_EXT_END_DT').on('change keyup', function(e) {
			//	var target = e.target;
			//	var piPipExtEndDt = target.value;
			//	FormState.updateVariableValue('PI_PIP_EXT_END_DT', piPipExtEndDt, false);
			//	controlPiPipExtEndDtVisibility();
			//});
			
			$('#btnExtendPipEndDt, #btnAltExtendPipEndDt').on('click', function(e) {
				pipExtDialog.openDataDialog();
			});
			
			$('#viewPipExtHistory').on('click', function(e) {
				pipExtDialog.openHistoryDialog();
			});
			
			$('#PI_PIP_END_PRIOR_TO_PLAN').on('change', function(e) {
				setSelectElemValue(e.target);
				controlPiPipEndPriorToPlanVisibility();
			});
			
			$('#PI_PIP_ORAL_PRSNT_REQ').on('change', function(e) {
				setSelectElemValue(e.target);
				controlPiPipOralPresentReqVisibility();
			});
			
			$('#PI_PIP_WRTN_RESP_SBMT').on('change', function(e) {
				setSelectElemValue(e.target);
				controlPiPipWrittenRespSubmitVisibility();
			});
			
			$('#PI_PIP_EMPL_GRIEVANCE').on('change', function(e) {
				setSelectElemValue(e.target);
				controlPiPipEmplGrievanceVisibility();
			});
			
			$('#PI_PIP_APPEAL_DECISION').on('change', function(e) {
				setSelectElemValue(e.target);
				controlAppealVisibility();
			});
			
			$('#PI_RMV_EMPL_NOTC_LEV').on('change', function(e) {
				setSelectElemValue(e.target);
				controlPiRemovalEmplPlacedNoticeLeaveVisibility();
			});
			
			$('#PI_RMV_ORAL_PRSNT_REQ').on('change', function(e) {
				setSelectElemValue(e.target);
				controlPiRemovalOralPresentReqVisibility();
			});
			
			$('#PI_RMV_WRTN_RESP_SBMT').on('change', function(e) {
				setSelectElemValue(e.target);
				controlPiRemovalWrittenRespSubmitVisibility();
			});
			
			$('#PI_RMV_FIN_AGCY_DECISION').on('change', function(e) {
				setSelectElemValue(e.target);
				controlPiRemovalFinDecisionVisibility();
			});
			
			$('#PI_RMV_APPEAL_DECISION').on('change', function(e) {
				setSelectElemValue(e.target);
				controlAppealVisibility();
			});
			
			$('#PI_WRTN_NRTV_RVW_TYPE').on('change', function(e) {
				setSelectElemValue(e.target);
				controlPiWrtnNartvRvwTypeVisibility();
			});
			
			$('#PI_WNR_WGI_WTHLD').on('change', function(e) {
				setSelectElemValue(e.target);
				controlPiWrtnNartvRvwWgiWithheldNoteVisibility();
			});
		}
		
		
		
		
		function mapFunctionAdminCd(context) {
			return {
				adminCd:      $("AC_ADMIN_CD", context).text(),
				adminCdDesc:  $("AC_ADMIN_CD_DESCR", context).text()
			};
		}

		function getSelectionLabelAdminCd(item) {
			var label = item.adminCd;
			return label;
		}

		function getCandidateLabelAdminCd(item) {
			return item.adminCd + ' - ' + item.adminCdDesc;
		}

		function getItemIDAdminCd(item) {
			return item.adminCd;
		}
		
		function setDataToFormAdminCd(items) {
			if (typeof items == 'undefined' || items == null) return;
			var item = null;
			if ($.isArray(items)) {
				item = items[0];
			} else {
				item = items;
			}
			
			if ( typeof item === 'object' && item != null 
					&& typeof item.adminCd != 'undefined' && item.adminCd != null && item.adminCd.trim().length > 0
					&& typeof item.adminCdDesc != 'undefined' && item.adminCdDesc != null && item.adminCdDesc.trim().length > 0 ) {
				$('#PI_REASGN_FIN_ORG_NM').text(item.adminCdDesc);
				FormState.updateObjectValue('PI_REASGN_FIN_ADMIN_CD', items);
				FormState.updateVariableValue('PI_REASGN_FIN_ORG_NM', item.adminCdDesc, false);
			} else {
				$('#PI_REASGN_FIN_ORG_NM').text('');
				FormState.updateObjectValue('PI_REASGN_FIN_ADMIN_CD', []);
				FormState.updateVariableValue('PI_REASGN_FIN_ORG_NM', '', false);
			}
		}
		
		function mapFunctionParticipant(context) {
			return {
				id:             $("MID", context).text(),
				participantId:  "[" + $("MTYPE", context).text() + "]" + $("MID", context).text(),
				name:           $("NAME", context).text(),
				email:          $("EMAIL", context).text(),
				org:            $("DEPTNAME", context).text(),
				title:          $("JOBTITLENAME", context).text()
			};
		}

		function getSelectionLabelParticipant(item) {
			var label = item.name + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '') + ' ' + item.org;
			if (item.title) {
				label += '/' + item.title;
			}

			return label;
		}

		function getCandidateLabelParticipant(item) {
			return item.name + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '');
		}

		function getItemIDParticipant(item) {
			return item.id;
		}
		
		function setupCustomWidget() {
			//PI_PIP_EXT
			pipExtDialog = MultiDateSelectDialog.setupMultiDateSelectDialog(pipExtDialogOption);
			
			
			//PI_REASGN_FIN_ADMIN_CD
            var optionAdminCd = {
                id: 'PI_REASGN_FIN_ADMIN_CD_SEARCH',
                baseURL: '/bizflowwebmaker/StratCon_AUT',
                targetURL: '/bizflowwebmaker/StratCon_AUT/SearchAdmOffOrg.do?searchAdmOff=',
                minLength: 2,
                minSelectionCount: 0,
                maxSelectionCount: 1,

                mapFunction: mapFunctionAdminCd,
                getSelectionLabel: getSelectionLabelAdminCd,
                getCandidateLabel: getCandidateLabelAdminCd,
                getItemID: getItemIDAdminCd,
                setDataToForm: setDataToFormAdminCd,

                // initialize
                initialItems: FormState.getElementArrayValue('PI_REASGN_FIN_ADMIN_CD', [])
            };
			FormAutoComplete.makeAutoCompletion(optionAdminCd);
			
			
			//PI_PIP_DECIDING_OFFICAL_NM
            var optionPiPipDecidingOfc = {
                id: 'PI_PIP_DECIDING_OFFICAL_SRCH',
                baseURL: '/bizflowwebmaker/StratCon_AUT',
                targetURL: '/bizflowwebmaker/cms_erlr_service/searchParticipants.do?g=&q=',
                minLength: 2,
                minSelectionCount: 0,
                maxSelectionCount: 1,

                mapFunction: mapFunctionParticipant,
                getSelectionLabel: getSelectionLabelParticipant,
                getCandidateLabel: getCandidateLabelParticipant,
                getItemID: getItemIDParticipant,
                setDataToForm: function (values) {
                    FormState.updateObjectValue('PI_PIP_DECIDING_OFFICAL_NM', values);
                },

                // initialize
                initialItems: FormState.getElementArrayValue('PI_PIP_DECIDING_OFFICAL_NM', [])
            };
			FormAutoComplete.makeAutoCompletion(optionPiPipDecidingOfc);
			
			//PI_DMTN_FIN_DECIDING_OFC_NM
            var optionPiDmtnDecidingOfc = {
                id: 'PI_DMTN_FIN_DECIDING_OFC_SRCH',
                baseURL: '/bizflowwebmaker/StratCon_AUT',
                targetURL: '/bizflowwebmaker/cms_erlr_service/searchParticipants.do?g=&q=',
                minLength: 2,
                minSelectionCount: 0,
                maxSelectionCount: 1,

                mapFunction: mapFunctionParticipant,
                getSelectionLabel: getSelectionLabelParticipant,
                getCandidateLabel: getCandidateLabelParticipant,
                getItemID: getItemIDParticipant,
                setDataToForm: function (values) {
                    FormState.updateObjectValue('PI_DMTN_FIN_DECIDING_OFC_NM', values);
                },

                // initialize
                initialItems: FormState.getElementArrayValue('PI_DMTN_FIN_DECIDING_OFC_NM', [])
            };
			FormAutoComplete.makeAutoCompletion(optionPiDmtnDecidingOfc);
			
			//PI_RMV_FIN_DECIDING_OFC_NM
            var optionPiRmvDecidingOfc = {
                id: 'PI_RMV_FIN_DECIDING_OFC_SRCH',
                baseURL: '/bizflowwebmaker/StratCon_AUT',
                targetURL: '/bizflowwebmaker/cms_erlr_service/searchParticipants.do?g=&q=',
                minLength: 2,
                minSelectionCount: 0,
                maxSelectionCount: 1,

                mapFunction: mapFunctionParticipant,
                getSelectionLabel: getSelectionLabelParticipant,
                getCandidateLabel: getCandidateLabelParticipant,
                getItemID: getItemIDParticipant,
                setDataToForm: function (values) {
                    FormState.updateObjectValue('PI_RMV_FIN_DECIDING_OFC_NM', values);
                },

                // initialize
                initialItems: FormState.getElementArrayValue('PI_RMV_FIN_DECIDING_OFC_NM', [])
            };
			FormAutoComplete.makeAutoCompletion(optionPiRmvDecidingOfc);
			
		}
		
		
		
				
		function init() {
			
			initPayPlanGradeDetails();
			
			//-----------------------------------
			// visibility configuration
			//-----------------------------------
			initVisibility();
			
			//-----------------------------------
			// enable/disable configuration
			//-----------------------------------
			controlEnableDisable();
			
			//-----------------------------------
			// validation configuration
			//-----------------------------------
			dateFieldsPastPresent.forEach(function(item){
				hyf.calendar.setDateConstraint(item, 'Maximum', 'Today');
			});
			dateFieldsPresentFuture.forEach(function(item){
				hyf.calendar.setDateConstraint(item, 'Minimum', 'Today');
			});
			CommonOpUtil.dynamicMandatory(reqFieldForActivity);
			
			
			//-----------------------------------
			// event handler configuration
			//-----------------------------------
			initEventHandlers();
			
			
			//-----------------------------------
			// custom ui element initialization
			//-----------------------------------
			setupCustomWidget();
		}
		
		// manage data population and display of read-only fields and disabled fields since they cannot be controlled by event handler
		function render() {
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'erlr_performance_issue::render START');
			
			var genEmployeeFormState = FormState.getState('GEN_EMPLOYEE');
			if (genEmployeeFormState && genEmployeeFormState.dirty) {
				var genCaseTypeSelVal = FormState.getElementValue('GEN_CASE_TYPE');
				var genCaseTypeSelTxt = $('#GEN_CASE_TYPE option[value="' + genCaseTypeSelVal + '"]').text();
				if (genCaseTypeSelTxt === 'Performance Issue') {
					var piActionTypeSelVal = FormState.getElementValue('PI_ACTION_TYPE');
					var piActionTypeSelTxt = $('#PI_ACTION_TYPE option[value="' + piActionTypeSelVal + '"]').text();
					if (piActionTypeSelTxt === 'Demotion') {
						populatePiDemotionCurPosnData();
					} else if (piActionTypeSelTxt === 'Reassignment') {
						populatePiReassignCurInfo();
						populateReassignFinAdminCdDesc();
					}
				}
			}
			
			FormLog.log(FormLog.LOG_LEVEL.DEBUG, 'erlr_performance_issue::render END');
		}
		
		
		return {
			initialized: initialized,
			reqFieldForActivity: reqFieldForActivity,
			render: render,
			init: init
		};
	};

    var _initializer = window.cms_perf_issue || (window.cms_perf_issue = cms_perf_issue());
})(window);

