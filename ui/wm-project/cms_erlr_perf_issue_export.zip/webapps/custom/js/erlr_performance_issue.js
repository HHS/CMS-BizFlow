var PerformanceIssue = {
    
	initialized: false,
	
	layout_group: [
		'pi_action_counseling_group',
		'pi_action_written_narrative_review_group',
		'pi_counseling_grievance_decision_note_group',
		'pi_action_pip_group',
		'pi_action_demotion_group',
		'pi_demotion_oral_present_detail_group',
		'pi_demotion_written_resp_detail_group',
		'oral_presentation_date_group',
		'written_response_group',
		'start_grievance_case_note',
		'pi_pip_written_resp_detail_group',
		'pi_pip_oral_present_detail_group',
		'pi_pip_success_complete_rsn_group',
		'pi_pip_end_prior_to_plan_group',
		'pi_action_reassignment_group',
		'pi_removal_notice_leave_detail_group',
		'pi_removal_oral_present_detail_group',
		'pi_removal_written_resp_detail_group',
		'pi_action_removal_group'
	],
	
	dateFields: [
		'PI_dt_wrtn_narrative_reviewed',
		'PI_PIP_START_DT',
		'PI_PIP_END_DT',
		'PIP_emp_notified',
		'PI_EXT_PIP_END_DT',
		'actual_pip_dt',
		'PMAP_signature',
		'PIP_oral_prop_dt',
		'PIP_oral_pres_dt',
		'PIP_dt_written_submit',
		'PIP_written_resp_due',
		'PIP_final_agency_dt',
		'PIP_decision_issued_dt',
		'PIP_eff_action_dt',
		'PI_proposed_action_dt',
		'PI_oral_pres_dt',
		'PI_resp_due',
		'PI_written_resp_submit_dt',
		'PI_decision_dt',
		'PI_reassignment_notice_dt',
		'PI_reassignment_eff_dt',
		'PI_removal_ntc_end_dt',
		'PI_removal_ntc_start_dt',
		'PI_removal_oral_prezn_dt',
		'PI_removal_written_resp_submit_dt',
		'PI_removal_eff_dt',
		'PI_removal_decision_issue_dt',
		'PI_removal_prop_action_dt',
		'PI_date_mngr_issued_review',
		'PI_PERF_COUNSEL_ISSUE_DT',
		'PI_removal_written_resp_due'
	],
	
    init: function () {     
        PerformanceIssue.layout_group.forEach(function(el,index){
            hyf.util.hideComponent(el);
        });
		PerformanceIssue.dateFields.forEach(function(el){
			hyf.calendar.setDateConstraint(el, 'Maximum', 'Today');
		});
		
		//$('#btnAddExtPipEndDt').on('click', PerfIssueUtil.addDate);
		var dateOption = {
			dataElemId: 'PI_PIP_EXT_DT',
			dispElemId: 'PI_PIP_EXT_DT_DISP',
			inputElemId: 'PI_EXT_PIP_END_DT',
			btnElemId: 'btnAddExtPipEndDt',
			minSelectCount: 0,
			maxSelectCount: 3
		};
		MultiDateSelection.init(dateOption);
    },
    
	render: function (){
        var actionType = FormState.getState('PI_ACTION_TYPE');
		var grievanceDecision = FormState.getState('PI_GRV_DECISION');
		var oral_presentation = FormState.getState('PIP_oral_pres_resq');
		var demotion_oral_presentation = FormState.getState('PI_oral_Request');
		var demotion_written_response = FormState.getState('PI_written_resp');
		var written_response_requested = FormState.getState('PIP_written_resp_submit');
		var PIP_end_prior = FormState.getState('PIP_end_prior');
		var pi_pip_success_complete_rsn_group = FormState.getState('PIP_succ_completed');
		var employee_notice_leave_placed = FormState.getState('PI_emp_notice_resp');
		var removal_oral_presentaion_requested = FormState.getState('PI_removal_oral_prezn');
		var removal_written_response = FormState.getState('PI_removal_resp_submit');
		var emp = FormState.getState('empContact');
		var pip_grievance_note = FormState.getState('PIP_grievance');
		
		if (grievanceDecision && grievanceDecision.dirty){
			if (grievanceDecision.value === 'Y'){								
                hyf.util.showComponent('pi_counseling_grievance_decision_note_group');                
            } else {
				hyf.util.hideComponent('pi_counseling_grievance_decision_note_group');                
			}
		}
		if (emp && emp.dirty){
			PerfIssueUtil.PI_populateCurrentPosition(emp.value);		
		}
		if (actionType && actionType.dirty){
			PerfIssueUtil.showCaseView('pi_action_'+ actionType.text.toLowerCase().replace(/\s/g, '_') + '_group', PerformanceIssue.layout_group);
        }
		if (oral_presentation && oral_presentation.dirty){
			PerfIssueUtil.hyfShowOrHide(oral_presentation, 'pi_pip_oral_present_detail_group');
		}
		if (pip_grievance_note && pip_grievance_note.dirty){
			PerfIssueUtil.hyfShowOrHide(pip_grievance_note, 'start_grievance_case_note');
		}
		if (demotion_oral_presentation && demotion_oral_presentation.dirty){
			PerfIssueUtil.hyfShowOrHide(demotion_oral_presentation, 'pi_demotion_oral_present_detail_group');
		}
		if (written_response_requested && written_response_requested.dirty){
			PerfIssueUtil.hyfShowOrHide(written_response_requested, 'pi_pip_written_resp_detail_group');
		}
		if (PIP_end_prior && PIP_end_prior.dirty){
			PerfIssueUtil.hyfShowOrHide(PIP_end_prior, 'pi_pip_end_prior_to_plan_group');
		}
		if (pi_pip_success_complete_rsn_group && pi_pip_success_complete_rsn_group.dirty){
			PerfIssueUtil.hyfShowOrHide(pi_pip_success_complete_rsn_group, 'pi_pip_success_complete_rsn_group');
		}
		if (demotion_written_response && demotion_written_response.dirty){
			PerfIssueUtil.hyfShowOrHide(demotion_written_response, 'pi_demotion_written_resp_detail_group');
		}
		if (employee_notice_leave_placed && employee_notice_leave_placed.dirty){
			PerfIssueUtil.hyfShowOrHide(employee_notice_leave_placed, 'pi_removal_notice_leave_detail_group');
		}
		if (removal_written_response && removal_written_response.dirty){
			PerfIssueUtil.hyfShowOrHide(removal_written_response, 'pi_removal_written_resp_detail_group');
		}
		if (removal_oral_presentaion_requested && removal_oral_presentaion_requested.dirty){
			PerfIssueUtil.hyfShowOrHide(removal_oral_presentaion_requested, 'pi_removal_oral_present_detail_group');
		}
		if (!PerformanceIssue.initialized){
			FormAutoComplete.setAutoComplete('PIP_deciding_official', '/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=', populateOfficial, responseMapper, appendInfo);
			FormAutoComplete.setAutoComplete('PI_demotion_official', '/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=', populateOfficial, responseMapper, appendInfo);
			FormAutoComplete.setAutoComplete('PI_removal_official', '/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=', populateOfficial, responseMapper, appendInfo);
			FormAutoComplete.setAutoComplete('PI_reassignment_final_code', '/bizflowwebmaker/cms_erlr_service/contactInfo.do?admin=', populateAdminCode, adminCodeResponseMapper, appendAdminCode);
			PerfIssueUtil.dynamicMandatory('CompleteCase');
            PerformanceIssue.initialized = true;
		}
    }
};




(function(window){
	
	var PerfIssueUtil = function(){
		
		function addDate(e){
			var storedElem = '', selectionId = '', selected = '', date = '';
			var target = e.target ? e.target.id : e.id;
			if (target){
				if (target === 'btnAddExtPipEndDt'){
					storedElem = 'PI_PIP_EXT_DT';
					selectionId = 'PI_PIP_EXT_DT_DISP';
					date = $('#PI_EXT_PIP_END_DT').val();
					selected = e.value ? e.value : $('#' + storedElem).val();
				}
			}
			if (selected !== '' && selected.indexOf(',') > -1){
				var arr = selected.split(',');
				arr.push(date);
				var tempArr =[];
				arr.forEach(function(el){
					if($.inArray(el, tempArr)=== -1 && el !== ''){
						tempArr.push(el);
					}
				});
				arr = null;
				$('#'+selectionId).html('');
				tempArr.forEach(function(el){
					var itemId = selectionId + el.replace(/\//g, '');
					$('#'+selectionId).append("<label id=\"" +  itemId
						+ "\"><span onclick=\"PerfIssueUtil.removeItem('" + itemId
						+ "')\" title=\"Remove date.\"><a href=\"#\" style=\"color:red;padding:5px;\" onclick=\"PerfIssueUtil.removeItem('"
						+ itemId + "')\">X</a></span>" 
						+ el + "</label><br/>");
				});
				$('#'+storedElem).val(tempArr.join());
				FormState.doActionNoRender(StateAction.changeText(storedElem, tempArr.join()));			
			} else {
				var itemId = selectionId + date.replace(/\//g, '');
				$('#'+selectionId).append("<label id=\"" + itemId
					+ "\"><span title=\"Remove date.\"><a href=\"#\" style=\"color:red;padding:5px;\" onclick=\"PerfIssueUtil.removeItem('" 
					+ itemId + "')\">X</a></span>" 
					+ date + "</label><br/>");
				date = date + ',';
				$('#'+storedElem).val(date);
				FormState.doActionNoRender(StateAction.changeText(storedElem, date));
			}
		}
		
		function PI_populateCurrentPosition(item){
			var currentPosition = item.split(',');
			$('#PI_demotion_pos_title').text(currentPosition[8]);
			$('#PI_demotion_payplan').text(currentPosition[6]);
			$('#PI_demotion_job_series').text(currentPosition[7]);
			$('#PI_demotion_step').text(currentPosition[4]);
			$('#PI_demotion_grade').text(currentPosition[5]);  //curr_admin_code
			$('#PI_reassignment_curr_code').text(currentPosition[2]);
		}

		function showCaseView(caseValue, arr){
			arr.forEach(function(el, index){
				if (el === caseValue){  
					hyf.util.showComponent(el);	
				} else {
					$('#' + el).find('input:text').val('');		
					hyf.util.hideComponent(el);
				}			
			});
		}

		function hyfShowOrHide(item, id){
			if (item.value === 'Y' || item.value === 'yes' || item.value === 'Yes' || item.value === 'true' || item.value == true){
				hyf.util.showComponent(id);
			} else {
				hyf.util.hideComponent(id);
			}
		}
		
		function dynamicMandatory(activityName){
			var dynamic_requireActivity = BFActivityOption.getActivityName().replace(/\s/g, '');
			if (dynamic_requireActivity === activityName){
				var list  = $('.' + activityName + '_dynamic_require').get();
				list.forEach(function(el){
					if (el.id !== ''){
						hyf.util.setMandatoryConstraint(el.id, true); 
					}
				});
			}
		}
		
		function removeItem(containerId, targetId){
			$('#'+containerId).find('label[id=' + targetId+ ']').remove();
		}
		
		
		return {
			addDate: addDate,
			PI_populateCurrentPosition: PI_populateCurrentPosition,
			showCaseView: showCaseView,
			hyfShowOrHide: hyfShowOrHide,
			dynamicMandatory: dynamicMandatory,
			removeItem: removeItem
		};
	};
	
    var _initializer = window.PerfIssueUtil || (window.PerfIssueUtil = PerfIssueUtil());
})(window);



(function(window){
	
	var MultiDateSelection = function(){

		var dataElemId;
		var dispElemId;
		var inputElemId;
		var btnElemId;
		var minSelectCount;
		var maxSelectCount;
		var dataArray = [];
		
		var addItem = function(){
			var newValue = $('#'+inputElemId).val();
			if (typeof newValue != 'undefined' && newValue != null && dataArray.length < maxSelectCount){
				dataArray.push(newValue);
				$('#'+dataElemId).val(dataArray.join());
			}
			displaySelected();
		}
		
		var deleteItem = function(deleteValue){
			if (typeof deleteValue == 'undefined' || deleteValue == null) return;
			for(var i = 0; i < dataArray.length; i++){
				if (deleteValue == dataArray[i]){
					dataArray.splice(i, 1);
					$('#'+dataElemId).val(dataArray.join());
					break;
				}
			}
		}
		
		/**
		 *	utility method to remove selected date item from display element
		 */
		var removeSelectedItem = function(containerId, targetId){
			$('#'+containerId).find('label[id=' + targetId+ ']').remove();
		}
		
		var displaySelected = function(){
			$('#'+dispElemId).html('');
			dataArray.forEach(function(el){
				var itemId = dispElemId + el.replace(/\//g, '');
				$('#'+dispElemId).append("<label id=\"" +  itemId
					+ "\"><span onclick=\"MultiDateSelection.removeSelectedItem('" + dispElemId + "', '" + itemId
					+ "')\" title=\"Remove date.\"><a href=\"#\" style=\"color:red;padding:5px;\" onclick=\"MultiDateSelection.removeSelectedItem('"
					+ dispElemId + "', '" + itemId + "')\">X</a></span>" 
					+ el + "</label><br/>");
			});
		}
		
		var init = function(optionObj){
			
			//TODO: validate option setting
			
			// initialize member variables from optionObj
			dataElemId = optionObj.dataElemId;
			dispElemId = optionObj.dispElemId;
			inputElemId = optionObj.inputElemId;
			btnElemId = optionObj.btnElemId;
			minSelectCount = optionObj.minSelectCount;
			maxSelectCount = optionObj.maxSelectCount;
						
			var dataElem = $('#'+dataElemId);
			if (dataElem && dataElem.val() != null && dataElem.val().length > 0){
				var dataVal = dataElem.val();
				if (dataVal.indexOf(',') > 0){
					dataArray = dataVal.split(',');
				} else {
					dataArray.push(dataVal);
				}
				displaySelected();
			}
			$('#'+btnElemId).on('click', addItem);
		}

		return {
			addItem: addItem,
			deleteItem: deleteItem,
			removeSelectedItem: removeSelectedItem,
			displaySelected: displaySelected,
			init: init
		};
	};
	
    var _initializer = window.MultiDateSelection || (window.MultiDateSelection = MultiDateSelection());
})(window);


