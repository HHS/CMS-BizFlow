//var PerformanceIssue = {
    
(function (window) {
    var cms_perf_issue = function () {
	
		var initialized = false;
		
		var layout_group = 
		[
			'pi_action_counseling_group',
			'pi_counseling_grievance_decision_note_group',
			'pi_action_written_narrative_review_group',
			'pi_action_pip_group',
			'pi_pip_written_resp_detail_group',
			'pi_pip_oral_present_detail_group',
			'pi_pip_success_complete_rsn_group',
			'pi_pip_end_prior_to_plan_group',
			'pi_action_demotion_group',
			'pi_demotion_oral_present_detail_group',
			'pi_demotion_written_resp_detail_group',
			'pi_action_reassignment_group',
			'pi_action_removal_group',
			'pi_removal_notice_leave_detail_group',
			'pi_removal_oral_present_detail_group',
			'pi_removal_written_resp_detail_group'
		]
		
		var dateFieldsPastPresent = 
		[
			'PI_PERF_COUNSEL_ISSUE_DT',
			'PI_dt_wrtn_narrative_reviewed',
			'PI_PIP_START_DT',
			'PI_PIP_END_DT',
			'PI_PIP_EMPL_NOTIF_DT',
			'PI_PIP_ACTUAL_DT',
			'PI_PIP_PMAP_RTNG_SIGN_DT',
			'PI_PIP_PROPS_ISSUE_DT',
			'PI_PIP_ORAL_PRSNT_DT',
			   'PI_proposed_action_dt',
			   'PI_oral_pres_dt',
			'PIP_dt_written_submit',
			'PIP_written_resp_due',
			'PIP_final_agency_dt',
			'PIP_decision_issued_dt',
			'PIP_eff_action_dt',
			'PI_resp_due',
			'PI_written_resp_submit_dt',
			'PI_decision_dt',
			'PI_reassignment_notice_dt',
			'PI_reassignment_eff_dt',
			'PI_removal_ntc_end_dt',
			'PI_removal_ntc_start_dt',
			'PI_removal_oral_prezn_dt',
			'PI_removal_written_resp_submit_dt',
			'PI_removal_eff_dt',
			'PI_removal_decision_issue_dt',
			'PI_removal_prop_action_dt',
			'PI_WNR_MGR_RVW_RTNG_DT',
			'PI_removal_written_resp_due'
		];
		
		var dateFieldsPresentFuture = 
		[
			'PI_PIP_EXT_END_DT'
		];
		
		var reqFieldForActivity = 
		[
			{
				actName: globalVars.actAll,
				reqFieldIds: 
				[
					'PI_ACTION_TYPE',
					'PI_WNR_MGR_RVW_RTNG_DT'
					
					/*
					PI_PIP_PROPS_ACTN
					PI_PIP_PROPS_ISSUE_DT
					PIP_oral_pres_resq        
					PI_PIP_ORAL_PRSNT_DT          
					PIP_written_resp_due  
					
					PIP_dt_written_submit     
					PIP_deciding_official     
					PIP_final_agency_dt       
					PIP_decision_issued_dt    
					PIP_eff_action_dt  
					
					PIP_appeal_decision       
					PI_proposed_action_dt
					PI_DMTN_ORAL_PRSNT_REQ
					PI_oral_pres_dt
					PI_DMTN_WRTN_RESP_SBMT
					
					PI_resp_due
					PI_written_resp_submit_dt
					PI_decision_dt
					PI_demotion_official
					PI_demotion_prop_title
					
					PI_demotion_prop_series
					PI_demotion_prop_pay_plan
					PI_demotion_prop_grade
					PI_demotion_prop_step
					PI_demotion_final_title
					
					PI_demotion_final_series
					PI_demotion_final_pay_plan
					PI_demotion_final_grade
					PI_demotion_final_step
					PI_demotion_appeal_decision
					
					PI_dt_wrtn_narrative_reviewed
					PI_WGI_DENIAL_APPEAL
					PI_reassignment_notice_dt
					PI_reassignment_eff_dt
					PI_reassignment_final_code
					
					PI_removal_prop_action_dt
					PI_REMV_EMPL_NOTC_LEV
					PI_removal_ntc_start_dt
					PI_REMV_ORAL_PRSNT_REQ
					PI_removal_oral_prezn_dt
					
					PI_REMV_WRTN_RESP_SBMT
					PI_removal_written_resp_due
					PI_removal_official
					PI_removal_decision_issue_dt
					PI_removal_eff_dt
					PI_removal_appeal_decision
					*/
					
				]
			},
			{
				actName: globalVars.actCaseCreation,
				reqFieldIds: 
				[
					'PI_WRTN_NRTV_RVW_TYPE'
				]
			},
			{
				actName: globalVars.actCaseComplete,
				reqFieldIds: 
				[
				]
			}
		];
		
	
		function controlPiActionTypeVisibility() {
            var piActionTypeSelVal = FormState.getElementValue('PI_ACTION_TYPE');
            var piActionTypeSelTxt = $('#PI_ACTION_TYPE option[value="' + piActionTypeSelVal + '"]').text();
			if (typeof piActionTypeSelTxt == 'undefined' || piActionTypeSelTxt == null || piActionTypeSelTxt.trim().length <= 0) return;
			
			// layout group names maps to PI_ACTION_TYPE value: "pi_action_" + selected label in lower case, replacing space with underscore
			var selectedPiActionTypeGroupId = 'pi_action_' + piActionTypeSelTxt.toLowerCase().replace(/\s/g,'_') + '_group';
			$('#performance_issue_group div[id^="pi_action_"]').each(function(index, item){
				if (item.id === selectedPiActionTypeGroupId) {
					hyf.util.showComponent(item.id);
				} else {
					hyf.util.hideComponent(item.id);
				}
			});
        }
		
		function controlPiCounselGrievanceDecisionVisibility() {
            var piCnslGrvDecisionVal = FormState.getElementValue('PI_CNSL_GRV_DECISION');
			if ('Yes' === piCnslGrvDecisionVal) {
				hyf.util.showComponent('pi_counseling_grievance_decision_note_group');
			} else {
				hyf.util.hideComponent('pi_counseling_grievance_decision_note_group');
			}
        }
		
		function controlPiPipSuccessfullyCompletedVisibility() {
            var piPipSucessCmpltSelVal = FormState.getElementValue('PI_PIP_SUCCESS_CMPLT');
			
			if ('No' === piPipSucessCmpltSelVal) {
				hyf.util.showComponent('pi_pip_not_success_group');
			} else {
				hyf.util.hideComponent('pi_pip_not_success_group');
			}
			
			if ('Yes' === piPipSucessCmpltSelVal) {
				hyf.util.showComponent('pi_pip_success_complete_rsn_group');
			} else {
				hyf.util.hideComponent('pi_pip_success_complete_rsn_group');
			}
        }
		
		function controlPiPipExtEndDtVisibility() {
            var piPipExtEndDtVal = FormState.getElementValue('PI_PIP_EXT_END_DT');
			if (piPipExtEndDtVal != null && piPipExtEndDtVal.trim().length > 0) {
				hyf.util.showComponent('pi_pip_ext_detail_group');
			} else {
				hyf.util.hideComponent('pi_pip_ext_detail_group');
			}
        }
		
		function controlPiPipEndPriorToPlanVisibility() {
            var piPipEndPriorToPlanVal = FormState.getElementValue('PI_PIP_END_PRIOR_TO_PLAN');
			if ('Yes' === piPipEndPriorToPlanVal) {
				hyf.util.showComponent('pi_pip_end_prior_to_plan_group');
			} else {
				hyf.util.hideComponent('pi_pip_end_prior_to_plan_group');
			}
        }
		
		function controlPiPipOralPresentReqVisibility() {
            var piPipOralPresReqVal = FormState.getElementValue('PI_PIP_ORAL_PRSNT_REQ');
			if ('Yes' === piPipOralPresReqVal) {
				hyf.util.showComponent('pi_pip_oral_present_detail_group');
			} else {
				hyf.util.hideComponent('pi_pip_oral_present_detail_group');
			}
        }
		
		function controlPiPipWrittenRespSubmitVisibility() {
            var piPipWrtnRespSbmtVal = FormState.getElementValue('PI_PIP_WRTN_RESP_SBMT');
			if ('Yes' === piPipWrtnRespSbmtVal) {
				hyf.util.showComponent('pi_pip_written_resp_detail_group');
			} else {
				hyf.util.hideComponent('pi_pip_written_resp_detail_group');
			}
        }
		
		function controlPiDemotionOralPresentReqVisibility() {
            var piDmtnOralPrsntReqVal = FormState.getElementValue('PI_DMTN_ORAL_PRSNT_REQ');
			if ('Yes' === piDmtnOralPrsntReqVal) {
				hyf.util.showComponent('pi_demotion_oral_present_detail_group');
			} else {
				hyf.util.hideComponent('pi_demotion_oral_present_detail_group');
			}
        }
		
		function controlPiDemotionWrittenRespSubmitVisibility() {
            var piDmtnWrtnRespSbmtVal = FormState.getElementValue('PI_DMTN_WRTN_RESP_SBMT');
			if ('Yes' === piDmtnWrtnRespSbmtVal) {
				hyf.util.showComponent('pi_demotion_written_resp_detail_group');
			} else {
				hyf.util.hideComponent('pi_demotion_written_resp_detail_group');
			}
        }
		
		function controlPiRemovalEmplPlacedNoticeLeaveVisibility() {
            var piRemvEmplNotcLevVal = FormState.getElementValue('PI_REMV_EMPL_NOTC_LEV');
			if ('Yes' === piRemvEmplNotcLevVal) {
				hyf.util.showComponent('pi_removal_notice_leave_detail_group');
			} else {
				hyf.util.hideComponent('pi_removal_notice_leave_detail_group');
			}
        }
		
		function controlPiRemovalOralPresentReqVisibility() {
            var piRemvOralPrsntReqVal = FormState.getElementValue('PI_REMV_ORAL_PRSNT_REQ');
			if ('Yes' === piRemvOralPrsntReqVal) {
				hyf.util.showComponent('pi_removal_oral_present_detail_group');
			} else {
				hyf.util.hideComponent('pi_removal_oral_present_detail_group');
			}
        }
		
		function controlPiRemovalWrittenResSubmitVisibility() {
            var piRemvWrtnRespSbmtVal = FormState.getElementValue('PI_REMV_WRTN_RESP_SBMT');
			if ('Yes' === piRemvWrtnRespSbmtVal) {
				hyf.util.showComponent('pi_removal_written_resp_detail_group');
			} else {
				hyf.util.hideComponent('pi_removal_written_resp_detail_group');
			}
        }
		
		function initEventHandlers() {
			$('#PI_ACTION_TYPE').on('change', function(e) {
				var target = e.target;
				var piActionType = target.options[target.options.selectedIndex].value;
				FormState.updateObjectValue('PI_ACTION_TYPE', piActionType);
				
				controlPiActionTypeVisibility();
			});
			
			$('#PI_CNSL_GRV_DECISION').on('change', function(e) {
				var target = e.target;
				var piCnslGrvDecision = target.options[target.options.selectedIndex].value;
				FormState.updateObjectValue('PI_CNSL_GRV_DECISION', piCnslGrvDecision);
				
				controlPiCounselGrievanceDecisionVisibility();
			});
			
			$('#PI_PIP_SUCCESS_CMPLT').on('change', function(e) {
				var target = e.target;
				var piPipSucessCmplt = target.options[target.options.selectedIndex].value;
				FormState.updateObjectValue('PI_PIP_SUCCESS_CMPLT', piPipSucessCmplt);
				
				controlPiPipSuccessfullyCompletedVisibility();
			});
			
			$('#PI_PIP_EXT_END_DT').on('change keyup', function(e) {
				var target = e.target;
				var piPipExtEndDt = target.value;
				FormState.updateObjectValue('PI_PIP_EXT_END_DT', piPipExtEndDt);
				
				controlPiPipExtEndDtVisibility();
			});
			
			$('#PI_PIP_END_PRIOR_TO_PLAN').on('change', function(e) {
				var target = e.target;
				var piPipEndPriorToPlan = target.options[target.options.selectedIndex].value;
				FormState.updateObjectValue('PI_PIP_END_PRIOR_TO_PLAN', piPipEndPriorToPlan);
				
				controlPiPipEndPriorToPlanVisibility();
			});
			
			$('#PI_PIP_ORAL_PRSNT_REQ').on('change', function(e) {
				var target = e.target;
				var piPipOralPresReq = target.options[target.options.selectedIndex].value;
				FormState.updateObjectValue('PI_PIP_ORAL_PRSNT_REQ', piPipOralPresReq);
				
				controlPiPipOralPresentReqVisibility();
			});
			
			$('#PI_PIP_WRTN_RESP_SBMT').on('change', function(e) {
				var target = e.target;
				var piPipWrtnRespSbmt = target.options[target.options.selectedIndex].value;
				FormState.updateObjectValue('PI_PIP_WRTN_RESP_SBMT', piPipWrtnRespSbmt);
				
				controlPiPipWrittenRespSubmitVisibility();
			});
			
			$('#PI_DMTN_ORAL_PRSNT_REQ').on('change', function(e) {
				var target = e.target;
				var piDmtnOralPrsntReq = target.options[target.options.selectedIndex].value;
				FormState.updateObjectValue('PI_DMTN_ORAL_PRSNT_REQ', piDmtnOralPrsntReq);
				
				controlPiDemotionOralPresentReqVisibility();
			});
			
			$('#PI_DMTN_WRTN_RESP_SBMT').on('change', function(e) {
				var target = e.target;
				var piDmtnWrtnRespSbmt = target.options[target.options.selectedIndex].value;
				FormState.updateObjectValue('PI_DMTN_WRTN_RESP_SBMT', piDmtnWrtnRespSbmt);
				
				controlPiDemotionWrittenRespSubmitVisibility();
			});
			
			$('#PI_REMV_EMPL_NOTC_LEV').on('change', function(e) {
				var target = e.target;
				var piRemvEmplNotcLev = target.options[target.options.selectedIndex].value;
				FormState.updateObjectValue('PI_REMV_EMPL_NOTC_LEV', piRemvEmplNotcLev);
				
				controlPiRemovalEmplPlacedNoticeLeaveVisibility();
			});
			
			$('#PI_REMV_ORAL_PRSNT_REQ').on('change', function(e) {
				var target = e.target;
				var piRemvOralPrsntReq = target.options[target.options.selectedIndex].value;
				FormState.updateObjectValue('PI_REMV_ORAL_PRSNT_REQ', piRemvOralPrsntReq);
				
				controlPiRemovalOralPresentReqVisibility();
			});
			
			$('#PI_REMV_WRTN_RESP_SBMT').on('change', function(e) {
				var target = e.target;
				var piRemvWrtnRespSbmt = target.options[target.options.selectedIndex].value;
				FormState.updateObjectValue('PI_REMV_WRTN_RESP_SBMT', piRemvWrtnRespSbmt);
				
				controlPiRemovalWrittenResSubmitVisibility();
			});
		}
		
		function initVisibility() {
			controlPiActionTypeVisibility();
			controlPiCounselGrievanceDecisionVisibility();
			controlPiPipSuccessfullyCompletedVisibility();
			controlPiPipExtEndDtVisibility();
			controlPiPipEndPriorToPlanVisibility();
			controlPiPipOralPresentReqVisibility();
			controlPiPipWrittenRespSubmitVisibility();
			controlPiDemotionOralPresentReqVisibility();
			controlPiDemotionWrittenRespSubmitVisibility();
			controlPiRemovalEmplPlacedNoticeLeaveVisibility();
			controlPiRemovalOralPresentReqVisibility();
			controlPiRemovalWrittenResSubmitVisibility();
		}
		
		function init() {     
			//-----------------------------------
			// visibility configuration
			//-----------------------------------
			//layout_group.forEach(function(item,index){
			//	hyf.util.hideComponent(item);
			//});
			initVisibility();
			
			
			//-----------------------------------
			// validation configuration
			//-----------------------------------
			dateFieldsPastPresent.forEach(function(item){
				hyf.calendar.setDateConstraint(item, 'Maximum', 'Today');
			});
			dateFieldsPresentFuture.forEach(function(item){
				hyf.calendar.setDateConstraint(item, 'Minimum', 'Today');
			});
			CommonOpUtil.dynamicMandatory(reqFieldForActivity);
			
			
			//-----------------------------------
			// event handler configuration
			//-----------------------------------
			initEventHandlers();
			
			
			//-----------------------------------
			// custom ui element initialization
			//-----------------------------------
			
			// multi-date selection for Extended PIP End Date
			var pipExtDtOption = {
				dataElemId: 'PI_PIP_EXT_DT',
				dispElemId: 'PI_PIP_EXT_DT_DISP',
				inputElemId: 'PI_PIP_EXT_END_DT',
				btnElemId: 'btnAddExtPipEndDt',
				//minSelectCount: 0,
				minSelectCount: 0
				//maxSelectCount: 3
			};
			var pipExtDtMultiSelect = MultiDateSelection.setupMultiDateSelection(pipExtDtOption);
			var initPiPipExtDtVal = $('#PI_PIP_EXT_DT').val();
			if (initPiPipExtDtVal == null || initPiPipExtDtVal.trim().length <= 0){
				var piPipExtDtValState = FormState.getState('PI_PIP_EXT_DT');
				if (typeof piPipExtDtValState != 'undefined' && piPipExtDtValState != null){
					initPiPipExtDtVal = piPipExtDtValState.value;
				}
			}
			pipExtDtMultiSelect.refreshData(initPiPipExtDtVal);
		}
		
		function render() {
			/*
			//var actionType = FormState.getState('PI_ACTION_TYPE');
			//var piCnslGrvDecision = FormState.getState('PI_CNSL_GRV_DECISION');
			//var piPipEndPriorToPlan = FormState.getState('PI_PIP_END_PRIOR_TO_PLAN');
			//var piPipSuccessCmplt = FormState.getState('PI_PIP_SUCCESS_CMPLT');
			//var piPipOralPresReq = FormState.getState('PI_PIP_ORAL_PRSNT_REQ');
			//var piPipWrtnRespSbmt = FormState.getState('PI_PIP_WRTN_RESP_SBMT');
			var piPipEmplGrievance = FormState.getState('PI_PIP_EMPL_GRIEVANCE');
			//var piDmtnOralPrsntReq = FormState.getState('PI_DMTN_ORAL_PRSNT_REQ');
			//var piDmtnWrtnRespSbmt = FormState.getState('PI_DMTN_WRTN_RESP_SBMT');
			//var piRemvEmplNotcLev = FormState.getState('PI_REMV_EMPL_NOTC_LEV');
			//var piRemvOralPrsntReq = FormState.getState('PI_REMV_ORAL_PRSNT_REQ');
			//var piRemvWrtnRespSbmt = FormState.getState('PI_REMV_WRTN_RESP_SBMT');
			var emp = FormState.getState('empContact');
			
			//if (piCnslGrvDecision && piCnslGrvDecision.dirty){
			//	if (piCnslGrvDecision.value === 'Y'){								
			//		hyf.util.showComponent('pi_counseling_grievance_decision_note_group');                
			//	} else {
			//		hyf.util.hideComponent('pi_counseling_grievance_decision_note_group');                
			//	}
			//}
			if (emp && emp.dirty){
				PerfIssueUtil.PI_populateCurrentPosition(emp.value);		
			}
			//if (actionType && actionType.dirty){
			//	PerfIssueUtil.showCaseView('pi_action_'+ actionType.text.toLowerCase().replace(/\s/g, '_') + '_group', layout_group);
			//}
			//if (piPipEndPriorToPlan && piPipEndPriorToPlan.dirty){
			//	CommonOpUtil.hyfShowOrHide(piPipEndPriorToPlan, 'pi_pip_end_prior_to_plan_group');
			//}
			//if (piPipSuccessCmplt && piPipSuccessCmplt.dirty){
			//	CommonOpUtil.hyfShowOrHide(piPipSuccessCmplt, 'pi_pip_success_complete_rsn_group');
			//}
			//if (piPipOralPresReq && piPipOralPresReq.dirty){
			//	CommonOpUtil.hyfShowOrHide(piPipOralPresReq, 'pi_pip_oral_present_detail_group');
			//}
			//if (piPipWrtnRespSbmt && piPipWrtnRespSbmt.dirty){
			//	CommonOpUtil.hyfShowOrHide(piPipWrtnRespSbmt, 'pi_pip_written_resp_detail_group');
			//}
			if (piPipEmplGrievance && piPipEmplGrievance.dirty){
				CommonOpUtil.hyfShowOrHide(piPipEmplGrievance, 'start_grievance_case_note');
			}
			//if (piDmtnOralPrsntReq && piDmtnOralPrsntReq.dirty){
			//	CommonOpUtil.hyfShowOrHide(piDmtnOralPrsntReq, 'pi_demotion_oral_present_detail_group');
			//}
			//if (piDmtnWrtnRespSbmt && piDmtnWrtnRespSbmt.dirty){
			//	CommonOpUtil.hyfShowOrHide(piDmtnWrtnRespSbmt, 'pi_demotion_written_resp_detail_group');
			//}
			//if (piRemvEmplNotcLev && piRemvEmplNotcLev.dirty){
			//	CommonOpUtil.hyfShowOrHide(piRemvEmplNotcLev, 'pi_removal_notice_leave_detail_group');
			//}
			//if (piRemvOralPrsntReq && piRemvOralPrsntReq.dirty){
			//	CommonOpUtil.hyfShowOrHide(piRemvOralPrsntReq, 'pi_removal_oral_present_detail_group');
			//}
			//if (piRemvWrtnRespSbmtVal && piRemvWrtnRespSbmtVal.dirty){
			//	CommonOpUtil.hyfShowOrHide(piRemvWrtnRespSbmtVal, 'pi_removal_written_resp_detail_group');
			//}
			if (!initialized){
				//FormAutoComplete.setAutoComplete('PIP_deciding_official', '/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=', PerfIssueUtil.populateOfficial, CommonOpUtil.responseMapper, CommonOpUtil.appendEmplInfo);
				//FormAutoComplete.setAutoComplete('PI_demotion_official', '/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=', PerfIssueUtil.populateOfficial, CommonOpUtil.responseMapper, CommonOpUtil.appendEmplInfo);
				//FormAutoComplete.setAutoComplete('PI_removal_official', '/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=', PerfIssueUtil.populateOfficial, CommonOpUtil.responseMapper, CommonOpUtil.appendEmplInfo);
				//FormAutoComplete.setAutoComplete('PI_reassignment_final_code', '/bizflowwebmaker/cms_erlr_service/contactInfo.do?admin=', PerfIssueUtil.populateAdminCode, CommonOpUtil.adminCodeResponseMapper, CommonOpUtil.appendAdminCode);
				
				//PerformanceIssue.initialized = true;
			}
			*/
		}
		
		
		return {
			initialized: initialized,
			reqFieldForActivity: reqFieldForActivity,
			render: render,
			init: init
		};
	};

    var _initializer = window.cms_perf_issue || (window.cms_perf_issue = cms_perf_issue());
})(window);



(function(window){
	
	var PerfIssueUtil = function(){
		
		function PI_populateCurrentPosition(item){
			var currentPosition = item.split(',');
			$('#PI_demotion_pos_title').text(currentPosition[8]);
			$('#PI_demotion_payplan').text(currentPosition[6]);
			$('#PI_demotion_job_series').text(currentPosition[7]);
			$('#PI_demotion_step').text(currentPosition[4]);
			$('#PI_demotion_grade').text(currentPosition[5]);  //curr_admin_code
			$('#PI_reassignment_curr_code').text(currentPosition[2]);
		}

		function showCaseView(caseValue, arr){
			arr.forEach(function(el, index){
				if (el === caseValue){  
					hyf.util.showComponent(el);	
				} else {
					$('#' + el).find('input:text').val('');		
					hyf.util.hideComponent(el);
				}			
			});
		}
		
		
		//TODO: implement
		function populateOfficial(item, id){
			//if(id ==='CI_APPROVAL_NAME' && (item.last_name !==''||item.first_name !=='')){
			//	$('#CI_APPROVAL_NAME').val(item.last_name +','+item.first_name +'('+item.email+')');
			//}
			return;
		}
		
		//TODO: implement
		function populateAdminCode(item, id){
			return;
		}
		
		
		
		return {
			PI_populateCurrentPosition: PI_populateCurrentPosition,
			showCaseView: showCaseView,
			populateOfficial: populateOfficial,
			populateAdminCode: populateAdminCode
		};
	};
	
    var _initializer = window.PerfIssueUtil || (window.PerfIssueUtil = PerfIssueUtil());
})(window);


