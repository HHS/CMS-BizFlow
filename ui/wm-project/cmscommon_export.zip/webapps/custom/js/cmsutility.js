/* eslint yoda:0, operator-linebreak:0 */

var CMSUtility = {
    autoCompletionBaseURL: '/bizflowwebmaker/StratCon_AUT/',
    showDebugLog: false,
    showErrorLog: false,
    showInfoLog: false,
    debugLog: function (message) {
        if (CMSUtility.showDebugLog === true) {
            if (console && console.log) {
                console.log('DEBUG: ' + message);
            }
        }
    },
    errorLog: function (message) {
        if (CMSUtility.showErrorLog === true) {
            if (console && console.log) {
                console.log('ERROR: ' + message);
            }
        }
    },
    infoLog: function (message) {
        if (CMSUtility.showInfoLog === true) {
            if (console && console.log) {
                console.log('INFO: ' + message);
            }
        }
    },

    getAnchorID: function (tabID) {
        return 'tab_control_tab_' + tabID;
    },
    getTabIDFromAnchor: function (node) {
        if (node != null && node.id != null) {
            var lastIndex = node.id.lastIndexOf('_');
            if (lastIndex >= 0) {
                return node.id.substring(lastIndex + 1);
            }
        }
        return null;
    },
    getTabIDFromAnchorID: function (node) {
        if (node != null && node.length > 0) {
            var lastIndex = node.lastIndexOf('_');
            if (lastIndex >= 0) {
                return node.substring(lastIndex + 1);
            }
        }
        return null;
    },
    // dateFormat can include yyyy mm dd hh MM ss pattern and these pattern will be replaced by real values.
    // yyyy - 4 digit year, mm - month, dd - day, hh - hours, MM - minutes, ss - seconds
    formatDateString: function (dateFormat, yyyy, mm, dd, hh, MM, ss) {
        if (dateFormat == null || dateFormat.length === 0) {
            dateFormat = 'mm/dd/yyyy';
        }
        var dateString = dateFormat;
        if (yyyy != null && yyyy.length > 0) {
            dateString = dateString.replace(/yyyy/, yyyy);
        }
        if (mm != null && mm.length > 0) {
            dateString = dateString.replace(/mm/, mm);
        }
        if (dd != null && dd.length > 0) {
            dateString = dateString.replace(/dd/, dd);
        }
        if (hh != null && hh.length > 0) {
            var amPM = 'AM';
            dateString = dateString.replace(/HH/, hh);
            var hh12 = hh;
            if (hh12 >= 12) {
                amPM = 'PM';
                hh12 = (hh12 > 12) ? (hh12 - 12) : hh12;
                hh12 = '' + hh12;
                hh12 = (hh12.length === 1) ? ('0' + hh12) : hh12;
            }
            dateString = dateString.replace(/hh/, hh12);
            dateString = dateString.replace(/a/, amPM);
        }
        if (MM != null && MM.length > 0) {
            dateString = dateString.replace(/MM/, MM);
        }
        if (ss != null && ss.length > 0) {
            dateString = dateString.replace(/ss/, ss);
        }
        dateString = dateString.replace(/yyyy/, '');
        dateString = dateString.replace(/mm/, '');
        dateString = dateString.replace(/dd/, '');
        dateString = dateString.replace(/hh/, '');
        dateString = dateString.replace(/MM/, '');
        dateString = dateString.replace(/ss/, '');
        return dateString;
    },
    //
    // option : {
    //     isUTC: true // true or false
    //     dateFormat: "yyyy/mm/dd"    // The patterns yyyy mm dd hh MM ss will be replaced with real values.
    // }
    //
    getDateString: function (option, when) {
        var year, month, day, hours, minutes, seconds;
        if (option.isUTC === true) {
            year = when.getUTCFullYear();
            month = when.getUTCMonth() + 1;
            day = when.getUTCDate();
            hours = when.getUTCHours();
            minutes = when.getUTCMinutes();
            seconds = when.getUTCSeconds();
        } else {
            year = when.getFullYear();
            month = when.getMonth() + 1;
            day = when.getDate();
            hours = when.getHours();
            minutes = when.getMinutes();
            seconds = when.getSeconds();
        }
        if (month < 10) {
            month = '0' + month;
        }
        if (day < 10) {
            day = '0' + day;
        }
        if (hours < 10) {
            hours = '0' + hours;
        }
        if (minutes < 10) {
            minutes = '0' + minutes;
        }
        if (seconds < 10) {
            seconds = '0' + seconds;
        }
        year = '' + year;
        month = '' + month;
        day = '' + day;
        hours = '' + hours;
        minutes = '' + minutes;
        seconds = '' + seconds;
        return CMSUtility.formatDateString(option.dateFormat, year, month, day, hours, minutes, seconds);
    },
    getNowUTCString: function () {
        var now = new Date();
        return CMSUtility.getDateString({isUTC: true, dateFormat: 'yyyy/mm/dd hh:MM:ss'}, now);
    },
    // The parameter "components" is array of component IDs.
    enableComponents: function (components) {
        if (components != null && components.length > 0) {
            components.forEach(function (component) {
                hyf.util.enableComponent(component);
				$('#' + component + ' img[src="/bizflowwebmaker/StratCon_AUT/custom/images/delete-icon.png"]').show();
            });
        }
    },
    // The parameter "components" is array of component IDs.
    disableComponents: function (components) {
        if (components != null && components.length > 0) {
            components.forEach(function (component) {
                hyf.util.disableComponent(component);
				$('#' + component + ' img[src="/bizflowwebmaker/StratCon_AUT/custom/images/delete-icon.png"]').hide();
            });
        }
    },
    existInArray: function (array, targetItem) {
        var found = false;
        if (array) {
            var foundItems;
            if (typeof targetItem === 'function') {
                foundItems = array.filter(targetItem);
            } else {
                foundItems = array.filter(function (item) {
                    return item === targetItem;
                });
            }
            if (foundItems && foundItems.length > 0) {
                found = true;
            }
        }
        return found;
    },
    /**
     * Event handler code generated by WebMaker when exit WIH action is used in Event tab of the WM Studio.
     * Moved the implementation here so as to have better development control over the event handler.
     * @param btnId - element id of the exit button
     */
    exitWitemHandler: function (btnId) {
        var evt = (window.event) ? window.event : e;
        var sourceComponent = null;
        if ((evt != null) && (typeof (evt) !== 'undefined')) {
            sourceComponent = (evt.target) ? evt.target : evt.srcElement;
            if ((sourceComponent != null) && (sourceComponent.nodeType === 3)) { // defeat Safari bug
                sourceComponent = sourceComponent.parentNode;
            }
        }
        var objEventSource = {
            name: 'EventSource',
            option: 'field',
            event: evt,
            component: sourceComponent,
            value: btnId,
            field: document.getElementById(btnId)
        };
        return dojo.hitch(objEventSource.field, function () {
            var objWIHAction = {name: 'WIHAction', option: 'WIHAction', value: 'exit'};
            var objResponse = {name: 'Response', option: 'Default', value: ''};
            hyf.HSGAction.handleWIHAction(objWIHAction, objResponse, objEventSource);
        })();
    },
    initMaxSizePerTab: function (tabID) {
        var inputControls = $('#' + tabID + ' input[size]');
        $.each(inputControls, function (index, control) {
            var maxSize = $(control).attr('size');
            var id = $(control).attr('id');
            var controlType = $(control).attr('_type');
            var alwaysReadonly = $('control').attr('alwaysReadonly');
            var alwaysDisabled = $('control').attr('alwaysDisabled');

            // Skip if the control is date control
            if (controlType !== 'date' && typeof id !== 'undefined' && !alwaysReadonly && !alwaysDisabled) {
                if ($(control).parent().length === 1
                    && $(control).parent().parent().length === 1
                    && $(control).parent().parent().parent().length === 1) {
                    var initialMessage = $(control).val();
                    var target;
                    if ($(control).hasClass('dijitInputInner')) {
                        target = $(control).parent().parent().parent();
                    } else {
                        target = $(control).parent().parent();
                    }
                    if (target.find('p.sizeLabel').length === 0) {
                        target.append('<p id="' + (id + '_sizeLabel') + '" class="sizeLabel" debugMessage="' + initialMessage + '">(Now: ' + initialMessage.length + ' / Max: ' + maxSize + ')</p>');
                        $('#' + id + '_sizeLabel').hide();
                        $(control).on('focus', function () {
                            var disabled = $(this).attr('disabled');
                            var readonly = $(this).prop('readonly');
                            if (!disabled && !readonly) {
                                $('#' + id + '_sizeLabel').show();
                            }
                        });
                        $(control).on('blur', function () {
                            $('#' + id + '_sizeLabel').hide();
                        });
                        $(control).on('keyup paste blur change', function () {
                            var message = $(control).val();
                            if (message.length > maxSize) {
                                $(control).val(message.substring(0, maxSize));
                            }
                            $('#' + id + '_sizeLabel').text('(Now: ' + message.length + ' / Max: ' + maxSize + ')');
                        })
                    }
                }
            }
        });

        inputControls = $('#' + tabID + ' textarea.textbox[maxlength]');
        $.each(inputControls, function (index, control) {
            var maxSize = $(control).attr('maxlength');
            var id = $(control).attr('id');
            var alwaysReadonly = $('control').attr('alwaysReadonly');
            var alwaysDisabled = $('control').attr('alwaysDisabled');
            if ($(control).parent().length === 1 && typeof id !== 'undefined' && !alwaysReadonly && !alwaysDisabled) {
                var initialMessage = $(control).val();
                if ($(control).parent().find('p.sizeLabel').length === 0) {
                    $(control).parent().append('<p id="' + (id + '_sizeLabel') + '" class="sizeLabel">(Now: ' + initialMessage.length + ' / Max: ' + maxSize + ')</p>');
                    $('#' + id + '_sizeLabel').hide();
                    $(control).on('focus', function () {
                        var disabled = $(this).attr('disabled');
                        var readonly = $(this).prop('readonly');
                        if (!disabled && !readonly) {
                            $('#' + id + '_sizeLabel').show();
                        }
                    });
                    $(control).on('blur', function () {
                        $('#' + id + '_sizeLabel').hide();
                    });
                    $(control).on('keyup keypress blur change', function () {
                        var message = $(control).val();
                        $('#' + id + '_sizeLabel').text('(Now: ' + message.length + ' / Max: ' + maxSize + ')');
                    })
                }
            }
        });
    },
    setDateIconTabOrder: function () {
        var dateTextBoxes = $('input.textbox[_type=date]');
        $.each(dateTextBoxes, function (index, control) {
            var tabIndex = $(control).attr('tabindex');
            if ($.isNumeric(tabIndex) === true && tabIndex > 0) {
                var controlID = $(control).attr('id');
                var newTabIndex = tabIndex * 1 + 1;
                $('#' + controlID + '_calendar_anchor').attr('tabindex', newTabIndex);
            }
        });
    },
    callPartialPage: function (o, action, sourceGroup, targetGroup) {
        if (window.location.pathname.indexOf('bizflowwebmaker') > -1 && action.indexOf('/') === 0) {
            action = '/bizflowwebmaker' + action;
        }
        var objEventSource5 = {
            name: 'EventSource',
            optio: 'field',
            even: null,
            componen: null,
            value: targetGroup,
            field: dojo.byId(targetGroup)
        };
        var objAction = {
            name: 'Action',
            option: 'Action',
            value: action
        };
        var objSourceGroup = null;
        if (null === sourceGroup || '' === sourceGroup || 'all' === sourceGroup || 'ALL' === sourceGroup) {
            objSourceGroup = {name: 'SourceGroup', option: 'AllFormData', value: ''};
        } else {
            objSourceGroup = {name: 'SourceGroup', option: 'PageGroup', value: sourceGroup};
        }
        var objTargetGroup = {
            name: 'TargetGroup',
            option: 'PageGroup',
            value: targetGroup
        };
        var objValidate = {
            name: 'Validate',
            option: 'Static',
            value: 'false'
        };
        hyf.FMAction.handleAjaxSubmission(objAction, objSourceGroup, objTargetGroup, objValidate, objEventSource5);
    },
    submitFormPage: function (o, action) {
        var e = (typeof (event) !== 'undefined') ? event : arguments[0];
        var evt = (window.event) ? window.event : e;
        var sourceComponent = null;
        if ((evt != null) && (typeof (evt) !== 'undefined')) {
            sourceComponent = (evt.target) ? evt.target : evt.srcElement;
            if ((sourceComponent != null) && (sourceComponent.nodeType === 3)) { // defeat Safari bug
                sourceComponent = sourceComponent.parentNode;
            }
        }
        var objId = null;
        if (o !== 'undefined' && o != null && o.id !== 'undefined' && o.id != null) {
            objId = o.id;
        }
        var objEventSource = {
            name: 'EventSource',
            option: 'field',
            event: evt,
            component: sourceComponent,
            value: objId,
            field: document.getElementById(objId)
        };
        return dojo.hitch(objEventSource.field, function () {
            var objAction = {
                name: 'Action',
                option: 'Action',
                value: action
            };
            var objValidate = {
                name: 'Validate',
                option: 'Static',
                value: 'false'
            };
            hyf.FMAction.handleFormSubmission(objAction, objValidate, objEventSource);
        })();
    },
    enableAllFields: function () {
        CMSUtility.setAllFieldsEnabledDisabled('enable');
    },
    disableAllFields: function () {
        CMSUtility.setAllFieldsEnabledDisabled('disable');
    },
    setAllFieldsEnabledDisabled: function (mode) {
        // mode: disable, enable
        if ('disable' === mode) {
            $('input').attr('disabled', 'disabled');
            $('select').attr('disabled', 'disabled');
            $('textarea').attr('disabled', 'disabled');
        } else {
            $('input').removeAttr('disabled');
            $('select').removeAttr('disabled');
            $('textarea').removeAttr('disabled');
        }
    },
    // Grey out screen and prevent from user input
    greyOutScreen: function (mode, messageBody) {
        try {
            if (mode) {
                if (null == messageBody || '' === messageBody) {
                    messageBody = "<p style='font-size:30px;color:white;'>Please wait...</p>";
                }
                CMSUtility.blockScreen(messageBody);
            } else {
                CMSUtility.unblockScreen();
            }
        } catch (e) {}
    },

    blockScreen: function (messageContent) {
        if (null == messageContent || '' === messageContent) {
            messageContent = 'Please wait...';
        }
        $.blockUI({
            message: messageContent,
            css: {
                border: 'none',
                padding: '20px',
                backgroundColor: '#000',
                '-webkit-border-radius': '15px',
                '-moz-border-radius': '15px',
                opacity: 0.5,
                color: '#000'
        } });
    },
    unblockScreen: function (waitTime) {
        if (null == waitTime) {
            waitTime = 500;
        }
        $.unblockUI({ fadeOut: waitTime });
    },
    getAutoCompRemoveIconElement: function (target, targetDescription, tabIndex) {
        var elementString = '<img src="' + CMSUtility.autoCompletionBaseURL + 'custom/images/delete-icon.png' +
                    '" id="delete-' + target + '" deleteId="' + target +
                    '" title="Remove ' + targetDescription + '" tabindex="' + tabIndex + '" /> ';
        return elementString;
    },
    _readOnly: null,
    isReadOnly: function() {
        if (CMSUtility._readOnly == null) {
            CMSUtility._readOnly = $('#h_readOnly').val();
            if (CMSUtility._readOnly == 'y') {
                CMSUtility._readOnly = true;
            } else {
                CMSUtility._readOnly = false;
            }
        }
        return CMSUtility._readOnly;
    },
    
    isSpecialProgramValue: function(requestType, appointmentType) {
        var result = false;
        if (requestType == 'Appointment') {
            var specialPrograms = ['30% or more disabled veterans', 'Veteran Recruitment Appointment (VRA)', 'Volunteer', 'Schedule A']; // HRB-1427
            var foundProgram = CMSUtility.existInArray(specialPrograms, appointmentType);
            if (foundProgram == true) {
                CMSUtility.debugLog('CMSUtility.isSpecialProgramValue - This is Special Program.');
                result = true;
            }
        }
        return result;

    },
    isSpecialProgram: function(requestTypeID, appointmentTypeID) {
        var requestType = $('#' + requestTypeID + ' :selected').text();
        var appointmentType = $('#' + appointmentTypeID + ' :selected').text();
        return CMSUtility.isSpecialProgramValue(requestType, appointmentType);
    },	
	isMeetingTabRequired: function() {
        var requestType = $('#SG_RT_ID :selected').text();
        var appointmentType = $('#SG_AT_ID :selected').text();
        var classificationType = $('#SG_CT_ID :selected').text();
        var appointmentTypesToHide = ['Volunteer', 'Intergovernmental Personnel Act (IPA)', 'Expert/Consultant'];
        var classificationTypesToHide = ['Conduct 5-year Recertification','Update Coversheet','Review Existing Position Description'];

        var meetingRequired = true;

        if (requestType == 'Appointment') {
            if (appointmentType && appointmentType.length > 0 && CMSUtility.existInArray(appointmentTypesToHide, appointmentType)) {
                meetingRequired = false;
            } else if (classificationType && classificationType.length > 0 && CMSUtility.existInArray(classificationTypesToHide, classificationType)) {
                meetingRequired= false;
            }
        }
        return meetingRequired;
    },
    shouldNotifyHR: function() {
        var requestType = $('#SG_RT_ID :selected').text() || '';
        var appointmentType = $('#SG_AT_ID :selected').text() || '';
        var classificationType = $('#SG_CT_ID :selected').text() || '';
        var appointmentTypesToNotify = ['Intergovernmental Personnel Act (IPA)', 'Expert/Consultant'];
        var classificationTypesToNotify = ['Conduct 5-year Recertification','Update Coversheet','Review Existing Position Description'];
        var notifyHR = false;

        if (requestType && requestType == 'Appointment') {
            var foundAppointmentType = CMSUtility.existInArray(appointmentTypesToNotify, appointmentType);
            var foundClassificationTyupe = CMSUtility.existInArray(classificationTypesToNotify, classificationType);
            if ( foundAppointmentType == true &&  foundClassificationTyupe == true) {
                notifyHR = true;
            }
        }

        return notifyHR;
    },
	/**
	 * Initializes multi-select elements for the given select element (dropdown).
	 * 
	 * @param initOption - the object that specifies options for the multi-select element.  It can specify the following options. 
	 *
	 *		id: string - id of the input element (i.e. a hidden element) that stores the selected values.
	 *
	 *		tabindex: number - tabindex for the input element.  Optional.  
	 *			If specified, the same value will be used for the subsequent selected elements.  
	 *			If omitted, the selected elements will not have tab focus.
	 *
	 *		minSelectionCount: number - the minimum number of selection to be made.  
	 *			Set to 0 if not a required field.
	 *
	 *		maxSelectionCount: number - the maximum number of selection allowed.  
	 *			If the number of selected items reaches this, the input element (dropdown) will be hidden.
	 *
	 *		getSelectionLabel: function - callback function definition that should return the string for the displayed value of the selected item.
	 *
	 *		getItemID: function - callback function definition that should return the string for the stored value of the selected item.
	 *
	 *		initialItems: array of item - item is an object that has data that will be used for constructing the stored value and displayed value.
	 *			The structure of the item should be coordinated with the callback functions in the initOption object.
	 *
	 *		setDataToForm: function - callback function definition that should perform any actions to set data for persistence.
	 *
	 *	For example, 
	 *		{
	 *			id: 'PD_CYB_SEC_CD',
	 *			tabindex: 204,
	 *			minSelectionCount: 1,
	 *			maxSelectionCount: 3, 
	 *			getSelectionLabel: function(item) {
	 *				return item.label
	 *			},
	 *			getItemID: function(item) {
	 *				return item.id;
	 *			},
	 *			initialItems: cybersecInitialData,
	 *			setDataToForm: function(values) {
	 *				var Ids = values.reduce(function(accumulator, currentValue, currentIndex, array) {
	 *					return (accumulator && accumulator.length > 0) ? accumulator + ',' + currentValue.id : currentValue.id;
	 *				}, '');
	 *				$('#PD_CYB_SEC_CD').val(Ids);
	 *			}
	 *		}
	 *		
	 * @return an object that reflects the data and callback functions used for the multi-select element.
	 *	{
	 *		option: option,
	 *		inputID: inputID,
	 *		selectedElementID: selectedElementID,
	 *		inputContainer: inputContainer,
	 *		selectedValues: selectedValues,
	 *		select: select,
	 *		deleteItem: deleteItem
	 *	}
	 *
	 */
	initMultiSelect: function(initOption) {
		if (initOption == null) {
			console.log('Invalid option. Option is null.');
			return;
		}
		if (initOption.id == null || typeof initOption.id !== 'string' || initOption.id.length <= 0) {
			console.log('Invalid option. option.id should be string and cannot be blank.');
			return;
		}
		if (initOption.getItemID == null || typeof initOption.getItemID !== 'function') {
			console.log('Invalid option. option.getItemID is required and mandatory.');
			return;
		}
		if (initOption.getSelectionLabel == null || typeof initOption.getSelectionLabel !== 'function') {
			console.log('Invalid option. option.getSelectionLabel is required and mandatory.');
			return;
		}
		if (initOption.setDataToForm == null || typeof initOption.setDataToForm !== 'function') {
			console.log('Invalid option. option.setDataToForm is required and mandatory.');
			return;
		}
		
		var option = initOption;
		var inputID = option.id + "_SEL";
		var selectedElementID = inputID + '_DISP';
		var inputContainer = inputID + '_container';
		var separator = option.separator || ',';
		var selectedValues = [];

		option.minSelectionCount = option.minSelectionCount || 1;
		option.maxSelectionCount = option.maxSelectionCount || 1;

		var footerHTML = '<div class="customControl"><ul class="hidden nobullet autocomplete_ul" id="___UL___" /></div>';
		footerHTML = footerHTML.replace('___UL___', selectedElementID);
		$('#' + inputContainer).parent().parent().append(footerHTML);

		var getListItemHTML = function(targetID, targetLabel, tabIndex) {
			var elementString = "";
			if (CMSUtility.isReadOnly() == true) {
				elementString = '<li id="' + targetID + '">' + targetLabel + '</li>';
			} else {
				elementString = "<li id=\"" + targetID + "\"><img src=\"/bizflowwebmaker/StratCon_AUT/custom/images/delete-icon.png"
				+ "\" id=\"delete-" + targetID + "\" deleteId=\"" + targetID
				+ "\" title=\"Remove " + targetLabel + "\" tabindex=\"" + tabIndex + "\" />" + targetLabel + "</li>";
			}
			return elementString;
		}

		var sortSelectedValues = function() {
			if (selectedValues && selectedValues.length > 1) {
				if (option.compare != null && typeof option.compare === 'function') {
					selectedValues.sort(option.compare);
				} else {
					selectedValues.sort(function(a,b) {
						return option.getSelectionLabel(a) > option.getSelectionLabel(b);
					});
				}
			}
		}

		var setDataToForm = function() {
			option.setDataToForm(selectedValues);
		}

		var display = function() {
			var count = selectedValues.length
			if (count > 0) {
				$('#' + selectedElementID + ' li').each(function() {
					$(this).remove();
				});
			}
			for (var index = 0; index < count; index++) {
				var itemID = option.getItemID(selectedValues[index]);
				var itemLabel = option.getSelectionLabel(selectedValues[index])
				var listItemHTML = getListItemHTML(itemID, itemLabel, option.tabindex);
				$('#' + selectedElementID).append(listItemHTML);
			}
			$('#' + selectedElementID).removeClass('hidden');
			if (count >= option.maxSelectionCount) {
				$('#' + inputContainer).addClass('hidden');
			}
			if (count >= option.minSelectionCount) {
				$('#' + inputID).attr('_required', 'false');
			}
		}
		
		var select = function() {
			var currentItem = {
				id: $('#' + inputID + ' option:selected').val(),
				label: $('#' + inputID + ' option:selected').text()
			};
			var found = false;
			for (var valueIndex = 0; valueIndex < selectedValues.length; valueIndex++) {
				var foundID = option.getItemID(selectedValues[valueIndex]);
				if (foundID === currentItem.id) {
					found = true;
					break;
				}
			}

			if (found === false) {
				selectedValues.push(currentItem);
				var count = selectedValues.length;
				sortSelectedValues();
				display();
				setDataToForm();  // Call form to save selected values after addition
				$('#' + inputID + ' option:selected').prop('selected', false);  // unselect the dropdown
			}
		};

		var deleteItem = function(e) {
			var count = selectedValues.length;
			var targetID = $(e.currentTarget).attr('deleteid');
			var found = false;

			for (var valueIndex = 0; valueIndex < selectedValues.length; valueIndex++) {
				var foundID = option.getItemID(selectedValues[valueIndex]);
				if (foundID === targetID) {
					found = true;
					break;
				}
			}

			if (found) {    
				for (var index = 0; index < count; index++) {
					if (targetID === option.getItemID(selectedValues[index])) {
						selectedValues.splice(index, 1);
						count -= 1;
						break;
					}
				}

				$('#' + selectedElementID + ' li[id="' + targetID + '"]').remove();
				setDataToForm();  // Call form to save changed values after removal
				$('#' + inputContainer).removeClass('hidden');

				if (count == 0) {
					$('#' + selectedElementID).addClass('hidden').empty();
				}
				if (count < option.minSelectionCount) {
					$('#' + inputID).attr('_required', 'true');
				}
			}
		};

		$('#' + inputID).on('change', function(){
			select();
		});

		if (CMSUtility.isReadOnly() == false) {
			$('#' + selectedElementID).delegate("img", "click keyup", function (e) {
				if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
					deleteItem(e);
				}
			});
		}

		// if there is initial items, build selected item list to display
		if (option.initialItems && typeof option.initialItems === 'object') {
			var count = option.initialItems.length
			var isEmpty = true;
			for (var index = 0; index < count; index++) {
				var ui = {};
				ui.item = option.initialItems[index];

				for (var key in ui.item) {
					if (ui.item.hasOwnProperty(key)) {
						var data = ui.item[key];
						if (typeof data == 'string' && data.length > 0) {
							isEmpty = false;
							break;
						}
					}
				}
			}
			if(!isEmpty){
				selectedValues = option.initialItems.slice();
				sortSelectedValues();
				display();
			}
		}

		if (CMSUtility.isReadOnly() == true) {
			$('#' + inputContainer).addClass('hidden');
		}

		console.log('Multiselect is initialized!! - ' + option.id);
		return {
			option: option,
			inputID: inputID,
			selectedElementID: selectedElementID,
			inputContainer: inputContainer,
			selectedValues: selectedValues,
			select: select,
			deleteItem: deleteItem
		};
	}
	// end of initMultiSelect
};

