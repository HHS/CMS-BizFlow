//-----------------------------------------------------------
// BizFlow AngularJS Wrapper
//-----------------------------------------------------------
function initCommentTab() {
//-----------------------------------------------------------
// BizFlow.app Controller
//-----------------------------------------------------------
(function (angular) {
    "use strict";

angular.module("bizflow.app", [
    'ngSanitize'
    ,'blockUI'
    ,'ngAnimate'
    ,'ngCookies'
    ,'inform'
    ,'inform-exception'
    ,'ui.bootstrap'
    ,'ui.select'
    ,'ui.grid'
    ,'ui.grid.selection'
    ,'ui.grid.pagination'
    ,'ui.grid.autoResize'
    ,'ui.grid.resizeColumns'
    ,'ngMessages'
    ,'bizflow.angular.context'
    ,'bizflow.angular.wih'
    ,'bizflow.angular.component'
    ,'bizflow.app.common'])
    .factory('timeoutHttpIntercept', function (inform) {
        return {
            "request" : function(config) {
                config.timeout = 600000; //increase timeout for Excel download operation
                return config;
            },
            "responseError" : function(responseError) {
                if( responseError.status == -1 || responseError.status == 499 || responseError.status == 598 || responseError.status == 599 ) {
                    inform.add('Error: Time out', {type: "danger"})
                }
                return responseError;
            }
        };
    })
    .config(['$httpProvider', 'blockUIConfig', 'bizflowContextProvider', 'informProvider', '$compileProvider', '$logProvider',
        function ($httpProvider, blockUIConfig, bizflowContextProvider, informProvider, $compileProvider, $logProvider) {
            //Turn on or off debugging message
            $logProvider.debugEnabled(true);
            bizflowContextProvider.custom.debugEnabled = $logProvider.debugEnabled();
            bizflowContextProvider.custom.formStyle = "tab";

            $httpProvider.interceptors.push('timeoutHttpIntercept');


            blockUIConfig.autoBlock = true;
            blockUIConfig.delay = 0;
            blockUIConfig.message = "Please Wait...";
            // Disable auto body block(This is important! if it's value is true then browser will be flickering on ie 9 and ie 10)
            blockUIConfig.autoInjectBodyBlock = false;
            // ... don't block it.
            blockUIConfig.requestFilter = function (config) {
            };

            //Need to change bizflowsrs context patch if it is not default value bizflowsrs
            bizflowContextProvider.setServiceContextPath("/bizflowsrs/services");
            bizflowContextProvider.setDataServiceContextPath("/bizflowsrs/services");
            bizflowContextProvider.setAppContextPath("/app");

            informProvider.defaults({ttl:0, type: 'danger'});

            //need to set as false for PRODUCTION SERVER to speed up
            //https://docs.angularjs.org/guide/production
            $compileProvider.debugInfoEnabled(false);
        }
    ])
    .controller('CtrlCommentMain', function($scope, $location, bizflowContext, $document, $window, $rootScope, $log, bizflowWih, $timeout) {
        CMSUtility.debugLog('cmscommon - bizflow.app - CtrlCommentMain - controller START');

        var vm = this;
        vm.bizflowContext = bizflowContext;

        $scope.$ctrl = vm;
        $scope.isContextLoaded = true;

        //trigger destroy events for all children when window is switched or closed
        $window.onbeforeunload = function () {
            $rootScope.$destroy();
        };
        $scope.$on('$destroy', function () {
        });

        //Prevent backspace from navigating back in AngularJS in IE
        $document.on('keydown', function(event){
            if (event.keyCode === 8) {
                var doPrevent = true;
                var types = ["text", "password", "file", "search", "email", "number", "date", "color", "datetime", "datetime-local", "month", "range", "search", "tel", "time", "url", "week"];
                var d = $(event.srcElement || event.target);
                var disabled = d.prop("readonly") || d.prop("disabled");
                if (!disabled) {
                    if (d[0].isContentEditable) {
                        doPrevent = false;
                    } else if (d.is("input")) {
                        var type = d.attr("type");
                        if (type) {
                            type = type.toLowerCase();
                        }
                        if (types.indexOf(type) > -1) {
                            doPrevent = false;
                        } else if (d[0].outerHTML.indexOf("textbox") > -1) {
                            doPrevent = false;
                        } else if (d[0].outerHTML.indexOf("text-box") > -1) {
                            doPrevent = false;
                        }
                    } else if (d.is("textarea")) {
                        doPrevent = false;
                    }
                }
                if (doPrevent) {
                    event.preventDefault();
                }
            }
        });


        vm.init = function() {
            // Prevent backspace from navigating back in AngularJS in IE
            $document.on('keydown', function(event){
                if (event.keyCode === 8) {
                    var doPrevent = true;
                    var types = ["text", "password", "file", "search", "email", "number", "date", "color", "datetime", "datetime-local", "month", "range", "search", "tel", "time", "url", "week"];
                    var d = $(event.srcElement || event.target);
                    var disabled = d.prop("readonly") || d.prop("disabled");
                    if (!disabled) {
                        if (d[0].isContentEditable) {
                            doPrevent = false;
                        } else if (d.is("input")) {
                            var type = d.attr("type");
                            if (type) {
                                type = type.toLowerCase();
                            }
                            if (types.indexOf(type) > -1) {
                                doPrevent = false;
                            } else if (d[0].outerHTML.indexOf("textbox") > -1) {
                                doPrevent = false;
                            } else if (d[0].outerHTML.indexOf("text-box") > -1) {
                                doPrevent = false;
                            }
                        } else if (d.is("textarea")) {
                            doPrevent = false;
                        }
                    }
                    if (doPrevent) {
                        event.preventDefault();
                    }
                }
            });

            if (angular.isUndefined(bizflowContext.custom)) bizflowContext.custom = {};

            var absUrl = $location.absUrl();
            bizflowContext.custom.bfIntegrationMode = "workitem"; //login, bizcove, workitem
            if (bizflowWih.basicWih) {
                var workitemContext = bizflowWih.getWorkitemContext();
                bizflowContext.custom.SESSIONINFO = workitemContext.SessionInfoXML;
                bizflowContext.custom.MEMBERID = workitemContext.User.MemberID;
                bizflowContext.custom.MEMBERNAME = workitemContext.User.Name;

                bizflowContext.custom.PROCESSID = workitemContext.Process.ID;
                bizflowContext.custom.ACTIVITYSEQ = workitemContext.Activity.Sequence;
                bizflowContext.custom.ACTIVITYNAME = workitemContext.Activity.Name;
                bizflowContext.custom.WITEMSEQ = workitemContext.Workitem.Sequence;
                bizflowContext.custom.bfIntegrationMode = "workitem"; //login, bizcove, workitem
            }
        };

        vm.init();

        vm.processID = bizflowContext.custom.PROCESSID;
        vm.isReadOnly = CMSUtility.isReadOnly();

        CMSUtility.debugLog('cmscommon - bizflow.app - CtrlCommentMain - controller END');
    });
})(window.angular);
    angular.bootstrap(document.getElementById("commentSectionID"), ['bizflow.app']);
}

