function initCommentTab() {
    if (basicWIHActionClient) {
        var comments = basicWIHActionClient.getComments();
        if (comments) {
            for (var i = 0; i < comments.length; i++) {
                var ID = comments[i].commentID;
                var activityName = comments[i].activityName;
                var creatorName = comments[i].creatorName;
                var creatorID = comments[i].creatorID;
                var creationDate = comments[i].creationDate;
                var comment = comments[i].comments;

                console.log(ID + ': ' + comment + ' - by ' + creatorName + ' @ ' + creationDate + ' / ' + activityName);
            }            
        } else {
            console.log('No comments found from basicWIHActionClient');
        }
    } else {
        console.log('No basicWIHActionClient found');
    }
};