var fieldMap = {
    'SG_RT_ID': {'Consultation': 'SG_RT_ID', 'Eligibility': 'EQG_RT_ID'},
    'SG_AT_ID': {'Consultation': 'SG_AT_ID', 'Eligibility': 'EQG_AT_ID'},
    'SG_SAT_ID': {'Consultation': 'SG_SAT_ID', 'Eligibility': 'EQG_SAT_ID'},
    'SG_VT_ID': {'Consultation': 'SG_VT_ID', 'Eligibility': 'EQG_VT_ID'},
    'SG_CT_ID': {'Consultation': 'SG_CT_ID', 'Eligibility': 'EQG_CT_ID'}
}

//-----------------------------------------------------------
// BizFlow AngularJS Wrapper
//-----------------------------------------------------------
function initAttachmentTab() {
    //-----------------------------------------------------------
    // BizFlow.app Controller
    //-----------------------------------------------------------
    (function (angular) {
        "use strict";
    
    angular.module("bizflow.app", [
        'ngSanitize'
        ,'blockUI'
        ,'ngAnimate'
        ,'ngCookies'
        ,'inform'
        ,'inform-exception'
        ,'ui.bootstrap'
        ,'ui.select'
        ,'ui.grid'
        ,'ui.grid.selection'
        ,'ui.grid.pagination'
        ,'ui.grid.autoResize'
        ,'ui.grid.resizeColumns'
        ,'ngMessages'
        ,'bizflow.angular.context'
        ,'bizflow.angular.wih'
        ,'bizflow.angular.component'
        ,'bizflow.app.common'])
        .factory('timeoutHttpIntercept', function (inform) {
            return {
                "request" : function(config) {
                    config.timeout = 600000; //increase timeout for Excel download operation
                    return config;
                },
                "responseError" : function(responseError) {
                    if( responseError.status == -1 || responseError.status == 499 || responseError.status == 598 || responseError.status == 599 ) {
                        inform.add('Error: Time out', {type: "danger"})
                    }
                    return responseError;
                }
            };
        })
        .config(['$httpProvider', 'blockUIConfig', 'bizflowContextProvider', 'informProvider', '$compileProvider', '$logProvider',
            function ($httpProvider, blockUIConfig, bizflowContextProvider, informProvider, $compileProvider, $logProvider) {
                //Turn on or off debugging message
                $logProvider.debugEnabled(true);
                bizflowContextProvider.custom.debugEnabled = $logProvider.debugEnabled();
                bizflowContextProvider.custom.formStyle = "tab";
    
                $httpProvider.interceptors.push('timeoutHttpIntercept');
    
                blockUIConfig.autoBlock = true;
                blockUIConfig.delay = 0;
                blockUIConfig.message = "Please Wait...";
                // Disable auto body block(This is important! if it's value is true then browser will be flickering on ie 9 and ie 10)
                blockUIConfig.autoInjectBodyBlock = false;
                // ... don't block it.
                blockUIConfig.requestFilter = function (config) {
                };
    
                //Need to change bizflowsrs context patch if it is not default value bizflowsrs
                bizflowContextProvider.setServiceContextPath("/bizflowsrs/services");
                bizflowContextProvider.setDataServiceContextPath("/bizflowsrs/services");
                bizflowContextProvider.setAppContextPath("/app");
    
                informProvider.defaults({ttl:0, type: 'danger'});
    
                //need to set as false for PRODUCTION SERVER to speed up
                //https://docs.angularjs.org/guide/production
                $compileProvider.debugInfoEnabled(false);
            }
        ])
        .controller('CtrlAppMain', function($scope, $location, bizflowContext, $document, $window, $rootScope, $log, bizflowWih, $timeout) {
            CMSUtility.debugLog('cmscommon - bizflow.app - controller START');
    
            var vm = this;
            vm.bizflowContext = bizflowContext;
    
            $scope.$ctrl = vm;
            $scope.isContextLoaded = true;
    
            //trigger destroy events for all children when window is switched or closed
            $window.onbeforeunload = function () {
                $rootScope.$destroy();
            };
            $scope.$on('$destroy', function () {
            });
    
            //Prevent backspace from navigating back in AngularJS in IE
            $document.on('keydown', function(event){
                if (event.keyCode === 8) {
                    var doPrevent = true;
                    var types = ["text", "password", "file", "search", "email", "number", "date", "color", "datetime", "datetime-local", "month", "range", "search", "tel", "time", "url", "week"];
                    var d = $(event.srcElement || event.target);
                    var disabled = d.prop("readonly") || d.prop("disabled");
                    if (!disabled) {
                        if (d[0].isContentEditable) {
                            doPrevent = false;
                        } else if (d.is("input")) {
                            var type = d.attr("type");
                            if (type) {
                                type = type.toLowerCase();
                            }
                            if (types.indexOf(type) > -1) {
                                doPrevent = false;
                            } else if (d[0].outerHTML.indexOf("textbox") > -1) {
                                doPrevent = false;
                            } else if (d[0].outerHTML.indexOf("text-box") > -1) {
                                doPrevent = false;
                            }
                        } else if (d.is("textarea")) {
                            doPrevent = false;
                        }
                    }
                    if (doPrevent) {
                        event.preventDefault();
                    }
                }
            });

            vm.processType = 'Consultation';
            vm.definitionName = $('#h_definitionName').val();
            if (vm.definitionName.indexOf("Classification") > -1) {
                vm.processType = 'Classification';
            } else if (vm.definitionName.indexOf("Eligibility") > -1) {
                vm.processType = 'Eligibility';
            }
    
            vm.getFLSAMandatoryList = function() {
                var grades = [];
                var isFLSAExemptSelected = false;
                var isFLSANonExemptSelected = false;
    
                if (bizflowContext.custom.ACTIVITYNAME == 'Approve Coversheet and Create Final Pkg') {
                    for (var index = 1; index <= 5; index++) {
                        var IDPredicate = '#CS_GR_ID_' + index + ' option:selected';
                        var grade = $(IDPredicate).text();
    
                        if (grade != null && grade.length > 0 && grade != 'Select One') {
                            grades.push(grade);
    
                            var ExemptPredicate = '#CS_FLSA_DETERM_ID_' + index + ' option:selected';
                            var exempt = $(ExemptPredicate).text();
    
                            if (isFLSAExemptSelected == false && exempt == 'Exempt') {
                                isFLSAExemptSelected = true;
                            }
                            if (isFLSANonExemptSelected == false && exempt == 'Non-exempt') {
                                isFLSANonExemptSelected = true;
                            }
                        } else {
                            break;
                        }
                    }
    
                    if (grades.length == 0) {
                        grades.push('0');
                        var ExemptPredicate = '#CS_FLSA_DETERM_ID_1 option:selected';
                        var exempt = $(ExemptPredicate).text();
    
                        if (isFLSAExemptSelected == false && exempt == 'Exempt') {
                            isFLSAExemptSelected = true;
                        }
                        if (isFLSANonExemptSelected == false && exempt == 'Non-exempt') {
                            isFLSANonExemptSelected = true;
                        }
                    }
                }
    
                return {FLSAExempt: isFLSAExemptSelected, FLSANonExempt: isFLSANonExemptSelected, grades: grades};
            },
            vm.getDocumentTypeList = function() {
                var documentTypes = LookupManager.findByLTYPE('DocumentType');
                if (vm.processType == 'Consultation' || vm.processType == 'Eligibility') {
                    var requestType = $('#SG_RT_ID :selected').text();
                    if (requestType == 'Appointment') {
                        var appointmentDocumentTypes = LookupManager.findByLTYPE('AppointmentDocumentType');
                        documentTypes = documentTypes.concat(appointmentDocumentTypes);
    
                        var appointmentType = $('#SG_AT_ID :selected').text();
                        if (appointmentType == 'Schedule A') {
                            var scheduleAType = $('#SG_SAT_ID :selected').text();
                            var extraTypes = LookupManager.findByLTYPE('ScheduleAType[' + scheduleAType + ']/MDDocumentTypeExtra');
                            if (extraTypes && extraTypes.length > 0) {
                                documentTypes = documentTypes.concat(extraTypes);
                            }
                        } else if (appointmentType == 'Volunteer') {
                            var volunteerType = $('#SG_VT_ID :selected').text();
                            var extraTypes = LookupManager.findByLTYPE('VolunteerType[' + volunteerType + ']/MDDocumentTypeExtra');
                            if (extraTypes && extraTypes.length > 0) {
                                documentTypes = documentTypes.concat(extraTypes);
                            }
                        } else if (appointmentType == 'Expert/Consultant') {
                            var extraTypes = LookupManager.findByLTYPE('AppointmentType[Expert*/*Consultant]/MDDocumentTypeExtra')
                            if (extraTypes && extraTypes.length > 0) {
                                documentTypes = documentTypes.concat(extraTypes);
                            }
                        }
                    } else if (requestType == 'Classification Only') {
                        // Should hide "Budget Authorization" document type
                        for (var index = 0; index < documentTypes.length; index++) {
                            if (documentTypes[index].NAME == 'Budget Authorization') {
                                documentTypes.splice(index, 1);
                            }
                        }
                    }
                } else {
                    var requestType = $('#requestType').text();
                    if (requestType == 'Classification Only') {
                        for (var index = 0; index < documentTypes.length; index++) {
                            if (documentTypes[index].NAME == 'Budget Authorization') {
                                documentTypes.splice(index, 1);
                            }
                        }
                    }
                }

                documentTypes.sort(function(item1, item2) {
                    if (item1.NAME == item2.NAME) {
                        return 0;
                    } else {
                        return (item1.NAME > item2.NAME ? 1: -1);
                    }
                });
    
                documentTypes.forEach(function(item) {
                    item.Label = item.LABEL;
                    item.Name = item.LABEL;
                });
                documentTypes.dataMap = angularExt.objectToMap(documentTypes, "Label");
                return documentTypes;
            },    
            vm.getMissingDocumentList = function()  {
                var mandatoryDocumentList = [];
                var attachments = bizflowWih.getAttachments();
    
                if (vm.processType == 'Consultation' || vm.processType == 'Eligibility') {
                    var classType = $('#SG_CT_ID option:selected').text();
                    var mandatoryDocumentListOrg = LookupManager.findByLTYPE('MandatoryDocument[' + vm.processType + ']/MDClassificationType[' + classType + ']/MDDocumentType');
    
                    var requestType = $('#SG_RT_ID :selected').text();
                    var appointmentType = $('#SG_AT_ID :selected').text();
    
                    if (requestType == 'Appointment') {
                        var searchLTYPE = appointmentType;
                        if (searchLTYPE == 'Expert/Consultant') {
                            searchLTYPE = 'Expert*/*Consultant';
                        }
                        var extraMandatoryType = LookupManager.findByLTYPE('AppointmentType[' + searchLTYPE + ']/MDDocumentType');
                        if (extraMandatoryType && extraMandatoryType.length > 0) {
                            mandatoryDocumentListOrg = mandatoryDocumentListOrg.concat(extraMandatoryType);
                        }
    
                        if (appointmentType == 'Schedule A') {
                            var scheduleAType = $('#SG_SAT_ID :selected').text();
                            var mandatoryTypes = LookupManager.findByLTYPE('ScheduleAType[' + scheduleAType + ']/MDDocumentType');
                            if (mandatoryTypes && mandatoryTypes.length > 0) {
                                mandatoryDocumentListOrg = mandatoryDocumentListOrg.concat(mandatoryTypes);
                            }
    
                            var extraTypes = LookupManager.findByLTYPE('ScheduleAType[' + scheduleAType + ']/MDDocumentTypeExtra');
                            if (extraTypes && extraTypes.length > 0) {
                                mandatoryDocumentListOrg = mandatoryDocumentListOrg.concat(extraTypes);
                            }
    
                        } else if (appointmentType == 'Volunteer') {
                            var volunteerType = $('#SG_VT_ID :selected').text();
                            var mandatoryTypes = LookupManager.findByLTYPE('VolunteerType[' + volunteerType + ']/MDDocumentType');
                            if (mandatoryTypes && mandatoryTypes.length > 0) {
                                mandatoryDocumentListOrg = mandatoryDocumentListOrg.concat(mandatoryTypes);
                            }
    
                            var extraTypes = LookupManager.findByLTYPE('VolunteerType[' + volunteerType + ']/MDDocumentTypeExtra');
                            if (extraTypes && extraTypes.length > 0) {
                                mandatoryDocumentListOrg = mandatoryDocumentListOrg.concat(extraTypes);
                            }
                        } else if (appointmentType == 'Expert/Consultant') {
                            if (vm.processType == 'Eligibility') {
                                for (var index = 0; index < mandatoryDocumentListOrg.length; index++) {
                                    if (mandatoryDocumentListOrg[index].NAME == 'New Position Designation Tool (PDT)') {
                                        mandatoryDocumentListOrg.splice(index, 1);
                                    }
                                }
                            }

                            var extraTypes = LookupManager.findByLTYPE('AppointmentType[Expert*/*Consultant]/MDDocumentTypeExtra');
                            // Should not be mandatory
                            for (var index = 0; index < extraTypes.length; index++) {
                                if (extraTypes[index].NAME == 'Security Clearance Email') {
                                    extraTypes.splice(index, 1);
                                }
                            }
                            if (extraTypes && extraTypes.length > 0) {
                                mandatoryDocumentListOrg = mandatoryDocumentListOrg.concat(extraTypes);
                            }
                        }
                    }
    
                    // if (requestType == 'Appointment' && appointmentType == 'Expert/Consultant') {
                    //     var budgetApproved = $('#POS_BGT_APR_OFM option:selected').text();
                    //     if (budgetApproved == 'Yes') {
                    //         var budgetAuthType = LookupManager.findByLTYPE('DocumentType[Budget Authorization]');
                    //         mandatoryDocumentListOrg = mandatoryDocumentListOrg.concat(budgetAuthType);
                    //     }
                    // }
    
                    mandatoryDocumentList = mandatoryDocumentListOrg.slice();
                } else if (vm.processType == 'Classification') {
                    var classType = $('#pv_classificationType').val();
                    var mandatoryDocumentListOrg = LookupManager.findByLTYPE('MandatoryDocument[' + vm.processType + ']/MDClassificationType[' + classType + ']/MDDocumentType');
                    if (mandatoryDocumentListOrg) {
                        mandatoryDocumentList = mandatoryDocumentListOrg.slice();
                    }
                }
    
                if (vm.processType == 'Consultation') {
                    var approvedItem = $('#RI_OA_APRV_ITEM option:selected').text();
                    if (approvedItem != null && approvedItem != 'N/A' && approvedItem != "") {
                        var additionalMandatoryItem = LookupManager.findByLTYPE('DocumentType[Office of the Administrator Approval]');
                        if (additionalMandatoryItem != null && additionalMandatoryItem.length > 0) {
                            mandatoryDocumentList.push(additionalMandatoryItem[0]);
                        }
                    }
                } else if (vm.processType == 'Classification') {
                    if (bizflowContext.custom.ACTIVITYNAME == 'Approve Coversheet and Create Final Pkg') {
                        var grades = [];
                        var isFLSAExemptSelected = false;
                        var isFLSANonExemptSelected = false;
    
                        var flsaOptions = vm.getFLSAMandatoryList();
    
                        isFLSAExemptSelected = flsaOptions.FLSAExempt;
                        isFLSANonExemptSelected = flsaOptions.FLSANonExempt;
                        grades = flsaOptions.grades;
    
                        grades.forEach(function(grade) {
                            mandatoryDocumentList.push({LABEL: 'PD Coversheet for Grade ' + grade, ETCINFO: 'PDCOVERSHEET_' + grade});
                            mandatoryDocumentList.push({LABEL: 'Final Package for Grade ' + grade, ETCINFO: 'PACKAGE_' + grade});
                        });
    
                        if (isFLSAExemptSelected == true) {
                            mandatoryDocumentList.push({LABEL: 'FLSA Exempt Checklist', ETCINFO: 'FLSAEXEMPT_0'});
                        }
                        if (isFLSANonExemptSelected == true) {
                            mandatoryDocumentList.push({LABEL: 'FLSA Non-Exempt Checklist', ETCINFO: 'FLSANONEXEMPT_0'});
                        }
                    }
    
                } else {
    
                }
    
                if (attachments != null && attachments.length > 0) {
                    if (mandatoryDocumentList != null && mandatoryDocumentList.length > 0) {
                        for (var index = mandatoryDocumentList.length - 1; index >= 0 ; index--) {
                            for (var attachmentIndex = 0; attachmentIndex < attachments.length; attachmentIndex++) {
                                if (attachments[attachmentIndex].CATEGORY == mandatoryDocumentList[index].LABEL) {
                                    mandatoryDocumentList.splice(index, 1);
                                    break;
                                } else if (attachments[attachmentIndex].ETCINFO != null && attachments[attachmentIndex].ETCINFO.length > 0) {
                                    // Grade is changed from number to string with leading 0 if grade is less than 10.
                                    // So, ETCINFO cannot be used to detect mapped document.
                                    // In order to detect mapped document, ETCINFO needs to be parsed and compared one by one for backward compatibility.
                                    var mandatoryInfo = mandatoryDocumentList[index].ETCINFO;
                                    var attachmentInfo = attachments[attachmentIndex].ETCINFO;

                                    if (mandatoryInfo != null && attachmentInfo != null) {
                                        var mandatoryTokens = mandatoryInfo.split('_');
                                        var attachmentTokens = attachmentInfo.split('_');

                                        if (mandatoryTokens.length == 2 && attachmentTokens.length == 2) {
                                            if ((mandatoryTokens[0] == attachmentTokens[0]) 
                                                && (mandatoryTokens[1] * 1 == attachmentTokens[1] * 1)) {
                                                mandatoryDocumentList.splice(index, 1);
                                                break;
                                            }
                                        }
                                    }
                                    // && attachments[attachmentIndex].ETCINFO == mandatoryDocumentList[index].ETCINFO) {
                                    //     mandatoryDocumentList.splice(index, 1);
                                    //     break;
                                }
                            }
                        }
                    } else {
                        return []; // No mandatory document list is specified.
                    }
                }
    
                mandatoryDocumentList.sort(function(item1, item2) {
                    if (item1.LABEL == item2.LABEL) {
                        return 0;
                    } else {
                        return (item1.LABEL > item2.LABEL ? 1: -1);
                    }
                });
                return mandatoryDocumentList;
            };  
    
            vm.init = function() {
                //Prevent backspace from navigating back in AngularJS in IE
                $document.on('keydown', function(event){
                    if (event.keyCode === 8) {
                        var doPrevent = true;
                        var types = ["text", "password", "file", "search", "email", "number", "date", "color", "datetime", "datetime-local", "month", "range", "search", "tel", "time", "url", "week"];
                        var d = $(event.srcElement || event.target);
                        var disabled = d.prop("readonly") || d.prop("disabled");
                        if (!disabled) {
                            if (d[0].isContentEditable) {
                                doPrevent = false;
                            } else if (d.is("input")) {
                                var type = d.attr("type");
                                if (type) {
                                    type = type.toLowerCase();
                                }
                                if (types.indexOf(type) > -1) {
                                    doPrevent = false;
                                } else if (d[0].outerHTML.indexOf("textbox") > -1) {
                                    doPrevent = false;
                                } else if (d[0].outerHTML.indexOf("text-box") > -1) {
                                    doPrevent = false;
                                }
                            } else if (d.is("textarea")) {
                                doPrevent = false;
                            }
                        }
                        if (doPrevent) {
                            event.preventDefault();
                        }
                    }
                });
    
                if (angular.isUndefined(bizflowContext.custom)) bizflowContext.custom = {};
    
                var absUrl = $location.absUrl();
                bizflowContext.custom.bfIntegrationMode = "workitem"; //login, bizcove, workitem
                if (bizflowWih.basicWih) {
                    var workitemContext = bizflowWih.getWorkitemContext();
                    bizflowContext.custom.SESSIONINFO = workitemContext.SessionInfoXML;
                    bizflowContext.custom.MEMBERID = workitemContext.User.MemberID;
                    bizflowContext.custom.MEMBERNAME = workitemContext.User.Name;
    
                    bizflowContext.custom.PROCESSID = workitemContext.Process.ID;
                    bizflowContext.custom.ACTIVITYSEQ = workitemContext.Activity.Sequence;
                    bizflowContext.custom.ACTIVITYNAME = workitemContext.Activity.Name;
                    bizflowContext.custom.WITEMSEQ = workitemContext.Workitem.Sequence;
                    bizflowContext.custom.bfIntegrationMode = "workitem"; //login, bizcove, workitem
                }
            };
    
            vm.init();
    
            vm.missingDocumentList = vm.getMissingDocumentList();
            vm.documentTypes = vm.getDocumentTypeList();
            // vm.documentTypes = LookupManager.findByLTYPE('DocumentType');
            // vm.documentTypes.forEach(function(item) {
            //     item.Label = item.LABEL;
            //     item.Name = item.LABEL;
            // });
            // vm.documentTypes.dataMap = angularExt.objectToMap(vm.documentTypes, "Label");
    
            vm.isBulkProcess = false;
            vm.showHideOriginals = false;
            vm.processID = bizflowContext.custom.PROCESSID;
            vm.isReadOnly = isReadOnly();
    
            vm.initialRefreshForEligibility = false;

            vm.onChange = function() {
                if (bizflowWih_attachmentCallback != null) {
                    bizflowWih_attachmentCallback = null;
                }
                
                if (vm.processType === 'Eligibility') {
                    if (vm.initialRefreshForEligibility == false) {
                        var actName = $('#h_activityName').val();
                        if (actName == 'Conduct Eligibility and Qualifications Review') {
                            refreshAttachment();
                        }
                        vm.initialRefreshForEligibility = true;
                    }
                }

                vm.missingDocumentList = vm.getMissingDocumentList();
                vm.documentTypes = vm.getDocumentTypeList();
    
                if (vm.missingDocumentList.length > 0) {
                    $('#h_mandatoryDocumentsValid').val('false');
                } else {
                    $('#h_mandatoryDocumentsValid').val('true');
                }
    
                try {
                    $timeout(function() {
                        $scope.$digest();
                    });
                } catch(e) {
                }
            }
    
            $(document).on("ON_TAB_CHANGE", function() {
                vm.onChange();
            });
    
            $(document).on("ON_DOCUMENT_CHANGE", function() {
                vm.onChange();
            })
    
            CMSUtility.debugLog('cmscommon - bizflow.app - controller END');
        });
    })(window.angular);
        //console.log("Angular bootstrap START.");
         angular.bootstrap(document.getElementById("attachmentSectionID"), ['bizflow.app']);
        //console.log("Angular bootstrap END.");
    }
    
    //-----------------------------------------------------------
    // BizFlow AngualrJS extension for CMS
    //-----------------------------------------------------------

    function refreshAttachment() {
        var attachmentController = null;

        try {
            attachmentController = angular.element(document.getElementById('cmsattachment')).controller('attachments');
            if (attachmentController != null) {
                attachmentController.reloadAttachments2();
            } else {
                console.log('Failed to retrieve attachments controller.')
            }
        } catch (e) {
            console.log("Exception happend while retrieving attachments controller.");
        }
    
    }

    /*
        Pop up Attachment Dialog box with given document type.
        @param {string} documentTypeString - Document Type String.
    */
    function addCMSDocument(documentTypeString) {
        var attachmentController = null;
        if (documentTypeString == null || documentTypeString.length == 0) {
            documentTypeString = "Supporting Documents";
        }
    
        try {
            attachmentController = angular.element(document.getElementById('cmsattachment')).controller('attachments');
        } catch (e) {
            console.log("Failed to retrieve attachments controller.");
        }
    
        if (attachmentController != null) {
            if (attachmentController.documentTypes != null && attachmentController.documentTypes.length > 0) {
                var foundDocumentType = false;
                for (var index = 0; index < attachmentController.documentTypes.length; index++) {
                    if (documentTypeString == attachmentController.documentTypes[index].Name) {
                        foundDocumentType = true;
                        break;
                    }
                }
    
                if (foundDocumentType == false) {
                    documentTypeString = "Supporting Documents";
                }
                attachmentController.addAttachment(documentTypeString);
            }
        }
    }
    
    /*
        Pop up Attachment Dialog box to add Existing PD Document.
    */
    function addCMSExistingPDDocument() {
        addCMSDocument('Existing Position Description (PD)');
    }
    /*
        Pop up Attachment Dialog box to add Propsed PD Document.
    */
    function addCMSProposedPDDocument() {
        addCMSDocument('Proposed Position Description (PD)');
    }
    
    /*
        Pop up Attachment Dialog box to add New PD Document.
    */
    function addCMSNewPDDocument() {
        addCMSDocument('New Position Description (PD)');
    }
    
    /*
        Pop up Attachment Dialog box to add New PDT Document.
    */
    function addCMSNewPDTDocument() {
        addCMSDocument('New Position Designation Tool (PDT)');
    }
    
    /*
        Pop up Attachment Dialog box to add Organization Chart.
    */
    function addCMSOrgChartDocument() {
        addCMSDocument('Organization Chart');
    }
    
    /*
        Pop up Attachment Dialog box to add Supporting Document.
    */
    function addCMSSupportingDocument() {
        addCMSDocument();
    }
    
    /*
        Pop up Attachment Dialog box to add OA Approval Document.
    */
    function addCMSOAApprovalDocument() {
        addCMSDocument('Office of the Administrator Approval');
    }
    