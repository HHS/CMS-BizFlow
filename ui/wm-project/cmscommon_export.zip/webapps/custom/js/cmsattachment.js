// Function initWIHLeftPane should be called as quickly as possible upon opening the form.
// If left pane is opened when opening the form, user can see disapearing the attachment section.
function initWIHLeftPane() {
    if (basicWIHActionClient) {
        var ui = basicWIHActionClient.getUI();
        if (ui) {
            var attachmentPane = ui.getPane(ui.PANE_ATTACHMENT);
            if (attachmentPane) {
                attachmentPane.hide();
            } else {
                console.log('No attachment pane from basic WIH');
            }
            var discussionPane = ui.getPane(ui.PANE_INTERNAL_DISCUSSION);
            if (discussionPane) {
                discussionPane.open();
            } else {
                console.log('No discussion pane from basic WIH');
            }
        } else {
            console.log('No ui found from basicWIHActionClient');
        }
    } else {
        console.log('No basicWIHActionClient found');
    }
};
initWIHLeftPane();

//-----------------------------------------------------------
// BizFlow AngularJS Wrapper
//-----------------------------------------------------------
function initAttachmentTab() {
//-----------------------------------------------------------
// BizFlow.app Controller
//-----------------------------------------------------------
(function (angular) {
    "use strict";

angular.module("bizflow.app", [
    'ngSanitize'
    ,'blockUI'
    ,'ngAnimate'
    ,'ngCookies'
    ,'inform'
    ,'inform-exception'
    ,'ui.bootstrap'
    ,'ui.select'
    ,'ui.grid'
    ,'ui.grid.selection'
    ,'ui.grid.pagination'
    ,'ui.grid.autoResize'
    ,'ui.grid.resizeColumns'
    ,'ngMessages'
    ,'bizflow.angular.context'
    ,'bizflow.angular.wih'
    ,'bizflow.angular.component'
    ,'bizflow.app.common'])
    .factory('timeoutHttpIntercept', function (inform) {
        return {
            "request" : function(config) {
                config.timeout = 600000; //increase timeout for Excel download operation
                return config;
            },
            "responseError" : function(responseError) {
                if( responseError.status == -1 || responseError.status == 499 || responseError.status == 598 || responseError.status == 599 ) {
                    inform.add('Error: Time out', {type: "danger"})
                }
                return responseError;
            }
        };
    })
    .config(['$httpProvider', 'blockUIConfig', 'bizflowContextProvider', 'informProvider', '$compileProvider', '$logProvider',
        function ($httpProvider, blockUIConfig, bizflowContextProvider, informProvider, $compileProvider, $logProvider) {
            //Turn on or off debugging message
            $logProvider.debugEnabled(true);
            bizflowContextProvider.custom.debugEnabled = $logProvider.debugEnabled();
            bizflowContextProvider.custom.formStyle = "tab";

            $httpProvider.interceptors.push('timeoutHttpIntercept');


            blockUIConfig.autoBlock = true;
            blockUIConfig.delay = 0;
            blockUIConfig.message = "Please Wait...";
            // Disable auto body block(This is important! if it's value is true then browser will be flickering on ie 9 and ie 10)
            blockUIConfig.autoInjectBodyBlock = false;
            // ... don't block it.
            blockUIConfig.requestFilter = function (config) {
            };

            //Need to change bizflowsrs context patch if it is not default value bizflowsrs
            bizflowContextProvider.setServiceContextPath("/bizflowsrs/services");
            bizflowContextProvider.setDataServiceContextPath("/bizflowsrs/services");
            bizflowContextProvider.setAppContextPath("/app");

            informProvider.defaults({ttl:0, type: 'danger'});

            //need to set as false for PRODUCTION SERVER to speed up
            //https://docs.angularjs.org/guide/production
            $compileProvider.debugInfoEnabled(false);
        }
    ])
    .controller('CtrlAppMain', function($scope, $location, bizflowContext, $document, $window, $rootScope, $log, bizflowWih, $timeout) {
        CMSUtility.debugLog('cmscommon - bizflow.app - controller START');

        var vm = this;
        vm.bizflowContext = bizflowContext;

        $scope.$ctrl = vm;
        $scope.isContextLoaded = true;

        //trigger destroy events for all children when window is switched or closed
        $window.onbeforeunload = function () {
            $rootScope.$destroy();
        };
        $scope.$on('$destroy', function () {
        });

        vm.isUseSection508 = function () {
            if (typeof FormSection508 !== "undefined") return FormSection508.isUseSection508();
            else return false;
        };
        //Prevent backspace from navigating back in AngularJS in IE
        $document.on('keydown', function(event){
            if (event.keyCode === 8) {
                var doPrevent = true;
                var types = ["text", "password", "file", "search", "email", "number", "date", "color", "datetime", "datetime-local", "month", "range", "search", "tel", "time", "url", "week"];
                var d = $(event.srcElement || event.target);
                var disabled = d.prop("readonly") || d.prop("disabled");
                if (!disabled) {
                    if (d[0].isContentEditable) {
                        doPrevent = false;
                    } else if (d.is("input")) {
                        var type = d.attr("type");
                        if (type) {
                            type = type.toLowerCase();
                        }
                        if (types.indexOf(type) > -1) {
                            doPrevent = false;
                        } else if (d[0].outerHTML.indexOf("textbox") > -1) {
                            doPrevent = false;
                        } else if (d[0].outerHTML.indexOf("text-box") > -1) {
                            doPrevent = false;
                        }
                    } else if (d.is("textarea")) {
                        doPrevent = false;
                    }
                }
                if (doPrevent) {
                    event.preventDefault();
                }
            }
        });

        vm.setProcessType = function() {
            vm.processType = 'Consultation';
            vm.definitionName = $('#h_definitionName').val();
            if (vm.definitionName.indexOf("Classification") > -1) {
                vm.processType = 'Classification';
            } else if (vm.definitionName.indexOf("Eligibility") > -1) {
                vm.processType = 'Eligibility';
            }
        }

        vm.getFLSAMandatoryList = function() {
            var grades = [];
            var isFLSAExemptSelected = false;
            var isFLSANonExemptSelected = false;

            if (bizflowContext.custom.ACTIVITYNAME == 'Approve Coversheet and Create Final Pkg') {
                for (var index = 1; index <= 5; index++) {
                    var IDPredicate = '#CS_GR_ID_' + index + ' option:selected';
                    var grade = $(IDPredicate).text();

                    if (grade != null && grade.length > 0 && grade != 'Select One') {
                        grades.push(grade);

                        var ExemptPredicate = '#CS_FLSA_DETERM_ID_' + index + ' option:selected';
                        var exempt = $(ExemptPredicate).text();

                        if (isFLSAExemptSelected == false && exempt == 'Exempt') {
                            isFLSAExemptSelected = true;
                        }
                        if (isFLSANonExemptSelected == false && exempt == 'Non-exempt') {
                            isFLSANonExemptSelected = true;
                        }
                    } else {
                        break;
                    }
                }

                if (grades.length == 0) {
                    grades.push('0');
                    var ExemptPredicate = '#CS_FLSA_DETERM_ID_1 option:selected';
                    var exempt = $(ExemptPredicate).text();

                    if (isFLSAExemptSelected == false && exempt == 'Exempt') {
                        isFLSAExemptSelected = true;
                    }
                    if (isFLSANonExemptSelected == false && exempt == 'Non-exempt') {
                        isFLSANonExemptSelected = true;
                    }
                }
            }

            return {FLSAExempt: isFLSAExemptSelected, FLSANonExempt: isFLSANonExemptSelected, grades: grades};
        };

        vm.getRequestType = function() {
            if (vm.processType == 'Consultation' || vm.processType == 'Eligibility') {
                return $('#SG_RT_ID :selected').text();
            } else {
                return $('#requestType').text();
            }
        };

        vm.getDocumentTypeList = function() {
            var documentTypes = LookupManager.findByLTYPE('DocumentType');
            var requestType = vm.getRequestType();

            if (vm.processType == 'Consultation' || vm.processType == 'Eligibility') {
                if (requestType == 'Appointment') {
                    var appointmentDocumentTypes = LookupManager.findByLTYPE('AppointmentDocumentType');
                    documentTypes = documentTypes.concat(appointmentDocumentTypes);

                    var appointmentType = $('#SG_AT_ID :selected').text();
                    if (appointmentType == 'Schedule A') {
                        var scheduleAType = $('#SG_SAT_ID :selected').text();
                        var extraTypes = LookupManager.findByLTYPE('ScheduleAType[' + scheduleAType + ']/MDDocumentTypeExtra');
                        if (extraTypes && extraTypes.length > 0) {
                            documentTypes = documentTypes.concat(extraTypes);
                        }
                    } else if (appointmentType == 'Volunteer') {
                        var volunteerType = $('#SG_VT_ID :selected').text();
                        var extraTypes = LookupManager.findByLTYPE('VolunteerType[' + volunteerType + ']/MDDocumentTypeExtra');
                        if (extraTypes && extraTypes.length > 0) {
                            documentTypes = documentTypes.concat(extraTypes);
                        }
                    } else if (appointmentType == 'Expert/Consultant') {
                        var extraTypes = LookupManager.findByLTYPE('AppointmentType[Expert*/*Consultant]/MDDocumentTypeExtra')
                        if (extraTypes && extraTypes.length > 0) {
                            documentTypes = documentTypes.concat(extraTypes);
                        }
                    }
                }
            }

            // Should hide "Budget Authorization" document type when Request Type is "Classification Only"
            if (requestType == 'Classification Only') {
                for (var index = 0; index < documentTypes.length; index++) {
                    if (documentTypes[index].NAME == 'Budget Authorization') {
                        documentTypes.splice(index, 1);
                    }
                }
            }

            documentTypes.sort(function(item1, item2) {
                if (item1.NAME == item2.NAME) {
                    return 0;
                } else {
                    return (item1.NAME > item2.NAME ? 1: -1);
                }
            });

            documentTypes.forEach(function(item) {
                item.Label = item.LABEL;
                item.Name = item.LABEL;
            });
            documentTypes.dataMap = angularExt.objectToMap(documentTypes, "Label");
            return documentTypes;
        };

        vm.getClassificationType = function() {
            var classificationType = ""
            if (vm.processType == 'Consultation' || vm.processType == 'Eligibility') {
                classificationType = $('#SG_CT_ID option:selected').text();
            } else if (vm.processType == 'Classification') {
                classificationType = $('#pv_classificationType').val();
            } else {
                console.log('Unknown process type [' + vm.processType + ']');
            }
            return classificationType;
        };
        vm.doesClassificationTypeRequirePDT = function(classType) {
            var shouldHide = false;
            if (classType == 'Create New Position Description'
                || classType == 'Update Major Duties'
                || classType == 'Reorganization for New Position' 
                || classType == 'Conduct 5-year Recertification') {
                shouldHide = true;
            }
            return shouldHide;
        };
        vm.showHidePDTFromMandatoryDocumentList = function(processType, activityName, classType, mandatoryList) {
            var shouldHidePDT = false;
            var classTypesToHide = ['Create New Position Description', 'Update Major Duties','Reorganization for New Position','Conduct 5-year Recertification'];

            if (processType == 'Eligibility') {
                shouldHidePDT = true;
            } else if (processType == 'Consultation' || (processType == 'Classification' && activityName != 'Approve PD Coversheet - SO')) {
                for (var index = 0; index < classTypesToHide.length; index++) {
                    if (classTypesToHide[index] == classType) {
                        shouldHidePDT = true;
                        break;
                    }
                }
            }

            if (shouldHidePDT) {
                for (var index = 0; index < mandatoryList.length; index++) {
                    if (mandatoryList[index].NAME == 'New Position Designation Tool (PDT)') {
                        mandatoryList.splice(index, 1);
                    }
                }
            }
        };

        vm.addScheduleAMandatoryDocTypes = function() {
            var finalTypes = [];
            var scheduleAType = $('#SG_SAT_ID :selected').text();
            var mandatoryTypes = LookupManager.findByLTYPE('ScheduleAType[' + scheduleAType + ']/MDDocumentType');
            if (mandatoryTypes && mandatoryTypes.length > 0) {
                //targetList = targetList.concat(mandatoryTypes);
                finalTypes = finalTypes.concat(mandatoryTypes);
            }

            var extraTypes = LookupManager.findByLTYPE('ScheduleAType[' + scheduleAType + ']/MDDocumentTypeExtra');
            if (extraTypes && extraTypes.length > 0) {
                //targetList = targetList.concat(extraTypes);
                finalTypes = finalTypes.concat(extraTypes);
            }
            
            return finalTypes;
        };
        vm.addVolunteerMandatoryDocTypes = function() {
            var finalTypes = [];
            var volunteerType = $('#SG_VT_ID :selected').text();
            var mandatoryTypes = LookupManager.findByLTYPE('VolunteerType[' + volunteerType + ']/MDDocumentType');
            if (mandatoryTypes && mandatoryTypes.length > 0) {
                //targetList = targetList.concat(mandatoryTypes);
                finalTypes = finalTypes.concat(mandatoryTypes);
            }

            var extraTypes = LookupManager.findByLTYPE('VolunteerType[' + volunteerType + ']/MDDocumentTypeExtra');
            if (extraTypes && extraTypes.length > 0) {
                //targetList = targetList.concat(extraTypes);
                finalTypes = finalTypes.concat(extraTypes);
            }
            return finalTypes;
        };
        vm.addExpertConsultantDocTypes = function() {
            var extraTypes = LookupManager.findByLTYPE('AppointmentType[Expert*/*Consultant]/MDDocumentTypeExtra');
            // Should not be mandatory
            for (var index = 0; index < extraTypes.length; index++) {
                if (extraTypes[index].NAME == 'Security Clearance Email') {
                    extraTypes.splice(index, 1);
                }
            }
            // if (extraTypes && extraTypes.length > 0) {
            //     targetList = targetList.concat(extraTypes);
            // }
            return extraTypes;
        }
        vm.getMissingDocumentList = function()  {
            var mandatoryDocumentList = [];
            var attachments = bizflowWih.getAttachments();
            var classificationType = vm.getClassificationType();

            if (vm.processType == 'Consultation' || vm.processType == 'Eligibility') {
                var mandatoryDocumentListOrg = LookupManager.findByLTYPE('MandatoryDocument[' + vm.processType + ']/MDClassificationType[' + classificationType + ']/MDDocumentType');

                var requestType = $('#SG_RT_ID :selected').text();
                var appointmentType = $('#SG_AT_ID :selected').text();

                if (requestType == 'Appointment') {
                    var searchLTYPE = appointmentType;
                    if (searchLTYPE == 'Expert/Consultant') {
                        searchLTYPE = 'Expert*/*Consultant';
                    }
                    var extraMandatoryType = LookupManager.findByLTYPE('AppointmentType[' + searchLTYPE + ']/MDDocumentType');
                    if (extraMandatoryType && extraMandatoryType.length > 0) {
                        mandatoryDocumentListOrg = mandatoryDocumentListOrg.concat(extraMandatoryType);
                    }

                    if (appointmentType == 'Schedule A') {
                        var scheduleATypes = vm.addScheduleAMandatoryDocTypes();
                        mandatoryDocumentListOrg = mandatoryDocumentListOrg.concat(scheduleATypes)
                    } else if (appointmentType == 'Volunteer') {
                        var volunteerTypes = vm.addVolunteerMandatoryDocTypes();
                        mandatoryDocumentListOrg = mandatoryDocumentListOrg.concat(volunteerTypes)
                    } else if (appointmentType == 'Expert/Consultant') {
                        var expertTypes = vm.addExpertConsultantDocTypes();
                        mandatoryDocumentListOrg = mandatoryDocumentListOrg.concat(expertTypes)
                    }
                }

                if (vm.processType == 'Consultation') {
                    var approvedItem = $('#RI_OA_APRV_ITEM option:selected').text();
                    if (approvedItem != null && approvedItem != 'N/A' && approvedItem != "") {
                        var additionalMandatoryItem = LookupManager.findByLTYPE('DocumentType[Office of the Administrator Approval]');
                        if (additionalMandatoryItem != null && additionalMandatoryItem.length > 0) {
                            mandatoryDocumentListOrg.push(additionalMandatoryItem[0]);
                        }
                    }
                }
    
                mandatoryDocumentList = mandatoryDocumentListOrg.slice();
            } else if (vm.processType == 'Classification') {
                var version = $('#h_version').val();
                var mandatoryDocumentListOrg = LookupManager.findByLTYPE('MandatoryDocument[' + vm.processType + ']/MDClassificationType[' + classificationType + ']/MDDocumentType');
                if (mandatoryDocumentListOrg) {
                    mandatoryDocumentList = mandatoryDocumentListOrg.slice();
                }

                if (bizflowContext.custom.ACTIVITYNAME == 'Approve Coversheet and Create Final Pkg') {
                    var grades = [];
                    var isFLSAExemptSelected = false;
                    var isFLSANonExemptSelected = false;

                    var flsaOptions = vm.getFLSAMandatoryList();

                    isFLSAExemptSelected = flsaOptions.FLSAExempt;
                    isFLSANonExemptSelected = flsaOptions.FLSANonExempt;
                    grades = flsaOptions.grades;

                    grades.forEach(function(grade) {
                        mandatoryDocumentList.push({LABEL: 'PD Coversheet for Grade ' + grade, ETCINFO: 'PDCOVERSHEET_' + grade});
                        mandatoryDocumentList.push({LABEL: 'Final Package for Grade ' + grade, ETCINFO: 'PACKAGE_' + grade});
                        // Version 1 or less - No OF 8 required.
                        // Version 2 or higher - OF 8 is required
                        //if (version * 1 > 1) {
                            mandatoryDocumentList.push({LABEL: 'OF 8', ETCINFO: 'OF 8_' + grade});
                        //}
                    });

                    if (isFLSAExemptSelected == true) {
                        mandatoryDocumentList.push({LABEL: 'FLSA Exempt Checklist', ETCINFO: 'FLSAEXEMPT_0'});
                    }
                    if (isFLSANonExemptSelected == true) {
                        mandatoryDocumentList.push({LABEL: 'FLSA Non-Exempt Checklist', ETCINFO: 'FLSANONEXEMPT_0'});
                    }
                } 
            }

            vm.showHidePDTFromMandatoryDocumentList(vm.processType, bizflowContext.custom.ACTIVITYNAME, classificationType, mandatoryDocumentList);

            if (attachments != null && attachments.length > 0) {
                if (mandatoryDocumentList != null && mandatoryDocumentList.length > 0) {
                    for (var index = mandatoryDocumentList.length - 1; index >= 0 ; index--) {
                        for (var attachmentIndex = 0; attachmentIndex < attachments.length; attachmentIndex++) {
                            if (attachments[attachmentIndex].CATEGORY == mandatoryDocumentList[index].LABEL) {
                                mandatoryDocumentList.splice(index, 1);
                                break;
                            } else if (attachments[attachmentIndex].ETCINFO != null && attachments[attachmentIndex].ETCINFO.length > 0) {
                                // Grade is changed from number to string with leading 0 if grade is less than 10.
                                // So, ETCINFO cannot be used to detect mapped document.
                                // In order to detect mapped document, ETCINFO needs to be parsed and compared one by one for backward compatibility.
                                var mandatoryInfo = mandatoryDocumentList[index].ETCINFO;
                                var attachmentInfo = attachments[attachmentIndex].ETCINFO;

                                if (mandatoryInfo != null && attachmentInfo != null) {
                                    var mandatoryTokens = mandatoryInfo.split('_');
                                    var attachmentTokens = attachmentInfo.split('_');

                                    if (mandatoryTokens.length == 2 && attachmentTokens.length == 2) {
                                        if ((mandatoryTokens[0] == attachmentTokens[0]) 
                                            && (mandatoryTokens[1] * 1 == attachmentTokens[1] * 1)) {
                                            mandatoryDocumentList.splice(index, 1);
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    return []; // No mandatory document list is specified.
                }
            }

            mandatoryDocumentList.sort(function(item1, item2) {
                if (item1.LABEL == item2.LABEL) {
                    return 0;
                } else {
                    return (item1.LABEL > item2.LABEL ? 1: -1);
                }
            });
            return mandatoryDocumentList;
        };  

        vm.init = function() {
            // Init process type
            vm.setProcessType();

            // Prevent backspace from navigating back in AngularJS in IE
            $document.on('keydown', function(event){
                if (event.keyCode === 8) {
                    var doPrevent = true;
                    var types = ["text", "password", "file", "search", "email", "number", "date", "color", "datetime", "datetime-local", "month", "range", "search", "tel", "time", "url", "week"];
                    var d = $(event.srcElement || event.target);
                    var disabled = d.prop("readonly") || d.prop("disabled");
                    if (!disabled) {
                        if (d[0].isContentEditable) {
                            doPrevent = false;
                        } else if (d.is("input")) {
                            var type = d.attr("type");
                            if (type) {
                                type = type.toLowerCase();
                            }
                            if (types.indexOf(type) > -1) {
                                doPrevent = false;
                            } else if (d[0].outerHTML.indexOf("textbox") > -1) {
                                doPrevent = false;
                            } else if (d[0].outerHTML.indexOf("text-box") > -1) {
                                doPrevent = false;
                            }
                        } else if (d.is("textarea")) {
                            doPrevent = false;
                        }
                    }
                    if (doPrevent) {
                        event.preventDefault();
                    }
                }
            });

            if (angular.isUndefined(bizflowContext.custom)) bizflowContext.custom = {};

            var absUrl = $location.absUrl();
            bizflowContext.custom.bfIntegrationMode = "workitem"; //login, bizcove, workitem
            if (bizflowWih.basicWih) {
                var workitemContext = bizflowWih.getWorkitemContext();
                bizflowContext.custom.SESSIONINFO = workitemContext.SessionInfoXML;
                bizflowContext.custom.MEMBERID = workitemContext.User.MemberID;
                bizflowContext.custom.MEMBERNAME = workitemContext.User.Name;

                bizflowContext.custom.PROCESSID = workitemContext.Process.ID;
                bizflowContext.custom.ACTIVITYSEQ = workitemContext.Activity.Sequence;
                bizflowContext.custom.ACTIVITYNAME = workitemContext.Activity.Name;
                bizflowContext.custom.WITEMSEQ = workitemContext.Workitem.Sequence;
                bizflowContext.custom.bfIntegrationMode = "workitem"; //login, bizcove, workitem
            }
        };

        vm.init();

        vm.missingDocumentList = vm.getMissingDocumentList();
        vm.documentTypes = vm.getDocumentTypeList();

        vm.isBulkProcess = false;
        vm.showHideOriginals = false;
        vm.processID = bizflowContext.custom.PROCESSID;
        vm.isReadOnly = CMSUtility.isReadOnly();

        vm.initialRefreshForEligibility = false;

        vm.onChange = function() {
            if (bizflowWih_attachmentCallback != null) {
                bizflowWih_attachmentCallback = null;
            }
            
            if (vm.processType === 'Eligibility') {
                if (vm.initialRefreshForEligibility == false) {
                    var actName = $('#h_activityName').val();
                    if (actName == 'Conduct Eligibility and Qualifications Review') {
                        refreshAttachment();
                    }
                    vm.initialRefreshForEligibility = true;
                }
            }

            vm.missingDocumentList = vm.getMissingDocumentList();
            vm.documentTypes = vm.getDocumentTypeList();

            if (vm.missingDocumentList.length > 0) {
                $('#h_mandatoryDocumentsValid').val('false');
            } else {
                $('#h_mandatoryDocumentsValid').val('true');
            }

            try {
                $timeout(function() {
                    $scope.$digest();
                });
            } catch(e) {
            }
        }

        $(document).on("ON_TAB_CHANGE", function() {
            vm.onChange();
        });

        $(document).on("ON_DOCUMENT_CHANGE", function() {
            vm.onChange();
        })

        CMSUtility.debugLog('cmscommon - bizflow.app - controller END');
    });
})(window.angular);
    angular.bootstrap(document.getElementById("attachmentSectionID"), ['bizflow.app']);
}

//-----------------------------------------------------------
// BizFlow AngualrJS extension for CMS
//-----------------------------------------------------------
function refreshAttachment() {
    var attachmentController = null;
    try {
        attachmentController = angular.element(document.getElementById('cmsattachment')).controller('attachments');
        if (attachmentController != null) {
            attachmentController.reloadAttachments2();
        } else {
            console.log('Failed to retrieve attachments controller.')
        }
    } catch (e) {
        console.log("Exception happend while retrieving attachments controller.");
    }
}

// Pop up Attachment Dialog box with given document type.
// @param {string} documentTypeString - Document Type String.
function addCMSDocument(documentTypeString) {
    var attachmentController = null;
    if (documentTypeString == null || documentTypeString.length == 0) {
        documentTypeString = "Supporting Documents";
    }

    try {
        attachmentController = angular.element(document.getElementById('cmsattachment')).controller('attachments');
    } catch (e) {
        console.log("Failed to retrieve attachments controller.");
    }

    if (attachmentController != null) {
        if (attachmentController.documentTypes != null && attachmentController.documentTypes.length > 0) {
            var foundDocumentType = false;
            for (var index = 0; index < attachmentController.documentTypes.length; index++) {
                if (documentTypeString == attachmentController.documentTypes[index].Name) {
                    foundDocumentType = true;
                    break;
                }
            }

            if (foundDocumentType == false) {
                documentTypeString = "Supporting Documents";
            }
            attachmentController.addAttachment(documentTypeString);
        }
    }
}

// Pop up Attachment Dialog box to add Existing PD Document.
function addCMSExistingPDDocument() {
    addCMSDocument('Existing Position Description (PD)');
}

//Pop up Attachment Dialog box to add Propsed PD Document.
function addCMSProposedPDDocument() {
    addCMSDocument('Proposed Position Description (PD)');
}

// Pop up Attachment Dialog box to add New PD Document.
function addCMSNewPDDocument() {
    addCMSDocument('New Position Description (PD)');
}

// Pop up Attachment Dialog box to add New PDT Document.
function addCMSNewPDTDocument() {
    addCMSDocument('New Position Designation Tool (PDT)');
}

// Pop up Attachment Dialog box to add Staffing Chart.
function addCMSOrgChartDocument() {
    addCMSDocument('Staffing Chart');
}

// Pop up Attachment Dialog box to add Supporting Document.
function addCMSSupportingDocument() {
    addCMSDocument();
}

// Pop up Attachment Dialog box to add OA Approval Document.
function addCMSOAApprovalDocument() {
    addCMSDocument('Office of the Administrator Approval');
}
    