
// var testOption = {
//     id: 'SG_ADMIN_CD_INPUT',                 // Textbox ID that user enters 
//     mapFunction: function(context) {
//         return {
//             admin_cd: $( "AC_ADMIN_CD", context ).text(),
//             admin_desc: $( "AC_ADMIN_CD_DESCR", context ).text()
//         }
//     },
//     getSelectionLabel: function(item) {
//         return item.admin_cd + ' - ' + item.admin_desc;
//     },
//     getCandidateLabel: function(item) {
//         return item.admin_cd + ' - ' + item.admin_desc;
//     },
//     minLength: 2,
//     validationMessage: 'Invalid Selection:<br />Item must be selected from the available options.',  // Optional
//     targetURL: 'SearchAdmOffOrg.do',
//     targetParam: 'searchAdmOff',
//     baseURL: '/bizflowwebmaker/StratCon_AUT',    // Optional
//     getItemID: function(item) {
//         return item.admin_cd;
//     },
//     minSelectionCount: 1, // Optional
//     maxSelectionCount: 13,// Optional
//     postSelect: function(event, ui, selectedValues) {}    // Optional
//     postDelete: function(e, selectedValues) {},  // Optional
//     initialItems: [{ // Optional
//         admin_cd: '123123',
//         admin_cd_dscr: '123123123'    
//     }],
//     compare: function(a, b) {}, // Optional
//     setDataToForm: function(selectedValues) {},
// }


function initAutoCompletion(initOption) {
    if (initOption == null) {
        console.log('Invalid option. Option is null.');
        return;
    }
    if (initOption.id == null || typeof initOption.id !== 'string') {
        console.log('Invalid option. option.id should be string.');
        return;
    }
    if (initOption.mapFunction == null || typeof initOption.mapFunction !== 'function') {
        console.log('Invalid option. option.mapFunction is required and mandatory.');
        return;
    }
    if (initOption.getItemID == null || typeof initOption.getItemID !== 'function') {
        console.log('Invalid option. option.getItemID is required and mandatory.');
        return;
    }
    if (initOption.getSelectionLabel == null || typeof initOption.getSelectionLabel !== 'function') {
        console.log('Invalid option. option.getSelectionLabel is required and mandatory.');
        return;
    }
    if (initOption.getCandidateLabel == null || typeof initOption.getCandidateLabel !== 'function') {
        console.log('Invalid option. option.getCandidateLabel is required and mandatory.');
        return;
    }
    if (initOption.setDataToForm == null || typeof initOption.setDataToForm !== 'function') {
        console.log('Invalid option. option.setDataToForm is required and mandatory.');
        return;
    }
	
    var baseURL = '/bizflowwebmaker/StratCon_AUT/';
    if (initOption.baseURL && typeof initOption.baseURL == 'string' && initOption.baseURL.length > 0) {
        baseURL = initOption.baseURL;
    }
    var option = initOption;
    var inputID = option.id;
    var listElementID = inputID + '_LIST';
    var noMatchElementID = inputID + '_NOMATCH';
    var selectedElementID = inputID + '_DISP';
    var inputContainer = inputID + '_container';
    var separator = option.separator || ',';
    var selectedValues = [];

    option.minSelectionCount = option.minSelectionCount || 1;
    option.maxSelectionCount = option.maxSelectionCount || 1;

    var footerHTML = '<div class="customControl"><ul class="hidden nobullet autocomplete_ul" id="___UL___" /></div><div id="___LIST___"></div>';
    footerHTML = footerHTML.replace('___LIST___', listElementID);
    footerHTML = footerHTML.replace('___UL___', selectedElementID);
    $('#' + inputContainer).parent().parent().append(footerHTML);

    var getListItemHTML = function(targetID, targetLabel, tabIndex) {
        var elementString = "";
        if (CMSUtility.isReadOnly() == true) {
            elementString = '<li id="' + targetID + '">' + targetLabel + '</li>';

        } else {
            elementString = "<li id=\"" + targetID + "\"><img src=\"" + baseURL + "custom/images/delete-icon.png"
                + "\" id=\"delete-" + targetID + "\" deleteId=\"" + targetID
                + "\" title=\"Remove " + targetLabel + "\" tabindex=\"" + tabIndex + "\" />" + targetLabel + "</li>";
        }
        return elementString;
    }

    var sortSelectedValues = function() {
        if (selectedValues && selectedValues.length > 1) {
            if (option.compare != null && typeof option.compare === 'function') {
                selectedValues.sort(option.compare);
            } else {
                selectedValues.sort(function(a,b) {
                    return option.getSelectionLabel(a) > option.getSelectionLabel(b);
                });
            }
        }
    }

    var setDataToForm = function() {
        option.setDataToForm(selectedValues);
    }

    var select = function(event, ui) {
        var id = option.getItemID(ui.item)
        var label = option.getSelectionLabel(ui.item)
        //var listItemHTML = getListItemHTML(id, label)

        // var foundItem = selectedValues.find(function(element) {
        //     return option.getItemID(element) === id;
        // });
        var found = false;
        for (var valueIndex = 0; valueIndex < selectedValues.length; valueIndex++) {
            var foundID = option.getItemID(selectedValues[valueIndex]);
            if (foundID === id) {
                found = true;
                break;
            }
        }

        // if (typeof foundItem === 'undefined') {
        if (found === false) {
            var count = selectedValues.length
            if (count > 0) {
                $('#' + selectedElementID + ' li').each(function() {
                    $(this).remove();
                })
            }

            selectedValues.push(ui.item)
            count = selectedValues.length
            sortSelectedValues();

            // Display
            for(var index = 0; index < count; index++) {
                var itemID = option.getItemID(selectedValues[index]);
                var itemLabel = option.getSelectionLabel(selectedValues[index])
                var listItemHTML = getListItemHTML(itemID, itemLabel, option.tabindex);
                $('#' + selectedElementID).append(listItemHTML);
            }
            $('#' + selectedElementID).removeClass('hidden');

            // Call form to save selected values 
            setDataToForm();

            if (count >= option.maxSelectionCount) {
                $('#' + inputContainer).addClass('hidden');
            }
            if (count >= option.minSelectionCount) {
                $('#' + inputID).attr('_required', 'false');
            }
        
            // Remove candidate
            $('#' + listElementID + ' ul li').each(function() {
                $(this).remove();
            });
        }
    };

    var deleteItem = function(e) {
        var count = selectedValues.length;
        var targetID = $(e.currentTarget).attr('deleteid');

        // var foundItem = selectedValues.find(function(element) {
        //     return option.getItemID(element) === targetID;
        // });
        var found = false;
        for (var valueIndex = 0; valueIndex < selectedValues.length; valueIndex++) {
            var foundID = option.getItemID(selectedValues[valueIndex]);
            if (foundID === targetID) {
                found = true;
                break;
            }
        }

        // if (typeof foundItem === 'object') {
        if (found) {    
            for (var index = 0; index < count; index++) {
                if (targetID === option.getItemID(selectedValues[index])) {
                    selectedValues.splice(index, 1);
                    count -= 1;
                    break;
                }
            }

            $('#' + selectedElementID + ' li[id="' + targetID + '"]').remove();

            // Call form to save selected values 
            setDataToForm();
    
            if (count == 0) {
                $('#' + selectedElementID).addClass('hidden').empty();
            }
            
            $('#' + inputContainer).removeClass('hidden');
    
            if (count < option.minSelectionCount) {
                $('#' + inputID).attr('_required', 'true');
            }
        }
    };

    $('#' + inputID).autocomplete({
        appendTo: '#' + listElementID,
        source: function (request, response) {
			//var userInput = $('#' + inputID).val() + '%';
			var userInput = request.term.toUpperCase();
			if (typeof option.targetURL != 'undefined' && option.targetURL != null && option.targetURL.length > 0) {
				// source to ajax service call for DB query
				userInput = encodeURIComponent(userInput) + '%';
				console.log(baseURL + option.targetURL + '?' + option.targetParam + '=' + userInput);
				$.ajax({
					url: baseURL + option.targetURL + '?' + option.targetParam + '=' + userInput,
					dataType: "xml",
					cache: false,
					success: function (xmlResponse) {
						var data = $("record", xmlResponse ).map(function() {
							return option.mapFunction(this);
						}).get();
						response(data);
					}
				});
			} else {
				// source to statically loaded dropdown field (select input element)
				console.log('srcSelectElemId = ' + option.srcSelectElemId + '  userInput = ' + userInput );
				var data = $('#' + option.srcSelectElemId + ' option')
					.filter(function(){
						// filter by matching label (displayed value) of each drop down option against user input
						var itemLabel = $(this).text();
						if (typeof itemLabel == 'undefined' || itemLabel == null || itemLabel.length <= 0) {
							return false;
						}
						return itemLabel.toUpperCase().indexOf(userInput) >= 0;
					})
					.map(function() {
						return option.mapFunction(this);
					})
					.get();
				response(data);
			}
        },
        minLength: option.minLength || 2,
        change: function (event, ui) {
            if (!option.changeFunction || typeof option.changeFunction !== 'function') {
                //If the No match found" u.item will return null, clear the TextBox.
                if (ui.item == null) {
                    //Clear the AutoComplete TextBox.
                    var pos = $(this).position();
                    $('#' + noMatchElementID).remove();

                    var errorMessage = 'Invalid Selection:<br />Item must be selected from the available options.';
                    if (option.validationMessage && option.validationMessage.length > 0) {
                        errorMessage = option.validationMessage;
                    }

                    var noMatchClass = 'acNoMatch';
                    if (option.noMatchClass && option.noMatchClass.length > 0) {
                        noMatchClass = option.noMatchClass;
                    }
                    $(this).after('<span id="' + noMatchElementID + '" class="' + noMatchClass + '">' + errorMessage + '</span>');

                    $('#' + noMatchElementID).css({top: pos.top + 20, left: pos.left + 30, position:'absolute'});
                    setTimeout(function() { $('#' + noMatchElementID).remove(); }, 2000);

                    $('#' + inputID).val("")
                    $('#' + inputID).trigger('keydown');
                    $(this).autocomplete('close');
                }
            } else {
                option.changeFunction(e, u);
            }
        },
        select: function(event, ui) {
            select(event, ui);
            if (option.postSelect && typeof option.postSelect === 'function') {
                option.postSelect(event, ui, selectedValues);
            }
			// clear the search textbox once selection is made
			this.value = '';
			return false;
        },
        open: function() {
            $(".ui-autocomplete").css("z-index", 5000);
        },
        close: function() {
            $(".ui-autocomplete").css("z-index", 1);
        }
    })
    .autocomplete().data("ui-autocomplete")._renderItem = function(ul, item) {
        var itemLabel = option.getCandidateLabel(item);
        itemLabel = '<a>' + itemLabel + '</a>';
        return $("<li>").append(itemLabel).appendTo(ul);
    }

    if (CMSUtility.isReadOnly() == false) {
        $('#' + selectedElementID).delegate("img", "click keyup", function (e) {
            if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
                deleteItem(e);
                if (option.postDelete && typeof option.postDelete === 'function') {
                    option.postDelete(e, selectedValues);
                }
            }
        });
    }

    if (option.initialItems && typeof option.initialItems === 'object') {
        var count = option.initialItems.length

        for (var index = 0; index < count; index++) {
            var ui = {};
            ui.item = option.initialItems[index];

            var isEmpty = true;
            for (var key in ui.item) {
                if (ui.item.hasOwnProperty(key)) {
                    var data = ui.item[key];
                    if (typeof data == 'string' && data.length > 0) {
                        isEmpty = false;
                        break;
                    }
                }
            }
            if (isEmpty != true) {
                select(null, ui);
            }
        }
    }

    if (CMSUtility.isReadOnly() == true) {
        $('#' + inputContainer).addClass('hidden');
    }

    console.log('AutoCompletion is initialized!! - ' + option.id);
    return {
        option: option,
        baseURL: baseURL,

        inputID: inputID,
        listElementID: listElementID,
        noMatchElementID: noMatchElementID,
        selectedElementID: selectedElementID,
        inputContainer: inputContainer,

        selectedValues: selectedValues,

        select: select,
        deleteItem: deleteItem
    }
};

// AutoCompletion.init(testOption);

