/**
 * AngularJS component showing BizFlow Attachments.<br>
 * This component can be initiated by adding attachments element into HTML.
 * @component attachments
 * @memberOf module:"bizflow.angular.component"
 *
 * @param {int} BizFlow Process ID
 * @param {array} documentTypes document type array
 * @param {boolean} showHideOriginals The flag showing original attachment information or not.
 * @param {boolean} isBulkProcess The flag showing BizFlow Process ID or not.
 * @param {boolean} readOnly The flag hiding buttons (Add Attachment) or not.
 *
 * @example
 *<attachments
 *      process-id="$ctrl.processId"
 *      document-types="$ctrl.documentTypes"
 *      show-hide-originals="$ctrl.showHideOriginals"
 *      is-bulk-process="false"
 *      read-only="false">
 *</attachments>
 */

(function() {
    'use strict';

    angular.module('bizflow.angular.component')
        .filter('printCreatorName', function() {
            return function(input) {
                if (input && input.CREATORNAME) {
                    if (input.TYPE == 'C' ||
                        angular.lowercase(input.CREATORNAME).indexOf('agent') > -1 ||
                        input.CREATORNAME == 'ERA User') {
                        return 'System';
                    } else {
                        return input.CREATORNAME;
                    }
                } else {
                    return '';
                }
            };
        });

    angular.module('bizflow.angular.component')
        .component('attachments', {
            templateUrl: function($element, $attrs, bizflowContext) {
                return '../cmscommon/js/angularjs/common/components/attachment/attachments.html';
            },
            bindings: {
                processId: '<',
                documentTypes: '<',
                showHideOriginals: '<?',
                isBulkProcess: '<?',
                readOnly: '<?',
                onChangeCallback: '&',
                processType: '<'
            },
            controller: CtrlAttachments
        });

    function CtrlAttachments(bizflowWih, bizflowContext, inform, $window, $uibModal, blockUI, $scope, $log, $timeout) {
        var vm = this;
        vm.attachments = [];
        vm.selectedTypeName = null;
        vm.currentActivityName = bizflowContext.custom.ACTIVITYNAME;
        vm.mainFormReadOnly = false;
        if (vm.readOnly == true){
            vm.mainFormReadOnly = true;
        }

        vm.$onInit = function() {
            if (bizflowWih.basicWih) {
                bizflowWih.setChangeWorkitemAttachmentCallback(function() {
                    vm.reloadAttachments();
                });
            }
            vm.loadAttachments();

            try {
                $timeout(function() {
                    $scope.$apply(function() {
                        vm.currentActivityName = bizflowContext.custom.ACTIVITYNAME;
                        vm.mainFormReadOnly = false;
                        if (vm.readOnly == true){
                            vm.mainFormReadOnly = true;
                        }
                    });
                });
            } catch(e) {
            }
        };

        vm.showAddButton = function() {
            var showButton = false;
            if (vm.mainFormReadOnly != true) {
                if (vm.processType === 'Eligibility') {
                    if (vm.currentActivityName ==='Update the Request') {
                        showButton = true;
                    }
                } else {
                    if (vm.currentActivityName !='Confirm BUS Code') {
                        showButton = true;
                    }
                }
            }

            return showButton;
        }

        vm.showGeneratePackageButton = function () {
            return vm.mainFormReadOnly != true && vm.processType == 'Classification' && vm.currentActivityName == 'Approve Coversheet and Create Final Pkg';
        }

        vm.showRefreshPDCoversheetButton = function() {
            return vm.mainFormReadOnly != true && vm.processType == 'Classification' && (vm.currentActivityName == 'Review DWC Entry' || vm.currentActivityName == 'Confirm Final BUS Code');
        }

        vm.$onDestroy = function() {
        };

        /**
         * Attachments
         */
        vm.loadAttachments = function() {
            if (bizflowWih && bizflowWih.basicWih) { // Get attachments from basic WIH
                vm.attachments = bizflowWih.getAttachments();
                if (vm.attachments != null && vm.attachments.length) {
                    for (var i = 0; i < vm.attachments.length; i++) {
                        var category = vm.documentTypes.dataMap[vm.attachments[i].CATEGORY];
                        if (category && category.length > 0) {
                            vm.attachments[i].category = category;
                        } else {
                            vm.attachments[i].category = {'LABEL' : vm.attachments[i].CATEGORY};
                        }
                    }
                    vm.onChangeCallback();
                }
            } else {
                console.log("ERROR - No BizFlow Workitem Handler found!")
            }
        };

        vm.reloadAttachments = function() {
            vm.loadAttachments();
            blockUI.stop();
            $scope.$digest();
        };

        vm.getAttachmentUrl = function(processId, attachmentId) {
            var url = bizflowWih.getAttachmentUrl(processId, attachmentId);
            return url;
        };

        vm.deleteAttachment = function(id) {
            bootbox.confirm("Do you want to delete the file?", function(result) {
                if (result) {
                    if (!bizflowWih.basicWih) {
                        alert("Deleting Document Type requires Workitem Handler");
                    } else {
                        bizflowWih.removeAttachment(id, function() {
                            bizflowWih.reloadAttachments();
                            //vm.reloadAttachments();           // TODO: CHECK THIS
                            vm.onChangeCallback();
                        });
                    }
                }
            });
        };

        vm.updateAttachmentDocType = function(attachment, newDocType, metadata) {
            if (!bizflowWih.basicWih) {
                inform.add("Updating Document Type requires Workitem Handler", {
                    ttl: 3000
                });
            } else {
                attachment.CATEGORY = newDocType;
                if (metadata != undefined) {
                    attachment.edmsMetadata = metadata;
                }
                bizflowWih.updateAttachments(angularExt.objectToArray(attachment));
                vm.loadAttachments();
            }
        };

        vm.replaceAttachment = function(attachment) {
            $uibModal.open({
                template: '<replace-attachment ' +
                                '$close="$close(result)" ' +
                                'callback="$ctrl.callback" selected-attachment="$ctrl.selectedAttachment"></add-attachment>',
                backdrop: 'static',
                animation: true,
                size: 'lg',
                windowClass: 'attachmentAddWindow',
                controller: function() {
                    this.callback = vm.reloadAttachments;
                    this.selectedAttachment = attachment;
                },
                controllerAs: '$ctrl'
            }).result.then(function(result) {
                vm.onChangeCallback();
            });
        };

        vm.addAttachment = function(selectedTypeName) {
            $uibModal.open({
                template: '<add-attachment $close="$close(result)" document-types="$ctrl.documentTypes" callback="$ctrl.callback" selected-type-name="$ctrl.selectedTypeName"></add-attachment>',
                backdrop: 'static',
                animation: true,
                appendTo: (selectedTypeName ? '' : angular.element('#cmscommon_attachmentBody')),
                size: 'lg',
                windowClass: 'attachmentAddWindow',
                controller: function() {
                    this.documentTypes = vm.documentTypes;
                    this.callback = vm.reloadAttachments;
                    vm.selectedTypeName = selectedTypeName
                    this.selectedTypeName = vm.selectedTypeName;
                },
                controllerAs: '$ctrl'
            }).result.then(function(result) {
                vm.onChangeCallback();
            });
        };

        vm.viewAllViewableAttachments = function() {
            $window.getAppScope = function() {
                vm.bizflowWih = bizflowWih;
                return vm;
            };
            $window.open(bizflowContext.appContextPath + "/common/components/attachment/attachment-carousel-viewer-app.html?procid=" + vm.processId, "ViewAttachments", "toolbar=0,resizable=1");
        };

        vm.openModalViewAllViewableAttachments = function() {
            var modalInstance = $uibModal.open({
                templateUrl: '../fragments/attachment-carousel-viewer.html',
                controller: 'viewAttachmentsController',
                resolve: {
                    attachments: function() {
                        return vm.attachments;
                    },
                    callback: function() {
                        return function() {}
                    }
                },
                windowClass: 'attachmentViewWindow',
                size: "lg"
            });
        };

        //--------------------------------
        // CMS Extension
        //--------------------------------
        vm.reloadAttachments2 = function() {
            bizflowWih.basicWih.reloadAttachments({event:'UPDATED', forceLoad: true});
        }
        vm.generatePDCoversheet = function() {
            enableTabsForSubmission();
            captureSelDispVal();
            var targetUrl = '/classification_main/refreshPDCoversheet.do';
            callPartialPage(null, targetUrl, null, 'async_save_pp_group');
            rollbackTabsAfterSubmission();
        };

        vm.generatePackage = function() {
            $uibModal.open({
                template: '<generate-package attachments="$ctrl.attachments" '
                                + '$close="$close(result)" document-types="$ctrl.documentTypes" '
                                + 'callback="$ctrl.callback" selected-type-name="$ctrl.selectedTypeName"></add-attachment>',
                backdrop: 'static',
                animation: true,
                size: 'xl',
                windowClass: 'attachmentAddWindow',
                controller: function() {
                    this.documentTypes = vm.documentTypes;
                    this.callback = vm.reloadAttachments;
                    this.attachments = vm.attachments;
                },
                controllerAs: '$ctrl'
            }).result.then(function(result) {
                if (result.result == 'ok') {
                    setTimeout(function() {
                        blockScreen("<p style='font-size:30px;color:white;'>Creating Package...</p>");
                    }, 1);

                    var sessionInfoXML = $('#cmscommon_sessioninfo').val();
                    var procID = $('#cmscommon_procid').val();

                    if (result.grade == 'N/A') {
                        result.grade = 0;
                    }

                    $.ajax({
                		type: "POST",
                		url: "/bizflowwebmaker/cmscommon/generateFinalPackage.do",

                		data: {
                            sessionInfo: sessionInfoXML,
                            processID: procID,
                            grade: result.grade,
                            fileName: result.filename,
                            IDs: result.files
                        },
                		dataType: "json",
                		cache:false,
                		success: function(response) {
                			if(response.success)
                			{
                                vm.onChangeCallback();
                			}
                			else if(response.message)
                			{
                				console.log('ERROR - ' + response.message);
                			}
                            blockUI.stop();
                		},
                		error: function(e){
                            if (e.status == 200 && e.statusText == 'OK') {
                                //loadAttachments();
                                vm.onChangeCallback();
                                bizflowWih.basicWih.reloadAttachments({event:'UPDATED', forceLoad: true})
                            } else {
                                console.log('Failed to generate final package: ' + e.statusText);
                            }
                            unblockScreen();
                            bootbox.alert('Position Description Package [' + result.filename + '] is added to document list.');
                		}
                	});
                } else {
                    console.log("Cancelled.");
                }
            });
        };
    }

    angular.module('bizflow.angular.component')
        .component('attachmentList', {
            templateUrl: function($element, $attrs, bizflowContext) {
                return '../cmscommon/js/angularjs/common/components/attachment/attachment-list.html';
            },
            bindings: {
                documentTypes: '<',
                showHideOriginals: '<?',
                isBulkProcess: '<?',
                readOnly: '<?',
                attachments: '=',
                processType: '<?'
            },
            require: {
                main: '^attachments'
            },
            controller: CtrlAttachmentList
        });

    //function CtrlAddAttachment($scope, $timeout, bizflowContext, FileUploader, bizflowWih, blockUI) {
    function CtrlAttachmentList($log, bizflowContext, bizflowWih, blockUI) {
        var vm = this;
        vm.documentTypeForList = [];

        vm.$onInit = function() {
            vm.documentTypeForList = Object.create(vm.documentTypes);
            var count = vm.documentTypeForList.length;
            for (var index = count - 1; index >= 0; index--) {
                if (vm.documentTypeForList[index].Name == 'FLSA'
                    || vm.documentTypeForList[index].Name == 'FLSA Exempt'
                    || vm.documentTypeForList[index].Name == 'FLSA Non-Exempt'
                    || vm.documentTypeForList[index].Name == 'PD Coversheet'
                    || vm.documentTypeForList[index].Name == 'Final Package') {
                    vm.documentTypeForList.splice(index, 1);
                }
            }
        };

        vm.$onDestroy = function() {
        };

        vm.canChangeDocumentType = function(attachment) {
            var result = true;
            var documentType = attachment.CATEGORY;
            if (documentType == 'FLSA' 
            || documentType == 'PD Coversheet' 
            || documentType == 'Final Package') {
                result = false;
            }
            return result;
        };

        vm.changeFileType = function(attachment, $select) {
            attachment.CATEGORY = $select.selected.LABEL; 
            $(document).trigger('ON_DOCUMENT_CHANGE');
            if (bizflowWih && bizflowWih.basicWih) {
                bizflowWih.updateAttachments(angularExt.objectToArray(attachment));
            } else {
                inform.add("Updating Document Type requires Workitem Handler", {
                    ttl: 3000
                });
            }
        };

        vm.showDeleteButton = function (attachment) {
            var showButton = false;
            var activityName = vm.main.currentActivityName;
            if (vm.main.mainFormReadOnly != true && vm.main.deleteAttachment) {
                if (activityName == 'Approve Coversheet and Create Final Pkg') {
                    if (attachment.category != null && attachment.category.LABEL == 'Final Package') {
                        showButton = true;
                    }
                } else {
                    if (vm.processType === 'Eligibility') {
                        if (activityName === 'Update the Request') {
                            if (attachment.category != null
                                && attachment.category.LABEL != 'FLSA'
                                && attachment.category.LABEL != 'FLSA Exempt'
                                && attachment.category.LABEL != 'FLSA Non-Exempt'
                                && attachment.category.LABEL != 'PD Coversheet'
                                && attachment.category.LABEL != 'Final Package') {
                                showButton = true;
                            }
                        }
                    } else {
                        if (activityName != 'Confirm BUS Code') {
                            if (attachment.category != null
                                && attachment.category.LABEL != 'FLSA'
                                && attachment.category.LABEL != 'FLSA Exempt'
                                && attachment.category.LABEL != 'FLSA Non-Exempt'
                                && attachment.category.LABEL != 'PD Coversheet'
                                && attachment.category.LABEL != 'Final Package') {
                                showButton = true;
                            }
                        }
                    }
                }
            }
            return showButton;
        };

        // Conduct Eligibility and Qualifications Review   -- All readonly
        // Approve Candidate for Appointment - All readonly
        // Select Candidate for Appointment - All readonly
        // Update the Request - Upload/Replace/Delete except classification documents.

        vm.showReplaceButton = function(attachment) {
            var showButton = false;
            var activityName = vm.main.currentActivityName;
            if (vm.main.mainFormReadOnly != true && vm.main.replaceAttachment) {
                if (vm.processType === 'Classification') {
                    if (activityName == 'Approve PD Coversheet - SO' || activityName == 'Approve Coversheet and Create Final Pkg') {
                        if (attachment.category != null
                            && (attachment.category.LABEL == 'FLSA' 
                                || attachment.category.LABEL == 'FLSA Exempt' 
                                || attachment.category.LABEL == 'FLSA Non-Exempt' 
                                || attachment.category.LABEL == 'PD Coversheet')) {
                            showButton = true;
                        }
                    }
                } else if (vm.processType === 'Eligibility') {
                    if (activityName === 'Update the Request') {
                        if (attachment.category !== null 
                            && attachment.category.LABEL != 'FLSA'
                            && attachment.category.LABEL != 'FLSA Exempt'
                            && attachment.category.LABEL != 'FLSA Non-Exempt'
                            && attachment.category.LABEL != 'PD Coversheet'
                            && attachment.category.LABEL != 'Final Package') {
                            showButton = true;
                        }
                    }
                }
            }
            return showButton;
        };
    }

    angular.module('bizflow.angular.component')
        .component('addAttachment', {
            templateUrl: function($element, $attrs, bizflowContext) {
                //return bizflowContext.appContextPath + '/common/components/attachment/attachment-add.html';
                return '../cmscommon/js/angularjs/common/components/attachment/attachment-add.html';
            },
            bindings: {
                $close: '&',
                documentTypes: '=',
                callback: '=',
                selectedTypeName:  '='
            },
            controller: CtrlAddAttachment
        });

    function CtrlAddAttachment($scope, $timeout, bizflowContext, FileUploader, bizflowWih, blockUI) {
        var vm = this;
        vm.selectedType = null;

        vm.$onInit = function() {
            if (vm.selectedTypeName != null) {
                for (var index = 0; index < vm.documentTypes.length; index++) {
                    if (vm.documentTypes[index].Name == vm.selectedTypeName) {
                        vm.selectedType = vm.documentTypes[index];
                        break;
                    }
                }
            } else {
                var count = vm.documentTypes.length;
                for (var index = count - 1; index >= 0; index--) {
                    if (vm.documentTypes[index].Name == 'FLSA'
                        || vm.documentTypes[index].Name == 'FLSA Exempt'
                        || vm.documentTypes[index].Name == 'FLSA Non-Exempt'
                        || vm.documentTypes[index].Name == 'PD Coversheet'
                        || vm.documentTypes[index].Name == 'Final Package') {
                        vm.documentTypes.splice(index, 1);
                    }
                }
            }
        };

        // with or without WIH
        var config;
        if (bizflowWih.basicWih) {
            config = {
                url: bizflowContext.getUrl('/bizcoves/wih/attachUpload.jsp?basicWihReadOnly=n'),
                formData: [{
                    attachType: 'file',
                    attachUrlName: '',
                    attachUrl: '',
                    hdmMetaFilePath: '',
                    responseType: 'JSON'
                }]
            };
        } else {
            config = {
                url: bizflowContext.getServiceUrl('/bizflow/attachment/upload.json'),
                formData: [{
                    processId: bizflowContext.custom.PROCESSID,
                    responseType: 'JSON'
                }]
            };
        }

        vm.uploader = $scope.uploader = new FileUploader(config);

        vm.isReadyToUpload = function() {
            if (vm.uploader.queue.length && vm.uploader.queue.length > 0) {
                for (var i = 0; i < vm.uploader.queue.length; i++) {
                    var item = vm.uploader.queue[i];
                    if (angularExt.isInvalidObject(item.category)) {
                        if (vm.selectedType != null) {
                            item.category = vm.selectedType
                        } else {
                            return false;
                        }
                    }
                }
                return true;
            }
            return false;
        };

        vm.upload = function() {
            if (vm.uploader.queue.length == 0) {
                alert("Please Select File(s)");
            } else if (vm.uploader.queue.filter(function(el) {
                    return el.category == undefined
                }).length > 0) {
                alert("Please Select Document Type");
            } else {
                $timeout(function() {
                    blockUI.start();
                }, 1);
                vm.uploader.uploadAll();
            }
        };

        vm.cancel = function() {
            vm.uploader.clearQueue();
            vm.$close({
                result: 'cancel'
            });
        };

        vm.uploader.filters.push({
            name: 'customFilter',
            fn: function(item /*{File|FileLikeObject}*/ , options) {
                return this.queue.length < 10;
            }
        });

        vm.uploader.onBeforeUploadItem = function(item) {
            if (item.category) {
                item.error = null;
                var formData = [{
                    category: item.category.Name,
                    description: item.description || "",
                    etcInfo: "",
                    edmsMetadata: ""
                }];
                Array.prototype.push.apply(item.formData, formData);
            }
        };

        vm.uploader.onCompleteAll = function() {
            vm.uploader.clearQueue();
            vm.$close({
                result: 'cancel'
            });
            if (bizflowWih && bizflowWih.basicWih) {
                bizflowWih.reloadAttachments();
            }
            if (vm.callback) {
                vm.callback();
            } else {
                blockUI.stop();
            }
        };

        vm.clickSelectFileButtonMouse = function() {
            setTimeout(function() {
                $('#cmsattachment_fileInput').trigger('click');
            })
        }
        vm.clickSelectFileButtonKeyboard = function(event) {
            if (event.type == 'keydown' && (event.key == ' ' || event.key == 'Enter')) {
                setTimeout(function() {
                    $('#cmsattachment_fileInput').trigger('click');
                })
            }
        }
    }

    angular.module('bizflow.angular.component')
        .component('replaceAttachment', {
            templateUrl: function($element, $attrs, bizflowContext) {
                return '../cmscommon/js/angularjs/common/components/attachment/attachment-replace.html';
            },
            bindings: {
                $close: '&',
                callback: '=',
                selectedAttachment:  '='
            },
            controller: CtrlReplaceAttachment
        });

    function CtrlReplaceAttachment($scope, $timeout, bizflowContext, FileUploader, bizflowWih, blockUI) {
        var vm = this;

        var config = {};
        if (bizflowWih.basicWih) {
            config = {
                //url: bizflowContext.getUrl('/bizcoves/wih/attachUpload_HHS.jsp?basicWihReadOnly=n'),
                url: bizflowContext.getUrl('/solutions/cms/attachment/HHSAttachUpload.jsp?basicWihReadOnly=n'),
                formData: [{
                    attachType: 'file',
                    attachUrlName: '',
                    attachUrl: '',
                    hdmMetaFilePath: '',
                    responseType: 'JSON'
                }]
            };
        } else {
            config = {
                url: bizflowContext.getServiceUrl('/bizflow/attachment/upload.json'),
                formData: [{
                    processId: bizflowContext.custom.PROCESSID,
                    responseType: 'JSON'
                }]
            };
        }

        vm.uploader = $scope.uploader = new FileUploader(config);
        vm.uploader.clearQueue();

        vm.isTouchedBackground = false;
        vm.isReadyToUpload = function() {
            if (vm.uploader.queue.length && vm.uploader.queue.length > 0) {
                if (vm.isTouchedBackground == false) {
                    vm.isTouchedBackground = true;
                    // $timeout(function() {
                    //     $('#cmscommon_attachment_button_section').focus();;
                    // }, 1);
                }
                return true;
            }
            return false;
        };

        vm.upload = function() {
            if (vm.uploader.queue.length == 0) {
                alert("Please Select File(s)");
            } else {
                $timeout(function() {
                    blockUI.start();
                }, 1);
                vm.uploader.uploadAll();
            }
        };

        vm.cancel = function() {
            vm.uploader.clearQueue();
            vm.$close({
                result: 'cancel'
            });
        };

        vm.uploader.filters.push({
            name: 'customFilter',
            fn: function(item /*{File|FileLikeObject}*/ , options) {
                return this.queue.length < 10;
            }
        });

        vm.uploader.onBeforeUploadItem = function(item) {
            item.error = null;
            var formData = [{
                action: 'update',
                attachSeq: vm.selectedAttachment.ID,
                description: vm.selectedAttachment.DESCRIPTION,
                category: vm.selectedAttachment.CATEGORY,
                etcInfo: vm.selectedAttachment.ETCINFO
            }];

            Array.prototype.push.apply(item.formData, formData);
        };

        vm.uploader.onCompleteAll = function() {
            vm.uploader.clearQueue();
            vm.$close({
                result: 'cancel'
            });
            if (bizflowWih && bizflowWih.basicWih) {
                bizflowWih.reloadAttachments();
            }
            if (vm.callback) {
                vm.callback();
            } else {
                blockUI.stop();
            }
        };

        vm.$onInit = function() {
            // $('#cmscommon_attachment_button_section').focus();
        };

        vm.clickSelectFileButtonMouse = function() {
            setTimeout(function() {
                $('#cmsattachment_fileInput').trigger('click');
            })
        }
        vm.clickSelectFileButtonKeyboard = function(event) {
            if (event.type == 'keydown' && (event.key == ' ' || event.key == 'Enter')) {
                setTimeout(function() {
                    $('#cmsattachment_fileInput').trigger('click');
                })
            }
        }        
    }
// -------------------------------
// buildViewAttachmentController
// -------------------------------
    function buildViewAttachmentController($scope, attachments, bizflowWih) {
        $scope.attachments = attachments;
        $scope.getDocumentExt = function(attachment) {
            var ext = null;
            var filename = attachment.FILENAME;
            var idx = filename.lastIndexOf(".");
            if (-1 != idx) {
                ext = filename.substring(idx).toLowerCase();
            }

            return ext;
        };
        $scope.getAttachmentUrl = function(attachment) {
            return bizflowWih.getAttachmentUrl(attachment.ID);
        };
        $scope.isImage = function(attachment) {
            var v = false;
            var ext = this.getDocumentExt(attachment);
            if (null != ext) {
                var visibleExts = ".png,.jpg,.jpeg,.gif,";
                v = -1 != visibleExts.indexOf(ext + ",");
            }

            return v;
        };
        $scope.isNotVisibleDocumentInIE = function(ext) {
            var exts = ".pdf,";
            return -1 == exts.indexOf(ext + ",");
        };
        $scope.isVisibleDocument = function(attachment) {
            var v = false;
            var ext = this.getDocumentExt(attachment);
            if (null != ext) {
                var visibleExts = ".pdf,.txt,";
                v = -1 != visibleExts.indexOf(ext + ",");
                //if (v && angularExt.browser.IsIE) {
                //    v = this.isNotVisibleDocumentInIE(ext);
                //}
            }

            return v;
        };
    }

    angular.module('bizflow.angular.component')
        .controller('viewAttachmentsController', ['$scope', '$uibModalInstance', 'attachments', 'bizflowWih',
            function($scope, $uibModalInstance, attachments, bizflowWih) {
                buildViewAttachmentController($scope, attachments, bizflowWih);
                $scope.cancel = function() {
                    $uibModalInstance.dismiss('cancel');
                };
            }
        ]);

    //--------------------------------
    // CMS Extension
    //--------------------------------
    angular.module('bizflow.angular.component')
        .component('generatePackage', {
            templateUrl: function($element, $attrs, bizflowContext) {
                //return bizflowContext.appContextPath + '/common/components/attachment/attachment-add.html';
                return '../cmscommon/js/angularjs/common/components/attachment/generate-package.html';
            },
            bindings: {
                $close: '&',
                documentTypes: '=',
                callback: '=',
                attachments: '='
            },
            controller: CtrlGeneratePackage
        });

    function CtrlGeneratePackage($scope, $timeout, bizflowContext, bizflowWih, blockUI) {
        var vm = this;
        vm.selectedType = null;

        // with or without WIH
        //var config;

        vm.selectedGrade;
        vm.grades = [];
        vm.exempts = [];
        vm.targetFileName = "";

        vm.attachmentFilter = function(attachment) {
            return attachment.FILEEXTENSION == 'pdf' && attachment.ETCINFO.indexOf('PACKAGE') == -1;
        };

        vm.getSelectedDocumentID = function() {
            var IDString = "";
            var selected = $('#PDFDocumentList input[name="PDFCheckBox"]:checked');

            var count = selected.length;
            for (var index = 0; index < count; index++) {
                IDString += selected[index].value;
                if (index + 1 < count) {
                    IDString += ",";
                }
            }
            return IDString;
        };

        vm.isReadyToRequest = function() {
            var isReady = false;
            var selectedIDString = vm.getSelectedDocumentID();
            if (vm.selectedGrade != 0 && vm.targetFileName.length > 0 && selectedIDString.length > 0)
            {
                isReady = true;
            }
            return isReady;
        };

        vm.cancel = function() {
            vm.$close({
                result: 'cancel'
            });
        };

        vm.getFinalFileName = function() {
            var index = vm.targetFileName.lastIndexOf('.pdf');
            if (index != -1 && index == vm.targetFileName.length - 4) {
                return vm.targetFileName;
            } else {
                return vm.targetFileName + '.pdf';
            }
        };

        vm.requestGeneratePackage = function() {
            vm.$close({
                result: {
                    result: 'ok',
                    grade: vm.selectedGrade,
                    filename: vm.getFinalFileName(),
                    files: vm.getSelectedDocumentID()
                }
            });
        };

        vm.$onInit = function() {
            for (var index = 1; index <= 5; index++) {
                var IDPredicate = '#CS_GR_ID_' + index + ' option:selected';
                var grade = $(IDPredicate).text();

                if (grade != null && grade.length > 0 && grade != 'Select One') {
                    vm.grades.push(grade);

                    var ExemptPredicate = '#CS_FLSA_DETERM_ID_' + index + ' option:selected';
                    var exempt = $(ExemptPredicate).text();
                    vm.exempts.push(exempt);
                } else {
                    break;
                }
            }

            if (vm.grades.length == 0) {
                vm.grades.push('N/A');
            }

            if (vm.selectedTypeName != null) {
                for (var index = 0; index < vm.documentTypes.length; index++) {
                    if (vm.documentTypes[index].Name == vm.selectedTypeName) {
                        vm.selectedType = vm.documentTypes[index];
                        break;
                    }
                }
            }

            vm.attachments.forEach(function(attachment) {
                attachment.selected = false;
            })
        }
    }

})();
