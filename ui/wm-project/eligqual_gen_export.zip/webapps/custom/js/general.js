var base_url = '/bizflowwebmaker/StratCon_AUT/';

var eligQualGenObj = {
	separator: ',',
	longSeparator: '_/~'
}

var eligQualGen = function(){
	CMSUtility.debugLog('ELIGQUALGEN - eligQualGen START');

	var isSelectingOfficial = EligQualMain.isCurrentUserMemberOf('Selecting Officials');
	
	var onChangeRequestType = function(){
		var preselect = $('#SG_CT_ID').val();
		$('#SG_CT_ID').empty();
		$('#classification_type_parent').val($('#SG_RT_ID :selected').val());
		$('#classification_type_parent :selected').each(function(){
			var $tmp = $('#classification_type_data option[value="' + $(this).text() + '"]');
			$('#SG_CT_ID').append('<option value=' + $tmp.val() + '>' + $tmp.text() + '</option>');
		});
		if (preselect !== undefined) {
			$('#SG_CT_ID').val(preselect);
		}
		hyf.util.hideComponent('layout_group_so_agree', null, null, null);
		
		var requestType = $('#SG_RT_ID :selected').text();
		if (requestType != null && requestType.length > 0) {
			requestType = requestType.toLowerCase();
		}

		if (requestType != 'recruitment') {
			$('#COMMISSIONED_NOTE').addClass('hidden');
			$('#OTHER_CERT_DIV').addClass('hidden');
			$('#certSearch_display').empty();
			$('#SG_OTHER_CERT').val('');
		} else {
			$('#OTHER_CERT_DIV').removeClass('hidden');

			if (isSelectingOfficial == true) {
				hyf.util.showComponent('layout_group_so_agree', null, null, null);
			}
			$('#COMMISSIONED_NOTE').removeClass('hidden');
		}
		showHideClassificationType();
		showHideAppointmentType();
		showHideStaffSpecialistGroup();

		try {
			// function from position.js
			if (eligQualPos && eligQualPos.showHideAppointmentFields) {
				eligQualPos.showHideAppointmentFields();
			} else {
				CMSUtility.errorLog('general.js - Not Found eligQualPos.showHideAppointmentFields.')
			}
		} catch (e) {
			CMSUtility.errorLog('Exception occurred from eligQualPos.showHideAppointmentFields(). [' + e + ']');
		}

		try {
			if (eligQualPos && eligQualPos.showHideFieldsBasedOnContext) {
				eligQualPos.showHideFieldsBasedOnContext();
			} else {
				CMSUtility.errorLog('general.js - Not Found eligQualPos.showHideFieldsBasedOnContext');
			}
		} catch (e) {
			CMSUtility.errorLog('Exception occurred from eligQualPos.showHideFieldsBasedOnContext(). [' + e + ']');
		}
	} // end of function onChangeRequestType
	
	var onChangeAppointmentType = function(){
		CMSUtility.debugLog('ELIGQUALGEN - onChangeAppointmentType START');
		var requestType = $('#SG_RT_ID :selected').text();
		var appointmentType = $('#SG_AT_ID :selected').text();

		if (requestType == 'Appointment' && appointmentType == 'Schedule A') {
			$('#SG_VT_ID').val('');
			hyf.util.showComponent('layout_group_SAT', null, null, null);
			hyf.util.hideComponent('layout_group_VOL', null, null, null);
		} else if (requestType == 'Appointment' && appointmentType == 'Volunteer') {
			$('#SG_SAT_ID').val('');
			hyf.util.hideComponent('layout_group_SAT', null, null, null);
			hyf.util.showComponent('layout_group_VOL', null, null, null);
		} else {
			$('#SG_VT_ID').val('');
			$('#SG_SAT_ID').val('');
			hyf.util.hideComponent('layout_group_SAT', null, null, null);
			hyf.util.hideComponent('layout_group_VOL', null, null, null);
		}

		showHideClassificationType();
		showHideStaffSpecialistGroup();

		try {
			if (eligQualPos && eligQualPos.showHideFieldsBasedOnContext) {
				eligQualPos.showHideFieldsBasedOnContext();
			} else {
				CMSUtility.errorLog('general.js - Not Found eligQualPos.showHideFieldsBasedOnContext');
			}
		} catch (e) {
			CMSUtility.errorLog('Exception occurred from eligQualPos.showHideFieldsBasedOnContext(). [' + e + ']');
		}

		CMSUtility.debugLog('ELIGQUALGEN - onChangeAppointmentType END');
	} // end of function onChangeAppointmentType
	
	
	// General tab will be read-only except for the "Conduct Eligibility and Qualifications Review" activity.
	// Moreover, even if tab itself is enabled for HR Staffing Specialist/Special Program Specialist, 
	// Job Request workflow defining fields, i.e. Request Type, Classification Type, Approintment Type, Volunteer Type, Schedule A Type,
	// should not be allowed to be changed all throughout the Eligibility and Qualifications Review process.
	/*
	$('#SG_RT_ID').on('change',function(e) {
		CMSUtility.debugLog('ELIGQUALGEN - SG_RT_ID.onChange START');

		onChangeRequestType();
		// Notify document tab so that it can retrieve new document types and mandatory documents.
		$(document).trigger('ON_DOCUMENT_CHANGE');

		CMSUtility.debugLog('ELIGQUALGEN - SG_RT_ID.onChange END');
	});

	$('#SG_CT_ID').on('change', function() {
		CMSUtility.debugLog('ELIGQUALGEN - SG_CT_ID.onChange START');

		// Notify document tab so that it can retrieve new document types and mandatory documents.
		$(document).trigger('ON_DOCUMENT_CHANGE');

		CMSUtility.debugLog('ELIGQUALGEN - SG_CT_ID.onChange END');
	});
	
	$('#SG_AT_ID').on('change', function() {
		CMSUtility.debugLog('ELIGQUALGEN - SG_AT_ID.onChange START');

		onChangeAppointmentType();
		// Notify document tab so that it can retrieve new document types and mandatory documents.
		$(document).trigger('ON_DOCUMENT_CHANGE');

		CMSUtility.debugLog('ELIGQUALGEN - SG_AT_ID.onChange END');
	});

	$('#SG_VT_ID').on('change', function() {
		CMSUtility.debugLog('ELIGQUALGEN - SG_VT_ID.onChange START');

		// Notify document tab so that it can retrieve new document types and mandatory documents.
		$(document).trigger('ON_DOCUMENT_CHANGE');

		CMSUtility.debugLog('ELIGQUALGEN - SG_VT_ID.onChange END');
	});
	*/

	//$('#SG_SO_ID').trigger('change');
	//$('#SG_XO_ID').trigger('change');
	//$('#SG_HRL_ID').trigger('change');
	onChangeRequestType();
	onChangeAppointmentType();
	setCertAutoComplete();
	//setACAutoComplete();
	setAutoComplete();
	
	if ($('#AC_ADMIN_CD_DESCR').val() != '') {
		var li_org_name = "<li id=\"" + $("#AC_ADMIN_CD").val() + "_dscr\">";
		var li_admin_cd = "<li id=\"" + $("#AC_ADMIN_CD").val() + "\">";
		// Admin Code should be locked down, hence should not show delete icon unconditionally
		//if ($('#h_readOnly').val() != 'y') {
		//	li_org_name += CMSUtility.getAutoCompRemoveIconElement($('#AC_ADMIN_CD').val() + '_dscr', $('#AC_ADMIN_CD_DESCR').val(), '35');
		//	li_admin_cd += CMSUtility.getAutoCompRemoveIconElement($('#AC_ADMIN_CD').val(), $('#AC_ADMIN_CD').val(), '25');
		//}
		li_admin_cd += $('#AC_ADMIN_CD').val() + '</li>';
		li_org_name += $('#AC_ADMIN_CD_DESCR').val() + '</li>';

		$('#SG_AC_DISP').append(li_admin_cd).removeClass('hidden');
		$('#SG_ON_DISP').append(li_org_name).removeClass('hidden');
		$('#SG_ADMIN_CD_INPUT_container').addClass('hidden');
		$('#SG_ORG_NAME_container').addClass('hidden');
		$('#SG_ORG_NAME').attr('_required', 'false');
		$('#SG_ADMIN_CD_INPUT').attr('_required', 'false');
	}

	if ($('#OTHER_CERT_DATA option').length != 0) {
		$('#OTHER_CERT_DATA option').each(function(){
			var li = "<li id=\"" + $(this).val() + "\">";
			if($('#h_readOnly').val() != 'y'){
				li += CMSUtility.getAutoCompRemoveIconElement($(this).val(), $(this).text(), '205');
			}
			li +=  $(this).text() + '</li>';
			$('#certSearch_display').append(li);

		});
	}
	
	$('#certSearch_display').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			$('#' + $(this).attr('deleteid')).remove();
			$('#SG_OTHER_CERT').val($('#SG_OTHER_CERT').val().replace($(this).attr('deleteid'),'')).replace(',,',',');
		}
	});
	
	// Admin Code is locked down entirely all throughout Eligibility and Qualifications Review process
	/*
	$('#SG_AC_DISP').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			$('#SG_AC_DISP').addClass('hidden').empty();
			$('#SG_ADMIN_CD_INPUT_container').removeClass('hidden');
			$('#SG_ADMIN_CD_INPUT').attr('_required', 'true');
			$('#SG_ON_DISP').addClass('hidden').empty();
			$('#SG_ORG_NAME_container').removeClass('hidden');
			$('#SG_ORG_NAME').attr('_required', 'true');
		}
	});

	$('#SG_ON_DISP').delegate('img', 'click keyup', function (e) {
		if (event.type == 'click' || (event.type == 'keyup' && (event.key == ' ' || event.key == 'Enter'))) {
			$('#SG_AC_DISP').addClass('hidden').empty();
			$('#SG_ADMIN_CD_INPUT_container').removeClass('hidden');
			$('#SG_ADMIN_CD_INPUT').attr('_required', 'true');
			$('#SG_ON_DISP').addClass('hidden').empty();
			$('#SG_ORG_NAME_container').removeClass('hidden');
			$('#SG_ORG_NAME').attr('_required', 'true');
		}
	});
	*/
	
	hyf.util.disableComponent('type_selection_group');
	
	CMSUtility.debugLog('ELIGQUALGEN - eligQualGen END');
}

var showHideAppointmentType = function() {
	var requestType = $('#SG_RT_ID :selected').text();
	if (requestType == 'Appointment') {
		// SHOW
		hyf.util.showComponent('layout_group_AT', null, null, null);
		$('#SG_AT_ID').trigger('change');
	} else {
		// HIDE
		$('#SG_AT_ID').val('');
		//$('#').val('');
		$('#SG_SAT_ID').val('');
		hyf.util.hideComponent('layout_group_AT', null, null, null);
	}
}

var showHideClassificationType = function() {
	var requestType = $('#SG_RT_ID :selected').text();
	var appointmentType = $('#SG_AT_ID :selected').text();

	if (requestType != 'Appointment'
		|| (appointmentType != 'Volunteer'
			&& appointmentType != 'Intergovernmental Personnel Act (IPA)')
			&& appointmentType != 'Expert/Consultant') {
		hyf.util.showComponent('layout_group_CT', null, null, null);
		hyf.util.showComponent('clsf_prticipant_group', null, null, null);
	} else {
		$('#SG_CT_ID').val('');
		$('#CS_ID').val('');
		hyf.util.hideComponent('layout_group_CT', null, null, null);
		hyf.util.hideComponent('clsf_prticipant_group', null, null, null);
	}
}

var showHideStaffSpecialistGroup = function() {
	var isSpecial = EligQualMain.isSpecialProgram();
	if (isSpecial == true) {
		hyf.util.disableComponent('SS_ID');
		$('#SS_ID').attr('donotsubmit', 'true');
		
		hyf.util.enableComponent('SP_ID');
		$('#SP_ID').removeAttr('donotsubmit');
		
		hyf.util.hideComponent('staff_prticipant_group', null, null, null);
		hyf.util.hideComponent('spcprg_prticipant_group', null, null, null);
		
		$('#pv_specialProgram').val('Yes');
	} else {
		hyf.util.disableComponent('SP_ID');
		$('#SP_ID').attr('donotsubmit', 'true');

		hyf.util.enableComponent('SS_ID');
		$('#SS_ID').removeAttr('donotsubmit');

		var requestType = $('#SG_RT_ID :selected').text();
		if (requestType == 'Classification Only') {
			$('#SS_ID').val('');
			hyf.util.hideComponent('staff_prticipant_group', null, null, null);
		} else if (requestType == 'Recruitment') {
			hyf.util.showComponent('staff_prticipant_group', null, null, null);
		} else if (requestType == 'Appointment') {
			var appointmentType = $('#SG_AT_ID :selected').text(); // HRB-1654
			if (appointmentType == 'Intergovernmental Personnel Act (IPA)') {
				$('#SS_ID').val('');
				hyf.util.hideComponent('staff_prticipant_group', null, null, null);
			} else {
				hyf.util.showComponent('staff_prticipant_group', null, null, null);
			}
		} else {
			hyf.util.showComponent('staff_prticipant_group', null, null, null);
		}
		hyf.util.hideComponent('spcprg_prticipant_group', null, null, null);
		$('#pv_specialProgram').val('No');
	}

	$(document).trigger('EQG_SPECIAL_PROGRAM_CHANGED');
}

var setCertAutoComplete = function () {
	$('#certSearch').autocomplete({
		source: function (request, response) {
			$.ajax({
				url: base_url + 'SearchPeople.do?searchString=' + $('#certSearch').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						return {
							value: '',
							name: $( 'DSPNAME', this ).text() + ' (' + $( 'DEPTNAME', this ).text() + ')' ,
							id: $( 'MID', this ).text(),
							email: $( 'EMAIL', this ).text()
						};
					}).get();
					response(data);
				}

			})
		},
		minLength: 1,
		change: function (e, u) {
			var pos = $(this).position();
			if (u.item == null) {
				//Clear the AutoComplete TextBox.
				$('#certSearch_noMatch').remove();
				$(this).after("<span id='certSearch_noMatch' class='acNoMatch'>Invalid Selection:<br />Item must be selected from the available options.</span>");
				$('#certSearch_noMatch').css({top: pos.top + 20, left: pos.left + 30, position:'absolute'});
				setTimeout(function() {
					$('#certSearch_noMatch').remove();
				}, 2000);
				$(this).val('');
				return false;
			}
		},
		select: function (event, ui) {
			var sep = ',';
			if ($("#certSearch_display li[id='" + ui.item.id + "']").length == 0) {
				var li = "<li id=\"" + ui.item.id + "\">";
				li += CMSUtility.getAutoCompRemoveIconElement(ui.item.id, ui.item.name, '205');
				li += ui.item.name + ' ' + ui.item.email + '</li>';

				$('#certSearch_display').append(li);
				if($('#SG_OTHER_CERT').val() == ''){sep = '';}
				$('#SG_OTHER_CERT').val($('#SG_OTHER_CERT').val() + sep + ui.item.id);
			}
		},
		open: function(){
			 $('.ui-autocomplete').css('z-index', 5000);
		},
		close: function(){
			 $('.ui-autocomplete').css('z-index', 1);
		}
	})
	.autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
		return $('<li>')
		.append('<a>' + item.name + '</a>')
		.appendTo(ul);
	};
}

// Admin Code is locked down entirely all throughout Eligibility and Qualifications Review process
/*
var setACAutoComplete = function () {
	$('#SG_ADMIN_CD_INPUT').autocomplete({
		source: function (request, response) {
			$.ajax({
				url: base_url + 'SearchAdmOffOrg.do?searchAdmOff=' + $('#SG_ADMIN_CD_INPUT').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						return {
							//ac_id: $( 'AC_ID', this ).text(),
							admin_cd: $( 'AC_ADMIN_CD', this ).text(),
							admin_desc: $( 'AC_ADMIN_CD_DESCR', this ).text()
						};
					}).get();
					response(data);
				}
			})
		},
		minLength: 2,
		change: function (e, u) {
			//If the No match found" u.item will return null, clear the TextBox.
			if (u.item == null) {
				//Clear the AutoComplete TextBox.
				var pos = $(this).position();
				$('#SG_ADMIN_CD_INPUT_noMatch').remove();
				$(this).after("<span id='SG_ADMIN_CD_INPUT_noMatch' class='acNoMatch'>Invalid Selection:<br />Item must be selected from the available options.</span>");
				$('#SG_ADMIN_CD_INPUT_noMatch').css({top: pos.top + 20, left: pos.left + 30, position:'absolute'});
				setTimeout(function() {
					$('#SG_ADMIN_CD_INPUT_noMatch').remove();
				}, 2000);
				$(this).val('');
				return false;
			}
		},
		select: function (event, ui) {
			var li_admin_cd = "<li id=\"" + ui.item.admin_cd + "\" >";
			li_admin_cd += CMSUtility.getAutoCompRemoveIconElement(ui.item.admin_cd, ui.item.admin_cd, '25');
			li_admin_cd += ui.item.admin_cd + '</li>';

			var li_org_name = "<li id=\"" + ui.item.admin_cd + "_dscr\" >";
			li_org_name += CMSUtility.getAutoCompRemoveIconElement(ui.item.admin_cd + '_dscr', ui.item.admin_desc, '35');
			li_org_name += ui.item.admin_desc + '</li>';

			$('#SG_AC_DISP').append(li_admin_cd).removeClass('hidden');
			$('#SG_ADMIN_CD_INPUT_container').addClass('hidden');
			$('#SG_ADMIN_CD_INPUT').attr('_required', 'false');
			$('#SG_ON_DISP').append(li_org_name).removeClass('hidden');
			$('#SG_ORG_NAME_container').addClass('hidden');
			$('#SG_ORG_NAME').attr('_required', 'false');
			$('#SG_ADMIN_CD').val(ui.item.admin_cd);
		},
		open: function() {
			 $('.ui-autocomplete').css('z-index', 5000);
		},
		close: function() {
			 $('.ui-autocomplete').css('z-index', 1);
		}
	})
	.autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
		return $('<li>')
			.append('<a>' + item.admin_cd + ' - '  + item.admin_desc + '</a>')
			.appendTo(ul);
	};

	$('#SG_ORG_NAME').autocomplete({
		source: function (request, response) {
			$.ajax({
				url: base_url + 'SearchAdmOffOrg.do?searchOrg=' + $('#SG_ORG_NAME').val(),
				dataType: 'xml',
				cache: false,
				success: function (xmlResponse) {
					var data = $('record', xmlResponse ).map(function() {
						return {
							//ac_id: $( 'AC_ID', this ).text(),
							admin_cd: $( 'AC_ADMIN_CD', this ).text(),
							admin_desc: $( 'AC_ADMIN_CD_DESCR', this ).text()
						};
					}).get();
					response(data);
				}

			})
		},
		change: function (e, u) {
			//If the No match found" u.item will return null, clear the TextBox.
			if (u.item == null) {
				//Clear the AutoComplete TextBox.
				var pos = $(this).position();
				$('#SG_ORG_NAME_noMatch').remove();
				$(this).after("<span id='SG_ORG_NAME_noMatch' class='acNoMatch'>Invalid Selection:<br />Item must be selected from the available options.</span>");
				$('#SG_ORG_NAME_noMatch').css({top: pos.top + 20, left: pos.left + 30, position:'absolute'});
				setTimeout(function() {
					$('#SG_ORG_NAME_noMatch').remove();
				}, 2000);
				$(this).val('');
				return false;
			}
		},
		select: function (event, ui) {
			var li_admin_cd = "<li id=\"" + ui.item.admin_cd + "\" >";
			li_admin_cd += CMSUtility.getAutoCompRemoveIconElement(ui.item.admin_cd, ui.item.admin_cd, '25');
			li_admin_cd += ui.item.admin_cd + '</li>';

			var li_org_name = "<li id=\"" + ui.item.admin_cd + "_dscr\" >";
			li_org_name += CMSUtility.getAutoCompRemoveIconElement(ui.item.admin_cd + '_dscr', ui.item.admin_desc, '35');
			li_org_name += ui.item.admin_desc + '</li>';

			$('#SG_AC_DISP').append(li_admin_cd).removeClass('hidden');
			$('#SG_ADMIN_CD_INPUT_container').addClass('hidden');
			$('#SG_ADMIN_CD_INPUT').attr('_required', 'false');
			$('#SG_ON_DISP').append(li_org_name).removeClass('hidden');
			$('#SG_ORG_NAME_container').addClass('hidden');
			$('#SG_ORG_NAME').attr('_required', 'false');
			$('#SG_ADMIN_CD').val(ui.item.admin_cd);
		},
		open: function() {
			 $('.ui-autocomplete').css('z-index', 5000);
		},
		close: function() {
			 $('.ui-autocomplete').css('z-index', 1);
		}
	})
	.autocomplete().data('ui-autocomplete')._renderItem = function (ul, item) {
		return $('<li>')
		.append('<a>' + item.admin_desc + ' - ' + item.admin_cd + '</a>')
		.appendTo(ul);
	};
}
*/


	
/**
 * Utility method for autocompletion of user with dept/title info
 */
var	getUserObjectForAC = function(userID) {
	var userObject = [];
	var userFromSource = $('#group_user_info option[value="' +  userID + '"]');
	if (userFromSource && userFromSource.length > 0) {
		var userText = userFromSource.text();
		if (userText && userText.length > 0) {
			var userInfo = userText.split(eligQualGenObj.longSeparator);
			// userInfo[0] - memberid // userInfo[1] - name // userInfo[2] - email // userInfo[3] - deptname // userInfo[4] - jobtitlename
			userObject.push({
				id: userID,
				name: userInfo[1],
				deptname: userInfo[3],
				jobtitle: userInfo[4]
			});
		}
	}
	return userObject;
};

var getXOObjectForAC = function() {
	var userObject = [];

	var IDString = $('#XO_ID').val();
	if(IDString && IDString.length >0){
		var IDs = IDString.split(eligQualGenObj.separator);
		var count = IDs.length;

		for (var i = 0; i < count; i++) {
			var userInfo = getUserObjectForAC(IDs[i]);
			if (userInfo.length == 1) {
				userObject.push(userInfo[0]);
			}
		}
	}
	
	return userObject;
};

var setAutoComplete = function () {

	// SO Auto Completion
	var soID = $('#SO_ID').val();
	var soInitialData = getUserObjectForAC(soID);
	var soOption = {
		id: 'soSearch',
		tabindex: 120,
		targetURL: 'SearchPeopleUGNameTitle.do',
		targetParam: 'userGroupName=Selecting Officials&searchString',
		searchMode: 'include',
		minLength: 2,
		minSelectionCount: 1,
		maxSelectionCount: 1,
		mapFunction: function(context) {
			return {
				id: $( "MEMBERID", context ).text(),
				name: $( "NAME", context ).text(),
				deptname: $( "DEPTNAME", context ).text(),
				jobtitle: $( "JOBTITLENAME", context ).text()
			};            
		},
		getSelectionLabel: function(item) {
			var selectionLabel = '';
			selectionLabel = item.name;
			if ((item.deptname && item.deptname.length > 0) || (item.jobtitle && item.jobtitle.length > 0)) {
				selectionLabel += (' (' + item.deptname);
				if (item.jobtitle && item.jobtitle.length > 0) {
					selectionLabel += ('/' + item.jobtitle)
				}
				selectionLabel += ')'
			}
			return selectionLabel;
		},
		getCandidateLabel: function(item) {
			var selectionLabel = '';
			selectionLabel = item.name;
			if ((item.deptname && item.deptname.length > 0) || (item.jobtitle && item.jobtitle.length > 0)) {
				selectionLabel += (' (' + item.deptname);
				if (item.jobtitle && item.jobtitle.length > 0) {
					selectionLabel += ('/' + item.jobtitle)
				}
				selectionLabel += ')'
			}
			return selectionLabel;
		},
		getItemID: function(item) {
			return item.id;
		},
		setDataToForm: function(values) {
			if (values && values.length == 1) {
				$('#SO_ID').val(values[0].id);
				$('#SO_TITLE').val(values[0].jobtitle);
				$('#SO_ORG').val(values[0].deptname);
			}
		},
		initialItems: soInitialData
	};
	var soAC = initAutoCompletion(soOption);

	// XO Auto Completion
	var xoID = $('#XO_ID').val();
	//var xoInitialData = getUserObjectForAC(xoID);
	var xoOption = Object.create(soOption);
	xoOption.id = 'xoSearch';
	xoOption.minSelectionCount = 1;
    xoOption.maxSelectionCount = 3;
	xoOption.tabindex = 0;
	xoOption.targetParam = 'userGroupName=Executive Officers&searchString';
	xoOption.setDataToForm = function(values) {
		var count = values.length;
            var IDs = '';
            var titles = '';
            var orgs = '';

            for (var i = 0; i < count; i++) {
                if (i != 0) {
                    IDs = IDs + eligQualGenObj.separator;
                    titles = titles + eligQualGenObj.longSeparator;
                    orgs = orgs + eligQualGenObj.longSeparator;
                }
                IDs = IDs + values[i].id;
                titles = titles + values[i].jobtitle;
                orgs = orgs + values[i].deptname;
            }

            $('#XO_ID').val(IDs);
            $('#XO_TITLE').val(titles);
            $('#XO_ORG').val(orgs);
    };
	//xoOption.initialItems = xoInitialData;
	xoOption.initialItems = getXOObjectForAC();
	var xoAC = initAutoCompletion(xoOption);

	// HR Liaison Auto Completion
	var hrID = $('#HRL_ID').val();
	var hrInitialData = [];
	if (hrID == '0000000000') {
		hrInitialData.push({
			id: '0000000000',
			name: 'N/A',
			deptname: '',
			jobtitle: ''
		});
	} else {
		hrInitialData = getUserObjectForAC(hrID);
	}
	
	var hrOption = Object.create(soOption);
	hrOption.id = 'hrSearch';
	hrOption.tabindex = 140;
	hrOption.targetParam = 'userGroupName=HR Liaison&searchString';
	hrOption.setDataToForm = function(values) {
		if (values && values.length == 1) {
			$('#HRL_ID').val(values[0].id);
			$('#HRL_TITLE').val(values[0].jobtitle);
			$('#HRL_ORG').val(values[0].deptname);
		}
	};
	hrOption.initialItems = hrInitialData;
	hrOption.addCandidateItems = function(candidates) {
		candidates.push({
			id: '0000000000',
			name: 'N/A',
			deptname: '',
			jobtitle: ''
		});
	};
	var hrAC = initAutoCompletion(hrOption);

	// Staff Specialist Auto Completion
	var ssID = $('#SS_ID').val();
	var ssInitialData = getUserObjectForAC(ssID);
	var ssOption = Object.create(soOption);
	ssOption.id = 'ssSearch';
	ssOption.tabindex = 150;
	ssOption.targetParam = 'userGroupName=HR Staffing Specialists&searchString';
	ssOption.setDataToForm = function(values) {
		if (values && values.length == 1) {
			$('#SS_ID').val(values[0].id)
		}
	};
	ssOption.initialItems = ssInitialData;
	var ssAC = initAutoCompletion(ssOption);

	// Special Program Specialist Auto Completion
	var spID = $('#SP_ID').val();
	var spInitialData = getUserObjectForAC(spID);
	var spOption = Object.create(soOption);
	spOption.id = 'spSearch';
	spOption.tabindex = 160;
	spOption.targetParam = 'userGroupName=HR Special Programs&searchString';
	spOption.setDataToForm = function(values) {
		if (values && values.length == 1) {
			$('#SP_ID').val(values[0].id)
		}
	};
	spOption.initialItems = spInitialData;
	var spAC = initAutoCompletion(spOption);

	// Classification Specialist Auto Completion
	var csID = $('#CS_ID').val();
	var csInitialData = getUserObjectForAC(csID);
	var csOption = Object.create(soOption);
	csOption.id = 'csSearch';
	csOption.tabindex = 170;
	csOption.targetParam = 'userGroupName=HR Classification Specialists&searchString';
	csOption.setDataToForm = function(values) {
		if (values && values.length == 1) {
			$('#CS_ID').val(values[0].id)
		}
	};
	csOption.initialItems = csInitialData;
	var csAC = initAutoCompletion(csOption);
}