(function (window) {
    var cms_incentives_le_approval = function () {
        var _readOnly = false;
        var _initialized = false;

        function onChangeSupportLE(value) {
            var yes = "Yes" === value;

            FormState.updateSelectValue("leApprovalSOValue", yes ? "Approve" : ("No" === value ? "Disapprove" : ""), "", true);
        }

        function setApproverAndApprovalDate(eleId, dateEleId, checked) {
            var currentUserName = "";
            var currentUserId = "";
            var currentDate = "";
            if (checked) {
                currentUserName = myInfo.getMyName();
                currentUserId = myInfo.getMyMemberId();
                currentDate = FormUtility.getDateString(false, "mm/dd/yyyy", new Date());
            }

            $("#" + eleId).val(currentUserName);
            $("#" + dateEleId).val(currentDate);

            FormState.updateTextValue(eleId, currentUserName, false);
            FormState.updateTextValue(eleId + "Id", currentUserId, false);
            FormState.updateDateValue(dateEleId, currentDate, false);
        }

        function initEventHandlers() {
            $('#leApprovalSOCheck').on('change', function (e) {
                var target = e.target;
                setApproverAndApprovalDate("leApprovalSO", "leApprovalSOResponseDate", target.checked);
            });
            $('#leApprovalSOValue').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                setApproverAndApprovalDate("leApprovalSO", "leApprovalSOResponseDate", value !== "");
            });
            $('#leApprovalCOCValue').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                if (activityStep.isCOCReview()) {
                    if (("Approve" == value) || ("Disapprove" == value)) {
                        hyf.util.setComponentUsability('button_SubmitWorkitem', true);
                    } else {
                        hyf.util.setComponentUsability('button_SubmitWorkitem', false);
                    }
                }
                setApproverAndApprovalDate("leApprovalCOC", "leApprovalCOCResponseDate", value !== "");
            });
            $('#leApprovalDGHOValue').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                setApproverAndApprovalDate("leApprovalDGHO", "leApprovalDGHOResponseDate", value !== "");
            });
            $('#leApprovalTABGValue').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                setApproverAndApprovalDate("leApprovalTABG", "leApprovalTABGResponseDate", value !== "");
            });
        }

        function setSignUsability() {
            var isSO = accessControl.isDesignatedSO();
            hyf.util.setComponentUsability("leApprovalSOCheck", isSO);
            hyf.util.setMandatoryConstraint("leApprovalSOCheck", isSO);
            FormMain.setComponentUsability("leApprovalSOValue", isSO);
            hyf.util.setMandatoryConstraint("leApprovalSOValue", isSO);
            FormMain.setComponentUsability("leApprovalSOActing", isSO);
            hyf.util.setMandatoryConstraint("leApprovalSOActing", isSO);
            var isCOC = accessControl.isDesignator("lecocDirector")
            hyf.util.setComponentUsability("leApprovalCOCCheck", isCOC);
            hyf.util.setMandatoryConstraint("leApprovalCOCCheck", isCOC);
            FormMain.setComponentUsability("leApprovalCOCValue", isCOC);
            hyf.util.setMandatoryConstraint("leApprovalCOCValue", isCOC);
            FormMain.setComponentUsability("leApprovalCOCActing", isCOC);
            hyf.util.setMandatoryConstraint("leApprovalCOCActing", isCOC);

            var isDGHO = myInfo.isDGHO();
            hyf.util.setComponentUsability("leApprovalDGHOCheck", isDGHO);
            hyf.util.setMandatoryConstraint("leApprovalDGHOCheck", isDGHO);
            FormMain.setComponentUsability("leApprovalDGHOValue", isDGHO);
            hyf.util.setMandatoryConstraint("leApprovalDGHOValue", isDGHO);
            FormMain.setComponentUsability("leApprovalDGHOActing", isDGHO);
            hyf.util.setMandatoryConstraint("leApprovalDGHOActing", isDGHO);

            var isTABG = myInfo.isTABG();
            hyf.util.setComponentUsability("leApprovalTABGCheck", isTABG);
            hyf.util.setMandatoryConstraint("leApprovalTABGCheck", isTABG);
            FormMain.setComponentUsability("leApprovalTABGValue", isTABG);
            hyf.util.setMandatoryConstraint("leApprovalTABGValue", isTABG);
            FormMain.setComponentUsability("leApprovalTABGActing", isTABG);
            hyf.util.setMandatoryConstraint("leApprovalTABGActing", isTABG);
        }

        function initComponents() {
            setSignUsability();
            onChangeSupportLE(FormState.getElementValue("supportLE", ""));
        }

        function init(readOnly, tabObject) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();
            FormMain.resetMandatoryMark(tabObject);

            _initialized = true;
        }

        function render(action) {
        }

        return {
            init: init,
            render: render,
            onChangeSupportLE: onChangeSupportLE
        }
    };

    var _initializer = window.cms_incentives_le_approval || (window.cms_incentives_le_approval = cms_incentives_le_approval());
})(window);
