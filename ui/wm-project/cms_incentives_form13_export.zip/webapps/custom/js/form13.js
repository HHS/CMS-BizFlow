(function (window) {
    var cms_incentives_le_approval = function () {
        var _readOnly = false;
        var _initialized = false;

        function onChangeSupportLE(value) {
            var yes = "Yes" === value;
            FormState.updateSelectValue("leApprovalSOValue", yes ? "Approve" : ("No" === value ? "Disapprove" : ""), "", true);
            FormMain.setComponentUsability("leApprovalSOValue", false);
        }

        function setApproverAndApprovalDate(eleId, dateEleId, checked) {
            var currentUserName = "";
            var currentUserId = "";
            var currentDate = "";
            if (checked) {
                currentUserName = myInfo.getMyName();
                currentUserId = myInfo.getMyMemberId();
                currentDate = FormUtility.getDateString(false, "mm/dd/yyyy", new Date());
            }

            $("#" + eleId).val(currentUserName);
            $("#" + dateEleId).val(currentDate);

            FormState.updateTextValue(eleId, currentUserName, false);
            FormState.updateTextValue(eleId + "Id", currentUserId, false);
            FormState.updateDateValue(dateEleId, currentDate, false);
        }

        function initEventHandlers() {
            $('#leApprovalSOCheck').on('change', function (e) {
                var target = e.target;
                setApproverAndApprovalDate("leApprovalSO", "leApprovalSOResponseDate", target.checked);
            });
            $('#leApprovalSOValue').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                setApproverAndApprovalDate("leApprovalSO", "leApprovalSOResponseDate", value !== "");
            });
            $('#leApprovalCOCCheck').on('change', function (e) {
                var target = e.target;
                if(!target.checked) {
                    $("#leApprovalCOCValue").val("");
/*					hyf.util.setComponentUsability('button_ReturnForModification', true);
                }
				else {
					var leAppCOCRetVal = FormState.getElementValue('leApprovalCOCValue');
					if(leAppCOCRetVal!="") {
						hyf.util.setComponentUsability('button_SubmitWorkitem', true);
					}
					hyf.util.setComponentUsability('button_ReturnForModification', false);
*/					
				}
                setApproverAndApprovalDate("leApprovalCOC", "leApprovalCOCResponseDate", target.checked);
            });
            $('#leApprovalCOCValue').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                if (_initialized) {
                    if (activityStep.isCOCReview()) {
                        // var leApprovalCOCActing = FormState.getElementValue("leApprovalCOCActing", "");
                        // if (("" != leApprovalCOCActing) && (("Approve" == value) || ("Disapprove" == value))) {
                        //     hyf.util.setComponentUsability('button_SubmitWorkitem', true);
                        // } else {
                        //     hyf.util.setComponentUsability('button_SubmitWorkitem', false);
                        // }
                        if (("Approve" == value) || ("Disapprove" == value)) {
                            hyf.util.setComponentUsability('button_SubmitWorkitem', true);
//							hyf.util.setComponentUsability('button_ReturnForModification', false);
                        } else {
                            hyf.util.setComponentUsability('button_SubmitWorkitem', false);
/*							if ($('#leApprovalCOCCheck').is(":checked")) {
								hyf.util.setComponentUsability('button_ReturnForModification', false);
							}
							else { 
								hyf.util.setComponentUsability('button_ReturnForModification', true);
							}
*/
                        }
                    }
                }
                setApproverAndApprovalDate("leApprovalCOC", "leApprovalCOCResponseDate", value !== "");
            });
            $('#leApprovalCOCActing').on('change', function (e) {
                if (activityStep.isCOCReview()) {
                    var target = e.target;
                    var value = target.options[target.options.selectedIndex].value;
                    var text = target.options[target.options.selectedIndex].text;
                    // var leApprovalCOCValue = FormState.getElementValue("leApprovalCOCValue", "");
                    // if (("" != value) && (("Approve" == leApprovalCOCValue) || ("Disapprove" == leApprovalCOCValue))) {
                    //     hyf.util.setComponentUsability('button_SubmitWorkitem', true);
                    // } else {
                    //     hyf.util.setComponentUsability('button_SubmitWorkitem', false);
                    // }
                    FormState.updateSelectValue("leApprovalCOCActing", value, text, false);
                }
            });
            $('#leApprovalDGHOCheck').on('change', function (e) {
                var target = e.target;
                if(!target.checked) {
                    $("#leApprovalDGHOValue").val("");
                }
                setApproverAndApprovalDate("leApprovalDGHO", "leApprovalDGHOResponseDate", target.checked);
            });
            $('#leApprovalDGHOValue').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                if ("Approve" == value) {
                    $("#button_SubmitWorkitem").attr("value", "Send to TABG");
                } else if ("Disapprove" == value) {
                    $("#button_SubmitWorkitem").attr("value", "Send to HR");
                }
                setApproverAndApprovalDate("leApprovalDGHO", "leApprovalDGHOResponseDate", value !== "");
            });
            $('#leApprovalTABGCheck').on('change', function (e) {
                var target = e.target;
                if(!target.checked) {
                    $("#leApprovalTABGValue").val("");
                }
                setApproverAndApprovalDate("leApprovalTABG", "leApprovalTABGResponseDate", target.checked);
            });
            $('#leApprovalTABGValue').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                setApproverAndApprovalDate("leApprovalTABG", "leApprovalTABGResponseDate", value !== "");
            });
        }

        function setApproverNotesVisibility() {
            var rcmdAnnualLeaveAccrualRates = FormState.getElementArrayValue("rcmdAnnualLeaveAccrualRates", []);
            if (rcmdAnnualLeaveAccrualRates.length === 1) {
                if (typeof rcmdAnnualLeaveAccrualRates[0].witemSeq === 'undefined') {
                    rcmdAnnualLeaveAccrualRates = [];
                }
            }

            if (rcmdAnnualLeaveAccrualRates.length > 0) {
                if (activityStep.isHRSReview()) {
                    hyf.util.showComponent("leApproverNotes_group");
                    hyf.util.disableComponent("leApproverNotes");
                } else if (activityStep.isDGHOReview() || activityStep.isTABGReview()) {
                    hyf.util.showComponent("leApproverNotes_group");
                    hyf.util.enableComponent("leApproverNotes");
                }
            } else {
                hyf.util.hideComponent("leApproverNotes_group");
                FormState.updateTextValue("leApproverNotes", "", false);
            }
        }

        function setSignUsability() {
            var isSO = accessControl.isDesignatedSO();
            FormMain.setComponentUsability("leApprovalSOCheck", isSO);
            hyf.util.setMandatoryConstraint("leApprovalSOCheck", isSO);
            FormMain.setComponentUsability("leApprovalSOValue", isSO);
            hyf.util.setMandatoryConstraint("leApprovalSOValue", isSO);
            FormMain.setComponentUsability("leApprovalSOActing", isSO);
            hyf.util.setMandatoryConstraint("leApprovalSOActing", isSO);
            
			var isCOC = accessControl.isDesignator("lecocDirector")
            FormMain.setComponentUsability("leApprovalCOCCheck", isCOC);
            hyf.util.setMandatoryConstraint("leApprovalCOCCheck", isCOC);
            FormMain.setComponentUsability("leApprovalCOCValue", isCOC);
            hyf.util.setMandatoryConstraint("leApprovalCOCValue", isCOC);
            FormMain.setComponentUsability("leApprovalCOCActing", isCOC);
            hyf.util.setMandatoryConstraint("leApprovalCOCActing", isCOC);
			
			/* comment out since no more biz rule
			var leAppCOCVal = FormState.getElementValue('leApprovalCOCValue');
			var incentive_Type = FormState.getElementValue('incentiveType');
			var leAppCOCCheck = FormState.getElementValue('leApprovalCOCCheck');
			if (activityStep.isCOCReview() && incentive_Type == INCENTIVES_TYPE.LE) {
				if (leAppCOCCheck=="true" ||  leAppCOCVal=="Approve" || leAppCOCVal=="Disapprove" ) {
					hyf.util.setComponentUsability('button_ReturnForModification', false);
				}
				else {
					hyf.util.setComponentUsability('button_ReturnForModification', true);
				}
			}
			*/
            var isDGHO = myInfo.isDGHO();
            FormMain.setComponentUsability("leApprovalDGHOCheck", isDGHO);
            hyf.util.setMandatoryConstraint("leApprovalDGHOCheck", isDGHO);
            FormMain.setComponentUsability("leApprovalDGHOValue", isDGHO);
            hyf.util.setMandatoryConstraint("leApprovalDGHOValue", isDGHO);
            FormMain.setComponentUsability("leApprovalDGHOActing", isDGHO);
            hyf.util.setMandatoryConstraint("leApprovalDGHOActing", isDGHO);

            var isTABG = myInfo.isTABG();
            FormMain.setComponentUsability("leApprovalTABGCheck", isTABG);
            hyf.util.setMandatoryConstraint("leApprovalTABGCheck", isTABG);
            FormMain.setComponentUsability("leApprovalTABGValue", isTABG);
            hyf.util.setMandatoryConstraint("leApprovalTABGValue", isTABG);
            FormMain.setComponentUsability("leApprovalTABGActing", isTABG);
            hyf.util.setMandatoryConstraint("leApprovalTABGActing", isTABG);
        }

        function initComponents() {
            setSignUsability();
            setApproverNotesVisibility();
            onChangeSupportLE(FormState.getElementValue("supportLE", ""));
        }

        function init(readOnly, tabObject) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();
            FormMain.resetMandatoryMark(tabObject);

            _initialized = true;
        }

        function render(action) {
        }

        return {
            init: init,
            render: render,
            setApproverNotesVisibility: setApproverNotesVisibility,
            onChangeSupportLE: onChangeSupportLE
        }
    };

    var _initializer = window.cms_incentives_le_approval || (window.cms_incentives_le_approval = cms_incentives_le_approval());
})(window);
