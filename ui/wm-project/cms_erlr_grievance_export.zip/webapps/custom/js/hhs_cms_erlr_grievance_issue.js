var GrievanceIssue = {
	 initialized: false,
    groups : ['GI_admin_stg2_group','grievance_Individual_group','grievance_Union_Management_group'],
	reqFieldForActivity: 
		[
			/*{
				actName: globalVars.actAll,
				reqFieldIds: 
				[
				'GI_FILING_DT',
				'GI_IND_MEETING_DT',
				'GI_IND_STEP_1_DECISION_DT',
				'GI_IND_DECISION_ISSUE_DT',
				'GI_IND_STEP2_MEETING_DT',
				'GI_IND_STEP2_DECISION_DUE_DT',
				'GI_IND_STEP2_DECISION_ISSUE_DT',
				'GI_IND_EXT_DEADLINE_DT',
				'GI_IND_STEP2_REASON',
				'GI_IND_STEP2_PARTICIPANTS',
				'GI_IND_STEP2_DEADLINE'
				]
			},*/
			{
				actName: globalVars.actCaseCreation,
				reqFieldIds: 
				[
				'GI_FILING_DT',
				'GI_IND_MEETING_DT',
				'GI_IND_STEP_1_DECISION_DT',
				'GI_IND_DECISION_ISSUE_DT',
				'GI_IND_STEP2_MEETING_DT',
				'GI_IND_STEP2_DECISION_DUE_DT',
				'GI_IND_STEP2_DECISION_ISSUE_DT',
				'GI_IND_EXT_DEADLINE_DT',
				'GI_IND_STEP2_REASON',
				'GI_IND_STEP2_PARTICIPANTS',
				'GI_IND_STEP2_DEADLINE',
				'GI_IND_THIRD_PARTY_APPEAL_DT',
				'GI_IND_THIRD_APPEAL_REQUEST',
				'GI_UM_GRIEVABILITY',
				'GI_MEETING_DT',
				'GI_GRIEVANCE_STATUS',
				'GI_ARBITRATION_DEADLINE_DT',
				'GI_ARBITRATION_REQUEST',
				'GI_ADMIN_OFFCL_1',
				'GI_ADMIN_STG_1_DECISION_DT',
				'GI_ADMIN_STG_1_ISSUE_DT',
				'GI_ADMIN_STG_2_RESP',
				'GI_ADMIN_OFFCL_2',
				'GI_ADMIN_STG_2_DECISION_DT',
				'GI_ADMIN_STG_2_ISSUE_DT'
				]
			},
			{
				actName: globalVars.actCaseComplete,
				reqFieldIds: 
				[
				'GI_FILING_DT',
				'GI_IND_MEETING_DT',
				'GI_IND_STEP_1_DECISION_DT',
				'GI_IND_DECISION_ISSUE_DT',
				'GI_IND_STEP2_MEETING_DT',
				'GI_IND_STEP2_DECISION_DUE_DT',
				'GI_IND_STEP2_DECISION_ISSUE_DT',
				'GI_IND_EXT_DEADLINE_DT',
				'GI_IND_STEP2_REASON',
				'GI_IND_STEP2_PARTICIPANTS',
				'GI_IND_STEP2_DEADLINE',
				'GI_IND_THIRD_PARTY_APPEAL_DT',
				'GI_IND_THIRD_APPEAL_REQUEST',
				'GI_UM_GRIEVABILITY',
				'GI_MEETING_DT',
				'GI_GRIEVANCE_STATUS',
				'GI_ARBITRATION_DEADLINE_DT',
				'GI_ARBITRATION_REQUEST',
				'GI_ADMIN_OFFCL_1',
				'GI_ADMIN_STG_1_DECISION_DT',
				'GI_ADMIN_STG_1_ISSUE_DT',
				'GI_ADMIN_STG_2_RESP',
				'GI_ADMIN_OFFCL_2',
				'GI_ADMIN_STG_2_DECISION_DT',
				'GI_ADMIN_STG_2_ISSUE_DT'
				]
				
			}
		],
	init: function (){
		GrievanceIssue.groups.forEach(function(el){
			hyf.util.hideComponent(el);
		});
		hyf.util.hideComponent('grievance_Negotiated_group');
		hyf.util.hideComponent('grievance_Administrative_group');
		hyf.util.hideComponent('GI_Negotiated_grievance_group')
		CommonOpUtil.dynamicMandatory(GrievanceIssue.reqFieldForActivity);
		var Step1ExtDtOption1 = {
			dataElemId: 'GI_IND_EXT_HIDDEN_SELECTION',//HIDDEN FIELD
			dispElemId: 'GI_IND_EXT_SELECTED_DTs',
			inputElemId: 'GI_IND_EXTENDED_DUE',
			btnElemId: 'GI_IND_EXT1_DUE_DT_BTN'
		};
		var Step2ExtDtOption2 = {
			dataElemId: 'GI_IND_STEP2_PREV_EXT_DT',//HIDDEN FIELD
			dispElemId: 'GI_IND_PREV_EXT2_DT',
			inputElemId: 'GI_IND_EXT2_DUE_DT',
			btnElemId: 'GI_IND_STEP2_ADD_BTN'
		};
		var Step1ExtDtObj1 = MultiDateSelection.setupMultiDateSelection(Step1ExtDtOption1);
		var Step2ExtDtObj2 = MultiDateSelection.setupMultiDateSelection(Step2ExtDtOption2);
		
		var Step1RevDt = $('#GI_IND_EXT_HIDDEN_SELECTION').val();
		var Step2ExtDt =$('#GI_IND_STEP2_PREV_EXT_DT').val();
		if(Step1RevDt && Step1RevDt.trim().length <= 0){
			Step1RevDt = FormState.getState('GI_IND_EXT_HIDDEN_SELECTION');
			Step1ExtDtObj1.refreshData(Step1RevDt);
		}
		if(Step2ExtDt && Step2ExtDt.trim().length <= 0){
			Step2ExtDt = FormState.getState('GI_IND_STEP2_PREV_EXT_DT');
			Step2ExtDtObj2.refreshData(Step2ExtDt);
		}
	},
    render: function(){
		var actionType = FormState.getState('GI_TYPE');
		var grievanceType = FormState.getState('GI_NEGOTIATED_GRIEVANCE_TYPE');
		var adminStage2Group = FormState.getState('GI_ADMIN_STG_2_RESP');		
		if(actionType && actionType.dirty){
			if(actionType.value ==='Negotiated'){
				hyf.util.showComponent('GI_Negotiated_grievance_group');
				hyf.util.hideComponent('grievance_Administrative_group');
				hyf.util.showComponent('grievance_Negotiated_group');
			}else if (actionType.value ==='Administrative'){
				hyf.util.hideComponent('GI_Negotiated_grievance_group');
				hyf.util.hideComponent('grievance_Negotiated_group');
				hyf.util.showComponent('grievance_Administrative_group');
			}else{
				hyf.util.hideComponent('GI_Negotiated_grievance_group');
				hyf.util.hideComponent('grievance_Administrative_group');
				hyf.util.hideComponent('grievance_Negotiated_group');
				GrievanceIssue.showCaseView('',GrievanceIssue.groups);
			}
		}
		if(grievanceType && grievanceType.dirty){
			GrievanceIssue.showCaseView(grievanceType.value,GrievanceIssue.groups);
		}
		if(adminStage2Group && adminStage2Group.dirty){
			CommonOpUtil.hyfShowOrHide(adminStage2Group,'GI_admin_stg2_group');
		}
	if(!GrievanceIssue.initialized){
		FormAutoComplete.setAutoComplete('GI_IND_MEETING_PARTICIPANTS','/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=',GrievanceIssue.populatetAutocomplete,CommonOpUtil.responseMapper,appendInfo);
		FormAutoComplete.setAutoComplete('GI_IND_STEP2_PARTICIPANTS','/bizflowwebmaker/cms_erlr_service/contactInfo.do?emp=',GrievanceIssue.populatetAutocomplete,CommonOpUtil.responseMapper,appendInfo);
		FormAutoComplete.setAutoComplete('GI_ADMIN_OFFCL_1','/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=',GrievanceIssue.populatetAutocomplete,CommonOpUtil.responseMapper,appendInfo);
		FormAutoComplete.setAutoComplete('GI_IND_MANAGER','/bizflowwebmaker/cms_erlr_service/contactInfo.do?emp=',GrievanceIssue.populatetAutocomplete,CommonOpUtil.responseMapper,appendInfo);
		FormAutoComplete.setAutoComplete('GI_ADMIN_OFFCL_2','/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=',GrievanceIssue.populatetAutocomplete,CommonOpUtil.responseMapper,appendInfo);
		//CommonOpUtil.setStandardDateConstraint('standard_date');
		GrievanceIssue.initialized = true;
	  }
    },
	// load case view will be used as event handler on case type select box. 
showCaseView : function(caseValue,arr){
	//var tempGroups = GrievanceIssue.groups;
	arr.forEach(function(el,index){
	if(el.indexOf(caseValue) > -1 ){  
		hyf.util.showComponent(el);	
		$('#' + el).find('input:text').val('');	
		$('#' + el).find('textarea').val('');
		$('#' + el).find('select').val('');		
	}else{
		$('#' + el).find('input:text').val('');
		$('#' + el).find('textarea').val('');
		$('#' + el).find('select').val('');			
		hyf.util.hideComponent(el);
	}			
});
},
 meetingParticipants : function(parentId,string){
	$('#' +parentId).append(string);
},
 populatetAutocomplete : function(item,id){
	 var str =''+item.first_name +','+ item.last_name+'('+item.email + ')';
	 $('#' + id).val(str);
 }
};
