//(function(window){
	'use strict';
	var cms_grievance ={
	 initialized : false,
    groups : [
	'GI_admin_stg2_group',
	'grievance_ind_stg1_ext_group',
	'grievance_step2_request_group',
	'grievance_ind_step2_group'],
	reqFieldForActivity :
		[
			{
				actName: globalVars.actAll,
				reqFieldIds: 
				[
				
				]
			},
			{
				actName: globalVars.actCaseCreation,
				reqFieldIds: 
				[
				
				]
			},
			{
				actName: globalVars.actCaseComplete,
				reqFieldIds: 
				[
				'GI_TYPE',
				'GI_FILING_DT',
				'GI_IND_MEETING_DT',
				'GI_IND_STEP_1_DECISION_DT',
				'GI_IND_DECISION_ISSUE_DT',
				'GI_IND_STEP_2_MTG_DT',
				'GI_IND_STEP_2_DECISION_DUE_DT',
				'GI_IND_STEP_2_DECISION_ISSUE_DT',
				'GI_IND_EXTENDED_DUE_DT',
				'GI_IND_STEP_2_REASON',
				'GI_IND_STEP_2_DEADLINE',
				'GI_IND_THIRD_PARTY_APPEAL_DT',
				'GI_IND_THIRD_APPEAL_REQUEST',
				'GI_UM_GRIEVABILITY',
				'GI_MEETING_DT',
				'GI_GRIEVANCE_STATUS',
				'GI_ARBITRATION_DEADLINE_DT',
				'GI_ARBITRATION_REQUEST',
				'GI_ADMIN_OFFCL_1',
				'GI_ADMIN_STG_1_DECISION_DT',
				'GI_ADMIN_STG_1_ISSUE_DT',
				'GI_ADMIN_STG_2_RESP',
				'GI_ADMIN_OFFCL_2',
				'GI_ADMIN_STG_2_DECISION_DT',
				'GI_ADMIN_STG_2_ISSUE_DT',
				'GI_NEGOTIATED_GRIEVANCE_TYPE',
				'GI_TIMELY_FILING'
				]
				
			}
		],
	 standardDTs : [
	'GI_FILING_DT',
	'GI_IND_MEETING_DT',
	'GI_IND_STEP_1_DECISION_DT',
	'GI_IND_DECISION_ISSUE_DT',
	'GI_IND_EXTENDED_DUE_DT',
	'GI_IND_STEP_2_MEETING_DT',
	'GI_IND_STEP_2_DECISION_DUE_DT',
	'GI_IND_STEP_2_DECISION_ISSUE_DT',
	'GI_IND_EXT_2_DUE_DT',
	'GI_IND_THIRD_PARTY_APPEAL_DT',
	'GI_MEETING_DT',
	'GI_ADMIN_STG_1_DECISION_DT',
	'GI_ADMIN_STG_1_ISSUE_DT',
	'GI_ADMIN_STG_2_ISSUE_DT',
	'GI_ADMIN_STG_2_DECISION_DT'
	],
	init: function(){
		cms_grievance.groups.forEach(function(el){
			hyf.util.hideComponent(el);
		});
		if (Array.isArray(cms_grievance.standardDTs) && cms_grievance.standardDTs.length > 0){
			cms_grievance.standardDTs.forEach(function(el){
			if (el !=='' && el !== undefined){
				try{
					hyf.calendar.setDateConstraint(el, 'Maximum', 'Today'); 
				}catch(e){
					
				}	
			}
		});
		}
		hyf.util.hideComponent('grievance_Negotiated_group');
		hyf.util.hideComponent('grievance_Administrative_group');
		hyf.util.hideComponent('GI_Negotiated_grievance_group');
		hyf.util.hideComponent('grievance_Individual_group');
		hyf.util.hideComponent('grievance_Union_Management_group');
		hyf.util.hideComponent('manager_layout_group');
		hyf.util.showComponent('non_manager_layout_group');
		CommonOpUtil.dynamicMandatory(cms_grievance.reqFieldForActivity);
		var Step1ExtDtOption1 = {
			dataElemId: 'GI_IND_EXT_HIDDEN_SELECTION',//HIDDEN FIELD
			dispElemId: 'GI_IND_EXT_SELECTED_DTs',
			inputElemId: 'GI_IND_EXTENDED_DUE_DT',
			btnElemId: 'GI_IND_EXT1_DUE_DT_BTN'
		};
		var Step2ExtDtOption2 = {
			dataElemId: 'GI_IND_STEP_2_PREV_EXT_DT',//HIDDEN FIELD
			dispElemId: 'GI_IND_PREV_EXT2_DT',
			inputElemId: 'GI_IND_EXT_2_DUE_DT',
			btnElemId: 'GI_IND_STEP_2_ADD_BTN'
		};
		var Step1ExtDtObj1 = MultiDateSelection.setupMultiDateSelection(Step1ExtDtOption1);
		var Step2ExtDtObj2 = MultiDateSelection.setupMultiDateSelection(Step2ExtDtOption2);
		
		var Step1RevDt = $('#GI_IND_EXT_HIDDEN_SELECTION').val();
		var Step2ExtDt =$('#GI_IND_STEP_2_PREV_EXT_DT').val();
		if(Step1RevDt && Step1RevDt.trim().length <= 0){
			Step1RevDt = FormState.getState('GI_IND_EXT_HIDDEN_SELECTION');
			Step1ExtDtObj1.refreshData(Step1RevDt);
		}
		if(Step2ExtDt && Step2ExtDt.trim().length <= 0){
			Step2ExtDt = FormState.getState('GI_IND_STEP_2_PREV_EXT_DT');
			Step2ExtDtObj2.refreshData(Step2ExtDt);
		}
		$('#GI_TYPE').on('change',grievanceEvent);
		$('#GI_NEGOTIATED_GRIEVANCE_TYPE').on('change',negotiatedType);
		$('#GI_ADMIN_STG_2_RESP,#GI_STEP_2_REQUEST,#GI_IND_STEP_2_DEADLINE, #GI_IND_STEP_1_DECISION_DEADLINE').on('change',grievanceToggle);
		
		FormAutoComplete.setAutoComplete('GI_ADMIN_OFFCL_1','/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=',cms_grievance.populatetAutocomplete,CommonOpUtil.responseMapper,CommonOpUtil.appendEmplInfo);
		FormAutoComplete.setAutoComplete('GI_IND_MANAGER','/bizflowwebmaker/cms_erlr_service/contactInfo.do?emp=',cms_grievance.populatetAutocomplete,CommonOpUtil.responseMapper,CommonOpUtil.appendEmplInfo);
		FormAutoComplete.setAutoComplete('GI_ADMIN_OFFCL_2','/bizflowwebmaker/cms_erlr_service/contactInfo.do?cust=',cms_grievance.populatetAutocomplete,CommonOpUtil.responseMapper,CommonOpUtil.appendEmplInfo);
		CommonOpUtil.setStandardDateConstraint('standard_date');
		
	  },
	
   render: function(){
		onloadInit();
    }
}// load case view will be used as event handler on case type select box. 
 function showCaseView(caseValue,arr){
	arr.forEach(function(el,index){
	if(el.indexOf(caseValue) > -1 ){  
		hyf.util.showComponent(el);
		$('#' + el+' input[type="text"]').val('');	
		$('#' + el+' textarea').val('');
		$('#' + el+' select').val('');		
		}
	else{
		$('#' + el).find('input[type=text]').val('');
		$('#' + el).find('textarea').val('');
		$('#' + el).find('select').val('');			
		hyf.util.hideComponent(el);
	}			
});
}
 function meetingParticipants(parentId,string){
	$('#' +parentId).append(string);
}
  function populatetAutocomplete(item,id){
	 var str =''+item.first_name +','+ item.last_name+'('+item.email + ')';
	 $('#' + id).val(str);
 }

function grievanceEvent(e){
	var grievanceType = '';// e.target.options[e.target.options.selectedIndex].value;
	if(e === 'undefined'){
		return;		 
	}else if(typeof e ==='object'){
		if(e.target !== 'undefined'){
			grievanceType = e.target.options[e.target.options.selectedIndex].value;
		}	
	}else{
		grievanceType = e;
	}
	if(grievanceType && grievanceType !== ''){
		if(grievanceType ==='Negotiated'){
			hyf.util.showComponent('GI_Negotiated_grievance_group');
			hyf.util.hideComponent('grievance_Administrative_group');
			hyf.util.showComponent('grievance_Negotiated_group');
		}else if (grievanceType ==='Administrative'){
			hyf.util.hideComponent('GI_Negotiated_grievance_group');
			hyf.util.hideComponent('grievance_Negotiated_group');
			hyf.util.showComponent('grievance_Administrative_group');
		}else{
			hyf.util.hideComponent('GI_Negotiated_grievance_group');
			hyf.util.hideComponent('grievance_Administrative_group');
			hyf.util.hideComponent('grievance_Negotiated_group');	
		}
	}	
}
function negotiatedType(e){
	var negotiatedValue = '';// e.target.options[e.target.options.selectedIndex].value;
	if( e === 'undefined'){
		return;
				
	}else if(typeof e === 'object'){
		if(e.target !== 'undefined'){
			negotiatedValue =  e.target.options[e.target.options.selectedIndex].value;
		}	
	}else{
		negotiatedValue = e;
	}
	if(negotiatedValue === 'Individual'){
		hyf.util.showComponent('grievance_Individual_group');	
		hyf.util.hideComponent('grievance_Union_Management_group');
		hyf.util.showComponent('manager_layout_group');
		hyf.util.hideComponent('non_manager_layout_group');
	}else if(negotiatedValue === 'Union' ||negotiatedValue === 'Management'){
		hyf.util.showComponent('grievance_Union_Management_group');
		hyf.util.hideComponent('grievance_Individual_group');
		hyf.util.showComponent('non_manager_layout_group');
		hyf.util.hideComponent('manager_layout_group');
	}else{
		hyf.util.hideComponent('grievance_Individual_group');
		hyf.util.hideComponent('grievance_Union_Management_group');
		hyf.util.hideComponent('manager_layout_group');
		hyf.util.showComponent('non_manager_layout_group');
	}
}
function grievanceToggle(e){
	var negotiatedValue = '';
	if(e !== 'undefined'){
		if(e.target !== 'undefined'){
			negotiatedValue = e.target.options[e.target.options.selectedIndex].value;
		}
	}else{
		return;
	}
	var dynamicSection ='';
	if(e.target.id ==='GI_ADMIN_STG_2_RESP'){
		dynamicSection = 'GI_admin_stg2_group';
	}
	if(e.target.id ==='GI_STEP_2_REQUEST'){
		dynamicSection = 'grievance_step2_request_group';
	}
	if(e.target.id === 'GI_IND_STEP_2_DEADLINE'){
		dynamicSection = 'grievance_ind_step2_group';
	}
	if(e.target.id === 'GI_IND_STEP_1_DECISION_DEADLINE'){
		dynamicSection = 'grievance_ind_stg1_ext_group';
	}
	CommonOpUtil.hyfShowOrHide({value:negotiatedValue},dynamicSection);	
}
function onloadInit(){
	var negotiatedType = FormState.getElementValue('GI_NEGOTIATED_GRIEVANCE_TYPE');
	var grievanceType = FormState.getElementValue('GI_TYPE');
	var stg2Request = FormState.getElementValue('GI_ADMIN_STG_2_RESP');
	var Step2Rrequest = FormState.getElementValue('GI_STEP_2_REQUEST');
	var indStep2Deadline = FormState.getElementValue('GI_IND_STEP_2_DEADLINE');
	var indStep1DecisionDeadline = FormState.getElementValue('GI_IND_STEP_1_DECISION_DEADLINE');
	
	if(stg2Request && stg2Request ==='Y'){//GI_admin_stg2_group
		hyf.util.showComponent('GI_admin_stg2_group');
	}else{
		hyf.util.hideComponent('GI_admin_stg2_group');
	}
	if(grievanceType && grievanceType ==='Negotiated'){
		if(negotiatedType === 'Individual'){
			hyf.util.showComponent('GI_Negotiated_grievance_group');
			hyf.util.showComponent('grievance_Individual_group');
			hyf.util.hideComponent('grievance_Union_Management_group');
		}else if(negotiatedType === 'Union' || negotiatedType === 'Management'){
			hyf.util.showComponent('grievance_Union_Management_group');
			hyf.util.hideComponent('grievance_Individual_group');
			hyf.util.showComponent('GI_Negotiated_grievance_group');
		}	
	}else if(grievanceType && grievanceType ==='Administrative'){
		hyf.util.hideComponent('GI_Negotiated_grievance_group');
		hyf.util.showComponent('grievance_Administrative_group');
	}else{
		hyf.util.hideComponent('grievance_Administrative_group');
		hyf.util.hideComponent('GI_Negotiated_grievance_group');
	}
	if(Step2Rrequest && Step2Rrequest ==='Y'){
		hyf.util.showComponent('grievance_step2_request_group');
	}else{
		hyf.util.hideComponent('grievance_step2_request_group');
	}
	if(indStep2Deadline && indStep2Deadline ==='Y'){
		hyf.util.showComponent('grievance_ind_step2_group');
	}else{
		hyf.util.hideComponent('grievance_ind_step2_group');
	}
	if(indStep1DecisionDeadline && indStep1DecisionDeadline ==='Y'){
		hyf.util.showComponent('grievance_ind_stg1_ext_group');
	}else{
		hyf.util.hideComponent('grievance_ind_stg1_ext_group');
	}
}
//return{
	//init : init,
	//render : render
//}
//(window.cms_grievance !== undefined ? window.cms_grievance : (window.cms_grievance = cms_grievance()));
//})(window);
