//(function(window){
	'use strict';
	var cms_grievance ={
	 initialized : false,
    groups : [
	'GI_admin_stg2_group',
	'grievance_ind_stg1_ext_group',
	'grievance_step2_request_group',
	'grievance_ind_step2_group'],
	reqFieldForActivity :
		[
			{
				actName: globalVars.actAll,
				reqFieldIds: 
				[
				
				]
			},
			{
				actName: globalVars.actCaseCreation,
				reqFieldIds: 
				[
				
				]
			},
			{
				actName: globalVars.actCaseComplete,
				reqFieldIds: 
				[
				'GI_TYPE',
				'GI_FILING_DT',
				'GI_IND_STEP_1_DECISION_DT',
				'GI_IND_DECISION_ISSUE_DT',
				'GI_IND_STEP_2_MTG_DT',
				'GI_IND_STEP_2_DECISION_DUE_DT',
				'GI_IND_STEP_2_DECISION_ISSUE_DT',
				'GI_IND_EXTENDED_DUE_DT',
				'GI_IND_STEP_2_REASON',
				'GI_IND_STEP_2_DEADLINE',
				'GI_IND_THIRD_PARTY_APPEAL_DT',
				'GI_IND_THIRD_APPEAL_REQUEST',
				'GI_UM_GRIEVABILITY_SEL',
				'GI_GRIEVANCE_STATUS',
				'GI_ARBITRATION_DEADLINE_DT',
				'GI_ARBITRATION_REQUEST',
				'GI_ADMIN_OFFCL_1_SRCH',
				'GI_ADMIN_STG_1_DECISION_DT',
				'GI_ADMIN_STG_1_ISSUE_DT',
				'GI_ADMIN_STG_2_RESP',
				'GI_ADMIN_OFFCL_2_SRCH',
				'GI_ADMIN_STG_2_DECISION_DT',
				'GI_ADMIN_STG_2_ISSUE_DT',
				'GI_NEGOTIATED_GRIEVANCE_TYPE',
				'GI_TIMELY_FILING',
				'GI_IND_STEP_2_REASON',
				'GI_IND_REASON',
				'GI_TIMELY_FILING_2',
				'GI_IND_MANAGER_SRCH',
				'GI_FILING_DT_2'
				]
				
			}
		],
	 standardDTs : [
	'GI_FILING_DT',
	'GI_IND_MEETING_DT',
	'GI_IND_STEP_1_DECISION_DT',
	'GI_IND_DECISION_ISSUE_DT',
	'GI_IND_EXTENDED_DUE_DT',
	'GI_IND_STEP_2_MEETING_DT',
	'GI_IND_STEP_2_DECISION_DUE_DT',
	'GI_IND_STEP_2_DECISION_ISSUE_DT',
	'GI_IND_EXT_2_DUE_DT',
	'GI_IND_THIRD_PARTY_APPEAL_DT',
	'GI_ADMIN_STG_1_DECISION_DT',
	'GI_ADMIN_STG_1_ISSUE_DT',
	'GI_ADMIN_STG_2_ISSUE_DT',
	'GI_ADMIN_STG_2_DECISION_DT'
	],
	GI_ADMIN_OFFCL_1 : null,
	GI_ADMIN_OFFCL_2 : null,
	GI_IND_MANAGER : null,
	GI_UM_GRIEVABILITY : null,
	GIExtDialog : null,
	init: function(){
		cms_grievance.groups.forEach(function(el){
			hyf.util.hideComponent(el);
		});
		if (Array.isArray(cms_grievance.standardDTs) && cms_grievance.standardDTs.length > 0){
			cms_grievance.standardDTs.forEach(function(el){
			if (el !=='' && el !== undefined){
				try{
				hyf.calendar.setDateConstraint(el, 'Maximum', 'Today'); 
				}catch(e){
					
				}	
			}
		});
		}
		//hyf.util.hideComponent('grievance_Negotiated_group');
		hyf.util.hideComponent('grievance_Administrative_group');
		hyf.util.hideComponent('GI_Negotiated_grievance_group');
		hyf.util.hideComponent('grievance_Individual_group');
		hyf.util.hideComponent('grievance_Union_Management_group');
		hyf.util.hideComponent('manager_layout_group');
		hyf.util.showComponent('non_manager_layout_group');
		var giExtDialogOption = {
				dataDialogTitle:    'Date Extension Details',
				historyDialogTitle: 'Extended Step 1 Due Date(s)',
				dataObjectId:       'GI_IND_EXT',
				origDateElemId:     'GI_IND_STEP_1_DECISION_DT',
				extDateElemId:      'GI_IND_EXTENDED_DUE_DT',
				labelForDateElem:   'Extend Due Date',
				extSelectElemId:    'GI_IND_REASON',
				labelForSelectElem: 'Reason',
				dropdownOptionType: 'ERLRGIExtReason',
				extDetailGrpId:     'grievance_ind_stg1_ext_group',
				btnExtendId:        'GI_IND_EXT1_DUE_DT_BTN',
				btnAltExtendId:     'GI_IND_EXT_DUE_DT_BTN',
				postDialogCallback: function() { 
					controlGIExtEndDtVisibility(); 
					controlGIINDEndDtEnableDisable();
				}
			};
			//TODO: Implement date extension history
			cms_grievance.GIExtDialog = MultiDateSelectDialog.setupMultiDateSelectDialog(giExtDialogOption);
		
		$('#GI_IND_EXT1_DUE_DT_BTN, #GI_IND_STEP_2_ADD_BTN').on('click', function(e) {
				if (typeof cms_grievance.GIExtDialog != 'undefined' && cms_grievance.GIExtDialog != null) {
					cms_grievance.GIExtDialog.openDataDialog();
				}
			});
		CommonOpUtil.dynamicMandatory(cms_grievance.reqFieldForActivity);
		
		var Step2ExtDtOption2 = {
			dataElemId: 'GI_IND_STEP_2_PREV_EXT_DT',//HIDDEN FIELD
			dispElemId: 'GI_IND_PREV_EXT2_DT',
			inputElemId: 'GI_IND_EXT_2_DUE_DT',
			btnElemId: 'GI_IND_STEP_2_ADD_BTN'
		};
		//var Step1ExtDtObj1 = MultiDateSelection.setupMultiDateSelection(Step1ExtDtOption1);
		var Step2ExtDtObj2 = MultiDateSelection.setupMultiDateSelection(Step2ExtDtOption2);
		
		var Step1RevDt = $('#GI_IND_EXT_HIDDEN_SELECTION').val();
		var Step2ExtDt =$('#GI_IND_STEP_2_PREV_EXT_DT').val();
		if(Step1RevDt && Step1RevDt.trim().length <= 0){
			Step1RevDt = FormState.getState('GI_IND_EXT_HIDDEN_SELECTION');
			Step1ExtDtObj1.refreshData(Step1RevDt);
		}
		if(Step2ExtDt && Step2ExtDt.trim().length <= 0){
			Step2ExtDt = FormState.getState('GI_IND_STEP_2_PREV_EXT_DT');
			Step2ExtDtObj2.refreshData(Step2ExtDt);
		}
		$('#GI_TYPE').on('change',grievanceEvent);
		$('#GI_NEGOTIATED_GRIEVANCE_TYPE').on('change',negotiatedType);
		$('#GI_ADMIN_STG_2_RESP,#GI_STEP_2_REQUEST,#GI_IND_STEP_2_DEADLINE, #GI_IND_STEP_1_DECISION_DEADLINE').on('change',grievanceToggle);
		$('#GI_ARBITRATION_REQUEST').on('change',function(e){
			var val;
			try{
				val = e.target.options[e.target.options.selectedIndex].value;
				if(val && val ==='Y'){
					hyf.util.showComponent('tab_control_tab_tab80');
				}else{
					hyf.util.hideComponent('tab_control_tab_tab80');
				}
			}catch(err){}	
		});	

		cms_grievance.GI_ADMIN_OFFCL_1 = autoCompleteOptions('GI_ADMIN_OFFCL_1');
		cms_grievance.GI_IND_MANAGER = autoCompleteOptions('GI_IND_MANAGER');
		cms_grievance.GI_ADMIN_OFFCL_2 = autoCompleteOptions('GI_ADMIN_OFFCL_2');
		cms_grievance.GI_UM_GRIEVABILITY = grievanceMultiSelectOptions('GI_UM_GRIEVABILITY');
		CommonOpUtil.setStandardDateConstraint('standard_date');
		onloadInit();
	  },
	
   render: function(){
	var arbitrationDecison = FormState.getElementValue('GI_IND_THIRD_APPEAL_REQUEST');
		if(arbitrationDecison && arbitrationDecison ==='Y'){
				hyf.util.showComponent('tab_control_tab_tab80');
			}else{
			hyf.util.hideComponent('tab_control_tab_tab80');
		}
		//multi date selection logic
		/* var extendedStep1Dt = FormState.getElementValue('GI_IND_EXTENDED_DUE_DT');
		var extendedStep1OriginalDt = FormState.getElementValue('GI_IND_STEP_1_DECISION_DT'); 
		if(extendedStep1Dt !=='' && extendedStep1Dt.length > 3){
			hyf.util.enableComponent('GI_IND_EXT_DUE_DT_BTN');
		}else{
			hyf.util.disableComponent('GI_IND_EXT_DUE_DT_BTN');
		}
		if(extendedStep1OriginalDt.length > 1 && extendedStep1OriginalDt === extendedStep1Dt){
			$('#GI_IND_EXTENDED_DUE_DT').val('');
			FormState.updateObjectValue('GI_IND_EXTENDED_DUE_DT','');
		} */
    },
 clearData : function(){
	 var caseType;
	 try{
		caseType= FormState.getState('GEN_CASE_TYPE');
		if(caseType.value.replace(/\s/g,'') !=='Grievance'){
		$('#grievance_layout input[type!="button"]').val('');
		$('#grievance_layout input[type=checkbox]').prop('checked',false);
		$('#grievance_layout select').not('#GI_TYPE,#GI_NEGOTIATED_GRIEVANCE_TYPE').val('');
		$('#grievance_layout input').each(function(field){
			FormState.updateObjectValue(field.id,'');
		});
		$('#grievance_layout select').each(function(field){
			FormState.updateObjectValue(field.id,'');
		});	
	 }
	 if (typeof cms_grievance.GI_ADMIN_OFFCL_1 !== 'undefined' && cms_grievance.GI_ADMIN_OFFCL_1 != null) {
		cms_grievance.GI_ADMIN_OFFCL_1.initializeItems([]);
	}
	if (typeof cms_grievance.GI_IND_MANAGER !== 'undefined' && cms_grievance.GI_IND_MANAGER != null) {
		cms_grievance.GI_IND_MANAGER.initializeItems([]);
	}
	if (typeof cms_grievance.GI_ADMIN_OFFCL_2 !== 'undefined' && cms_grievance.GI_ADMIN_OFFCL_2 != null) {
		cms_grievance.GI_ADMIN_OFFCL_2.initializeItems([]);
	}
	if (typeof cms_grievance.GI_UM_GRIEVABILITY !== 'undefined' && cms_grievance.GI_UM_GRIEVABILITY != null) {
		cms_grievance.GI_UM_GRIEVABILITY.deleteAll();
	}
	 }catch(err){
		 
	 }
} 
}
function controlGIExtEndDtVisibility() 
{
	var giExt = FormState.getElementValue('GI_IND_EXT');
	if (typeof giExt != 'undefined' && giExt != null && giExt.length > 0) {
		$('#GI_IND_EXT1_DUE_DT_BTN').hide();
		hyf.util.showComponent('grievance_ind_stg1_ext_group');
		// when pip extension is displayed, further control history hyperlink
		CommonOpUtil.showHideLayoutGroup('GI_step1_history_group', ($.isArray(giExt) && giExt.length > 1));
	} else {
		$('#GI_IND_EXT1_DUE_DT_BTN').show();
		hyf.util.hideComponent('grievance_ind_stg1_ext_group');
		CommonOpUtil.clearGroupContent('grievance_ind_stg1_ext_group');
	}
}
function controlGIINDEndDtEnableDisable() 
{		
	var origDt = FormState.getElementValue('GI_IND_STEP_1_DECISION_DT');
	if (typeof origDt == 'undefined' || origDt == null || origDt.length <= 0) {
		hyf.util.disableComponent('GI_IND_EXT1_DUE_DT_BTN');
	} else {
		hyf.util.enableComponent('GI_IND_EXT1_DUE_DT_BTN');
	}	
	var extDt = FormState.getElementValue('GI_IND_EXTENDED_DUE_DT');
	if (typeof extDt == 'undefined' || extDt == null || extDt.length <= 0) {
		hyf.util.enableComponent('GI_IND_EXT_DUE_DT_BTN');
	} else {
		hyf.util.disableComponent('GI_IND_EXT_DUE_DT_BTN');
	}
}
//use this function where a multi select is needed, without creating config object repeatedly. Just pass field ID from index 0 up until "_SEL". eg. GEN_CASE_CATEGORY_SEL, you pass GEN_CASE_CATEGORY instead.
function grievanceMultiSelectOptions(dropdownID){
	var activityName = ActivityManager.getActivityName();
	var optionsMinSelection = (activityName === 'Complete Case') ? 1 : 0;
	var optionsInitialData = [];
	var optionsIdString = FormState.getElementValue(dropdownID);
	var optionsIds = ((optionsIdString != null && optionsIdString.length > 0) ? optionsIdString.split(',') : []);
	var count = optionsIds.length;
	for (var index = 0; index < count; index++) {
		var itemLabel = $('#'+ dropdownID + '_SEL option[value="' + optionsIds[index] + '"]').text();
		optionsInitialData.push({
			id: optionsIds[index],
			label: itemLabel
		});
	}
	var multiSelectOptions = {
	id: dropdownID,
	tabindex: 0,
	minSelectionCount: optionsMinSelection,
	maxSelectionCount: 10, 
	getSelectionLabel: function(item) {
		return item.label
	},
	getItemID: function(item) {
		return item.id;
	},
	initialItems: optionsInitialData,
	setDataToForm: function(values) {
		if (typeof values == 'undefined') return;
		var selectedIds = '';
		if (values != null && $.isArray(values)) {
			selectedIds = values.reduce(function(accumulator, currentValue, currentIndex, array) {
				return (accumulator && accumulator.length > 0) ? accumulator + ',' + currentValue.id : currentValue.id;
			}, '');
		}
		FormState.updateObjectValue(dropdownID, selectedIds);
	}
	};
	return MultiSelectDropdown.setupMultiSelectDropdown(multiSelectOptions);
}
function controlGIExtDueDtEnableDisable() {
			
		var origDt = FormState.getElementValue('GI_IND_EXTENDED_DUE_DT');
		if (typeof origDt == 'undefined' || origDt == null || origDt.length <= 0) {
			hyf.util.disableComponent('GI_IND_EXT1_DUE_DT_BTN');
		} else {
			hyf.util.enableComponent('GI_IND_EXT1_DUE_DT_BTN');
		}
		
		var extDt = FormState.getElementValue('PI_PIP_EXT_END_DT');
		if (typeof extDt == 'undefined' || extDt == null || extDt.length <= 0) {
			hyf.util.enableComponent('GI_IND_EXTENDED_DUE_DT');
		} else {
			hyf.util.disableComponent('GI_IND_EXTENDED_DUE_DT');
		}
	}
function autoCompleteOptions(id){
	var optionConfig = {
		id: id + '_SRCH',
		 baseURL: '/bizflowwebmaker/StratCon_AUT',
		 targetURL : '/bizflowwebmaker/cms_erlr_service/searchParticipants.do?g=&q=',
		 minLength: 2,
		 minSelectionCount: 0,
		 maxSelectionCount: 1,
		 mapFunction: function(context){
			return {
				id: $("MID", context).text(),
				participantId:  "[" + $("MTYPE", context).text() + "]" + $("MID", context).text(),
				name:  $("NAME", context).text(),
				email: $("EMAIL", context).text(),
				org:  $("DEPTNAME", context).text(),
				title: $("JOBTITLENAME", context).text()
			};
		},
		 getSelectionLabel: function(item){
			var label = item.name + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '');
			if (item.title) {
				label += '/' + item.title;
			}
			return label;
		},
		getCandidateLabel: function(item) {
			return item.name + ' ' + (item.email && item.email.length > 0 ? '(' + item.email + ')' : '');
		},
		 getItemID : function(item){
			 return item.id;
		 },
		 setDataToForm: function (values) {
             FormState.updateObjectValue(id, values);
         },
		  // initialize
         initialItems: FormState.getElementArrayValue(id, []),
		};
		return FormAutoComplete.makeAutoCompletion(optionConfig);
}
// load case view will be used as event handler on case type select box. 
 function showCaseView(caseValue,arr){
	arr.forEach(function(el,index){
	if(el.indexOf(caseValue) > -1 ){  
		hyf.util.showComponent(el);
		$('#' + el+' input[type="text"]').val('');	
		$('#' + el+' textarea').val('');
		$('#' + el+' select').val('');		
		}
	else{
		$('#' + el).find('input[type=text]').val('');
		$('#' + el).find('textarea').val('');
		$('#' + el).find('select').val('');			
		hyf.util.hideComponent(el);
	}			
});
}
function populatetAutocomplete(item,id){
	 var str =''+item.first_name +','+ item.last_name+'('+item.email + ')';
	 //$('#' + id).val(str);
	 return str;
 }

function grievanceEvent(e){
	var grievanceType = '';// e.target.options[e.target.options.selectedIndex].value;
	if(e === 'undefined'){
		return;		 
	}else if(typeof e ==='object'){
		if(e.target !== 'undefined'){
			grievanceType = e.target.options[e.target.options.selectedIndex].value;
		}	
	}else{
		grievanceType = e;
	}
	if(grievanceType && grievanceType !== ''){
		if(grievanceType ==='Negotiated'){
			hyf.util.showComponent('GI_Negotiated_grievance_group');
			hyf.util.showComponent('grievance_Negotiated_group');
			hyf.util.hideComponent('grievance_Administrative_group');
		}else if (grievanceType ==='Administrative'){
			hyf.util.hideComponent('GI_Negotiated_grievance_group');
			hyf.util.hideComponent('grievance_Negotiated_group');
			hyf.util.showComponent('grievance_Administrative_group');
		}else{
			hyf.util.hideComponent('GI_Negotiated_grievance_group');
			hyf.util.hideComponent('grievance_Administrative_group');
			hyf.util.hideComponent('grievance_Negotiated_group');
			
		}
	}
cms_grievance.clearData();	
}
function negotiatedType(e){
	var negotiatedValue = '';// e.target.options[e.target.options.selectedIndex].value;
	if( e === 'undefined'){
		return;			
	}else if(typeof e === 'object'){
		if(e.target !== 'undefined'){
			negotiatedValue =  e.target.options[e.target.options.selectedIndex].value;
		}	
	}else{
		negotiatedValue = e;
	}
	if(negotiatedValue === 'Individual'){
		hyf.util.showComponent('grievance_Individual_group');	
		hyf.util.hideComponent('grievance_Union_Management_group');
		hyf.util.showComponent('manager_layout_group');
		hyf.util.hideComponent('non_manager_layout_group');
	}else if(negotiatedValue === 'Union' ||negotiatedValue === 'Management'){
		hyf.util.showComponent('grievance_Union_Management_group');
		hyf.util.hideComponent('grievance_Individual_group');
		hyf.util.showComponent('non_manager_layout_group');
		hyf.util.hideComponent('manager_layout_group');
	}else{
		hyf.util.hideComponent('grievance_Individual_group');
		hyf.util.hideComponent('grievance_Union_Management_group');
		hyf.util.hideComponent('manager_layout_group');
		hyf.util.showComponent('non_manager_layout_group');
	}
	$('#GI_main_body select,#GI_main_body input[type="text"]').not('#GI_TYPE,#GI_NEGOTIATED_GRIEVANCE_TYPE').val('');
	//GI_ARBITRATION_REQUEST
	FormState.updateObjectValue('GI_ARBITRATION_REQUEST', '');
	cms_grievance.clearData();
}
function grievanceToggle(e){
	var negotiatedValue = '';
	if(e !== 'undefined'){
		if(e.target !== 'undefined'){
			negotiatedValue = e.target.options[e.target.options.selectedIndex].value;
		}
	}else{
		return;
	}
	var dynamicSection ='';
	if(e.target.id ==='GI_ADMIN_STG_2_RESP'){
		dynamicSection = 'GI_admin_stg2_group';
	}
	if(e.target.id ==='GI_STEP_2_REQUEST'){
		dynamicSection = 'grievance_step2_request_group';
	}
	if(e.target.id === 'GI_IND_STEP_2_DEADLINE'){
		dynamicSection = 'grievance_ind_step2_group';
	}
	if(e.target.id === 'GI_IND_STEP_1_DECISION_DEADLINE'){
		dynamicSection = 'grievance_ind_stg1_ext_group';
	}
	CommonOpUtil.hyfShowOrHide({value:negotiatedValue},dynamicSection);	
}
function onloadInit(){
	var negotiatedType = FormState.getElementValue('GI_NEGOTIATED_GRIEVANCE_TYPE');
	var grievanceType = FormState.getElementValue('GI_TYPE');
	var stg2Request = FormState.getElementValue('GI_ADMIN_STG_2_RESP');
	var Step2Rrequest = FormState.getElementValue('GI_STEP_2_REQUEST');
	var indStep2Deadline = FormState.getElementValue('GI_IND_STEP_2_DEADLINE');
	var indStep1DecisionDeadline = FormState.getElementValue('GI_IND_STEP_1_DECISION_DEADLINE');
	var thirdPartyAppeal = FormState.getElementValue('GI_ARBITRATION_REQUEST');
	
	if(stg2Request && stg2Request ==='Y'){//GI_admin_stg2_group
		hyf.util.showComponent('GI_admin_stg2_group');
	}else{
		hyf.util.hideComponent('GI_admin_stg2_group');
	}
	if(grievanceType && grievanceType ==='Negotiated'){
		if(negotiatedType === 'Individual'){
		hyf.util.showComponent('GI_Negotiated_grievance_group');
		hyf.util.showComponent('grievance_Individual_group');
		hyf.util.hideComponent('grievance_Union_Management_group');
		}else if(negotiatedType === 'Union' || negotiatedType === 'Management'){
		hyf.util.showComponent('GI_Negotiated_grievance_group'); 
		hyf.util.showComponent('grievance_Union_Management_group');
		hyf.util.hideComponent('grievance_Individual_group');
		hyf.util.showComponent('non_manager_layout_group');
		hyf.util.hideComponent('manager_layout_group');
	}	
	}else if(grievanceType && grievanceType ==='Administrative'){
		hyf.util.hideComponent('GI_Negotiated_grievance_group');
		hyf.util.showComponent('grievance_Administrative_group');
	}else{
		hyf.util.hideComponent('grievance_Administrative_group');
		hyf.util.hideComponent('GI_Negotiated_grievance_group');
	}
	
	if(Step2Rrequest && Step2Rrequest ==='Y'){
		hyf.util.showComponent('grievance_step2_request_group');
	}else{
		hyf.util.hideComponent('grievance_step2_request_group');
	}
	if(indStep2Deadline && indStep2Deadline ==='Y'){
		hyf.util.showComponent('grievance_ind_step2_group');
	}else{
		hyf.util.hideComponent('grievance_ind_step2_group');
	}
	if(indStep1DecisionDeadline && indStep1DecisionDeadline ==='Y'){
		hyf.util.showComponent('grievance_ind_stg1_ext_group');
	}else{
		hyf.util.hideComponent('grievance_ind_stg1_ext_group');
	}
	if(thirdPartyAppeal && thirdPartyAppeal ==='Yes'){
		hyf.util.showComponent('tab_control_tab_tab80');
	}else{
		hyf.util.hideComponent('tab_control_tab_tab80');
	}
	
}
//return{
	//init : init,
	//render : render
//}
//})(window);
//(window.cms_grievance !== undefined ? window.cms_grievance : (window.cms_grievance = cms_grievance()));
//})(window);
//})(window);