var eligQualApr = {

	onChange_DcoCert: function(){
		var dcoCertVal = $('#DCO_CERT option:selected').val();
		if (typeof dcoCertVal != 'undefined' && dcoCertVal != null && dcoCertVal == 'Yes') {
			if ($('#DCO_SIG').val() == null || $('#DCO_SIG').val().length <= 0
				|| $('#DCO_NAME').val() == null || $('#DCO_NAME').val().length <= 0
				|| $('#DCO_SIG_DT').val() == null || $('#DCO_SIG_DT').val().length <= 0) 
			{
				var dateOpt = {
					isUTC: false,
					dateFormat: 'mm/dd/yyyy'
				};
				var curDate = CMSUtility.getDateString(dateOpt, new Date());
				$('#DCO_SIG').val($('#h_currentUserMemberID').val());
				$('#DCO_NAME').val($('#h_currentUserName').val());
				$('#DCO_SIG_DT').val(curDate);
			}
		} else {
			$('#DCO_SIG').val('');
			$('#DCO_NAME').val('');
			$('#DCO_SIG_DT').val('');
		}
	}
	,
	
	getApprovalFlag: function(){
		var approvalFlag = null;
		var result = 'No';
		
		var approvalFlag = $('#DCO_CERT option:selected').val();
		if (typeof approvalFlag != 'undefined' && approvalFlag != null && approvalFlag == 'Yes'){
			result = 'Yes';
		} 
		
		return result;
	}
	,
	
	init: function(){
		
		// certifier info fields should be readonly
		$('#DCO_SIG').prop('readonly', true);
		$('#DCO_NAME').prop('readonly', true);
		$('#DCO_SIG_DT').prop('readonly', true);
		
		// establish event handler
		$('#DCO_CERT').off('change').on('change', eligQualApr.onChange_DcoCert);
		
		// initialize element states
		eligQualApr.onChange_DcoCert();
	}
}