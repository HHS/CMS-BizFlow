(function (window) {
    var cms_incentives_sam_review = function () {
        var _readOnly = false;
        var _initialized = false;
        var _ohcDirector_ac = null;

        var SELECTEE_MEET_ELIGIBILITY = {
            CIVILIAN_EMPLOYEE: "5 CFR 531.212(a)(i) First appointment as a civilian employee",
            REAPPOINTMENT: "5 CFR 531.212(a)(ii) Qualifying Reappointment",
            NOT_ELIGIBILITY: "Selectee does not meet eligibility requirements"
        };

        var SELECTEE_MEET_CRITERIA = {
            SUPERIOR: "Superior Qualifications",
            AGENCY_NEED: "Fills a special agency need"
        };

        var QUALIFYING_REAPPOINTMENT = {
            DAY90_BREAK_IN: "90-day break in service",
            OTHER: "Other exceptions"
        };

        var SUPERIOR_QUALIFICATION_REASON = {
            AS_ASSESSED: "As assessed by the candidate’s level, type or quality of skills and competencies",
            AS_EVIDENCED: "As evidenced by experience and/or education",
            IN_COMPARING: "In comparing his/her accomplishments to others in the field",
            OTHER: "Based on other factors"
        };

        var SPECIAL_AGENCY_NEED_REASON = {
            DOCUMENTED: "Agency’s workforce need is documented in the agency’s strategic human capital plan",
            ESSENTIAL: "Candidate’s qualities are essential to accomplishing an important agency mission, goal or program activity"
        };

        var HRSPECIALIST_REVIEW_CERTIFICATION = {
            SUPPORT_PROPOSED: "I support this request with the component's proposed salary",
            SUPPORT_MODIFIED: "I support this request with the modified recommended salary",
            NOT_SUPPORT: "I do not support this request for the following reason(s)"
        };

        var OTHER_RELEVANT_FACTORS = {
            OTHER: "Other relevant factors"
        };

        function updateSelecteeMeetCriteria(value, text) {
            FormState.updateSelectValue("selecteeMeetCriteria", value, text, true);
            onChangeSelecteeMeetCriteria(value);
        }

        function updateBasicPayRateFactor(value, text) {
            FormState.updateSelectValue("basicPayRateFactor", value, text, true);
            onChangeBasicPayRateFactor(value);
        }

        function updateSuperiorQualificationReason(value, text) {
            FormState.updateSelectValue("superiorQualificationReason", value, text, true);
            onChangeSuperiorQualificationReason(value);
        }

        function updateSpecialAgencyNeedReason(value, text) {
            FormState.updateSelectValue("specialAgencyNeedReason", value, text, true);
            onChangeSpecialAgencyNeedReason(value);
        }

        function onChangeSelecteeMeetEligibility(value) {
            var isReappointment = value === SELECTEE_MEET_ELIGIBILITY.REAPPOINTMENT;
            hyf.util.setComponentVisibility("qualifyingReappointment_group", isReappointment);
            if (!isReappointment) {
                FormState.updateSelectValue("qualifyingReappointment", "", "Select One", true);
                onChangeQualifyingReappointment("");
            }
            var isNotEligibility = value === SELECTEE_MEET_ELIGIBILITY.NOT_ELIGIBILITY;

            if (isNotEligibility) {
                updateSelecteeMeetCriteria("", "Select One");
                updateBasicPayRateFactor("", "Select One");
            }

            hyf.util.setMandatoryConstraint("basicPayRateFactor", !isNotEligibility);
        }

        function onChangeSelecteeMeetCriteria(value) {
            var isAgencyNeed = value === SELECTEE_MEET_CRITERIA.AGENCY_NEED;
            var isSuperior = value === SELECTEE_MEET_CRITERIA.SUPERIOR;

            hyf.util.setComponentVisibility("specialAgencyNeedReason_group", isAgencyNeed);
            hyf.util.setComponentVisibility("superiorQualificationCriteria_group", isSuperior);
            if (!isAgencyNeed) {
                updateSpecialAgencyNeedReason("", "Select One");
            }
            if (!isSuperior) {
                updateSuperiorQualificationReason("", "Select One");
            }
        }

        function onChangeQualifyingReappointment(value) {
            var isOther = value === QUALIFYING_REAPPOINTMENT.OTHER;
            if (!isOther) {
                FormState.updateTextValue("otherExceptions", "", true);
            }
            hyf.util.setComponentVisibility("otherExceptions_group", isOther);
        }

        function onChangeSuperiorQualificationReason(value) {
            var isOther = value === SUPERIOR_QUALIFICATION_REASON.OTHER;
            if (!isOther) {
                FormState.updateTextValue("otherFactorsAsExplained", "", true);
            }
            hyf.util.setComponentVisibility("otherFactorsAsExplained_group", isOther);
        }

        function onChangeSpecialAgencyNeedReason(value) {
            var isEssential = value === SPECIAL_AGENCY_NEED_REASON.ESSENTIAL;
            if (!isEssential) {
                FormState.updateTextValue("specialAgencyNeedReasonEssential", "", true);
            }
            hyf.util.setComponentVisibility("specialAgencyNeedReasonEssential_group", isEssential);
        }

        function setReviewerAndReviewDate(eleId, dateEleId, checked) {
            var currentUserName = "";
            var currentDate = "";
            if (checked) {
                currentUserName = myInfo.getMyName();
                currentDate = FormUtility.getDateString(false, "mm/dd/yyyy", new Date());
            }

            $("#" + eleId).val(currentUserName);
            $("#" + dateEleId).val(currentDate);

            FormState.updateTextValue(eleId, currentUserName, false);
            FormState.updateDateValue(dateEleId, currentDate, false);
        }

        function setRecommandIncDecAmount(totalCompensation, rcmdSalary) {
            totalCompensation = FormUtility.moneyToNumber(totalCompensation, 0);
            rcmdSalary = FormUtility.moneyToNumber(rcmdSalary, 0);

            var amount = rcmdSalary - totalCompensation;
            var amountStr = (amount > 0 ? "+" : "") + amount.format();
            FormState.updateTextValue("reviewRcmdIncDecAmount", amountStr, true);
            setReviewRcmdPercentageDifference(amount, totalCompensation);
        }

        function setReviewRcmdPercentageDifference(reviewRcmdIncDecAmount, totalCompensation) {
            var percentage = (reviewRcmdIncDecAmount * 100) / totalCompensation;
            var percentageStr = (percentage > 0 ? "+" : "") + percentage.format() + "%";
            FormState.updateTextValue("reviewRcmdPercentageDifference", percentageStr, true);
        }

        function onChangeHRSpecialistReviewCertification(value) {
            var isNotSupport = value === HRSPECIALIST_REVIEW_CERTIFICATION.NOT_SUPPORT;

            if (!isNotSupport) {
                FormState.updateSelectValue("hrSpecialistNotSupportReason", "", "Select One", true);
            }

            setReviewerAndReviewDate("reviewHRSpecialist", "hrSpecialistReviewDate", value !== "");
            hyf.util.setComponentVisibility("hrSpecialistNotSupportReason_group", isNotSupport);

            var isSupportModified = value === HRSPECIALIST_REVIEW_CERTIFICATION.SUPPORT_MODIFIED;
            hyf.util.setComponentVisibility("recommendedSalary_group", isSupportModified);
        }

        function onChangeBasicPayRateFactor(value) {
            var isOther = value === OTHER_RELEVANT_FACTORS.OTHER;

            if (!isOther) {
                FormState.updateTextValue("otherRelevantFactors", "", true);
            }

            hyf.util.setComponentVisibility("otherRelevantFactors_group", isOther);
        }

        function onChangeSelecteeTotalCompensation(value) {
            setRecommandIncDecAmount(value, FormState.getElementValue("reviewRcmdSalaryPerAnnum"));
        }

        function onChangeReviewRcmdPerDiffReqOHCApproval(value) {
            var isYes = "Yes" === value;
            hyf.util.setComponentVisibility("reviewRcmdApprovalOHCDirector_group", isYes);

            if (!isYes) {
                _ohcDirector_ac.deleteAllItems();
            }
        }

        function initEventHandlers() {
            $('#selecteeMeetEligibility').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeSelecteeMeetEligibility(value);
            });
            $('#selecteeMeetCriteria').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeSelecteeMeetCriteria(value);
            });
            $('#qualifyingReappointment').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeQualifyingReappointment(value);
            });
            $('#superiorQualificationReason').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeSuperiorQualificationReason(value);
            });
            $('#specialAgencyNeedReason').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeSpecialAgencyNeedReason(value);
            });
            $('#hrSpecialistReviewCertification').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeHRSpecialistReviewCertification(value);
            });
            $('#basicPayRateFactor').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeBasicPayRateFactor(value);
            });
            $('#reviewRcmdSalaryPerAnnum').on('blur', function (e) {
                var target = e.target;
                var value = target.value;

                setRecommandIncDecAmount(FormState.getElementValue("selecteeTotalCompensation"), value);
            });
            $('#requireOHCApproval').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeReviewRcmdPerDiffReqOHCApproval(value);
            });
        }

        function setOHCDirectorAutoCompletion() {
            _ohcDirector_ac = cms_incentives_general.setDesignatedUserAutoCompletion("reviewRcmdApprovalOHCDirector", USER_GROUP_KEY.OHC_DIRECTORS, 0, 1, _readOnly);
        }

        function setReviewRcmdLocalityPayScale() {
            LookupManager.fillListBox("reviewRcmdLocalityPayScale", "Incentives-Locality");
        }

        function initComponents() {
            hyf.util.disableComponent("hrSpecialistReviewDate");

            if (!_readOnly && (myInfo.isTABG() || myInfo.isOHC())) {
                hyf.util.disableComponent("samReview_upper_group");
                hyf.util.disableComponent("recommendedSalary_group");
                _readOnly = true;
            }

            setOHCDirectorAutoCompletion();

            onChangeSelecteeMeetEligibility(FormState.getElementValue("selecteeMeetEligibility"));
            onChangeQualifyingReappointment(FormState.getElementValue("qualifyingReappointment"));
            onChangeSelecteeMeetCriteria(FormState.getElementValue("selecteeMeetCriteria"));
            onChangeSuperiorQualificationReason(FormState.getElementValue("superiorQualificationReason"));
            onChangeSpecialAgencyNeedReason(FormState.getElementValue("specialAgencyNeedReason"));
            onChangeHRSpecialistReviewCertification(FormState.getElementValue("hrSpecialistReviewCertification"));
            onChangeBasicPayRateFactor(FormState.getElementValue("basicPayRateFactor"));
            setRecommandIncDecAmount(FormState.getElementValue("selecteeTotalCompensation"), FormState.getElementValue("reviewRcmdSalaryPerAnnum"))
            onChangeReviewRcmdPerDiffReqOHCApproval(FormState.getElementValue("requireOHCApproval"));
            setReviewRcmdLocalityPayScale();

            if (myInfo.isTABG() || myInfo.isOHC()) {
                hyf.util.enableComponent("reviewRcmdStep");
                hyf.util.enableComponent("reviewRcmdSalaryPerAnnum");
            }
        }

        function init(readOnly) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();

            _initialized = true;
        }

        function render(action) {
        }

        return {
            onChangeSelecteeTotalCompensation: onChangeSelecteeTotalCompensation,
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_sam_review || (window.cms_incentives_sam_review = cms_incentives_sam_review());
})(window);
