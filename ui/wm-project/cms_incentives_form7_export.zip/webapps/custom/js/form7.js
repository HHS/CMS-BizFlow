(function (window) {
    var cms_incentives_sam_review = function () {
        var _readOnly = false;
        var _initialized = false;

        var SELECTEE_MEET_ELIGIBILITY = {
            CIVILIAN_EMPLOYEE: "5 CFR 531.212(a)(i) First appointment as a civilian employee",
            REAPPOINTMENT: "5 CFR 531.212(a)(ii) Qualifying Reappointment",
            NOT_ELIGIBILITY: "Selectee does not meet eligibility requirements"
        };

        var SELECTEE_MEET_CRITERIA = {
            SUPERIOR: "Superior Qualifications",
            AGENCY_NEED: "Fills a special agency need"
        };

        var QUALIFYING_REAPPOINTMENT = {
            DAY90_BREAK_IN: "90-day break in service",
            OTHER: "Other exceptions"
        };

        var SUPERIOR_QUALIFICATION_REASON = {
            AS_ASSESSED: "As assessed by the candidate’s level, type or quality of skills and competencies",
            AS_EVIDENCED: "As evidenced by experience and/or education",
            IN_COMPARING: "In comparing his/her accomplishments to others in the field",
            OTHER: "Based on other factors"
        };

        var SPECIAL_AGENCY_NEED_REASON = {
            DOCUMENTED: "Agency’s workforce need is documented in the agency’s strategic human capital plan",
            ESSENTIAL: "Candidate’s qualities are essential to accomplishing an important agency mission, goal or program activity"
        };

        function onChangeSelecteeMeetEligibility(value) {
            var isReappointment = value === SELECTEE_MEET_ELIGIBILITY.REAPPOINTMENT;
            hyf.util.setComponentVisibility("qualifyingReappointment_group", isReappointment);
            if(!isReappointment) {
                FormState.updateSelectValue("qualifyingReappointment", "", "Select One", true);
                onChangeQualifyingReappointment("");
            }
            if (value === SELECTEE_MEET_ELIGIBILITY.NOT_ELIGIBILITY) {
            }
        }

        function onChangeSelecteeMeetCriteria(value) {
            hyf.util.setComponentVisibility("specialAgencyNeedReason_group", value === SELECTEE_MEET_CRITERIA.AGENCY_NEED);
            hyf.util.setComponentVisibility("superiorQualificationCriteria_group", value === SELECTEE_MEET_CRITERIA.SUPERIOR);
            if (value !== SELECTEE_MEET_CRITERIA.SUPERIOR) {
                FormState.updateSelectValue("superiorQualificationReason", "", "Select One", true);
                onChangeSuperiorQualificationReason("");
            }
        }

        function onChangeQualifyingReappointment(value) {
            var isOther = value === QUALIFYING_REAPPOINTMENT.OTHER;
            if (!isOther) {
                FormState.updateTextValue("otherExceptions", "", true);
            }
            hyf.util.setComponentVisibility("otherExceptions_group", isOther);
        }

        function onChangeSuperiorQualificationReason(value) {
            var isOther = value === SUPERIOR_QUALIFICATION_REASON.OTHER;
            if (!isOther) {
                FormState.updateTextValue("otherFactorsAsExplained", "", true);
            }
            hyf.util.setComponentVisibility("otherFactorsAsExplained_group", isOther);
        }

        function onChangeSpecialAgencyNeedReason(value) {
            var isEssential = value === SPECIAL_AGENCY_NEED_REASON.ESSENTIAL;
            if (!isEssential) {
                FormState.updateTextValue("specialAgencyNeedReasonEssential", "", true);
            }
            hyf.util.setComponentVisibility("specialAgencyNeedReasonEssential_group", isEssential);
        }

        function setReviewerAndReviewDate(eleId, dateEleId, checked) {
            var currentUserName = "";
            var currentDate = "";
            if (checked) {
                currentUserName = myInfo.getMyName();
                currentDate = FormUtility.getDateString(false, "mm/dd/yyyy", new Date());
            }

            $("#" + eleId).val(currentUserName);
            $("#" + dateEleId).val(currentDate);

            FormState.updateTextValue(eleId, currentUserName, false);
            FormState.updateDateValue(dateEleId, currentDate, false);
        }

        function initEventHandlers() {
            $('#selecteeMeetEligibility').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeSelecteeMeetEligibility(value);
            });
            $('#selecteeMeetCriteria').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeSelecteeMeetCriteria(value);
            });
            $('#qualifyingReappointment').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeQualifyingReappointment(value);
            });
            $('#superiorQualificationReason').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeSuperiorQualificationReason(value);
            });
            $('#specialAgencyNeedReason').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeSpecialAgencyNeedReason(value);
            });
            $('#hrSpecialistCertifyReviewCheck').on('change', function (e) {
                var target = e.target;
                setReviewerAndReviewDate("reviewHRSpecialist", "hrSpecialistReviewDate", target.checked);
            });
        }

        function initComponents() {
            hyf.util.disableComponent("hrSpecialistReviewDate");
            onChangeSelecteeMeetEligibility(FormState.getElementValue("selecteeMeetEligibility"));
            onChangeQualifyingReappointment(FormState.getElementValue("qualifyingReappointment"));
            onChangeSelecteeMeetCriteria(FormState.getElementValue("selecteeMeetCriteria"));
            onChangeSuperiorQualificationReason(FormState.getElementValue("superiorQualificationReason"));
            onChangeSpecialAgencyNeedReason(FormState.getElementValue("specialAgencyNeedReason"));
        }

        function init(readOnly) {
            _readOnly = readOnly;
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_sam_review::init, readOnly ==> ", readOnly);

            initComponents();

            initEventHandlers();

            _initialized = true;
        }

        function render(action) {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_sam_review::render..., action ==> ", action);
        }

        return {
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_sam_review || (window.cms_incentives_sam_review = cms_incentives_sam_review());
})(window);
