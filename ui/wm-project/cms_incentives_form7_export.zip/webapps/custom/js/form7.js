(function (window) {
    var cms_incentives_sam_review = function () {
        var _readOnly = false;
        var _initialized = false;

        var SELECTEE_MEET_CRITERIA = {
            SUPERIOR: "Superior Qualifications",
            AGENCY_NEED: "Fills a special agency need"
        };

        function onSelecteeMeetCriteria(value) {
            hyf.util.setComponentVisibility("specialAgencyNeedCriteria_group", value === SELECTEE_MEET_CRITERIA.AGENCY_NEED);
            hyf.util.setComponentVisibility("superiorQualificationCriteria_group", value === SELECTEE_MEET_CRITERIA.SUPERIOR);
        }

        function setReviewerAndReviewDate(eleId, dateEleId, checked) {
            var currentUserName = "";
            var currentDate = "";
            if (checked) {
                currentUserName = myInfo.getMyName();
                currentDate = FormUtility.getDateString(false, "mm/dd/yyyy", new Date());
            }

            $("#" + eleId).val(currentUserName);
            $("#" + dateEleId).val(currentDate);

            FormState.updateTextValue(eleId, currentUserName, false);
            FormState.updateDateValue(dateEleId, currentDate, false);
        }

        function initEventHandlers() {
            $('#selecteeMeetCriteria').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onSelecteeMeetCriteria(value);
            });
            $('#hrSpecialistCertifyReviewCheck').on('change', function (e) {
                var target = e.target;
                setReviewerAndReviewDate("reviewHRSpecialist", "hrSpecialistReviewDate", target.checked);
            });
        }

        function initComponents() {
            hyf.util.disableComponent("hrSpecialistReviewDate");
        }

        function init(readOnly) {
            _readOnly = readOnly;
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_sam_review::init, readOnly ==> ", readOnly);

            initComponents();

            initEventHandlers();

            _initialized = true;
        }

        function render(action) {
            if (FormLog.isDebugLevel()) FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_sam_review::render..., action ==> ", action);
        }

        return {
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_sam_review || (window.cms_incentives_sam_review = cms_incentives_sam_review());
})(window);
