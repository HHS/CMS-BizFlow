(function (window) {
    var cms_incentives_sam_review = function () {
        var _readOnly = false;
        var _initialized = false;
        var _ohcDirector_ac = null;
        var _basicPayRateFactor_ac = null;
        var _lastRcmdSalary = null;
        var _lastRcmdSalaryIndex = -1;
        var _lastRcmdSalaryTr = null;

        var SELECTEE_MEET_ELIGIBILITY = {
            CIVILIAN_EMPLOYEE: "5 CFR 531.212(a)(i) First appointment as a civilian employee",
            REAPPOINTMENT: "5 CFR 531.212(a)(ii) Qualifying Reappointment",
            NOT_ELIGIBILITY: "Selectee does not meet eligibility requirements"
        };

        var SELECTEE_MEET_CRITERIA = {
            SUPERIOR: "Superior Qualifications",
            AGENCY_NEED: "Fills a special agency need"
        };

        var QUALIFYING_REAPPOINTMENT = {
            DAY90_BREAK_IN: "90-day break in service",
            OTHER: "Other exceptions"
        };

        var SUPERIOR_QUALIFICATION_REASON = {
            AS_ASSESSED: "As assessed by the candidate’s level, type or quality of skills and competencies",
            AS_EVIDENCED: "As evidenced by experience and/or education",
            IN_COMPARING: "In comparing his/her accomplishments to others in the field",
            OTHER: "Based on other factors"
        };

        var SPECIAL_AGENCY_NEED_REASON = {
            DOCUMENTED: "Agency’s workforce need is documented in the agency’s strategic human capital plan",
            ESSENTIAL: "Candidate’s qualities are essential to accomplishing an important agency mission, goal or program activity"
        };

        var HRSPECIALIST_REVIEW_CERTIFICATION = {
            SUPPORT_PROPOSED: "I support this request with the component’s proposed salary",
            SUPPORT_MODIFIED: "I support this request with the modified recommended salary",
            NOT_SUPPORT: "I do not support this request for the following reason(s)"
        };

        var OTHER_RELEVANT_FACTORS = {
            OTHER: "Other relevant factors"
        };


        function setBasicPayRateFactorAutoCompletion() {
            var option = {
                id: 'basicPayRateFactor',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                useAddButton: true,
                addButtonTooltip: "Click the button to add a rate of basic pay factor to the list",
                minSelectionCount: 1,
                maxSelectionCount: 10,
                readOnly: _readOnly,
                // onChangeInputContainerVisibility: function(visible) {
                //     var $mandatoryMark = $("#basicPayRateFactor_label > span.mandatory").show();
                //     if ($mandatoryMark.length > 0) {
                //         if (visible) {
                //             $mandatoryMark.show();
                //         } else {
                //             $mandatoryMark.hide();
                //         }
                //     }
                // },
                mapFunction: function (context) {
                },
                getSelectionLabel: function (item) {
                    return item.text;
                },
                getCandidateLabel: function (item) {
                    return item.value;
                },
                getItemID: function (item) {
                    return item.value;
                },
                setDataToForm: function (values) {
                    FormState.updateObjectValue('basicPayRateFactor', values);
                    onChangeBasicPayRateFactor(values);
                },
                sortSelectedValues: function (values) {
                    var other = null;
                    for (var i = 0; i < values.length; i++) {
                        var item = values[i];
                        if (item.value === OTHER_RELEVANT_FACTORS.OTHER) {
                            other = item;
                            values.splice(i, 1);
                            break;
                        }
                    }

                    values.sort(function (a, b) {
                        return a.value > b.value;
                    });

                    if (other !== null) {
                        values.push(item);
                    }

                    return values;
                },
                isValidListItem: function (item, target) {
                    return item.value !== "";
                },
                afterItemDisplayed: function (containerId, item) {
                    FormUtility.removeSelectOption(item.value, "basicPayRateFactor");
                },
                afterItemDeleted: function (containerId, targetId, item, values) {
                    var target = FormUtility.addSelectionAndSortExceptLast(item.text, item.value, "basicPayRateFactor", OTHER_RELEVANT_FACTORS.OTHER);
                    target.selectedIndex = values.length === 0 ? 0 : -1;
                },
                initialItems: FormState.getElementSelectArrayValue('basicPayRateFactor', [])
            };

            _basicPayRateFactor_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        function resetSelecteeMeetCriteria() {
            FormState.updateSelectValue("selecteeMeetCriteria", "", "Select One", true);
            onChangeSelecteeMeetCriteria("");
        }

        function resetBasicPayRateFactor() {
            if (_basicPayRateFactor_ac) {
                _basicPayRateFactor_ac.deleteAllItems();
            }
            onChangeBasicPayRateFactor([]);
        }

        function updateSuperiorQualificationReason(value, text) {
            FormState.updateSelectValue("superiorQualificationReason", value, text, true);
            onChangeSuperiorQualificationReason(value);
        }

        function updateSpecialAgencyNeedReason(value, text) {
            FormState.updateSelectValue("specialAgencyNeedReason", value, text, true);
            onChangeSpecialAgencyNeedReason(value);
        }

        function onChangeSelecteeMeetEligibility(value) {
            var isReappointment = value === SELECTEE_MEET_ELIGIBILITY.REAPPOINTMENT;
            FormMain.setComponentVisibility("qualifyingReappointment_group", isReappointment);
            if (!isReappointment) {
                FormState.updateSelectValue("qualifyingReappointment", "", "Select One", true);
                onChangeQualifyingReappointment("");
            }
            var isNotEligibility = value === SELECTEE_MEET_ELIGIBILITY.NOT_ELIGIBILITY;
            
            if (isNotEligibility) {
                resetSelecteeMeetCriteria();
                resetBasicPayRateFactor();
                hyf.util.hideComponent("selecteeMeet_sub_group");
                if (_initialized) {
                    hyf.util.disableComponent("button_SubmitWorkitem");
                }
            } else {
                if( activityStep.isStartNew()) {
                    hyf.util.hideComponent("selecteeMeet_sub_group");
                } else {
                    hyf.util.showComponent("selecteeMeet_sub_group");
                }
                if (_initialized) {
                    hyf.util.enableComponent("button_SubmitWorkitem");
                }
            }

            if (_initialized) {
                hyf.util.setMandatoryConstraint("basicPayRateFactor", !isNotEligibility);
            }
        }

        function onChangeSelecteeMeetCriteria(value) {
            var isAgencyNeed = value === SELECTEE_MEET_CRITERIA.AGENCY_NEED;
            var isSuperior = value === SELECTEE_MEET_CRITERIA.SUPERIOR;

            FormMain.setComponentVisibility("specialAgencyNeedReason_group", isAgencyNeed);
            FormMain.setComponentVisibility("superiorQualificationCriteria_group", isSuperior);
            if (!isAgencyNeed) {
                updateSpecialAgencyNeedReason("", "Select One");
            }
            if (!isSuperior) {
                updateSuperiorQualificationReason("", "Select One");
            }
        }

        function onChangeQualifyingReappointment(value) {
            var isOther = value === QUALIFYING_REAPPOINTMENT.OTHER;
            if (!isOther) {
                FormState.updateTextValue("otherExceptions", "", true);
            }
            FormMain.setComponentVisibility("otherExceptions_group", isOther);
        }

        function onChangeSuperiorQualificationReason(value) {
            var isOther = value === SUPERIOR_QUALIFICATION_REASON.OTHER;
            FormMain.setComponentVisibility("otherFactorsAsExplained_group", isOther);
            if (isOther) {
                FormUtility.focusElement("otherFactorsAsExplained");
            } else {
                FormState.updateTextValue("otherFactorsAsExplained", "", true);
            }
        }

        function onChangeSpecialAgencyNeedReason(value) {
            var isEssential = value === SPECIAL_AGENCY_NEED_REASON.ESSENTIAL;
            if (!isEssential) {
                FormState.updateTextValue("specialAgencyNeedReasonEssential", "", true);
            }
            FormMain.setComponentVisibility("specialAgencyNeedReasonEssential_group", isEssential);
        }

        function setReviewerAndReviewDate(eleId, dateEleId, checked) {
            var currentUserName = "";
            var currentUserId = "";
            var currentDate = "";
            if (checked) {
                currentUserName = myInfo.getMyName();
                currentUserId = myInfo.getMyMemberId();
                currentDate = FormUtility.getDateString(false, "mm/dd/yyyy", new Date());
            }

            $("#" + eleId).val(currentUserName);
            $("#" + dateEleId).val(currentDate);

            FormState.updateTextValue(eleId, currentUserName, false);
            FormState.updateTextValue(eleId + "Id", currentUserId, false);
            FormState.updateDateValue(dateEleId, currentDate, false);
        }

        function setRecommandIncDecAmount(totalCompensation, rcmdSalary) {
            totalCompensation = FormUtility.moneyToNumber(totalCompensation, 0);
            rcmdSalary = FormUtility.moneyToNumber(rcmdSalary, 0);

            var amount = rcmdSalary - totalCompensation;
            var amountStr = (amount > 0 ? "+" : "") + amount.format();
            FormState.updateTextValue("reviewRcmdIncDecAmount", amountStr, true);
            setReviewRcmdPercentageDifference(amount, totalCompensation);
        }

        function setReviewRcmdPercentageDifference(reviewRcmdIncDecAmount, totalCompensation) {
            var percentage = (reviewRcmdIncDecAmount * 100) / totalCompensation;
            var percentageStr = (percentage > 0 ? "+" : "") + percentage.format() + "%";
            FormState.updateTextValue("reviewRcmdPercentageDifference", percentageStr, true);
        }

        function getReviewRecommendedSalaryHtml(rcmdSalary) {
            var payPlan = FormState.getElementValue("payPlan", "");
            var visibleReviewRcmdStep = isVisibleReviewRcmdStep(rcmdSalary.grade, payPlan);
            var gradeAndStep = "";
            if(visibleReviewRcmdStep) {
                if ("ES" === payPlan) {
                    gradeAndStep = rcmdSalary.step;
                } else {
                    gradeAndStep = rcmdSalary.grade + " - " + rcmdSalary.step;
                }
            } else {
                if ("ES" === payPlan) {
                    gradeAndStep = "";
                } else {
                    gradeAndStep = rcmdSalary.grade;
                }
            }
            var salaryPerAnnumWithCurrency = "";
            if (typeof rcmdSalary.salaryPerAnnum === "number") {
                salaryPerAnnumWithCurrency = dojo.currency.format(rcmdSalary.salaryPerAnnum, {currency: "USD"});
            } else {
                salaryPerAnnumWithCurrency = dojo.currency.format(rcmdSalary.salaryPerAnnum, {currency: "USD"});
                if (undefined === salaryPerAnnumWithCurrency) {
                    salaryPerAnnumWithCurrency = rcmdSalary.salaryPerAnnum;
                }
            }

            var html = "<td>" + gradeAndStep + "</td>";
            html += "<td>" + salaryPerAnnumWithCurrency + "</td>";
            html += "<td>" + rcmdSalary.localityPayScale + "</td>";
            html += "<td>" + rcmdSalary.createdBy + "</td>";
            html += "<td>" + rcmdSalary.modifiedBy + "</td>";
            html += "<td>" + rcmdSalary.modifierRoleGroup + "</td>";
            html += "<td>" + FormUtility.getDateString(false, "mm/dd/yyyy", new Date(FormUtility.parseInt(rcmdSalary.modifiedDate, 0))) + "</td>";

            return html;
        }

        function getReviewRecommendedSalaries() {
            var reviewRecommendedSalaries = FormState.getElementArrayValue("reviewRecommendedSalaries", []);
            if (reviewRecommendedSalaries.length === 1) {
                if (typeof reviewRecommendedSalaries[0].witemSeq === 'undefined') {
                    reviewRecommendedSalaries = [];
                }
            }

            return reviewRecommendedSalaries;
        }

        function initReviewRecommendedSalaries() {
            var payPlan = FormState.getElementValue("payPlan", "");
            var reviewRecommendedSalaries = getReviewRecommendedSalaries();
            if (reviewRecommendedSalaries.length > 0) {
                var table = document.getElementById("reviewRcmdSalary_history");
                if(reviewRecommendedSalaries.length > 0) {
                    var visibleReviewRcmdStep = isVisibleReviewRcmdStep(reviewRecommendedSalaries[0].grade, payPlan);
                    if (visibleReviewRcmdStep) {
                        if ("ES" === payPlan) {
                            $("#reviewRcmdSalary_historyGradeStepTh").html("Step");
                        } else {
                            $("#reviewRcmdSalary_historyGradeStepTh").html("Grade - Step");
                        }
                    } else {
                        if ("ES" === payPlan) {
                            $("#reviewRcmdSalary_historyGradeStepTh").html("");
                        } else {
                            $("#reviewRcmdSalary_historyGradeStepTh").html("Grade");
                        }
                    }
                }
                hyf.util.showComponent("recommandSalary_updates_group");
                for (var i = 0; i < reviewRecommendedSalaries.length; i++) {
                    var item = reviewRecommendedSalaries[i];
                    if (item && item.witemSeq) {
                        var html = getReviewRecommendedSalaryHtml(item);
                        var tr = document.createElement("tr");
                        tr.setAttribute("class", "reviewRcmdSalaryRecord");
                        tr.setAttribute("id", "reviewRecommendedSalaryTr" + i);
                        tr.setAttribute("_id2", item.grade + "_" + item.step + "_" + FormUtility.moneyToNumber(item.salaryPerAnnum, 0) + "_" + item.localityPayScale);

                        tr.innerHTML = html;
                        table.appendChild(tr);
                    }
                }
            }
        }

        function getMyRcmdSalary(reviewRecommendedSalaries) {
            var rcmdSalaryIndex = -1;
            var witemSeq = FormMain.getProcessInfo().workitem.sequence;
            for (var i = 0; i < reviewRecommendedSalaries.length; i++) {
                var item = reviewRecommendedSalaries[i];
                if (item.witemSeq == witemSeq && item.modifier == myInfo.getMyMemberId()) {
                    rcmdSalaryIndex = i;
                    break;
                }
            }
            return rcmdSalaryIndex;
        }

        function updateRecommendedSalary(opt) {
            opt = opt || {showMsg: true};
            var forceCheck = undefined !== opt.forceCheck ? opt.forceCheck : false;
            var now = new Date();
            var witemSeq = FormMain.getProcessInfo().workitem.sequence;
            var reviewRecommendedSalaries = getReviewRecommendedSalaries();

            var reviewRcmdGrade_2 = undefined !== opt.reviewRcmdGrade_2 ? opt.reviewRcmdGrade_2 : FormState.getElementValue("reviewRcmdGrade_2");
            var reviewRcmdStep_2 = undefined !== opt.reviewRcmdStep_2 ? opt.reviewRcmdStep_2 : FormState.getElementValue("reviewRcmdStep_2");
            var reviewRcmdSalaryPerAnnum_2 = undefined !== opt.reviewRcmdSalaryPerAnnum_2 ? opt.reviewRcmdSalaryPerAnnum_2 : FormState.getElementValue("reviewRcmdSalaryPerAnnum_2");
            var reviewRcmdLocalityPayScale_2 = undefined !== opt.reviewRcmdLocalityPayScale_2 ? opt.reviewRcmdLocalityPayScale_2 : FormState.getElementValue("reviewRcmdLocalityPayScale_2");

            var reviewRcmdGrade = FormState.getElementValue("reviewRcmdGrade");
            var reviewRcmdStep = FormState.getElementValue("reviewRcmdStep");
            var reviewRcmdSalaryPerAnnum = FormState.getElementValue("reviewRcmdSalaryPerAnnum");
            var reviewRcmdLocalityPayScale = FormState.getElementValue("reviewRcmdLocalityPayScale");

            reviewRcmdSalaryPerAnnum_2 = FormUtility.moneyToNumber(reviewRcmdSalaryPerAnnum_2, 0);
            reviewRcmdSalaryPerAnnum = FormUtility.moneyToNumber(reviewRcmdSalaryPerAnnum, 0);
            if (!forceCheck &&
                (reviewRcmdGrade === reviewRcmdGrade_2) &&
                (reviewRcmdStep === reviewRcmdStep_2) &&
                (reviewRcmdSalaryPerAnnum === reviewRcmdSalaryPerAnnum_2) &&
                (reviewRcmdLocalityPayScale === reviewRcmdLocalityPayScale_2)) {
                if (opt.showMsg) {
                    bootbox.alert("No change have been made. Please change value to update.");
                }
            } else {
                var id2 = reviewRcmdGrade_2 + "_" + reviewRcmdStep_2 + "_" + reviewRcmdSalaryPerAnnum_2 + "_" + reviewRcmdLocalityPayScale_2;
                var _existingTr = $("#reviewRcmdSalary_history tr.reviewRcmdSalaryRecord[_id2='" + id2 + "']");
                if (forceCheck && _existingTr.length == 0) {
                    return;
                }
                if (_existingTr.length > 0) {
                    _lastRcmdSalaryIndex = _existingTr.parent().find("tr.reviewRcmdSalaryRecord").index(_existingTr);
                    _existingTr.empty();
                    _existingTr.remove();
                    _lastRcmdSalaryTr = null;
                    if (_lastRcmdSalaryIndex !== -1) {
                        reviewRecommendedSalaries.splice(_lastRcmdSalaryIndex, 1);
                        FormState.updateObjectValue("reviewRecommendedSalaries", reviewRecommendedSalaries);
                        if (reviewRecommendedSalaries.length === 0) {
                            hyf.util.hideComponent("recommandSalary_updates_group");
                        }
                        _lastRcmdSalaryIndex = -1;
                    }
                    _lastRcmdSalary = null;
                } else {
                    var rcmdSalaryIndex = getMyRcmdSalary(reviewRecommendedSalaries);
                    if (rcmdSalaryIndex == -1) {
                        var last = null;

                        if (reviewRecommendedSalaries.length > 0) {
                            last = reviewRecommendedSalaries[reviewRecommendedSalaries.length - 1];
                        }

                        _lastRcmdSalary = {
                            grade: reviewRcmdGrade,
                            step: reviewRcmdStep,
                            salaryPerAnnum: reviewRcmdSalaryPerAnnum,
                            localityPayScale: reviewRcmdLocalityPayScale,
                            createdBy: null != last ? last.modifiedBy : FormState.getElementValue("reviewHRSpecialist"),
                            modifiedBy: myInfo.getMyName(),
                            modifier: myInfo.getMyMemberId(),
                            modifiedDate: now.getTime(),
                            modifierRoleGroup: activityStep.getCurrentRoleGroup(),
                            witemSeq: witemSeq
                        };

                        if (reviewRecommendedSalaries.length === 0) {
                            hyf.util.showComponent("recommandSalary_updates_group");
                        }

                        reviewRecommendedSalaries.push(_lastRcmdSalary);
                        _lastRcmdSalaryIndex = reviewRecommendedSalaries.length - 1;
                        FormState.updateObjectValue("reviewRecommendedSalaries", reviewRecommendedSalaries);
                        var table = document.getElementById("reviewRcmdSalary_history");
                        _lastRcmdSalaryTr = document.createElement("tr");
                        _lastRcmdSalaryTr.setAttribute("class", "reviewRcmdSalaryRecord");
                        _lastRcmdSalaryTr.setAttribute("_id2", _lastRcmdSalary.grade + "_" + _lastRcmdSalary.step + "_" + FormUtility.moneyToNumber(_lastRcmdSalary.salaryPerAnnum, 0) + "_" + _lastRcmdSalary.localityPayScale);
                        _lastRcmdSalaryTr.innerHTML = getReviewRecommendedSalaryHtml(_lastRcmdSalary);
                        table.appendChild(_lastRcmdSalaryTr);
                    } else {
                        var $lastRcmdSalaryTr = $("#reviewRcmdSalary_history tr.reviewRcmdSalaryRecord:eq("+ rcmdSalaryIndex +")");
                        if ($lastRcmdSalaryTr.length > 0) {
                            _lastRcmdSalaryTr = $lastRcmdSalaryTr[0];
                            _lastRcmdSalary = reviewRecommendedSalaries[rcmdSalaryIndex];
                            _lastRcmdSalary.modifiedDate = now.getTime();
                            _lastRcmdSalaryTr.setAttribute("_id2", _lastRcmdSalary.grade + "_" + _lastRcmdSalary.step + "_" + FormUtility.moneyToNumber(_lastRcmdSalary.salaryPerAnnum, 0) + "_" + _lastRcmdSalary.localityPayScale);
                            _lastRcmdSalaryTr.innerHTML = getReviewRecommendedSalaryHtml(_lastRcmdSalary);
                        }
                    }
                }
            }

            FormState.updateSelectValue("reviewRcmdGrade", reviewRcmdGrade_2, reviewRcmdGrade_2, false);
            FormState.updateSelectValue("reviewRcmdStep", reviewRcmdStep_2, reviewRcmdStep_2, false);
            FormState.updateDijitInputInner("reviewRcmdSalaryPerAnnum", reviewRcmdSalaryPerAnnum_2, false);
            FormState.updateSelectValue("reviewRcmdLocalityPayScale", reviewRcmdLocalityPayScale_2, reviewRcmdLocalityPayScale_2, false);

            if(cms_incentives_sam_approval) {
                cms_incentives_sam_approval.setApproverNotesVisibility();
            }
        }

        function enableRecommendedSalaryUpdate(supportModified) {
            hyf.util.hideComponent("reviewRcmdSalary_group");
            hyf.util.showComponent("reviewRcmdSalary_group_2");
            var reviewRcmdSalaryPerAnnum_2 = FormState.getElementValue("reviewRcmdSalaryPerAnnum_2", "");

            if (supportModified) {
                FormMain.setComponentUsability("reviewRcmdStep_2", true);
                hyf.util.setComponentUsability("reviewRcmdSalaryPerAnnum_2", true);
                FormMain.setComponentUsability("reviewRcmdLocalityPayScale_2", true);

                FormMain.setMandatoryConstraint("reviewRcmdStep_2", true);
                FormMain.setMandatoryConstraint("reviewRcmdSalaryPerAnnum_2", true);
                FormMain.setMandatoryConstraint("reviewRcmdLocalityPayScale_2", true);
            } else {
                FormMain.setComponentUsability("reviewRcmdStep_2", false);
                hyf.util.setComponentUsability("reviewRcmdSalaryPerAnnum_2", false);
                FormMain.setComponentUsability("reviewRcmdLocalityPayScale_2", false);

                FormMain.setMandatoryConstraint("reviewRcmdStep_2", false);
                FormMain.setMandatoryConstraint("reviewRcmdSalaryPerAnnum_2", false);
                FormMain.setMandatoryConstraint("reviewRcmdLocalityPayScale_2", false);
            }


            var reviewRcmdGrade = FormState.getElementValue("reviewRcmdGrade");
            var reviewRcmdStep = FormState.getElementValue("reviewRcmdStep");
            var reviewRcmdSalaryPerAnnum = FormState.getElementValue("reviewRcmdSalaryPerAnnum");
            var reviewRcmdLocalityPayScale = FormState.getElementValue("reviewRcmdLocalityPayScale");

            FormState.updateSelectValue("reviewRcmdGrade_2", reviewRcmdGrade, reviewRcmdGrade, true);
            FormState.updateSelectValue("reviewRcmdStep_2", reviewRcmdStep, reviewRcmdStep, true);

            try {
                var reviewRcmdSalaryPerAnnum_number = FormUtility.moneyToNumber(reviewRcmdSalaryPerAnnum, 0);
                var reviewRcmdSalaryPerAnnumCurrency = dojo.currency.format(reviewRcmdSalaryPerAnnum_number, {currency: "USD"});
                FormState.updateDijitInputInner("reviewRcmdSalaryPerAnnum_2", reviewRcmdSalaryPerAnnumCurrency, true);
            } catch(e) {
                FormState.updateDijitInputInner("reviewRcmdSalaryPerAnnum_2", reviewRcmdSalaryPerAnnum, true);
            }

            LookupManager.fillListBox("reviewRcmdLocalityPayScale_2", "Incentives-Locality");
            FormState.updateSelectValue("reviewRcmdLocalityPayScale_2", reviewRcmdLocalityPayScale, reviewRcmdLocalityPayScale, true);
            if ( "" != reviewRcmdSalaryPerAnnum_2) {
                updateRecommendedSalary({reviewRcmdSalaryPerAnnum_2: reviewRcmdSalaryPerAnnum, forceCheck: true});
            }
        }

        function onChangeHRSpecialistReviewCertification(value) {
            var isNotSupport = value === HRSPECIALIST_REVIEW_CERTIFICATION.NOT_SUPPORT;

            if (isNotSupport) {
                FormState.updateSelectValue("requireOHCApproval", "", "Select One", true);
                onChangeReviewRcmdPerDiffReqOHCApproval("");
            } else {
                FormState.updateSelectValue("hrSpecialistNotSupportReason", "", "Select One", true);
            }

            FormMain.setComponentVisibility("hrSpecialistNotSupportReason_group", isNotSupport);

            if (_initialized) {
                setReviewerAndReviewDate("reviewHRSpecialist", "hrSpecialistReviewDate", value !== "");
            }

            var isSupportProposed = value === HRSPECIALIST_REVIEW_CERTIFICATION.SUPPORT_PROPOSED;
            var isSupportModified = value === HRSPECIALIST_REVIEW_CERTIFICATION.SUPPORT_MODIFIED;
            FormMain.setComponentVisibility("recommendedSalary_group", isSupportProposed || isSupportModified);
            FormMain.setComponentVisibility("requireOHCApproval_group", isSupportProposed || isSupportModified);

            var enabledSupportModified = activityStep.isDGHOReview() || activityStep.isTABGReview() || activityStep.isOHCReview() || (activityStep.isHRSReview() && isSupportModified);
            FormMain.setComponentUsability("reviewRcmdStep", enabledSupportModified);
            FormMain.setComponentUsability("reviewRcmdSalaryPerAnnum", enabledSupportModified);
            FormMain.setComponentUsability("reviewRcmdLocalityPayScale", enabledSupportModified);

            if (_initialized) {
                if(isSupportProposed || isSupportModified) {
                    var componentRcmdStep = FormState.getElementValue("componentRcmdStep", "");
                    var componentRcmdSalaryPerAnnum = FormState.getElementValue("componentRcmdSalaryPerAnnum", "");
                    var componentRcmdLocalityPayScale = FormState.getElementValue("componentRcmdLocalityPayScale", "");
                    FormState.updateSelectValue("reviewRcmdStep", componentRcmdStep, componentRcmdStep, true);
                    FormState.updateTextValue("reviewRcmdSalaryPerAnnum", componentRcmdSalaryPerAnnum, true);
                    FormState.updateSelectValue("reviewRcmdLocalityPayScale", componentRcmdLocalityPayScale, componentRcmdLocalityPayScale, true);
                    enableRecommendedSalaryUpdate(enabledSupportModified);
                } else {
                    FormState.updateSelectValue("reviewRcmdStep", "", "Select One", true);
                    FormState.updateTextValue("reviewRcmdSalaryPerAnnum", "", true);
                    FormState.updateSelectValue("reviewRcmdLocalityPayScale", "", "Select One", true);
                }
            }
            if (!_initialized && (isSupportProposed || isSupportModified)) {
                enableRecommendedSalaryUpdate(enabledSupportModified);
            }

            FormMain.setComponentUsability("reviewRcmdGrade", false);
            FormMain.setComponentUsability("reviewRcmdGrade_2", false);
        }

        function onChangeBasicPayRateFactor(values) {
            var isOther = false;
            for (var i = 0; i < values.length; i++) {
                if (values[i].value === OTHER_RELEVANT_FACTORS.OTHER) {
                    isOther = true;
                    break;
                }
            }

            FormMain.setComponentVisibility("otherRelevantFactors_group", isOther);
            if (isOther) {
                if (FormState.getElementValue("otherRelevantFactors", "'") === "") {
                    FormUtility.focusElement("otherRelevantFactors");
                }
            } else {
                FormState.updateTextValue("otherRelevantFactors", "", true);
            }
        }

        function isVisibleReviewRcmdStep(grade, payPlan) {
            // return ("00" !== grade) && ("" !== grade) && ("ED, EE, EF, EG, ES, EX".indexOf(payPlan) == -1);
            if ("undefined" == typeof(payPlan)) {
                payPlan = "";
            }

            return (("" == payPlan) || ("ED, EE, EF, EG, ES, EX".indexOf(payPlan) == -1));
        }

        function onGradeChanged(grade) {
            var payPlan = FormState.getElementValue("payPlan", "");
            var visibleReviewRcmdStepGroup = isVisibleReviewRcmdStep(grade, payPlan);
            FormMain.setComponentVisibility("reviewRcmdStep_group", visibleReviewRcmdStepGroup);
            FormMain.setComponentVisibility("reviewRcmdStep_group_2", visibleReviewRcmdStepGroup);

            if (_initialized) {
                FormState.updateSelectValue("reviewRcmdGrade", grade, grade, true);
                FormState.updateSelectValue("reviewRcmdGrade_2", grade, grade, true);
            }
            if ("ES" === payPlan) {
                onGradeHidden(false);
            }
        }

        function onGradeHidden(visible) {
            var ele = document.getElementById("reviewRcmdGrade");
            if (ele) {
                ele.parentElement.style.display = visible ? "" : "none";
            }
            var ele2 = document.getElementById("reviewRcmdGrade_label");
            if (ele2) {
                ele2.parentElement.style.display = visible ? "" : "none";
            }
            var ele3 = document.getElementById("reviewRcmdGrade_2");
            if (ele3) {
                ele3.parentElement.style.display = visible ? "" : "none";
            }
            var ele4 = document.getElementById("reviewRcmdGrade_2_label");
            if (ele4) {
                ele4.parentElement.style.display = visible ? "" : "none";
            }
        }

        function onChangeSelecteeTotalCompensation(value) {
            setRecommandIncDecAmount(value, FormState.getElementValue("reviewRcmdSalaryPerAnnum"));
        }

        function onChangeReviewRcmdPerDiffReqOHCApproval(value) {
            var isYes = "Yes" === value;
            FormMain.setComponentVisibility("reviewRcmdApprovalOHCDirector_group", isYes);

            if (!isYes) {
                _ohcDirector_ac.deleteAllItems();
            }
        }

        function onChangeOtherRequirements(opt) {
            var incentiveType = FormState.getElementValue('incentiveType');
            if (incentiveType === INCENTIVES_TYPE.SAM) {
                opt = opt || {};
                var otherReqJustificationApproved = opt.otherReqJustificationApproved || FormState.getElementValue("otherReqJustificationApproved");
                var otherReqSufficientInformationProvided = opt.otherReqSufficientInformationProvided || FormState.getElementValue("otherReqSufficientInformationProvided");
                var otherReqIncentiveRequired = opt.otherReqIncentiveRequired || FormState.getElementValue("otherReqIncentiveRequired");
                var otherReqDocumentationProvided = opt.otherReqDocumentationProvided || FormState.getElementValue("otherReqDocumentationProvided");

                if (_initialized) {
                    hyf.util.setComponentUsability("button_SubmitWorkitem",
                        otherReqJustificationApproved === "Yes" && otherReqSufficientInformationProvided === "Yes"
                        && otherReqIncentiveRequired === "Yes" && otherReqDocumentationProvided === "Yes");
                }
            }
        }

        function initEventHandlers() {
            $('#selecteeMeetEligibility').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeSelecteeMeetEligibility(value);
            });
            $('#selecteeMeetCriteria').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeSelecteeMeetCriteria(value);
            });
            $('#qualifyingReappointment').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeQualifyingReappointment(value);
            });
            $('#superiorQualificationReason').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeSuperiorQualificationReason(value);
            });
            $('#specialAgencyNeedReason').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeSpecialAgencyNeedReason(value);
            });
            $('#hrSpecialistReviewCertification').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeHRSpecialistReviewCertification(value);
            });
            $('#reviewRcmdSalaryPerAnnum').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                setRecommandIncDecAmount(FormState.getElementValue("selecteeTotalCompensation"), value);
            });
            $('#requireOHCApproval').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeReviewRcmdPerDiffReqOHCApproval(value);
            });
            $('#reviewRcmdGrade_2').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                updateRecommendedSalary({reviewRcmdGrade_2: value});
            });
            $('#reviewRcmdStep_2').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                updateRecommendedSalary({reviewRcmdStep_2: value});
            });
            $('#reviewRcmdSalaryPerAnnum_2').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                updateRecommendedSalary({reviewRcmdSalaryPerAnnum_2: value});
            });
            $('#reviewRcmdLocalityPayScale_2').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                updateRecommendedSalary({reviewRcmdLocalityPayScale_2: value});
            });
            $('#otherReqJustificationApproved').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeOtherRequirements({otherReqJustificationApproved: value});
            });
            $('#otherReqSufficientInformationProvided').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeOtherRequirements({otherReqSufficientInformationProvided: value});
            });
            $('#otherReqIncentiveRequired').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeOtherRequirements({otherReqIncentiveRequired: value});
            });
            $('#otherReqDocumentationProvided').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeOtherRequirements({otherReqDocumentationProvided: value});
            });
        }

        function setOHCDirectorAutoCompletion() {
            _ohcDirector_ac = cms_incentives_general.setDesignatedUserAutoCompletion("reviewRcmdApprovalOHCDirector", USER_GROUP_KEY.OHC_DIRECTORS, 0, 1, _readOnly);
        }

        function setReviewRcmdLocalityPayScale() {
            LookupManager.fillListBox("reviewRcmdLocalityPayScale", "Incentives-Locality");
        }

        function setOtherRequirementVisibility() {
            if (activityStep.isHRSReview()) {
                hyf.util.showComponent("otherRequirements_group");
            } else if (activityStep.isTABGReview() || activityStep.isOHCReview() || activityStep.isDGHOReview()) {
                hyf.util.showComponent("otherRequirements_group");
                hyf.util.disableComponent("otherRequirements_group");
                FormMain.setComponentUsability("otherReqJustificationApproved", false);
                FormMain.setComponentUsability("otherReqSufficientInformationProvided", false);
                FormMain.setComponentUsability("otherReqIncentiveRequired", false);
                FormMain.setComponentUsability("otherReqDocumentationProvided", false);
            }
        }

        function setMiscellaneousReviewNoteVisibility() {
            if (activityStep.isHRSReview() || activityStep.isTABGReview() || activityStep.isOHCReview() || activityStep.isDGHOReview() || activityStep.isHRSRecordConclusion()) {
                hyf.util.showComponent("miscellaneousReviewNote_group");
            } else {
                hyf.util.hideComponent("miscellaneousReviewNote_group");
            }
            if (activityStep.isHRSReview() || activityStep.isDGHOReview()) {
                hyf.util.enableComponent("samReviewRemarks");
            } else {
                hyf.util.disableComponent("samReviewRemarks");
            }
        }

        function initComponents() {
            hyf.util.disableComponent("hrSpecialistReviewDate");

            onChangeSelecteeMeetEligibility(FormState.getElementValue("selecteeMeetEligibility"));
            onChangeQualifyingReappointment(FormState.getElementValue("qualifyingReappointment"));

            if (myInfo.isXO() || myInfo.isSO() || myInfo.isHRL() || myInfo.isDGHO() || myInfo.isTABG() || myInfo.isOHC()) {
                hyf.util.disableComponent("selecteeMeets_group");
                FormMain.setComponentUsability("selecteeMeetEligibility", false);
                FormMain.setComponentUsability("qualifyingReappointment", false);
            }

            if (activityStep.isStartNew() || activityStep.isHRSReviewForModification() || activityStep.isSOReview() || activityStep.isCOMPReview() || activityStep.isCOMPReviewForModification() || activityStep.isCOCReview()) {
                hyf.util.hideComponent("selecteeMeet_sub_group");
                hyf.util.hideComponent("basicPayRate_group");
                hyf.util.hideComponent("otherRequirements_group");
                hyf.util.hideComponent("hrsRegulatoryReview_group");
                if (activityStep.isStartNew() && myInfo.isHRS()) {
                    hyf.util.enableComponent("selecteeMeets_group");
                    FormMain.setComponentUsability("selecteeMeetEligibility", true);
                    FormMain.setComponentUsability("qualifyingReappointment", true);
                } else {
                    hyf.util.disableComponent("selecteeMeets_group");
                    FormMain.setComponentUsability("selecteeMeetEligibility", false);
                    FormMain.setComponentUsability("qualifyingReappointment", false);
                }
                if (activityStep.isSOReview()) {
                    hyf.util.setMandatoryConstraint("selecteeMeetEligibility", false);
                    hyf.util.setMandatoryConstraint("qualifyingReappointment", false);
                    hyf.util.setMandatoryConstraint("otherExceptions", false);
                }
            } else {
                if (!_readOnly && (activityStep.isTABGReview() || activityStep.isOHCReview()) || activityStep.isHRSRecordConclusion()) {
                    hyf.util.disableComponent("samReview_upper_group");
                    hyf.util.disableComponent("recommendedSalary_group");
                    hyf.util.disableComponent("requireOHCApproval_group");

                    FormMain.setComponentUsability("selecteeMeetEligibility", false);
                    FormMain.setComponentUsability("qualifyingReappointment", false);
                    FormMain.setComponentUsability("selecteeMeetCriteria", false);
                    FormMain.setComponentUsability("specialAgencyNeedReason", false);
                    FormMain.setComponentUsability("specialAgencyNeedReasonEssential", false);
                    FormMain.setComponentUsability("superiorQualificationReason", false);
                    FormMain.setComponentUsability("otherFactorsAsExplained", false);
                    FormMain.setComponentUsability("basicPayRateFactor", false);
                    FormMain.setComponentUsability("otherRelevantFactors", false);

                    hyf.util.setMandatoryConstraint("basicPayRateFactor", false);
                    try {
                        if ((typeof FormSection508 !== "undefined") && FormSection508.isUseSection508()) {
                            hyf.util.setComponentVisibility("basicPayRateFactorOutput", false);
                            hyf.util.setComponentVisibility("basicPayRateFactor", false);
                        }
                        hyf.util.setComponentVisibility("button_basicPayRateFactor", false);
                        $("#basicPayRateFactor_DISP > li > .removeButton").hide();
                    } catch(e) {
                    }
                    FormMain.setComponentUsability("otherReqJustificationApproved", false);
                    FormMain.setComponentUsability("otherReqSufficientInformationProvided", false);
                    FormMain.setComponentUsability("otherReqIncentiveRequired", false);
                    FormMain.setComponentUsability("otherReqDocumentationProvided", false);
                    FormMain.setComponentUsability("hrSpecialistReviewCertification", false);
                    FormMain.setComponentUsability("hrSpecialistNotSupportReason", false);
                    FormMain.setComponentUsability("reviewRcmdGrade", false);
                    FormMain.setComponentUsability("reviewRcmdStep", false);
                    FormMain.setComponentUsability("reviewRcmdLocalityPayScale", false);
                    FormMain.setComponentUsability("reviewRcmdLocalityPayScale_2", false);
                    FormMain.setComponentUsability("reviewRcmdGrade_2", false);
                    FormMain.setComponentUsability("reviewRcmdStep_2", false);
                    FormMain.setComponentUsability("requireOHCApproval", false);

                    _readOnly = true;
                }

                setBasicPayRateFactorAutoCompletion();
                setOHCDirectorAutoCompletion();

                onChangeSelecteeMeetCriteria(FormState.getElementValue("selecteeMeetCriteria"));
                onChangeSuperiorQualificationReason(FormState.getElementValue("superiorQualificationReason"));
                onChangeSpecialAgencyNeedReason(FormState.getElementValue("specialAgencyNeedReason"));
                onChangeHRSpecialistReviewCertification(FormState.getElementValue("hrSpecialistReviewCertification", ""));
                onChangeBasicPayRateFactor(FormState.getElementSelectArrayValue('basicPayRateFactor', []));
                setRecommandIncDecAmount(FormState.getElementValue("selecteeTotalCompensation"), FormState.getElementValue("reviewRcmdSalaryPerAnnum"))
                onChangeReviewRcmdPerDiffReqOHCApproval(FormState.getElementValue("requireOHCApproval"));
                onGradeChanged(FormState.getElementValue("grade"));
                setReviewRcmdLocalityPayScale();

                if (activityStep.isDGHOReview()) {
                    FormMain.setComponentUsability("selecteeMeetEligibility", false);
                    FormMain.setComponentUsability("qualifyingReappointment", false);
                    FormMain.setComponentUsability("selecteeMeetCriteria", false);
                    FormMain.setComponentUsability("specialAgencyNeedReason", false);
                    FormMain.setComponentUsability("specialAgencyNeedReasonEssential", false);
                    FormMain.setComponentUsability("superiorQualificationReason", false);
                    FormMain.setComponentUsability("otherFactorsAsExplained", false);
                    FormMain.setComponentUsability("basicPayRateFactor", false);
                    FormMain.setComponentUsability("otherRelevantFactors", false);
                    hyf.util.setMandatoryConstraint("basicPayRateFactor", false);
                    try {
                        if ((typeof FormSection508 !== "undefined") && FormSection508.isUseSection508()) {
                            hyf.util.setComponentVisibility("basicPayRateFactorOutput", false);
                            hyf.util.setComponentVisibility("basicPayRateFactor", false);
                        }
                        hyf.util.setComponentVisibility("button_basicPayRateFactor", false);
                        $("#basicPayRateFactor_DISP > li > .removeButton").hide();
                    } catch(e) {
                    }
                }

                FormMain.setComponentUsability("hrSpecialistReviewCertification", activityStep.isHRSReview());
                initReviewRecommendedSalaries();
                setOtherRequirementVisibility();
                setMiscellaneousReviewNoteVisibility();
                onChangeOtherRequirements();
            }
            if ("ES" === FormState.getElementValue("payPlan", "")) {
                onGradeHidden(false);
            }
        }

        function init(readOnly, tabObject) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();
            FormMain.resetMandatoryMark(tabObject);

            _initialized = true;
        }

        function render(action) {
        }

        return {
            onGradeChanged: onGradeChanged,
            onGradeHidden: onGradeHidden,
            onChangeSelecteeTotalCompensation: onChangeSelecteeTotalCompensation,
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_sam_review || (window.cms_incentives_sam_review = cms_incentives_sam_review());
})(window);
