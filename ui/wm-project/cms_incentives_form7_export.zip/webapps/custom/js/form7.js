(function (window) {
    var cms_incentives_sam_review = function () {
        var _readOnly = false;
        var _initialized = false;
        var _ohcDirector_ac = null;
        var _basicPayRateFactor_ac = null;
        var _lastRcmdSalary = null;
        var _lastRcmdSalaryIndex = -1;
        var _lastRcmdSalaryTr = null;

        var SELECTEE_MEET_ELIGIBILITY = {
            CIVILIAN_EMPLOYEE: "5 CFR 531.212(a)(i) First appointment as a civilian employee",
            REAPPOINTMENT: "5 CFR 531.212(a)(ii) Qualifying Reappointment",
            NOT_ELIGIBILITY: "Selectee does not meet eligibility requirements"
        };

        var SELECTEE_MEET_CRITERIA = {
            SUPERIOR: "Superior Qualifications",
            AGENCY_NEED: "Fills a special agency need"
        };

        var QUALIFYING_REAPPOINTMENT = {
            DAY90_BREAK_IN: "90-day break in service",
            OTHER: "Other exceptions"
        };

        var SUPERIOR_QUALIFICATION_REASON = {
            AS_ASSESSED: "As assessed by the candidate’s level, type or quality of skills and competencies",
            AS_EVIDENCED: "As evidenced by experience and/or education",
            IN_COMPARING: "In comparing his/her accomplishments to others in the field",
            OTHER: "Based on other factors"
        };

        var SPECIAL_AGENCY_NEED_REASON = {
            DOCUMENTED: "Agency’s workforce need is documented in the agency’s strategic human capital plan",
            ESSENTIAL: "Candidate’s qualities are essential to accomplishing an important agency mission, goal or program activity"
        };

        var HRSPECIALIST_REVIEW_CERTIFICATION = {
            SUPPORT_PROPOSED: "I support this request with the component’s proposed salary",
            SUPPORT_MODIFIED: "I support this request with the modified recommended salary",
            NOT_SUPPORT: "I do not support this request for the following reason(s)"
        };

        var OTHER_RELEVANT_FACTORS = {
            OTHER: "Other relevant factors"
        };


        function setBasicPayRateFactorAutoCompletion() {
            var option = {
                id: 'basicPayRateFactor',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                useAddButton: true,
                addButtonTooltip: "Click the button to add a rate of basic pay factor to the list",
                minSelectionCount: 1,
                maxSelectionCount: 10,
                readOnly: _readOnly,

                mapFunction: function (context) {
                },
                getSelectionLabel: function (item) {
                    return item.text;
                },
                getCandidateLabel: function (item) {
                    return item.value;
                },
                getItemID: function (item) {
                    return item.value;
                },
                setDataToForm: function (values) {
                    FormState.updateObjectValue('basicPayRateFactor', values);
                    onChangeBasicPayRateFactor(values);
                },
                sortSelectedValues: function (values) {
                    var other = null;
                    for (var i = 0; i < values.length; i++) {
                        var item = values[i];
                        if (item.value === OTHER_RELEVANT_FACTORS.OTHER) {
                            other = item;
                            values.splice(i, 1);
                            break;
                        }
                    }

                    values.sort(function (a, b) {
                        return a.value > b.value;
                    });

                    if (other !== null) {
                        values.push(item);
                    }

                    return values;
                },
                isValidListItem: function (item, target) {
                    return item.value !== "";
                },
                afterItemDisplayed: function (containerId, item) {
                    FormUtility.removeSelectOption(item.value, "basicPayRateFactor");
                },
                afterItemDeleted: function (containerId, targetId, item, values) {
                    var target = FormUtility.addSelectionAndSortExceptLast(item.text, item.value, "basicPayRateFactor", OTHER_RELEVANT_FACTORS.OTHER);
                    target.selectedIndex = values.length === 0 ? 0 : -1;
                },
                initialItems: FormState.getElementArrayValue('basicPayRateFactor', [])
            };

            _basicPayRateFactor_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        function resetSelecteeMeetCriteria() {
            FormState.updateSelectValue("selecteeMeetCriteria", "", "Select One", true);
            onChangeSelecteeMeetCriteria("");
        }

        function resetBasicPayRateFactor() {
            if (_basicPayRateFactor_ac) {
                _basicPayRateFactor_ac.deleteAllItems();
            }
            onChangeBasicPayRateFactor([]);
        }

        function updateSuperiorQualificationReason(value, text) {
            FormState.updateSelectValue("superiorQualificationReason", value, text, true);
            onChangeSuperiorQualificationReason(value);
        }

        function updateSpecialAgencyNeedReason(value, text) {
            FormState.updateSelectValue("specialAgencyNeedReason", value, text, true);
            onChangeSpecialAgencyNeedReason(value);
        }

        function onChangeSelecteeMeetEligibility(value) {
            var isReappointment = value === SELECTEE_MEET_ELIGIBILITY.REAPPOINTMENT;
            hyf.util.setComponentVisibility("qualifyingReappointment_group", isReappointment);
            if (!isReappointment) {
                FormState.updateSelectValue("qualifyingReappointment", "", "Select One", true);
                onChangeQualifyingReappointment("");
            }
            var isNotEligibility = value === SELECTEE_MEET_ELIGIBILITY.NOT_ELIGIBILITY;

            if (isNotEligibility) {
                resetSelecteeMeetCriteria();
                resetBasicPayRateFactor();
            }

            if (_initialized) {
                hyf.util.setMandatoryConstraint("basicPayRateFactor", !isNotEligibility);
            }
        }

        function onChangeSelecteeMeetCriteria(value) {
            var isAgencyNeed = value === SELECTEE_MEET_CRITERIA.AGENCY_NEED;
            var isSuperior = value === SELECTEE_MEET_CRITERIA.SUPERIOR;

            hyf.util.setComponentVisibility("specialAgencyNeedReason_group", isAgencyNeed);
            hyf.util.setComponentVisibility("superiorQualificationCriteria_group", isSuperior);
            if (!isAgencyNeed) {
                updateSpecialAgencyNeedReason("", "Select One");
            }
            if (!isSuperior) {
                updateSuperiorQualificationReason("", "Select One");
            }
        }

        function onChangeQualifyingReappointment(value) {
            var isOther = value === QUALIFYING_REAPPOINTMENT.OTHER;
            if (!isOther) {
                FormState.updateTextValue("otherExceptions", "", true);
            }
            hyf.util.setComponentVisibility("otherExceptions_group", isOther);
        }

        function onChangeSuperiorQualificationReason(value) {
            var isOther = value === SUPERIOR_QUALIFICATION_REASON.OTHER;
            hyf.util.setComponentVisibility("otherFactorsAsExplained_group", isOther);
            if (isOther) {
                FormUtility.focusElement("otherFactorsAsExplained");
            } else {
                FormState.updateTextValue("otherFactorsAsExplained", "", true);
            }
        }

        function onChangeSpecialAgencyNeedReason(value) {
            var isEssential = value === SPECIAL_AGENCY_NEED_REASON.ESSENTIAL;
            if (!isEssential) {
                FormState.updateTextValue("specialAgencyNeedReasonEssential", "", true);
            }
            hyf.util.setComponentVisibility("specialAgencyNeedReasonEssential_group", isEssential);
        }

        function setReviewerAndReviewDate(eleId, dateEleId, checked) {
            var currentUserName = "";
            var currentDate = "";
            if (checked) {
                currentUserName = myInfo.getMyName();
                currentDate = FormUtility.getDateString(false, "mm/dd/yyyy", new Date());
            }

            $("#" + eleId).val(currentUserName);
            $("#" + dateEleId).val(currentDate);

            FormState.updateTextValue(eleId, currentUserName, false);
            FormState.updateDateValue(dateEleId, currentDate, false);
        }

        function setRecommandIncDecAmount(totalCompensation, rcmdSalary) {
            totalCompensation = FormUtility.moneyToNumber(totalCompensation, 0);
            rcmdSalary = FormUtility.moneyToNumber(rcmdSalary, 0);

            var amount = rcmdSalary - totalCompensation;
            var amountStr = (amount > 0 ? "+" : "") + amount.format();
            FormState.updateTextValue("reviewRcmdIncDecAmount", amountStr, true);
            setReviewRcmdPercentageDifference(amount, totalCompensation);
        }

        function setReviewRcmdPercentageDifference(reviewRcmdIncDecAmount, totalCompensation) {
            var percentage = (reviewRcmdIncDecAmount * 100) / totalCompensation;
            var percentageStr = (percentage > 0 ? "+" : "") + percentage.format() + "%";
            FormState.updateTextValue("reviewRcmdPercentageDifference", percentageStr, true);
        }

        function getReviewRecommendedSalaryHtml(rcmdSalary) {
            var html = "<td>" + rcmdSalary.grade + " - " + rcmdSalary.step + "</td>";
            html += "<td>" + rcmdSalary.salaryPerAnnum + "</td>";
            html += "<td>" + rcmdSalary.localityPayScale + "</td>";
            html += "<td>" + rcmdSalary.createdBy + "</td>";
            html += "<td>" + rcmdSalary.modifiedBy + "</td>";
            html += "<td>" + rcmdSalary.modifierRoleGroup + "</td>";
            html += "<td>" + FormUtility.getDateString(false, "mm/dd/yyyy", new Date(FormUtility.parseInt(rcmdSalary.modifiedDate, 0))) + "</td>";

            return html;
        }

        function getReviewRecommendedSalaries() {
            var reviewRecommendedSalaries = FormState.getElementArrayValue("reviewRecommendedSalaries", []);
            if (reviewRecommendedSalaries.length === 1) {
                if (typeof reviewRecommendedSalaries[0].witemSeq === 'undefined') {
                    reviewRecommendedSalaries = [];
                }
            }

            return reviewRecommendedSalaries;
        }

        function initReviewRecommendedSalaries() {
            var reviewRecommendedSalaries = getReviewRecommendedSalaries();
            if (reviewRecommendedSalaries.length > 0) {
                var table = document.getElementById("reviewRcmdSalary_history");
                hyf.util.showComponent("recommandSalary_updates_group");
                for (var i = 0; i < reviewRecommendedSalaries.length; i++) {
                    var item = reviewRecommendedSalaries[i];
                    if (item && item.witemSeq) {
                        var html = getReviewRecommendedSalaryHtml(item);
                        var tr = document.createElement("tr");
                        tr.setAttribute("id", "reviewRecommendedSalaryTr" + i);
                        tr.innerHTML = html;
                        table.appendChild(tr);
                    }
                }
            }
        }

        function updateRecommendedSalary(opt) {
            opt = opt || {showMsg: true};
            var now = new Date();
            var witemSeq = FormMain.getProcessInfo().workitem.sequence;
            var reviewRecommendedSalaries = getReviewRecommendedSalaries();

            if (null == _lastRcmdSalary) {
                for (var i = 0; i < reviewRecommendedSalaries.length; i++) {
                    var item = reviewRecommendedSalaries[i];
                    if (item.witemSeq == witemSeq && item.modifier == myInfo.getMyMemberId()) {
                        _lastRcmdSalary = item;
                        _lastRcmdSalaryIndex = i;
                        _lastRcmdSalaryTr = document.getElementById("reviewRecommendedSalaryTr" + i);
                        break;
                    }
                }
            }

            var reviewRcmdGrade_2 = undefined !== opt.reviewRcmdGrade_2 ? opt.reviewRcmdGrade_2 : FormState.getElementValue("reviewRcmdGrade_2");
            var reviewRcmdStep_2 = undefined !== opt.reviewRcmdStep_2 ? opt.reviewRcmdStep_2 : FormState.getElementValue("reviewRcmdStep_2");
            var reviewRcmdSalaryPerAnnum_2 = undefined !== opt.reviewRcmdSalaryPerAnnum_2 ? opt.reviewRcmdSalaryPerAnnum_2 : FormState.getElementValue("reviewRcmdSalaryPerAnnum_2");
            var reviewRcmdLocalityPayScale_2 = undefined !== opt.reviewRcmdLocalityPayScale_2 ? opt.reviewRcmdLocalityPayScale_2 : FormState.getElementValue("reviewRcmdLocalityPayScale_2");

            if (null == _lastRcmdSalary) {
                var reviewRcmdGrade = FormState.getElementValue("reviewRcmdGrade");
                var reviewRcmdStep = FormState.getElementValue("reviewRcmdStep");
                var reviewRcmdSalaryPerAnnum = FormState.getElementValue("reviewRcmdSalaryPerAnnum");
                var reviewRcmdLocalityPayScale = FormState.getElementValue("reviewRcmdLocalityPayScale");

                if (reviewRcmdGrade === reviewRcmdGrade_2 && reviewRcmdStep === reviewRcmdStep_2
                    && reviewRcmdSalaryPerAnnum === reviewRcmdSalaryPerAnnum_2 && reviewRcmdLocalityPayScale === reviewRcmdLocalityPayScale_2) {
                    if (opt.showMsg) {
                        bootbox.alert("No change have been made. Please change value to update.");
                    }
                } else {
                    var last = null;

                    if (reviewRecommendedSalaries.length > 0) {
                        last = reviewRecommendedSalaries[reviewRecommendedSalaries.length - 1];
                    }

                    _lastRcmdSalary = {
                        grade: reviewRcmdGrade,
                        step: reviewRcmdStep,
                        salaryPerAnnum: reviewRcmdSalaryPerAnnum,
                        localityPayScale: reviewRcmdLocalityPayScale,
                        createdBy: null != last ? last.modifiedBy : FormState.getElementValue("reviewHRSpecialist"),
                        modifiedBy: myInfo.getMyName(),
                        modifier: myInfo.getMyMemberId(),
                        modifiedDate: now.getTime(),
                        modifierRoleGroup: activityStep.getCurrentRoleGroup(),
                        witemSeq: witemSeq
                    };

                    if (reviewRecommendedSalaries.length === 0) {
                        hyf.util.showComponent("recommandSalary_updates_group");
                    }

                    reviewRecommendedSalaries.push(_lastRcmdSalary);
                    _lastRcmdSalaryIndex = reviewRecommendedSalaries.length - 1;
                    FormState.updateObjectValue("reviewRecommendedSalaries", reviewRecommendedSalaries);
                    var table = document.getElementById("reviewRcmdSalary_history");
                    _lastRcmdSalaryTr = document.createElement("tr");
                    _lastRcmdSalaryTr.innerHTML = getReviewRecommendedSalaryHtml(_lastRcmdSalary);
                    table.appendChild(_lastRcmdSalaryTr);
                }
            } else {
                if (reviewRcmdGrade_2 === _lastRcmdSalary.grade && reviewRcmdStep_2 === _lastRcmdSalary.step
                    && reviewRcmdSalaryPerAnnum_2 === _lastRcmdSalary.salaryPerAnnum && reviewRcmdLocalityPayScale_2 === _lastRcmdSalary.localityPayScale) {
                    if (null != _lastRcmdSalaryTr) {
                        var table = document.getElementById("reviewRcmdSalary_history");
                        table.removeChild(_lastRcmdSalaryTr);
                        _lastRcmdSalaryTr = null;
                    }
                    if (_lastRcmdSalaryIndex !== -1) {
                        reviewRecommendedSalaries.splice(_lastRcmdSalaryIndex, 1);
                        FormState.updateObjectValue("reviewRecommendedSalaries", reviewRecommendedSalaries);
                        if (reviewRecommendedSalaries.length === 0) {
                            hyf.util.hideComponent("recommandSalary_updates_group");
                        }
                        _lastRcmdSalaryIndex = -1;
                    }
                    _lastRcmdSalary = null;
                } else {
                    _lastRcmdSalary.modifiedDate = now.getTime();
                    _lastRcmdSalaryTr.innerHTML = getReviewRecommendedSalaryHtml(_lastRcmdSalary);
                }
            }

            FormState.updateSelectValue("reviewRcmdGrade", reviewRcmdGrade_2, reviewRcmdGrade_2, false);
            FormState.updateSelectValue("reviewRcmdStep", reviewRcmdStep_2, reviewRcmdStep_2, false);
            FormState.updateDijitInputInner("reviewRcmdSalaryPerAnnum", reviewRcmdSalaryPerAnnum_2, false);
            FormState.updateSelectValue("reviewRcmdLocalityPayScale", reviewRcmdLocalityPayScale_2, reviewRcmdLocalityPayScale_2, false);

            cms_incentives_sam_approval.setApproverNotesVisibility();
        }

        function enableRecommendedSalaryUpdate() {
            hyf.util.hideComponent("reviewRcmdSalary_group");
            hyf.util.showComponent("reviewRcmdSalary_group_2");

            if (activityStep.isTABGReview() || activityStep.isOHCReview()) {
                hyf.util.enableComponent("reviewRcmdStep_2");
                hyf.util.enableComponent("reviewRcmdSalaryPerAnnum_2");
            }

            var reviewRcmdGrade = FormState.getElementValue("reviewRcmdGrade");
            var reviewRcmdStep = FormState.getElementValue("reviewRcmdStep");
            var reviewRcmdSalaryPerAnnum = FormState.getElementValue("reviewRcmdSalaryPerAnnum");
            var reviewRcmdLocalityPayScale = FormState.getElementValue("reviewRcmdLocalityPayScale");

            FormState.updateSelectValue("reviewRcmdGrade_2", reviewRcmdGrade, reviewRcmdGrade, true);
            FormState.updateSelectValue("reviewRcmdStep_2", reviewRcmdStep, reviewRcmdStep, true);
            FormState.updateDijitInputInner("reviewRcmdSalaryPerAnnum_2", reviewRcmdSalaryPerAnnum, true);
            LookupManager.fillListBox("reviewRcmdLocalityPayScale_2", "Incentives-Locality");
            FormState.updateSelectValue("reviewRcmdLocalityPayScale_2", reviewRcmdLocalityPayScale, reviewRcmdLocalityPayScale, true);
        }

        function onChangeHRSpecialistReviewCertification(value) {
            var isNotSupport = value === HRSPECIALIST_REVIEW_CERTIFICATION.NOT_SUPPORT;

            if (isNotSupport) {
                FormState.updateSelectValue("requireOHCApproval", "", "Select One", true);
                onChangeReviewRcmdPerDiffReqOHCApproval("");
            } else {
                FormState.updateSelectValue("hrSpecialistNotSupportReason", "", "Select One", true);
            }

            hyf.util.setComponentVisibility("hrSpecialistNotSupportReason_group", isNotSupport);

            if (_initialized) {
                setReviewerAndReviewDate("reviewHRSpecialist", "hrSpecialistReviewDate", value !== "");
            }

            var isSupportProposed = value === HRSPECIALIST_REVIEW_CERTIFICATION.SUPPORT_PROPOSED;
            var isSupportModified = value === HRSPECIALIST_REVIEW_CERTIFICATION.SUPPORT_MODIFIED;
            hyf.util.setComponentVisibility("recommendedSalary_group", isSupportModified);
            hyf.util.setComponentVisibility("requireOHCApproval_group", isSupportProposed || isSupportModified);

            if (!_initialized && isSupportModified) {
                if (activityStep.isDGHOReview() || activityStep.isTABGReview() || activityStep.isOHCReview()) {
                    enableRecommendedSalaryUpdate();
                }
            }
        }

        function onChangeBasicPayRateFactor(values) {
            var isOther = false;
            for (var i = 0; i < values.length; i++) {
                if (values[i].value === OTHER_RELEVANT_FACTORS.OTHER) {
                    isOther = true;
                    break;
                }
            }

            hyf.util.setComponentVisibility("otherRelevantFactors_group", isOther);
            if (isOther) {
                if (FormState.getElementValue("otherRelevantFactors", "'") === "") {
                    FormUtility.focusElement("otherRelevantFactors");
                }
            } else {
                FormState.updateTextValue("otherRelevantFactors", "", true);
            }
        }

        function onGradeChanged(grade) {
            hyf.util.setComponentVisibility("reviewRcmdStep_group", "00" !== grade);
            if (_initialized) {
                FormState.updateSelectValue("reviewRcmdGrade", grade, grade, true);
                FormState.updateSelectValue("reviewRcmdGrade_2", grade, grade, true);
            }
        }

        function onChangeSelecteeTotalCompensation(value) {
            setRecommandIncDecAmount(value, FormState.getElementValue("reviewRcmdSalaryPerAnnum"));
        }

        function onChangeReviewRcmdPerDiffReqOHCApproval(value) {
            var isYes = "Yes" === value;
            hyf.util.setComponentVisibility("reviewRcmdApprovalOHCDirector_group", isYes);

            if (!isYes) {
                _ohcDirector_ac.deleteAllItems();
            }
        }

        function onChangeOtherRequirements(opt) {
            opt = opt || {};
            var otherReqJustificationApproved = opt.otherReqJustificationApproved || FormState.getElementValue("otherReqJustificationApproved");
            var otherReqSufficientInformationProvided = opt.otherReqSufficientInformationProvided || FormState.getElementValue("otherReqSufficientInformationProvided");
            var otherReqIncentiveRequired = opt.otherReqIncentiveRequired || FormState.getElementValue("otherReqIncentiveRequired");
            var otherReqDocumentationProvided = opt.otherReqDocumentationProvided || FormState.getElementValue("otherReqDocumentationProvided");

            hyf.util.setComponentUsability("button_SubmitWorkitem",
                otherReqJustificationApproved === "Yes" && otherReqSufficientInformationProvided === "Yes"
                && otherReqIncentiveRequired === "Yes" && otherReqDocumentationProvided === "Yes");
        }

        function initEventHandlers() {
            $('#selecteeMeetEligibility').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeSelecteeMeetEligibility(value);
            });
            $('#selecteeMeetCriteria').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeSelecteeMeetCriteria(value);
            });
            $('#qualifyingReappointment').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeQualifyingReappointment(value);
            });
            $('#superiorQualificationReason').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeSuperiorQualificationReason(value);
            });
            $('#specialAgencyNeedReason').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeSpecialAgencyNeedReason(value);
            });
            $('#hrSpecialistReviewCertification').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeHRSpecialistReviewCertification(value);
            });
            $('#reviewRcmdSalaryPerAnnum').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                setRecommandIncDecAmount(FormState.getElementValue("selecteeTotalCompensation"), value);
            });
            $('#requireOHCApproval').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeReviewRcmdPerDiffReqOHCApproval(value);
            });
            $('#reviewRcmdGrade_2').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                updateRecommendedSalary({reviewRcmdGrade_2: value});
            });
            $('#reviewRcmdStep_2').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                updateRecommendedSalary({reviewRcmdStep_2: value});
            });
            $('#reviewRcmdSalaryPerAnnum_2').on('blur', function (e) {
                var target = e.target;
                var value = target.value;
                updateRecommendedSalary({reviewRcmdSalaryPerAnnum_2: value});
            });
            $('#reviewRcmdLocalityPayScale_2').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                updateRecommendedSalary({reviewRcmdLocalityPayScale_2: value});
            });
            $('#otherReqJustificationApproved').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeOtherRequirements({otherReqJustificationApproved: value});
            });
            $('#otherReqSufficientInformationProvided').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeOtherRequirements({otherReqSufficientInformationProvided: value});
            });
            $('#otherReqIncentiveRequired').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeOtherRequirements({otherReqIncentiveRequired: value});
            });
            $('#otherReqDocumentationProvided').on('change', function (e) {
                var target = e.target;
                var value = target.options[target.options.selectedIndex].value;
                onChangeOtherRequirements({otherReqDocumentationProvided: value});
            });
        }

        function setOHCDirectorAutoCompletion() {
            _ohcDirector_ac = cms_incentives_general.setDesignatedUserAutoCompletion("reviewRcmdApprovalOHCDirector", USER_GROUP_KEY.OHC_DIRECTORS, 0, 1, _readOnly);
        }

        function setReviewRcmdLocalityPayScale() {
            LookupManager.fillListBox("reviewRcmdLocalityPayScale", "Incentives-Locality");
        }

        function setOtherRequirementVisibility() {
            if (activityStep.isHRSReview() || activityStep.isDGHOReview()) {
                hyf.util.showComponent("otherRequirements_group");
            } else if (activityStep.isTABGReview() || activityStep.isOHCReview()) {
                hyf.util.showComponent("otherRequirements_group");
                hyf.util.disableComponent("otherRequirements_group");
            }
        }

        function setMiscellaneousReviewNoteVisibility() {
            if (activityStep.isHRSReview() || activityStep.isDGHOReview()) {
                hyf.util.showComponent("miscellaneousReviewNote_group");
            } else if (activityStep.isTABGReview() || activityStep.isOHCReview()) {
                hyf.util.showComponent("miscellaneousReviewNote_group");
                hyf.util.disableComponent("miscellaneousReviewNote_group");
            }
        }

        function initComponents() {
            hyf.util.disableComponent("hrSpecialistReviewDate");

            if (activityStep.isStartNew() || activityStep.isSOReview()) {
                hyf.util.hideComponent("selecteeMeet_sub_group");
                hyf.util.hideComponent("basicPayRate_group");
                hyf.util.hideComponent("otherRequirements_group");
                hyf.util.hideComponent("hrsRegulatoryReview_group");
            } else {
                if (!_readOnly && (activityStep.isTABGReview() || activityStep.isOHCReview())) {
                    hyf.util.disableComponent("samReview_upper_group");
                    hyf.util.disableComponent("recommendedSalary_group");
                    hyf.util.disableComponent("requireOHCApproval_group");
                    _readOnly = true;
                }

                setBasicPayRateFactorAutoCompletion();
                setOHCDirectorAutoCompletion();

                onChangeSelecteeMeetEligibility(FormState.getElementValue("selecteeMeetEligibility"));
                onChangeQualifyingReappointment(FormState.getElementValue("qualifyingReappointment"));
                onChangeSelecteeMeetCriteria(FormState.getElementValue("selecteeMeetCriteria"));
                onChangeSuperiorQualificationReason(FormState.getElementValue("superiorQualificationReason"));
                onChangeSpecialAgencyNeedReason(FormState.getElementValue("specialAgencyNeedReason"));
                onChangeHRSpecialistReviewCertification(FormState.getElementValue("hrSpecialistReviewCertification", ""));
                onChangeBasicPayRateFactor(FormState.getElementArrayValue('basicPayRateFactor', []));
                setRecommandIncDecAmount(FormState.getElementValue("selecteeTotalCompensation"), FormState.getElementValue("reviewRcmdSalaryPerAnnum"))
                onChangeReviewRcmdPerDiffReqOHCApproval(FormState.getElementValue("requireOHCApproval"));
                onGradeChanged(FormState.getElementValue("grade"));
                setReviewRcmdLocalityPayScale();

                if (activityStep.isTABGReview() || activityStep.isOHCReview()) {
                    hyf.util.enableComponent("reviewRcmdStep");
                    hyf.util.enableComponent("reviewRcmdSalaryPerAnnum");
                }

                hyf.util.setComponentUsability("hrSpecialistReviewCertification", activityStep.isHRSReview());
                initReviewRecommendedSalaries();
                setOtherRequirementVisibility();
                setMiscellaneousReviewNoteVisibility();
                onChangeOtherRequirements();
            }
        }

        function init(readOnly) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();

            _initialized = true;
        }

        function render(action) {
        }

        return {
            onGradeChanged: onGradeChanged,
            onChangeSelecteeTotalCompensation: onChangeSelecteeTotalCompensation,
            init: init,
            render: render
        }
    };

    var _initializer = window.cms_incentives_sam_review || (window.cms_incentives_sam_review = cms_incentives_sam_review());
})(window);
