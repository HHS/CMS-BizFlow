(function(window){
	function cms_erlr_3rdparty_hear(){
    initialized = false;
	function init () {
		var thirdPartyHearing = FormState.getElementValue();
        hyf.util.hideComponent('thrd_prty_Exception_info_group');
        hyf.util.hideComponent('thrd_prty_Arbitration_group_Grievance');        
        hyf.util.hideComponent('thrd_prty_Exception_info_group_2');
        hyf.util.hideComponent('thrd_prty_discovery_due_group');  
        hyf.util.hideComponent('thrd_prty_petition_review_date_group'); 
        $('#THRD_PRTY_APPEAL_TYPE').on('change',appealTypeEvent);
		$('#thrd_prty_group select,#thrd_prty_group input[type="text"]').on('change',updateEvent);
	var actionType = FormState.getElementValue('THRD_PRTY_APPEAL_TYPE');
	 //if(actionType !='undefined'){
		if(actionType && actionType !=='undefined'){
            if(actionType === 'Arbitration'){								
                hyf.util.showComponent('thrd_prty_Arbitration_group');
                hyf.util.hideComponent('thrd_prty_Special_Counsel_group');
                hyf.util.hideComponent('thrd_prty_Arbitration_group_Grievance');
                hyf.util.hideComponent('thrd_prty_MSPB_group');
				hyf.util.hideComponent('thrd_prty_FLRA_group');
            }
            else if(actionType === 'Special Counsel'){
                hyf.util.hideComponent('thrd_prty_Arbitration_group');                
				hyf.util.showComponent('thrd_prty_Special_Counsel_group');
                hyf.util.hideComponent('thrd_prty_Arbitration_group_Grievance');
                hyf.util.hideComponent('thrd_prty_MSPB_group');
				hyf.util.hideComponent('thrd_prty_FLRA_group');
            }
            else if(actionType === 'Grievance'){                
                hyf.util.hideComponent('thrd_prty_Arbitration_group');
                hyf.util.hideComponent('thrd_prty_Special_Counsel_group');
				hyf.util.showComponent('thrd_prty_Arbitration_group_Grievance');
				hyf.util.hideComponent('thrd_prty_FLRA_group');
                hyf.util.hideComponent('thrd_prty_MSPB_group');
            }
            else if(actionType === 'MSPB'){   thrd_prty_FLRA_group             
                hyf.util.hideComponent('thrd_prty_Arbitration_group');
                hyf.util.hideComponent('thrd_prty_Special_Counsel_group');
                hyf.util.hideComponent('thrd_prty_Arbitration_group_Grievance');
				hyf.util.hideComponent('thrd_prty_FLRA_group');
				hyf.util.showComponent('thrd_prty_MSPB_group');
            }
			else if(actionType === 'FLRA'){                
                hyf.util.hideComponent('thrd_prty_Arbitration_group');
                hyf.util.hideComponent('thrd_prty_Special_Counsel_group');
                hyf.util.hideComponent('thrd_prty_Arbitration_group_Grievance');
				hyf.util.hideComponent('thrd_prty_MSPB_group');
				hyf.util.showComponent('thrd_prty_FLRA_group');
            }
            else{                
                hyf.util.hideComponent('thrd_prty_Arbitration_group');
                hyf.util.hideComponent('thrd_prty_Special_Counsel_group');
                hyf.util.hideComponent('thrd_prty_Arbitration_group_Grievance');
                hyf.util.hideComponent('thrd_prty_MSPB_group');
				hyf.util.hideComponent('thrd_prty_FLRA_group');
            }
		}
		//}
	// }
    }
	//TODO: set contraint on date fields. In appeal tab as well.
	var dateFields = [
		'THRD_PRTY_PREHEARING_DT',
		'THRD_PRTY_HEARING_DT',
		'THRD_PRTY_POSTHEARING_BRIEF_DUE',
		'THRD_PRTY_FINAL_ARBITRATOR_DECISION_DT',
		'THRD_PRTY_EXCEPTION_FILE_DT',
		'THRD_PRTY_RESPONSE_TO_EXCEPTIONS_DUE',
		'THRD_PRTY_FINAL_FLRA_DECISION_DT',
		'THRD_PRTY_PREHEARING_DT_SC',
		'THRD_PRTY_HEARING_DT_SC',
		'THRD_PRTY_DT_STEP_DECISION',
		'THRD_PRTY_PREHEARING_DT_2',
		'THRD_PRTY_HEARING_DT_2',
		'THRD_PRTY_POSTHEARING_BRIEF_DUE_2',
		'THRD_PRTY_FINAL_ARBITRATOR_DECISION_DT_2',
		'THRD_PRTY_EXCEPTION_FILE_DT_2',
		'THRD_PRTY_RESPONSE_TO_EXCEPTIONS_DUE',
		'THRD_PRTY_FINAL_FLRA_DECISION_DT_2',
		'THRD_PRTY_THRD_PRTYPEAL_FILE_DT',
		'THRD_PRTY_DT_SETTLEMENT_DISCUSSION',
		'THRD_PRTY_DT_AGENCY_FILE_RESPONSE_DUE',
		'THRD_PRTY_PREHEARING_DT_MSPB',
		'THRD_PRTY_DT_DISCOVERY_DUE',
		'THRD_PRTY_HEARING_DT_MSPB',
		'THRD_PRTY_INITIAL_DECISION_DT_MSPB',
		'THRD_PRTY_PETITION_FILED_DT_MSPB',
		'THRD_PRTY_FINAL_BOARD_DECISION_DT_MSPB',
		'THRD_PRTY_PETITION_RV_DT'
		];
		dateFields.forEach(function(el){
			if(el !==''){
				try{hyf.calendar.setDateConstraint(el, 'Maximum', 'Today');}catch(err){}
			}
		})
	
   function render() {
		
    }
    function dateValidate(e, msg, targetId){
        var days = 0
        var dt1 = '';
        var dt2 = ''
        if(e.value1 !=undefined || e.value2 !=undefined){
            dt1 = e.value1;
            dt2 = e.value2;
        }
        if((dt2 && dt2 !== '') ||(dt1 && dt1 !== '')){
            var m1 = moment(dt1);
            var m2 = moment(dt2);
            days = m2.diff(m1,'days');
            if(days < 0 ){
                bootbox.alert({
                message: msg,
                callback: function(){ 
                    FormState.doAction(StateAction.changeDate(targetId, ''), false);
                    $('#' +targetId).val('');
                    }
                });
            }
        }
    }
function appealTypeEvent(e){
	var appealType = '';//e.target.options[e.target.options.selectedIndex].value;
	if(e === 'undefined'){
		return;
	}else if(typeof e ==='object'){
		if(e.target !=='undefined'){
			appealType = e.target.options[e.target.options.selectedIndex].value;
		}
	}
	if(appealType && appealType !=='undefined'){
            if(appealType === 'Arbitration'){								
                hyf.util.showComponent('thrd_prty_Arbitration_group');
                hyf.util.hideComponent('thrd_prty_Special_Counsel_group');
                hyf.util.hideComponent('thrd_prty_Arbitration_group_Grievance');
                hyf.util.hideComponent('thrd_prty_MSPB_group');
				hyf.util.hideComponent('thrd_prty_FLRA_group');
            }
            else if(appealType === 'Special Counsel'){
                hyf.util.hideComponent('thrd_prty_Arbitration_group');                
				hyf.util.showComponent('thrd_prty_Special_Counsel_group');
                hyf.util.hideComponent('thrd_prty_Arbitration_group_Grievance');
                hyf.util.hideComponent('thrd_prty_MSPB_group');
				hyf.util.hideComponent('thrd_prty_FLRA_group');
            }
            else if(appealType === 'Grievance'){                
                hyf.util.hideComponent('thrd_prty_Arbitration_group');
                hyf.util.hideComponent('thrd_prty_Special_Counsel_group');
				hyf.util.showComponent('thrd_prty_Arbitration_group_Grievance');
				hyf.util.hideComponent('thrd_prty_FLRA_group');
                hyf.util.hideComponent('thrd_prty_MSPB_group');
            }
            else if(appealType === 'MSPB'){   thrd_prty_FLRA_group             
                hyf.util.hideComponent('thrd_prty_Arbitration_group');
                hyf.util.hideComponent('thrd_prty_Special_Counsel_group');
                hyf.util.hideComponent('thrd_prty_Arbitration_group_Grievance');
				hyf.util.hideComponent('thrd_prty_FLRA_group');
				hyf.util.showComponent('thrd_prty_MSPB_group');
            }
			else if(appealType === 'FLRA'){                
                hyf.util.hideComponent('thrd_prty_Arbitration_group');
                hyf.util.hideComponent('thrd_prty_Special_Counsel_group');
                hyf.util.hideComponent('thrd_prty_Arbitration_group_Grievance');
				hyf.util.hideComponent('thrd_prty_MSPB_group');
				hyf.util.showComponent('thrd_prty_FLRA_group');
            }
            else{                
                hyf.util.hideComponent('thrd_prty_Arbitration_group');
                hyf.util.hideComponent('thrd_prty_Special_Counsel_group');
                hyf.util.hideComponent('thrd_prty_Arbitration_group_Grievance');
                hyf.util.hideComponent('thrd_prty_MSPB_group');
				hyf.util.hideComponent('thrd_prty_FLRA_group');
            }
        }
		$('#thrd_prty_group select,#thrd_prty_group input[type="text"]').not('#THRD_PRTY_APPEAL_TYPE').val('');
}
function updateEvent(e){
	var eventSource = '';
	var val = '';//e.target.options[e.target.options.selectedIndex].value;
	if(e === 'undefined'){
		return;
	}else if(typeof e ==='object'){
		if(e.target !=='undefined'){
			val = e.target.options[e.target.options.selectedIndex].value;
			eventSource = e.target.id;
		}
	}
	 if(eventSource && eventSource === 'THRD_PRTY_EXCEPTION_FILED'){
            if(val === 'Yes'){
        	    hyf.util.showComponent('thrd_prty_Exception_info_group');            	
            }
            else{
				hyf.util.hideComponent('thrd_prty_Exception_info_group');            	
            }
        }
        
        if(eventSource && eventSource ==='THRD_PRTY_EXCEPTION_FILED_2'){
            if(val === 'Yes'){
        	    hyf.util.showComponent('thrd_prty_Exception_info_group_2');            	
            }
            else{
				hyf.util.hideComponent('thrd_prty_Exception_info_group_2');            	
            }
        }
        
        if(eventSource && eventSource === 'THRD_PRTY_ARBITRATION_INVOKED'){
            if(val === 'Yes'){
        	    hyf.util.showComponent('thrd_prty_Arbitration_group_Grievance');            	
            }
            else{
				hyf.util.hideComponent('thrd_prty_Arbitration_group_Grievance');            	
            }
        }
        
        if(eventSource && eventSource === 'THRD_PRTY_WAS_DISCOVERY_INITIATED'){
            if(val === 'Yes'){
        	    hyf.util.showComponent('thrd_prty_discovery_due_group');            	
            }
            else{
				hyf.util.hideComponent('thrd_prty_discovery_due_group');            	
            }
        }
        if(eventSource && eventSource ==='THRD_PRTY_WAS_PETITION_FILED_MSPB'){
            if(val === 'Yes'){
        	    hyf.util.showComponent('thrd_prty_petition_review_date_group');            	
            }
            else{
				hyf.util.hideComponent('thrd_prty_petition_review_date_group');            	
            }
        }      
}
function appealDateEvents(e){
	var eventSource = e.target.id;
	var val = $('#' +eventSource).val();
	 if(eventSource && eventSource ==='THRD_PRTY_PREHEARING_DT'){
			 var hearingDate = FormState.getElementValue('THRD_PRTY_HEARING_DT');
			dateValidate({value1: val, value2: hearingDate}, 'Date of Hearing must be after the Date of Prehearing Conference.','THRD_PRTY_PREHEARING_DT');
		}
        
        if(eventSource && eventSource === 'THRD_PRTY_HEARING_DT'){
			var phearingDt = FormState.getElementValue('THRD_PRTY_PREHEARING_DT');
            dateValidate({value1: phearingDt, value2: val}, 'Date of Hearing must be after the Date of Prehearing Conference.','THRD_PRTY_HEARING_DT');
        }
        
        if(eventSource && eventSource === 'THRD_PRTY_PREHEARING_DT_MSPB'){//prehearingDateMSPB
			var hearing = FormState.getElementValue('THRD_PRTY_HEARING_DT_MSPB');
			dateValidate({value1: val, value2: hearing}, 'Date of Hearing must be after the Date of Prehearing Conference.','THRD_PRTY_PREHEARING_DT_MSPB');
		}
     
        if(eventSource && eventSource ==='THRD_PRTY_HEARING_DT_MSPB' ){//hearingDateMSPB
			var hearingMSPB = FormState.getState('THRD_PRTY_PREHEARING_DT_MSPB');
            dateValidate({value1:val, value2: hearingMSPB}, 'Date of Hearing must be after the Date of Prehearing Conference.','THRD_PRTY_HEARING_DT_MSPB');
        }
        
       if(eventSource && eventSource =='THRD_PRTY_PREHEARING_DT_SC'){
			var phearingDTSC = FormState.getState('THRD_PRTY_HEARING_DT_SC');
			dateValidate({value1: val, value2: phearingDTSC}, 'Date of Hearing must be after the Date of Prehearing Conference.','THRD_PRTY_PREHEARING_DT_SC');
		}
        
        if(eventSource && eventSource ==='THRD_PRTY_HEARING_DT_SC'){
			var phearingSC = FormState.getState('THRD_PRTY_PREHEARING_DT_SC');
           dateValidate({value1:val, value2: phearingSC}, 'Date of Hearing must be after the Date of Prehearing Conference.','THRD_PRTY_HEARING_DT_SC');
        }
}
return {
	appealDateEvents : appealDateEvents,
	updateEvent : updateEvent,
	appealTypeEvent : appealTypeEvent,
	dateValidate : dateValidate,
	init : init,
	render : render
}
}
(window.cms_erlr_3rdparty_hear  !== undefined ? window.cms_erlr_3rdparty_hear :(window.cms_erlr_3rdparty_hear = cms_erlr_3rdparty_hear()));
})(window)






