(function (window) {
    var cms_incentives_position = function () {
        var _initialized = false;
        var _dutyStation_ac = null;

        function setDutyStationAutoCompletion() {
            var option = {
                id: 'dutyStation_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchDutyStations.do?l=100&q=',
                minLength: 2,
                minSelectionCount: 0,
                maxSelectionCount: 1,

                mapFunction: function (context) {
                    return {
                        id: $("LOC_ID", context).text(),
                        state: $("LOC_STATE", context).text(),
                        city: $("LOC_CITY", context).text()
                    };
                },
                getSelectionLabel: function (item) {
                    return item.city + ", " + item.state
                },
                getCandidateLabel: function (item) {
                    return item.city + ", " + item.state
                },
                getItemID: function (item) {
                    return item.id;
                },
                setDataToForm: function (values) {
                    FormState.updateObjectValue('dutyStation', values);
                },
                // initialize
                initialItems: FormState.getElementArrayValue('dutyStation', [])
            };

            _dutyStation_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        function setGradeOptions(grades) {
            $('#grade').children('option:not(:first)').remove();
            if (grades) {
                for (var g = 0; g < grades.length; g++) {
                    var grade = grades[g];
                    if (grade) {
                        $('#grade').append($("<option></option>").attr("value", grade).text(grade));
                    }
                }
            }
        }

        function setGradeSelectBox(item) {
            if (item.position) {
                setGradeOptions(item.position.grade);
            }
        }

        function isValidGrades(grades) {
            for (var g = 0; g < grades.length; g++) {
                if (grades[g]) return true;
            }

            return false;
        }

        function setGradeSelectBoxByPayPlan(payPlan, item) {
            if (payPlan && 'ES, GP, GR, GS, WG'.indexOf(payPlan) !== -1) {
                hyf.util.showComponent('grade_group');
                item = item || FormState.getElementSingleValue('associatedIncentives');
                if (null != item) {
                    if (!isValidGrades(item.position.grade)) {
                        if ('ES' === payPlan) {
                            setGradeOptions([1, 2, 3, 4, 5, 6]);
                        } else if ('WG' === payPlan) {
                            setGradeOptions([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
                        } else if ('GP, GR, GS'.indexOf(payPlan) !== -1) {
                            setGradeOptions([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]);
                        }
                    } else if (_initialized) {
                        FormState.updateSelectValue("grade", "", "Select One", true);
                    }
                }
            } else {
                hyf.util.hideComponent('grade_group');
            }
        }

        function setPositionDescriptionNumber(item) {
            item = item || FormState.getElementSingleValue('associatedIncentives');
            if (item.position.descNum) {
                if (isValidGrades(item.position.grade)) {
                    var target = document.getElementById('grade');
                    var selectedIndex = target.options.selectedIndex;
                    if (selectedIndex > 0) {
                        if (item.position.descNum.length >= selectedIndex) {
                            var descNum = item.position.descNum[selectedIndex - 1];
                            FormState.updateTextValue("posDescNumber", descNum, true);
                        }
                    }
                }
            }
        }

        function populateRelatedFields(item) {
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_position::populateRelatedFields - item ==> ", item);
            if (item) {
                item.position = item.position || {title: '', payPlan: {desc: ''}, series: {desc: ''}};
                var payPlan = item.position.payPlan.desc;

                // var series = item.position.series.desc;
                var series = '0602';  // automatically populate as 0602 by user story 212170
                FormState.updateTextValue("positionTitle", item.position.title, true);
                FormState.updateTextValue("payPlan", payPlan, true);
                FormState.updateTextValue("series", series, true);
                FormState.updateTextValue("notToExceedDate", item.position.notToExceedDate, true);
                if (item.position.workSchedule) {
                    var workSchedule = item.position.workSchedule.desc;
                    FormState.updateTextValue("workSchedule", workSchedule, true);
                    setHoursPerWeek(workSchedule);
                }
                FormState.updateTextValue("hoursPerWeek", item.position.hoursPerWeek, true);

                setGradeSelectBoxByPayPlan(payPlan, item);
                setGradeSelectBox(item);
                setPVPayPlanSeriesGrade(payPlan, series, '');

                item.license = item.license || {info: ''};
                FormState.updateTextValue("licenseInfo", item.license.info, true);

                if (null == item.id) {   // clean
                    _dutyStation_ac.deleteAllItems();
                    FormState.updateTextValue("posDescNumber", "", true);
                    FormState.updateSelectValue("typeOfAppointment", "", "Select One", true);
                    FormState.updateSelectValue("requireBoardCert", "", "Select One", true);
                    FormState.updateSelectValue("requireAdminApproval", "", "Select One", true);
                }
            }
        }

        function setPVPayPlanSeriesGrade(payPlan, series, grade) {
            var value = "";
            if (payPlan && payPlan.length > 0) {
                value = payPlan;
            }
            if (series && series.length > 0) {
                value += '/' + series;
            }
            if (grade && grade.length > 0) {
                value += '/' + grade;
            }
            FormState.updateObjectValue('payPlanSeriesGrade', value);
        }

        function setHoursPerWeek(workSchedule) {
            workSchedule = workSchedule || FormState.getElementValue("workSchedule");
            if ("Full-Time" === workSchedule) {
                if (_initialized) {
                    FormState.updateTextValue("hoursPerWeek", 40, true);
                }
                hyf.util.showComponent('hoursPerWeek_group');
                hyf.util.disableComponent("hoursPerWeek");
            } else if ("Part-Time" === workSchedule) {
                hyf.util.showComponent('hoursPerWeek_group');
                hyf.util.enableComponent("hoursPerWeek");
                if (_initialized) {
                    FormState.updateTextValue("hoursPerWeek", '', true);
                }
            } else {
                hyf.util.hideComponent('hoursPerWeek_group');
            }
        }

        function setPayPlanSelectBox() {
            var payPlans = LookupManager.findByLTYPE('PayPlan');
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_position::setPayPlanSelectBox - payPlans ==> ", payPlans);

            $('#payPlan').children('option:not(:first)').remove();
            if (payPlans.length > 0) {
                for (var i = 0; i < payPlans.length; i++) {
                    var item = payPlans[i];
                    if (item) {
                        $('#payPlan').append($("<option></option>").attr("value", item.NAME).text(item.NAME));
                    }
                }
            }
        }

        function setTypeOfAppointmentSelectBox() {
            var lookupData = LookupManager.findByLTYPE('ApptType');
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_position::setTypeOfAppointmentSelectBox - ApptType ==> ", lookupData);

            $('#typeOfAppointment').children('option:not(:first)').remove();
            if (lookupData.length > 0) {
                for (var i = 0; i < lookupData.length; i++) {
                    var item = lookupData[i];
                    if (item) {
                        $('#typeOfAppointment').append($("<option></option>").attr("value", item.NAME).text(item.NAME));
                    }
                }
            }
        }

        function setNotToExceedDate(typeOfAppointment) {
            typeOfAppointment = typeOfAppointment || FormState.getElementValue("typeOfAppointment");
            if ("Term, Temporary Promotion, Temporary".indexOf(typeOfAppointment) !== -1) {
                hyf.util.showComponent('notToExceedDate_group');
            } else {
                hyf.util.hideComponent('notToExceedDate_group');
            }
        }

        function setWorkScheduleSelectBox() {
            var lookupData = LookupManager.findByLTYPE('WorkSchedule');
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_position::setWorkScheduleSelectBox - WorkSchedule ==> ", lookupData);

            $('#workSchedule').children('option:not(:first)').remove();
            if (lookupData.length > 0) {
                for (var i = 0; i < lookupData.length; i++) {
                    var item = lookupData[i];
                    if (item) {
                        $('#workSchedule').append($("<option></option>").attr("value", item.NAME).text(item.NAME));
                    }
                }
            }
        }

        function initEventHandlers() {
            $('#grade').on('change', function (e) {
                var target = e.target;
                var grade = target.options[target.options.selectedIndex].value;
                setPVPayPlanSeriesGrade(FormState.getElementValue('payPlan', ''), FormState.getElementValue('series', ''), grade);
                setPositionDescriptionNumber();
                cms_incentives_pca_details.onGradeChanged(grade);
            });

            $('#payPlan').on('change', function (e) {
                var target = e.target;
                var payPlan = target.options[target.options.selectedIndex].value;
                setGradeSelectBoxByPayPlan(payPlan);
                cms_incentives_pca_details.onPayPlanChanged(payPlan);
            });

            $('#typeOfAppointment').on('change', function (e) {
                var target = e.target;
                var typeOfAppointment = target.options[target.options.selectedIndex].value;
                setNotToExceedDate(typeOfAppointment);
            });

            $('#workSchedule').on('change', function (e) {
                var target = e.target;
                var workSchedule = target.options[target.options.selectedIndex].value;
                setHoursPerWeek(workSchedule);
            });

            $('#requireBoardCert').on('change', function (e) {
                var target = e.target;
                var requireBoardCert = target.options[target.options.selectedIndex].value;
                cms_incentives_pca_details.onRequireBoardCertChanged(requireBoardCert);
            });
        }

        function init() {
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_position::init...");
            var item = FormState.getElementSingleValue('associatedIncentives');
            if (item) {
                setGradeSelectBox(item);
                setGradeSelectBoxByPayPlan(FormState.getElementValue('payPlan'), item, true);
            }

            if (MyUserGroupManager.isUserMemberOf(USER_GROUP_KEY.HR_SPECIALISTS)) {
                hyf.util.showComponent('requireAdminApproval_group');
            } else {
                hyf.util.hideComponent('requireAdminApproval_group');
            }

            setPayPlanSelectBox();
            setTypeOfAppointmentSelectBox();
            setNotToExceedDate();
            setWorkScheduleSelectBox();
            setHoursPerWeek();

            setDutyStationAutoCompletion();
            initEventHandlers();

            _initialized = true;
        }

        function render() {
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_position::render...");
        }

        return {
            init: init,
            render: render,
            populateRelatedFields: populateRelatedFields
        }
    };

    var _initializer = window.cms_incentives_position || (window.cms_incentives_position = cms_incentives_position());
})(window);
