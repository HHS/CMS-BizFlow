(function (window) {
    var cms_incentives_position = function () {
        var _readOnly = false;
        var _initialized = false;
        var _dutyStation_ac = null;

        function setDutyStationAutoCompletion() {
            var option = {
                id: 'dutyStation_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchDutyStations.do?l=100&q=',
                minLength: 2,
                minSelectionCount: 1,
                maxSelectionCount: 1,
                readOnly: _readOnly,

                mapFunction: function (context) {
                    return {
                        id: $("LOC_ID", context).text(),
                        state: $("LOC_STATE", context).text(),
                        city: $("LOC_CITY", context).text()
                    };
                },
                getSelectionLabel: function (item) {
                    return item.city + ", " + item.state
                },
                getCandidateLabel: function (item) {
                    return item.city + ", " + item.state
                },
                getItemID: function (item) {
                    return item.id;
                },
                setDataToForm: function (values) {
                    FormState.updateObjectValue('dutyStation', values);
                },
                // initialize
                initialItems: FormState.getElementArrayValue('dutyStation', [])
            };

            _dutyStation_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        function setGradeOptions(grades) {
            var selObj = $('#grade');
            selObj.children('option:not(:first)').remove();
            if (grades) {
                var selectedGrade = "";
                var cnt = 0;
                for (var g = 0; g < grades.length; g++) {
                    var grade = grades[g];
                    if (grade) {
                        cnt++;
                        if (typeof grade === 'number' && grade < 10) {
                            grade = '0' + grade;
                        }
                        selObj.append($("<option></option>").attr("value", grade).text(grade));
                        if (cnt === 1) {
                            selectedGrade = grade;
                        }
                    }
                }

                if (_initialized) {
                    if (cnt > 1) {
                        selectedGrade = "";
                    }
                    FormState.updateSelectValue("grade", selectedGrade, selectedGrade, true);
                    onGradeChanged(selectedGrade);
                }
            }
        }

        function setGradeSelectBoxWithRequestGrade(item) {
            if (item && item.position) {
                setGradeOptions(item.position.grade.slice(0).sort());
            }
        }

        function isValidGrades(grades) {
            for (var g = 0; g < grades.length; g++) {
                if (grades[g]) return true;
            }

            return false;
        }

        function setGradeVisibility(visible) {
            hyf.util.setComponentVisibility('grade_group', visible);
            if (!visible) {
                onGradeChanged("");
            }
            if (_initialized) {
                cms_incentives_sam_details.onGradeHidden(visible);
            }
        }

        function setGradeSelectBoxByPayPlan(payPlan, item) {
            if (payPlan && 'ES, GP, GR, GS, WG'.indexOf(payPlan) !== -1) {
                setGradeVisibility(true);
                item = item || FormState.getElementSingleValue('associatedNEILRequest');
                if (item) {
                    if (!isValidGrades(item.position.grade)) {
                        if ('ES' === payPlan) {
                            setGradeOptions([1, 2, 3, 4, 5, 6]);
                        } else if ('WG' === payPlan) {
                            setGradeOptions([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
                        } else if ('GP, GR, GS'.indexOf(payPlan) !== -1) {
                            setGradeOptions([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]);
                        }
                    }
                }
            } else {
                setGradeVisibility(false);
            }
        }

        function getGradeIndex(item, grade) {
            for (var i = 0; i < item.position.grade.length; i++) {
                if (item.position.grade[i] === grade) {
                    return i;
                }
            }

            return -1;
        }

        function setPositionDescriptionNumber(grade) {
            var descNum = "";
            var item = FormState.getElementSingleValue('associatedNEILRequest');
            if (item) {
                var idx = getGradeIndex(item, grade);
                if (idx > -1) {
                    descNum = item.position.descNum[idx];
                }
            }
            if (_initialized) {
                FormState.updateTextValue("posDescNumber", descNum || "", true);
            }
        }

        function setGradeSelectBox(incentiveType, payPlan, item) {
            if (INCENTIVES_TYPE.SAM === incentiveType && "ES" === payPlan) {
                var grade = "00";
                setGradeOptions([grade]);
                hyf.util.disableComponent("grade");
                if (_initialized) {
                    FormState.updateSelectValue("grade", grade, grade, true);
                    setGradeVisibility(true);
                    onGradeChanged(grade);
                }
            } else {
                setGradeSelectBoxWithRequestGrade(item);
                setGradeSelectBoxByPayPlan(payPlan, item, true);
                hyf.util.enableComponent("grade");
            }
        }

        function populateRelatedFields(item) {
            if (item) {
                item.position = item.position || {title: '', payPlan: {desc: ''}, series: {desc: ''}};
                var payPlan = item.position.payPlan.desc;

                // var series = item.position.series.desc;
                var series = null == item.id ? '' : '0602';  // automatically populate as 0602 by user story 212170
                FormState.updateTextValue("positionTitle", item.position.title, true);
                FormState.updateTextValue("payPlan", payPlan, true);
                FormState.updateTextValue("series", series, true);

                var typeOfAppointment = item.position.typeOfAppointment;
                FormState.updateTextValue("typeOfAppointment", typeOfAppointment, true);
                FormState.updateTextValue("notToExceedDate", item.position.notToExceedDate, true);
                setNotToExceedDate(typeOfAppointment);

                if (item.position.workSchedule) {
                    var workSchedule = item.position.workSchedule.desc;
                    FormState.updateTextValue("workSchedule", workSchedule, true);
                    setHoursPerWeek(workSchedule);
                }
                FormState.updateTextValue("hoursPerWeek", item.position.hoursPerWeek, true);

                var incentiveType = FormState.getElementValue('incentiveType');

                setGradeSelectBox(incentiveType, payPlan, item);
                setPVPayPlanSeriesGrade(payPlan, series, '');

                item.license = item.license || {info: ''};
                FormState.updateTextValue("licenseInfo", item.license.info, true);

                if (null == item.id) {   // clean
                    _dutyStation_ac.deleteAllItems();
                    FormState.updateTextValue("posDescNumber", "", true);
                    FormState.updateTextValue("typeOfAppointment", "", true);
                    FormState.updateSelectValue("requireBoardCert", "", "Select One", true);
                    FormState.updateSelectValue("posHardToFill", "", "Select One", true);
                    FormState.updateTextValue("numOfInterviewed", "", true);
                }
            }
        }

        function setPVPayPlanSeriesGrade(payPlan, series, grade) {
            var value = "";
            if (payPlan && payPlan.length > 0) {
                value = payPlan;
            }
            if (series && series.length > 0) {
                value += '/' + series;
            }
            if (grade && grade.length > 0) {
                value += '/' + grade;
            }
            FormState.updateObjectValue('payPlanSeriesGrade', value);
        }

        function setHoursPerWeek(workSchedule) {
            workSchedule = workSchedule || FormState.getElementValue("workSchedule");
            if ("Full-Time" === workSchedule) {
                if (_initialized) {
                    FormState.updateTextValue("hoursPerWeek", 40, true);
                }
                hyf.util.showComponent('hoursPerWeek_group');
                hyf.util.disableComponent("hoursPerWeek");
            } else if ("Part-Time" === workSchedule) {
                hyf.util.showComponent('hoursPerWeek_group');
                hyf.util.enableComponent("hoursPerWeek");
                if (_initialized) {
                    FormState.updateTextValue("hoursPerWeek", '', true);
                }
            } else {
                hyf.util.hideComponent('hoursPerWeek_group');
            }
        }

        function setPayPlanSelectBox() {
            LookupManager.fillListBox("payPlan", "PayPlan");
        }

        function setNotToExceedDate(typeOfAppointment) {
            typeOfAppointment = typeOfAppointment || FormState.getElementValue("typeOfAppointment");
            if ("" !== typeOfAppointment && "Term, Temporary Promotion, Temporary".indexOf(typeOfAppointment) !== -1) {
                hyf.util.showComponent('notToExceedDate_group');
            } else {
                hyf.util.hideComponent('notToExceedDate_group');
            }
        }

        function setWorkScheduleSelectBox() {
            LookupManager.fillListBox("workSchedule", "WorkSchedule");
        }

        function onIncentiveTypeChanged(incentiveType) {
            hyf.util.setComponentVisibility("PCA_fields_group", "PCA" === incentiveType);
            // hyf.util.setComponentVisibility("SAM_fields_group", "SAM" === incentiveType);

            var item = FormState.getElementSingleValue('associatedNEILRequest');
            var payPlan = FormState.getElementValue('payPlan');
            setGradeSelectBox(incentiveType, payPlan, item);
        }

        function onGradeChanged(grade) {
            setPVPayPlanSeriesGrade(FormState.getElementValue('payPlan', ''), FormState.getElementValue('series', ''), grade);
            setPositionDescriptionNumber(grade);
            if (_initialized) {
                cms_incentives_pca_details.onGradeChanged(grade);
                cms_incentives_sam_details.onGradeChanged(grade);
                cms_incentives_sam_review.onGradeChanged(grade);
            }
        }

        function initEventHandlers() {
            $('#grade').on('change', function (e) {
                var target = e.target;
                var grade = target.options[target.options.selectedIndex].value;
                onGradeChanged(grade);
            });

            $('#payPlan').on('change', function (e) {
                var target = e.target;
                var payPlan = target.options[target.options.selectedIndex].value;
                setGradeSelectBoxByPayPlan(payPlan);
                cms_incentives_pca_details.onPayPlanChanged(payPlan);
            });

            $('#workSchedule').on('change', function (e) {
                var target = e.target;
                var workSchedule = target.options[target.options.selectedIndex].value;
                setHoursPerWeek(workSchedule);
            });

            $('#requireBoardCert').on('change', function (e) {
                var target = e.target;
                var requireBoardCert = target.options[target.options.selectedIndex].value;
                cms_incentives_pca_details.onRequireBoardCertChanged(requireBoardCert);
            });
        }

        function postDisableTab(afterAllTabLoaded, tab) {
            if (afterAllTabLoaded) {
                if (activityStep.isSOReview()) {
                    if (tab.readOnly) {
                        hyf.util.enableComponent("numOfInterviewed");
                    }
                }
            }
        }

        function initComponents() {
            onIncentiveTypeChanged(FormState.getElementValue("incentiveType"));

            if (activityStep.isSOReview()) {
                hyf.util.setMandatoryConstraint("grade", false);
                hyf.util.setMandatoryConstraint("posDescNumber", false);
                hyf.util.setMandatoryConstraint("dutyStation_ac", false);
            }

            setPayPlanSelectBox();
            setNotToExceedDate();
            setWorkScheduleSelectBox();
            setHoursPerWeek();

            setDutyStationAutoCompletion();
        }

        function init(readOnly, tabObject) {
            _readOnly = readOnly;

            initComponents();
            initEventHandlers();
            FormMain.resetMandatoryMark(tabObject);

            _initialized = true;
        }

        function render(action) {
        }

        return {
            init: init,
            render: render,
            populateRelatedFields: populateRelatedFields,
            onIncentiveTypeChange: onIncentiveTypeChanged,
            postDisableTab: postDisableTab
        }
    };

    var _initializer = window.cms_incentives_position || (window.cms_incentives_position = cms_incentives_position());
})(window);
