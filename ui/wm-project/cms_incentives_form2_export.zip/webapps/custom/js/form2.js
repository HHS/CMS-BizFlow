(function (window) {
    var cms_incentives_position = function () {
        var _readOnly = false;
        var _initialized = false;
        var _dutyStation_ac = null;

        function setDutyStationAutoCompletion() {
            var option = {
                id: 'dutyStation_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchDutyStations.do?l=100&q=',
                minLength: 2,
                minSelectionCount: 1,
                maxSelectionCount: 1,
                readOnly: _readOnly,
                // onChangeInputContainerVisibility: function(visible) {
                //     var $mandatoryMark = $("#dutyStation_ac_label > span.mandatory").show();
                //     if ($mandatoryMark.length > 0) {
                //         if (visible) {
                //             $mandatoryMark.show();
                //         } else {
                //             $mandatoryMark.hide();
                //         }
                //     }
                // },
                mapFunction: function (context) {
                    return {
                        id: $("LOC_ID", context).text(),
                        state: $("LOC_STATE", context).text(),
                        city: $("LOC_CITY", context).text()
                    };
                },
                getSelectionLabel: function (item) {
                    return item.city + ", " + item.state
                },
                getCandidateLabel: function (item) {
                    return item.city + ", " + item.state
                },
                getItemID: function (item) {
                    return item.id;
                },
                setDataToForm: function (values) {
                    FormState.updateObjectValue('dutyStation', values);
                },
                // initialize
                initialItems: FormState.getElementArrayValue('dutyStation', [])
            };

            _dutyStation_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        function setGradeOptions(grades) {
            var selObj = $('#grade');
            selObj.children('option:not(:first)').remove();
            if (grades) {
                var selectedGrade = "";
                var cnt = 0;
                for (var g = 0; g < grades.length; g++) {
                    var grade = grades[g];
                    if (grade) {
                        cnt++;
                        if (typeof grade === 'number' && grade < 10) {
                            grade = '0' + grade;
                        }
                        selObj.append($("<option></option>").attr("value", grade).text(grade));
                        if (cnt === 1) {
                            selectedGrade = grade;
                        }
                    }
                }

                if (_initialized) {
                    if (cnt > 1) {
                        selectedGrade = "";
                    }
                    FormState.updateSelectValue("grade", selectedGrade, selectedGrade, true);
                    onGradeChanged(selectedGrade);
                }
            }
        }

        function setGradeSelectBoxWithRequestGrade(item) {
            if (item && item.position) {
                setGradeOptions(item.position.grade.slice(0).sort());
            }
        }

        function isValidGrades(grades) {
            for (var g = 0; g < grades.length; g++) {
                if (grades[g]) return true;
            }

            return false;
        }

        function setGradeVisibility(visible) {
            FormMain.setComponentVisibility('grade_group', visible);
            if (!visible) {
                onGradeChanged("");
            }
            if (_initialized) {
                if(cms_incentives_sam_details) {
                    cms_incentives_sam_details.onGradeHidden(visible);
                }
                if(cms_incentives_sam_review) {
                    cms_incentives_sam_review.onGradeHidden(visible);
                }
            }
        }

        function setGradeSelectBoxByPayPlan(payPlan, item) {
            if ("undefined" == typeof(payPlan)) {
                payPlan = "";
            }
            if (("" != payPlan) && ('ES, GP, GR, GS, WG'.indexOf(payPlan) !== -1)) {
                setGradeVisibility(true);
                item = item || FormState.getElementSingleValue('associatedNEILRequest');
                if (item) {
                    if (!isValidGrades(item.position.grade)) {
                        if ('ES' === payPlan) {
                            setGradeOptions([1, 2, 3, 4, 5, 6]);
                        } else if ('WG' === payPlan) {
                            setGradeOptions([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
                        } else if ('GP, GR, GS'.indexOf(payPlan) !== -1) {
                            setGradeOptions([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]);
                        }
                    }
                }
            } else {
                setGradeVisibility(false);
            }
        }

        function getGradeIndex(item, grade) {
            for (var i = 0; i < item.position.grade.length; i++) {
                if (item.position.grade[i] === grade) {
                    return i;
                }
            }

            return -1;
        }

        function setPositionDescriptionNumber(grade) {
            var descNum = "";
            var item = FormState.getElementSingleValue('associatedNEILRequest');
            if (item) {
                var idx = getGradeIndex(item, grade);
                if (idx > -1) {
                    descNum = item.position.descNum[idx];
                }
            }
            if (_initialized) {
                FormState.updateTextValue("posDescNumber", descNum || "", true);
            }
        }

        function setGradeSelectBox(incentiveType, payPlan, item) {
            if (INCENTIVES_TYPE.SAM === incentiveType && "ES" === payPlan) {
                // var grade = "00";
                var grade = "";
                setGradeOptions([grade]);
                FormMain.setComponentUsability("grade", false);
                if (_initialized) {
                    FormState.updateSelectValue("grade", grade, grade, true);
                    setGradeVisibility(true);
                    onGradeChanged(grade);
                }
            } else {
                setGradeSelectBoxWithRequestGrade(item);
                setGradeSelectBoxByPayPlan(payPlan, item, true);
                if(!_readOnly) {
                    FormMain.setComponentUsability("grade", true);
                } else {
                    FormMain.setComponentUsability("grade", false);
                }
            }
            if (INCENTIVES_TYPE.LE === incentiveType || INCENTIVES_TYPE.SAM === incentiveType) {
                FormMain.setComponentUsability("payPlan", false);
                hyf.util.setMandatoryConstraint("payPlan", false);
                if ("ES" === payPlan) {
                    var grade = "";
                    FormState.updateSelectValue("grade", grade, grade, true);
                    setGradeVisibility(false);
                }
            }
        }

        function populateRelatedFields(item) {
            if (item) {
                item.position = item.position || {title: '', payPlan: {desc: ''}, series: {desc: ''}};
                var payPlan = item.position.payPlan.desc;

                // var series = item.position.series.desc;
                var series = null == item.id ? '' : '0602';  // automatically populate as 0602 by user story 212170

                FormState.updateTextValue("positionTitle", item.position.title, true);
                FormState.updateTextValue("payPlan", payPlan, true);
                FormState.updateTextValue("series", series, true);

                var incentiveType = FormState.getElementValue('incentiveType');
                if (incentiveType == "PDP") {
                    FormState.updateTextValue("series", "0680", true);
                }

                if(cms_incentives_sam_details) {
                    cms_incentives_sam_details.onPayPlanChanged(payPlan);
                }

                var typeOfAppointment = item.position.typeOfAppointment;
                FormState.updateTextValue("typeOfAppointment", typeOfAppointment, true);
                FormState.updateTextValue("notToExceedDate", item.position.notToExceedDate, true);
                setNotToExceedDate(typeOfAppointment);

                if (item.position.workSchedule) {
                    var workSchedule = item.position.workSchedule.desc;
                    FormState.updateTextValue("workSchedule", workSchedule, true);
                    setHoursPerWeek(workSchedule);
                }
                FormState.updateTextValue("hoursPerWeek", item.position.hoursPerWeek, true);

                setGradeSelectBox(incentiveType, payPlan, item);
                setPVPayPlanSeriesGrade(payPlan, series, FormState.getElementValue('grade', ''));

                item.license = item.license || {info: ''};
                FormState.updateTextValue("licenseInfo", item.license.info, true);

                if (null == item.id) {   // clean
                    _dutyStation_ac.deleteAllItems();
                    FormState.updateTextValue("posDescNumber", "", true);
                    FormState.updateTextValue("typeOfAppointment", "", true);
                    FormState.updateSelectValue("requireBoardCert", "", "Select One", true);
                    FormState.updateSelectValue("posHardToFill", "", "Select One", true);
                    FormState.updateTextValue("numOfInterviewed", "", true);
                }
                onChangeAssociateRequest(incentiveType, FormState.getElementValue("associatedRequest"));
            }
        }

        function setPVPayPlanSeriesGrade(payPlan, series, grade) {
            var value = "";
            if (payPlan && payPlan.length > 0) {
                value = payPlan;
            }
            if (series && series.length > 0) {
                value += '/' + series;
            }
            if (grade && grade.length > 0) {
                value += '/' + grade;
            }
            FormState.updateObjectValue('payPlanSeriesGrade', value);
        }

        function setHoursPerWeek(workSchedule) {
            workSchedule = workSchedule || FormState.getElementValue("workSchedule");
            if ("Full-Time" === workSchedule) {
                if (_initialized) {
                    FormState.updateTextValue("hoursPerWeek", 40, true);
                }
                hyf.util.showComponent('hoursPerWeek_group');
                hyf.util.disableComponent("hoursPerWeek");
            } else if ("Part-Time" === workSchedule) {
                hyf.util.showComponent('hoursPerWeek_group');
                hyf.util.enableComponent("hoursPerWeek");
                hyf.util.setMandatoryConstraint("hoursPerWeek", true);
                   
                if (_initialized) {
                    FormState.updateTextValue("hoursPerWeek", '', true);
                }
            } else {
                hyf.util.hideComponent('hoursPerWeek_group');
            }
        }

        function setPayPlanSelectBox() {
            LookupManager.fillListBox("payPlan", "PayPlan");
        }

        function setNotToExceedDate(typeOfAppointment) {
            typeOfAppointment = typeOfAppointment || FormState.getElementValue("typeOfAppointment");
            if ("" !== typeOfAppointment && "Term, Temporary Promotion, Temporary".indexOf(typeOfAppointment) !== -1) {
                hyf.util.showComponent('notToExceedDate_group');
            } else {
                hyf.util.hideComponent('notToExceedDate_group');
            }
        }

        function setWorkScheduleSelectBox() {
            LookupManager.fillListBox("workSchedule", "WorkSchedule");
        }

        function onIncentiveTypeChanged(incentiveType) {
            FormMain.setComponentVisibility("PCA_fields_group", (("PCA" === incentiveType) || ("PDP" === incentiveType)));
            // FormMain.setComponentVisibility("SAM_fields_group", "SAM" === incentiveType);

            var item = FormState.getElementSingleValue('associatedNEILRequest');
            var payPlan = FormState.getElementValue('payPlan');
            setGradeSelectBox(incentiveType, payPlan, item);
            if (incentiveType == INCENTIVES_TYPE.SAM || incentiveType == INCENTIVES_TYPE.LE ) {
                FormMain.setComponentVisibility("typeOfAppointmentSelect_group", false);
                FormMain.setComponentVisibility("typeOfAppointment_group", true);
            }
            onChangeAssociateRequest(incentiveType, FormState.getElementValue("associatedRequest"));
        }

        function onGradeChanged(grade) {
            setPVPayPlanSeriesGrade(FormState.getElementValue('payPlan', ''), FormState.getElementValue('series', ''), grade);
            setPositionDescriptionNumber(grade);
            if (_initialized) {
                if (cms_incentives_pca_details) {
                    cms_incentives_pca_details.onGradeChanged(grade);
                }
                if (cms_incentives_sam_details) {
                    cms_incentives_sam_details.onGradeChanged(grade);
                }
                if(cms_incentives_sam_review) {
                    cms_incentives_sam_review.onGradeChanged(grade);
                }
            }
        }

        function initEventHandlers() {
            $('#grade').on('change', function (e) {
                var target = e.target;
                var grade = target.options[target.options.selectedIndex].value;
                onGradeChanged(grade);
            });

            $('#payPlan').on('change', function (e) {
                var target = e.target;
                var payPlan = target.options[target.options.selectedIndex].value;

                var incentiveType = FormState.getElementValue("incentiveType");
                var associatedRequest = FormState.getElementValue("associatedRequest");
                var item = FormState.getElementSingleValue('associatedNEILRequest');

                if (incentiveType == "PCA") {
                    setGradeSelectBoxWithRequestGrade(item);
                    setGradeSelectBoxByPayPlan(payPlan);
                    if(associatedRequest == "No") {
                        if("ES" == payPlan) {
                            FormMain.setComponentVisibility('grade_group', false);
                        } else if ('GP, GR, GS'.indexOf(payPlan) !== -1) {
                            setGradeOptions([11, 12, 13, 14, 15]);
                        }
                        FormState.updateSelectValue("grade", "", "Select One", true);
                    }
                } else if(incentiveType == "PDP") {
                    
                    if(associatedRequest == "No") {
                        setGradeSelectBoxWithRequestGrade(item);
                        setGradeSelectBoxByPayPlan(payPlan);

                        
                        FormState.updateSelectValue("grade", "", "Select One", true);
                        setGradeOptions([13, 14, 15]);                        
                        FormMain.setComponentVisibility('grade_group', true);
                        FormMain.setComponentUsability('grade', true);
                    }
                    if("ES" == payPlan) {
                        //FormState.updateSelectValue("grade", "", "", true);
                        setGradeOptions(['00']);
                        //$('#grade option:selected').val('00').text('00');
                    }
                }

                if(cms_incentives_pca_details) {
                    cms_incentives_pca_details.onPayPlanChanged(payPlan);
                }
                if(_initialized) {
                    if(cms_incentives_sam_details) {
                        cms_incentives_sam_details.onPayPlanChanged(payPlan);
                    }
                }
            });

            $('#workSchedule').on('change', function (e) {
                var target = e.target;
                var workSchedule = target.options[target.options.selectedIndex].value;
                setHoursPerWeek(workSchedule);
            });

            $('#requireBoardCert').on('change', function (e) {
                var target = e.target;
                var requireBoardCert = target.options[target.options.selectedIndex].value;
                if(cms_incentives_pca_details) {
                    cms_incentives_pca_details.onRequireBoardCertChanged(requireBoardCert);
                }
            });
        }

        function onChangeAssociateRequest(incentiveType, hasRequestId) {
            if ((incentiveType == "PDP") || (incentiveType == "PCA")) {
                if (hasRequestId == "No") {
                    if (incentiveType == "PDP") {
                        hyf.util.setMandatoryConstraint("workSchedule", true);
                        FormState.updateTextValue("series", "0680", true);
                    }

                    hyf.util.setMandatoryConstraint("typeOfAppointmentSelect", true);
                    FormMain.setComponentVisibility("typeOfAppointmentSelect_group", true);
                    FormMain.setComponentVisibility("typeOfAppointment_group", false);
                    FormState.updateSelectValue("typeOfAppointmentSelect", "", "Select One", true);

                    FormState.updateTextValue("positionTitle", "", true);
                    hyf.util.setMandatoryConstraint("positionTitle", true);
                    FormMain.setComponentUsability("positionTitle", true);

                    FormState.updateSelectValue("payPlan", "", "Select One", true);
                    FormMain.setComponentUsability("payPlan", true);
                    hyf.util.setMandatoryConstraint("payPlan", true);

                    FormState.updateTextValue("licenseInfo", "", true);
                    FormMain.setComponentUsability("licenseInfo", true);

                    if (incentiveType == "PCA") {
                        var payPlan = FormState.getElementValue('payPlan');
                        setGradeSelectBoxByPayPlan(payPlan);
                        if("ES" == payPlan) {
                            FormMain.setComponentVisibility('grade_group', false);
                        } else if ('GP, GR, GS'.indexOf(payPlan) !== -1) {
                            setGradeOptions([11, 12, 13, 14, 15]);
                        }
                        FormState.updateSelectValue("grade", "", "Select One", true);
                    } else if (incentiveType == "PDP") {
                        setGradeSelectBoxWithRequestGrade(item);
                        setGradeSelectBoxByPayPlan(payPlan);
                        setGradeOptions([13, 14, 15]);
                        FormMain.setComponentVisibility('grade_group', true);
                        FormMain.setComponentUsability('grade', true);
                    }

                } else if (hasRequestId == "Yes") {
                    if (incentiveType == "PDP") {
                        hyf.util.setMandatoryConstraint("workSchedule", false);
                    }
                    hyf.util.setMandatoryConstraint("typeOfAppointmentSelect", false);
                    FormMain.setComponentVisibility("typeOfAppointmentSelect_group", false);
                    FormMain.setComponentVisibility("typeOfAppointment_group", true);
                    var item = FormState.getElementSingleValue('associatedNEILRequest');
                    if (item) {
                        item.position = item.position || {title: '', payPlan: {desc: ''}, series: {desc: ''}};
                        FormState.updateTextValue("positionTitle", item.position.title, false);
                        FormState.updateTextValue("typeOfAppointment", item.position.typeOfAppointment, true);
                        FormState.updateTextValue("licenseInfo", item.position.licenseInfo, true);
                        if (incentiveType == "PCA") {
                            var payPlan = FormState.getElementValue('payPlan');
                            setGradeSelectBoxWithRequestGrade(item);
                            setGradeSelectBoxByPayPlan(payPlan);
                        }
                    } else {
                        FormState.updateTextValue("positionTitle", "", true);
                        FormState.updateTextValue("typeOfAppointment", "", true);
                        FormState.updateTextValue("licenseInfo", "", true);
                        if (incentiveType == "PCA") {
                            var payPlan = FormState.getElementValue('payPlan');
                            setGradeSelectBoxByPayPlan(payPlan);
                            FormState.updateSelectValue("grade", "", "Select One", true);
                        }
                    }
                    hyf.util.setMandatoryConstraint("positionTitle", false);
                    FormMain.setComponentUsability("positionTitle", false);

                    //FormState.updateSelectValue("payPlan", "", "Select One", true);
                    FormMain.setComponentUsability("payPlan", false);
                    hyf.util.setMandatoryConstraint("payPlan", false);

                    FormMain.setComponentUsability("licenseInfo", false);
                }
            } else {
                hyf.util.setMandatoryConstraint("typeOfAppointmentSelect", false);
                FormMain.setComponentVisibility("typeOfAppointmentSelect_group", false);
                FormMain.setComponentVisibility("typeOfAppointment_group", true);
                var item = FormState.getElementSingleValue('associatedNEILRequest');
                if (item) {
                    item.position = item.position || {title: '', payPlan: {desc: ''}, series: {desc: ''}};
                    FormState.updateTextValue("positionTitle", item.position.title, false);
                    FormState.updateTextValue("typeOfAppointment", item.position.typeOfAppointment, true);
                    FormState.updateTextValue("licenseInfo", item.position.licenseInfo, false);
                }
                hyf.util.setMandatoryConstraint("positionTitle", false);
                FormMain.setComponentUsability("positionTitle", false);

                FormMain.setComponentUsability("payPlan", false);
                hyf.util.setMandatoryConstraint("payPlan", false);

                FormMain.setComponentUsability("licenseInfo", false);
            }
        }

        function initPdpValues(hasRequestId) {
            if (hasRequestId == "No") {
                hyf.util.setMandatoryConstraint("positionTitle", true);
                FormMain.setComponentUsability("positionTitle", true);

                hyf.util.setMandatoryConstraint("payPlan", true);
                FormMain.setComponentUsability("payPlan", true);  
                
                FormMain.setComponentVisibility('grade_group', true);
                FormMain.setComponentUsability('grade', true);

                hyf.util.setMandatoryConstraint("typeOfAppointmentSelect", true);
                FormMain.setComponentVisibility("typeOfAppointmentSelect_group", true);
                FormMain.setComponentVisibility("typeOfAppointment_group", false);

                hyf.util.setMandatoryConstraint("workSchedule", true);

                hyf.util.setMandatoryConstraint("licenseInfo", true);
                FormMain.setComponentUsability("licenseInfo", true);

            } else {
                hyf.util.setMandatoryConstraint("positionTitle", false);
                FormMain.setComponentUsability("positionTitle", false);

                FormMain.setComponentUsability("payPlan", false);
                hyf.util.setMandatoryConstraint("payPlan", false);

                hyf.util.setMandatoryConstraint("typeOfAppointmentSelect", false);
                FormMain.setComponentVisibility("typeOfAppointmentSelect_group", false);
                FormMain.setComponentVisibility("typeOfAppointment_group", true);

                hyf.util.setMandatoryConstraint("workSchedule", false);

                hyf.util.setMandatoryConstraint("licenseInfo", false);
                FormMain.setComponentUsability("licenseInfo", false);

                var item = FormState.getElementSingleValue('associatedNEILRequest');
                var payPlan = FormState.getElementValue('payPlan');
                setGradeSelectBox(incentiveType, payPlan, item);

            }
                            
            setGradeOptions([13, 14, 15]);
            if (FormState.getElementValue("payPlan") == "ES") {                       
                setGradeOptions(['00']);
            }
            
            //setGradeSelectBoxByPayPlan(payPlan);
        }

        function postDisableTab(afterAllTabLoaded, tab) {
            if (afterAllTabLoaded) {
                if (activityStep.isSOReview()) {
                    if (tab.readOnly) {
                        hyf.util.enableComponent("numOfInterviewed");
                    }
                }
            }
        }
        function initComponents() {
            var isPdpInitState = false;
            if (FormState.getElementValue("incentiveType") == "PDP") {
                isPdpInitState = true;
                initPdpValues(FormState.getElementValue("associatedRequest"));
            }     
            if (!isPdpInitState) {
                onIncentiveTypeChanged(FormState.getElementValue("incentiveType"));
            }     

            if (activityStep.isSOReview()) {
                hyf.util.setMandatoryConstraint("grade", false);
                hyf.util.setMandatoryConstraint("posDescNumber", false);
                hyf.util.setMandatoryConstraint("dutyStation_ac", false);
            }


            setPayPlanSelectBox();
            setNotToExceedDate();
            setWorkScheduleSelectBox();
            setHoursPerWeek();

            setDutyStationAutoCompletion();
        }

        function init(readOnly, tabObject) {
            _readOnly = readOnly;
            if(tabObject && tabObject.readOnly) {
                _readOnly = true;
            }

            initComponents();
            initEventHandlers();
            FormMain.resetMandatoryMark(tabObject);

            _initialized = true;
        }

        function render(action) {
        }

        return {
            init: init,
            render: render,
            populateRelatedFields: populateRelatedFields,
            onIncentiveTypeChange: onIncentiveTypeChanged,
            onChangeAssociateRequest: onChangeAssociateRequest,
            postDisableTab: postDisableTab
        }
    };

    var _initializer = window.cms_incentives_position || (window.cms_incentives_position = cms_incentives_position());
})(window);
