(function (window) {
    var cms_incentives_position = function () {
        var _dutyStation_ac = null;

        function setDutyStationAutoCompletion() {
            var option = {
                id: 'dutyStation_ac',
                baseURL: '/bizflowwebmaker/cms_incentives_main',
                targetURL: '/bizflowwebmaker/cms_incentives_service/searchDutyStations.do?q=',
                minLength: 2,
                minSelectionCount: 1,
                maxSelectionCount: 1,

                mapFunction: function (context) {
                    return {
                        id: $("LOC_ID", context).text(),
                        state: $("LOC_STATE", context).text(),
                        city: $("LOC_CITY", context).text()
                    };
                },
                getSelectionLabel: function (item) {
                    return item.city + ", " + item.state
                },
                getCandidateLabel: function (item) {
                    return item.city + ", " + item.state
                },
                getItemID: function (item) {
                    return item.id;
                },
                setDataToForm: function (values) {
                    FormState.updateObjectValue('dutyStation', values);
                },
                // initialize
                initialItems: FormState.getElementArrayValue('dutyStation', [])
            };

            _dutyStation_ac = FormAutoComplete.makeAutoCompletion(option);
        }

        function setGradeDropBox(item) {
            $('#grade').children('option:not(:first)').remove();
            for (var g = 0; g < item.position.grade.length; g++) {
                var value = item.position.grade[g];
                if (value) {
                    $('#grade').append($("<option></option>").attr("value", value).text(value));
                }
            }
        }

        function populateRelatedFields(item) {
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_position::populateRelatedFields - item ==> ", item);
            if (item) {
                item.position = item.position || {title: '', payPlan: {desc: ''}, series: {desc: ''}};

                FormState.updateTextValue("positionTitle", item.position.title, true);
                FormState.updateTextValue("payPlan", item.position.payPlan.desc, true);
                FormState.updateTextValue("series", item.position.series.desc, true);

                setGradeDropBox(item);
                setPVPayPlanSeriesGrade(item.position.payPlan.desc, item.position.series, '');

                item.license = item.license || {info: ''};
                FormState.updateTextValue("licenseInfo", item.license.info, true);
            }
        }

        function setPVPayPlanSeriesGrade(payPlan, series, grade) {
            var value = payPlan + '/' + series;
            if (grade && grade.length > 0) {
                value += '/' + grade;
            }
            FormState.updateObjectValue('payPlanSeriesGrade', value);
        }

        function initElements() {
            $('#grade').on('change', function (e) {
                var target = e.target;
                var grade = target.options[target.options.selectedIndex].value;
                setPVPayPlanSeriesGrade(FormState.getElementValue('payPlan', ''), FormState.getElementValue('series', ''), grade);
            });
        }

        function init() {
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_position::init...");

            var item = FormState.getElementSingleValue('associatedIncentives');
            if (item) {
                setGradeDropBox(item);
            }

            setDutyStationAutoCompletion();
            initElements();
        }

        function render() {
            FormLog.log(FormLog.LOG_LEVEL.DEBUG, "cms_incentives_position::render...");
        }

        return {
            init: init,
            render: render,
            populateRelatedFields: populateRelatedFields
        }
    };

    var _initializer = window.cms_incentives_position || (window.cms_incentives_position = cms_incentives_position());
})(window);
