/**
 * onload event handler for AOC tab page
 */

function initAocTab(){
	$(document).on("CMS_ALL_TAB_LOADED", function() {
		setMeetingDate($("#SSH_MEETING_SCHED_DT").val());

		// add event handler for date change in Meeting tab
		$("#SSH_MEETING_SCHED_DT").on("change", function(){
			setMeetingDate($(this).val());
		});

		// add event handler for each checkbox to inspect sibling checkboxes whenever clicked
		$("#SG_RT_ID").on("change", function() {
			showHideApptRecrSection($(this).children("option").filter(":selected").text());
		});
		showHideApptRecrSection($('#SG_RT_ID option:selected').text());
	});
	//-------------------------------------------------------------------------


	setMeetingDate($("#SSH_MEETING_SCHED_DT").val());

	//-------------------------------------------------------------------------
	// Add event handler for date change in Meeting tab.
	// If the date is past or current, display it in this tab.
	//-------------------------------------------------------------------------
	$("#SSH_MEETING_SCHED_DT").on("change", function(){
		setMeetingDate($(this).val());
	});

	//-------------------------------------------------------------------------
	// Add event handler for Request Type in General tab.
	// Show/hide Announcement Required/Not Required depending on Request Type
	//-------------------------------------------------------------------------
	$("#SG_RT_ID").on("change", function() {
		showHideApptRecrSection($(this).children("option").filter(":selected").text());
	});

	//-------------------------------------------------------------------------
	// show AOC_NON_COMP_APPL field (under noncompetitive_group) only when at least one checkbox
	// under announce_not_req_grid_group is checked
	//-------------------------------------------------------------------------
	// add event handler for each checkbox to inspect sibling checkboxes whenever clicked
	$("#announce_not_req_grid_group input[type=checkbox]").on("change", function() {
		if ($("#announce_not_req_grid_group").filter(function(){ return $(this).find("input[type=checkbox]:checked").length > 0; }).length > 0 ) {
			$("#noncompetitive_group").show();
		} else {
			$("#noncompetitive_group").hide();
		}
	});

	//Chrome works on maxlength property for textarea.  If IE or FF doesn't work with it, we need implement event handler for it.
	var maxNonBargLength = 500;
	$("#AOC_NON_BARGAIN_DOC_RATIONALE").on("keypress change", function(){
		var nonBargInput = $(this).val();
		var nonBargLength = nonBargInput.length;
		if (nonBargLength > maxNonBargLength) {
			$(this).val(nonBargInput.substring(0, maxNonBargLength - 1));
		}
	});

	//------------------------------------------
	// trigger events for initial processing
	//------------------------------------------
	//WARNING: Calling trigger on SSH_MEETING_SCHED_DT has side effect of firing validation popup unexpectedly.
	// Get and set the value manually, instead.
	//$("#SSH_MEETING_SCHED_DT").trigger("change");

	//$("#SG_RT_ID").trigger("change");
	showHideApptRecrSection($('#SG_RT_ID option:selected').text());
	$("#announce_not_req_grid_group input[type=checkbox]").trigger("change");

} // end initAocTab()


/**
 * Sets the Scheduled Meeting Date.
 *
 * @param mtgDtVal - string representation of the meeting date in MM/dd/yyyy format
 */
function setMeetingDate(mtgDtVal){
	//debug
	//console.log("setMeetingDate(): mtgDtVal = " + mtgDtVal);

	// If changed meeting date is past or current, display.  Otherwise, clear it.
	if (typeof mtgDtVal != "undefined" && mtgDtVal != null && mtgDtVal.length == 10) {
		var mtgDtCmpChg = new Date(parseInt(mtgDtVal.substring(6,10)), (parseInt(mtgDtVal.substring(0,2)) - 1), parseInt(mtgDtVal.substring(3,5)));
		var curDtChg = new Date();
		var curDtCmpChg = new Date(curDtChg.getFullYear(), curDtChg.getMonth(), curDtChg.getDate());
		if (mtgDtCmpChg <= curDtCmpChg) {
			$("#RO_SC_MEETING_SCHED_DT").text(mtgDtVal);
		} else {
			$("#RO_SC_MEETING_SCHED_DT").text("");
		}
	} else {
		$("#RO_SC_MEETING_SCHED_DT").text("");
	}
}


/**
 * Shows or hides Announcement Required/Not Required sections depending on Request Type value selected.
 *
 * @param reqTypeVal - Request Type value that is selected.
 */
function showHideApptRecrSection(reqTypeVal){
	if (typeof reqTypeVal != "undefined" && reqTypeVal != null && reqTypeVal == "Appointment") {
		// For Appointment, show Announcement Not Required section
		$("#reqtype_appointment_group").show();
		$("#reqtyp_recruitment_group").hide();
	} else if (typeof reqTypeVal != "undefined" && reqTypeVal != null && reqTypeVal == "Recruitment") {
		// For Recruitment, show Announcement Required section
		$("#reqtype_appointment_group").hide();
		$("#reqtyp_recruitment_group").show();
	} else {
		$("#reqtype_appointment_group").hide();
		$("#reqtyp_recruitment_group").hide();
	}
}
