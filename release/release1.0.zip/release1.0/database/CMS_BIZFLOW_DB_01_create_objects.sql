
/**
 * Gets the participant names for a active work item of a process instance.
 *
 * @param I_PROCID - Process ID
 *
 * @return Names of participants concatenated by comma.
 */
CREATE OR REPLACE FUNCTION HHS_FN_GETCURPRTCPTNAMES
(
	I_PROCID IN NUMBER
) 
RETURN VARCHAR2
IS
	L_COUNT NUMBER(10);
	L_NAME VARCHAR2(100);
	L_VALUE VARCHAR2(2000);

	CURSOR CUR_GET_ALL_PRTCP IS
		SELECT W.PRTCPNAME
		FROM WITEM W
			INNER JOIN ACT A ON A.PROCID = W.PROCID AND A.ACTSEQ = W.ACTSEQ
		WHERE W.PROCID = I_PROCID AND W.STATE IN ('I', 'R', 'P', 'V')
		ORDER BY A.ACTSEQ;

BEGIN

	L_COUNT := 0;
	L_VALUE := ' ';

	OPEN CUR_GET_ALL_PRTCP;
	
	LOOP
		FETCH CUR_GET_ALL_PRTCP INTO L_NAME;
		EXIT WHEN CUR_GET_ALL_PRTCP%NOTFOUND;

		IF (L_COUNT = 0) THEN
			L_VALUE := L_NAME;
		ELSE
			L_VALUE := L_VALUE || ',' || L_NAME;
		END IF;
		L_COUNT := L_COUNT + 1;
	END LOOP;

	CLOSE CUR_GET_ALL_PRTCP;
  
	RETURN L_VALUE;
END;

/




/**
 * Gets the activity names for an active process instance.
 *
 * @param I_PROCID - Process ID
 *
 * @return Names of activities concatenated by comma.
 */
CREATE OR REPLACE FUNCTION HHS_FN_GETCURACTNAMES
(
	I_PROCID NUMBER
)
RETURN VARCHAR2
IS
	L_COUNT NUMBER(10);
	L_NAME VARCHAR2(100);
	L_VALUE VARCHAR2(2000);
	
	CURSOR CUR_GET_ALL_ACT IS
		SELECT NAME FROM ACT
		WHERE PROCID = I_PROCID AND STATE IN ('R', 'V')
		ORDER BY ACTSEQ;
BEGIN
	L_VALUE := ' ';
	L_COUNT := 0;
	OPEN CUR_GET_ALL_ACT;
	
	LOOP
		FETCH CUR_GET_ALL_ACT INTO L_NAME;
		EXIT WHEN CUR_GET_ALL_ACT%NOTFOUND;

		IF (L_COUNT = 0) THEN
			L_VALUE := L_NAME;
		ELSE
			L_VALUE := L_VALUE || ',' || L_NAME;
		END IF;
		L_COUNT := L_COUNT + 1;  
	END LOOP;
  
	CLOSE CUR_GET_ALL_ACT;
  
	RETURN L_VALUE;
END;

/

