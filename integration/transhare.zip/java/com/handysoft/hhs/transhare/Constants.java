package com.handysoft.hhs.transhare;


public class Constants
{
  public static final String FORM_DATE_FORMAT = "MM/dd/yyyy HH:mm:ss";
  
  public static final String FORM_DECIMAL_FORMAT = "###,###,##0.00";
  
  public static final String LOTSPACE_SEPERATOR = "-";
  
  public static final String PERMIT_CODE_HANDICAPPED = "HC";
  
  public static final String PERMIT_CODE_VANPOOL = "VP";
  
  public static final String PERMIT_CODE_CARPOOL = "A";
  
  public static final String PERMIT_CODE_CARPOOL2 = "A4";
  
  public static final String PERMIT_CODE_CARPOOL3 = "A3";
  
  public static final String PERMIT_CODE_CARPOOL4 = "A2";
  
  public static final String PERMIT_CODE_EXECUTIVE = "A1";
  
  public static final String PERMIT_CODE_SINGLE = "A5";
  
  public static final String PERMIT_CODE_MOTORCYCLE = "M";
  
  public static final String PERMIT_CODE_HYBRID = "HY";
  public static final String PERMIT_CODE_ALL = "AA";
  public static final String PERMIT_CODE_HANDICAPPED_STR = "Handicapped";
  public static final String PERMIT_CODE_VANPOOL_STR = "Vanpool";
  public static final String PERMIT_CODE_CARPOOL_STR = "Carpool";
  public static final String PERMIT_CODE_EXECUTIVE_STR = "Executive";
  public static final String PERMIT_CODE_SINGLE_STR = "Single";
  public static final String PERMIT_CODE_MOTORCYCLE_STR = "Motorcycle";
  public static final String PERMIT_CODE_HYBRID_STR = "Hybrid Vehicle";
  public static final String CONTROL_ACTION_REJECT = "reject";
  public static final String CONTROL_ACTION_ACCEPT = "accept";
  public static final String CONTROL_ACTION_SUBMIT = "submit";
  public static final String CONTROL_ACTION_CANCEL = "cancel";
  public static final String CONTROL_ACTION_SAVE = "save";
  public static final String CONTROL_ACTION_PERMIT = "permit";
  public static final String STATUS_REJECT = "reject";
  public static final String STATUS_ACCEPT = "accept";
  public static final String STATUS_SUBMIT = "submit";
  public static final String STATUS_CANCEL = "cancel";
  public static final String STATUS_PERMIT = "permit";
  public static final String STATUS_OUTDATED = "outdated";
  public static final String STATUS_SUPERVISOR_ACCEPT = "Supervisor Accept";
  public static final String STATUS_COORDINATOR_ACCEPT = "Coordinator Accept";
  public static final String STATUS_TRANSHARE_COORDINATOR_ACCEPT = "Transhare Coordinator Accept";
  public static final String STATUS_PREPARE_MEDIA_ACCEPT = "Prepare Media Accept";
  public static final String STATUS_SUPERVISOR_REJECT = "Supervisor Reject";
  public static final String STATUS_COORDINATOR_REJECT = "Coordinator Reject";
  public static final String STATUS_TRANSHARE_COORDINATOR_REJECT = "Transhare Coordinator Reject";
  public static final String STATUS_PREPARE_MEDIA_REJECT = "Prepare Media Reject";
  public static final String STATUS_SUPERVISOR_UPDATE = "Supervisor Update";
  public static final String VIEWER_APPLICANT = "applicant";
  public static final String VIEWER_CARPOOLER = "carpooler";
  public static final String VIEWER_REVIEWER = "reviewer";
  public static final String VIEWER_PIOSTAFF = "piostaff";
  public static final int VID_APPLICANT = 0;
  public static final int VID_SUPERVISOR = 1;
  public static final int VID_COORDINATOR = 2;
  public static final int VID_TRANSHARE_COORDINATOR = 3;
  public static final int VID_PREPARE_MEDIA = 4;
  public static final String PURPOSE_NEW = "N";
  public static final String PURPOSE_UPDATE = "U";
  public static final String PURPOSE_RECERTIFICATION = "R";
  public static final String WORK_DAY_SCHEDULE_EIGHT = "E";
  public static final String WORK_DAY_SCHEDULE_NINE = "N";
  public static final String WORK_DAY_SCHEDULE_TEN = "T";
  public static final String WORK_DAY_SCHEDULE_ANY = "A";
  public static final int MASS_TRANSIT_OTHER_ID = 11;
  public static final int MASS_TRANSIT_VANPOOL_ID = 9;
  public static final String HEADQUARTER = "HQ";
  public static final int NOTIFY_ENROLLEE = 1;
  public static final int NOTIFY_SUPERVISOR = 2;
  public static final int NOTIFY_COORDINATOR = 4;
  
  public static String getPermitCodeStr(String code)
  {
    if ("HC".equals(code))
    {
      return "Handicapped";
    }
    if ("A".equals(code))
    {
      return "Carpool";
    }
    if ("A4".equals(code))
    {
      return "Carpool";
    }
    if ("A3".equals(code))
    {
      return "Carpool";
    }
    if ("A2".equals(code))
    {
      return "Carpool";
    }
    if ("VP".equals(code))
    {
      return "Vanpool";
    }
    if ("A1".equals(code))
    {
      return "Executive";
    }
    if ("A5".equals(code))
    {
      return "Single";
    }
    if ("M".equals(code))
    {
      return "Motorcycle";
    }
    if ("HY".equals(code))
    {
      return "Hybrid Vehicle";
    }
    

    return code;
  }
}
