package com.handysoft.hhs.transhare.services;

import com.handysoft.hhs.transhare.Constants;
import com.handysoft.hhs.transhare.TranshareProperties;
import com.handysoft.hhs.transhare.dao.CommonDAO;
import com.handysoft.hhs.transhare.dao.ParkingApplicationDAO;
import com.handysoft.hhs.transhare.dao.ParkingAssignDAO;
import com.handysoft.hhs.transhare.model.EligibilityCheck;
import com.handysoft.hhs.transhare.model.ParkingAppCarpool;
import com.handysoft.hhs.transhare.model.ParkingAppStatus;
import com.handysoft.hhs.transhare.model.ParkingApplication;
import com.handysoft.hhs.transhare.model.ParkingAssign;
import com.handysoft.hhs.transhare.model.ParkingAssignItem;
import com.hs.bf.wf.jo.HWProcessVariable;
import com.hs.bf.wf.jo.HWProcessVariableImpl;
import com.hs.bf.wf.jo.HWProcessVariables;
import java.util.HashMap;
import java.util.List;
import org.apache.commons.logging.Log;

public class ParkingManager
{
  Log log = null;
  
  private ParkingApplicationDAO parkingApplicationDAO = null;
  private ParkingAssignDAO parkingAssignDAO = null;
  private CommonDAO commonDAO = null;
  private BizFlowManager bizFlowManager = null;
  
  public ParkingManager()
  {
    this.log = org.apache.commons.logging.LogFactory.getLog(ParkingManager.class);
  }
  
  public ParkingApplicationDAO getParkingApplicationDAO() {
    return this.parkingApplicationDAO;
  }
  
  public void setParkingApplicationDAO(ParkingApplicationDAO parkingApplicationDAO) {
    this.parkingApplicationDAO = parkingApplicationDAO;
  }
  
  public ParkingAssignDAO getParkingAssignDAO() {
    return this.parkingAssignDAO;
  }
  
  public void setParkingAssignDAO(ParkingAssignDAO parkingAssignDAO) {
    this.parkingAssignDAO = parkingAssignDAO;
  }
  
  public CommonDAO getCommonDAO()
  {
    return this.commonDAO;
  }
  
  public void setCommonDAO(CommonDAO commonDAO)
  {
    this.commonDAO = commonDAO;
  }
  
  public BizFlowManager getBizFlowManager() {
    return this.bizFlowManager;
  }
  
  public void setBizFlowManager(BizFlowManager bizFlowManager) {
    this.bizFlowManager = bizFlowManager;
  }
  
  public ParkingApplication getParkingApplicationByProcId(int procid)
  {
    ParkingApplication parkingApplication = this.parkingApplicationDAO.getParkingApplicationByProcId(procid);
    if (parkingApplication != null)
    {
      parkingApplication.setCarTagList(getParkingCarTag(procid, parkingApplication.getEmployeeID()));
      if (parkingApplication.isCarpool())
      {
        parkingApplication.setCarpoolList(getParkingAppCarpool(procid));
      }
    }
    return parkingApplication;
  }
  
  public List<ParkingAppCarpool> getParkingAppCarpool(int procid)
  {
    return this.parkingApplicationDAO.getParkingAppCarpool(procid);
  }
  
  public void updateParkingApplication(ParkingApplication parkingApplication) throws Exception
  {
    try {
      ParkingAppStatus previousParkingAppStatus = getParkingAppStatusByEmployeeID(parkingApplication.getEmployeeID(), "AA");
      
      if ((previousParkingAppStatus.isSubmitted()) && (parkingApplication.getProcid() != previousParkingAppStatus.getProcid()))
      {
        if (previousParkingAppStatus.isAccepted())
        {




          this.parkingApplicationDAO.updateParkingAppStatus(previousParkingAppStatus.getProcid(), "outdated");
        }
        else
        {
          this.parkingApplicationDAO.deleteParkingApplication(previousParkingAppStatus.getProcid());
          
          boolean success = this.bizFlowManager.deleteProcess(parkingApplication.getSessioninfo(), previousParkingAppStatus.getProcid());
          if (!success)
          {
            this.log.error("Cannot delete process(" + previousParkingAppStatus.getProcid() + ")");
          }
        }
      }
      
      this.commonDAO.updateEmpInfo(parkingApplication.getEmployeeID(), parkingApplication.getEmployeeHomeAddress(), parkingApplication.getEmployeeHomeUnit(), parkingApplication.getEmployeeCity(), parkingApplication.getEmployeeState(), parkingApplication.getEmployeeZip(), parkingApplication.getEmployeeWorkHourStart(), parkingApplication.getEmployeeWorkHourEnd(), parkingApplication.getEmployeeAgency(), parkingApplication.getEmployeeSubAgency(), parkingApplication.getEmployeeRoom(), parkingApplication.getEmployeePhone(), parkingApplication.getEmployeeEmail(), null, null, null, null, null, null, null);
      




      this.log.info("update Employee info(" + parkingApplication.getEmployeeID() + ")");
      this.parkingApplicationDAO.update(parkingApplication);
      

      HWProcessVariables pvs = BizFlowManager.getProcessVariables(parkingApplication.getSessioninfo(), parkingApplication.getProcid(), false);
      BizFlowManager.setDateVar(pvs, "submitdate", com.handysoft.hhs.transhare.util.CommandUtil.getGMT());
      BizFlowManager.setStringVar(pvs, "applicantname", parkingApplication.getEmployeeName());
      BizFlowManager.setStringVar(pvs, "agency", parkingApplication.getEmployeeAgency());
      BizFlowManager.setStringVar(pvs, "employeeid", parkingApplication.getEmployeeID());
      BizFlowManager.setStringVar(pvs, "permittype", Constants.getPermitCodeStr(parkingApplication.getPermitCode()));
      
      BizFlowManager.setStringVar(pvs, "building", parkingApplication.getEmployee().getBuilding());
      if ((null == parkingApplication.getAsnSpace()) || ("".equals(parkingApplication.getAsnSpace())))
      {
        BizFlowManager.setStringVar(pvs, "space", parkingApplication.getEmployeeLotSpace());
      } else {
        BizFlowManager.setStringVar(pvs, "space", parkingApplication.getAsnSpace());
      }
      
      if ("A1".equals(parkingApplication.getPermitCode()))
      {
        if ((null == pvs.getItemByName("agencycoordinator").getValue()) || ("".equals(pvs.getItemByName("agencycoordinator").getValue())))
        {
          String agencyCoordinator = null;
          if ((null != parkingApplication.getEmployeeSubAgency()) && (!"".equals(parkingApplication.getEmployeeSubAgency().trim())))
          {
            agencyCoordinator = this.bizFlowManager.getUserGroupMemberID(parkingApplication.getEmployeeAgency() + "/" + parkingApplication.getEmployeeSubAgency(), TranshareProperties.get("parkingProcess.userGroupHierarchyName"));
          }
          if (null == agencyCoordinator)
          {
            agencyCoordinator = this.bizFlowManager.getUserGroupMemberID(parkingApplication.getEmployeeAgency(), TranshareProperties.get("parkingProcess.userGroupHierarchyName"));
          }
          BizFlowManager.setGroupParticipantVar(pvs, "agencycoordinator", agencyCoordinator);
        }
        BizFlowManager.setStringVar(pvs, "title", parkingApplication.getEmployeeTitle());
      }
      
      if (pvs != null)
      {
        if ((parkingApplication.getPermitCode().equals("A")) || (parkingApplication.getPermitCode().equals("A4")) || (parkingApplication.getPermitCode().equals("A3")) || (parkingApplication.getPermitCode().equals("A2")) || (parkingApplication.getPermitCode().equals("VP")))
        {




          if (0 < parkingApplication.getCarpoolList().size())
          {

            String nextID = this.parkingApplicationDAO.updateNextCarpooler(parkingApplication.getProcid());
            if (nextID != null)
            {
              String memberID = this.bizFlowManager.getBizFlowMemberID(nextID);
              if ((memberID != null) && (1 < memberID.length()))
              {
                BizFlowManager.setParticipantVar(pvs, "nextapplicant", memberID);
              }
              else
              {
                throw new RuntimeException("The user(key:" + nextID + ") is not registered in the BizFlow.");
              }
            }
            
            BizFlowManager.setStringVar(pvs, "submitapplication", nextID != null ? "false" : "true");
          }
        }
        

        pvs.update();
      }
    }
    catch (Exception e)
    {
      this.log.error("updateParkingApplication Error " + e.getMessage());
      throw e;
    }
  }
  
  public void updateCarpooler(ParkingAppCarpool carpool) throws Exception
  {
    try {
      this.commonDAO.updateEmpInfo(carpool.getEmployeeID(), carpool.getEmployeeHomeAddress(), carpool.getEmployeeHomeUnit(), carpool.getEmployeeCity(), carpool.getEmployeeState(), carpool.getEmployeeZip(), carpool.getEmployeeWorkHourStart(), carpool.getEmployeeWorkHourEnd(), carpool.getEmployeeAgency(), carpool.getEmployeeSubAgency(), carpool.getEmployeeRoom(), carpool.getEmployeePhone(), carpool.getEmployeeEmail(), null, null, null, null, null, null, null);
      





      this.parkingApplicationDAO.updateParkingAppCarpool(carpool);
      

      HWProcessVariables pvs = BizFlowManager.getProcessVariables(carpool.getSessioninfo(), carpool.getProcid(), false);
      
      if (pvs != null)
      {
        String nextID = this.parkingApplicationDAO.updateNextCarpooler(carpool.getProcid());
        if (nextID != null)
        {
          String memberID = this.bizFlowManager.getBizFlowMemberID(nextID);
          if ((memberID != null) && (1 < memberID.length()))
          {
            BizFlowManager.setParticipantVar(pvs, "nextapplicant", memberID);
          }
          else
          {
            throw new RuntimeException("The user(key:" + nextID + ") is not registered in the BizFlow.");
          }
        }
        
        BizFlowManager.setStringVar(pvs, "submitapplication", nextID != null ? "false" : "true");
        pvs.update();
      }
    }
    catch (Exception e)
    {
      this.log.error("updateCarpooler error " + e.getMessage());
      throw e;
    }
  }
  
  public void cancelParkingApplication(ParkingApplication parkingApplication) throws Exception {
    this.parkingApplicationDAO.updateParkingAppStatus(parkingApplication.getProcid(), "cancel");
    
    HWProcessVariables pvs = BizFlowManager.getProcessVariables(parkingApplication.getSessioninfo(), parkingApplication.getProcid(), false);
    BizFlowManager.setStringVar(pvs, "cancelapplication", "true");
    BizFlowManager.setStringVar(pvs, "notifycancel", "true");
    
    if (parkingApplication.isCarpool())
    {
      List<String> carpoolers = new java.util.ArrayList();
      carpoolers.add(this.bizFlowManager.getBizFlowMemberID(parkingApplication.getEmployeeID()));
      
      for (ParkingAppCarpool carpool : parkingApplication.getCarpoolList())
      {
        carpoolers.add(this.bizFlowManager.getBizFlowMemberID(carpool.getEmployeeID()));
      }
      
      BizFlowManager.setParticipantArrayVar(pvs, "cancelledcarpooler", carpoolers);
    }
    
    pvs.update();
  }
  
  public void acceptParkingApplication(ParkingApplication parkingApplication) throws Exception
  {
    parkingApplication.setStatus("accept");
    this.parkingApplicationDAO.update(parkingApplication);
    HWProcessVariables pvs = BizFlowManager.getProcessVariables(parkingApplication.getSessioninfo(), parkingApplication.getProcid(), false);
    BizFlowManager.setStringVar(pvs, "status", "Approved");
    
    BizFlowManager.setStringVar(pvs, "space", parkingApplication.getAsnSpace());
    BizFlowManager.setStringVar(pvs, "permittype", Constants.getPermitCodeStr(parkingApplication.getPermitCode()));
    pvs.update();
    



    this.parkingApplicationDAO.copyToPSCLocator(parkingApplication.getProcid(), "BizFlow");
  }
  

  public void permitParkingApplication(ParkingApplication parkingApplication)
    throws Exception
  {
    if ("A1".equals(parkingApplication.getPermitCode()))
    {
      this.parkingApplicationDAO.update(parkingApplication);
    }
    
    this.parkingApplicationDAO.copyToPSCLocator(parkingApplication.getProcid(), "BizFlow");
    HWProcessVariables pvs = BizFlowManager.getProcessVariables(parkingApplication.getSessioninfo(), parkingApplication.getProcid(), false);
    BizFlowManager.setStringVar(pvs, "status", "Approved");
    pvs.update();
  }
  
  public void rejectParkingApplication(ParkingApplication parkingApplication) throws Exception
  {
    this.parkingApplicationDAO.updateComment(parkingApplication.getProcid(), parkingApplication.getComment());
    this.parkingApplicationDAO.updateParkingAppStatus(parkingApplication.getProcid(), "reject");
    
    HWProcessVariables pvs = BizFlowManager.getProcessVariables(parkingApplication.getSessioninfo(), parkingApplication.getProcid(), false);
    BizFlowManager.setStringVar(pvs, "status", "Disapproved");
    BizFlowManager.setStringVar(pvs, "message", parkingApplication.getComment());
    BizFlowManager.addComment(parkingApplication, parkingApplication.getComment());
    pvs.update();
  }
  
  public void deleteParkingApplication(int procid)
  {
    this.parkingApplicationDAO.deleteParkingApplication(procid);
  }
  
  public ParkingAssign getParkingAssign()
  {
    return this.bizFlowManager.getParkingAssign();
  }
  
  public ParkingAssign getParkingAssignByProcId(int procid)
  {
    return this.parkingAssignDAO.getParkingAssignByProcId(procid);
  }
  
  public List<com.handysoft.hhs.transhare.model.ParkingAssignDetail> getAllParkingAssignDetailByProcId(int procid, String agency)
  {
    return this.parkingAssignDAO.getAllParkingAssignDetailByProcId(procid, agency);
  }
  
  public void insertParkingAssign(ParkingAssign parkingAssign)
    throws Exception
  {
    this.parkingAssignDAO.insert(parkingAssign);
    

    HWProcessVariables pvs = BizFlowManager.getProcessVariables(parkingAssign.getSessioninfo(), parkingAssign.getProcid(), false);
    if (pvs != null)
    {
      for (ParkingAssignItem item : parkingAssign.getItems())
      {
        if (item.getLotCount() > 0) {
          HWProcessVariableImpl pv = (HWProcessVariableImpl)pvs.getItemByName(item.getAgency().replaceAll("/", "").toLowerCase() + "spot");
          if (pv != null)
          {
            pv.setFieldValue("VALUE", item.getLotCount());
          }
        }
      }
      pvs.update();
    }
  }
  
  public void saveParkingAssignItem(ParkingAssignItem parkingAssignItem) throws Exception
  {
    this.parkingAssignDAO.updateParkingAssignItem(parkingAssignItem);
  }
  
  public void updateParkingAssignItem(ParkingAssignItem parkingAssignItem) throws Exception {
    this.parkingAssignDAO.updateParkingAssignItem(parkingAssignItem);
    this.bizFlowManager.startExecParkingProcess(parkingAssignItem.getSessioninfo(), parkingAssignItem);
  }
  
  public List<com.handysoft.hhs.transhare.model.ParkingCarTag> getParkingCarTag(int procid, String employeeID)
  {
    return this.parkingApplicationDAO.getParkingCarTag(procid, employeeID);
  }
  
  public List<com.handysoft.hhs.transhare.model.ParkingCarTag> getParkingCarTagFromLocator(String employeeID)
  {
    return this.parkingApplicationDAO.getParkingCarTagFromLocator(employeeID);
  }
  
  public ParkingAppStatus getParkingAppStatusByEmployeeID(String employeeID, String exceptPermitCode) throws Exception
  {
    return this.parkingApplicationDAO.getParkingAppStatusByEmployeeID(employeeID, exceptPermitCode);
  }
  
  public EligibilityCheck isEligible(String employeeID) throws Exception
  {
    EligibilityCheck eligibilityCheck = new EligibilityCheck();
    

    HashMap hashMap = this.parkingApplicationDAO.isEligible(employeeID);
    eligibilityCheck.setEligible(1 == ((Integer)hashMap.get("eligible")).intValue());
    eligibilityCheck.setHasTranshare(1 == ((Integer)hashMap.get("hasTranshare")).intValue());
    eligibilityCheck.setHasParkingPermit(1 == ((Integer)hashMap.get("hasParkingPermit")).intValue());
    
    return eligibilityCheck;
  }
  
  public void cancelParkingAssign(ParkingAssign parkingAssign) throws Exception
  {
    boolean success = this.bizFlowManager.deleteProcess(parkingAssign.getSessioninfo(), parkingAssign.getProcid());
    if (!success)
    {
      this.log.error("Cannot delete process(" + parkingAssign.getProcid() + ")");
    }
  }
}
