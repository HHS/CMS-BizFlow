package com.handysoft.hhs.transhare.services;

import com.handysoft.hhs.transhare.TranshareProperties;
import com.handysoft.hhs.transhare.dao.BizFlowDAO;
import com.handysoft.hhs.transhare.model.BaseModel;
import com.handysoft.hhs.transhare.model.ParkingAssignDetail;
import com.handysoft.hhs.transhare.model.ParkingAssignItem;
import com.hs.bf.wf.jo.HWActivityImpl;
import com.hs.bf.wf.jo.HWComment;
import com.hs.bf.wf.jo.HWComments;
import com.hs.bf.wf.jo.HWProcessDefinition;
import com.hs.bf.wf.jo.HWProcessVariable;
import com.hs.bf.wf.jo.HWProcessVariableImpl;
import com.hs.bf.wf.jo.HWProcessVariables;
import com.hs.bf.wf.jo.HWUserImpl;
import org.apache.commons.logging.Log;

public class BizFlowManager
{
  Log log = null;
  private static final String PV_DATE_FORMAT = "yyyy/MM/dd HH:mm:ss z";
  private static final String PV_DATE_TIMEZONE = "GMT-0:00";
  private BizFlowDAO bizflowDAO;
  
  public BizFlowManager()
  {
    this.log = org.apache.commons.logging.LogFactory.getLog(BizFlowManager.class);
  }
  
  public BizFlowDAO getBizflowDAO()
  {
    return this.bizflowDAO;
  }
  
  public void setBizflowDAO(BizFlowDAO bizflowDAO)
  {
    this.bizflowDAO = bizflowDAO;
  }
  
  public com.hs.bf.wf.jo.HWUser getBizFlowUser(String sessionInfo, String userID) throws Exception
  {
    return new HWUserImpl(sessionInfo, null, userID);
  }
  
  public String getActivityName(String sessionInfo, int procid, int actseq) throws Exception
  {
    HWActivityImpl act = new HWActivityImpl(sessionInfo, procid, actseq);
    if (act != null)
    {
      return act.getName();
    }
    

    return null;
  }
  
  public String getEmployeeID(String sessionInfo, String userID)
    throws Exception
  {
    HWUserImpl user = new HWUserImpl(sessionInfo, null, userID);
    if (user != null)
    {
      return user.getFieldValue("CUSTOMD");
    }
    

    return null;
  }
  
  public String getEmployeeID(String userID)
    throws Exception
  {
    return this.bizflowDAO.getEmployeeID(userID);
  }
  
  public String getBizFlowMemberID(String employeeID) throws Exception
  {
    try
    {
      return this.bizflowDAO.getMemberID(employeeID);
    }
    catch (Exception e) {}
    
    return null;
  }
  
  public String getUserGroupMemberID(String userGroupName, String userGroupHierarchyName)
    throws Exception
  {
    try
    {
      return this.bizflowDAO.getUserGroupMemberID(userGroupName, userGroupHierarchyName);
    }
    catch (Exception e) {}
    
    return null;
  }
  

  public static HWProcessVariables getProcessVariables(String sessionInfo, int processID, boolean isArchive)
    throws Exception
  {
    if (((null == sessionInfo) || ("".equals(sessionInfo))) && (0 >= processID))
    {
      throw new Exception("Invalid parameter(s)");
    }
    

    return new com.hs.bf.wf.jo.HWProcessVariablesImpl(sessionInfo, processID, isArchive);
  }
  

  public static HWProcessVariable getProcessVariable(String sessionInfo, int processID, boolean isArchive, String variableName)
    throws Exception
  {
    if (((null == sessionInfo) || ("".equals(sessionInfo))) && (0 >= processID))
    {
      throw new Exception("Invalid parameter(s)");
    }
    

    HWProcessVariables vars = new com.hs.bf.wf.jo.HWProcessVariablesImpl(sessionInfo, processID, isArchive);
    HWProcessVariable var = null;
    if (null != vars)
    {
      var = vars.getItemByName(variableName);
    }
    return var;
  }
  

  public static void updateVariables(HWProcessVariables vars)
    throws Exception
  {
    if (null == vars)
    {
      throw new Exception("Invalid parameter(s)");
    }
    

    vars.update();
  }
  















  public void startExecParkingProcess(String sessionInfo, ParkingAssignItem parkingAssignItem)
    throws Exception
  {
    if ((null == sessionInfo) || ("".equals(sessionInfo)))
    {
      throw new Exception("BizFlow connection is not available.");
    }
    

    String processName = TranshareProperties.get("parkingProcess.processName");
    int pdefid = TranshareProperties.getInt("parkingProcess.processDefID");
    int instanceFolderID = TranshareProperties.getInt("parkingProcess.instanceFolderID");
    int archiveFolderID = TranshareProperties.getInt("parkingProcess.archiveFolderID");
    String startActivityName = TranshareProperties.get("parkingProcess.startActivityName");
    com.hs.bf.wf.jo.HWVariant procid = new com.hs.bf.wf.jo.HWVariant();
    
    HWProcessDefinition hwProcDef = new com.hs.bf.wf.jo.HWProcessDefinitionImpl(sessionInfo, pdefid);
    for (ParkingAssignDetail item : parkingAssignItem.getItems())
    {
      if ((item.getEmployeeID() != null) && (0 < item.getEmployeeID().length()) && (item.getStatus() == 0))
      {
        HWProcessVariables pvs = hwProcDef.getProcessVariables();
        setStringVar(pvs, "agency", item.getAgency());
        setStringVar(pvs, "employeeid", item.getEmployeeID());
        setStringVar(pvs, "applicantname", item.getEmployeeName());
        setParticipantVar(pvs, "applicant", getBizFlowMemberID(item.getEmployeeID()));
        setGroupParticipantVar(pvs, "agencycoordinator", item.getMemberid());
        if ((null == item.getEmployeeID()) || ("".equals(item.getEmployeeID())))
        {
          throw new Exception("Exec Allotment: EmployeeID is not available.[" + item.getProcid() + "]");
        }
        this.log.debug("agency:" + item.getAgency());
        this.log.debug("employeeid:" + item.getEmployeeID());
        this.log.debug("applicantname:" + item.getEmployeeName());
        this.log.debug("applicant:" + getBizFlowMemberID(item.getEmployeeID()));
        boolean isUrgent = false;
        boolean isStartProcess = true;
        boolean needWorkitem = false;
        String customID = null;
        com.hs.bf.wf.jo.HWAttachments attachments = null;
        com.hs.bf.wf.jo.HWWorkitem hwWorkitem = hwProcDef.createInstance(processName, "initiated by " + item.getAgency() + " PIO", isUrgent, isStartProcess, needWorkitem, instanceFolderID, archiveFolderID, customID, startActivityName, attachments, pvs, procid);
        this.log.debug("Exec Parking Process is initiated - ProcID:" + procid.getIntValue());
      }
    }
  }
  


  public static void setStringVar(HWProcessVariables pvs, String name, String value)
  {
    if (pvs != null)
    {
      HWProcessVariable pv = pvs.getItemByName(name);
      if (pv != null)
      {
        pv.setValue(value);
      }
    }
  }
  
  public static void setDateVar(HWProcessVariables pvs, String name, java.util.Date value) throws Exception
  {
    if (pvs != null)
    {
      HWProcessVariable pv = pvs.getItemByName(name);
      if (pv != null)
      {
        pv.setValue(value);
      }
    }
  }
  
  public static void setParticipantVar(HWProcessVariables pvs, String name, String value) throws Exception
  {
    if (pvs != null)
    {
      HWProcessVariable pv = pvs.getItemByName(name);
      if (pv != null)
      {
        ((HWProcessVariableImpl)pv).setParticipantValue('U', value); }
    }
  }
  
  public static void setParticipantArrayVar(HWProcessVariables pvs, String name, java.util.List<String> values) throws Exception {
    int idx;
    com.hs.bf.wf.jo.HWProcessVariableArray array;
    if (pvs != null)
    {
      HWProcessVariable pv = pvs.getItemByName(name);
      if (pv != null)
      {
        idx = 1;
        array = pv.getArrayValues();
        for (String memberID : values)
        {
          ((HWProcessVariableImpl)array.getItemByDimensionIndex(String.valueOf(idx++))).setParticipantValue('U', memberID);
        }
      }
    }
  }
  
  public static void setGroupParticipantVar(HWProcessVariables pvs, String name, String value) throws Exception
  {
    if (value == null)
    {
      throw new Exception("Invalid Participant value");
    }
    if (pvs != null)
    {
      HWProcessVariable pv = pvs.getItemByName(name);
      if (pv != null)
      {
        ((HWProcessVariableImpl)pv).setParticipantValue('G', value);
      }
    }
  }
  
  public boolean deleteProcess(String sessionInfo, int procid)
  {
    try
    {
      com.hs.bf.web.beans.HWSession session = new com.hs.bf.wf.jo.HWObject().getSession();
      session.deleteProcess(sessionInfo, procid, true);
      return true;
    }
    catch (Exception e)
    {
      e.printStackTrace(); }
    return false;
  }
  

  public static HWComments getComments(String sessionInfo, int processID, boolean isArchive)
    throws Exception
  {
    if (((null == sessionInfo) || ("".equals(sessionInfo))) && (0 >= processID))
    {
      throw new Exception("Invalid parameter(s)");
    }
    

    return new com.hs.bf.wf.jo.HWCommentsImpl(sessionInfo, processID, isArchive);
  }
  
  public static void addComment(BaseModel base, String comment)
    throws Exception
  {
    if ((null == base) || (null == comment))
    {
      throw new Exception("Invalid parameter(s)");
    }
    
    HWComments cs = new com.hs.bf.wf.jo.HWCommentsImpl(base.getSessioninfo(), base.getProcid(), false);
    HWComment c = cs.add();
    c.setWorkItemSequence(base.getWorkseq());
    c.setContents(comment);
    cs.update();
  }
  
  public com.handysoft.hhs.transhare.model.ParkingAssign getParkingAssign()
  {
    this.log.debug("Getting Parking Coordinator group list from BizFlow user group");
    this.log.debug("agencyGroupName: " + TranshareProperties.get("parkingProcess.agencyGroupName"));
    this.log.debug("userGroupHierarchyName: " + TranshareProperties.get("parkingProcess.userGroupHierarchyName"));
    return this.bizflowDAO.getParkingAssign(TranshareProperties.get("parkingProcess.agencyGroupName"), TranshareProperties.get("parkingProcess.userGroupHierarchyName"));
  }
  
  public void updateMemberEMail(String memberID, String email) throws Exception
  {
    if ((null == memberID) || (null == email))
    {
      throw new Exception("Invalid parameter(s)");
    }
    this.bizflowDAO.updateMemberEMail(memberID, email);
  }
  
  public Integer getTranshareAccessEligible(Integer procID, String memberID)
    throws Exception
  {
    Integer cntUserGroup = this.bizflowDAO.getTranshareAccessEligible(procID, memberID);
    this.log.info("getTranshareAccessEligible procID:" + procID + " memberID:" + memberID + " result:" + cntUserGroup);
    return cntUserGroup;
  }
}
