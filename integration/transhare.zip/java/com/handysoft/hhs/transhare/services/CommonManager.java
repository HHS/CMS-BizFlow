package com.handysoft.hhs.transhare.services;

import com.handysoft.hhs.transhare.dao.BizFlowDAO;
import com.handysoft.hhs.transhare.dao.CommonDAO;
import com.handysoft.hhs.transhare.model.Building;
import com.handysoft.hhs.transhare.model.DBLookUp;
import com.handysoft.hhs.transhare.model.Employee;
import com.handysoft.hhs.transhare.model.TravelMethod;
import com.hs.frmwk.json.JSONArray;
import com.hs.frmwk.json.JSONException;
import java.util.List;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.web.context.WebApplicationContext;










public class CommonManager
{
  Log log = null;
  
  private CommonDAO commonDAO = null;
  private BizFlowDAO bizflowDAO = null;
  
  public CommonManager()
  {
    this.log = LogFactory.getLog(CommonManager.class);
  }
  
  public BizFlowDAO getBizflowDAO() {
    return this.bizflowDAO;
  }
  
  public void setBizflowDAO(BizFlowDAO bizflowDAO) {
    this.bizflowDAO = bizflowDAO;
  }
  
  public CommonDAO getCommonDAO() {
    return this.commonDAO;
  }
  
  public void setCommonDAO(CommonDAO commonDAO) {
    this.commonDAO = commonDAO;
  }
  
  public Employee getEmployee(String employeeID) {
    return this.commonDAO.getEmployeeByID(employeeID);
  }
  
  public List<Employee> getAllExecutiveByAgency(String agency) {
    return this.commonDAO.getAllExecutiveByAgency(agency);
  }
  
  public List<DBLookUp> getStates()
  {
    return this.commonDAO.getStates();
  }
  
  public String getStatesJSON()
  {
    try
    {
      List<DBLookUp> list = getStates();
      JSONArray array = new JSONArray();
      for (DBLookUp d : list)
      {
        array.put(d.toJSONObject());
      }
      
      return array.toString();
    }
    catch (JSONException e) {}
    
    return null;
  }
  

  public List<DBLookUp> getAllRegion()
  {
    return this.commonDAO.getRegions();
  }
  
  public List getAllBuilding() {
    return this.commonDAO.getAllBuilding();
  }
  
  public Building getBuilding(String id) {
    return this.commonDAO.getBuilding(id);
  }
  
  public List getAllAgency() {
    return this.commonDAO.getAllAgency();
  }
  
  public List getSubAgency(String agency) {
    return this.commonDAO.getSubAgency(agency);
  }
  
  public List getAllAgencyByProcId(int procid) {
    return this.commonDAO.getAllAgencyByProcId(procid);
  }
  
  public String getAllAgencyJSON()
  {
    try
    {
      List<DBLookUp> list = getAllAgency();
      JSONArray array = new JSONArray();
      for (DBLookUp d : list)
      {
        array.put(d.toJSONObject());
      }
      
      return array.toString();
    }
    catch (JSONException e) {}
    
    return null;
  }
  

  public List<TravelMethod> getTravelMethods(String region)
  {
    return this.commonDAO.getTravelMethods(region);
  }
  
  public Object getBean(HttpSession session, String name)
  {
    ServletContext sc = session.getServletContext();
    AbstractApplicationContext ac = (AbstractApplicationContext)sc.getAttribute(WebApplicationContext.ROOT_WEB_APPLICATION_CONTEXT_ATTRIBUTE);
    return ac.getBean(name);
  }
  
  public List<DBLookUp> getParkingPriorities()
  {
    return this.commonDAO.getParkingPriorities();
  }
  
  public List<DBLookUp> getParkingLots()
  {
    return this.commonDAO.getParkingLots();
  }
}
