package com.handysoft.hhs.transhare.services;

import com.handysoft.hhs.transhare.TranshareProperties;
import com.handysoft.hhs.transhare.dao.CommonDAO;
import com.handysoft.hhs.transhare.dao.TranshareApplicationDAO;
import com.handysoft.hhs.transhare.model.BaseModel;
import com.handysoft.hhs.transhare.model.EligibilityCheck;
import com.handysoft.hhs.transhare.model.Employee;
import com.handysoft.hhs.transhare.model.TranshareApplication;
import com.handysoft.hhs.transhare.model.TranshareCost;
import com.handysoft.hhs.transhare.util.WebCallUtil;
import com.hs.bf.wf.jo.HWComment;
import com.hs.bf.wf.jo.HWComments;
import com.hs.bf.wf.jo.HWProcessVariable;
import com.hs.bf.wf.jo.HWProcessVariables;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;





public class TranshareManager
{
  Log log = null;
  
  private CommonDAO commonDAO = null;
  private TranshareApplicationDAO transhareApplicationDAO = null;
  private BizFlowManager bizFlowManager = null;
  
  public TranshareManager()
  {
    this.log = LogFactory.getLog(TranshareManager.class);
  }
  
  public TranshareApplicationDAO getTranshareApplicationDAO() {
    return this.transhareApplicationDAO;
  }
  
  public void setTranshareApplicationDAO(TranshareApplicationDAO transhareApplicationDAO) {
    this.transhareApplicationDAO = transhareApplicationDAO;
  }
  
  public CommonDAO getCommonDAO()
  {
    return this.commonDAO;
  }
  
  public void setCommonDAO(CommonDAO commonDAO)
  {
    this.commonDAO = commonDAO;
  }
  
  public BizFlowManager getBizFlowManager() {
    return this.bizFlowManager;
  }
  
  public void setBizFlowManager(BizFlowManager bizFlowManager) {
    this.bizFlowManager = bizFlowManager;
  }
  
  public List<TranshareCost> getTranshareCosts(int procid)
  {
    return this.transhareApplicationDAO.getTranshareCost(procid);
  }
  
  public TranshareApplication getTranshareApplicationByProcId(int procid)
  {
    TranshareApplication app = this.transhareApplicationDAO.getTranshareApplicationByProcId(procid);
    if (app != null)
    {
      app.setEmployee(this.commonDAO.getEmployeeByID(app.getEmployeeID()));
      app.setCosts(getTranshareCosts(procid));
    }
    return app;
  }
  
  public void cancelTranshareApplication(TranshareApplication app) throws Exception {
    this.transhareApplicationDAO.updateTranshareStatus(app.getProcid(), "cancel");
    
    this.log.info("cancelTranshareApplication(ProcId: " + app.getProcid() + ", userid: " + app.getCurrentUserId() + ")");
    
    HWProcessVariables pvs = BizFlowManager.getProcessVariables(app.getSessioninfo(), app.getProcid(), false);
    BizFlowManager.setStringVar(pvs, "cancelapplication", "true");
    BizFlowManager.setParticipantVar(pvs, "lastuser", app.getCurrentUserId());
    pvs.update();
  }
  
  public void acceptTranshareApplication(int viewerID, TranshareApplication app) throws Exception
  {
    HWProcessVariables pvs = BizFlowManager.getProcessVariables(app.getSessioninfo(), app.getProcid(), false);
    BizFlowManager.setStringVar(pvs, "sendback", "false");
    
    if (viewerID == 1)
    {
      BizFlowManager.setStringVar(pvs, "status", "Supervisor Accept");
      app.setStatus("Supervisor Accept");
      this.transhareApplicationDAO.updateBySupervisor(app);
    }
    else if (viewerID == 2)
    {
      BizFlowManager.setStringVar(pvs, "status", "Coordinator Accept");
      BizFlowManager.setParticipantVar(pvs, "coordinatoremail", app.getCurrentUserId());
      app.setStatus("Coordinator Accept");
      this.transhareApplicationDAO.updateByCoordinator(app);
    }
    else if (viewerID == 3)
    {
      setNotify(app, pvs);
      BizFlowManager.setStringVar(pvs, "notifysubject", app.getEmailSubject().replaceAll("[^a-zA-Z 0-9~!@#$%^&*)(_+`={}|\\[\\]\\:\";'<>?,./-]", ""));
      BizFlowManager.setStringVar(pvs, "message", app.getMessageForEmail().replaceAll("(\r\n|\r|\n|\n\r)", "<br>").replaceAll("[^a-zA-Z 0-9~!@#$%^&*)(_+`={}|\\[\\]\\:\";'<>?,./-]", ""));
      BizFlowManager.setStringVar(pvs, "status", "accept");
      app.setStatus("accept");
      this.transhareApplicationDAO.updateByTranshareCoordinator(app);
      this.transhareApplicationDAO.copyToPSCLocator(app);
    }
    






    this.log.info("acceptTranshareApplication(ProcId: " + app.getProcid() + ", userid: " + app.getCurrentUserId() + ")");
    
    BizFlowManager.setParticipantVar(pvs, "lastuser", app.getCurrentUserId());
    pvs.update();
  }
  
  private void setNotify(TranshareApplication app, HWProcessVariables pvs) throws Exception
  {
    if (app.isNotifyEnrollee())
    {
      BizFlowManager.setStringVar(pvs, "notifyenrolee", "true");
    }
    else
    {
      BizFlowManager.setStringVar(pvs, "notifyenrolee", "false");
    }
    if (app.isNotifySupervisor())
    {
      BizFlowManager.setStringVar(pvs, "notifysupervisor", "true");
      if ((null != pvs.getItemByName("supervisor")) && (!"".equals(pvs.getItemByName("supervisor").getValue())))
      {
        BizFlowManager.setStringVar(pvs, "supervisoremail", pvs.getItemByName("supervisor").getValue());
      }
    }
    else
    {
      BizFlowManager.setStringVar(pvs, "notifysupervisor", "false");
    }
    if (app.isNotifyCoordinator())
    {
      BizFlowManager.setStringVar(pvs, "notifycoordinator", "true");
    }
    else
    {
      BizFlowManager.setStringVar(pvs, "notifycoordinator", "false");
      if ((null != pvs.getItemByName("coordinatoremail")) && (!"".equals(pvs.getItemByName("coordinatoremail").getValue())))
      {
        BizFlowManager.setStringVar(pvs, "coordinatoremail", "");
      }
    }
  }
  
  public void sendbackTranshareApplication(int viewerID, TranshareApplication app) throws Exception
  {
    String status = "permit";
    if (viewerID == 1)
    {
      status = "Supervisor Reject";
    }
    else if (viewerID == 2)
    {
      status = "Coordinator Reject";
    }
    else if (viewerID == 3)
    {
      status = "Coordinator Reject";
    }
    else if (viewerID == 4)
    {
      status = "Prepare Media Reject";
    }
    
    this.log.info("sendbackTranshareApplication(" + app.getProcid() + ":" + status + ")");
    
    this.transhareApplicationDAO.updateTranshareStatus(app.getProcid(), status);
    BizFlowManager.addComment(app, app.getComment());
    
    HWProcessVariables pvs = BizFlowManager.getProcessVariables(app.getSessioninfo(), app.getProcid(), false);
    BizFlowManager.setStringVar(pvs, "sendback", "true");
    BizFlowManager.setStringVar(pvs, "message", app.getComment());
    BizFlowManager.setStringVar(pvs, "status", status);
    BizFlowManager.setParticipantVar(pvs, "lastuser", app.getCurrentUserId());
    BizFlowManager.setStringVar(pvs, "activityname", "Resubmit Transhare application");
    pvs.update();
  }
  
  public void deleteTranshareApplication(int procid)
  {
    this.transhareApplicationDAO.deleteTranshareApplication(procid);
    this.log.info("deleteTranshareApplication(" + procid + ")");
  }
  
  public void updateTranshareApplication(TranshareApplication app) throws Exception {
    try {
      this.log.debug(">>updateTranshareApplication procid=" + app.getProcid());
      Employee employee = app.getEmployee();
      
      if (employee.isHeadquarter())
      {
        employee.setOfficeAddress(null);
        employee.setOfficeCity(null);
        employee.setOfficeState(null);
        employee.setOfficeZip(null);
      }
      
      this.bizFlowManager.updateMemberEMail(app.getCurrentUserId(), employee.getEmail());
      this.commonDAO.updateEmpInfo(employee);
      this.log.info("update Employee info(" + employee.getEmployeeID() + " " + employee.getName() + ")");
      
      this.transhareApplicationDAO.update(app);
      this.transhareApplicationDAO.deleteTranshareCost(app.getProcid());
      for (TranshareCost tc : app.getCosts())
      {
        if (0 < tc.getTravelMethodID())
        {
          tc.setProcid(app.getProcid());
          this.transhareApplicationDAO.insertTranshareCost(tc);
        }
      }
      

      HWProcessVariables pvs = BizFlowManager.getProcessVariables(app.getSessioninfo(), app.getProcid(), false);
      String supervisorBizFlowMemberID = this.bizFlowManager.getBizFlowMemberID(app.getSupervisorID());
      this.log.debug("supervisorBizFlowMemberID=" + supervisorBizFlowMemberID);
      if ((null != supervisorBizFlowMemberID) && (!"".equalsIgnoreCase(supervisorBizFlowMemberID)))
      {
        this.log.debug("NOT NULL supervisorBizFlowMemberID=" + supervisorBizFlowMemberID);
        BizFlowManager.setParticipantVar(pvs, "supervisor", supervisorBizFlowMemberID);
      }
      String userGroupMemberID = null;
      if (employee.isHeadquarter())
      {
        if ((null != employee.getDivision()) && (!"".equals(employee.getDivision())))
        {
          userGroupMemberID = this.bizFlowManager.getUserGroupMemberID(employee.getAgency().toUpperCase() + "/" + employee.getSubAgency().toUpperCase() + "/" + employee.getDivision().toUpperCase(), TranshareProperties.get("transhareProcess.userGroupHierarchyName"));
        }
        if ((null != employee.getSubAgency()) && (!"".equals(employee.getSubAgency())) && (null == userGroupMemberID))
        {
          userGroupMemberID = this.bizFlowManager.getUserGroupMemberID(employee.getAgency().toUpperCase() + "/" + employee.getSubAgency().toUpperCase(), TranshareProperties.get("transhareProcess.userGroupHierarchyName"));
        }
        if ((null != employee.getAgency()) && (!"".equals(employee.getAgency())) && (null == userGroupMemberID))
        {
          userGroupMemberID = this.bizFlowManager.getUserGroupMemberID(employee.getAgency().toUpperCase(), TranshareProperties.get("transhareProcess.userGroupHierarchyName"));
        }
        this.log.debug("getting coordinator info(" + employee.getName() + ": " + employee.getAgency() + "/" + employee.getSubAgency() + "/" + employee.getDivision() + " [" + userGroupMemberID + "] )");
        if (null != userGroupMemberID)
        {
          this.log.info("setGroupParticipantVar Headquarter coordinator = (" + userGroupMemberID + ")");
          BizFlowManager.setGroupParticipantVar(pvs, "coordinator", userGroupMemberID);
        }
        else
        {
          throw new Exception("COORDINATOR:Please contact the transhare office (301-443-2414). This coordinator can not be found. (" + employee.getName() + ": " + employee.getAgency() + "/" + employee.getSubAgency() + "/" + employee.getDivision() + " [" + userGroupMemberID + "] )");
        }
      }
      else
      {
        this.log.debug("getUserGroupMemberID RegionName:" + employee.getRegionName());
        userGroupMemberID = this.bizFlowManager.getUserGroupMemberID(employee.getRegionName(), TranshareProperties.get("transhareProcess.userGroupHierarchyName"));
        this.log.info("setGroupParticipantVar Region coordinator = (" + userGroupMemberID + ")");
        if (null != userGroupMemberID)
        {
          BizFlowManager.setGroupParticipantVar(pvs, "coordinator", userGroupMemberID);
        }
        else
        {
          throw new Exception("COORDINATOR:Please contact the transhare office (301-443-2414). This coordinator can not be found. (" + employee.getName() + ": " + employee.getAgency() + "/" + employee.getSubAgency() + "/" + employee.getDivision() + " [" + userGroupMemberID + "] )");
        }
      }
      BizFlowManager.setStringVar(pvs, "agency", employee.getAgency());
      BizFlowManager.setStringVar(pvs, "subagency", employee.getSubAgency());
      BizFlowManager.setStringVar(pvs, "employeeid", employee.getEmployeeID());
      BizFlowManager.setStringVar(pvs, "region", employee.getRegion());
      BizFlowManager.setStringVar(pvs, "sendback", "false");
      BizFlowManager.setParticipantVar(pvs, "lastuser", app.getCurrentUserId());
      BizFlowManager.setStringVar(pvs, "activityname", "Review " + employee.getName() + " Transhare application");
      BizFlowManager.setStringVar(pvs, "purpose", app.getPurpose());
      

      BizFlowManager.setStringVar(pvs, "division", employee.getDivision());
      
      pvs.update();
    }
    catch (Exception e)
    {
      this.log.error("updateTranshareApplication Error " + e.getMessage());
      throw e;
    }
  }
  
  public Employee getDefaultSupervisor(String employeeID) {
    return this.commonDAO.getEmployeeByID(employeeID);
  }
  
  public String getLatestComment(BaseModel base) throws Exception
  {
    HWComments cs = BizFlowManager.getComments(base.getSessioninfo(), base.getProcid(), false);
    if ((cs != null) && (0 < cs.getCount()))
    {
      return cs.getItem(cs.getCount() - 1).getContents();
    }
    

    return null;
  }
  

  public BigDecimal getTranshareMonthlyMaximum(String employeeID)
  {
    BigDecimal max = this.transhareApplicationDAO.getTranshareMonthlyMaximum(employeeID);
    return (max == null) || (max.floatValue() < 0.0F) ? new BigDecimal(0) : max;
  }
  
  public EligibilityCheck isEligible(String employeeID) throws Exception
  {
    EligibilityCheck eligibilityCheck = new EligibilityCheck();
    

    HashMap hashMap = this.transhareApplicationDAO.isEligible(employeeID);
    eligibilityCheck.setEligible(1 == ((Integer)hashMap.get("transhareEligible")).intValue());
    eligibilityCheck.setHasParkingPermit(1 == ((Integer)hashMap.get("hasParkingPermit")).intValue());
    
    return eligibilityCheck;
  }
  
  private String removeInvalidXmlChars(String in)
  {
    StringBuffer out = new StringBuffer();
    

    if ((in == null) || ("".equals(in))) return "";
    for (int i = 0; i < in.length(); i++) {
      char current = in.charAt(i);
      if ((current == '\t') || (current == '\n') || (current == '\r') || ((current >= ' ') && (current <= 55295)) || ((current >= 57344) && (current <= 65533)) || ((current >= 65536) && (current <= 1114111)))
      {




        out.append(current); }
    }
    return out.toString();
  }
  
  public void importSupervisor(TranshareApplication app)
    throws Exception
  {
    this.log.info("********** runtime supervisor import begin **********");
    this.log.info("Checking supervisor info in BizFlow... procid=" + app.getProcid() + ", supervior employeeid=" + app.getSupervisorID());
    HWProcessVariables pvs = BizFlowManager.getProcessVariables(app.getSessioninfo(), app.getProcid(), false);
    String supervisorBizFlowMemberID = this.bizFlowManager.getBizFlowMemberID(app.getSupervisorID());
    this.log.info("supervisorBizFlowMemberID=" + supervisorBizFlowMemberID);
    if ((null != supervisorBizFlowMemberID) && (!"".equalsIgnoreCase(supervisorBizFlowMemberID)))
    {
      BizFlowManager.setParticipantVar(pvs, "supervisor", supervisorBizFlowMemberID);
      this.log.info("Supervisor exists in BizFlow. No need to import the supervisor into BizFlow");
    }
    else
    {
      this.log.info("Supervisor does not exist in BizFlow.");
      HWProcessVariable pvVersion = pvs.getItemByName("version");
      String defVersion = "";
      if ((null != pvVersion) && (!"".equals(pvVersion.getValue()))) {
        defVersion = pvVersion.getValue();
      }
      this.log.debug("Definition version=" + defVersion);
      if ((null == defVersion) || ("".equals(defVersion)))
      {
        this.log.debug("Definition version 1.1 or higher supports runtime supervisor import.");
      }
      else {
        try
        {
          String errMsgOfAddingSupervisor = null;
          
          this.log.info(">>ADD SUPERVISOR_ID=" + app.getSupervisorID());
          String importUserUrl = TranshareProperties.get("transhare.importUserUrl");
          String importUserUrlParamName = TranshareProperties.get("transhare.importUserUrlParamName");
          importUserUrl = importUserUrl + "&" + importUserUrlParamName + "=" + app.getSupervisorID();
          this.log.info("SUPERVISOR_URL=" + importUserUrl);
          String actionResult = "";
          StringBuffer sb = WebCallUtil.callURLandGetActionResult(importUserUrl, "<actionresult>", "</actionresult>");
          if (null != sb) {
            actionResult = sb.toString();
            this.log.info("ACTIONRESULT=" + actionResult);
            int idx = actionResult.indexOf("memberid=");
            if (0 <= idx) {
              supervisorBizFlowMemberID = actionResult.substring(idx + "memberid=".length());
            } else {
              supervisorBizFlowMemberID = "";
              if ((null != actionResult) && (!"".equals(actionResult))) {
                errMsgOfAddingSupervisor = actionResult;
              } else {
                errMsgOfAddingSupervisor = "The supervisor you selected has not been registered in BizFlow.";
              }
            }
            this.log.info("SUPERVISOR_MEMBERID=" + supervisorBizFlowMemberID + ".!!");
          }
          
          if ((null == supervisorBizFlowMemberID) || ("".equals(supervisorBizFlowMemberID)))
          {
            this.log.info("importsupervisorrequired=Y, importsupervisorempid=" + app.getSupervisorID() + ",importsupervisorstatus=" + errMsgOfAddingSupervisor);
            BizFlowManager.setStringVar(pvs, "importsupervisorrequired", "Y");
            BizFlowManager.setStringVar(pvs, "importsupervisorempid", app.getSupervisorID());
            BizFlowManager.setStringVar(pvs, "importsupervisorstatus", errMsgOfAddingSupervisor);
            BizFlowManager.setStringVar(pvs, "status", "Supervisor Update");
          }
          else {
            this.log.info("importsupervisorrequired=N, supervisorBizFlowMemberID=" + supervisorBizFlowMemberID);
            BizFlowManager.setStringVar(pvs, "importsupervisorrequired", "N");
            BizFlowManager.setStringVar(pvs, "importsupervisorempid", "");
            BizFlowManager.setStringVar(pvs, "importsupervisorstatus", "");
            BizFlowManager.setStringVar(pvs, "status", "Pending");
            BizFlowManager.setParticipantVar(pvs, "supervisor", supervisorBizFlowMemberID);
          }
          pvs.update();
          this.log.info("<<ADD SUPERVISOR_ID=" + app.getSupervisorID());
        } catch (Exception e) {
          this.log.error(e.getMessage());
          throw new Exception("SUPERVISOR:Please contact the transhare office (301-443-2414). The office needs to ensure the supervisor you selected is added to the list. (Supervisor Employee ID: " + app.getSupervisorID() + ") Error Details: " + e.getMessage());
        }
      }
    }
    
    this.log.debug("********** runtime supervisor import end **********");
  }
}
