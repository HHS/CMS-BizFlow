package com.handysoft.hhs.transhare.model;

import java.io.Serializable;






public class EligibilityCheck
  implements Serializable
{
  private boolean eligible = true;
  private boolean hasTranshare = false;
  private boolean hasParkingPermit = false;
  
  public boolean isEligible() {
    return this.eligible;
  }
  
  public void setEligible(boolean eligible) {
    this.eligible = eligible;
  }
  
  public boolean isHasTranshare() {
    return this.hasTranshare;
  }
  
  public void setHasTranshare(boolean hasTranshare) {
    this.hasTranshare = hasTranshare;
  }
  
  public boolean isHasParkingPermit() {
    return this.hasParkingPermit;
  }
  
  public void setHasParkingPermit(boolean hasParkingPermit) {
    this.hasParkingPermit = hasParkingPermit;
  }
}
