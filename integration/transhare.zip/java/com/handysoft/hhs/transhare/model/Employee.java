package com.handysoft.hhs.transhare.model;

import java.util.Date;





public class Employee
  extends BaseModel
{
  private String name;
  private String firstName;
  private String lastName;
  private String middleName;
  private String title;
  private float status;
  private String building;
  private String room;
  private String agency;
  private String subAgency;
  private String division;
  private String email;
  private String city;
  private String state;
  private String zip;
  private String homeAddress;
  private String homeUnit;
  private String lotSpace;
  private String asnType;
  private String asnSpace;
  private boolean tranShare;
  private String phone;
  private String employeeID;
  private String hhsID;
  private String workHourStart;
  private String workHourEnd;
  private String officeCity;
  private String officeState;
  private String officeZip;
  private String officeAddress;
  private String region;
  private String regionName;
  private String permitNumber;
  private Date permitDate;
  private String supervisorID;
  private String priority;
  private boolean inactive;
  private Date dateEntered;
  private Date dateAppUpdated;
  private Date lastExportedToBF;
  private boolean parkingEligible;
  private boolean transhareEligible;
  
  public String getAgency()
  {
    return this.agency;
  }
  
  public void setAgency(String agency)
  {
    this.agency = agency;
  }
  
  public String getAsnSpace()
  {
    return this.asnSpace;
  }
  
  public void setAsnSpace(String asnSpace)
  {
    this.asnSpace = asnSpace;
  }
  
  public String getAsnType()
  {
    return this.asnType;
  }
  
  public void setAsnType(String asnType)
  {
    this.asnType = asnType;
  }
  
  public String getBuilding()
  {
    return this.building;
  }
  
  public void setBuilding(String building)
  {
    this.building = building;
  }
  
  public String getCity()
  {
    return this.city;
  }
  
  public void setCity(String city)
  {
    this.city = city;
  }
  
  public String getDivision()
  {
    return this.division;
  }
  
  public void setDivision(String division)
  {
    this.division = division;
  }
  
  public String getEmail()
  {
    return this.email;
  }
  
  public void setEmail(String email)
  {
    this.email = email;
  }
  
  public String getFirstName()
  {
    return this.firstName;
  }
  
  public void setFirstName(String firstName)
  {
    this.firstName = firstName;
  }
  
  public String getLastName()
  {
    return this.lastName;
  }
  
  public void setLastName(String lastName)
  {
    this.lastName = lastName;
  }
  
  public String getLotSpace()
  {
    return this.lotSpace;
  }
  
  public void setLotSpace(String lotSpace)
  {
    this.lotSpace = lotSpace;
  }
  
  public String getMiddleName()
  {
    return this.middleName;
  }
  
  public void setMiddleName(String middleName)
  {
    this.middleName = middleName;
  }
  
  public String getRoom()
  {
    return this.room;
  }
  
  public void setRoom(String room)
  {
    this.room = room;
  }
  
  public String getEmployeeID()
  {
    return this.employeeID;
  }
  
  public void setEmployeeID(String employeeID)
  {
    this.employeeID = employeeID;
  }
  
  public String getHhsID() {
    return this.hhsID;
  }
  
  public void setHhsID(String hhsID) {
    this.hhsID = hhsID;
  }
  
  public String getState()
  {
    return this.state;
  }
  
  public void setState(String state)
  {
    this.state = state;
  }
  
  public float getStatus()
  {
    return this.status;
  }
  
  public void setStatus(float status)
  {
    this.status = status;
  }
  
  public String getSubAgency()
  {
    return this.subAgency;
  }
  
  public void setSubAgency(String subAgency)
  {
    this.subAgency = subAgency;
  }
  
  public String getTitle()
  {
    return this.title;
  }
  
  public void setTitle(String title)
  {
    this.title = title;
  }
  
  public boolean isTranShare()
  {
    return this.tranShare;
  }
  
  public void setTranShare(boolean tranShare)
  {
    this.tranShare = tranShare;
  }
  
  public String getZip()
  {
    return this.zip;
  }
  
  public void setZip(String zip)
  {
    this.zip = zip;
  }
  
  public String getHomeAddress()
  {
    return this.homeAddress;
  }
  
  public void setHomeAddress(String homeAddress)
  {
    this.homeAddress = homeAddress;
  }
  
  public String getHomeUnit()
  {
    return this.homeUnit;
  }
  
  public void setHomeUnit(String homeUnit)
  {
    this.homeUnit = homeUnit;
  }
  
  public String getPhone()
  {
    return this.phone;
  }
  
  public void setPhone(String phone)
  {
    this.phone = phone;
  }
  
  public String getWorkHourStart()
  {
    return this.workHourStart;
  }
  
  public void setWorkHourStart(String workHourStart)
  {
    this.workHourStart = workHourStart;
  }
  
  public String getWorkHourEnd()
  {
    return this.workHourEnd;
  }
  
  public void setWorkHourEnd(String workHourEnd)
  {
    this.workHourEnd = workHourEnd;
  }
  
  public String getOfficeCity()
  {
    return this.officeCity;
  }
  
  public void setOfficeCity(String officeCity)
  {
    this.officeCity = officeCity;
  }
  
  public String getOfficeState()
  {
    return this.officeState;
  }
  
  public void setOfficeState(String officeState)
  {
    this.officeState = officeState;
  }
  
  public String getOfficeZip()
  {
    return this.officeZip;
  }
  
  public void setOfficeZip(String officeZip)
  {
    this.officeZip = officeZip;
  }
  
  public String getOfficeAddress()
  {
    return this.officeAddress;
  }
  
  public void setOfficeAddress(String officeAddress)
  {
    this.officeAddress = officeAddress;
  }
  
  public String getName()
  {
    return this.name;
  }
  
  public void setName(String name)
  {
    this.name = name;
  }
  
  public String getAddress()
  {
    String addr = "";
    if ((null != this.homeAddress) && (0 < this.homeAddress.length()))
    {
      addr = addr + this.homeAddress;
    }
    if ((null != this.homeUnit) && (0 < this.homeUnit.length()))
    {
      addr = addr + ", Unit " + this.homeUnit;
    }
    if (null != this.city)
    {
      addr = addr + ", " + this.city;
    }
    if (null != this.state)
    {
      addr = addr + ", " + this.state;
    }
    if (null != this.zip)
    {
      addr = addr + " " + this.zip;
    }
    return addr;
  }
  
  public String getLot()
  {
    if ((this.lotSpace != null) && (0 < this.lotSpace.length()))
    {
      int pos = this.lotSpace.indexOf("-");
      if (pos < 0)
      {

        return this.lotSpace;
      }
      

      return this.lotSpace.substring(0, pos);
    }
    


    return "";
  }
  

  public String getSpaceNumber()
  {
    if ((this.lotSpace != null) && (2 < this.lotSpace.length()))
    {
      int pos = this.lotSpace.indexOf("-");
      if (pos < 0)
      {

        return "";
      }
      

      if (pos < this.lotSpace.length() - 1)
      {
        return this.lotSpace.substring(pos + 1);
      }
      

      return "";
    }
    



    return "";
  }
  
  public String getRegion()
  {
    return this.region;
  }
  
  public void setRegion(String region) {
    this.region = region;
  }
  
  public String getRegionName() {
    return this.regionName;
  }
  
  public void setRegionName(String regionName) {
    this.regionName = regionName;
  }
  
  public String getPermitNumber() {
    return this.permitNumber;
  }
  
  public void setPermitNumber(String permitNumber) {
    this.permitNumber = permitNumber;
  }
  
  public Date getPermitDate() {
    return this.permitDate;
  }
  
  public void setPermitDate(Date permitDate) {
    this.permitDate = permitDate;
  }
  
  public boolean isHeadquarter()
  {
    return "HQ".equals(this.region);
  }
  
  public String getSupervisorID() {
    return this.supervisorID;
  }
  
  public void setSupervisorID(String supervisorID) {
    this.supervisorID = supervisorID;
  }
  
  public String getPriority() {
    return this.priority;
  }
  
  public void setPriority(String priority) {
    this.priority = priority;
  }
  
  public boolean isInactive()
  {
    return this.inactive;
  }
  
  public void setInactive(boolean inactive) {
    this.inactive = inactive;
  }
  
  public Date getDateEntered() {
    return this.dateEntered;
  }
  
  public void setDateEntered(Date dateEntered) {
    this.dateEntered = dateEntered;
  }
  
  public Date getDateAppUpdated() {
    return this.dateAppUpdated;
  }
  
  public void setDateAppUpdated(Date dateAppUpdated) {
    this.dateAppUpdated = dateAppUpdated;
  }
  
  public Date getTranShareDate() {
    if (this.dateAppUpdated == null) {
      return this.dateEntered;
    }
    return this.dateAppUpdated;
  }
  
  public Date getLastExportedToBF()
  {
    return this.lastExportedToBF;
  }
  
  public void setLastExportedToBF(Date lastExportedToBF) {
    this.lastExportedToBF = lastExportedToBF;
  }
  
  public boolean isParkingEligible() {
    return this.parkingEligible;
  }
  
  public void setParkingEligible(boolean parkingEligible) {
    this.parkingEligible = parkingEligible;
  }
  
  public boolean isTranshareEligible() {
    return this.transhareEligible;
  }
  
  public void setTranshareEligible(boolean transhareEligible) {
    this.transhareEligible = transhareEligible;
  }
}
