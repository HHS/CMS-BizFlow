package com.handysoft.hhs.transhare.model;

import com.handysoft.hhs.transhare.services.CommonManager;
import com.hs.bf.web.beans.HWSessionInfo;
import java.io.Serializable;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;
import javax.servlet.http.HttpServletRequest;
import org.springframework.web.bind.ServletRequestUtils;










public class BaseModel
  implements Serializable
{
  static final long serialVersionUID = 1L;
  private long id = -1L;
  private String wihCommand = "";
  private HWSessionInfo hwSessionInfo = new HWSessionInfo();
  private String sessioninfo = "";
  private String svrid = "";
  private int procid;
  private String responsegroupid = "";
  private int workseq;
  private int actid;
  private int appseq;
  private String browser = "";
  private String lang = "";
  private String timeformat = "";
  private TimeZone timezone = null;
  private String agenturl = "";
  private boolean readOnly = false;
  private String controlAction = "";
  private String activityName = "";
  
  protected CommonManager commonManager;
  
  public CommonManager getCommonManager()
  {
    return this.commonManager;
  }
  
  public void setCommonManager(CommonManager commonManager)
  {
    this.commonManager = commonManager;
  }
  
  public long getId() {
    return this.id;
  }
  
  public void setId(long id) {
    this.id = id;
  }
  
  public String getWihCommand() {
    return this.wihCommand;
  }
  
  public void setWihCommand(String wihCommand) {
    this.wihCommand = wihCommand;
  }
  
  public String getSessioninfo() {
    return this.sessioninfo;
  }
  
  public void setSessioninfo(String sessioninfo) {
    this.sessioninfo = sessioninfo;
    this.hwSessionInfo.setSessionInfo(sessioninfo);
  }
  
  public HWSessionInfo getHwSessionInfo() {
    return this.hwSessionInfo;
  }
  
  public String getCurrentUserId()
  {
    if (this.hwSessionInfo != null)
    {
      return this.hwSessionInfo.get("USERID");
    }
    

    return null;
  }
  
  public String getSvrid()
  {
    return this.svrid;
  }
  
  public void setSvrid(String svrid) {
    this.svrid = svrid;
  }
  
  public int getProcid() {
    return this.procid;
  }
  
  public void setProcid(int procid) {
    this.procid = procid;
  }
  
  public String getResponsegroupid() {
    return this.responsegroupid;
  }
  
  public void setResponsegroupid(String responsegroupid) {
    this.responsegroupid = responsegroupid;
  }
  
  public int getWorkseq() {
    return this.workseq;
  }
  
  public void setWorkseq(int workseq) {
    this.workseq = workseq;
  }
  
  public int getActid() {
    return this.actid;
  }
  
  public void setActid(int actid) {
    this.actid = actid;
  }
  
  public int getAppseq() {
    return this.appseq;
  }
  
  public void setAppseq(int appseq) {
    this.appseq = appseq;
  }
  
  public String getBrowser() {
    return this.browser;
  }
  
  public void setBrowser(String browser) {
    this.browser = browser;
  }
  
  public String getLang() {
    return this.lang;
  }
  
  public void setLang(String lang) {
    this.lang = lang;
  }
  
  public String getTimeformat() {
    return this.timeformat;
  }
  
  public void setTimeformat(String timeformat) {
    this.timeformat = timeformat;
  }
  
  public TimeZone getTimezone() {
    return this.timezone;
  }
  
  public void setTimezone(String timezone) {
    if ("".equals(timezone))
    {
      Calendar calendar = new GregorianCalendar();
      this.timezone = calendar.getTimeZone();
    }
    else
    {
      try
      {
        this.timezone = TimeZone.getTimeZone(timezone);
      }
      catch (Exception e)
      {
        Calendar calendar = new GregorianCalendar();
        this.timezone = calendar.getTimeZone();
      }
    }
  }
  
  public String getAgenturl() {
    return this.agenturl;
  }
  
  public void setAgenturl(String agenturl) {
    this.agenturl = agenturl;
  }
  
  public boolean isReadOnly()
  {
    return this.readOnly;
  }
  
  public void setReadOnly(String readOnly)
  {
    this.readOnly = (("true".equals(readOnly)) || ("y".equals(readOnly)));
  }
  
  public String getControlAction()
  {
    return this.controlAction;
  }
  
  public void setControlAction(String controlAction)
  {
    this.controlAction = controlAction;
  }
  
  public String getActivityName() {
    return this.activityName;
  }
  
  public void setActivityName(String activityName) {
    this.activityName = activityName;
  }
  
  public void setWIHParameters(HttpServletRequest request) {
    setWihCommand(ServletRequestUtils.getStringParameter(request, "wihCommand", ""));
    setSessioninfo(ServletRequestUtils.getStringParameter(request, "sessioninfo", ""));
    setSvrid(ServletRequestUtils.getStringParameter(request, "svrid", ""));
    setProcid(ServletRequestUtils.getIntParameter(request, "procid", 0));
    setResponsegroupid(ServletRequestUtils.getStringParameter(request, "responsegroupid", ""));
    setWorkseq(ServletRequestUtils.getIntParameter(request, "workseq", 0));
    setActid(ServletRequestUtils.getIntParameter(request, "actid", 0));
    setAppseq(ServletRequestUtils.getIntParameter(request, "appseq", 0));
    setBrowser(ServletRequestUtils.getStringParameter(request, "browser", ""));
    setLang(ServletRequestUtils.getStringParameter(request, "lang", ""));
    setTimeformat(ServletRequestUtils.getStringParameter(request, "timeformat", ""));
    setTimezone(ServletRequestUtils.getStringParameter(request, "timezone", ""));
    setAgenturl(ServletRequestUtils.getStringParameter(request, "agenturl", ""));
    setActivityName(ServletRequestUtils.getStringParameter(request, "actname", ""));
    setReadOnly(ServletRequestUtils.getStringParameter(request, "readOnly", ""));
  }
}
