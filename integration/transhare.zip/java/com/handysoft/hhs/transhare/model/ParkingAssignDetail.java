package com.handysoft.hhs.transhare.model;


public class ParkingAssignDetail
{
  private int procid;
  
  private String agency;
  
  private String memberid;
  
  private int seq;
  
  private int status;
  
  private String employeeID;
  private String employeeName;
  
  public int getProcid()
  {
    return this.procid;
  }
  
  public void setProcid(int procid) {
    this.procid = procid;
  }
  
  public String getAgency() {
    return this.agency;
  }
  
  public void setAgency(String agency) {
    this.agency = agency;
  }
  
  public int getSeq() {
    return this.seq;
  }
  
  public void setSeq(int seq) {
    this.seq = seq;
  }
  
  public String getEmployeeID() {
    return this.employeeID;
  }
  
  public void setEmployeeID(String employeeID) {
    this.employeeID = employeeID;
  }
  
  public String getEmployeeName() {
    return this.employeeName;
  }
  
  public void setEmployeeName(String employeeName) {
    this.employeeName = employeeName;
  }
  
  public String getMemberid() {
    return this.memberid;
  }
  
  public void setMemberid(String memberid) {
    this.memberid = memberid;
  }
  
  public int getStatus()
  {
    return this.status;
  }
  
  public void setStatus(int status)
  {
    this.status = status;
  }
}
