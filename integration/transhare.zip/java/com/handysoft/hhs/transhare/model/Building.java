package com.handysoft.hhs.transhare.model;

import com.hs.frmwk.json.JSONException;
import com.hs.frmwk.json.JSONObject;
import java.io.Serializable;




public class Building
  implements Serializable
{
  private String id;
  private String name;
  private String address;
  private String city;
  private String state;
  private String zip;
  
  public String getId()
  {
    return this.id;
  }
  
  public void setId(String id)
  {
    this.id = id;
  }
  
  public String getName()
  {
    return this.name;
  }
  
  public void setName(String name)
  {
    this.name = name;
  }
  
  public String getAddress()
  {
    return this.address;
  }
  
  public void setAddress(String address)
  {
    this.address = address;
  }
  
  public String getCity()
  {
    return this.city;
  }
  
  public void setCity(String city)
  {
    this.city = city;
  }
  
  public String getState()
  {
    return this.state;
  }
  
  public void setState(String state)
  {
    this.state = state;
  }
  
  public String getZip()
  {
    return this.zip;
  }
  
  public void setZip(String zip)
  {
    this.zip = zip;
  }
  
  public JSONObject toJSONObject() throws JSONException
  {
    JSONObject o = new JSONObject();
    o.put("id", this.id);
    o.put("name", this.name);
    o.put("address", this.address);
    o.put("city", this.city);
    o.put("state", this.state);
    o.put("zip", this.zip);
    return o;
  }
}
