package com.handysoft.hhs.transhare.model;



public class BizFlowOU
  extends BaseModel
{
  private String name;
  
  private String memberID;
  

  public String getName()
  {
    return this.name;
  }
  
  public void setName(String name)
  {
    this.name = name;
  }
  
  public String getMemberID()
  {
    return this.memberID;
  }
  
  public void setMemberID(String memberID)
  {
    this.memberID = memberID;
  }
}
