package com.handysoft.hhs.transhare.model;

import com.handysoft.hhs.transhare.Constants;
import java.io.Serializable;




public class ParkingAppStatus
  implements Serializable
{
  private String employeeID;
  private int procid = -1;
  private String status;
  private String permitCode;
  private String primaryCarpoolerID;
  private String primaryCarpoolerName;
  
  public boolean isSubmitted()
  {
    return this.procid != -1;
  }
  
  public boolean isAccepted()
  {
    return (isSubmitted()) && ("accept".equals(this.status));
  }
  
  public boolean isCarpooler()
  {
    return (isSubmitted()) && (("A".equals(this.permitCode)) || ("A4".equals(this.permitCode)) || ("A3".equals(this.permitCode)) || ("A2".equals(this.permitCode)) || ("VP".equals(this.permitCode)));
  }
  







  public String getEmployeeID()
  {
    return this.employeeID;
  }
  
  public void setEmployeeID(String employeeID)
  {
    this.employeeID = employeeID;
  }
  
  public int getProcid()
  {
    return this.procid;
  }
  
  public void setProcid(int procid)
  {
    this.procid = procid;
  }
  
  public String getStatus()
  {
    return this.status;
  }
  
  public void setStatus(String status)
  {
    this.status = status;
  }
  
  public String getPermitCode()
  {
    return this.permitCode;
  }
  
  public void setPermitCode(String permitCode)
  {
    this.permitCode = permitCode;
  }
  
  public String getPermitCodeStr() {
    return Constants.getPermitCodeStr(this.permitCode);
  }
  
  public String getPrimaryCarpoolerID()
  {
    return this.primaryCarpoolerID;
  }
  
  public void setPrimaryCarpoolerID(String primaryCarpoolerID)
  {
    this.primaryCarpoolerID = primaryCarpoolerID;
  }
  
  public String getPrimaryCarpoolerName()
  {
    return this.primaryCarpoolerName;
  }
  
  public void setPrimaryCarpoolerName(String primaryCarpoolerName)
  {
    this.primaryCarpoolerName = primaryCarpoolerName;
  }
}
