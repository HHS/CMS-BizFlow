package com.handysoft.hhs.transhare.model;

import java.util.List;






public class ParkingAssignItem
  extends BaseModel
{
  private String agency;
  private String memberid;
  private int lotCount;
  private List<ParkingAssignDetail> items;
  private List<DBLookUp> agencies;
  private List<Employee> executives;
  
  public String getAgency()
  {
    return this.agency;
  }
  
  public void setAgency(String agency) {
    this.agency = agency;
  }
  
  public int getLotCount() {
    return this.lotCount;
  }
  
  public void setLotCount(int lotCount) {
    this.lotCount = lotCount;
  }
  
  public String getMemberid() {
    return this.memberid;
  }
  
  public void setMemberid(String memberid) {
    this.memberid = memberid;
  }
  
  public List<ParkingAssignDetail> getItems() {
    return this.items;
  }
  
  public void setItems(List<ParkingAssignDetail> items) {
    this.items = items;
  }
  
  public List<DBLookUp> getAgencies() {
    return this.agencies;
  }
  
  public void setAgencies(List<DBLookUp> agencies) {
    this.agencies = agencies;
  }
  
  public List<Employee> getExecutives() {
    return this.executives;
  }
  
  public void setExecutives(List<Employee> executives) {
    this.executives = executives;
  }
}
