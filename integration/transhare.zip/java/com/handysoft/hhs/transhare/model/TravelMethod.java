package com.handysoft.hhs.transhare.model;

import java.io.Serializable;






public class TravelMethod
  implements Serializable
{
  private int id;
  private String region;
  private String travelMethod;
  private int sortOrder;
  
  public int getId()
  {
    return this.id;
  }
  
  public void setId(int id)
  {
    this.id = id;
  }
  
  public String getRegion()
  {
    return this.region;
  }
  
  public void setRegion(String region)
  {
    this.region = region;
  }
  
  public String getTravelMethod()
  {
    return this.travelMethod;
  }
  
  public void setTravelMethod(String travelMethod)
  {
    this.travelMethod = travelMethod;
  }
  
  public int getSortOrder()
  {
    return this.sortOrder;
  }
  
  public void setSortOrder(int sortOrder)
  {
    this.sortOrder = sortOrder;
  }
}
