package com.handysoft.hhs.transhare.model;


public class ParkingCarTag
  extends BaseModel
{
  static final long serialVersionUID = 2L;
  
  private int procid;
  
  private String employeeID;
  
  private String carTag;
  
  private String carState;
  

  public ParkingCarTag() {}
  

  public ParkingCarTag(int procid, String employeeID, String carTag, String carState)
  {
    this.procid = procid;
    this.employeeID = employeeID;
    this.carTag = carTag;
    this.carState = carState;
  }
  
  public int getProcid()
  {
    return this.procid;
  }
  
  public void setProcid(int procid)
  {
    this.procid = procid;
  }
  
  public String getEmployeeID()
  {
    return this.employeeID;
  }
  
  public void setEmployeeID(String employeeID)
  {
    this.employeeID = employeeID;
  }
  
  public String getCarTag()
  {
    return this.carTag;
  }
  
  public void setCarTag(String carTag)
  {
    this.carTag = carTag;
  }
  
  public String getCarState()
  {
    return this.carState;
  }
  
  public void setCarState(String carState)
  {
    this.carState = carState;
  }
}
