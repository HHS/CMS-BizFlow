package com.handysoft.hhs.transhare.model;


public class BizFlowUser
  extends BaseModel
{
  private String loginID;
  
  private String name;
  
  private String customD;
  
  private String email;
  
  private String memberID;
  

  public String getLoginID()
  {
    return this.loginID;
  }
  
  public void setLoginID(String loginID)
  {
    this.loginID = loginID;
  }
  
  public String getName()
  {
    return this.name;
  }
  
  public void setName(String name)
  {
    this.name = name;
  }
  
  public String getCustomD()
  {
    return this.customD;
  }
  
  public void setCustomD(String customD)
  {
    this.customD = customD;
  }
  
  public String getEmail()
  {
    return this.email;
  }
  
  public void setEmail(String email)
  {
    this.email = email;
  }
  
  public String getMemberID()
  {
    return this.memberID;
  }
  
  public void setMemberID(String memberID)
  {
    this.memberID = memberID;
  }
}
