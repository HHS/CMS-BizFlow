package com.handysoft.hhs.transhare.model;

import com.handysoft.hhs.transhare.TranshareProperties;
import com.handysoft.hhs.transhare.services.CommonManager;
import java.util.ArrayList;
import java.util.List;








public class ParkingAppCarpool
  extends BaseModel
{
  static final long serialVersionUID = 2L;
  private int procid;
  private String employeeID;
  private boolean driver;
  private List<ParkingCarTag> carTagList;
  private String employeeName;
  private String employeeFirstName;
  private String employeeLastName;
  private String employeeMiddleName;
  private String employeeTitle;
  private String employeeBuilding;
  private String employeeRoom;
  private String employeeAgency;
  private String employeeSubAgency;
  private String employeeCity;
  private String employeeState;
  private String employeeZip;
  private String employeeHomeAddress;
  private String employeeHomeUnit;
  private String employeeLotSpace;
  private String employeePhone;
  private String employeeWorkHourStart;
  private String employeeWorkHourEnd;
  private String employeeEmail;
  private String carTag1;
  private String carTag2;
  private String carTag3;
  private String carTag4;
  private String carState1;
  private String carState2;
  private String carState3;
  private String carState4;
  
  public ParkingAppCarpool()
  {
    this.carTagList = new ArrayList();
  }
  
  public ParkingAppCarpool(int procid, String employeeID)
  {
    this();
    this.procid = procid;
    this.employeeID = employeeID;
  }
  
  private String getCarState(int idx)
  {
    if ((this.carTagList != null) && (idx <= this.carTagList.size()))
    {
      return ((ParkingCarTag)this.carTagList.get(idx - 1)).getCarState();
    }
    

    return this.employeeState;
  }
  
  private String getCarTag(int idx)
  {
    if ((this.carTagList != null) && (idx <= this.carTagList.size()))
    {
      return ((ParkingCarTag)this.carTagList.get(idx - 1)).getCarTag();
    }
    

    return null;
  }
  

  public String getCarState1()
  {
    return getCarState(1);
  }
  
  public void setCarState1(String carState1)
  {
    this.carState1 = carState1;
  }
  
  public String getCarState2()
  {
    return getCarState(2);
  }
  
  public void setCarState2(String carState2)
  {
    this.carState2 = carState2;
  }
  
  public String getCarState3()
  {
    return getCarState(3);
  }
  
  public void setCarState3(String carState3)
  {
    this.carState3 = carState3;
  }
  
  public String getCarState4()
  {
    return getCarState(4);
  }
  
  public void setCarState4(String carState4)
  {
    this.carState4 = carState4;
  }
  
  public String getCarTag1()
  {
    return getCarTag(1);
  }
  
  public void setcarTag1(String carTag1)
  {
    this.carTag1 = carTag1;
  }
  
  public String getCarTag2()
  {
    return getCarTag(2);
  }
  
  public void setcarTag2(String carTag2)
  {
    this.carTag2 = carTag2;
  }
  
  public String getCarTag3()
  {
    return getCarTag(3);
  }
  
  public void setcarTag3(String carTag3)
  {
    this.carTag3 = carTag3;
  }
  
  public String getCarTag4()
  {
    return getCarTag(4);
  }
  
  public void setcarTag4(String carTag4)
  {
    this.carTag4 = carTag4;
  }
  

  public int getProcid()
  {
    return this.procid;
  }
  
  public void setProcid(int procid)
  {
    this.procid = procid;
  }
  
  public String getEmployeeID()
  {
    return this.employeeID;
  }
  
  public void setEmployeeID(String employeeID)
  {
    this.employeeID = employeeID;
  }
  
  public String getEmployeeWorkHourStart()
  {
    if (this.employeeWorkHourStart == null)
    {
      return TranshareProperties.get("default.workHourStart");
    }
    

    return this.employeeWorkHourStart;
  }
  

  public void setEmployeeWorkHourStart(String employeeWorkHourStart)
  {
    this.employeeWorkHourStart = employeeWorkHourStart;
  }
  
  public String getEmployeeWorkHourEnd()
  {
    if (this.employeeWorkHourEnd == null)
    {
      return TranshareProperties.get("default.workHourEnd");
    }
    

    return this.employeeWorkHourEnd;
  }
  

  public void setEmployeeWorkHourEnd(String employeeWorkHourEnd)
  {
    this.employeeWorkHourEnd = employeeWorkHourEnd;
  }
  
  public boolean isDriver()
  {
    return this.driver;
  }
  
  public void setDriver(boolean driver)
  {
    this.driver = driver;
  }
  
  public List<ParkingCarTag> getCarTagList()
  {
    return this.carTagList;
  }
  
  public void setCarTagList(List<ParkingCarTag> carTagList)
  {
    this.carTagList = carTagList;
  }
  
  public void assignCarTagList()
  {
    this.carTagList = new ArrayList();
    if ((this.carTag1 != null) && (0 < this.carTag1.length()))
    {
      this.carTagList.add(new ParkingCarTag(getProcid(), getEmployeeID(), this.carTag1, this.carState1));
    }
    if ((this.carTag2 != null) && (0 < this.carTag2.length()))
    {
      this.carTagList.add(new ParkingCarTag(getProcid(), getEmployeeID(), this.carTag2, this.carState2));
    }
    if ((this.carTag3 != null) && (0 < this.carTag3.length()))
    {
      this.carTagList.add(new ParkingCarTag(getProcid(), getEmployeeID(), this.carTag3, this.carState3));
    }
    if ((this.carTag4 != null) && (0 < this.carTag4.length()))
    {
      this.carTagList.add(new ParkingCarTag(getProcid(), getEmployeeID(), this.carTag4, this.carState4));
    }
  }
  
  public String getEmployeeName() {
    return this.employeeName;
  }
  
  public void setEmployeeName(String employeeName) {
    this.employeeName = employeeName;
  }
  
  public String getEmployeeFirstName()
  {
    return this.employeeFirstName;
  }
  
  public void setEmployeeFirstName(String employeeFirstName)
  {
    this.employeeFirstName = employeeFirstName;
  }
  
  public String getEmployeeLastName()
  {
    return this.employeeLastName;
  }
  
  public void setEmployeeLastName(String employeeLastName)
  {
    this.employeeLastName = employeeLastName;
  }
  
  public String getEmployeeMiddleName()
  {
    return this.employeeMiddleName;
  }
  
  public void setEmployeeMiddleName(String employeeMiddleName)
  {
    this.employeeMiddleName = employeeMiddleName;
  }
  
  public String getEmployeeTitle()
  {
    return this.employeeTitle;
  }
  
  public void setEmployeeTitle(String employeeTitle)
  {
    this.employeeTitle = employeeTitle;
  }
  
  public String getEmployeeBuilding()
  {
    return this.employeeBuilding;
  }
  
  public void setEmployeeBuilding(String employeeBuilding)
  {
    this.employeeBuilding = employeeBuilding;
  }
  
  public String getEmployeeRoom()
  {
    return this.employeeRoom;
  }
  
  public void setEmployeeRoom(String employeeRoom)
  {
    this.employeeRoom = employeeRoom;
  }
  
  public String getEmployeePhone()
  {
    return this.employeePhone;
  }
  
  public void setEmployeePhone(String employeePhone)
  {
    this.employeePhone = employeePhone;
  }
  
  public String getEmployeeAgency()
  {
    return this.employeeAgency;
  }
  
  public void setEmployeeAgency(String employeeAgency)
  {
    this.employeeAgency = employeeAgency;
  }
  
  public String getEmployeeSubAgency()
  {
    return this.employeeSubAgency;
  }
  
  public void setEmployeeSubAgency(String employeeSubAgency)
  {
    this.employeeSubAgency = employeeSubAgency;
  }
  
  public String getEmployeeCity()
  {
    return this.employeeCity;
  }
  
  public void setEmployeeCity(String employeeCity)
  {
    this.employeeCity = employeeCity;
  }
  
  public String getEmployeeState()
  {
    return this.employeeState;
  }
  
  public void setEmployeeState(String employeeState)
  {
    this.employeeState = employeeState;
  }
  
  public String getEmployeeZip()
  {
    return this.employeeZip;
  }
  
  public void setEmployeeZip(String employeeZip)
  {
    this.employeeZip = employeeZip;
  }
  
  public String getEmployeeHomeAddress()
  {
    return this.employeeHomeAddress;
  }
  
  public void setEmployeeHomeAddress(String employeeHomeAddress)
  {
    this.employeeHomeAddress = employeeHomeAddress;
  }
  
  public String getEmployeeHomeUnit()
  {
    return this.employeeHomeUnit;
  }
  
  public void setEmployeeHomeUnit(String employeeHomeUnit)
  {
    this.employeeHomeUnit = employeeHomeUnit;
  }
  
  public String getEmployeeLotSpace()
  {
    return this.employeeLotSpace;
  }
  
  public void setEmployeeLotSpace(String employeeLotSpace)
  {
    this.employeeLotSpace = employeeLotSpace;
  }
  
  public String getEmployeeLot()
  {
    if ((this.employeeLotSpace != null) && (0 < this.employeeLotSpace.length()))
    {
      int pos = this.employeeLotSpace.indexOf("-");
      if (pos < 0)
      {

        return this.employeeLotSpace;
      }
      

      return this.employeeLotSpace.substring(0, pos);
    }
    


    return "";
  }
  

  public String getEmployeeSpaceNumber()
  {
    if ((this.employeeLotSpace != null) && (2 < this.employeeLotSpace.length()))
    {
      int pos = this.employeeLotSpace.indexOf("-");
      if (pos < 0)
      {

        return "";
      }
      

      if (pos < this.employeeLotSpace.length() - 1)
      {
        return this.employeeLotSpace.substring(pos + 1);
      }
      

      return "";
    }
    



    return "";
  }
  

  public void setEmployee(Employee employee)
  {
    this.employeeHomeUnit = employee.getHomeUnit();
    this.employeeHomeAddress = employee.getHomeAddress();
    this.employeeAgency = employee.getAgency();
    this.employeeBuilding = employee.getBuilding();
    this.employeeCity = employee.getCity();
    this.employeeFirstName = employee.getFirstName();
    this.employeeLastName = employee.getLastName();
    this.employeeMiddleName = employee.getMiddleName();
    this.employeeLotSpace = employee.getLotSpace();
    this.employeePhone = employee.getPhone();
    this.employeeRoom = employee.getRoom();
    this.employeeState = employee.getState();
    this.employeeSubAgency = employee.getSubAgency();
    this.employeeTitle = employee.getTitle();
    this.employeeZip = employee.getZip();
    this.employeeWorkHourStart = employee.getWorkHourStart();
    this.employeeWorkHourEnd = employee.getWorkHourEnd();
    this.employeeEmail = employee.getEmail();
  }
  
  public void collectCarTagList()
  {
    if ((this.carTag1 != null) && (0 < this.carTag1.length()))
    {
      if (this.carTagList == null)
      {
        this.carTagList = new ArrayList();
      }
      this.carTagList.add(new ParkingCarTag(getProcid(), getEmployeeID(), this.carTag1, this.carState1));
    }
    if ((this.carTag2 != null) && (0 < this.carTag2.length()))
    {
      if (this.carTagList == null)
      {
        this.carTagList = new ArrayList();
      }
      this.carTagList.add(new ParkingCarTag(getProcid(), getEmployeeID(), this.carTag2, this.carState2));
    }
    if ((this.carTag3 != null) && (0 < this.carTag3.length()))
    {
      if (this.carTagList == null)
      {
        this.carTagList = new ArrayList();
      }
      this.carTagList.add(new ParkingCarTag(getProcid(), getEmployeeID(), this.carTag3, this.carState3));
    }
    if ((this.carTag4 != null) && (0 < this.carTag4.length()))
    {
      if (this.carTagList == null)
      {
        this.carTagList = new ArrayList();
      }
      this.carTagList.add(new ParkingCarTag(getProcid(), getEmployeeID(), this.carTag4, this.carState4));
    }
  }
  
  public List<DBLookUp> getAllMySubAgency()
  {
    if (this.employeeAgency != null)
    {
      return this.commonManager.getSubAgency(this.employeeAgency);
    }
    

    return null;
  }
  
  public String getEmployeeEmail()
  {
    return this.employeeEmail;
  }
  
  public void setEmployeeEmail(String employeeEmail) {
    this.employeeEmail = employeeEmail;
  }
}
