package com.handysoft.hhs.transhare.model;

import com.hs.frmwk.json.JSONException;
import com.hs.frmwk.json.JSONObject;


public class DBLookUp
  extends BaseModel
{
  private String name;
  private String value;
  
  public String getName()
  {
    return this.name;
  }
  
  public void setName(String name) {
    this.name = name;
  }
  
  public String getValue() {
    return this.value;
  }
  
  public void setValue(String value) {
    this.value = value;
  }
  
  public JSONObject toJSONObject() throws JSONException
  {
    JSONObject o = new JSONObject();
    o.put("name", this.name);
    o.put("value", this.value);
    return o;
  }
  




  public String toString()
  {
    try
    {
      return toJSONObject().toString();
    }
    catch (JSONException e) {}
    
    return null;
  }
}
