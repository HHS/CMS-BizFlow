package com.handysoft.hhs.transhare.model;

import com.hs.frmwk.json.JSONException;
import com.hs.frmwk.json.JSONObject;
import java.io.Serializable;
import java.math.BigDecimal;





public class TranshareCost
  implements Serializable
{
  private int procid;
  private int travelMethodID;
  private String travelMethodName;
  private String toCompany;
  private String fromCompany;
  private BigDecimal toDailyCost;
  private BigDecimal fromDailyCost;
  private BigDecimal weeklyPassCost;
  private BigDecimal monthlyPassCost;
  private String toWorkModeName;
  private String fromWorkModeName;
  
  public int getProcid()
  {
    return this.procid;
  }
  
  public void setProcid(int procid)
  {
    this.procid = procid;
  }
  
  public int getTravelMethodID()
  {
    return this.travelMethodID;
  }
  
  public String getTravelMethodName()
  {
    return this.travelMethodName;
  }
  
  public void setTravelMethodName(String travelMethodName)
  {
    this.travelMethodName = travelMethodName;
  }
  
  public void setTravelMethodID(int travelMethodID)
  {
    this.travelMethodID = travelMethodID;
  }
  
  public String getToCompany()
  {
    return this.toCompany;
  }
  
  public void setToCompany(String toCompany)
  {
    this.toCompany = toCompany;
  }
  
  public String getFromCompany()
  {
    return this.fromCompany;
  }
  
  public void setFromCompany(String fromCompany)
  {
    this.fromCompany = fromCompany;
  }
  
  public BigDecimal getToDailyCost()
  {
    return this.toDailyCost;
  }
  
  public void setToDailyCost(BigDecimal toDailyCost)
  {
    this.toDailyCost = (toDailyCost != null ? toDailyCost.setScale(2) : toDailyCost);
  }
  
  public BigDecimal getFromDailyCost()
  {
    return this.fromDailyCost;
  }
  
  public void setFromDailyCost(BigDecimal fromDailyCost)
  {
    this.fromDailyCost = (fromDailyCost != null ? fromDailyCost.setScale(2) : fromDailyCost);
  }
  
  public BigDecimal getWeeklyPassCost()
  {
    return this.weeklyPassCost;
  }
  
  public void setWeeklyPassCost(BigDecimal weeklyPassCost)
  {
    this.weeklyPassCost = (weeklyPassCost != null ? weeklyPassCost.setScale(2) : weeklyPassCost);
  }
  
  public BigDecimal getMonthlyPassCost()
  {
    return this.monthlyPassCost;
  }
  
  public void setMonthlyPassCost(BigDecimal monthlyPassCost)
  {
    this.monthlyPassCost = (monthlyPassCost != null ? monthlyPassCost.setScale(2) : monthlyPassCost);
  }
  
  public String getToWorkModeName()
  {
    return this.toWorkModeName;
  }
  
  public void setToWorkModeName(String toWorkModeName)
  {
    this.toWorkModeName = toWorkModeName;
  }
  
  public String getFromWorkModeName()
  {
    return this.fromWorkModeName;
  }
  
  public void setFromWorkModeName(String fromWorkModeName)
  {
    this.fromWorkModeName = fromWorkModeName;
  }
  
  public JSONObject toJSON() throws JSONException {
    JSONObject o = new JSONObject();
    o.put("travelMethodID", this.travelMethodID);
    o.put("travelMethodName", this.travelMethodName);
    o.put("toCompany", this.toCompany);
    o.put("fromCompany", this.fromCompany);
    o.put("toDailyCost", this.toDailyCost);
    o.put("fromDailyCost", this.fromDailyCost);
    o.put("weeklyPassCost", this.weeklyPassCost);
    o.put("monthlyPassCost", this.monthlyPassCost);
    if (9 == this.travelMethodID)
    {
      o.put("toWorkModeName", this.toWorkModeName);
      o.put("fromWorkModeName", this.fromWorkModeName);
    }
    return o;
  }
  
  private boolean hasValue(String s)
  {
    return (s != null) && (0 < s.trim().length());
  }
  
  private boolean hasValue(BigDecimal s) {
    return (s != null) && (0.0F != s.floatValue());
  }
  
  private boolean isSetOnlyOne(BigDecimal c1, BigDecimal c2, BigDecimal c3) {
    return 1 == (hasValue(c1) ? 1 : 0) + (hasValue(c2) ? 1 : 0) + (hasValue(c3) ? 1 : 0);
  }
  
  public boolean validate()
  {
    if (9 == this.travelMethodID)
    {
      return (hasValue(this.toCompany)) && (hasValue(this.monthlyPassCost));
    }
    if (11 == this.travelMethodID)
    {
      return ((hasValue(this.toWorkModeName)) && (hasValue(this.toCompany)) && (isSetOnlyOne(this.toDailyCost, this.weeklyPassCost, this.monthlyPassCost))) || ((hasValue(this.fromWorkModeName)) && (hasValue(this.fromCompany)) && (isSetOnlyOne(this.fromDailyCost, this.weeklyPassCost, this.monthlyPassCost)));
    }
    


    return ((hasValue(this.toCompany)) && (isSetOnlyOne(this.toDailyCost, this.weeklyPassCost, this.monthlyPassCost))) || ((hasValue(this.fromCompany)) && (isSetOnlyOne(this.fromDailyCost, this.weeklyPassCost, this.monthlyPassCost)));
  }
}
