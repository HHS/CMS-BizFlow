package com.handysoft.hhs.transhare.model;

import com.handysoft.hhs.transhare.services.CommonManager;
import com.hs.frmwk.json.JSONArray;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;


public class TranshareApplication
  extends BaseModel
{
  private Employee employee;
  private String employeeID;
  private String purpose = "N";
  private String supervisorID;
  private String supervisorName;
  private boolean changedSupervisor;
  private Date supervisorVerifyDate;
  private String coordinatorID;
  private String coordinatorName;
  private Date coordinatorVerifyDate;
  private String workDaySchedule = "?";
  private int daysInOfficeEachMonth;
  private Date dateEntered;
  private Date approveDate;
  private String transhareNumber;
  private String benefit;
  private BigDecimal dailyCost;
  private BigDecimal weeklyCost;
  private BigDecimal monthlyCost;
  private BigDecimal total;
  private Date notToExceedDate;
  private String status;
  private String notes;
  private String comment;
  private List<TranshareCost> costs;
  private int notify = 7;
  private String messageForEmail;
  private String emailSubject;
  private String definitionVersion = "";
  
  public TranshareApplication()
  {
    this.employee = new Employee();
  }
  
  public String getEmployeeID()
  {
    return this.employeeID;
  }
  
  public void setEmployeeID(String employeeID)
  {
    this.employeeID = employeeID;
  }
  
  public String getPurpose()
  {
    return this.purpose;
  }
  
  public void setPurpose(String purpose)
  {
    this.purpose = purpose;
  }
  
  public String getSupervisorID()
  {
    return this.supervisorID;
  }
  
  public void setSupervisorID(String supervisorID)
  {
    this.supervisorID = supervisorID;
  }
  
  public Date getSupervisorVerifyDate()
  {
    return this.supervisorVerifyDate;
  }
  
  public void setSupervisorVerifyDate(Date supervisorVerifyDate)
  {
    this.supervisorVerifyDate = supervisorVerifyDate;
  }
  
  public String getCoordinatorID()
  {
    return this.coordinatorID;
  }
  
  public void setCoordinatorID(String coordinatorID)
  {
    this.coordinatorID = coordinatorID;
  }
  
  public Date getCoordinatorVerifyDate()
  {
    return this.coordinatorVerifyDate;
  }
  
  public void setCoordinatorVerifyDate(Date coordinatorVerifyDate)
  {
    this.coordinatorVerifyDate = coordinatorVerifyDate;
  }
  
  public String getWorkDaySchedule()
  {
    return this.workDaySchedule;
  }
  
  public void setWorkDaySchedule(String workDaySchedule)
  {
    this.workDaySchedule = workDaySchedule;
    if ("E".equals(workDaySchedule))
    {
      setDaysInOfficeEachMonth(20);
    }
    else if ("N".equals(workDaySchedule))
    {
      setDaysInOfficeEachMonth(18);
    }
    else if ("T".equals(workDaySchedule))
    {
      setDaysInOfficeEachMonth(16);
    }
  }
  
  public int getDaysInOfficeEachMonth()
  {
    return this.daysInOfficeEachMonth;
  }
  
  public void setDaysInOfficeEachMonth(int daysInOfficeEachMonth)
  {
    this.daysInOfficeEachMonth = daysInOfficeEachMonth;
  }
  
  public Date getDateEntered()
  {
    return this.dateEntered;
  }
  
  public void setDateEntered(Date dateEntered)
  {
    this.dateEntered = dateEntered;
  }
  
  public BigDecimal getDailyCost()
  {
    return this.dailyCost;
  }
  
  public void setDailyCost(BigDecimal dailyCost)
  {
    this.dailyCost = dailyCost;
  }
  
  public BigDecimal getWeeklyCost()
  {
    return this.weeklyCost;
  }
  
  public void setWeeklyCost(BigDecimal weeklyCost)
  {
    this.weeklyCost = weeklyCost;
  }
  
  public BigDecimal getMonthlyCost()
  {
    return this.monthlyCost;
  }
  
  public void setMonthlyCost(BigDecimal monthlyCost)
  {
    this.monthlyCost = monthlyCost;
  }
  
  public BigDecimal getTotal()
  {
    return this.total;
  }
  
  public void setTotal(BigDecimal total)
  {
    this.total = total;
  }
  
  public Date getNotToExceedDate()
  {
    return this.notToExceedDate;
  }
  
  public void setNotToExceedDate(Date notToExceedDate)
  {
    this.notToExceedDate = notToExceedDate;
  }
  
  public String getStatus()
  {
    return this.status;
  }
  
  public void setStatus(String status)
  {
    this.status = status;
  }
  
  public String getNotes()
  {
    return this.notes;
  }
  
  public void setNotes(String notes)
  {
    this.notes = notes;
  }
  
  public String getCostsJSON() throws Exception
  {
    JSONArray array = new JSONArray();
    if (this.costs != null)
    {
      for (TranshareCost c : this.costs)
      {
        array.put(c.toJSON());
      }
    }
    return array.toString();
  }
  
  public List<TranshareCost> getCosts()
  {
    return this.costs;
  }
  
  public void setCosts(List<TranshareCost> costs)
  {
    this.costs = costs;
  }
  
  public String getSupervisorName()
  {
    return this.supervisorName;
  }
  
  public void setSupervisorName(String supervisorName)
  {
    this.supervisorName = supervisorName;
  }
  
  public String getCoordinatorName()
  {
    return this.coordinatorName;
  }
  
  public void setCoordinatorName(String coordinatorName)
  {
    this.coordinatorName = coordinatorName;
  }
  
  public Date getApproveDate()
  {
    return this.approveDate;
  }
  
  public void setApproveDate(Date approveDate)
  {
    this.approveDate = approveDate;
  }
  
  public String getTranshareNumber()
  {
    return this.transhareNumber;
  }
  
  public void setTranshareNumber(String transhareNumber)
  {
    this.transhareNumber = transhareNumber;
  }
  
  public int getNotify()
  {
    return this.notify;
  }
  
  public void setNotify(int notify)
  {
    this.notify = notify;
  }
  
  public boolean isNotifyEnrollee()
  {
    return (this.notify & 0x1) == 1;
  }
  
  public boolean isNotifySupervisor() {
    return (this.notify & 0x2) == 2;
  }
  
  public boolean isNotifyCoordinator() {
    return (this.notify & 0x4) == 4;
  }
  
  public void setNotifyEnrollee(boolean checked)
  {
    if (checked)
    {
      this.notify |= 0x1;
    }
    else
    {
      this.notify &= 0xFFFFFFFE;
    }
  }
  
  public void setNotifySupervisor(boolean checked) {
    if (checked)
    {
      this.notify |= 0x2;
    }
    else
    {
      this.notify &= 0xFFFFFFFD;
    }
  }
  
  public void setNotifyCoordinator(boolean checked) {
    if (checked)
    {
      this.notify |= 0x4;
    }
    else
    {
      this.notify &= 0xFFFFFFFB;
    }
  }
  
  public String getBenefit()
  {
    return this.benefit;
  }
  
  public void setBenefit(String benefit)
  {
    this.benefit = benefit;
  }
  
  public String getComment()
  {
    return this.comment;
  }
  
  public void setComment(String comment)
  {
    this.comment = comment;
  }
  
  public boolean isChangedSupervisor()
  {
    return this.changedSupervisor;
  }
  
  public void setChangedSupervisor(boolean changedSupervisor)
  {
    this.changedSupervisor = changedSupervisor;
  }
  
  public void setEmployee(Employee employee)
  {
    this.employee = employee;
  }
  
  public Employee getEmployee()
  {
    return this.employee;
  }
  
  public List<DBLookUp> getAllMySubAgency()
  {
    if (this.employee.getAgency() != null)
    {
      return this.commonManager.getSubAgency(this.employee.getAgency());
    }
    

    return null;
  }
  
  public String getMessageForEmail()
  {
    return this.messageForEmail;
  }
  
  public void setMessageForEmail(String messageForEmail) {
    this.messageForEmail = messageForEmail;
  }
  
  public String getEmailSubject() {
    return this.emailSubject;
  }
  
  public void setEmailSubject(String emailSubject) {
    this.emailSubject = emailSubject;
  }
  
  public String getDefinitionVersion() {
    return this.definitionVersion;
  }
  
  public void setDefinitionVersion(String definitionVersion) {
    this.definitionVersion = definitionVersion;
  }
}
