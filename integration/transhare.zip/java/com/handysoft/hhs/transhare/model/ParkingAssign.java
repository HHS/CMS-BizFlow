package com.handysoft.hhs.transhare.model;

import java.util.List;






public class ParkingAssign
  extends BaseModel
{
  private List<ParkingAssignItem> items;
  
  public List<ParkingAssignItem> getItems()
  {
    return this.items;
  }
  
  public void setItems(List<ParkingAssignItem> items) {
    this.items = items;
  }
}
