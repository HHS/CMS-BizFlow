package com.handysoft.hhs.transhare.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;





public class WebCallUtil
{
  public static final String ACTION_RESULT_BEGIN = "<actionresult>";
  public static final String ACTION_RESULT_END = "</actionresult>";
  
  public static StringBuffer callURLandGetActionResult(String targetUrl, String fromToken, String endToken)
    throws Exception
  {
    StringBuffer sb = new StringBuffer();
    URL url = new URL(targetUrl);
    URLConnection urlConn = url.openConnection();
    BufferedReader in = new BufferedReader(new InputStreamReader(urlConn.getInputStream()));
    


    boolean bStarted = false;
    String inputLine; while ((inputLine = in.readLine()) != null)
    {
      if ((null != fromToken) && (null != endToken))
      {
        if (0 <= inputLine.indexOf(fromToken))
        {
          bStarted = true;
        }
        else if ((bStarted) && (0 <= inputLine.indexOf(endToken)))
        {
          int idx = inputLine.lastIndexOf(endToken);
          inputLine = inputLine.substring(0, idx + endToken.length());
          sb.append(inputLine);
          break;
        }
        
        if (bStarted)
        {
          sb.append(inputLine);
        }
      }
      else
      {
        sb.append(inputLine);
      }
    }
    in.close();
    
    if ((null != fromToken) && (null != endToken))
    {
      int idx1 = sb.indexOf(fromToken);
      sb.delete(0, idx1 + fromToken.length());
      

      int idx2 = sb.indexOf(endToken);
      sb.delete(idx2, sb.length());
    }
    

    return sb;
  }
}
