package com.handysoft.hhs.transhare.util;

import java.util.Date;
import java.util.TimeZone;
import javax.servlet.http.HttpServletRequest;
import org.springframework.web.bind.ServletRequestUtils;












public class CommandUtil
{
  public static boolean isFormSubmitted(HttpServletRequest request)
  {
    String formSubmitted = ServletRequestUtils.getStringParameter(request, "formSubmitted", "no");
    boolean isSubmitted = false;
    if ((null != formSubmitted) && (
      ("y".equalsIgnoreCase(formSubmitted)) || ("yes".equalsIgnoreCase(formSubmitted)))) {
      isSubmitted = true;
    }
    return isSubmitted;
  }
  
  public static Date getGMT()
  {
    TimeZone tz = TimeZone.getDefault();
    Date ret = new Date(new Date().getTime() - tz.getRawOffset());
    

    if (tz.inDaylightTime(ret))
    {
      Date dstDate = new Date(ret.getTime() - tz.getDSTSavings());
      


      if (tz.inDaylightTime(dstDate))
      {
        ret = dstDate;
      }
    }
    
    return ret;
  }
}
