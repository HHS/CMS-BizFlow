package com.handysoft.hhs.transhare;

import java.io.InputStream;
import java.util.Properties;




public class TranshareProperties
{
  private static Properties p = new Properties();
  
  public void setLocation(String location)
  {
    ClassLoader cl = getClass().getClassLoader();
    InputStream is = cl.getResourceAsStream(location);
    try
    {
      p.load(is);
    }
    catch (Exception e) {}
  }
  



  public static String get(String key)
  {
    return (String)p.get(key);
  }
  
  public static int getInt(String key) throws NumberFormatException
  {
    String v = get(key);
    return Integer.parseInt(v);
  }
}
