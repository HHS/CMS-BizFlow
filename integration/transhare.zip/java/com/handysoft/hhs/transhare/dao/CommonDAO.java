package com.handysoft.hhs.transhare.dao;

import com.handysoft.hhs.transhare.model.Building;
import com.handysoft.hhs.transhare.model.DBLookUp;
import com.handysoft.hhs.transhare.model.Employee;
import com.handysoft.hhs.transhare.model.TravelMethod;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;



public class CommonDAO
  extends SqlMapClientDaoSupport
{
  private Log log = null;
  

  public CommonDAO()
  {
    this.log = LogFactory.getLog(CommonDAO.class);
  }
  
  public Employee getEmployeeByID(String employeeID)
  {
    return (Employee)getSqlMapClientTemplate().queryForObject("getEmployeeByID", employeeID);
  }
  
  public List<Employee> getAllExecutiveByAgency(String agency)
  {
    return getSqlMapClientTemplate().queryForList("getAllExecutiveByAgency", agency);
  }
  
  public List<Map> searchEmployee(String name, String building, String exceptEmployeeID, String agency, int maxResultCount)
  {
    HashMap param = new HashMap();
    param.put("maxResultCount", new Integer(maxResultCount));
    param.put("name", name);
    param.put("building", building);
    param.put("exceptEmployeeID", exceptEmployeeID);
    param.put("agency", agency);
    return getSqlMapClientTemplate().queryForList("searchEmployee", param);
  }
  
  public List<Map> searchEmployeeEx(String name, String building, String exceptEmployeeID, String agency, int maxResultCount)
  {
    HashMap param = new HashMap();
    param.put("maxResultCount", new Integer(maxResultCount));
    param.put("name", name);
    param.put("building", building);
    param.put("exceptEmployeeID", exceptEmployeeID);
    param.put("agency", agency);
    return getSqlMapClientTemplate().queryForList("searchEmployeeEx", param);
  }
  
  public List<DBLookUp> getStates()
  {
    return getSqlMapClientTemplate().queryForList("getStates", null);
  }
  
  public List<DBLookUp> getRegions()
  {
    return getSqlMapClientTemplate().queryForList("getRegions", null);
  }
  
  public List<Building> getAllBuilding()
  {
    return getSqlMapClientTemplate().queryForList("getAllBuilding", null);
  }
  
  public Building getBuilding(String id)
  {
    return (Building)getSqlMapClientTemplate().queryForObject("getBuilding", id);
  }
  
  public List<TravelMethod> getTravelMethods(String region)
  {
    return getSqlMapClientTemplate().queryForList("getTravelMethods", region);
  }
  
  public List<DBLookUp> getAllAgency()
  {
    return getSqlMapClientTemplate().queryForList("getAllAgency", null);
  }
  
  public List<DBLookUp> getSubAgency(String agency)
  {
    return getSqlMapClientTemplate().queryForList("getSubAgency", agency);
  }
  
  public List getAllAgencyByProcId(int procid)
  {
    return getSqlMapClientTemplate().queryForList("getAllAgencyByProcId", Integer.valueOf(procid));
  }
  
  public void updateEmpInfo(Employee employee) throws SQLException
  {
    updateEmpInfo(employee.getEmployeeID(), employee.getHomeAddress(), employee.getHomeUnit(), employee.getCity(), employee.getState(), employee.getZip(), employee.getWorkHourStart(), employee.getWorkHourEnd(), employee.getAgency(), employee.getSubAgency(), employee.getRoom(), employee.getPhone(), employee.getEmail(), employee.getBuilding(), employee.getSupervisorID(), employee.getOfficeAddress(), employee.getOfficeCity(), employee.getOfficeState(), employee.getOfficeZip(), employee.getRegion());
  }
  




  public void updateEmpInfo(String employeeID, String street, String unit, String city, String state, String zip, String workHourStart, String workHourEnd, String agency, String subAgency, String room, String phone, String email, String building, String supervisorID, String officeStreet, String officeCity, String officeState, String officeZip, String region)
    throws SQLException
  {
    if ((employeeID == null) && (street == null) && (city == null))
    {
      return;
    }
    
    HashMap<String, String> param = new HashMap();
    param.put("employeeID", employeeID);
    param.put("homeAddress", street);
    param.put("homeUnit", unit);
    param.put("city", city);
    param.put("state", state);
    param.put("zip", zip);
    param.put("officeAddress", officeStreet);
    param.put("officeCity", officeCity);
    param.put("officeState", officeState);
    param.put("officeZip", officeZip);
    param.put("workHourStart", workHourStart);
    param.put("workHourEnd", workHourEnd);
    param.put("agency", agency);
    param.put("subAgency", (subAgency != null) && (0 != subAgency.length()) ? subAgency : null);
    param.put("room", room);
    param.put("phone", phone);
    param.put("email", email);
    param.put("building", building);
    param.put("supervisorID", supervisorID);
    param.put("region", region);
    getSqlMapClientTemplate().queryForObject("updateEmpInfo", param);
  }
  



  public List<Employee> getAllEmployeesToImportEX(String employeeID, String name, String building, String agency, String subAgency, String email, String region, String officeState, String officeCity, String newUserOnly, String lastExportedToBfFrom, String lastExportedToBfTo, String transshare, String transhareDateFrom, String transhareDateTo, int maxResultCount)
  {
    HashMap param = new HashMap();
    param.put("employeeID", employeeID);
    param.put("name", name);
    param.put("building", building);
    param.put("agency", agency);
    param.put("subAgency", subAgency);
    param.put("email", email);
    param.put("region", region);
    param.put("officeState", officeState);
    param.put("officeCity", officeCity);
    param.put("newUserOnly", newUserOnly);
    param.put("lastExportedToBfFrom", lastExportedToBfFrom);
    param.put("lastExportedToBfTo", lastExportedToBfTo);
    param.put("transshare", transshare);
    param.put("transhareDateFrom", transhareDateFrom);
    param.put("transhareDateTo", transhareDateTo);
    param.put("maxResultCount", new Integer(maxResultCount));
    return getSqlMapClientTemplate().queryForList("getAllEmployeesToImportEX", param);
  }
  



  public List<Employee> getAllEmployeesEX(String employeeID, String name, String building, String agency, String subAgency, String email, String region, String officeState, String officeCity, String newUserOnly, String lastExportedToBfFrom, String lastExportedToBfTo, String transshare, String transhareDateFrom, String transhareDateTo, int maxResultCount)
  {
    HashMap param = new HashMap();
    param.put("employeeID", employeeID);
    param.put("name", name);
    param.put("building", building);
    param.put("agency", agency);
    param.put("subAgency", subAgency);
    param.put("email", email);
    param.put("region", region);
    param.put("officeState", officeState);
    param.put("officeCity", officeCity);
    param.put("newUserOnly", newUserOnly);
    param.put("lastExportedToBfFrom", lastExportedToBfFrom);
    param.put("lastExportedToBfTo", lastExportedToBfTo);
    param.put("transshare", transshare);
    param.put("transhareDateFrom", transhareDateFrom);
    param.put("transhareDateTo", transhareDateTo);
    param.put("maxResultCount", new Integer(maxResultCount));
    return getSqlMapClientTemplate().queryForList("getAllEmployeesEX", param);
  }
  





  public List<Employee> getSingleUserToImport(String employeeId)
  {
    return getSqlMapClientTemplate().queryForList("getSingleUserToImport", employeeId);
  }
  
  public void updateImportDate(String employeeID)
  {
    getSqlMapClientTemplate().queryForObject("updateEmpLastImport", employeeID);
  }
  
  public List<Map> getLocatorChangeLog(int maxResultCount)
  {
    HashMap param = new HashMap();
    param.put("maxResultCount", new Integer(maxResultCount));
    return getSqlMapClientTemplate().queryForList("getLocatorChangeLog", param);
  }
  
  public void updateLocatorChangeLog(int ChangeLogID)
  {
    HashMap param = new HashMap();
    param.put("ChangeLogID", new Integer(ChangeLogID));
    getSqlMapClientTemplate().update("updateLocatorChangeLog", param);
  }
  
  public List<DBLookUp> getParkingPriorities()
  {
    return getSqlMapClientTemplate().queryForList("getParkingPriorities", null);
  }
  
  public List<DBLookUp> getParkingLots()
  {
    return getSqlMapClientTemplate().queryForList("getParkingLots", null);
  }
}
