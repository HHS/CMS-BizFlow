package com.handysoft.hhs.transhare.dao;

import com.handysoft.hhs.transhare.model.BizFlowOU;
import com.handysoft.hhs.transhare.model.BizFlowUser;
import com.handysoft.hhs.transhare.model.ParkingAssign;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;



public class BizFlowDAO
  extends SqlMapClientDaoSupport
{
  Log log = null;
  
  public BizFlowDAO()
  {
    this.log = LogFactory.getLog(BizFlowDAO.class);
  }
  
  public String getMemberID(String employeeID)
  {
    return (String)getSqlMapClientTemplate().queryForObject("getBizFlowMemberID", employeeID);
  }
  
  public String getLoginID(String employeeID)
  {
    return (String)getSqlMapClientTemplate().queryForObject("getBizFlowLoginID", employeeID);
  }
  
  public String getLoginIDbyHhsID(String hhsID)
  {
    return (String)getSqlMapClientTemplate().queryForObject("getBizFlowLoginIDbyHhsID", hhsID);
  }
  
  public String getUserGroupMemberID(String userGroupName, String userGroupHierarchyName)
  {
    HashMap param = new HashMap();
    param.put("userGroupName", userGroupName);
    param.put("userGroupHierarchyName", userGroupHierarchyName);
    return (String)getSqlMapClientTemplate().queryForObject("getUserGroupMemberID", param);
  }
  
  public String getEmployeeID(String memberID)
  {
    return (String)getSqlMapClientTemplate().queryForObject("getHHSEmployeeID", memberID);
  }
  
  public List<BizFlowUser> getAllBizFlowUsers()
  {
    return getSqlMapClientTemplate().queryForList("getAllBizFlowUsers");
  }
  
  public List<BizFlowUser> getAllBizFlowUsersByID_Email(String employeeID, String email, String loginID)
  {
    HashMap param = new HashMap();
    param.put("employeeID", employeeID);
    param.put("email", email);
    param.put("loginID", loginID);
    return getSqlMapClientTemplate().queryForList("getAllBizFlowUsersByID_Email", param);
  }
  
  public List<BizFlowOU> getAllBizFlowOUs(String parentDeptID)
  {
    return getSqlMapClientTemplate().queryForList("getAllBizFlowOUs", parentDeptID);
  }
  



  public void addUser(String memberID, String licType, String inheritType, String changePassword, String memberInfoID, String name, String loginID, String serverID, String deptID, String deptName, String shortName, String email, String password, String description, String deptCode, String empNo, String alias, String customA, String customB, String customC, String customD, String customE)
    throws SQLException
  {
    HashMap pmap = new HashMap();
    pmap.put("memberID", memberID);
    pmap.put("licType", licType);
    pmap.put("inheritType", inheritType);
    pmap.put("changePassword", changePassword);
    pmap.put("memberInfoID", memberInfoID);
    pmap.put("name", name);
    pmap.put("loginID", loginID);
    pmap.put("serverID", serverID);
    pmap.put("deptID", deptID);
    pmap.put("deptName", deptName);
    pmap.put("shortName", shortName);
    pmap.put("email", email);
    pmap.put("password", password);
    pmap.put("description", description);
    pmap.put("deptCode", deptCode);
    pmap.put("empNo", empNo);
    pmap.put("alias", alias);
    getSqlMapClientTemplate().insert("InsertOneBizFlowUser", pmap);
    
    pmap = new HashMap();
    pmap.put("memberID", memberID);
    pmap.put("customA", customA);
    pmap.put("customB", customB);
    pmap.put("customC", customC);
    pmap.put("customD", customD);
    pmap.put("customE", customE);
    getSqlMapClientTemplate().insert("InsertMemberInfo", pmap);
    
    pmap = new HashMap();
    pmap.put("groupID", "licsgrp004");
    pmap.put("memberID", memberID);
    getSqlMapClientTemplate().insert("AssignLicense", pmap);
    
    pmap = new HashMap();
    pmap.put("groupID", "licsgrp005");
    pmap.put("memberID", memberID);
    getSqlMapClientTemplate().insert("AssignLicense", pmap);
  }
  
  public void addOU(String memberID, String name, String parentDeptID) throws SQLException
  {
    HashMap pmap = new HashMap();
    pmap.put("memberID", memberID);
    pmap.put("name", name);
    pmap.put("parentDeptID", parentDeptID);
    getSqlMapClientTemplate().insert("InsertOneBizFlowOU", pmap);
  }
  
  public void addUserToGroup(String memberID, String userGroupID, String hierarchyID) throws SQLException
  {
    HashMap pmap = new HashMap();
    pmap.put("userGroupID", userGroupID);
    pmap.put("prtcp", memberID);
    pmap.put("hierarchyID", hierarchyID);
    getSqlMapClientTemplate().insert("InsertUsrGrpPrtcp", pmap);
  }
  
  public String getNextMemberID(String serverID)
  {
    HashMap pmap = new HashMap();
    pmap.put("serverID", serverID);
    getSqlMapClientTemplate().queryForObject("getNextMemberID", pmap);
    
    String newID = Integer.toString(((Integer)pmap.get("nextID")).intValue());
    
    if (newID.length() == 3) {
      newID = "0000000" + newID;
    } else if (newID.length() == 4) {
      newID = "000000" + newID;
    } else if (newID.length() == 5) {
      newID = "00000" + newID;
    } else if (newID.length() == 6) {
      newID = "0000" + newID;
    } else if (newID.length() == 7) {
      newID = "000" + newID;
    } else if (newID.length() == 8) {
      newID = "00" + newID;
    } else if (newID.length() == 9) {
      newID = "0" + newID;
    }
    return newID;
  }
  
  public ParkingAssign getParkingAssign(String agencyGroupName, String userGroupHierarchyName)
  {
    HashMap param = new HashMap();
    param.put("userGroupName", agencyGroupName);
    param.put("userGroupHierarchyName", userGroupHierarchyName);
    return (ParkingAssign)getSqlMapClientTemplate().queryForObject("getParkingAssignEmpty", param);
  }
  
  public void updateMemberEMail(String memberID, String email)
  {
    HashMap param = new HashMap();
    param.put("memberID", memberID);
    param.put("email", email);
    getSqlMapClientTemplate().update("updateMemberEMail", param);
  }
  
  public void updateEmailPassword(String loginID, String email, String password) throws SQLException
  {
    HashMap param = new HashMap();
    param.put("email", email);
    param.put("password", password);
    param.put("loginID", loginID);
    getSqlMapClientTemplate().update("updateMemberEMailPassword", param);
  }
  
  public void grantPrivilige(String email, String employeeID, String userGroupID, String hierarchyID, String addToUSRGRP) throws SQLException
  {
    HashMap<String, String> param = new HashMap();
    param.put("email", email);
    param.put("employeeID", employeeID);
    param.put("userGroupID", userGroupID);
    param.put("hierarchyID", hierarchyID);
    param.put("addToUSRGRP", addToUSRGRP);
    
    getSqlMapClientTemplate().queryForObject("linkLocatorUser", param);
  }
  
  public void syncLocatorUser(int changeLogID, String employeeID, String hhsID, String changeType, String oldValue, String newValue, String transhareHierarchyID, String transhareUserGroupID, String parkingHierarchyID, String parkingUserGroupID) throws SQLException
  {
    HashMap param = new HashMap();
    param.put("changeLogID", Integer.valueOf(changeLogID));
    param.put("employeeID", employeeID);
    param.put("hhsID", hhsID);
    param.put("changeType", changeType);
    param.put("oldValue", oldValue);
    param.put("newValue", newValue);
    param.put("transhareHierarchyID", transhareHierarchyID);
    param.put("transhareUserGroupID", transhareUserGroupID);
    param.put("parkingHierarchyID", parkingHierarchyID);
    param.put("parkingUserGroupID", parkingUserGroupID);
    getSqlMapClientTemplate().queryForObject("syncLocatorUser", param);
  }
  

  public Integer getTranshareAccessEligible(Integer procID, String memberID)
  {
    HashMap param = new HashMap();
    param.put("procID", procID);
    param.put("memberID", memberID);
    return (Integer)getSqlMapClientTemplate().queryForObject("getTranshareAccessEligible", param);
  }
}
