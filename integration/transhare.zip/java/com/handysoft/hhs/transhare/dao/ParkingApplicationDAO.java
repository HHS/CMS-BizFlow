package com.handysoft.hhs.transhare.dao;

import com.handysoft.hhs.transhare.model.ParkingAppCarpool;
import com.handysoft.hhs.transhare.model.ParkingAppStatus;
import com.handysoft.hhs.transhare.model.ParkingApplication;
import com.handysoft.hhs.transhare.model.ParkingCarTag;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;






public class ParkingApplicationDAO
  extends SqlMapClientDaoSupport
{
  private Log log = null;
  
  public ParkingApplicationDAO()
  {
    this.log = LogFactory.getLog(ParkingApplicationDAO.class);
  }
  






  public ParkingApplication getParkingApplicationByProcId(int procid)
  {
    return (ParkingApplication)getSqlMapClientTemplate().queryForObject("getParkingApplicationByProcId", Integer.valueOf(procid));
  }
  
  public List<ParkingAppCarpool> getParkingAppCarpool(int procid) {
    List<ParkingAppCarpool> carpools = getSqlMapClientTemplate().queryForList("getParkingAppCarpool", Integer.valueOf(procid));
    for (ParkingAppCarpool carpool : carpools)
    {
      carpool.setCarTagList(getParkingCarTag(procid, carpool.getEmployeeID()));
    }
    return carpools;
  }
  





  public String updateNextCarpooler(int procid)
  {
    HashMap param = new HashMap();
    param.put("procid", new Integer(procid));
    getSqlMapClientTemplate().queryForObject("updateNextCarpooler", param);
    String employeeID = (String)param.get("employeeID");
    if ((employeeID != null) && (0 < employeeID.length()))
    {
      return employeeID;
    }
    

    return null;
  }
  
  public void update(ParkingApplication parkingApplication)
    throws SQLException
  {
    getSqlMapClientTemplate().queryForObject("updateParkingApplication", parkingApplication);
    
    if (!"accept".equalsIgnoreCase(parkingApplication.getControlAction()))
    {
      insertCarTagList(parkingApplication.getCarTagList());
      
      List<ParkingAppCarpool> carpoolList = parkingApplication.getCarpoolList();
      for (ParkingAppCarpool carpool : carpoolList)
      {
        insertParkingAppCarpool(carpool);
      }
    }
  }
  
  public void insertCarTagList(List<ParkingCarTag> tags)
  {
    if ((tags != null) && (0 < tags.size()))
    {
      getSqlMapClientTemplate().queryForObject("deleteCarTags2", tags.get(0));
      for (ParkingCarTag tag : tags)
      {
        getSqlMapClientTemplate().queryForObject("insertCarTag", tag);
      }
    }
  }
  
  public List<ParkingCarTag> getParkingCarTag(int procid, String employeeID)
  {
    HashMap param = new HashMap();
    param.put("procid", new Integer(procid));
    param.put("employeeID", employeeID);
    return getSqlMapClientTemplate().queryForList("getCarTagsByEmployeeID", param);
  }
  
  public List<ParkingCarTag> getParkingCarTagFromLocator(String employeeID)
  {
    return getSqlMapClientTemplate().queryForList("getCarTagsByEmployeeIDFromLocator", employeeID);
  }
  
  public void insertParkingAppCarpool(ParkingAppCarpool carpool)
  {
    getSqlMapClientTemplate().queryForObject("insertParkingAppCarpool", carpool);
    insertCarTagList(carpool.getCarTagList());
  }
  
  public void copyToPSCLocator(int procid, String whoUpdated)
  {
    HashMap param = new HashMap();
    param.put("procid", new Integer(procid));
    if (10 < whoUpdated.length())
    {
      whoUpdated = whoUpdated.substring(0, 9);
    }
    param.put("whoUpdated", whoUpdated);
    getSqlMapClientTemplate().queryForObject("copyToPSCLocator", param);
    this.log.info("copy to PSCLocator(" + Integer.toString(procid) + ")");
  }
  
  public void updateParkingAppCarpool(List<ParkingAppCarpool> carpoolList)
  {
    for (ParkingAppCarpool carpool : carpoolList)
    {
      updateParkingAppCarpool(carpool);
    }
  }
  
  public void updateParkingAppCarpool(ParkingAppCarpool carpool)
  {
    if ((carpool.getEmployeeID() != null) && (carpool.getEmployeeWorkHourStart() != null) && (carpool.getEmployeeWorkHourEnd() != null))
    {
      getSqlMapClientTemplate().queryForObject("updateParkingAppCarpool", carpool);
      insertCarTagList(carpool.getCarTagList());
    }
  }
  
  public void deleteParkingApplication(int procId)
  {
    getSqlMapClientTemplate().queryForObject("deleteParkingApplication", Integer.valueOf(procId));
  }
  
  public void updateParkingAppStatus(int procid, String status)
  {
    HashMap param = new HashMap();
    param.put("procid", Integer.valueOf(procid));
    param.put("status", status);
    getSqlMapClientTemplate().queryForObject("updateParkingAppStatus", param);
  }
  
  public void updateComment(int procid, String comment) throws SQLException
  {
    HashMap param = new HashMap();
    param.put("procid", Integer.valueOf(procid));
    param.put("comment", comment);
    getSqlMapClientTemplate().queryForObject("updateParkingAppComment", param);
  }
  
  public ParkingAppStatus getParkingAppStatusByEmployeeID(String employeeID, String exceptPermitCode) throws SQLException
  {
    HashMap param = new HashMap();
    param.put("employeeID", employeeID);
    param.put("ExceptPermitCode", exceptPermitCode);
    getSqlMapClientTemplate().queryForObject("getParkingAppStatusByEmployeeID", param);
    ParkingAppStatus status = new ParkingAppStatus();
    status.setEmployeeID(employeeID);
    status.setProcid(((Integer)param.get("procid")).intValue());
    status.setPermitCode((String)param.get("permitCode"));
    status.setStatus((String)param.get("status"));
    status.setPrimaryCarpoolerID((String)param.get("primaryCarpoolerID"));
    status.setPrimaryCarpoolerName((String)param.get("primaryCarpoolerName"));
    return status;
  }
  
  public HashMap isEligible(String employeeID) throws SQLException
  {
    HashMap param = new HashMap();
    param.put("employeeID", employeeID);
    getSqlMapClientTemplate().queryForObject("eligibleForParking", param);
    return param;
  }
}
