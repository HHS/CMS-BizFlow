package com.handysoft.hhs.transhare.dao;

import com.handysoft.hhs.transhare.model.Employee;
import com.handysoft.hhs.transhare.model.TranshareApplication;
import com.handysoft.hhs.transhare.model.TranshareCost;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

public class TranshareApplicationDAO extends SqlMapClientDaoSupport
{
  private Log log = null;
  
  public TranshareApplicationDAO()
  {
    this.log = LogFactory.getLog(TranshareApplicationDAO.class);
  }
  
  public TranshareApplication getTranshareApplicationByProcId(int procid) {
    return (TranshareApplication)getSqlMapClientTemplate().queryForObject("getTranshareByProcId", Integer.valueOf(procid));
  }
  
  public List<TranshareCost> getTranshareCost(int procid) {
    List<TranshareCost> costs = getSqlMapClientTemplate().queryForList("getTranshareCost", Integer.valueOf(procid));
    return costs;
  }
  
  public void update(TranshareApplication transhareApplication) throws SQLException
  {
    getSqlMapClientTemplate().queryForObject("updateTranshare", transhareApplication);
  }
  
  public void updateBySupervisor(TranshareApplication transhareApplication) throws SQLException
  {
    getSqlMapClientTemplate().queryForObject("updateTranshareBySupervisor", transhareApplication);
  }
  
  public void updateByCoordinator(TranshareApplication transhareApplication) throws SQLException
  {
    getSqlMapClientTemplate().queryForObject("updateTranshareByCoordinator", transhareApplication);
  }
  
  public void updateByTranshareCoordinator(TranshareApplication transhareApplication) throws SQLException
  {
    getSqlMapClientTemplate().queryForObject("updateTranshareByTranshareCoordinator", transhareApplication);
  }
  
  public void insertTranshareCost(TranshareCost cost)
  {
    getSqlMapClientTemplate().queryForObject("insertTranshareCost", cost);
  }
  
  public void copyToPSCLocator(TranshareApplication transhareApplication)
  {
    HashMap param = new HashMap();
    param.put("employeeID", transhareApplication.getEmployee().getEmployeeID());
    
    param.put("actualCostMonthly", transhareApplication.getTotal());
    param.put("procid", Integer.valueOf(transhareApplication.getProcid()));
    param.put("expirationDate", transhareApplication.getNotToExceedDate());
    param.put("whoUpdated", "BizFlow");
    getSqlMapClientTemplate().queryForObject("copyTranshareToPSCLocator", param);
  }
  

  public void deleteTranshareApplication(int procId)
  {
    getSqlMapClientTemplate().queryForObject("deleteTranshare", Integer.valueOf(procId));
  }
  
  public void deleteTranshareCost(int procId)
  {
    getSqlMapClientTemplate().queryForObject("deleteTranshareCost", Integer.valueOf(procId));
  }
  
  public void updateTranshareStatus(int procid, String status)
  {
    HashMap param = new HashMap();
    param.put("procid", Integer.valueOf(procid));
    param.put("status", status);
    getSqlMapClientTemplate().queryForObject("updateTranshareStatus", param);
  }
  
  public BigDecimal getTranshareMonthlyMaximum(String employeeID)
  {
    HashMap param = new HashMap();
    param.put("employeeID", employeeID);
    getSqlMapClientTemplate().queryForObject("getTranshareMonthlyMaximum", param);
    return (BigDecimal)param.get("max");
  }
  
  public HashMap isEligible(String employeeID) throws SQLException {
    HashMap param = new HashMap();
    param.put("employeeID", employeeID);
    getSqlMapClientTemplate().queryForObject("eligibleForTranshare", param);
    return param;
  }
}
