package com.handysoft.hhs.transhare.dao;

import com.handysoft.hhs.transhare.model.ParkingAssign;
import com.handysoft.hhs.transhare.model.ParkingAssignDetail;
import com.handysoft.hhs.transhare.model.ParkingAssignItem;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;


public class ParkingAssignDAO
  extends SqlMapClientDaoSupport
{
  Log log = null;
  

  public ParkingAssignDAO()
  {
    this.log = LogFactory.getLog(ParkingAssignDAO.class);
  }
  
  public ParkingAssign getParkingAssignByProcId(int procid)
  {
    return (ParkingAssign)getSqlMapClientTemplate().queryForObject("getParkingAssignByProcId", Integer.valueOf(procid));
  }
  
  public List<ParkingAssignDetail> getAllParkingAssignDetailByProcId(int procid, String agency)
  {
    HashMap pmap = new HashMap();
    pmap.put("procid", Integer.valueOf(procid));
    pmap.put("agency", agency);
    return getSqlMapClientTemplate().queryForList("getParkingAssignDetailByProcId", pmap);
  }
  
  public void insert(ParkingAssign parkingAssign)
    throws SQLException
  {
    getSqlMapClientTemplate().delete("deleteParkingAssign", parkingAssign);
    for (ParkingAssignItem item : parkingAssign.getItems())
    {
      if (item.getLotCount() > 0)
      {
        getSqlMapClientTemplate().insert("insertParkingAssign", item);
      }
    }
  }
  

  public void updateParkingAssignItem(ParkingAssignItem parkingAssignItem)
  {
    for (ParkingAssignDetail item : parkingAssignItem.getItems())
    {
      if ((item.getEmployeeID() != null) && (0 < item.getEmployeeID().length()) && (item.getStatus() == 0))
      {
        getSqlMapClientTemplate().update("updateParkingAssignDetail", item);
      }
    }
  }
  
  public void delete(ParkingAssign parkingAssign)
  {
    getSqlMapClientTemplate().delete("deleteParkingAssign", parkingAssign);
  }
}
