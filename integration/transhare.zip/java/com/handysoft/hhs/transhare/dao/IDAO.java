package com.handysoft.hhs.transhare.dao;

public abstract interface IDAO {}
