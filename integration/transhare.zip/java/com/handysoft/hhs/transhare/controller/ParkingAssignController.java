package com.handysoft.hhs.transhare.controller;

import com.handysoft.hhs.transhare.model.ParkingAssign;
import com.handysoft.hhs.transhare.services.BizFlowManager;
import com.handysoft.hhs.transhare.services.CommonManager;
import com.handysoft.hhs.transhare.services.ParkingManager;
import com.handysoft.hhs.transhare.util.CommandUtil;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractFormController;





public class ParkingAssignController
  extends AbstractFormController
{
  private final Log log;
  private CommonManager commonManager;
  private ParkingManager parkingManager;
  private BizFlowManager bizFlowManager = null;
  
  public ParkingAssignController()
  {
    this.log = LogFactory.getLog(ParkingAssignController.class);
  }
  
  protected Object formBackingObject(HttpServletRequest request) throws ServletException
  {
    ParkingAssign cmd = this.parkingManager.getParkingAssign();
    cmd.setWIHParameters(request);
    return cmd;
  }
  
  protected ModelAndView showForm(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, BindException e) throws Exception
  {
    this.log.info("Returning view");
    ModelAndView mv = showForm(httpServletRequest, e, "forms/assign_available_spots");
    mv.addObject("commonManager", this.commonManager);
    return mv;
  }
  
  protected ModelAndView processFormSubmission(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, BindException e) throws Exception
  {
    if (CommandUtil.isFormSubmitted(httpServletRequest))
    {
      ModelAndView mv = new ModelAndView("success");
      ParkingAssign cmd = (ParkingAssign)o;
      try {
        if ("cancel".equalsIgnoreCase(cmd.getControlAction()))
        {
          this.parkingManager.cancelParkingAssign(cmd);
          mv = new ModelAndView("close");
        }
        else if ("submit".equalsIgnoreCase(cmd.getControlAction()))
        {
          this.parkingManager.insertParkingAssign(cmd);
        }
      }
      catch (Exception ex) {
        mv = new ModelAndView("error", "message", ex);
      }
      return mv;
    }
    

    ModelAndView mv = showForm(httpServletRequest, httpServletResponse, e);
    return mv;
  }
  
  public void setCommonManager(CommonManager commonManager)
  {
    this.commonManager = commonManager;
  }
  
  public CommonManager getCommonManager() {
    return this.commonManager;
  }
  
  public ParkingManager getParkingManager() {
    return this.parkingManager;
  }
  
  public void setParkingManager(ParkingManager parkingManager) {
    this.parkingManager = parkingManager;
  }
  
  public BizFlowManager getBizFlowManager() {
    return this.bizFlowManager;
  }
  
  public void setBizFlowManager(BizFlowManager bizFlowManager) {
    this.bizFlowManager = bizFlowManager;
  }
}
