package com.handysoft.hhs.transhare.controller;

import com.handysoft.hhs.transhare.model.ParkingAssignDetail;
import com.handysoft.hhs.transhare.model.ParkingAssignItem;
import com.handysoft.hhs.transhare.services.BizFlowManager;
import com.handysoft.hhs.transhare.services.CommonManager;
import com.handysoft.hhs.transhare.services.ParkingManager;
import com.handysoft.hhs.transhare.util.CommandUtil;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.validation.BindException;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractFormController;









public class ParkingAssignPersonController
  extends AbstractFormController
{
  private final Log log;
  private CommonManager commonManager = null;
  private ParkingManager parkingManager = null;
  private BizFlowManager bizFlowManager = null;
  

  public ParkingAssignPersonController()
  {
    this.log = LogFactory.getLog(ParkingAssignPersonController.class);
  }
  
  protected Object formBackingObject(HttpServletRequest request)
    throws Exception
  {
    ParkingAssignItem cmd = new ParkingAssignItem();
    cmd.setWIHParameters(request);
    int procid = cmd.getProcid();
    String agency = ServletRequestUtils.getStringParameter(request, "agency", "NON");
    if ((!"".equals(cmd.getSessioninfo())) && ("NON".equals(agency)))
    {
      agency = cmd.getActivityName().substring(cmd.getActivityName().indexOf("-") + 2);
    }
    if ((cmd.getProcid() != 0) && (!"NON".equals(agency)))
    {
      List<ParkingAssignDetail> parkingAssignDetails = this.parkingManager.getAllParkingAssignDetailByProcId(procid, agency);
      cmd.setItems(parkingAssignDetails);
      if (!CommandUtil.isFormSubmitted(request))
      {
        cmd.setAgency(agency);
      }
    }
    return cmd;
  }
  
  protected ModelAndView showForm(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, BindException e)
    throws Exception
  {
    this.log.info("Returning view");
    
    ModelAndView mv = showForm(httpServletRequest, e, "forms/select_executives");
    mv.addObject("commonManager", this.commonManager);
    return mv;
  }
  
  protected ModelAndView processFormSubmission(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, BindException e)
    throws Exception
  {
    ModelAndView mv = new ModelAndView("success");
    if (CommandUtil.isFormSubmitted(httpServletRequest))
    {
      ParkingAssignItem cmd = (ParkingAssignItem)o;
      try
      {
        this.parkingManager.updateParkingAssignItem(cmd);
        
        if ("save".equalsIgnoreCase(cmd.getControlAction()))
        {
          mv = new ModelAndView("save");
        }
        else if ("submit".equalsIgnoreCase(cmd.getControlAction()))
        {
          mv = new ModelAndView("success");
        }
      }
      catch (Exception ex)
      {
        mv = new ModelAndView("error", "message", ex);
        mv.addObject("command", cmd);
      }
      return mv;
    }
    

    mv = showForm(httpServletRequest, httpServletResponse, e);
    return mv;
  }
  

  public void setCommonManager(CommonManager commonManager)
  {
    this.commonManager = commonManager;
  }
  
  public CommonManager getCommonManager()
  {
    return this.commonManager;
  }
  
  public ParkingManager getParkingManager()
  {
    return this.parkingManager;
  }
  
  public void setParkingManager(ParkingManager parkingManager)
  {
    this.parkingManager = parkingManager;
  }
  
  public BizFlowManager getBizFlowManager()
  {
    return this.bizFlowManager;
  }
  
  public void setBizFlowManager(BizFlowManager bizFlowManager)
  {
    this.bizFlowManager = bizFlowManager;
  }
}
