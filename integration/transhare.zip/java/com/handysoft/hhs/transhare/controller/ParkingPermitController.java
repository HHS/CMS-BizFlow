package com.handysoft.hhs.transhare.controller;

import com.handysoft.hhs.transhare.TranshareProperties;
import com.handysoft.hhs.transhare.model.EligibilityCheck;
import com.handysoft.hhs.transhare.model.Employee;
import com.handysoft.hhs.transhare.model.ParkingAppCarpool;
import com.handysoft.hhs.transhare.model.ParkingAppStatus;
import com.handysoft.hhs.transhare.model.ParkingApplication;
import com.handysoft.hhs.transhare.services.BizFlowManager;
import com.handysoft.hhs.transhare.services.CommonManager;
import com.handysoft.hhs.transhare.services.ParkingManager;
import com.handysoft.hhs.transhare.util.CommandUtil;
import com.hs.bf.web.beans.HWSessionInfo;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.validation.BindException;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.servlet.ModelAndView;

public class ParkingPermitController extends org.springframework.web.servlet.mvc.AbstractFormController
{
  Log log;
  private CommonManager commonManager = null;
  private ParkingManager parkingManager = null;
  private BizFlowManager bizFlowManager = null;
  private String currentEmployeeID = null;
  private String viewer = "applicant";
  private ParkingAppStatus previousParkingAppStatus = null;
  private EligibilityCheck eligibilityCheck = null;
  private Employee currentEmployee = null;
  
  public ParkingPermitController()
  {
    this.log = org.apache.commons.logging.LogFactory.getLog(ParkingPermitController.class);
  }
  
  public ParkingManager getParkingManager() {
    return this.parkingManager;
  }
  
  public void setParkingManager(ParkingManager parkingManager) {
    this.parkingManager = parkingManager;
  }
  
  public BizFlowManager getBizFlowManager() {
    return this.bizFlowManager;
  }
  
  public void setBizFlowManager(BizFlowManager bizFlowManager) {
    this.bizFlowManager = bizFlowManager;
  }
  
  public CommonManager getCommonManager() {
    return this.commonManager;
  }
  
  public void setCommonManager(CommonManager commonManager) {
    this.commonManager = commonManager;
  }
  
  protected void initBinder(HttpServletRequest request, ServletRequestDataBinder binder) {
    SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
    dateFormat.setLenient(false);
    binder.registerCustomEditor(Date.class, null, new CustomDateEditor(dateFormat, true));
  }
  

  protected Object formBackingObject(HttpServletRequest request)
    throws Exception
  {
    ParkingApplication cmd = new ParkingApplication();
    this.previousParkingAppStatus = null;
    

    if (CommandUtil.isFormSubmitted(request)) {
      cmd.setWIHParameters(request);
      checkPrecondition(cmd);
      this.currentEmployeeID = this.bizFlowManager.getEmployeeID(getCurrentUserId(cmd));
      this.viewer = ServletRequestUtils.getStringParameter(request, "viewer");
      if (("carpooler".equals(this.viewer)) || ("reviewer".equals(this.viewer))) {
        cmd.setCarpoolList(this.parkingManager.getParkingAppCarpool(cmd.getProcid()));
      }
    }
    else
    {
      int procid = ServletRequestUtils.getIntParameter(request, "procid", 0);
      
      if (procid == 0)
      {
        throw new Exception("Process ID is missing.");
      }
      String tempSessionInfoString = ServletRequestUtils.getStringParameter(request, "sessioninfo", "");
      if ("".equals(tempSessionInfoString))
      {
        throw new Exception("Access denied. Session information is missing.");
      }
      

      HWSessionInfo tempSessionInfo = new HWSessionInfo();
      tempSessionInfo.setSessionInfo(tempSessionInfoString);
      if (this.bizFlowManager.getTranshareAccessEligible(Integer.valueOf(procid), tempSessionInfo.get("USERID")).intValue() == 0)
      {
        throw new Exception("Access denied. You do not have permission.");
      }
      


      cmd = this.parkingManager.getParkingApplicationByProcId(procid);
      
      if (null == cmd)
      {
        cmd = new ParkingApplication();
        cmd.setWIHParameters(request);
        cmd.setCommonManager(this.commonManager);
        checkPrecondition(cmd);
        this.currentEmployeeID = this.bizFlowManager.getEmployeeID(getCurrentUserId(cmd));
        
        Employee emp = this.commonManager.getEmployee(this.currentEmployeeID);
        if (emp == null) {
          throw new Exception("System can't look up EmployeeID from PSC locator system [" + this.currentEmployeeID + "]");
        }
        this.currentEmployee = emp;
        
        cmd.setEmployee(emp);
        cmd.setEmployeeID(emp.getEmployeeID());
        
        this.eligibilityCheck = this.parkingManager.isEligible(emp.getEmployeeID());
        if (this.eligibilityCheck.isEligible()) {
          this.previousParkingAppStatus = this.parkingManager.getParkingAppStatusByEmployeeID(cmd.getEmployeeID(), "AA");
          if ((this.previousParkingAppStatus == null) || (!this.previousParkingAppStatus.isCarpooler()))
          {
            cmd.setCarTagList(this.parkingManager.getParkingCarTagFromLocator(cmd.getEmployeeID()));
          }
        }
      }
      else
      {
        cmd.setWIHParameters(request);
        cmd.setCommonManager(this.commonManager);
        this.currentEmployeeID = this.bizFlowManager.getEmployeeID(getCurrentUserId(cmd));
        if (cmd.getEmployeeID() != null)
        {
          cmd.setEmployee(this.commonManager.getEmployee(cmd.getEmployeeID()));
        }
        
        if (this.currentEmployeeID == null) {
          throw new Exception("System can't look up EmployeeID by BizFlowID  [" + getCurrentUserId(cmd) + "]");
        }
        this.currentEmployee = this.commonManager.getEmployee(this.currentEmployeeID);
        

        if (cmd.isCarpool()) {
          for (ParkingAppCarpool carpool : cmd.getCarpoolList()) {
            carpool.setCommonManager(this.commonManager);
            if ((carpool.getEmployeeID().equals(this.currentEmployeeID)) && (carpool.getCarTagList().size() == 0))
            {
              carpool.setCarTagList(this.parkingManager.getParkingCarTagFromLocator(this.currentEmployeeID));
            }
          }
        }
        
        if (!cmd.isReadOnly()) {
          checkPrecondition(cmd);
          this.eligibilityCheck = this.parkingManager.isEligible(cmd.getEmployeeID());
          if ("A1".equals(cmd.getPermitCode()))
          {
            if (TranshareProperties.get("requestParkingPermit.reviewExecApplicationActivityName").equals(cmd.getActivityName())) {
              Employee reviewer = this.currentEmployee;
              cmd.setReviewerID(reviewer.getEmployeeID());
              cmd.setDateReviewed(new Date());
              cmd.setReviewerName(reviewer.getName());
              cmd.setReviewerTitle(reviewer.getTitle());

            }
            else if ((cmd.getReviewerID() != null) && (cmd.getReviewerID().length() > 0)) {
              Employee reviewer = this.commonManager.getEmployee(cmd.getReviewerID());
              cmd.setReviewerName(reviewer.getName());
              cmd.setReviewerTitle(reviewer.getTitle());
            }
            
          }
        }
        else if ((cmd.getReviewerID() != null) && (cmd.getReviewerID().length() > 0)) {
          Employee reviewer = this.commonManager.getEmployee(cmd.getReviewerID());
          cmd.setReviewerName(reviewer.getName());
          cmd.setReviewerTitle(reviewer.getTitle());
        }
      }
    }
    
    return cmd;
  }
  
  private Calendar convert(String s, boolean fullHour) {
    if (s == null) {
      return null;
    }
    try
    {
      String[] d = s.split("/");
      Calendar cal = new GregorianCalendar();
      
      if (fullHour) {
        cal.set(cal.get(1), Integer.parseInt(d[0]) - 1, Integer.parseInt(d[1]), 23, 59, 59);
      } else {
        cal.set(cal.get(1), Integer.parseInt(d[0]) - 1, Integer.parseInt(d[1]), 0, 0, 0);
      }
      return cal;
    }
    catch (Exception e) {}
    return null;
  }
  
  private void checkPrecondition(ParkingApplication cmd) throws Exception
  {
    Calendar today = new GregorianCalendar();
    Calendar start = convert(TranshareProperties.get("singleApplicationBlock.startDate"), false);
    Calendar end = convert(TranshareProperties.get("singleApplicationBlock.endDate"), true);
    if ((today.after(start)) && (today.before(end))) {
      cmd.setSingleApplicationBlockPeriod(true);
    } else {
      cmd.setSingleApplicationBlockPeriod(false);
    }
  }
  
  private String getCurrentUserId(ParkingApplication cmd) {
    if (null == cmd.getCurrentUserId()) {
      return "0000000000";
    }
    return cmd.getCurrentUserId();
  }
  
  protected ModelAndView showForm(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, BindException e) throws Exception
  {
    String url = httpServletRequest.getRequestURI();
    ModelAndView mv;
    if ((!"y".equalsIgnoreCase(ServletRequestUtils.getStringParameter(httpServletRequest, "readOnly", ""))) && (((this.eligibilityCheck != null) && (!this.eligibilityCheck.isEligible())) || ((this.previousParkingAppStatus != null) && (this.previousParkingAppStatus.isCarpooler()))))
    {

      if (this.currentEmployee != null) this.log.info("forms/psc43_warning viewer: " + this.currentEmployee.getName() + " eligibilityCheck: " + this.eligibilityCheck.isEligible());
      mv = showForm(httpServletRequest, e, "forms/psc43_warning"); } else {
      if (url.contains("psc43_1")) {
        if (this.currentEmployee != null) this.log.info("forms/psc43_1 viewer: " + this.currentEmployee.getName());
        mv = showForm(httpServletRequest, e, "forms/psc43_1");
      } else {
        if (this.currentEmployee != null) this.log.info("forms/psc43 viewer: " + this.currentEmployee.getName());
        mv = showForm(httpServletRequest, e, "forms/psc43");
      } }
    mv.addObject("commonManager", this.commonManager);
    mv.addObject("previousParkingAppStatus", this.previousParkingAppStatus);
    mv.addObject("eligibilityCheck", this.eligibilityCheck);
    mv.addObject("currentEmployee", this.currentEmployee);
    return mv;
  }
  
  protected ModelAndView processFormSubmission(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, BindException e) throws Exception {
    ModelAndView mv = new ModelAndView("success");
    ParkingApplication cmd = (ParkingApplication)o;
    try {
      if (CommandUtil.isFormSubmitted(httpServletRequest)) {
        if (httpServletRequest.getRequestURI().contains("psc43_1")) {
          if ("cancel".equalsIgnoreCase(cmd.getControlAction())) {
            this.parkingManager.cancelParkingApplication(cmd);
          } else if ("accept".equalsIgnoreCase(cmd.getControlAction())) {
            this.parkingManager.acceptParkingApplication(cmd);
          } else if ("reject".equalsIgnoreCase(cmd.getControlAction())) {
            this.parkingManager.rejectParkingApplication(cmd);
          } else if ("permit".equalsIgnoreCase(cmd.getControlAction())) {
            this.parkingManager.permitParkingApplication(cmd);
          } else if ("submit".equalsIgnoreCase(cmd.getControlAction())) {
            cmd.setPermitCode("A1");
            cmd.collectCarTagList();
            this.parkingManager.updateParkingApplication(cmd);
          }
        }
        else if ("cancel".equalsIgnoreCase(cmd.getControlAction())) {
          this.parkingManager.cancelParkingApplication(cmd);
        } else if ("accept".equalsIgnoreCase(cmd.getControlAction())) {
          this.parkingManager.acceptParkingApplication(cmd);
        } else if ("reject".equalsIgnoreCase(cmd.getControlAction())) {
          this.parkingManager.rejectParkingApplication(cmd);
        } else if ("submit".equalsIgnoreCase(cmd.getControlAction())) {
          if ("applicant".equals(this.viewer)) {
            cmd.collectCarTagList();
            this.parkingManager.updateParkingApplication(cmd);
          } else if ("carpooler".equals(this.viewer)) {
            for (ParkingAppCarpool carpool : cmd.getCarpoolList()) {
              if (this.currentEmployeeID.equals(carpool.getEmployeeID())) {
                carpool.collectCarTagList();
                carpool.setSessioninfo(cmd.getSessioninfo());
                carpool.setProcid(cmd.getProcid());
                this.parkingManager.updateCarpooler(carpool);
                break;
              }
              
            }
            
          }
          
        }
        

      }
      else
      {
        mv = showForm(httpServletRequest, httpServletResponse, e);
        mv.addObject("commonManager", this.commonManager);
        mv.addObject("currentEmployeeID", this.currentEmployeeID);
        
        if (TranshareProperties.get("requestParkingPermit.reviewApplicationActivityName").equals(cmd.getActivityName())) {
          mv.addObject("viewer", "reviewer");
        } else if (TranshareProperties.get("requestParkingPermit.reviewExecApplicationActivityName").equals(cmd.getActivityName())) {
          mv.addObject("viewer", "reviewer");
        } else if (TranshareProperties.get("requestParkingPermit.preparePermitActivityName").equals(cmd.getActivityName())) {
          mv.addObject("viewer", "piostaff");
        } else {
          mv.addObject("viewer", "applicant");
          
          if (cmd.isCarpool()) {
            List<ParkingAppCarpool> list = cmd.getCarpoolList();
            for (ParkingAppCarpool carp : list) {
              if (this.currentEmployeeID.equals(carp.getEmployeeID())) {
                mv.addObject("viewer", "carpooler");
                break;
              }
            }
          }
        }
      }
    }
    catch (Exception ex) {
      mv = new ModelAndView("error", "message", ex);
      mv.addObject("command", cmd);
    }
    
    return mv;
  }
}
