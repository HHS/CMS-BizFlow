package com.handysoft.hhs.transhare.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractFormController;






public class SampleWihController
  extends AbstractFormController
{
  Log log = null;
  
  protected Object formBackingObject(HttpServletRequest httpServletRequest) throws Exception
  {
    return null;
  }
  
  protected ModelAndView showForm(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, BindException e) throws Exception {
    return null;
  }
  
  protected ModelAndView processFormSubmission(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, BindException e) throws Exception {
    return null;
  }
}
