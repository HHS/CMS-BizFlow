package com.handysoft.hhs.transhare.controller;

import com.handysoft.hhs.transhare.TranshareProperties;
import com.handysoft.hhs.transhare.model.EligibilityCheck;
import com.handysoft.hhs.transhare.model.Employee;
import com.handysoft.hhs.transhare.model.TranshareApplication;
import com.handysoft.hhs.transhare.model.TranshareCost;
import com.handysoft.hhs.transhare.services.BizFlowManager;
import com.handysoft.hhs.transhare.services.CommonManager;
import com.handysoft.hhs.transhare.services.TranshareManager;
import com.handysoft.hhs.transhare.util.CommandUtil;
import com.hs.bf.web.beans.HWSessionInfo;
import com.hs.bf.wf.jo.HWProcessVariable;
import com.hs.bf.wf.jo.HWProcessVariables;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.validation.BindException;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractFormController;






public class TranshareController
  extends AbstractFormController
{
  private final Log log;
  private CommonManager commonManager = null;
  private TranshareManager transhareManager = null;
  private BizFlowManager bizFlowManager = null;
  private Employee currentUser = null;
  private EligibilityCheck eligibilityCheck = null;
  private int viewerID = 0;
  private static final int MAX_TRAVEL_ROWS = 5;
  
  public TranshareController()
  {
    this.log = LogFactory.getLog(TranshareController.class);
  }
  
  public TranshareManager getTranshareManager() {
    return this.transhareManager;
  }
  
  public void setTranshareManager(TranshareManager transhareManager) {
    this.transhareManager = transhareManager;
  }
  
  public BizFlowManager getBizFlowManager()
  {
    return this.bizFlowManager;
  }
  
  public void setBizFlowManager(BizFlowManager bizFlowManager)
  {
    this.bizFlowManager = bizFlowManager;
  }
  
  public CommonManager getCommonManager()
  {
    return this.commonManager;
  }
  
  public void setCommonManager(CommonManager commonManager)
  {
    this.commonManager = commonManager;
  }
  
  protected void initBinder(HttpServletRequest request, ServletRequestDataBinder binder)
  {
    SimpleDateFormat dateFormat = new SimpleDateFormat("M/d/yyyy");
    dateFormat.setLenient(false);
    binder.registerCustomEditor(Date.class, null, new CustomDateEditor(dateFormat, true));
  }
  



  private boolean hasValue(String s)
  {
    return (s != null) && (0 < s.trim().length());
  }
  
  protected Object formBackingObject(HttpServletRequest request) throws Exception {
    TranshareApplication cmd = null;
    this.currentUser = null;
    
    if (CommandUtil.isFormSubmitted(request))
    {
      cmd = new TranshareApplication();
      cmd.setWIHParameters(request);
      
      List<TranshareCost> costs = new ArrayList();
      for (int i = 0; i < 5; i++)
      {
        costs.add(new TranshareCost());
      }
      cmd.setCosts(costs);
    }
    else
    {
      String currentEmployeeID = null;
      int procid = ServletRequestUtils.getIntParameter(request, "procid", 0);
      if (procid == 0)
      {
        throw new Exception("Process ID is missing.");
      }
      String tempSessionInfoString = ServletRequestUtils.getStringParameter(request, "sessioninfo", "");
      if ("".equals(tempSessionInfoString))
      {
        throw new Exception("Access denied. Session information is missing.");
      }
      

      HWSessionInfo tempSessionInfo = new HWSessionInfo();
      tempSessionInfo.setSessionInfo(tempSessionInfoString);
      if (this.bizFlowManager.getTranshareAccessEligible(Integer.valueOf(procid), tempSessionInfo.get("USERID")).intValue() == 0)
      {
        throw new Exception("Access denied. You do not have permission.");
      }
      

      cmd = this.transhareManager.getTranshareApplicationByProcId(procid);
      if (null == cmd)
      {

        cmd = new TranshareApplication();
        cmd.setWIHParameters(request);
        cmd.setCommonManager(this.commonManager);
        currentEmployeeID = this.bizFlowManager.getEmployeeID(getCurrentUserId(cmd));
        if (currentEmployeeID == null) {
          this.log.info("System can't look up EmployeeID by BizFlowID " + getCurrentUserId(cmd));
          this.eligibilityCheck = new EligibilityCheck();
          this.eligibilityCheck.setEligible(false);
        }
        else
        {
          this.currentUser = this.commonManager.getEmployee(currentEmployeeID);
          cmd.setEmployee(this.currentUser);
          cmd.setEmployeeID(this.currentUser.getEmployeeID());
          this.log.info("formBackingObject(ProcId:" + cmd.getProcid() + " Activty:" + cmd.getActivityName() + " User:" + this.currentUser.getEmployeeID() + " " + this.currentUser.getName() + " viewerID:" + this.viewerID + ")");
          
          this.eligibilityCheck = this.transhareManager.isEligible(cmd.getEmployeeID());
          if (this.currentUser.isTranShare())
          {
            cmd.setPurpose("U");
          }
        }
      }
      else
      {
        cmd.setWIHParameters(request);
        cmd.setCommonManager(this.commonManager);
        currentEmployeeID = this.bizFlowManager.getEmployeeID(getCurrentUserId(cmd));
        
        this.viewerID = getViewerID(cmd.getActivityName());
        if (currentEmployeeID == null) {
          this.log.info("System can't look up EmployeeID by BizFlowID " + getCurrentUserId(cmd));
          this.eligibilityCheck = new EligibilityCheck();
          this.eligibilityCheck.setEligible(false);
        }
        else
        {
          this.currentUser = this.commonManager.getEmployee(currentEmployeeID);
          this.eligibilityCheck = this.transhareManager.isEligible(cmd.getEmployeeID());
          this.log.info("formBackingObject(ProcId:" + cmd.getProcid() + " Activty:" + cmd.getActivityName() + " User:" + this.currentUser.getEmployeeID() + " " + this.currentUser.getName() + " viewerID:" + this.viewerID + ")");
          if ((1 == this.viewerID) && (cmd.getSupervisorVerifyDate() == null))
          {
            cmd.setSupervisorVerifyDate(new Date());
          }
          else if ((2 == this.viewerID) && (cmd.getCoordinatorVerifyDate() == null))
          {
            cmd.setCoordinatorVerifyDate(new Date());
          }
        }
      }
    }
    
    cmd = setProcessDefinitionVersion(cmd);
    this.log.debug("cmd.getDefinitionVersion()=" + cmd.getDefinitionVersion());
    return cmd;
  }
  
  private String getCurrentUserId(TranshareApplication cmd)
  {
    if (null == cmd.getCurrentUserId())
    {
      return "0000000000";
    }
    

    return cmd.getCurrentUserId();
  }
  
  private int getViewerID(String activityName)
  {
    if (TranshareProperties.get("transhare.activity.1").equals(activityName))
    {
      return 1;
    }
    if (TranshareProperties.get("transhare.activity.2").equals(activityName))
    {
      return 2;
    }
    if (TranshareProperties.get("transhare.activity.3").equals(activityName))
    {
      return 3;
    }
    if (TranshareProperties.get("transhare.activity.4").equals(activityName))
    {
      return 4;
    }
    
    return 0;
  }
  
  protected ModelAndView showForm(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, BindException e) throws Exception {
    ModelAndView mv;
    if (this.viewerID == 0) {
      if (this.eligibilityCheck.isEligible())
      {
        this.log.info("Applicant forms/psc58 viewerID: " + this.viewerID + " eligibilityCheck: " + this.eligibilityCheck.isEligible());
        mv = showForm(httpServletRequest, e, "forms/psc58");
      }
      else
      {
        this.log.info("Applicant forms/psc58_warning viewerID: " + this.viewerID + " eligibilityCheck: " + this.eligibilityCheck.isEligible());
        mv = showForm(httpServletRequest, e, "forms/psc58_warning");
      }
    }
    else
    {
      this.log.info("Other forms/psc58 viewerID: " + this.viewerID + " eligibilityCheck: " + this.eligibilityCheck.isEligible());
      mv = showForm(httpServletRequest, e, "forms/psc58");
    }
    mv.addObject("eligibilityCheck", this.eligibilityCheck);
    mv.addObject("commonManager", this.commonManager);
    return mv;
  }
  
  protected ModelAndView processFormSubmission(HttpServletRequest request, HttpServletResponse response, Object o, BindException e) throws Exception
  {
    ModelAndView mv = new ModelAndView("success");
    TranshareApplication cmd = (TranshareApplication)o;
    try {
      if (CommandUtil.isFormSubmitted(request))
      {
        int viewerID = ServletRequestUtils.getIntParameter(request, "viewerID", 0);
        if ("cancel".equalsIgnoreCase(cmd.getControlAction()))
        {
          this.transhareManager.cancelTranshareApplication(cmd);
        }
        if ("accept".equalsIgnoreCase(cmd.getControlAction()))
        {
          this.transhareManager.acceptTranshareApplication(viewerID, cmd);
        }
        if ("reject".equalsIgnoreCase(cmd.getControlAction()))
        {
          this.transhareManager.sendbackTranshareApplication(viewerID, cmd);
        }
        else if ("submit".equalsIgnoreCase(cmd.getControlAction()))
        {
          String orgSupervisorID = ServletRequestUtils.getStringParameter(request, "orgSupervisorID");
          this.log.debug("orgSupervisorID=" + orgSupervisorID + ", newSupervisorID=" + cmd.getSupervisorID());
          cmd.setChangedSupervisor((orgSupervisorID == null) || (!orgSupervisorID.equals(cmd.getSupervisorID())));
          
          this.transhareManager.updateTranshareApplication(cmd);
          

          this.transhareManager.importSupervisor(cmd);
        }
      }
      else
      {
        mv = showForm(request, response, e);
        mv.addObject("commonManager", this.commonManager);
        mv.addObject("currentUser", this.currentUser);
        mv.addObject("currentDate", new Date());
        mv.addObject("latestComment", this.transhareManager.getLatestComment(cmd));
        mv.addObject("monthlyMaximum", this.transhareManager.getTranshareMonthlyMaximum(cmd.getEmployeeID()).setScale(2));
        int viewerID = getViewerID(cmd.getActivityName());
        mv.addObject("viewerID", Integer.valueOf(viewerID));
        
        if ((viewerID == 0) && (this.eligibilityCheck.isEligible())) {
          Employee supervisor;
          if (cmd.getEmployee().getSupervisorID() == null)
          {

            supervisor = null;
          }
          else
          {
            cmd.setSupervisorID(cmd.getEmployee().getSupervisorID());
            supervisor = this.transhareManager.getDefaultSupervisor(cmd.getEmployee().getSupervisorID());
            


            if ((supervisor != null) && (supervisor.isInactive() == true))
            {
              cmd.setSupervisorID(null);
              supervisor = null;
            }
          }
          mv.addObject("defaultSupervisor", supervisor);
          
          List travelMethods = null;
          if (cmd.getEmployee().getRegion() != null) {
            this.log.info("GET TravelMethods Region: " + cmd.getEmployee().getRegion());
            travelMethods = this.commonManager.getTravelMethods(cmd.getEmployee().getRegion());
          }
          mv.addObject("availableTravelMethods", travelMethods);
          
          List costs = cmd.getCosts();
          if (costs == null)
          {
            costs = new ArrayList();
          }
          if (costs.size() < 5)
          {
            int diff = 5 - costs.size();
            for (int i = 0; i < diff; i++)
            {
              costs.add(new TranshareCost());
            }
            cmd.setCosts(costs);
          }
        }
      }
    }
    catch (Exception ex)
    {
      if ("3103".equals(ex.toString()))
      {
        mv = new ModelAndView("knownerror", "message", "Your use of this application has timed out for security reasons. Please close this window and log in to EWITS again and retrieve this application. The new values should be saved from when you last entered data.");
        mv.addObject("title", "Please log in to EWITS again.");
      }
      else if (ex.toString().indexOf("SUPERVISOR:") > -1)
      {
        mv = new ModelAndView("knownerror", "message", ex.toString().substring(ex.toString().indexOf("SUPERVISOR:") + 11));
        mv.addObject("title", "Please contact the Transhare Office.");
      }
      else if (ex.toString().indexOf("COORDINATOR:") > -1)
      {
        mv = new ModelAndView("knownerror", "message", ex.toString().substring(ex.toString().indexOf("COORDINATOR:") + 12));
        mv.addObject("title", "Please contact the Transhare Office.");
      }
      else {
        mv = new ModelAndView("error", "message", ex);
      }
      mv.addObject("command", cmd);
    }
    
    return mv;
  }
  
  private TranshareApplication setProcessDefinitionVersion(TranshareApplication cmd) throws Exception
  {
    this.log.debug(">>setProcessDefinitionVersion");
    String definitionVersion = getDefinitionVersion(cmd);
    cmd.setDefinitionVersion(definitionVersion);
    this.log.debug("<<setProcessDefinitionVersion");
    return cmd;
  }
  
  private String getDefinitionVersion(TranshareApplication cmd) throws Exception {
    this.log.debug(">>getDefinitionVersion");
    String defVersion = "";
    HWProcessVariables pvs = BizFlowManager.getProcessVariables(cmd.getSessioninfo(), cmd.getProcid(), false);
    HWProcessVariable pvDefVersion = pvs.getItemByName("version");
    if ((null != pvDefVersion) && (!"".equals(pvDefVersion))) {
      defVersion = pvDefVersion.getValue();
    }
    this.log.debug("definition version=" + defVersion);
    this.log.debug("<<getDefinitionVersion");
    return defVersion;
  }
}
