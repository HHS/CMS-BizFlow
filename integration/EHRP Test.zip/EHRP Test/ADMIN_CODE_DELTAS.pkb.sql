CREATE OR REPLACE PACKAGE BODY admin_code_deltas AS

--======================================================
--	- - -	- - - - - - - - - - - - - - - - - - - - - - - -

--GLOBAL VARIABLES

--	- - -	- - - - - - - - - - - - - - - - - - - - - - - -
--======================================================
GCV_UPDATE				CONSTANT admin_code_history.dml_type%TYPE	:= 'UPDATE';
GCV_INSERT				CONSTANT admin_code_history.dml_type%TYPE	:= 'INSERT';
	
--======================================================
--	- - -	- - - - - - - - - - - - - - - - - - - - - - - -

--TYPES

--	- - -	- - - - - - - - - - - - - - - - - - - - - - - -
--======================================================	
TYPE cache_tab IS TABLE OF admin_code_bk_csr%ROWTYPE
	INDEX BY VARCHAR2(200);
	
--======================================================
--	- - -	- - - - - - - - - - - - - - - - - - - - - - - -

--PROCEDURES

--	- - -	- - - - - - - - - - - - - - - - - - - - - - - -
--======================================================
--------------------------------------------------------
--PROCEDURE: insert_deltas
--DESCRIPTION: Insert records into admin_code_history
--------------------------------------------------------
PROCEDURE insert_deltas
	(it_history IN delta_tab)
IS
BEGIN
	FORALL i IN it_history.FIRST.. it_history.LAST
		INSERT INTO admin_code_history VALUES it_history(i);	
END;

--------------------------------------------------------
--PROCEDURE: check_updates
--DESCRIPTION: Checks if there were updates to the 
--				   administrative_code table
--------------------------------------------------------
PROCEDURE check_updates
	(ir_admin_code 		IN admin_code_csr%ROWTYPE,
	 ir_admin_code_bk	 	IN admin_code_bk_csr%ROWTYPE,
	 ot_updates				OUT delta_tab)
IS
	lr_history			admin_code_history%ROWTYPE;
BEGIN
		
	--Check if description changed
	IF (ir_admin_code_bk.description != ir_admin_code.description) THEN 

		lr_history.ac_history_id			:= ac_history_seq.NEXTVAL;
		lr_history.change_date				:= SYSDATE;
		lr_history.administrative_code	:= ir_admin_code_bk.administrative_code;
		lr_history.hrc_component_id		:= ir_admin_code_bk.hrc_component_id;
		lr_history.dml_type					:= GCV_UPDATE;
		lr_history.field_changed			:= 'DESCRIPTION';
		lr_history.old_value					:= ir_admin_code_bk.description;
		lr_history.new_value					:= ir_admin_code.description;
		
		ot_updates(ot_updates.COUNT) := lr_history;			
	END IF;
	
	--Check if institute changed
	IF (ir_admin_code_bk.institute != ir_admin_code.institute) THEN 

		lr_history.ac_history_id			:= ac_history_seq.NEXTVAL;
		lr_history.change_date				:= SYSDATE;
		lr_history.administrative_code	:= ir_admin_code_bk.administrative_code;
		lr_history.hrc_component_id		:= ir_admin_code_bk.hrc_component_id;
		lr_history.dml_type					:= GCV_UPDATE;
		lr_history.field_changed			:= 'INSTITUTE';
		lr_history.old_value					:= ir_admin_code_bk.institute;
		lr_history.new_value					:= ir_admin_code.institute;
		
		ot_updates(ot_updates.COUNT) := lr_history;			
	END IF;	
	
	--Check if organization_initials changed
	IF (ir_admin_code_bk.organization_initials != ir_admin_code.organization_initials) THEN 

		lr_history.ac_history_id			:= ac_history_seq.NEXTVAL;
		lr_history.change_date				:= SYSDATE;
		lr_history.administrative_code	:= ir_admin_code_bk.administrative_code;
		lr_history.hrc_component_id		:= ir_admin_code_bk.hrc_component_id;
		lr_history.dml_type					:= GCV_UPDATE;
		lr_history.field_changed			:= 'ORGANIZATION_INITIALS';
		lr_history.old_value					:= ir_admin_code_bk.organization_initials;
		lr_history.new_value					:= ir_admin_code.organization_initials;
		
		ot_updates(ot_updates.COUNT) := lr_history;			
	END IF;

	--Check if center changed
	IF (ir_admin_code_bk.center != ir_admin_code.center) THEN 

		lr_history.ac_history_id			:= ac_history_seq.NEXTVAL;
		lr_history.change_date				:= SYSDATE;
		lr_history.administrative_code	:= ir_admin_code_bk.administrative_code;
		lr_history.hrc_component_id		:= ir_admin_code_bk.hrc_component_id;
		lr_history.dml_type					:= GCV_UPDATE;
		lr_history.field_changed			:= 'CENTER';
		lr_history.old_value					:= ir_admin_code_bk.center;
		lr_history.new_value					:= ir_admin_code.center;

		ot_updates(ot_updates.COUNT) := lr_history;			
	END IF;	
	
	--Check if program_name changed
	IF (ir_admin_code_bk.program_name != ir_admin_code.program_name) THEN 

		lr_history.ac_history_id			:= ac_history_seq.NEXTVAL;
		lr_history.change_date				:= SYSDATE;
		lr_history.administrative_code	:= ir_admin_code_bk.administrative_code;
		lr_history.hrc_component_id		:= ir_admin_code_bk.hrc_component_id;
		lr_history.dml_type					:= GCV_UPDATE;
		lr_history.field_changed			:= 'PROGRAM_NAME';
		lr_history.old_value					:= ir_admin_code_bk.program_name;
		lr_history.new_value					:= ir_admin_code.program_name;
		
		ot_updates(ot_updates.COUNT) := lr_history;			
	END IF;		
	
	--Check if personnel_office_id changed
	IF (ir_admin_code_bk.personnel_office_id != ir_admin_code.personnel_office_id) THEN 

		lr_history.ac_history_id			:= ac_history_seq.NEXTVAL;
		lr_history.change_date				:= SYSDATE;
		lr_history.administrative_code	:= ir_admin_code_bk.administrative_code;
		lr_history.hrc_component_id		:= ir_admin_code_bk.hrc_component_id;
		lr_history.dml_type					:= GCV_UPDATE;
		lr_history.field_changed			:= 'PERSONNEL_OFFICE_ID';
		lr_history.old_value					:= ir_admin_code_bk.personnel_office_id;
		lr_history.new_value					:= ir_admin_code.personnel_office_id;
		
		ot_updates(ot_updates.COUNT) := lr_history;			
	END IF;
	
	--Check if program_opdiv changed
	IF (ir_admin_code_bk.program_opdiv != ir_admin_code.program_opdiv) THEN 

		lr_history.ac_history_id			:= ac_history_seq.NEXTVAL;
		lr_history.change_date				:= SYSDATE;
		lr_history.administrative_code	:= ir_admin_code_bk.administrative_code;
		lr_history.hrc_component_id		:= ir_admin_code_bk.hrc_component_id;
		lr_history.dml_type					:= GCV_UPDATE;
		lr_history.field_changed			:= 'PROGRAM_OPDIV';
		lr_history.old_value					:= ir_admin_code_bk.program_opdiv;
		lr_history.new_value					:= ir_admin_code.program_opdiv;
		
		ot_updates(ot_updates.COUNT) := lr_history;			
	END IF;		
			
END;

--------------------------------------------------------
--PROCEDURE: process_deltas
--DESCRIPTION:
--------------------------------------------------------
PROCEDURE process_deltas
	(it_ac 		IN admin_code_csr_tab,
	 it_ac_bk 	IN admin_code_bk_csr_tab)
IS
	lt_history		delta_tab;
	lt_updates		delta_tab;	
	lt_cache			cache_tab;
BEGIN
	IF it_ac_bk.COUNT > 0 THEN 
		FOR j IN it_ac_bk.FIRST.. it_ac_bk.LAST LOOP
			lt_cache(it_ac_bk(j).administrative_code || it_ac_bk(j).hrc_component_id).administrative_code	:= it_ac_bk(j).administrative_code;
			lt_cache(it_ac_bk(j).administrative_code || it_ac_bk(j).hrc_component_id).description 				:= it_ac_bk(j).description;
			lt_cache(it_ac_bk(j).administrative_code || it_ac_bk(j).hrc_component_id).hrc_component_id 		:= it_ac_bk(j).hrc_component_id;
			lt_cache(it_ac_bk(j).administrative_code || it_ac_bk(j).hrc_component_id).institute 				:= it_ac_bk(j).institute;
			lt_cache(it_ac_bk(j).administrative_code || it_ac_bk(j).hrc_component_id).organization_initials := it_ac_bk(j).organization_initials;
			lt_cache(it_ac_bk(j).administrative_code || it_ac_bk(j).hrc_component_id).center 					:= it_ac_bk(j).center;
			lt_cache(it_ac_bk(j).administrative_code || it_ac_bk(j).hrc_component_id).program_name 			:= it_ac_bk(j).program_name;
			lt_cache(it_ac_bk(j).administrative_code || it_ac_bk(j).hrc_component_id).personnel_office_id 	:= it_ac_bk(j).personnel_office_id;
			lt_cache(it_ac_bk(j).administrative_code || it_ac_bk(j).hrc_component_id).program_opdiv 			:= it_ac_bk(j).program_opdiv;			
		END LOOP;
	END IF;

	FOR i IN it_ac.FIRST..it_ac.LAST LOOP
		IF lt_cache.COUNT > 0 
		AND lt_cache.EXISTS(it_ac(i).administrative_code || it_ac(i).hrc_component_id) THEN
			--Record already exists on administrative_code
			--Check if the record was updated 
			check_updates(it_ac(i), lt_cache(it_ac(i).administrative_code || it_ac(i).hrc_component_id), lt_updates);
			
			IF lt_updates.COUNT > 0 THEN 
				insert_deltas(lt_updates);
			END IF;
	   
		ELSE  		
			--Create collection to insert into admin_code_history
			lt_history(i).ac_history_id			:= ac_history_seq.NEXTVAL;
			lt_history(i).change_date				:= SYSDATE;
			lt_history(i).administrative_code	:= it_ac(i).administrative_code;
			lt_history(i).hrc_component_id		:= it_ac(i).hrc_component_id;
			lt_history(i).dml_type					:= GCV_INSERT;
			lt_history(i).field_changed			:= NULL;
			lt_history(i).old_value					:= NULL;
			lt_history(i).new_value					:= NULL;
		END IF;
	END LOOP;

	--Insert admin_code_history records
	IF lt_history.COUNT > 0 THEN 
		insert_deltas(lt_history);	
	END  IF;
	
END;

--------------------------------------------------------
--PROCEDURE: fetch_deltas
--DESCRIPTION:
--------------------------------------------------------
PROCEDURE fetch_deltas
IS
	lt_ac 			admin_code_csr_tab;
	lt_ac_bk			admin_code_bk_csr_tab;
BEGIN
	
	--Fetch records from administrative_code
	BEGIN 
		OPEN admin_code_csr;
		FETCH admin_code_csr
		BULK COLLECT INTO lt_ac;
		CLOSE admin_code_csr;
	EXCEPTION
		WHEN no_data_found THEN 
			NULL;
	END;
	
	BEGIN 
		--Fetch records from administrative_code_bk
		OPEN admin_code_bk_csr;
		FETCH admin_code_bk_csr
		BULK COLLECT INTO lt_ac_bk;
		CLOSE admin_code_bk_csr;
	EXCEPTION
		WHEN no_data_found THEN 
			NULL;
	END;

	IF lt_ac.COUNT > 0 THEN
		process_deltas(lt_ac, lt_ac_bk);
	END IF;
END;


--======================================================
--	- - -	- - - - - - - - - - - - - - - - - - - - - - - -

--FUNCTIONS

--	- - -	- - - - - - - - - - - - - - - - - - - - - - - -
--======================================================
--------------------------------------------------------
--FUNCTION: get_deltas
--DESCRIPTION:
--------------------------------------------------------
FUNCTION get_deltas
RETURN BOOLEAN
IS
BEGIN

	fetch_deltas;
	
	COMMIT;
	RETURN TRUE;
EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK;
		RETURN FALSE;
END;

END admin_code_deltas;
/