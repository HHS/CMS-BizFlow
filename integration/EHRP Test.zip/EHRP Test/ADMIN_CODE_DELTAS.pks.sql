CREATE OR REPLACE PACKAGE admin_code_deltas AS

--======================================================
--	- - -	- - - - - - - - - - - - - - - - - - - - - - - -

--TYPES

--	- - -	- - - - - - - - - - - - - - - - - - - - - - - -
--======================================================		
TYPE delta_tab IS TABLE OF admin_code_history%ROWTYPE
	INDEX BY PLS_INTEGER;


--------------------------------------------------------
--CURSOR: admin_code_csr
--DESCRIPTION: Cursor retrieves records from administrative_code
--------------------------------------------------------
CURSOR admin_code_csr
IS
	SELECT *
	FROM administrative_code;

	TYPE admin_code_csr_tab IS TABLE OF admin_code_csr%ROWTYPE
		INDEX BY PLS_INTEGER;
		
		
--------------------------------------------------------
--CURSOR: admin_code_bk_csr
--DESCRIPTION: Cursor retrieves records from administrative_code_bk
--------------------------------------------------------
CURSOR admin_code_bk_csr
IS
	SELECT *
	FROM administrative_code_bk;

	TYPE admin_code_bk_csr_tab IS TABLE OF admin_code_bk_csr%ROWTYPE
		INDEX BY PLS_INTEGER;
		
--------------------------------------------------------
--PROCEDURE: insert_deltas
--DESCRIPTION: Insert records into admin_code_history
--------------------------------------------------------
PROCEDURE insert_deltas
	(it_history IN delta_tab);

--------------------------------------------------------
--PROCEDURE: check_updates
--DESCRIPTION: Checks if there were updates to the 
--				   administrative_code table
--------------------------------------------------------
PROCEDURE check_updates
	(ir_admin_code 		IN admin_code_csr%ROWTYPE,
	 ir_admin_code_bk	 	IN admin_code_bk_csr%ROWTYPE,
	 ot_updates				OUT delta_tab);

--------------------------------------------------------
--PROCEDURE: process_deltas
--DESCRIPTION:
--------------------------------------------------------
PROCEDURE process_deltas
	(it_ac 		IN admin_code_csr_tab,
	 it_ac_bk 	IN admin_code_bk_csr_tab);
	 
	 
--------------------------------------------------------
--PROCEDURE: fetch_deltas
--DESCRIPTION:
--------------------------------------------------------
PROCEDURE fetch_deltas;

--------------------------------------------------------
--FUNCTION: get_deltas
--DESCRIPTION:
--------------------------------------------------------
FUNCTION get_deltas
RETURN BOOLEAN;	 
		

END admin_code_deltas;
/