CREATE OR REPLACE PACKAGE copy_admin_codes AS

--------------------------------------------------------
--CURSOR: admin_csr
--DESCRIPTION: Cursor retrieves records from administrative_code
--------------------------------------------------------
CURSOR admin_csr
IS
	SELECT *
	FROM administrative_code;

	TYPE admin_csr_tab IS TABLE OF admin_csr%ROWTYPE
		INDEX BY PLS_INTEGER;
		
--------------------------------------------------------
--PROCEDURE: truncate_admin_code_bk
--DESCRIPTION: Truncate the table administrative_code_bk
--------------------------------------------------------
PROCEDURE truncate_admin_code_bk;

--------------------------------------------------------
--PROCEDURE: insert_admin_codes
--DESCRIPTION: Fetch admin codes from administrative_code
--------------------------------------------------------
PROCEDURE insert_admin_codes
	(it_admin_codes	admin_csr_tab);
	
	
--------------------------------------------------------
--PROCEDURE: get_admin_codes
--DESCRIPTION: Fetch admin codes from administrative_code
--------------------------------------------------------
PROCEDURE get_admin_codes;	

--------------------------------------------------------
--FUNCTION: copy_codes
--DESCRIPTION:
--------------------------------------------------------
FUNCTION copy_codes
RETURN BOOLEAN;

END copy_admin_codes;
/