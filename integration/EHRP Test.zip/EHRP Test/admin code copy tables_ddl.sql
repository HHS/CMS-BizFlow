/* --------------------------------------------------------
--  DDL for Table ADMINISTRATIVE_CODE_BK
--------------------------------------------------------*/

CREATE TABLE ADMINISTRATIVE_CODE_BK
SELECT * FROM ADMINISTRATIVE_CODE;

--=====================================================================================================================================================

--------------------------------------------------------
--  DDL for Table ADMIN_CODE_HISTORY
--------------------------------------------------------

CREATE TABLE HHS_CMS_HR.ADMIN_CODE_HISTORY
(
	AC_HISTORY_ID				NUMBER(38) NOT NULL,
	CHANGE_DATE					DATE	NOT NULL,	
	ADMINISTRATIVE_CODE     VARCHAR2(20 BYTE),
   HRC_COMPONENT_ID        NUMBER  DEFAULT 1,	
	DML_TYPE						VARCHAR2(10),			
	FIELD_CHANGED				VARCHAR2(30),
	OLD_VALUE					VARCHAR2(130),
	NEW_VALUE					VARCHAR2(130)
);


   COMMENT ON TABLE HHS_CMS_HR.ADMIN_CODE_HISTORY IS 'Provides historical information on the transactions of the administrative_code table';
 
   COMMENT ON COLUMN HHS_CMS_HR.ADMIN_CODE_HISTORY.AC_HISTORY_ID IS 'The unique ID';
		 
   COMMENT ON COLUMN HHS_CMS_HR.ADMIN_CODE_HISTORY.CHANGE_DATE IS 'The date that the change took place';

   COMMENT ON COLUMN HHS_CMS_HR.ADMIN_CODE_HISTORY.ADMINISTRATIVE_CODE IS 'The administrative code on the administrative_code table';	
	
   COMMENT ON COLUMN HHS_CMS_HR.ADMIN_CODE_HISTORY.HRC_COMPONENT_ID IS 'The HRC component id';			
	
   COMMENT ON COLUMN HHS_CMS_HR.ADMIN_CODE_HISTORY.DML_TYPE IS 'The type of DML: ''INSERT'' or ''UPDATE''';			
	
   COMMENT ON COLUMN HHS_CMS_HR.ADMIN_CODE_HISTORY.FIELD_CHANGED IS 'The field that was updated on the administrative_code table';		
	 
   COMMENT ON COLUMN HHS_CMS_HR.ADMIN_CODE_HISTORY.OLD_VALUE IS 'The old value on the administrative_code table';		

   COMMENT ON COLUMN HHS_CMS_HR.ADMIN_CODE_HISTORY.NEW_VALUE IS 'The new value on the administrative_code table';	

 --------------------------------------------------------                                        
 --  DDL for Index ADMIN_CODE_HISTORY_PK                                                                   
 --------------------------------------------------------                                        
   CREATE UNIQUE INDEX HHS_CMS_HR.ADMIN_CODE_HISTORY_PK ON HHS_CMS_HR.ADMIN_CODE_HISTORY (AC_HISTORY_ID);	

	-----------------------------------------------------------
-- DDL for Sequence AC_HISTORY_SEQ										
-----------------------------------------------------------
	CREATE SEQUENCE HHS_CMS_HR.AC_HISTORY_SEQ nocache;
	 
--------------------------------------------------------
--  Constraints for Table ADMIN_CODE_HISTORY
-------------------------------------------------------- 
  ALTER TABLE HHS_CMS_HR.ADMIN_CODE_HISTORY ADD CONSTRAINT ADMIN_CODE_HISTORY_PK PRIMARY KEY (AC_HISTORY_ID) ENABLE;	