CREATE OR REPLACE PACKAGE BODY copy_admin_codes AS

--======================================================
--	- - -	- - - - - - - - - - - - - - - - - - - - - - - -

--PROCEDURES

--	- - -	- - - - - - - - - - - - - - - - - - - - - - - -
--======================================================
--------------------------------------------------------
--PROCEDURE: truncate_admin_code_bk
--DESCRIPTION: Truncate the table administrative_code_bk
--------------------------------------------------------
PROCEDURE truncate_admin_code_bk
IS
	lv_sql	VARCHAR2(100);
BEGIN
	lv_sql := 'TRUNCATE TABLE ADMINISTRATIVE_CODE_BK';
	EXECUTE IMMEDIATE lv_sql;
END;

--------------------------------------------------------
--PROCEDURE: insert_admin_codes
--DESCRIPTION: Fetch admin codes from administrative_code
--------------------------------------------------------
PROCEDURE insert_admin_codes
	(it_admin_codes	admin_csr_tab)
IS
BEGIN
	FORALL i IN it_admin_codes.FIRST.. it_admin_codes.LAST
		INSERT INTO administrative_code_bk VALUES it_admin_codes(i);
END;


--------------------------------------------------------
--PROCEDURE: get_admin_codes
--DESCRIPTION: Fetch admin codes from administrative_code
--------------------------------------------------------
PROCEDURE get_admin_codes
IS
	lt_admin_codes		admin_csr_tab;
BEGIN
	BEGIN 
		OPEN admin_csr;
		FETCH admin_csr
		BULK COLLECT INTO lt_admin_codes;
		CLOSE admin_csr;
	EXCEPTION
		WHEN no_data_found THEN 
			NULL;
	END;
	
	IF lt_admin_codes.COUNT > 0 THEN 
		insert_admin_codes(lt_admin_codes);
	END IF;	
END;


--======================================================
--	- - -	- - - - - - - - - - - - - - - - - - - - - - - -

--FUNCTIONS

--	- - -	- - - - - - - - - - - - - - - - - - - - - - - -
--======================================================
--------------------------------------------------------
--FUNCTION: copy_codes
--DESCRIPTION:
--------------------------------------------------------
FUNCTION copy_codes
RETURN BOOLEAN
IS
BEGIN

	truncate_admin_code_bk;
	
	get_admin_codes;

	COMMIT;
	RETURN TRUE;
EXCEPTION
	WHEN OTHERS THEN
		ROLLBACK;
		RETURN FALSE;
END;

END copy_admin_codes;
/