#!/bin/sh

CLASS_PATH='/home/user/Desktop/locator'

java -cp "$CLASS_PATH/dist/lib/*:$CLASS_PATH/src/main/resources" com.hhs.persondirectory.HHSPersonDirectoryInterfaceApplication