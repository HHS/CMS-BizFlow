GRANT EXECUTE ON bizflow.sp_get_id TO hhs_hr;

GRANT SELECT, INSERT, UPDATE, DELETE ON bizflow.memberinfo TO hhs_hr;
GRANT SELECT, INSERT, UPDATE, DELETE ON bizflow.member TO hhs_hr;
