CREATE VIEW VRLVNTDATA AS select
	c.svrid as svrid, c.procid as procid, c.rlvntdataseq as rlvntdataseq,
	c.ispublic as ispublic, c.valuetype as valuetype, c.parentinouttype as parentinouttype,
	c.rlvntdataname as rlvntdataname,
	c.dispvalue, c.dscpt, c.value, 'I' as scope, 'F' as existdatafile, 0 as fldrid, 0 as grlvntdataid, 0 as orgprocdefid, 0 as fileid
from
	rlvntdata c
where
	c.scope = 'I'
union all
select
	a.svrid as svrid, a.procid as procid, b.rlvntdataseq as rlvntdataseq,
	b.ispublic as ispublic, c.valuetype as valuetype, b.parentinouttype as parentinouttype,
	c.rlvntdatadefname as rlvntdataname,
	c.dispvalue, c.dscpt, c.value, 'D' as scope, 'F' as existdatafile, 0 as fldrid, 0 as grlvntdataid, c.orgprocdefid as orgprocdefid, c.fileid as fileid
from
	procs a, rlvntdata b, drlvntdataval c
where
	a.svrid = b.svrid
	and a.procid = b.procid
	and b.scope = 'D'
	and b.svrid = c.svrid
	and a.orgprocdefid = c.orgprocdefid
	and b.rlvntdataname = c.rlvntdatadefname
union all
select
	b.svrid as svrid, b.procid as procid, b.rlvntdataseq as rlvntdataseq,
	b.ispublic as ispublic, c.valuetype as valuetype, b.parentinouttype as parentinouttype,
	c.name as rlvntdataname,
	c.dispvalue, c.dscpt, c.value, 'G' as scope, 'F' as existdatafile, c.fldrid as fldrid, c.grlvntdataid as grlvntdataid, 0 as orgprocdefid, 0 as fileid
from
	rlvntdata b, grlvntdata c
where
	b.scope = 'G'
	and b.svrid = c.svrid
	and b.rlvntdataname = c.name
union all
select
	a.svrid as svrid, a.procid as procid, 0 as rlvntdataseq,
	b.ispublic as ispublic, c.valuetype as valuetype, b.parentinouttype as parentinouttype,
	c.rlvntdatadefname as rlvntdataname,
	c.dispvalue, c.dscpt, c.value, 'D' as scope, 'F' as existdatafile, 0 as fldrid, 0 as grlvntdataid, c.orgprocdefid as orgprocdefid, c.fileid as fileid
from
	procs a, rlvntdata b, drlvntdataval c
where
	a.svrid = b.svrid
	and a.procid = b.procid
	and b.scope = 'D'
	and b.svrid = c.svrid
	and b.valuetype in ('T', 'O', 'Q', 'B', 'G', 'E')
	and a.orgprocdefid = c.orgprocdefid
	and c.rlvntdatadefname like '#' || b.rlvntdataname || '.%'
	and not exists ( select * from rlvntdata d where d.svrid = a.svrid and d.procid = a.procid and d.scope = 'D' and d.rlvntdataname = c.rlvntdatadefname)
union all
select
	b.svrid as svrid, b.procid as procid, 0 as rlvntdataseq,
	b.ispublic as ispublic, c.valuetype as valuetype, b.parentinouttype as parentinouttype,
	c.name as rlvntdataname,
	c.dispvalue, c.dscpt, c.value, 'G' as scope, 'F' as existdatafile, c.fldrid as fldrid, c.grlvntdataid as grlvntdataid, 0 as orgprocdefid, 0 as fileid
from
	rlvntdata b, grlvntdata c
where
	b.scope = 'G'
	and b.svrid = c.svrid
	and b.valuetype in ('T', 'O', 'Q', 'B', 'G', 'E')
	and c.name like '#' || b.rlvntdataname || '.%'
	and not exists ( select * from rlvntdata a where a.scope = 'G' and a.procid = b.procid and a.rlvntdataname = c.name )
/
