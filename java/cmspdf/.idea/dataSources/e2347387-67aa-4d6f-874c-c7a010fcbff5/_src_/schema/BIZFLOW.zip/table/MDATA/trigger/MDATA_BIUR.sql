CREATE TRIGGER BIZFLOW.MDATA_BIUR
BEFORE INSERT OR UPDATE OF VALUE
  ON BIZFLOW.MDATA
FOR EACH ROW
  DECLARE
-- 12.4.0.0
BEGIN
    IF :new.value is null THEN
		:new.indexvalue := ' ';
        RETURN;
    END IF;

	:new.indexvalue := SUBSTRB(:new.value, 1, 100);
END;
/
