CREATE FUNCTION fn_get_objectname(i_objType IN char, i_objID IN varchar2)
RETURN varchar2 IS
	l_objname varchar2(2000) := '';
-- 12.4.0.0
/*
'F' : Folder
'O' : Organizational unit
'S' : System ini file (x)
'G' : User group
'U' : Authority group
'H' : User group hierarchy
'D' : LDAP package
'I' : BizCove - Definition
'W' : BizCove - Workitem
'M' : BizCove - Monitor
'T' : BizCove - Report
'E' : BizCove - External Report
'L' : BizCove - Report list
'3' : BizCove - URL Viewer
'4' : Menu
'K' : Work Area
'Y' : Terminology (x)
'A' : System user (x)
'Q' : Web service
'C' : Process instance
'V' : Application (WorkitemApplication) (x)
'X' : Application in the Operational Environment
'2' : Application in the Project Environment
'B' : Process Definition in the Operational Environment.
'1' : Process Definition in the Project Environment
'N' : License (x)
'J' : User Custom Attribute Header (x)
'Z' : Undefined (x)
'G' : Global Variable (x)
'P' : Project itself

(x): not impl.
*/
BEGIN
	if i_objType in ('F','P') then
		select name into l_objname from fldrlist where fldrid = i_objID;

	elsif i_objType in ('O','G','H') then
		select name into l_objname from member where memberid = i_objID;

	elsif i_objType in ('I','W','M','T','E','L','K','3','4','D','Q')  then
		select name into l_objname from covelist where id = i_objID;

	elsif i_objType in ('U')  then
		select name into l_objname from fldrmemberlist where fldrid=52 and memberid = i_objID;

	elsif i_objType in ('B')  then
		select name into l_objname from procdef where orgprocdefid = i_objID AND isfinal = 'T' AND envtype='O';

	elsif i_objType in ('1') then
		select name into l_objname from procdef where orgprocdefid = i_objID AND isfinal = 'T' AND envtype='P';

	elsif i_objType in ('X')  then
		select name into l_objname from apptmplt where orgappid = i_objID and isfinal='T' and envtype='O';

	elsif i_objType in ('2')  then
		select name into l_objname from apptmplt where orgappid = i_objID and isfinal='T' and envtype='P';

	elsif i_objType in ('C')  then
		select name into l_objname from procs where procid = i_objID;
	end if;

	return l_objname;
exception
    when others then
        return '';
END;
/
