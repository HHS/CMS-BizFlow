CREATE TRIGGER BIZFLOW.ACTDEF_BIUR
BEFORE INSERT OR UPDATE OF PROVIDERID
  ON BIZFLOW.ACTDEF
FOR EACH ROW
  declare
-- 12.4.0.0
begin
        if :new.providerid = 300 and :new.type = 'O' then
                :new.providerid := 301;
        end if;
end;
/
