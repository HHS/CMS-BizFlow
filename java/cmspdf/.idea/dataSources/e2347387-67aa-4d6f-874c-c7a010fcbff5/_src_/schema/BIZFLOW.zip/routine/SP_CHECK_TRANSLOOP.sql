CREATE procedure sp_check_transloop(i_procdefid in number,
				i_fromnode in number,
				i_tonode in number,
				o_result out number)
is
--
-- 12.4.0.0
--
	l_fromnode	number(10);
	l_tonode	number(10);
	l_count		number(10);
	l_type		char;
begin
	l_fromnode := i_fromnode;
	l_tonode := i_tonode;
	select count(*) into l_count
	from transdef
	where procdefid = i_procdefid and fromnode = l_fromnode;

	o_result := 0;

	if l_count >= 2 then

		l_count := 1;
		while (l_count = 1) loop
			select count(*) into l_count
			from transdef
			where procdefid = i_procdefid and fromnode = l_tonode;

			if l_count = 1 then
				select tonode, type into l_tonode, l_type
				  from transdef
				where procdefid = i_procdefid
				   and fromnode = l_tonode;

				if l_type = 'L' then
					o_result := 1;
					return;
				end if;
			end if;
		end loop;
	end if;
end;
/
