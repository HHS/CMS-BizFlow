CREATE procedure          sp_check_all_parentfldrlist
( i_parentfldrid in number)
   is
--
-- 12.4.0.0
--
cursor cur_get_all_folder is
				select fldrid
					 -- begin of cs14316
					 from fldrlist f
					 where exists
						(select 1 from parentfldr p
						  where p.fldrid = f.fldrid
							and p.dirty = 'T')
					 or not exists
						 (select 1 from parentfldr p
						  where p.fldrid = f.fldrid);
					-- end fo cs14316
cursor cur_get_folder is
				select fldrid
					-- begin of cs14316
					from fldrlist f
					where parentfldrid = i_parentfldrid
					 and exists
						(select 1 from parentfldr p
						  where p.fldrid = f.fldrid
							and p.dirty = 'T')
					 or not exists
						 (select 1 from parentfldr p
						  where p.fldrid = f.fldrid);
					-- end of cs14316
	l_fldrid    integer;
	-- begin of cs14316
	l_isdirty   integer;
	-- end of cs14316
begin
	-- begin of cs14316: reduced disk i/o
	select count(*) into l_isdirty
	from parentfldr pf, fldrlist f
	where pf.fldrid = f.fldrid
		and pf.dirty = 'T';
	if l_isdirty > 0 then
	-- end of cs14316
		-- begin of cs7129 -- added by mhjeong on 2005/05/07 (code merged by kkkim on 2005/10/27 KST)
		delete from parentfldr pf
		where pf.dirty = 'T'
		and exists
		(
			select *
			  from fldrlist fl
			where pf.fldrid = fl.fldrid
		);
		-- end of cs7129 -- added by mhjeong on 2005/05/07 (code merged by kkkim on 2005/10/27 KST)
	-- begin of cs14316: reduced disk i/o
	else
		l_isdirty := 0;
	end if;
	-- end of cs14316
	-- begin of cs14316: reduced possibility of deadlock
	commit;
	-- end of cs14316

	if i_parentfldrid = 0 then
	    open cur_get_all_folder;
		loop
			fetch cur_get_all_folder into l_fldrid;
			exit when cur_get_all_folder%notfound;

			sp_check_parentfldrlist(l_fldrid);
		end loop;

		close cur_get_all_folder;
	else
	    open cur_get_folder;
		loop
			fetch cur_get_folder into l_fldrid;
			exit when cur_get_folder%notfound;

			sp_check_parentfldrlist(l_fldrid);
		end loop;

		close cur_get_folder;
	end if;

exception
    when others then
        if cur_get_all_folder%isopen then
            close cur_get_all_folder;
        end if;
        if cur_get_folder%isopen then
            close cur_get_folder;
        end if;
        raise_application_error(-20715, sqlerrm);
end;
/
