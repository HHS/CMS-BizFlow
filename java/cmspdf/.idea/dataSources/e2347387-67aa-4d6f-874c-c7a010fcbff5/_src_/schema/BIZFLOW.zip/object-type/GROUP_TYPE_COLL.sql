CREATE TYPE group_type_coll AS TABLE OF group_type;
/
