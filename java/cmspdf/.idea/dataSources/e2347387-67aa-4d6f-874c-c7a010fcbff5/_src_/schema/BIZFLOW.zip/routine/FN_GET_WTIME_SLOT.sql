CREATE function        fn_get_wtime_slot
  (	i_isdefault IN char,
	i_dayofweek IN char,
	i_memberid IN varchar2,
  	i_cal_date IN date,
	i_cur_date IN date,
	i_deadline IN number)
  RETURN  date IS
-- 12.4.0.0
   sw1				number;
   ew1				number;
   sw2				number;
   ew2				number;
   sw3				number;
   ew3				number;
   sw4				number;
   ew4				number;
   sw5				number;
   ew5				number;

   l_ret_date		date := i_cal_date;
   l_cur_date		date := i_cur_date;
   l_deadline		number := i_deadline;
BEGIN

	if i_isdefault = 'T' then
		select sworktime1, eworktime1, sworktime2, eworktime2, sworktime3, eworktime3,
				 sworktime4, eworktime4, sworktime5, eworktime5
			into sw1, ew1, sw2, ew2, sw3, ew3, sw4, ew4, sw5, ew5
			from calhead
			where memberid = i_memberid
				and dayofweek = i_dayofweek;
	else
		select sworktime1, eworktime1, sworktime2, eworktime2, sworktime3, eworktime3,
				 sworktime4, eworktime4, sworktime5, eworktime5
			into sw1, ew1, sw2, ew2, sw3, ew3, sw4, ew4, sw5, ew5
			from membercal
			where memberid = i_memberid
				and caldtime = i_cal_date;
	end if;

--dbms_output.put_line('l_deadline = ' || to_char(l_deadline));

	if sw1 <> 0 or ew1 <> 0 then
		l_ret_date := i_cal_date + sw1/86400 + l_deadline/86400;
		if ew1 - sw1 >= l_deadline
			and l_ret_date >= l_cur_date then
--dbms_output.put_line('l_ret_date = ' || to_char(l_ret_date));
		    RETURN l_ret_date;
		else
			l_deadline := l_deadline - (ew1 - sw1);
		end if;
	end if;

	if sw2 <> 0 and ew2 <> 0 then
		l_ret_date := i_cal_date + sw2/86400 + l_deadline/86400;
		if ew2 - sw2 >= l_deadline
			and l_ret_date >= l_cur_date then
		    RETURN l_ret_date;
		else
			l_deadline := l_deadline - (ew2 - sw2);
		end if;
	end if;

	if sw3 <> 0 and ew3 <> 0 then
		l_ret_date := i_cal_date + sw3/86400 + l_deadline/86400;
		if ew3 - sw3 >= l_deadline
			and l_ret_date >= l_cur_date then
		    RETURN l_ret_date;
		else
			l_deadline := l_deadline - (ew3 - sw3);
		end if;
	end if;

	if sw4 <> 0 and ew4 <> 0 then
		l_ret_date := i_cal_date + sw4/86400 + l_deadline/86400;
		if ew4 - sw3 >= l_deadline
			and l_ret_date >= l_cur_date then
		    RETURN l_ret_date;
		else
			l_deadline := l_deadline - (ew4 - sw4);
		end if;
	end if;

	if sw5 <> 0 and ew5 <> 0 then
		l_ret_date := i_cal_date + sw5/86400 + l_deadline/86400;
		if ew5 - sw5 >= l_deadline
			and l_ret_date >= l_cur_date then
		    RETURN l_ret_date;
		else
			l_deadline := l_deadline - (ew5 - sw5);
		end if;
	end if;

    RETURN l_ret_date;
END;
/
