CREATE FUNCTION		 fn_check_password_age
  (
	i_loginid		IN VARCHAR2,
	i_encpassword	IN VARCHAR2)
  RETURN  INT IS
	l_rowcount		INT;
	l_offset		INT;
-- 12.4.0.0
BEGIN
	-- l_rowcount should be 0 to pass history check

	l_offset := fn_get_configuration_valuen('PASSWORD', 'MAX_DAY_OF_PASSWORD_IN_HISTORY', 0);

	IF (l_offset = 0) THEN
		l_rowcount := 0;
	ELSE
		SELECT COUNT(1) INTO l_rowcount FROM (
		SELECT p.memberid, p.passwd, p.lastuseddtime AS dtime FROM password p, member m
		 WHERE p.memberid = m.memberid
		   AND m.loginid = i_loginid
		   AND p.passwd = i_encpassword
		   AND p.lastuseddtime > getutcdate() - l_offset
		 UNION ALL
		SELECT memberid, passwd, passwddtime AS dtime FROM member
		 WHERE memberid = i_loginid
		   AND passwd = i_encpassword
		);
	END IF;

	RETURN l_rowcount;
END;
/
