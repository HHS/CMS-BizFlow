CREATE function GetIncentiveRequestNumber(OfDay date default sysdate ) return number is  
  
  SequenceName  varchar2(30) default to_char( OfDay, '"IncentivesRequestId"yyyymmdd' );
  SequenceValue number;  
  SequenceCount number;

  pragma autonomous_transaction;

begin  

    select count(*) into SequenceCount FROM all_objects WHERE object_type = 'SEQUENCE' AND OBJECT_NAME = SequenceName;

    if SequenceCount = 0 then
        begin
            execute immediate 'create sequence ' || SequenceName;
        end;
    end if;

    execute immediate 'select ' || SequenceName || '.nextval from dual' into SequenceValue;   
    return SequenceValue;   
end;
/
