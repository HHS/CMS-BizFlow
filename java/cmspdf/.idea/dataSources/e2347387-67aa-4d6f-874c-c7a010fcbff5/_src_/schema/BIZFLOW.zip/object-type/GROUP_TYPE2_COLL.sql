CREATE TYPE group_type2_coll AS TABLE OF group_type2;
/
