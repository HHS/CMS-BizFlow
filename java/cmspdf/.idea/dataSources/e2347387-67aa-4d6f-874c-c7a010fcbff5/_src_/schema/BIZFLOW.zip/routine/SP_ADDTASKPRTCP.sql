CREATE PROCEDURE sp_addtaskprtcp
    (IN_TASKID     IN  NUMBER,
    IN_SUBTASKID   IN NUMBER,
    IN_PRTCP       IN VARCHAR2,
    IN_TYPE        IN CHAR,
    IN_KIND        IN VARCHAR2)
IS
    L_COUNT NUMBER;
-- 12.4.0.0
BEGIN

    IF (IN_KIND IS NULL) THEN
    SELECT COUNT(1) INTO L_COUNT FROM taskprtcp WHERE taskid = IN_TASKID
												  AND subtaskid = IN_SUBTASKID
                                                      AND prtcp = IN_PRTCP
                                                      AND kind IS NULL;
    ELSE
        SELECT COUNT(1) INTO L_COUNT FROM taskprtcp WHERE taskid = IN_TASKID
													AND subtaskid = IN_SUBTASKID
												  AND prtcp = IN_PRTCP
												  AND kind = IN_KIND;
	    END IF;

    -- if data exist do not add
	IF (L_COUNT = 0) THEN
		IF (IN_TYPE = 'E') THEN -- external user
    	    INSERT INTO taskprtcp(taskid, subtaskid, prtcp, type, kind, externaluser)
                    VALUES(IN_TASKID, IN_SUBTASKID, '9999999999', IN_TYPE, IN_KIND, IN_PRTCP);
		ELSE
	        INSERT INTO taskprtcp(taskid, subtaskid, prtcp, type, kind)
                    VALUES(IN_TASKID, IN_SUBTASKID, IN_PRTCP, IN_TYPE, IN_KIND);
		END IF;

	END IF;

END;
/
