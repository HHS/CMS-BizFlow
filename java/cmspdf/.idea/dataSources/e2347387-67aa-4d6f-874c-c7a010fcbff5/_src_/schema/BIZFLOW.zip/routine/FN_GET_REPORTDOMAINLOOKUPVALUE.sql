CREATE FUNCTION fn_get_reportdomainlookupvalue(i_lookup_path IN varchar2, i_lookup_value IN varchar2)
RETURN varchar2 IS
  l_label varchar2(256) := '';

BEGIN
  select label into l_label from reportdomainlookup
   where path = i_lookup_path
     and value = i_lookup_value;

  return l_label;

EXCEPTION
  WHEN OTHERS THEN
    return '';
END;
/
