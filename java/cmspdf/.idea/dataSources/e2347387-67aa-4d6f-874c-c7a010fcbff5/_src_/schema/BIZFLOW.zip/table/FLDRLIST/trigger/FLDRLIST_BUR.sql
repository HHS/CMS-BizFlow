CREATE TRIGGER BIZFLOW.FLDRLIST_BUR
BEFORE UPDATE OF INHERITTYPE, PARENTFLDRID, NAME
  ON BIZFLOW.FLDRLIST
FOR EACH ROW
  DECLARE
	l_updated			number;
	l_transactionid		varchar2(50);

-- 12.4.0.0
BEGIN
	-- Pass key to fldrlist_aur
	l_updated := 0;

	-- If moved
	if (:new.parentfldrid <> :old.parentfldrid) then
		l_updated := l_updated + 1;
	end if;

	if ( :new.inherittype <> :old.inherittype ) then
		l_updated := l_updated + 2;
	end if;

	if ( :new.name <> :old.name ) then
		l_updated := l_updated + 4;
	end if;

	if (l_updated > 0) then
	    select DBMS_TRANSACTION.LOCAL_TRANSACTION_ID into l_transactionid from dual;

		insert into hwtemp (tmpkey, vara, varb)
		values (l_transactionid, :new.fldrid, l_updated);
		--dbms_output.put_line('fldrlist_bur updated = ' || l_transactionid || ', ' || :new.fldrid || ', ' || l_updated);
	end if;

EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20937, SQLERRM);
END;
/
