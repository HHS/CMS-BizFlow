CREATE procedure sp_delete_member
  (
	 i_memberid  in varchar2,
	 i_membertype in char
  )
is
--
-- 12.4.0.0
--
	l_cnt					number;
	l_membertype			char;
	cannot_surr 			exception;
	cannot_manager		exception;
	cannot_prtcpusrgrp		exception;
	cannot_prtcpdef 		exception;
	cannot_prtcpprocs		exception;
	cannot_prtcpwitem		exception;
	cannot_chkoutuser		exception;
	cannot_pd_chkoutuser	exception;
	cannot_pi_chkoutuser	exception;
	cannot_usrgrphr 		exception;
	cannot_auth_grp 		exception;
	cannot_project_role	exception;

begin
	l_membertype := i_membertype;

	if l_membertype = '?' then
		select type into l_membertype from member
			where memberid = i_memberid;
	end if;

	if l_membertype = 'U' then
		select count(1) into l_cnt from member m
			where m.abssurrogater = i_memberid
				and m.type = 'U'
				and m.isabsent = 'T';

		if (l_cnt > 0) then
			raise cannot_surr;
		end if;
	end if;

	if l_membertype = 'H' then
		select count(1) into l_cnt from member m
			where m.type = 'G'
				and m.deptid = i_memberid;

		if (l_cnt > 0) then
			raise cannot_usrgrphr;
		end if;

		select count(1) into l_cnt from prtcpdef p
			where p.usrgrphid = i_memberid;
		if (l_cnt > 0) then
			raise cannot_prtcpdef;
		else
			select count(1) into l_cnt from prtcp p, procs pr
				where p.usrgrphid = i_memberid
					and pr.procid = p.procid
					and pr.state in ('N', 'R', 'E', 'V', 'S', 'D','J');
			if (l_cnt > 0) then
				raise cannot_prtcpprocs;
			end if;
		end if;
	end if;

-- No check on the user group membership.
--	select count(1) into l_cnt from usrgrpprtcp m, member n
--		where m.prtcp = i_memberid
--			and m.usrgrpid = n.memberid
--			and n.type <> 'A'
--			and n.type <> 'L';

--	if (l_cnt > 0) then
--		raise cannot_prtcpusrgrp;
--	end if;

--	remove this check code 2002.3.22 by cspark
--	In case of department, when delete the manager, it's manager changed to '0000000000' or '9999999999'
--	In case of user, there is no meaning of manager
--	select count(*) into l_cnt from member m
--		where managerid = i_memberid
--			and type in ('U', 'D');

--	if (l_cnt > 0) then
--		raise cannot_manager;
--	end if;

	select count(1) into l_cnt from prtcpdef
		where prtcp = i_memberid
			and type = l_membertype;
	if (l_cnt > 0) then
		raise cannot_prtcpdef;
	end if;

	select count(1) into l_cnt from prtcp a, procs b
		where a.prtcp = i_memberid
			and a.type = l_membertype
			and b.svrid = a.svrid
			and b.procid = a.procid
			and b.state in ('R','E','V','S','D','J');
	if (l_cnt > 0) then
		raise cannot_prtcpprocs;
	end if;

	select count(1) into l_cnt from witem
		where prtcp = i_memberid
			and prtcptype = l_membertype
			and state in ('I', 'R', 'V', 'S', 'P', 'Y');
	if (l_cnt > 0) then
		raise cannot_prtcpwitem;
	end if;

	select count(1) into l_cnt from checkout
		where memberid = i_memberid
			and type = 'O';
	if (l_cnt > 0) then
		raise cannot_chkoutuser;
	end if;

	select count(1) into l_cnt from procdef
		where checkoutusr = i_memberid;
	if (l_cnt > 0) then
		raise cannot_pd_chkoutuser;
	end if;

	select count(1) into l_cnt from procs
		where checkoutusr = i_memberid
		and state in ('R','E','V','S','D','J');
	if (l_cnt > 0) then
		raise cannot_pi_chkoutuser;
	end if;

	if l_membertype = 'A' then
		-- delete the fldrlist in which publisher has authority to publish items(proc.def or apptmplt).
		-- delete the fldrlist in which project-role has authority about the project.
		if i_memberid like 'prja%' then
			delete from fldrmemberlist fm
				where fm.memberid = i_memberid
					and exists (select fl.fldrid from fldrlist fl where fl.fldrid = fm.fldrid
									and (fl.prjid = 0 or fl.type = 'J'));
		end if;

		select count(1) into l_cnt from usrgrpprtcp u, member m
			where u.usrgrpid = i_memberid
				and m.memberid = u.usrgrpid
				and m.type = 'A';				-- Authority
		if (l_cnt > 0) then
			if i_memberid like 'prja%' then
				raise cannot_project_role;
			else
				raise cannot_auth_grp;
			end if;
		end if;

		select count(1) into l_cnt from orgmanagerlist o, member m
			where o.managerid = i_memberid
				and m.memberid = o.managerid
				and m.type = 'A';				-- Authority
		if (l_cnt > 0) then
			if i_memberid like 'prja%' then
				raise cannot_project_role;
			else
				raise cannot_auth_grp;
			end if;
		end if;

		select count(1) into l_cnt from fldrmanagerlist f, member m
			where f.managerid = i_memberid
				and m.memberid = f.managerid
				and m.type = 'A';				-- Authority
		if (l_cnt > 0) then
			if i_memberid like 'prja%' then
				raise cannot_project_role;
			else
				raise cannot_auth_grp;
			end if;
		end if;
	end if;

	delete from sso
		where memberid = i_memberid;

-- Delete all memberships.
	delete from usrgrpprtcp a
		where a.prtcp = i_memberid;
--			and exists (select * from member b where b.memberid = a.usrgrpid and b.type = 'A');
--
--	delete from usrgrpprtcp a
--		where a.prtcp = i_memberid
--			and exists (select * from member b where b.memberid = a.usrgrpid and b.type = 'L');

	if (l_membertype = 'G' or l_membertype = 'A') then
		delete from usrgrpprtcp where usrgrpid = i_memberid;
	end if;

	delete from fldrmemberlist
		where memberid = i_memberid;

	update member set abssurrogater = ''
		where isabsent = 'F'
			and abssurrogater = i_memberid;

	if (l_membertype = 'D' or l_membertype = 'G' or l_membertype = 'H') then
		delete from orgmanagerlist where memberid = i_memberid;
	end if;

	delete from memberinfo
		where memberid = i_memberid;

	delete from member
		where memberid = i_memberid;

exception
	when cannot_manager then
		raise_application_error(-20506, 'This Member is Manager of Others');
	when cannot_prtcpusrgrp then
		raise_application_error(-20507, 'This Member is Prtcp of UserGroups');
	when cannot_prtcpdef then
		raise_application_error(-20508, 'This Member is Prtcp of Process Definitions');
	when cannot_prtcpprocs then
		raise_application_error(-20509, 'This Member is Prtcp of Process Instances');
	when cannot_prtcpwitem then
		raise_application_error(-20510, 'This Member is Prtcp of Workitems');
	when cannot_chkoutuser then
		raise_application_error(-20511, 'This Member is Org CheckOut User');
	when cannot_surr then
		raise_application_error(-20512, 'This Member is Surrogater of Others');
	when cannot_usrgrphr then
		raise_application_error(-20518, 'This Member has User Groups');
	when cannot_pd_chkoutuser then
		raise_application_error(-20527, 'This Member is a user who checks out a process definition.');
	when cannot_pi_chkoutuser then
		raise_application_error(-20528, 'This Member is a user who checks out a process instance.');
	when cannot_auth_grp then
		raise_application_error(-20531, 'This autority group is being used.');
	when cannot_project_role then
		raise_application_error(-20536, 'This project role is not empty or being used.');
	when others then
		raise_application_error(-20709, sqlerrm);
end;
/
