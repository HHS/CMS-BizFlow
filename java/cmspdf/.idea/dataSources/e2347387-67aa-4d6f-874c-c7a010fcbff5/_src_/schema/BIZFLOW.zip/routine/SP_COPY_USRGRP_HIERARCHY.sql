CREATE procedure	sp_copy_usrgrp_hierarchy
(
	i_key			in varchar2,
	i_svrid			in varchar2,
	i_memberid		in varchar2,
	i_membername	in varchar2,
	i_maxcount		in number
)
is
--
-- 12.4.0.0
--
	cursor cur_get_group (l_memberid varchar2) is
	select memberid from vusrgrp
	 where deptid = l_memberid
	   and type in ('G','D');

	cursor cur_get_id (l_key varchar2) is
	select vara, varb from vusrgrp v, hwtemp t
	 where v.memberid = t.vara
	   and v.type <> 'H'
	   and t.tmpkey = l_key;

	l_cnt			number;
	l_newhid		number;
	l_newgid		number;
	l_newgidinc		number;
	l_strvorghid	varchar2(10);
	l_strnorghid	varchar2(10);
	l_strnewhid		varchar2(10);
	l_strnewgid		varchar2(10);
	l_stroldgid		varchar2(10);
	l_strnewpid		varchar2(10);
	l_inherittype	char;
	nosource		exception;
	namedup			exception;
	exceedcnt		exception;
	errm			varchar2(80);

begin
	-- Initialization of values
	-- ID of virtual hierarchy of organization chart
	l_strvorghid := '9999999996';

	-- validation of source usergroup hierarchy
	select count(1) into l_cnt
	  from vusrgrp
	 where memberid = i_memberid
	   and type = 'H';
	if (l_cnt <> 1) then
		errm := 'There is no source Usergroup Hierarchy.';
		raise nosource;
	end if;

	-- check for duplicated name of usergroup hierarchy
	select count(*) into l_cnt
	  from vusrgrp
	 where name = i_membername
	   and type = 'H'
	   and memberid <> l_strvorghid;
	if (l_cnt > 0) then
		errm := 'There are Usergroup Hierarchy which name is duplicated.';
		raise namedup;
	end if;

	-- check count of usergroup hierarchy
	select count(1) into l_cnt
	  from vusrgrp
	 where type = 'H'
	   and state = 'A'
	   and memberid <> l_strvorghid;
	if (l_cnt >= i_maxcount) then
		errm := 'There are too many Usergroup Hierarchy.';
		raise exceedcnt;
	end if;

	-- get id for new usergroup hierarchy
	sp_get_id(i_svrid, 'MemberID', 1, l_newhid);
	l_strnewhid := lpad(to_char(l_newhid), 10, '0');

	-- get the next display order number of UH.
	select max(disporder)+1 into l_cnt
	  from vusrgrp
	 where type = 'H';

	-- copy record of memberinfo table for usergroup hierarchy
	insert into memberinfo (memberid, dupusrflag, dupnameflag, managerrule)
				  select l_strnewhid, dupusrflag, dupnameflag, managerrule
	  from vusrgrp
	 where memberid = i_memberid;

	-- copy record of member table for usergroup hierarchy
	insert into member(memberid, memberinfoid, name, disporder, type, state)
		  select l_strnewhid, l_strnewhid, i_membername, l_cnt, 'H', state
	 from vusrgrp
	where memberid = i_memberid;

	-- insert mapping record between old and new groupid
	insert into hwtemp (tmpkey, vara, varb)
	values (i_key,i_memberid,l_strnewhid);

	-- copy record of usrgrpprtcp table for authority
	insert into usrgrpprtcp (usrgrpid, prtcp, prtcptype, disporder)
				   select usrgrpid, l_strnewhid, prtcptype, disporder
					 from vusrgrpprtcp
					where prtcp = i_memberid;

	-- copy record of orgmanagerlist table for administrative group
	if (i_memberid <> l_strvorghid) then
		insert into orgmanagerlist (svrid, memberid, managerid, auth, disporder, name)
							 select svrid, l_strnewhid, managerid, auth, disporder, name
							   from orgmanagerlist
							  where memberid = i_memberid;
	else
		insert into orgmanagerlist (svrid, memberid, managerid, auth, disporder, name)
				values (i_svrid, l_strnewhid, 'authgrp002', 112, 1, 'General Administrator');
	end if;

	-- get count of usergroup
	select count(1) into l_cnt
	  from vusrgrp
	 where deptid = i_memberid
	   and type in ('G','D');

	if (l_cnt > 0) then
		sp_get_id(i_svrid, 'MemberID', l_cnt, l_newgid);

		-- insert old and new id into hwtemp table
		open cur_get_group(i_memberid);
		l_newgidinc := 0;
		loop
			fetch cur_get_group into l_stroldgid;
			exit when cur_get_group%notfound;

			l_strnewgid := lpad(to_char(l_newgid + l_newgidinc), 10, '0');

			-- insert mapping record between old and new groupid
			insert into hwtemp (tmpkey, vara, varb)
			values (i_key,l_stroldgid,l_strnewgid);

			l_newgidinc := l_newgidinc + 1;
		end loop;
		close cur_get_group;

		-- copy record of usergroup and usergroup participants
		open cur_get_id(i_key);
		loop
			fetch cur_get_id into l_stroldgid, l_strnewgid;
			exit when cur_get_id%notfound;

			-- copy record of member table for usergroup
			insert into member
					(memberid, type, inherittype, name, disporder, deptid, managerid, parentdeptid)
			select l_strnewgid, 'G', vg.inherittype, vg.name, vg.disporder, l_strnewhid, vg.managerid, t.varb
			  from vusrgrp vg, hwtemp t
			 where vg.memberid = l_stroldgid
			   and vg.parentdeptid = t.vara
			   and t.tmpkey = i_key;

			-- copy record of usrgrpprtcp table for usergroup participants
			insert into usrgrpprtcp (usrgrpid, usrgrphid, prtcp, prtcptype, disporder)
                         select l_strnewgid, l_strnewgid, prtcp, prtcptype, disporder
			               from vusrgrpprtcp
			              where usrgrpid = l_stroldgid;

			if (i_memberid <> l_strvorghid) then
				-- copy record of usrgrpprtcp table for authority
				insert into usrgrpprtcp (prtcp, usrgrpid, prtcptype, disporder)
							select l_strnewgid, usrgrpid, prtcptype, disporder
						      from vusrgrpprtcp
							 where prtcp = l_stroldgid;

				-- copy record of orgmanagerlist table for administrative group
				insert into orgmanagerlist
				         (memberid, svrid, managerid, auth, disporder, name)
                select l_strnewgid, svrid, managerid, auth, disporder, name
                  from orgmanagerlist
                 where memberid = l_stroldgid;
			else
				select inherittype into l_inherittype from vusrgrp
				where memberid = l_stroldgid;

				if (l_inherittype = 'N' or l_inherittype = 'U') then
					select count(*) into l_cnt from orgmanagerlist
					where memberid = l_stroldgid and managerid = 'authgrp004';

					if (l_cnt < 1) then
						-- copy record of orgmanagerlist table for administrative group
						insert into orgmanagerlist
						         (memberid, svrid, managerid, auth, disporder, name)
						select l_strnewgid, i_svrid, memberid, 112, 0, name
						  from member
						 where memberid = 'authgrp004';
					end if;
				end if;
			end if;
		end loop;
		close cur_get_id;

		-- delete temporary record in hwtemp
		delete from hwtemp where tmpkey = i_key;
	end if;

exception
	when nosource then
		raise_application_error(-20519, errm);
	when namedup then
		raise_application_error(-20520, errm);
	when exceedcnt then
		raise_application_error(-20521, errm);
	when others then
		raise_application_error(-20735, sqlerrm);
end; -- procedure
/
