CREATE procedure         sp_copy_app
    ( i_svrid in varchar2,
      i_appid in number,
      i_fldrsvrid in varchar2,
      i_fldrid in number,
	  i_isprojectfolder in number,
      i_nsvrid in varchar2,
      i_nappid in number,
      i_nfldrsvrid in varchar2,
      i_nfldrid in number,
	  i_nisprojectfolder in number,
      i_appver in number,
      i_creationdtime in date,
      o_napptype out char,
	 o_dmdocrtype out char)
   is
      l_cnt			number;
      cannotcopy	exception;
      errm			varchar2(800);
--
-- 12.4.0.0
--
begin
    -- validation of source app.
	if (i_isprojectfolder = 0) then
		-- (source) operational environment.
		select count(*) into l_cnt from apptmplt
			where svrid = i_svrid
				and appid = i_appid
				and fldrsvrid = i_fldrsvrid
				and fldrid = i_fldrid;
		if (l_cnt <> 1) then
			errm := 'There is no Application in the Folder.';
			raise cannotcopy;
		end if;

		select type, dmdocrtype
				into o_napptype, o_dmdocrtype
			from apptmplt
			where svrid = i_svrid
				and appid = i_appid
				and fldrsvrid = i_fldrsvrid
				and fldrid = i_fldrid;
	else
		-- (source) project environment.
		select count(*) into l_cnt from apptmplt
			where svrid = i_svrid
				and appid = i_appid
				and fldrsvrid = i_fldrsvrid
				and prjfldrid = i_fldrid;
		if (l_cnt <> 1) then
			errm := 'There is no Application in the Folder.';
			raise cannotcopy;
		end if;

		select type, dmdocrtype
				into o_napptype, o_dmdocrtype
			from apptmplt
			where svrid = i_svrid
				and appid = i_appid
				and fldrsvrid = i_fldrsvrid
				and prjfldrid = i_fldrid;
	end if;

	insert into apptmplt
	( svrid, appid, isfinal, type, envtype, pkitype, dmdocrtype, dmsaveflag, dmidtype,
		fldrsvrid, fldrid, appver, creationdtime, keepingflag,
		publicationstate, prjfldrid, orgappid, preappid,
		name, author, authorname, invokedmethod, extname,
		dmsvrid, dmdocid, dmfldrid, dmfldrname, dscpt
	)
	select
	i_nsvrid, i_nappid, isfinal, type, envtype, pkitype, dmdocrtype, dmsaveflag, dmidtype,
		fldrsvrid, fldrid, i_appver, i_creationdtime, keepingflag,
		publicationstate, prjfldrid, orgappid, preappid,
		name, author, authorname, invokedmethod, extname,
		dmsvrid, dmdocid, dmfldrid, dmfldrname, dscpt
	from apptmplt
		where svrid = i_svrid
		and appid = i_appid;

    -- table apptmplt
	if (i_isprojectfolder = 0 and i_nisprojectfolder = 0) then
		-- copy app. in the operational env.
		update apptmplt
			set fldrid = i_nfldrid, prjfldrid = 0, orgappid = i_nappid, preappid = i_nappid
			where svrid = i_svrid
				and appid = i_nappid;
	else
	if (i_isprojectfolder = 1 and i_nisprojectfolder = 1) then
		-- copy app. in the project env.
		update apptmplt
			set fldrid = 0, prjfldrid = i_nfldrid, orgappid = i_nappid, preappid = i_nappid
			where svrid = i_svrid
				and appid = i_nappid;
	else
	if (i_isprojectfolder = 0 and i_nisprojectfolder = 1) then
		-- import api(from operational env. to project env.).
		update apptmplt
			set prjfldrid = i_nfldrid
			where svrid = i_svrid
				and orgappid = (select orgappid from apptmplt where svrid = i_svrid and appid = i_appid);

		update apptmplt
			set isfinal = 'T', envtype= 'P', publicationstate = 'O', preappid = i_appid
			where svrid = i_svrid
				and appid = i_nappid;

		update procappdef
		set appid = i_nappid
		where svrid = i_svrid
			and orgappid = (select orgappid from apptmplt where svrid = i_svrid and appid = i_appid)
			and envtype = 'O'
			and procdefid in (select procdefid from procdef where isfinal = 'T' and envtype = 'P');
	else
		-- publish api(from project env. to operational env.).
		update apptmplt
			set isfinal = 'F'
			where svrid = i_svrid
				and orgappid = (select orgappid from apptmplt where svrid = i_svrid and appid = i_appid)
				and envtype = 'O'
				and isfinal = 'T';

		update apptmplt
			set fldrid = i_nfldrid
			where svrid = i_svrid
				and orgappid = (select orgappid from apptmplt where svrid = i_svrid and appid = i_appid);

		update apptmplt
			set isfinal = 'T', envtype= 'O', publicationstate = 'P', preappid = i_appid
			where svrid = i_svrid
				and appid = i_nappid;
	end if;
	end if;
	end if;

exception
    when cannotcopy then
        raise_application_error(-20503, errm);
    when others then
        raise_application_error(-20705, sqlerrm);
end; -- procedure
/
