CREATE VIEW V_RESPONSES AS SELECT
	TaskID,
	SubTaskID,
	AssigneeResponseDate,
	InitiatorResponseDate,
	AssigneeResponse,
	InitiatorResponse
FROM Responses
UNION ALL
SELECT
	TaskID,
	SubTaskID,
	AssigneeResponseDate,
	InitiatorResponseDate,
	AssigneeResponse,
	InitiatorResponse
FROM CompleteResponses
/
