CREATE TYPE designee_type_coll AS TABLE OF designee_type;
/
