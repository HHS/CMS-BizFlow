CREATE VIEW VWORKLIST AS SELECT  a.name AS procname, a.urgent AS procurgent, a.creator AS proccreator, a.creatorname AS proccreatorname, a.deadline AS procdeadline,
  a.cmntcnt AS proccmntcnt, a.attachcnt AS procattachcnt, a.dscpt AS procdscpt, a.presvrid, a.preprocdefid, a.passwdflag,
  a.deadlinedtime AS procdeadlinedtime, a.instfldrid, a.archivefldrid, a.state AS procstate, a.customid, b.name AS actname, b.dscpt, b.type AS acttype,
  b.deadlinetype AS actdeadlinetype, b.state AS actstate, b.defsvrid AS actdefsvrid, b.priority AS actpriority, b.deadline AS actdeadline, b.subproctype,
  b.actinfo, b.respgrpseq, b.respseq AS actrespseq, b.isrepsign, b.cmpltcnt, b.subsvrid, b.suborgprocdefid, b.actauth, b.attaddcnt, b.resplist, c.svrid,
  c.procid, c.witemseq, c.prtcptype, c.state, c.urgent, c.actseq, c.prtcp, c.priority, c.creationdtime, c.startdtime, c.cmpltdtime, c.deadline, c.existinfofile,
  c.cmpltusr AS completeuserid, c.cmpltusrname AS completeusername, c.prtcpname AS participantname, c.deadlinedtime, c.respseq,
  c.prtcptype AS witemtype, v.issurrogater, v.memberid, a.orgprocdefid, a.lastcorrespondence
FROM  procs a, act b, witem c, vmyprtcp v
WHERE a.svrid = c.svrid AND a.procid = c.procid
AND c.svrid = b.svrid AND c.procid = b.procid AND c.actseq = b.actseq
AND c.prtcp = v.prtcp
AND (c.onasync IN ('F')) AND (c.checkoutusr IS NULL OR c.checkoutusr = v.memberid) AND c.state in ('I','R','P','V')
AND (v.issurrogater = 'F' or (v.issurrogater = 'T' and v.absstartdtime <= getutcdate and v.absenddtime > getutcdate))
/
