CREATE TRIGGER BIZFLOW.ACCOUNT_BIR
BEFORE INSERT
  ON BIZFLOW.ACCOUNT
FOR EACH ROW
  BEGIN
    --:new.id := hws_account.nextval; only works in 11g
    select hws_account.nextval into :new.id from dual;
EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20949, SQLERRM);
END;
/
