CREATE function		 fn_get_lastcorrespondence
(
	i_procid IN number
)
  RETURN  varchar2 IS
	l_value 		varchar2(100) := NULL;
	l_rootProcId 	INT;
-- 12.4.0.0
BEGIN
	 SELECT procid
	   INTO l_rootProcId
	   FROM procs WHERE parentprocid = 0
	CONNECT BY PRIOR parentprocid = procid
	  START WITH procid = i_procid;

	SELECT lastcorrespondence INTO l_value
	  FROM ( SELECT p.lastcorrespondence
			  FROM Correspondence c, (
				SELECT procid, lastcorrespondence FROM procs
				CONNECT BY PRIOR procid = parentprocid
				START WITH procid = l_rootProcId ) p
			 WHERE c.procid = p.procid
			ORDER BY c.sentdate DESC )
	WHERE ROWNUM <= 1;

	IF l_value IS NULL THEN
		RETURN NULL;
	END IF;

	RETURN l_value;

EXCEPTION WHEN OTHERS THEN
    RETURN NULL;
END;
/
