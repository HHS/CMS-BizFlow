CREATE FUNCTION FN_GETCMPLSUBTASKCOMMENTSCNT (IN_TASKID IN NUMBER, IN_SUBTASKID IN NUMBER)
    RETURN NUMBER
IS
    L_RESULTVAR   NUMBER;
-- 12.4.0.0
BEGIN

    SELECT COUNT(1) INTO L_RESULTVAR FROM cmnt c, witem w, act a, CompleteSubTasks s
        WHERE c.svrid = w.svrid AND c.procid = w.procid AND c.witemseq = w.witemseq
        AND w.svrid = a.svrid AND w.procid = a.procid AND w.actseq = a.actseq
        AND a.procid = s.ProcID AND a.actseq IN (
            select objseq from mdata where ObjType = 'A' AND ObjSubType ='P' AND ValueType='S' AND  procid = s.ProcID AND name = 'subtaskid' AND value = TO_CHAR( s.SubTaskID )
        )
        AND LENGTH(c.contents) > 0
        AND s.TaskID = IN_TASKID AND s.SubTaskID = IN_SUBTASKID;

    RETURN L_RESULTVAR;
END;
/
