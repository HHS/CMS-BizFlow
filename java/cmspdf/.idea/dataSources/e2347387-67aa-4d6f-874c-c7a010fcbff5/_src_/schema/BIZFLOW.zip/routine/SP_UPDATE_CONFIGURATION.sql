CREATE procedure sp_update_configuration
   (
     i_modifierID	in varchar2,
     i_section		in varchar2,
     i_entry		in varchar2,
     i_value		in varchar2,
     i_description	in varchar2)
   is
--
-- 12.4.0.0
--
l_count	int;
l_section varchar2(100);
l_entry varchar2(100);
begin
    l_section := upper(i_section);
    l_entry := upper(i_entry);

    SELECT count(*) INTO l_count FROM configuration WHERE section = l_section AND entry = l_entry;

    IF 0 < l_count THEN
		IF i_description IS NULL THEN
			UPDATE configuration SET value = i_value WHERE section = l_section AND entry = l_entry;
		ELSE
			UPDATE configuration SET value = i_value, description=i_description WHERE section = l_section AND entry = l_entry;
		END IF;
    ELSE
		INSERT INTO configuration (section, entry, value, description) VALUES (l_section, l_entry, i_value, i_description);
    END IF;
end; -- procedure
/
