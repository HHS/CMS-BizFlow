CREATE procedure          sp_delete_proc
   (
     i_svrid in varchar2,
     i_procid in number)
   is
--
-- 12.4.0.0
--
i_taskid NUMBER;
i_cnt NUMBER;
begin
    -- bug17939-CS-13487 [CJmall] Deadlock occurs on deadline table. (same with cs5216)
    -- begin of cs13487
    commit;
    -- end of cs13487
    delete deadline			where svrid = i_svrid  and procid = i_procid;
    delete act				where svrid = i_svrid  and procid = i_procid;
    delete witem			where svrid = i_svrid  and procid = i_procid;
    delete procs			where svrid = i_svrid  and procid = i_procid;
    delete param			where svrid = i_svrid  and procid = i_procid;
    delete rlvntdata		where svrid = i_svrid  and procid = i_procid;
    delete cond				where svrid = i_svrid  and procid = i_procid;
    delete event			where svrid = i_svrid  and procid = i_procid;
    delete actapp			where svrid = i_svrid  and procid = i_procid;
    delete actloop			where svrid = i_svrid  and procid = i_procid;
    delete procapp			where svrid = i_svrid  and procid = i_procid;
    delete trans			where svrid = i_svrid  and procid = i_procid;
    delete excpt			where svrid = i_svrid  and procid = i_procid;
    delete prtcp			where svrid = i_svrid  and procid = i_procid;
    delete attach			where svrid = i_svrid  and procid = i_procid;
    delete witemapp			where svrid = i_svrid  and procid = i_procid;
    delete appcheckout		where svrid = i_svrid  and procid = i_procid;
	delete cmnt				where svrid = i_svrid  and procid = i_procid;
	delete respgrp			where svrid = i_svrid  and procid = i_procid;
	delete resp			where svrid = i_svrid  and procid = i_procid;
	delete auditinfo		where svrid = i_svrid  and procid = i_procid and event <> 'X';
	delete witemti			where svrid = i_svrid  and procid = i_procid;
	delete cp				where svrid = i_svrid  and procid = i_procid;

	delete va_appmap		where svrid = i_svrid  and procid = i_procid;
	delete va_appvermap		where svrid = i_svrid  and procid = i_procid;
	delete va_verlink		where svrid = i_svrid  and procid = i_procid;
	delete Correspondence	where svrid = i_svrid  and procid = i_procid;
	delete procslink	where svrid = i_svrid  and procid = i_procid;

	-- bug19726 OfficeEngine support for Archive database
	SELECT Count(1) INTO i_cnt FROM CompleteTasks WHERE ProcID = i_procid;

	IF i_cnt > 0 Then
		SELECT TaskID INTO i_taskid FROM CompleteTasks WHERE ProcID = i_procid;

		DELETE FROM Tasks WHERE TaskID = i_taskid;
		DELETE FROM SubTasks WHERE TaskID = i_taskid;
		DELETE FROM Responses WHERE TaskID = i_taskid;
		DELETE FROM DTaskerAudit WHERE TaskID = i_taskid;
		DELETE FROM TaskAssociation WHERE TaskID = i_taskid;
		DELETE FROM taskprtcp WHERE TaskID = i_taskid;
		DELETE FROM taskapprovers WHERE TaskID = i_taskid;

		DELETE FROM CompleteTasks WHERE TaskID = i_taskid;
		DELETE FROM CompleteSubTasks WHERE TaskID = i_taskid;
		DELETE FROM CompleteResponses WHERE TaskID = i_taskid;
		DELETE FROM CompleteDTaskerAudit WHERE TaskID = i_taskid;
		DELETE FROM CompleteTaskAssociation WHERE TaskID = i_taskid;
		DELETE FROM completetaskprtcp WHERE TaskID = i_taskid;
		DELETE FROM completetaskapprovers WHERE TaskID = i_taskid;

	END IF;

	-- QuickProcess support for Archive database
	SELECT Count(1) INTO i_cnt FROM plantask WHERE procid = i_procid;
	IF i_cnt > 0 Then
		DELETE FROM plantask WHERE procid = i_procid;
		DELETE FROM plangoal WHERE procid = i_procid;
		DELETE FROM plantasklimitedassignee WHERE procid = i_procid;
		DELETE FROM planprtcp WHERE procid = i_procid;
		DELETE FROM planreminder WHERE procid = i_procid;
		DELETE FROM plantaskaux WHERE procid = i_procid;
		DELETE FROM plansubtask WHERE procid = i_procid;
		DELETE FROM plansubtaskaux WHERE procid = i_procid;
		DELETE FROM plansubtaskprtcp WHERE procid = i_procid;
	END IF;

exception
    when others then
        raise_application_error(-20711, sqlerrm);
end; -- procedure
/
