CREATE procedure sp_sync_parentmember
   is
--
-- 12.4.0.0
--
	l_cnt				integer;
	l_descorder			number;
	l_id				varchar2(10);
	l_parentid			varchar2(10);
	l_currentid			varchar2(10);
	l_parentname		varchar2(100);
	l_path				varchar2(500);
	l_inherittype		char(1);
	l_userflag			char(1);
	l_mngflag			char(1);
	l_membertype		char(1);
	parentiderror		exception;

cursor cur_get_id is
	select memberid from vusrgrp where type in ('D', 'H', 'G');

begin

	delete from parentmember;

	open cur_get_id;

	loop
		fetch cur_get_id into l_id;
		exit when cur_get_id%notfound;

		l_parentid := '0000000000';
		l_inherittype := '?';
		l_membertype := '?';
		l_path := '';
		l_userflag := 'T';
		l_mngflag  := 'T';

		select parentdeptid, inherittype, type, name into
			   l_parentid, l_inherittype, l_membertype, l_path
		  from vusrgrp
		 where memberid = l_id;

		dbms_output.put_line('Building parentmember for ' || l_id || ': type=' || l_membertype || ', parent=' || l_parentid || ', inherittype=' || l_inherittype || ', name=[' || l_path || ']');

		l_descorder := 1;
		l_path := '/' || l_path;
 		l_currentid := l_id;

		while (l_parentid <> '0000000000') loop
			if (l_userflag = 'T') then
				if (l_inherittype <>'B'
					and l_inherittype <>'U'
					and l_inherittype <>'P'
					and l_inherittype <>'Q') then
					l_userflag := 'F';
				end if;
			end if;
			if (l_mngflag = 'T') then
				if (l_inherittype <> 'B'
					and l_inherittype <> 'M'
					and l_inherittype <> 'Q') then
					l_mngflag := 'F';
				end if;
			end if;

			insert into parentmember (
					memberid, parentid, type,
					dirty, usrinherit, mnginherit, descorder)
			values (l_id, l_parentid, l_membertype,
					'F', l_userflag, l_mngflag, l_descorder);

			select count(1) into l_cnt from vusrgrp where memberid = l_parentid;
			if (l_cnt > 0) then
				dbms_output.put_line('Building parentmember for ' || l_id || ': parent=' || l_parentid || ' of ' || l_currentid || ' is OK.');

				l_currentid := l_parentid;
				select parentdeptid, inherittype, name into
					   l_parentid, l_inherittype, l_parentname
				  from vusrgrp
				 where memberid = l_parentid;
			else
				dbms_output.put_line('Building parentmember for ' || l_id || ': parent=' || l_parentid || ' of ' || l_currentid || ' does not exist.');
				exit;
			end if;

			l_descorder := l_descorder + 1;

			if (l_descorder > 50) then
				close cur_get_id;
				raise parentiderror;
			end if;

			l_path := '/' || l_parentname || l_path;
		end loop;

		insert into parentmember(
				memberid, parentid, type, dirty,
				usrinherit, mnginherit, descorder, memberpath)
		values (l_id, l_id, l_membertype, 'F',
				'T', 'T', 0, l_path);
	end loop;

	close cur_get_id;

exception
    when parentiderror then
        raise_application_error(-20538, 'Invalid parent memberid.');
    when others then
		if cur_get_id%isopen then
		    close cur_get_id;
		end if;
        raise_application_error(-20745, sqlerrm);
end;
/
