CREATE procedure          sp_set_adhoc_cmpltusr
(
	i_svrid        in  varchar,
	i_procid       in  number,
	i_actseq       in  number,
	i_rbackopt     in  varchar,
	i_cmpltusr     in  varchar
)   is
--
-- 12.4.0.0
--

l_CONST_last_adhoc_disporder	number;
l_max_disporder					number;
l_min_disporder					number;

begin

	select max(disporder) into l_CONST_last_adhoc_disporder from prtcp
				where svrid = i_svrid
					and procid = i_procid
					and actseq = i_actseq
					and kind = 'P';

	select min(disporder) into l_min_disporder from prtcp
				where svrid = i_svrid
					and procid = i_procid
					and actseq = i_actseq
					and kind = 'P';

	select max(disporder) into l_max_disporder from prtcp
				where svrid = i_svrid
					and procid = i_procid
					and actseq = i_actseq
					and kind = 'P'
					and useflag = 'T';

	update prtcp set type = 'U', prtcp = i_cmpltusr
				where svrid = i_svrid
					and procid = i_procid
					and actseq = i_actseq
					and kind = 'P'
					and useflag = 'T'
					and type <> 'U'
					and disporder = l_max_disporder
					and disporder <> l_min_disporder;

	if i_rbackopt in ('D', 'B') then
		update prtcp set type = 'U', prtcp = i_cmpltusr
					where svrid = i_svrid
						and procid = i_procid
						and actseq = i_actseq
						and kind = 'P'
						and disporder = l_CONST_last_adhoc_disporder - l_max_disporder
						and disporder > l_max_disporder;
	end if;

exception
    when others then
        raise_application_error(-20733, sqlerrm);
end;
/
