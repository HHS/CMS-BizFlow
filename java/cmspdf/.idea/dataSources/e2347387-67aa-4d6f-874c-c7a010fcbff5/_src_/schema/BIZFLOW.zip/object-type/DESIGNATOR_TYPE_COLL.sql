CREATE TYPE designator_type_coll AS TABLE OF designator_type;
/
