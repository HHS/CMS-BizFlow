CREATE FUNCTION fn_gettaskassignedpath
(
	i_taskid IN NUMBER,
	i_subtaskid IN NUMBER
)
/* Return value is JSON type*/
RETURN varchar2
IS
	l_path varchar2(2048);
	cursor curTaskPath(i_taskid in number, i_subtaskid IN NUMBER) is
		SELECT * FROM subtasks
		start with taskid=i_taskid and subtaskid=i_subtaskid
		connect by prior parenttaskid = subtaskid and taskid=i_taskid
                order by parenttaskid;

	rSubTask curTaskPath%ROWTYPE;

-- 12.4.0.0
BEGIN
	l_path := '';
	open curTaskPath(i_taskid, i_subtaskid);
	loop
		fetch curTaskPath into rSubTask;
		exit when curTaskPath%NOTFOUND;
		l_path := l_path || ',{id:"' || rSubTask.taskinitiator || '",type:"' || rSubTask.taskinitiatortype || '",name:"' || rSubTask.taskinitiatorname || '"}';
	end loop;

	l_path := l_path || ',{id:"'|| rSubTask.assignee|| '",type:"' || rSubTask.assigneetype ||'",name:"' || rSubTask.assigneename || '"}';

	close curTaskPath;

	if 2 < length(l_path) then
		return '['||Substr(l_path, 2)||']';
	end if;
	return '[]';
END;
/
