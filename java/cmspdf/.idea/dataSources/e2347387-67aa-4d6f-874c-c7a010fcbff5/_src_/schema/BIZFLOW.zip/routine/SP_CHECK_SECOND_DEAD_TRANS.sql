CREATE procedure sp_check_second_dead_trans
   (
     i_svrid   varchar2,
     i_procid  number,
     i_actseq  number,
     o_value   out number)
   is
--
-- 12.4.0.0
--
	l_count	number(10);
begin

	select count(*) into l_count
	from trans t, act a, act fa
	where t.svrid = i_svrid
	and t.procid = i_procid
	and t.tonode = i_actseq
	and t.state = 'C'
	and a.svrid = t.svrid
	and a.procid = t.procid
	and a.actseq = t.tonode
	and a.state not in ('N')
	and a.cmpltdtime < t.modifydtime
	and fa.svrid = t.svrid
	and fa.procid = t.procid
	and fa.actseq = t.fromnode
	and fa.state not in ('N')
	and a.cmpltdtime < fa.cmpltdtime;

	if (l_count > 0) then
		-- This is the second time that this activity was hit by an incoming dead transition. Do not activate this activity by this incoming dead transition.
		o_value := 1;
	else
		o_value := 0;
	end if;
end;
/
