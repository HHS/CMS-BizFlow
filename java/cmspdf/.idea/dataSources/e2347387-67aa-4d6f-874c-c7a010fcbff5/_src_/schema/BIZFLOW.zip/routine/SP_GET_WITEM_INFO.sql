CREATE procedure sp_get_witem_info
   ( i_svrid  			in varchar2,
     i_prtcp 			in varchar2,
	 i_condcnt			in number,
	 i_rlvntdataname1 	in varchar2,
	 i_value1 			in nvarchar2,
	 i_rlvntdataname2 	in varchar2,
	 i_value2 			in nvarchar2,
	 i_rlvntdataname3 	in varchar2,
	 i_value3 			in nvarchar2,
	 i_rlvntdataname4 	in varchar2,
	 i_value4 			in nvarchar2,
	 i_rlvntdataname5 	in varchar2,
	 i_value5 			in nvarchar2,
	 i_rlvntdataname6 	in varchar2,
	 i_value6 			in nvarchar2,
	 i_rlvntdataname7 	in varchar2,
	 i_value7 			in nvarchar2,
	 i_rlvntdataname8 	in varchar2,
	 i_value8 			in nvarchar2,
	 i_rlvntdataname9 	in varchar2,
	 i_value9 			in nvarchar2,
	 i_rlvntdataname10 	in varchar2,
	 i_value10 			in nvarchar2,
	 o_procid			out number)
   is
--
-- 12.4.0.0
--
cursor cur_get_myrlvntdata (
	 l_prtcp varchar2,
	 l_rlvntdataname1 	varchar2,
	 l_value1 			nvarchar2,
	 l_rlvntdataname2 	varchar2,
	 l_value2 			nvarchar2,
	 l_rlvntdataname3 	varchar2,
	 l_value3 			nvarchar2,
	 l_rlvntdataname4 	varchar2,
	 l_value4 			nvarchar2,
	 l_rlvntdataname5 	varchar2,
	 l_value5 			nvarchar2,
	 l_rlvntdataname6 	varchar2,
	 l_value6 			nvarchar2,
	 l_rlvntdataname7 	varchar2,
	 l_value7 			nvarchar2,
	 l_rlvntdataname8 	varchar2,
	 l_value8 			nvarchar2,
	 l_rlvntdataname9 	varchar2,
	 l_value9 			nvarchar2,
	 l_rlvntdataname10 	varchar2,
	 l_value10 			nvarchar2,
	 l_condcnt			number
) is
select rt.procid
		from (select svrid, procid, count(*) cnt from vmyrlvntdata where
				prtcp = l_prtcp
				 and ((rlvntdataname = l_rlvntdataname1
				 	and value = l_value1)
				 or (rlvntdataname = l_rlvntdataname2
				 	and value = l_value2)
				 or (rlvntdataname = l_rlvntdataname3
				 	and value = l_value3)
				 or (rlvntdataname = l_rlvntdataname4
				 	and value = l_value4)
				 or (rlvntdataname = l_rlvntdataname5
				 	and value = l_value5)
				 or (rlvntdataname = l_rlvntdataname6
				 	and value = l_value6)
				 or (rlvntdataname = l_rlvntdataname7
				 	and value = l_value7)
				 or (rlvntdataname = l_rlvntdataname8
				 	and value = l_value8)
				 or (rlvntdataname = l_rlvntdataname9
				 	and value = l_value9)
				 or (rlvntdataname = l_rlvntdataname10
				 	and value = l_value10))
		group by svrid, procid) rt
	where rt.cnt = l_condcnt;

l_procid		number(10);

begin

	o_procid := 0;
	open cur_get_myrlvntdata(i_prtcp, i_rlvntdataname1, i_value1, i_rlvntdataname2, i_value2,
							i_rlvntdataname3, i_value3, i_rlvntdataname4, i_value4,
							i_rlvntdataname5, i_value5, i_rlvntdataname6, i_value6,
							i_rlvntdataname7, i_value7, i_rlvntdataname8, i_value8,
							i_rlvntdataname9, i_value9, i_rlvntdataname10, i_value10,
							i_condcnt);
	loop
		fetch cur_get_myrlvntdata into l_procid;
		exit when cur_get_myrlvntdata%notfound;

		o_procid := l_procid;
		exit;
	end loop;
	close cur_get_myrlvntdata;

exception
    when others then
        if cur_get_myrlvntdata%isopen then
            close cur_get_myrlvntdata;
        end if;
		raise_application_error(-20725, sqlerrm);
end; -- procedure
/
