CREATE procedure          sp_check_parentfldrlist
   ( i_fldrid in number)
   is
--
-- 12.4.0.0
--
    l_inherittype       char;
    l_parentfldrid      integer;
    l_fldr_cnt          integer;
    l_dirty_cnt         integer;
    userflag            char;
    mngflag             char;
    l_call_depth	   integer;
    l_parentfldrname		varchar(100);
    l_fldrpath			varchar(500);
	fldriderror        exception;
begin

		select count(*) into l_fldr_cnt from fldrlist
		where fldrid = i_fldrid;
		if (l_fldr_cnt = 0) then
			return;
		end if;

-- begin CS-7129 -- deleted by mhjeong on 2005/05/07 (code merged by kkkim on 2005/10/27 KST)
--		select count(*) into l_dirty_cnt from parentfldr
--        where fldrid = i_fldrid
--          and dirty = 'T';

--        if (l_dirty_cnt > 0) then
--            delete from parentfldr where fldrid = i_fldrid;
--        end if;
-- end CS-7129 -- deleted by mhjeong on 2005/05/07 (code merged by kkkim on 2005/10/27 KST)

        select count(*) into l_fldr_cnt from parentfldr
        where fldrid = i_fldrid;

        if l_fldr_cnt = 0 then
           userflag := 'T';
           mngflag := 'T';
           insert into parentfldr(parentfldrid, fldrid, dirty, usrinherit, mnginherit)
           values (i_fldrid, i_fldrid, 'F', userflag, mngflag);

           select parentfldrid, inherittype, name
             into l_parentfldrid, l_inherittype, l_fldrpath
             from fldrlist
            where fldrid = i_fldrid;

			l_fldrpath := '/' || l_fldrpath;
   			l_call_depth := 0;
            while (l_parentfldrid <> 0) loop
                if (userflag = 'T') then
                   if (l_inherittype <> 'B' and l_inherittype <> 'U') then
                      userflag := 'F';
                   end if;
                end if;
                if (mngflag = 'T') then
                    if (l_inherittype <> 'B' and l_inherittype <> 'M') then
                        mngflag := 'F';
                    end if;
                end if;

                insert into parentfldr (parentfldrid, fldrid, dirty, usrinherit, mnginherit)
                values (l_parentfldrid, i_fldrid, 'F', userflag, mngflag);

                select parentfldrid, inherittype, name
                  into l_parentfldrid, l_inherittype, l_parentfldrname
                  from fldrlist
                 where fldrid = l_parentfldrid;
                 l_call_depth := l_call_depth + 1;
                 if l_call_depth > 50 then
					raise fldriderror;
                 end if;

		 l_fldrpath := '/' || l_parentfldrname || l_fldrpath;
            end loop;

	    update fldrlist set fldrpath = l_fldrpath where fldrid = i_fldrid;
        end if;

exception
    when fldriderror then
        raise_application_error(-20501, 'Invalid parent fldrid.');
    when others then
        raise_application_error(-20700, sqlerrm);
end;
/
