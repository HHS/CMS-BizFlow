CREATE TRIGGER BIZFLOW.DRLVNTDATAVAL_BIUR
BEFORE INSERT OR UPDATE OF VALUETYPE, VALUE
  ON BIZFLOW.DRLVNTDATAVAL
FOR EACH ROW WHEN (FOR EACH ROW )
DECLARE
    l_dispname        varchar2(100);

-- 12.4.0.0
BEGIN
    IF :new.valuetype = 'A' THEN
		IF :new.value is not null THEN
			SELECT name INTO l_dispname
			  FROM apptmplt
			 WHERE svrid = SUBSTR(:new.value, 1, 10)
			   AND envtype = 'O'
				AND isfinal = 'T'
				AND orgappid = to_number(SUBSTR(:new.value, 12, 10));
		ELSE
			l_dispname := null;
		END IF;
        :new.dispvalue := l_dispname;
    ELSIF  :new.valuetype = 'P' THEN
		IF :new.value is not null THEN
			SELECT name INTO l_dispname
			  FROM member
			 WHERE memberid = SUBSTR(:new.value, 4, 10);
		ELSE
			l_dispname := null;
		END IF;
        :new.dispvalue := l_dispname;
    END IF;

EXCEPTION
   WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20933, SQLERRM);
END;
/
