CREATE TRIGGER BIZFLOW.FLDRLIST_BDR
BEFORE DELETE
  ON BIZFLOW.FLDRLIST
FOR EACH ROW
  DECLARE
cnt integer;
cannotdelete    EXCEPTION;

-- 12.4.0.0
BEGIN

   SELECT count(1) INTO cnt FROM grlvntdata
   WHERE fldrid = :old.fldrid;
   IF (cnt > 0) THEN
      RAISE cannotdelete;
   END IF;

   IF (:old.prjid = 0) THEN
    UPDATE procdef SET fldrid = 0 WHERE svrid = :old.svrid and fldrid = :old.fldrid and envtype = 'P';
   END IF;

   SELECT count(1) INTO cnt FROM procdef
   WHERE fldrsvrid = :old.svrid AND (fldrid = :old.fldrid OR instfldrid = :old.fldrid OR archivefldrid = :old.fldrid);
   IF (cnt > 0) THEN
      RAISE cannotdelete;
   END IF;

   SELECT count(1) INTO cnt FROM procs
   WHERE svrid = :old.svrid AND ((instfldrid = :old.fldrid AND state in ('R', 'E', 'V', 'S', 'D','J'))
         OR archivefldrid = :old.fldrid);
   IF (cnt > 0) THEN
      RAISE cannotdelete;
   END IF;

   IF (:old.prjid = 0) THEN
    UPDATE apptmplt SET fldrid = 0 WHERE svrid = :old.svrid and fldrid = :old.fldrid and envtype = 'P';
   END IF;

   SELECT count(1) INTO cnt FROM apptmplt
   WHERE isfinal = 'T' AND fldrsvrid = :old.svrid AND fldrid = :old.fldrid;
   IF (cnt > 0) THEN
      RAISE cannotdelete;
   END IF;

   DELETE FROM fldrmemberlist
   WHERE svrid = :old.svrid AND fldrid = :old.fldrid;

	-- bug19518
	delete from fldrmanagerlist
	where svrid = :old.svrid and fldrid = :old.fldrid;

   -- bug19059
   delete from parentfldr
    where fldrid = :old.fldrid;

EXCEPTION
   WHEN cannotdelete THEN
        RAISE_APPLICATION_ERROR(-20802, 'This Folder has Children' || :old.fldrid);
   WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20901, SQLERRM);
END;
/
