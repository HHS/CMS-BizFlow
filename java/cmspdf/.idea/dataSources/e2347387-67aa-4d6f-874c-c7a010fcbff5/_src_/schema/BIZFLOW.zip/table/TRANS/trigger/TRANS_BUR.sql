CREATE TRIGGER BIZFLOW.TRANS_BUR
BEFORE UPDATE OF STATE
  ON BIZFLOW.TRANS
FOR EACH ROW
  BEGIN
    IF :new.state = 'C' or :new.state = 'D' THEN
		:new.modifydtime := getutcdate();
    END IF;
END;
/
