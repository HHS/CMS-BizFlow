CREATE function fn_check_running_procs_in_tree
   (i_procid IN number)
  RETURN int IS
    l_rootid number;
    l_count int;
    l_returnVal number;
-- 12.4.0.0
BEGIN
    -- Find root node
    select procid into l_rootid
    from procs
    where parentprocid = 0
    connect by nocycle prior parentprocid = procid
    start with procid = i_procid;

	-- Was root node already moved? then use input process ID as search root.
    if (l_rootid is null) then
        l_rootid := i_procid;
    end if;

    -- Find all running instances from tree
    select count(1) into l_count
    from (
        select procid, parentprocid, state, 0
        from procs
        where procid = i_procid
        union all
        select procid, parentprocid, state, level
        from procs
        connect by nocycle prior procid = parentprocid
        start with parentprocid = i_procid
    ) a
    where a.state in ('N', 'R', 'E', 'V', 'S', 'D', 'J');

    if (l_count = 0) then
        l_returnVal :=  i_procid;
    else
        l_returnVal :=  0;
    end if;

    RETURN l_returnVal;
END;
/
