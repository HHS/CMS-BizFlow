CREATE FUNCTION fn_get_busdaysdiff(i_fromdate IN date, i_todate IN date)
  return int IS
  nDays int;
  BEGIN
    select count(1) into nDays
    from cal c inner join calhead ch on ch.dayofweek = c.dayofweek
    where ch.daytype <> 'H'
          and c.caldtime not in (select caldtime from membercal where daytype = 'H' and memberid = '0000000000') -- and memberid = calendarID)
          and c.caldtime > i_fromdate
          and c.caldtime <= i_todate
          and ch.memberid = '0000000000';

    return nDays;
  END;
/
