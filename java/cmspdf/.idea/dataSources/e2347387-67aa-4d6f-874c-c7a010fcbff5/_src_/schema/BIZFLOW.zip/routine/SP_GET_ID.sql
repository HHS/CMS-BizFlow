CREATE procedure sp_get_id
   ( i_svrid  in  varchar2,
     i_keystr in  varchar2,
     i_increment in number,
     o_value  out number)
   is
--
-- 12.4.0.0
--
    init_value number(10);
begin
    update id
       set value = nvl(value,0) + i_increment
     where svrid = i_svrid
       and keystr = i_keystr;
    if sql%rowcount = 0 then
        init_value := i_increment + 100;
        begin
            insert into id (svrid, keystr, value) values (i_svrid, i_keystr, init_value);
            exception
            when others then
            begin
                update id
                   set value = nvl(value, 0) + i_increment
                 where svrid = i_svrid
                   and keystr = i_keystr;
            end;
        end;
    end if;
    select value - i_increment + 1
      into o_value
      from id
     where svrid = i_svrid
       and keystr = i_keystr;
exception
    when others then
        raise_application_error(-20714, sqlerrm);
end;
/
