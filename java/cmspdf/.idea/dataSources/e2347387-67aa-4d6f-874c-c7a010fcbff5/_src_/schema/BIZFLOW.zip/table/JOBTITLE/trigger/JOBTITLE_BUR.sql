CREATE TRIGGER BIZFLOW.JOBTITLE_BUR
BEFORE UPDATE OF NAME
  ON BIZFLOW.JOBTITLE
FOR EACH ROW
  BEGIN

    UPDATE member
       SET jobtitlename = :new.name
     WHERE jobtitleid = :new.jobtitleid;

    UPDATE memberinfo
       SET namea = :new.name
     WHERE ida = :new.jobtitleid;

    UPDATE memberinfo
       SET nameb = :new.name
     WHERE idb = :new.jobtitleid;

EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20916, SQLERRM);
END;
/
