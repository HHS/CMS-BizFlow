CREATE TRIGGER BIZFLOW.MEMBER_BUR
BEFORE UPDATE OF STATE, LICTYPE, INHERITTYPE, NAME, LOGINID, DEPTID, PARENTDEPTID, EMAIL, MANAGERID, PASSWD
  ON BIZFLOW.MEMBER
FOR EACH ROW WHEN (FOR EACH ROW )
DECLARE
	l_updated			number;
	l_transactionid		varchar2(50);
	cnt					integer;
	invalidjobtitle		EXCEPTION;

	l_type			char(1);
	l_objid			varchar2(20);
	l_objtype		varchar2(50);
	l_objtypestr	varchar2(50);
	l_ipaddr		varchar2(50);
	l_actor			varchar2(10);
	l_actorname		varchar2(100);
	l_objname		varchar2(100);
	l_event			varchar2(100);
	l_new			varchar2(100);
	l_old			varchar2(100);
	l_newdetail		varchar2(500);
	l_olddetail		varchar2(500);
	l_newdeptid		varchar2(10);
	l_olddeptid		varchar2(10);
	l_newdept		varchar2(500);
	l_olddept		varchar2(500);
	l_newparentid	varchar2(10);
	l_oldparentid	varchar2(10);
	l_newparent		varchar2(500);
	l_oldparent		varchar2(500);
	l_detail		varchar2(2048);
	l_nodatafound	boolean;
	l_auditinfoadm_seq number := -2;

-- 12.4.0.0
BEGIN

	IF :new.type = 'U' THEN
		SELECT count(1) INTO cnt
		  FROM jobtitle
		 WHERE jobtitleid = :new.jobtitleid;

		IF cnt = 0 THEN
		    RAISE invalidjobtitle;
		END IF;
	END IF;

	l_type := :new.type;
	l_objid := :new.memberid;
	l_objname := :new.name;

	if (:old.name <> :new.name
		or :old.parentdeptid <> :new.parentdeptid
		or :old.deptid <> :new.deptid
		or :old.inherittype <> :new.inherittype
		or :old.state <> :new.state
		or :old.lictype <> :new.lictype
		or :old.loginid <> :new.loginid
		or :old.passwd <> :new.passwd
		or :old.managerid <> :new.managerid
		or :old.email <> :new.email)
	then
		l_event := 'MODIFIED';
		l_detail := '            <MEMBERID>' || l_objid || '</MEMBERID>' || chr(13) || chr(10);
	else
		return;
	end if;

	if :new.type <> 'H' then
		l_actor := '0000000000';
		l_actorname := 'System';
	else
		l_actor := '';
	end if;

	if (l_type = 'U') then
		begin
			select o.memberid, o.membername, u.ipaddr
			  into l_actor, l_actorname, l_ipaddr
			  from parentmember p, checkout o, usrsession u
			 where p.memberid = :new.deptid
			   and o.nodeid = p.parentid
			   and o.type = 'O'
			   and u.memberid = o.memberid;
		exception when NO_DATA_FOUND then
			null;
		end;

		l_objtype := 'USER';
		l_objtypestr := 'User';

	elsif (l_type = 'D')then
		begin
			select o.memberid, o.membername, u.ipaddr
			  into l_actor, l_actorname, l_ipaddr
			  from parentmember p, checkout o, usrsession u
			 where p.memberid = :new.memberid
			   and o.nodeid = p.parentid
			   and o.type = 'O'
			   and u.memberid = o.memberid;
		exception when NO_DATA_FOUND then
			null;
		end;
		l_objtype := 'ORGANIZATIONALUNIT';
		l_objtypestr := 'OrganizationalUnit';

	elsif (l_type = 'G') then
		begin
			select o.memberid, o.membername, u.ipaddr
			  into l_actor, l_actorname, l_ipaddr
			  from parentmember p, checkout o, usrsession u
			 where p.memberid = :new.memberid
			   and o.nodeid = p.parentid
			   and o.type = 'G'
			   and u.memberid = o.memberid;
		exception when NO_DATA_FOUND then
			null;
		end;

		l_objtype := 'USERGROUP';
		l_objtypestr := 'UserGroup';

	elsif (l_type = 'H') then
		begin
			select o.memberid, o.membername, u.ipaddr
			  into l_actor, l_actorname, l_ipaddr
			  from checkout o, usrsession u
			 where o.nodeid = :new.memberid
			   and o.type = 'H'
			   and u.memberid = o.memberid;
		exception when NO_DATA_FOUND then
			null;
		end;
		l_objtype := 'USERGROUPHIERARCHY';
		l_objtypestr := 'UserGroupHierarchy';
	end if;

	if (:old.name <> :new.name) then
	    UPDATE fldrmemberlist
	       SET name = :new.name
	     WHERE memberid = :new.memberid;

	    -- cs10112
		UPDATE fldrmanagerlist
	       SET name = :new.name
	     WHERE managerid = :new.memberid;

		if (l_type = 'D' or l_type = 'G' or l_type = 'H' or l_type = 'U') then
			l_detail := l_detail || '            <NAME>' || chr(13) || chr(10);
			l_detail := l_detail || '                <xdf:insert>' || :new.name || '</xdf:insert>' || chr(13) || chr(10);
			l_detail := l_detail || '                <xdf:delete>' || :old.name || '</xdf:delete>' || chr(13) || chr(10);
			l_detail := l_detail || '            </NAME>' || chr(13) || chr(10);
		end if;
	else
		l_detail := l_detail || '            <NAME>' || :new.name || '</NAME>' || chr(13) || chr(10);
	end if;

	if (:old.parentdeptid <> :new.parentdeptid and (l_type = 'D' or l_type = 'G')) then
		l_oldparentid := :old.parentdeptid;
		select p.memberpath into l_oldparent
		  from parentmember p
		 where p.memberid = :old.parentdeptid
		   and p.parentid = p.memberid;
	end if;

	if (:old.deptid <> :new.deptid and l_type = 'U') then
		l_olddeptid := :old.deptid		;
		select p.memberpath into l_olddept
		  from parentmember p
		 where p.memberid = :old.deptid
		   and p.parentid = p.memberid;
	end if;

	if ((l_type = 'D' or l_type = 'G') and :old.parentdeptid <> '0000000000') then
		if (:old.parentdeptid <> :new.parentdeptid) then
			-- String '_NEW_PATH_' will be replaced after trigger.
			l_detail := l_detail || '            <PARENTDEPTID>' || chr(13) || chr(10);
			l_detail := l_detail || '                <xdf:insert>' || l_newparentid || ' [_NEW_PATH_]</xdf:insert>' || chr(13) || chr(10);
			l_detail := l_detail || '                <xdf:delete>' || l_oldparentid || ' [' || l_oldparent || ']</xdf:delete>' || chr(13) || chr(10);
			l_detail := l_detail || '            </PARENTDEPTID>' || chr(13) || chr(10);
		else
			l_new := :new.parentdeptid;
			select p.memberpath into l_newdetail
			  from parentmember p
			 where p.memberid = :new.parentdeptid
			   and p.parentid = p.memberid;
			l_detail := l_detail || '            <PARENTDEPTID>' || l_new || ' [' || l_newdetail || ']</PARENTDEPTID>' || chr(13) || chr(10);
		end if;

	elsif (l_type = 'U') then
		if (:old.deptid <> :new.deptid)	then
			l_newdeptid := :new.deptid;
			select p.memberpath into l_newdept
			  from parentmember p
			 where p.memberid = :new.deptid
			   and p.parentid = p.memberid;
			l_detail := l_detail || '            <DEPTID>' || chr(13) || chr(10);
			l_detail := l_detail || '                <xdf:insert>' || l_newdeptid || ' [' || l_newdept || ']</xdf:insert>' || chr(13) || chr(10);
			l_detail := l_detail || '                <xdf:delete>' || l_olddeptid || ' [' || l_olddept || ']</xdf:delete>' || chr(13) || chr(10);
			l_detail := l_detail || '            </DEPTID>' || chr(13) || chr(10);
		else
			l_new := :new.deptid;
			select p.memberpath into l_newdetail
			  from parentmember p
			 where p.memberid = :new.deptid
			   and p.parentid = p.memberid;
			l_detail := l_detail || '            <DEPTID>' || l_new || ' [' || l_newdetail || ']</DEPTID>' || chr(13) || chr(10);
		end if;

		if (:old.loginid <> :new.loginid) then
			l_detail := l_detail || '            <LOGINID>' || chr(13) || chr(10);
			l_detail := l_detail || '                <xdf:insert>' || :new.loginid || '</xdf:insert>' || chr(13) || chr(10);
			l_detail := l_detail || '                <xdf:delete>' || :old.loginid || '</xdf:delete>' || chr(13) || chr(10);
			l_detail := l_detail || '            </LOGINID>' || chr(13) || chr(10);
		end if;

		if (:old.email <> :new.email) then
			l_detail := l_detail || '            <EMAIL>' || chr(13) || chr(10);
			l_detail := l_detail || '                <xdf:insert>' || :new.email || '</xdf:insert>' || chr(13) || chr(10);
			l_detail := l_detail || '                <xdf:delete>' || :old.email || '</xdf:delete>' || chr(13) || chr(10);
			l_detail := l_detail || '            </EMAIL>' || chr(13) || chr(10);
		end if;
	end if; -- deptid updated

	if (:old.inherittype <> :new.inherittype) then
		l_detail := l_detail || '            <INHERITTYPE>' || chr(13) || chr(10);
		l_detail := l_detail || '                <xdf:insert>' || :new.inherittype || '</xdf:insert>' || chr(13) || chr(10);
		l_detail := l_detail || '                <xdf:delete>' || :old.inherittype || '</xdf:delete>' || chr(13) || chr(10);
		l_detail := l_detail || '            </INHERITTYPE>' || chr(13) || chr(10);
	end if;

	if (:old.state <> :new.state) then
		l_detail := l_detail || '            <STATE>' || chr(13) || chr(10);
		l_detail := l_detail || '                <xdf:insert>' || :new.state || '</xdf:insert>' || chr(13) || chr(10);
		l_detail := l_detail || '                <xdf:delete>' || :old.state || '</xdf:delete>' || chr(13) || chr(10);
		l_detail := l_detail || '            </STATE>' || chr(13) || chr(10);
	end if;

	if (:old.lictype <> :new.lictype) then
		l_detail := l_detail || '            <LICTYPE>' || chr(13) || chr(10);
		l_detail := l_detail || '                <xdf:insert>' || :new.lictype || '</xdf:insert>' || chr(13) || chr(10);
		l_detail := l_detail || '                <xdf:delete>' || :old.lictype || '</xdf:delete>' || chr(13) || chr(10);
		l_detail := l_detail || '            </LICTYPE>' || chr(13) || chr(10);
	end if;

	if (:old.managerid <> :new.managerid) then
		l_detail := l_detail || '            <MANAGERID>' || chr(13) || chr(10);
		l_detail := l_detail || '                <xdf:insert>' || :new.managerid || ' [_NEW_MNGR_]</xdf:insert>' || chr(13) || chr(10);
		l_detail := l_detail || '                <xdf:delete>' || :old.managerid || ' [_OLD_MNGR_]</xdf:delete>' || chr(13) || chr(10);
		l_detail := l_detail || '            </MANAGERID>' || chr(13) || chr(10);
	end if;

	if (:old.passwd <> :new.passwd) then
		if (fn_get_configuration_valuen('PASSWORD','MAX_DAY_OF_PASSWORD_IN_HISTORY',0) = 0 and
			fn_get_configuration_valuen('PASSWORD','MAX_NUMBER_OF_PASSWORDS_IN_HISTORY',0) = 0) then
			delete from password where memberid = :new.memberid;
		else
			insert into password (memberid, seq, passwd, lastuseddtime)
			values (:new.memberid, hws_password.nextval, :old.passwd, getutcdate());
		end if;

		l_detail := l_detail || '            <PASSWD>Updated</PASSWD>' || chr(13) || chr(10);
	end if;

	if (l_actor is not null and l_detail is not null) then
		select hws_adminaudit.nextval into l_auditinfoadm_seq from dual;

		insert into auditinfoadm (seq, actor, actorname, dtime, event, objid, objtype, objname, ipaddr, detail)
		values (l_auditinfoadm_seq, l_actor, l_actorname, getutcdate(), l_event, l_objid, l_objtype, l_objname, l_ipaddr,
				'<?xml version="1.0" encoding="UTF-8"?>' || chr(13) || chr(10) ||
				'<ADMINAUDIT xmlns:del="http://www.handysoft.com/bizflow/XDiff/Delete" xmlns:xdf="http://www.handysoft.com/bizflow/XDiff">' || chr(13) || chr(10) ||
				'    <MEMBER>' || chr(13) || chr(10) ||
				'        <' || l_objtypestr || '>' || chr(13) || chr(10) ||
				l_detail ||
				'        </' || l_objtypestr || '>' || chr(13) || chr(10) ||
				'    </MEMBER>' || chr(13) || chr(10) ||
				'</ADMINAUDIT>');
	else
		l_auditinfoadm_seq := -1;
	end if;

	-- bug19059: start
	-- Pass key to member_aur
	l_updated := 0;

	if (:new.type in ('D', 'H', 'G')) then
		-- If moved
		-- bug20286: start
		--if (:new.parentdeptid <> :old.parentdeptid) then
		if (:old.parentdeptid is null and :new.parentdeptid is not null ) or
			(:new.parentdeptid <> :old.parentdeptid) then
		-- bug20286: end
			l_updated := l_updated + 1;
		end if;

		if ( :new.inherittype <> :old.inherittype ) then
			l_updated := l_updated + 2;
		end if;

		if ( :new.name <> :old.name ) then
			l_updated := l_updated + 4;
		end if;
	end if;

	select DBMS_TRANSACTION.LOCAL_TRANSACTION_ID into l_transactionid from dual;

	insert into hwtemp (tmpkey, vara, varb, varc, vard, vare)
	values (l_transactionid, :new.memberid, l_updated,l_auditinfoadm_seq, :old.managerid, :new.managerid);
		--dbms_output.put_line('member_bur updated = ' || l_transactionid || ', ' || :new.memberid || ', ' || l_updated);
	-- bug19059: end

EXCEPTION
    WHEN invalidjobtitle THEN
        RAISE_APPLICATION_ERROR(-20807, 'Invalid JobTitleID ' || :new.JobTitleID);
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20904, SQLERRM);
END;
/
