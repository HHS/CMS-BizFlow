CREATE TRIGGER BIZFLOW.WITEM_BUR
BEFORE UPDATE OF STATE, URGENT, CHECKOUTUSR
  ON BIZFLOW.WITEM
FOR EACH ROW
  BEGIN
    IF :old.state <> 'C'
        AND :new.state = 'C' THEN

        UPDATE witemapp
           SET prtcpname = (SELECT name FROM member WHERE memberid = witemapp.prtcp)
         WHERE svrid  = :new.svrid
           AND procid = :new.procid
           AND witemseq = :new.witemseq
           AND state = 'C';

        UPDATE witemapp
           SET state = 'C', prtcp = :new.cmpltusr, prtcpname = :new.cmpltusrname
         WHERE svrid  = :new.svrid
           AND procid = :new.procid
           AND witemseq = :new.witemseq
           AND state <> 'C';

   ELSIF :old.state <> 'I'
        AND :new.state = 'I' THEN

		-- In the case of rejection, WitemApp should be changed to 'Normal' status at the same time.
        UPDATE witemapp
           SET prtcp = null, prtcpname = null, state = 'N'
         WHERE svrid  = :new.svrid
           AND procid = :new.procid
           AND witemseq = :new.witemseq;

    END IF;

    IF (:old.state <> :new.state OR
        :old.urgent <> :new.urgent) THEN
        IF (:old.state = 'Y' AND :new.state <> 'Y') THEN
            UPDATE witemcnt c SET cnt = cnt + 1
             WHERE c.memberid = :new.prtcp
               AND c.state = :new.state
               AND c.urgent = :new.urgent;
        ELSIF (:old.state <> 'Y' AND :new.state = 'Y') THEN
            UPDATE witemcnt c SET cnt = cnt - 1
             WHERE c.memberid = :old.prtcp
               AND c.state = :old.state
               AND c.urgent = :old.urgent
                AND c.cnt > 0;
        ELSE
            UPDATE witemcnt c SET cnt = cnt - 1
                WHERE c.memberid = :old.prtcp
                    AND c.state = :old.state
                    AND c.urgent = :old.urgent
                    AND c.cnt > 0;

            UPDATE witemcnt c SET cnt = cnt + 1
                WHERE c.memberid = :new.prtcp
                    AND c.state = :new.state
                    AND c.urgent = :new.urgent;
        END IF;
    END IF;

    IF :old.state <> :new.state THEN
		IF :new.state = 'C' THEN -- complete
			update cmnt
			   set type = 'COMPLETE'
			 where svrid = :new.svrid
			   and procid = :new.procid
			   and witemseq = :new.witemseq
			   and type = 'DRAFTC';
		ELSIF :new.state = 'W' THEN -- forward
			update cmnt
			   set type = 'FORWARD'
			 where svrid = :new.svrid
			   and procid = :new.procid
			   and witemseq = :new.witemseq
			   and type = 'DRAFTF';
		ELSIF :new.state = 'J' THEN -- reject or reply
			update cmnt
			   set type = 'REPLY'
			 where svrid = :new.svrid
			   and procid = :new.procid
			   and witemseq = :new.witemseq
			   and type = 'DRAFTR';
		END IF;
    END IF;

    IF :new.checkoutusr is not null THEN
        :new.checkoutdtime := getutcdate();
    END IF;

    IF :new.checkoutusr is null THEN
        :new.checkoutdtime := NULL;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20911, SQLERRM);
END;
/
