CREATE procedure          sp_check_parentdeptlist
   ( i_userid in varchar2,
     i_deptid in varchar2)
   is
--
-- 12.4.0.0
--
    l_cnt            integer;
    l_dirty_cnt        integer;
    l_dept_cnt        integer;
    l_deptid        varchar2(10);
    var_deptid        varchar2(10);
    l_call_depth    integer;
    deptiderror      exception;
    l_inherittype   char;
    l_memberid      varchar2(10);
    l_parentdeptid  varchar2(10);
    l_userflag        char;
    l_mngflag         char;
begin
    if i_userid is not null then
        select count(1) into l_cnt from member where memberid = i_userid;
        if l_cnt > 0 then
            select deptid into l_deptid from member where memberid = i_userid;
        else
            l_deptid := null;
        end if;
    else
        select count(1) into l_cnt from member where memberid = i_deptid;
        if l_cnt > 0 then
            l_deptid := i_deptid;
        else
            l_deptid := null;
        end if;
    end if;

    if l_deptid is not null then
        select count(1) into l_dirty_cnt from parentmember
         where memberid = l_deptid
           and dirty = 'T';

        if (l_dirty_cnt > 0) then
            delete from parentmember where memberid = l_deptid;
        end if;

        select count(1) into l_dept_cnt from parentmember
         where memberid = l_deptid;

        if l_dept_cnt = 0 then
           l_userflag := 'T';
           l_mngflag := 'T';
           insert into parentmember(memberid, parentid, type, dirty, usrinherit, mnginherit)
           values (l_deptid, l_deptid, 'D', 'F', l_userflag, l_mngflag);

           select memberid, parentdeptid, inherittype
             into l_memberid, l_parentdeptid, l_inherittype
             from member
            where memberid = l_deptid;

            l_call_depth := 0;
            while (l_parentdeptid <> '0000000000') loop
                if (l_userflag = 'T') then
                   if (l_inherittype <> 'B' and l_inherittype <> 'U') then
                       l_userflag := 'F';
                   end if;
                end if;
                if (l_mngflag = 'T') then
                    if (l_inherittype <> 'B' and l_inherittype <> 'M') then
                        l_mngflag := 'F';
                    end if;
                end if;

                insert into parentmember (memberid, parentid, type, dirty, usrinherit, mnginherit)
                values (l_deptid, l_parentdeptid, 'D', 'F', l_userflag, l_mngflag);

                select memberid, parentdeptid, inherittype
                  into l_memberid, l_parentdeptid, l_inherittype
                  from member
                 where memberid = l_parentdeptid;

                l_call_depth := l_call_depth + 1;
                if (l_call_depth > 50) then
                    raise deptiderror;
                end if;
            end loop;
        end if;
    end if;

exception
    when deptiderror then
        raise_application_error(-20501, 'Invalid parent deptid.');
    when others then
        raise_application_error(-20700, sqlerrm);
end;
/
