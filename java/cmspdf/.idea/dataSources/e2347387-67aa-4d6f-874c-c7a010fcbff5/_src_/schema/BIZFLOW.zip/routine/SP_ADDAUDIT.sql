CREATE PROCEDURE sp_addAudit(
	IN_TASKID IN NUMBER,
	IN_SUBTASKID IN NUMBER,
	IN_FROMID IN VARCHAR2,
	IN_FROMNAME IN VARCHAR2,
    IN_FROMGROUPID IN VARCHAR2,
    IN_FROMGROUPNAME IN VARCHAR2,
	IN_TOID IN VARCHAR2,
	IN_TONAME IN VARCHAR2,
	IN_VALUETYPE IN VARCHAR2,
	IN_VALUE IN VARCHAR2) IS
-- 12.4.0.0
BEGIN
	INSERT INTO DTaskerAudit (TaskID, SubTaskID, Seq,
	                            FromID, FromName,
	                            FromGroupID, FromGroupName,
	                            ToID, ToName,
	                            CreationDT,
	                            ValueType, Value)
			            VALUES (IN_TASKID, IN_SUBTASKID, hws_dtaskeraudit.nextval,
			                    IN_FROMID, IN_FROMNAME,
			                    IN_FROMGROUPID, IN_FROMGROUPNAME,
			                    IN_TOID, IN_TONAME,
			                    sys_extract_utc(current_timestamp),
			                    IN_VALUETYPE, IN_VALUE);
END;
/
