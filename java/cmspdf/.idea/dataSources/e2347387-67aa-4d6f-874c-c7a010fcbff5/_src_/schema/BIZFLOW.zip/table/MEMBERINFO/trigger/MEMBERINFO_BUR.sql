CREATE TRIGGER BIZFLOW.MEMBERINFO_BUR
BEFORE UPDATE OF IDA, IDB
  ON BIZFLOW.MEMBERINFO
FOR EACH ROW
  DECLARE
	cnt				integer;
	l_jobtitleid	varchar2(10);
	invalidjobtitle	EXCEPTION;
-- 12.4.0.0
BEGIN
	IF :new.memberid <> '0000000000' THEN
		IF :new.ida is not null THEN
			SELECT count(1) INTO cnt
			  FROM jobtitle
			 WHERE jobtitleid = :new.ida;

			IF cnt = 0 THEN
				l_jobtitleid := :new.ida;
				RAISE invalidjobtitle;
			END IF;
		END IF;

		IF :new.idb is not null THEN
			SELECT count(1) INTO cnt
			  FROM jobtitle
			 WHERE jobtitleid = :new.idb;

			IF cnt = 0 THEN
				l_jobtitleid := :new.idb;
				RAISE invalidjobtitle;
			END IF;
		END IF;
	END IF;

EXCEPTION
	WHEN invalidjobtitle THEN
		RAISE_APPLICATION_ERROR(-20807, 'Invalid JobTitleID ' || l_jobtitleid);
	WHEN OTHERS THEN
		RAISE_APPLICATION_ERROR(-20927, SQLERRM);
END;
/
