CREATE procedure		   sp_va_createdocument
(
	i_svrid in varchar2,
	i_procid in number,
	i_objseq in number,
	i_mapid in number,
	i_dmsvrid in varchar2,
	i_dmdocid in varchar2,
	i_dmver in varchar2,
	i_dmverlabel in varchar2,
	i_prtcp in varchar2,
	i_type in char,
	i_dmtype in char,
	i_modifydtime in date
)
	is
--
-- 12.4.0.0
--
	l_type				char;
	l_dmtype			char;
	l_cnt				number;
	new_internalid		number(10);
	cannotcreate  		exception;
	errm				varchar2(800);
begin
	l_type := i_type;
	l_dmtype := i_dmtype;

	-- id.
	sp_get_id(i_svrid, TO_CHAR(i_procid), 1, new_internalid);

	if l_type = 'P' then
		if l_dmtype = 'V' then
			insert into va_appmap
				(svrid, procid, appinstid, dmsvrid, dmdocid,
				 dmver, mapid,
				 appsvrid, appid, internalid, lastappverseq, type)
			select
				 a.svrid, a.procid, new_internalid, i_dmsvrid, i_dmdocid,
				 i_dmver, b.mapid,
				 b.appsvrid, b.appid, 101, 100, l_type
			from procapp a, witemapp b
				where b.svrid = i_svrid
					and b.procid = i_procid
					and b.witemappseq = i_objseq
					and b.state <> 'W'
					and a.svrid = b.svrid
					and a.procid = b.procid
					and b.procappseq = a.procappseq;
		else
			insert into va_appmap
				(svrid, procid, appinstid, dmsvrid, dmdocid,
				 dmver, mapid,
				 appsvrid, appid, internalid, lastappverseq, type)
			select
				 a.svrid, a.procid, new_internalid, a.dmsvrid, i_dmdocid,
				 i_dmver, b.mapid,
				 b.appsvrid, b.appid, 101, 100, l_type
			from procapp a, witemapp b
				where b.svrid = i_svrid
					and b.procid = i_procid
					and b.witemappseq = i_objseq
					and b.state <> 'W'
					and a.svrid = b.svrid
					and a.procid = b.procid
					and b.procappseq = a.procappseq;
		end if;
	else
		-- copy type attach and use folder variable.
		-- or link type attach
		if l_dmtype in ('V', 'L') then
			insert into va_appmap
				(svrid, procid, appinstid, dmsvrid, dmdocid,
				 dmver, mapid,
				 appsvrid, appid, internalid, lastappverseq, type)
			select
				 svrid, procid, new_internalid, i_dmsvrid, i_dmdocid,
				 i_dmver, mapid,
				 null, 0, 101, 100, l_type
			from attach
				where svrid = i_svrid
					and procid = i_procid
					and mapid = i_mapid;
		-- copy type attach and not use folder variable.
		else
			insert into va_appmap
				(svrid, procid, appinstid, dmsvrid, dmdocid,
				 dmver, mapid,
				 appsvrid, appid, internalid, lastappverseq, type)
			select
				 a.svrid, a.procid, new_internalid, b.dmsvrid, i_dmdocid,
				 i_dmver, a.mapid,
				 null, 0, 101, 100, l_type
			from attach a, procs b
				where a.svrid = i_svrid
					and a.procid = i_procid
					and a.mapid = i_mapid
					and b.svrid = a.svrid
					and b.procid = a.procid;
		end if;
	end if;

	if sql%rowcount = 0 then
		errm := 'Can not CreateDocument.';
		raise cannotcreate;
	end if;

	if l_type = 'P' then
		if l_dmtype = 'V' then
			insert into va_appvermap
				(svrid, procid, appinstid, appverseq,
				 actseq, actappseq, mapid, appsvrid, appid,
				 dmsvrid, dmdocid, dmver, dmverlabel,
				 modifydtime, prtcp, prtcpname)
			select
				b.svrid, b.procid, new_internalid, 100,
				b.actseq, b.actappseq, b.mapid, b.appsvrid, b.appid,
				i_dmsvrid, i_dmdocid, i_dmver, i_dmverlabel,
				i_modifydtime, i_prtcp, c.name
			from witemapp b, member c
				where b.svrid = i_svrid
					and b.procid = i_procid
					and b.witemappseq = i_objseq
					and b.mapid = i_mapid
					and b.state <> 'W'
					and c.memberid = i_prtcp;
		else
			insert into va_appvermap
				(svrid, procid, appinstid, appverseq,
				 actseq, actappseq, mapid, appsvrid, appid,
				 dmsvrid, dmdocid, dmver, dmverlabel,
				 modifydtime, prtcp, prtcpname)
			select
				b.svrid, b.procid, new_internalid, 100,
				b.actseq, b.actappseq, b.mapid, b.appsvrid, b.appid,
				a.dmsvrid, i_dmdocid, i_dmver, i_dmverlabel,
				i_modifydtime, i_prtcp, c.name
			from procapp a, witemapp b, member c
				where b.svrid = i_svrid
					and b.procid = i_procid
					and b.witemappseq = i_objseq
					and b.mapid = i_mapid
					and b.state <> 'W'
					and a.svrid = b.svrid
					and a.procid = b.procid
					and a.procappseq = b.procappseq
					and c.memberid = i_prtcp;
		end if;
	else
		-- copy type attach and use folder variable.
		-- or link type attach
		if l_dmtype in ('V', 'L') then
			insert into va_appvermap
				(svrid, procid, appinstid, appverseq,
				 actseq, actappseq, mapid, appsvrid, appid,
				 dmsvrid, dmdocid, dmver, dmverlabel,
				 modifydtime, prtcp, prtcpname)
			select
				a.svrid, a.procid, new_internalid, 100,
				a.actseq, 0, a.mapid, null, 0,
				i_dmsvrid, i_dmdocid, i_dmver, i_dmverlabel,
				i_modifydtime, i_prtcp, b.name
			from attach a, member b
				where a.svrid = i_svrid
					and a.procid = i_procid
					and a.mapid = i_mapid
					and b.memberid = i_prtcp;
		-- copy type attach and not use folder variable.
		else
			insert into va_appvermap
				(svrid, procid, appinstid, appverseq,
				 actseq, actappseq, mapid, appsvrid, appid,
				 dmsvrid, dmdocid, dmver, dmverlabel,
				 modifydtime, prtcp, prtcpname)
			select
				a.svrid, a.procid, new_internalid, 100,
				a.actseq, 0, a.mapid, null, 0,
				b.dmsvrid, i_dmdocid, i_dmver, i_dmverlabel,
				i_modifydtime, i_prtcp, c.name
			from attach a, procs b, member c
				where a.svrid = i_svrid
					and a.procid = i_procid
					and a.mapid = i_mapid
					and b.svrid = a.svrid
					and b.procid = a.procid
					and c.memberid = i_prtcp;
		end if;
	end if;

	if sql%rowcount = 0 then
		errm := 'Can not CreateDocument.';
		raise cannotcreate;
	end if;

exception
    when cannotcreate then
        raise_application_error(-20517, errm);
	when others then
		raise_application_error(-20730, sqlerrm);
end; -- procedure
/
