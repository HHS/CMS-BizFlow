CREATE TRIGGER BIZFLOW.MEMBER_AIR
AFTER INSERT
  ON BIZFLOW.MEMBER
  DECLARE
	cnt					integer;
	l_descorder			number;
	l_id				varchar2(10);
	l_parentid			varchar2(10);
	l_deptid			varchar2(10);
	l_transactionid		varchar2(50);
	l_parentname		varchar2(100);
	l_inherittype		char(1);
	l_userflag			char(1);
	l_mngflag			char(1);
	l_membertype		char(1);
	l_path				varchar(500);
	parentiderror		exception;

	l_type			char(1);
	l_objid		    varchar2(20);
	l_objtype		varchar2(50);
	l_objtypestr	varchar2(50);
	l_ipaddr		varchar2(50);
	l_actor	   	    varchar2(10);
	l_actorname	    varchar2(100);
	l_objname		varchar2(100);
	l_event			varchar2(100);
	l_loginid		varchar2(100);
	l_email			varchar2(100);
	l_lictype		char(1);
	l_state			char(1);
	l_detail		varchar2(2048);

	-- bug20286: start
	cursor cur_get_id_by_transactionid  is
	select vara from hwtemp where tmpkey = l_transactionid;
	-- bug20286: end

-- 12.4.0.0
BEGIN
    select DBMS_TRANSACTION.LOCAL_TRANSACTION_ID into l_transactionid from dual;

	l_id := '';

	-- bug20286: start
	open cur_get_id_by_transactionid();
	loop
		fetch cur_get_id_by_transactionid into l_id;
		exit when cur_get_id_by_transactionid%notfound;

	--select count(1) into cnt from hwtemp where tmpkey = l_transactionid;

	--if (cnt > 0) then
	--	select vara into l_id from hwtemp where tmpkey = l_transactionid;
	-- bug20286: end
		--dbms_output.put_line('member_air inserted = ' || l_transactionid || ', ' || l_id);

		select type, memberid, name, deptid
		  into l_type, l_objid, l_objname, l_deptid
		  from member
		 where memberid = l_id;

		if l_type <> 'U' then

			l_userflag := 'T';
			l_mngflag  := 'T';

			select parentdeptid, inherittype, type, name into
				   l_parentid, l_inherittype, l_membertype, l_path
			  from member
			 where memberid = l_id;

			l_descorder := 1;
			l_path := '/' || l_path;

			while (l_parentid <> '0000000000') loop
				if (l_userflag = 'T') then
					if (l_inherittype <>'B'
						and l_inherittype <>'U'
						and l_inherittype <>'P'
						and l_inherittype <>'Q') then
						l_userflag := 'F';
					end if;
				end if;
				if (l_mngflag = 'T') then
					if (l_inherittype <> 'B'
						and l_inherittype <> 'M'
						and l_inherittype <> 'Q') then
						l_mngflag := 'F';
					end if;
				end if;

				insert into parentmember (
						memberid, parentid, type, dirty,
						usrinherit, mnginherit, descorder)
				select l_id, l_parentid, l_membertype, 'F', l_userflag, l_mngflag, l_descorder
				from dual WHERE NOT EXISTS (select 1 from parentmember where memberid = l_id and parentid = l_parentid);

				select parentdeptid, inherittype, name into
					   l_parentid, l_inherittype, l_parentname
				  from vusrgrp
				 where memberid = l_parentid;

				l_descorder := l_descorder + 1;
				if (l_descorder > 50) then
					raise parentiderror;
				end if;

				l_path := '/' || l_parentname || l_path;
			end loop;

			insert into parentmember(
					memberid, parentid, type, dirty,
					usrinherit, mnginherit, descorder, memberpath)
			select l_id, l_id, l_membertype, 'F', 'T', 'T', 0, l_path
			from dual WHERE NOT EXISTS (select 1 from parentmember where memberid = l_id and parentid = l_id);
		end if;

	-- log
		if (l_type <> 'H') then
			l_actor := '0000000000';
			l_actorname := 'System';
		else
			l_actor := '';
		end if;

		l_detail := '';
		l_event := 'ADDED';

		if (l_type = 'U') then
			begin
				select o.memberid, o.membername, u.ipaddr
				  into l_actor, l_actorname, l_ipaddr
				  from parentmember p, checkout o, usrsession u
				 where p.memberid = l_deptid
				   and o.nodeid = p.parentid
				   and o.type = 'O'
				   and u.memberid = o.memberid;
			exception when NO_DATA_FOUND then
				null;
			end;

			l_objtype := 'USER';
			l_objtypestr := 'User';

			select i.deptid, p.memberpath, i.loginid, i.email, i.inherittype, i.lictype, i.state
			  into l_parentid, l_path, l_loginid, l_email, l_inherittype, l_lictype, l_state
			  from parentmember p, member i
			 where i.memberid = l_id
			   and p.memberid = i.deptid
			   and p.parentid = p.memberid;

			l_detail := l_detail || '            <MEMBERID>' || l_objid || '</MEMBERID>' || chr(13) || chr(10);
			l_detail := l_detail || '            <NAME>' || l_objname || '</NAME>' || chr(13) || chr(10);
			l_detail := l_detail || '            <DEPTID>' || l_parentid || ' [' || l_path || ']</DEPTID>' || chr(13) || chr(10);
			l_detail := l_detail || '            <LOGINID>' || l_loginid || '</LOGINID>' || chr(13) || chr(10);
			l_detail := l_detail || '            <EMAIL>' || l_email || '</EMAIL>' || chr(13) || chr(10);
			l_detail := l_detail || '            <INHERITTYPE>' || l_inherittype || '</INHERITTYPE>' || chr(13) || chr(10);
			l_detail := l_detail || '            <LICTYPE>' || l_inherittype || '</LICTYPE>' || chr(13) || chr(10);
			l_detail := l_detail || '            <STATE>' || l_state || '</STATE>' || chr(13) || chr(10);
		elsif (l_type = 'D') then
			begin
				select o.memberid, o.membername, u.ipaddr
				  into l_actor, l_actorname, l_ipaddr
				  from parentmember p, checkout o, usrsession u
				 where p.memberid = l_id
				   and o.nodeid = p.parentid
				   and o.type = 'O'
				   and u.memberid = o.memberid;
			exception when NO_DATA_FOUND then
				null;
			end;
			l_objtype := 'ORGANIZATIONALUNIT';
			l_objtypestr := 'OrganizationalUnit';

			select i.parentdeptid
			  into l_parentid
			  from member i
			 where i.memberid = l_id;

			if (l_parentid = '0000000000') then
				l_path := '/';
			else
				select p.memberpath
				  into l_path
				  from parentmember p
				 where p.memberid = l_id
				   and p.parentid = p.memberid;
			end if;

			l_detail := l_detail || '            <MEMBERID>' || l_objid || '</MEMBERID>' || chr(13) || chr(10);
			l_detail := l_detail || '            <NAME>' || l_objname || '</NAME>' || chr(13) || chr(10);
			l_detail := l_detail || '            <PARENTDEPTID>' || l_parentid || ' [' || l_path || ']</PARENTDEPTID>' || chr(13) || chr(10);

		elsif (l_type = 'G') then
			begin
				select o.memberid, o.membername, u.ipaddr
				  into l_actor, l_actorname, l_ipaddr
				  from parentmember p, checkout o, usrsession u
				 where p.memberid = l_id
				   and o.nodeid = p.parentid
				   and o.type = 'G'
				   and u.memberid = o.memberid;
			exception when NO_DATA_FOUND then
				null;
			end;

			l_objtype := 'USERGROUP';
			l_objtypestr := 'UserGroup';

			select i.parentdeptid, p.memberpath
			  into l_parentid, l_path
			  from parentmember p, member i
			 where i.memberid = l_id
			   and p.memberid = i.parentdeptid
			   and p.parentid = p.memberid;

			l_detail := l_detail || '            <MEMBERID>' || l_objid || '</MEMBERID>' || chr(13) || chr(10);
			l_detail := l_detail || '            <NAME>' || l_objname || '</NAME>' || chr(13) || chr(10);
			l_detail := l_detail || '            <PARENTDEPTID>' || l_parentid || ' [' || l_path || ']</PARENTDEPTID>' || chr(13) || chr(10);

		end if;

		if (l_actor is not null and l_detail is not null) then
			insert into auditinfoadm (seq, actor, actorname, dtime, event, objid, objtype, objname, ipaddr, detail)
			values (hws_adminaudit.nextval, l_actor, l_actorname, getutcdate(), l_event, l_objid, l_objtype, l_objname, l_ipaddr,
					'<?xml version="1.0" encoding="UTF-8"?>'|| chr(13) || chr(10) ||
					'<ADMINAUDIT xmlns:del="http://www.handysoft.com/bizflow/XDiff/Delete" xmlns:xdf="http://www.handysoft.com/bizflow/XDiff">'	|| chr(13) || chr(10) ||
					'    <MEMBER>' || chr(13) || chr(10) ||
					'        <' || l_objtypestr || '>' || chr(13) || chr(10) ||
					l_detail ||
					'        </' || l_objtypestr || '>' || chr(13) || chr(10) ||
					'    </MEMBER>' || chr(13) || chr(10) ||
					'</ADMINAUDIT>');
		end if;

	-- bug20286: start
	end loop;
	-- bug20286: end

	delete from hwtemp where tmpkey = l_transactionid;

	-- bug20286: start
	--end if;
	-- bug20286: end

EXCEPTION
    when parentiderror then
        raise_application_error(-20818, 'Invalid parent memberid.');
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20935, SQLERRM);
END;
/
