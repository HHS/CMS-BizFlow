CREATE TRIGGER BIZFLOW.CHECKOUT_BIDR
BEFORE INSERT OR DELETE
  ON BIZFLOW.CHECKOUT
FOR EACH ROW
  BEGIN
	IF inserting THEN
		INSERT INTO auditinfoadm (seq, actor, actorname,dtime,event, objid, objtype)
			   VALUES (hws_adminaudit.nextval, :new.memberid, :new.membername, getutcdate(), 'CHECKOUT', :new.nodeid, :new.type);
	ELSIF deleting THEN
		INSERT INTO auditinfoadm (seq, actor, actorname,dtime,event, objid, objtype)
			   VALUES (hws_adminaudit.nextval, :old.memberid, :old.membername, getutcdate(), 'CHECKIN', :old.nodeid, :old.type);
	END IF;

END;
/
