CREATE TRIGGER BIZFLOW.USRGRPPRTCP_BIR
BEFORE INSERT
  ON BIZFLOW.USRGRPPRTCP
FOR EACH ROW WHEN (FOR EACH ROW )
DECLARE
cnt				integer;
l_usrgrphid		varchar2(10);
l_prtcptype		char(1);
l_prtcp			varchar2(10);
l_prtcpname		varchar2(100);
l_usrgrptype	char(1);
l_usrgrpid		varchar2(10);
l_usrgrpname	varchar2(100);
l_actor			varchar2(10);
l_actorname		varchar2(100);
l_event			varchar2(100);
l_objid			varchar2(10);
l_objtype		varchar2(50);
l_objname		varchar2(100);
l_ipaddr		varchar2(50);
l_path			varchar2(500);
l_detail		varchar2(2048);


-- 12.4.0.0
BEGIN

	l_actor := '0000000000';
	l_actorname := 'System';
	l_detail := '';

	l_prtcp := :new.prtcp;
	l_prtcptype := :new.prtcptype;
	l_usrgrpid := :new.usrgrpid;

	begin
		select prtcp.name, g.type, g.name
		  into l_prtcpname, l_usrgrptype, l_usrgrpname
		  from member prtcp, member g
		 where prtcp.memberid = :new.prtcp
		   and g.memberid = :new.usrgrpid;
	exception when NO_DATA_FOUND then
		return;
	end;

	l_objid := l_prtcp;
	l_objtype := 'USER';
	l_objname := l_prtcpname;

	if (l_prtcptype = 'U') then

	    select deptid into l_usrgrphid from member where memberid = :new.usrgrpid;
	    :new.usrgrphid := l_usrgrphid;

		if (l_usrgrptype = 'A')
		then
			l_event := 'AUTHORITYGRANTED';
			l_detail := l_usrgrpname;

			begin
				select o.memberid, o.membername, u.ipaddr
				  into l_actor, l_actorname, l_ipaddr
				  from member m, parentmember p, checkout o, usrsession u
				 where m.memberid = :new.prtcp
				   and p.memberid = m.deptid
				   and o.nodeid = p.parentid
				   and o.type = 'O'
				   and u.memberid = o.memberid;
			exception when NO_DATA_FOUND then
				null;
			end;

		elsif (l_usrgrptype = 'L') then
			l_event := 'LICENSEGRANTED';
			l_detail := l_usrgrpname;

			begin
				select o.memberid, o.membername, u.ipaddr
				  into l_actor, l_actorname, l_ipaddr
				  from member m, parentmember p, checkout o, usrsession u
				 where m.memberid = :new.prtcp
				   and p.memberid = m.deptid
				   and o.nodeid = p.parentid
				   and o.type = 'O'
				   and u.memberid = o.memberid;
			exception when NO_DATA_FOUND then
				null;
			end;
		elsif (l_usrgrptype = 'G') then
			l_event := 'ADDEDTOUSERGROUP';

			select p.memberpath into l_detail
			  from parentmember p
			 where p.memberid = :new.usrgrpid
			   and p.parentid = p.memberid;

			begin
				select o.memberid, o.membername, u.ipaddr
				  into l_actor, l_actorname, l_ipaddr
				  from parentmember p, checkout o, usrsession u
				 where p.memberid = :new.usrgrpid
				   and o.nodeid = p.parentid
				   and o.type in ('H','G')
				   and u.memberid = o.memberid;
			exception when NO_DATA_FOUND then
				begin
					select o.memberid, o.membername, u.ipaddr
					  into l_actor, l_actorname, l_ipaddr
					  from member m, parentmember p, checkout o, usrsession u
					 where m.memberid = :new.prtcp
					   and p.memberid = m.deptid
					   and o.nodeid = p.parentid
					   and o.type = 'O'
					   and u.memberid = o.memberid;
				exception when NO_DATA_FOUND then
					null;
				end;
			end;
		end if;
	elsif (l_prtcptype = 'G') then
		l_objid := l_prtcp;
		l_objtype := 'USERGROUP';
		l_objname := l_prtcpname;

		if (l_usrgrptype = 'A') then
			l_event := 'AUTHORITYGRANTED';
			l_detail := l_usrgrpname;

			begin
				select o.memberid, o.membername, u.ipaddr
				  into l_actor, l_actorname, l_ipaddr
				  from parentmember p, checkout o, usrsession u
				 where p.memberid = :old.prtcp
				   and o.nodeid = p.parentid
				   and o.type = 'G'
				   and u.memberid = o.memberid;
			exception when NO_DATA_FOUND then
				null;
			end;
		end if;
	end if;

	if (l_detail is not null)	then
		insert into auditinfoadm (seq, actor, actorname, dtime, event, objid, objtype, objname, ipaddr, detail)
		values (hws_adminaudit.nextval, l_actor, l_actorname, getutcdate(), l_event, l_objid, l_objtype, l_objname, l_ipaddr, l_detail);
	end if;
EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20926, SQLERRM);
END;
/
