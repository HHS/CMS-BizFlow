CREATE function        fn_get_wtime_leftover
  (	i_isdefault IN char,
	i_dayofweek IN char,
	i_memberid IN varchar2,
  	i_cal_date IN date,
	i_cur_date IN date)
  RETURN  number IS
   sw1				number;
   ew1				number;
   sw2				number;
   ew2				number;
   sw3				number;
   ew3				number;
   sw4				number;
   ew4				number;
   sw5				number;
   ew5				number;

   l_cur_date		date := i_cur_date;
   l_leftovers		number := 0;
-- 12.4.0.0
BEGIN

	if i_isdefault = 'T' then
		select sworktime1, eworktime1, sworktime2, eworktime2, sworktime3, eworktime3,
				 sworktime4, eworktime4, sworktime5, eworktime5
			into sw1, ew1, sw2, ew2, sw3, ew3, sw4, ew4, sw5, ew5
			from calhead
			where memberid = i_memberid
				and dayofweek = i_dayofweek;
	else
		select sworktime1, eworktime1, sworktime2, eworktime2, sworktime3, eworktime3,
				 sworktime4, eworktime4, sworktime5, eworktime5
			into sw1, ew1, sw2, ew2, sw3, ew3, sw4, ew4, sw5, ew5
			from membercal
			where memberid = i_memberid
				and caldtime = i_cal_date;
	end if;

--dbms_output.put_line('*** l_cur_date = ' || to_char(l_cur_date));

	if sw1 <> 0 or ew1 <> 0 then
--dbms_output.put_line('1 ' || to_char(i_cal_date + sw1/86400) || ' ~ ' || to_char(i_cal_date + ew1/86400));
		if l_cur_date < i_cal_date + sw1/86400 then
			l_leftovers := l_leftovers + ew1 - sw1;
			l_leftovers := l_leftovers + ew2 - sw2;
			l_leftovers := l_leftovers + ew3 - sw3;
			l_leftovers := l_leftovers + ew4 - sw4;
			l_leftovers := l_leftovers + ew5 - sw5;
--dbms_output.put_line('1-1 l_leftovers = ' || to_char(l_leftovers));
		elsif i_cal_date + sw1/86400 <= l_cur_date
			and l_cur_date < i_cal_date + ew1/86400 then
			l_leftovers := (i_cal_date + ew1/86400 - l_cur_date) * 86400;
			l_leftovers := l_leftovers + ew2 - sw2;
			l_leftovers := l_leftovers + ew3 - sw3;
			l_leftovers := l_leftovers + ew4 - sw4;
			l_leftovers := l_leftovers + ew5 - sw5;
--dbms_output.put_line('1-2 l_leftovers = ' || to_char(l_leftovers));
		end if;
	end if;

	if ew1 <> 0 or sw2 <> 0 then
		if i_cal_date + ew1/86400 <= l_cur_date
			and l_cur_date < i_cal_date + sw2/86400 then
			l_cur_date := i_cal_date + sw2/86400;
		end if;
	end if;

	if sw2 <> 0 and ew2 <> 0 then
--dbms_output.put_line('2 ' || to_char(i_cal_date + sw2/86400) || ' ~ ' || to_char(i_cal_date + ew2/86400));
		if i_cal_date + sw2/86400 <= l_cur_date
			and l_cur_date < i_cal_date + ew2/86400 then
			l_leftovers := (i_cal_date + ew2/86400 - l_cur_date) * 86400;
			l_leftovers := l_leftovers + ew3 - sw3;
			l_leftovers := l_leftovers + ew4 - sw4;
			l_leftovers := l_leftovers + ew5 - sw5;
		end if;
	end if;

	if ew2 <> 0 and sw3 <> 0 then
		if i_cal_date + ew2/86400 <= l_cur_date
			and l_cur_date < i_cal_date + sw3/86400 then
			l_cur_date := i_cal_date + sw3/86400;
		end if;
	end if;

	if sw3 <> 0 and ew3 <> 0 then
--dbms_output.put_line('3 ' || to_char(i_cal_date + sw3/86400) || ' ~ ' || to_char(i_cal_date + ew3/86400));
		if i_cal_date + sw3/86400 <= l_cur_date
			and l_cur_date < i_cal_date + ew3/86400 then
			l_leftovers := (i_cal_date + ew3/86400 - l_cur_date) * 86400;
			l_leftovers := l_leftovers + ew4 - sw4;
			l_leftovers := l_leftovers + ew5 - sw5;
		end if;
	end if;

	if ew3 <> 0 and sw4 <> 0 then
		if i_cal_date + ew3/86400 <= l_cur_date
			and l_cur_date < i_cal_date + sw4/86400 then
			l_cur_date := i_cal_date + sw4/86400;
		end if;
	end if;

	if sw4 <> 0 and ew4 <> 0 then
--dbms_output.put_line('4 ' || to_char(i_cal_date + sw4/86400) || ' ~ ' || to_char(i_cal_date + ew4/86400));
		if i_cal_date + sw4/86400 <= l_cur_date
			and l_cur_date < i_cal_date + ew4/86400 then
			l_leftovers := (i_cal_date + ew4/86400 - l_cur_date) * 86400;
			l_leftovers := l_leftovers + ew5 - sw5;
		end if;
	end if;

	if ew4 <> 0 and sw5 <> 0 then
		if i_cal_date + ew4/86400 <= l_cur_date
			and l_cur_date < i_cal_date + sw5/86400 then
			l_cur_date := i_cal_date + sw5/86400;
		end if;
	end if;

	if sw5 <> 0 and ew5 <> 0 then
--dbms_output.put_line('5 ' || to_char(i_cal_date + sw5/86400) || ' ~ ' || to_char(i_cal_date + ew5/86400));
		if i_cal_date + sw5/86400 <= l_cur_date
			and l_cur_date < i_cal_date + ew5/86400 then
			l_leftovers := (i_cal_date + ew5/86400 - l_cur_date) * 86400;
		end if;
	end if;

    RETURN l_leftovers;
END;
/
