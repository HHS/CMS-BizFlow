CREATE TRIGGER BIZFLOW.RESPGRPDEF_BDR
BEFORE DELETE
  ON BIZFLOW.RESPGRPDEF
FOR EACH ROW
  BEGIN

    DELETE FROM respdef
     WHERE svrid = :old.svrid
       AND procdefid = :old.procdefid
       AND respgrpdefseq = :old.respgrpdefseq;

 EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20922, SQLERRM);
END;
/
