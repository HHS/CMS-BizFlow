CREATE procedure sp_sync_witemcnt
   is
--
-- 12.4.0.0
--
	l_memberid			varchar2(10);
	l_state				char;
	l_urgent			char;
	l_prtcptype			char;
	l_witemcnt			number;

cursor cur_get_witem is
	select prtcp, state, urgent, prtcptype, count(*) count_of_item
	from witem where state in ('I', 'R', 'P', 'V')
					and onasync = 'F'
					group by prtcp, state, urgent, prtcptype;

begin

	delete from witemcnt;
	commit;

	insert into witemcnt (memberid, state, urgent, prtcptype, cnt)
		select memberid, 'I', 'F', type, 0
			from member where type in ( 'D', 'U', 'G', 'R' );
	insert into witemcnt (memberid, state, urgent, prtcptype, cnt)
		select memberid, 'R', 'F', type, 0
			from member where type in ( 'D', 'U', 'G', 'R' );
	insert into witemcnt (memberid, state, urgent, prtcptype, cnt)
		select memberid, 'P', 'F', type, 0
			from member where type in ( 'D', 'U', 'G', 'R' );
	insert into witemcnt (memberid, state, urgent, prtcptype, cnt)
		select memberid, 'V', 'F', type, 0
			from member where type in ( 'D', 'U', 'G', 'R' );
	insert into witemcnt (memberid, state, urgent, prtcptype, cnt)
		select memberid, 'I', 'T', type, 0
			from member where type in ( 'D', 'U', 'G', 'R' );
	insert into witemcnt (memberid, state, urgent, prtcptype, cnt)
		select memberid, 'R', 'T', type, 0
			from member where type in ( 'D', 'U', 'G', 'R' );
	insert into witemcnt (memberid, state, urgent, prtcptype, cnt)
		select memberid, 'P', 'T', type, 0
			from member where type in ( 'D', 'U', 'G', 'R' );
	insert into witemcnt (memberid, state, urgent, prtcptype, cnt)
		select memberid, 'V', 'T', type, 0
			from member where type in ( 'D', 'U', 'G', 'R' );
	commit;

	open cur_get_witem;
	loop
		fetch cur_get_witem into l_memberid, l_state, l_urgent, l_prtcptype, l_witemcnt;
		exit when cur_get_witem%notfound;

		update witemcnt set cnt = l_witemcnt, prtcptype = l_prtcptype
				where memberid = l_memberid
					and state = l_state
					and urgent = l_urgent;
	end loop;
	close cur_get_witem;

exception
    when others then
        if cur_get_witem%isopen then
            close cur_get_witem;
        end if;
end;
/
