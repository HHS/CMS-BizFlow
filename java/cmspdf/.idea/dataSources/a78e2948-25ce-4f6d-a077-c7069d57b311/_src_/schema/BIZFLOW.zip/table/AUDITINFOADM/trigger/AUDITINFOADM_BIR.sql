CREATE TRIGGER BIZFLOW.AUDITINFOADM_BIR
BEFORE INSERT
  ON BIZFLOW.AUDITINFOADM
FOR EACH ROW
  BEGIN
	if (:new.objname is null or 0 = nvl(length(:new.objname),0)) then
		:new.objname := fn_get_objectname(:new.objtype, :new.objid);
	end if;
END;
/
