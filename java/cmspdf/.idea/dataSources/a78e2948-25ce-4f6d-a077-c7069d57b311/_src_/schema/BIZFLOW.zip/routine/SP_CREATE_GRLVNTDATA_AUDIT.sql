CREATE procedure                  sp_create_grlvntdata_audit
(
	i_svrid			in	procdef.svrid%type default null,
	i_grlvntid		in	grlvntdata.grlvntdataid%type default null,
	i_valuetype		in	char,
	i_procid		in	procs.procid%type default null,
	i_modifydtime	in	varchar2 default null,
	i_actor			in	auditinfo.actor%type default null,
	i_name			in	grlvntdata.name%type default null,
	i_dscpt			in	grlvntdata.dscpt%type default null,
	i_dispvalue		in	grlvntdata.dispvalue%type default null,
	i_value			in	grlvntdata.value%type default null
)
IS
--
-- 12.4.0.0
--
	nEXECSEQ                NUMBER(10);
	l_dispvalue                varchar2(100);
BEGIN
    select hws_audit.nextval
      into nexecseq
      from dual;

    IF i_valuetype = 'A' THEN
		IF i_value is not null THEN
			SELECT name INTO l_dispvalue
			  FROM apptmplt
			 WHERE svrid = SUBSTR(i_value, 1, 10)
			   AND orgappid = to_number(SUBSTR(i_value, 12, 10))
		           AND isfinal = 'T'
               		   AND envtype = 'O';
		ELSE
			l_dispvalue := null;
		END IF;
    ELSIF  i_valuetype = 'P' THEN
		IF i_value is not null THEN
			SELECT name INTO l_dispvalue
			  FROM member
			 WHERE memberid = SUBSTR(i_value, 4, 10);
		ELSE
			l_dispvalue := null;
		END IF;
    ELSE
	l_dispvalue := i_dispvalue;
    END IF;

	if i_procid <> 0 then
		insert into grdauditinfo
		(grlvntdataid, execseq, svrid, procid, name, procname, modifydtime,
	     modifier, modifiername, dispvalue, dscpt, value)
		select
			i_grlvntid, nexecseq, i_svrid, i_procid, i_name, p.name,
			to_date(ltrim(rtrim(i_modifydtime)), 'YYYY/MM/DD HH24:MI:SS'),
			i_actor, a.name, l_dispvalue, i_dscpt, i_value
		from member a, procs p
		where a.memberid = i_actor
			and p.procid = i_procid;
	else
		insert into grdauditinfo
		(grlvntdataid, execseq, svrid, procid, name, procname, modifydtime,
	     modifier, modifiername, dispvalue, dscpt, value)
		select
			i_grlvntid, nexecseq, i_svrid, i_procid, i_name, '',
			to_date(ltrim(rtrim(i_modifydtime)), 'YYYY/MM/DD HH24:MI:SS'),
			i_actor, a.name, l_dispvalue, i_dscpt, i_value
		from member a
		where a.memberid = i_actor;
	end if;

exception
    when others then
        raise_application_error(-20740, sqlerrm);
end;
/
