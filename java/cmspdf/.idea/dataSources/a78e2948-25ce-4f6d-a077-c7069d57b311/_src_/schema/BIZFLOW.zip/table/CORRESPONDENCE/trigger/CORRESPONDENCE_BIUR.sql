CREATE TRIGGER BIZFLOW.CORRESPONDENCE_BIUR
BEFORE INSERT OR UPDATE
  ON BIZFLOW.CORRESPONDENCE
FOR EACH ROW
  BEGIN
    IF updating and :new.reader is not null and :new.type = 'I'  and :new.mediatype = 'email' and :new.registerdtime is null THEN
		update procs
		   set lastcorrespondence = 'Read'
	         where svrid = :new.svrid
	          and procid = :new.procid
	          and nvl(lastcorrespondence,'?') <> 'Read';
    ELSIF inserting and :new.type = 'I'  and :new.mediatype = 'email' and :new.registerdtime is null THEN
		update procs
		   set lastcorrespondence = 'New'
	         where svrid = :new.svrid
	          and procid = :new.procid;
    ELSIF inserting and :new.type = 'O'  and :new.mediatype = 'email' and :new.registerdtime is null THEN
		update procs
		   set lastcorrespondence = 'Sent'
	         where svrid = :new.svrid
	          and procid = :new.procid;
    END IF;
END;
/
