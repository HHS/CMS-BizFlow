CREATE TRIGGER BIZFLOW.PRTCP_BIUR
BEFORE INSERT OR UPDATE
  ON BIZFLOW.PRTCP
FOR EACH ROW
  DECLARE
l_prtcpname        varchar2(400);
l_deptname        varchar2(100);
l_jobtitlename    varchar2(100);
l_skiplength    number;
l_constskiplen    number;
l_first         varchar2(100);
l_second        varchar2(100);
l_third         varchar2(100);
l_forth         varchar2(100);
l_delim         varchar2(5);

-- 12.4.0.0
BEGIN

    l_constskiplen := 12;

    IF (:new.type = 'U') THEN

        SELECT name, deptname, jobtitlename
            INTO l_prtcpname, l_deptname, l_jobtitlename
                FROM member WHERE memberid = :new.prtcp;

        :new.prtcpname        := l_prtcpname;
        :new.deptname        := l_deptname;
        :new.jobtitlename    := l_jobtitlename;
    ELSIF :new.type in ('D', 'G', 'R') THEN
        SELECT name INTO l_prtcpname
        FROM member
        WHERE memberid = :new.prtcp;

        :new.prtcpname := l_prtcpname;
    ELSIF :new.type = 'V' THEN
        SELECT rlvntdataname INTO l_prtcpname
         FROM vrlvntdata
            WHERE svrid = :new.svrid
                AND procid = :new.procid
                AND rlvntdataseq = TO_NUMBER(:new.prtcp);

        :new.prtcpname := l_prtcpname;
    ELSIF :new.type = 'L' THEN

        -- find l_first
        l_skiplength := 0;
        IF :new.prtcp = '$$Starter' THEN
            l_first := '';
        ELSE
            IF :new.prtcp = '$$Act' THEN
                SELECT name INTO l_first FROM act
                WHERE svrid = :new.svrid
                    AND procid = :new.procid
                    AND actseq = TO_NUMBER(SUBSTRB(:new.expr, l_skiplength + 2, 10));
            ELSE    -- '$$User', '$$Role', '$$Dept', '$$UsrGrp'
                SELECT name INTO l_first FROM member
                 WHERE memberid = SUBSTRB(:new.expr, l_skiplength + 2, 10);
            END IF;

            l_skiplength := l_skiplength + 12;
        END IF;

        -- find l_second
        IF :new.expr like '%JobTitle%' THEN
            SELECT name INTO l_second FROM jobtitle
             WHERE jobtitleid = SUBSTRB(:new.expr, l_skiplength + 2, 10);
        ELSE
            l_second := '';
        END IF;

        -- find l_third
        IF :new.expr like '%AndRole%'
            or :new.expr like '%AndUsrGrp%' THEN
            SELECT name INTO l_third FROM member
                WHERE memberid = SUBSTRB(:new.expr, l_skiplength + l_constskiplen + 2, 10);
        ELSIF :new.expr like '%EqualRole%'
                or :new.expr like '%EqualUsrGrp%' THEN
            SELECT name INTO l_third FROM member
                WHERE memberid = SUBSTRB(:new.expr, l_skiplength + 2, 10);
        ELSE
            l_third := '';
        END IF;

        -- find l_forth
        l_forth := SUBSTRB(:new.expr, instrb(:new.expr, 'CR_', 1, 1), 100);

        l_delim := '~|;';
        :new.prtcpname := l_first || l_delim || l_second || l_delim || l_third || l_delim || l_forth;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20914, SQLERRM);
END;
/
