CREATE procedure sp_sync_parentfldr
   is
--
-- 12.4.0.0
--
	l_cnt			integer;
	l_id			number;
	l_inherittype	char(1);
	l_parentid		number;
	l_userflag		char(1);
	l_mngflag		char(1);
	l_descorder		number;
	l_parentname	varchar2(100);
	l_path			varchar2(500);
	parentiderror	exception;

cursor cur_get_id is
	select fldrid from fldrlist;

begin

	delete from parentfldr;

	open cur_get_id;

	loop
		fetch cur_get_id into l_id;
		exit when cur_get_id%notfound;

		l_userflag := 'T';
		l_mngflag := 'T';

		select parentfldrid, inherittype, name into
			   l_parentid, l_inherittype, l_path
		  from fldrlist
		 where fldrid = l_id;

		l_descorder := 0;
		l_path := '/' || l_path;

		while (l_parentid <> 0) loop
			if (l_userflag = 'T') then
				if (l_inherittype <> 'B' and l_inherittype <> 'U') then
					l_userflag := 'F';
				end if;
			end if;
			if (l_mngflag = 'T') then
				if (l_inherittype <> 'B' and l_inherittype <> 'M') then
					l_mngflag := 'F';
				end if;
			end if;

			insert into parentfldr(fldrid, parentfldrid, dirty, usrinherit, mnginherit)
			values (l_id, l_parentid, 'F', l_userflag, l_mngflag);

			select count(1) into l_cnt from fldrlist where fldrid = l_parentid;
			if (l_cnt > 0) then
				select parentfldrid, inherittype, name into
					   l_parentid, l_inherittype, l_parentname
				  from fldrlist
				 where fldrid = l_parentid;
			else
				exit;
			end if;

			l_descorder := l_descorder + 1;

			if (l_descorder > 50) then
				raise parentiderror;
			end if;

			l_path := '/' || l_parentname || l_path;
		end loop;

		insert into parentfldr(fldrid, parentfldrid, dirty, usrinherit, mnginherit)
		values (l_id, l_id, 'F', 'T', 'T');

		update fldrlist set fldrpath = l_path where fldrid = l_id;
	end loop;

	close cur_get_id;

exception
    when parentiderror then
        raise_application_error(-20539, 'Invalid parent fldrid.');
    when others then
		if cur_get_id%isopen then
		    close cur_get_id;
		end if;
        raise_application_error(-20746, sqlerrm);
end;
/
