CREATE function		 fn_get_rlvntdatavalue
  ( i_procid IN number,
	i_scope IN char,
	i_valuetype IN char,
	i_rlvntdataname IN varchar2)
  RETURN  nvarchar2 IS
	l_value 			nvarchar2(2000);
	l_dispvalue 		nvarchar2(100);
	l_pvName			varchar2(100);
-- 12.4.0.0
BEGIN
	IF i_scope not in ('I', 'D', 'G') or i_valuetype not in ('S', 'D', 'N', 'P', 'A', 'F') THEN
		l_pvName := LTRIM(i_scope || i_valuetype || i_rlvntdataname);

		select value, value into l_value, l_dispvalue from rlvntdata
			where procid = i_procid
				and rlvntdataname = l_pvName;
	ELSIF i_scope = 'I' THEN
		select value, dispvalue into l_value, l_dispvalue from rlvntdata
			where procid = i_procid
				and valuetype = i_valuetype
				and rlvntdataname = i_rlvntdataname
				and scope = 'I';
	ELSE
		select value, dispvalue into l_value, l_dispvalue
			from drlvntdataval r, procs p
			where r.valuetype = i_valuetype
				and r.rlvntdatadefname = i_rlvntdataname
				and r.orgprocdefid = p.orgprocdefid
				and p.procid = i_procid;
	END IF;

	IF i_valuetype in ('S', 'N', 'D') THEN
		RETURN SUBSTR(l_value, 1, 300);
	END IF;

	RETURN l_dispvalue;
END;
/
