CREATE TRIGGER BIZFLOW.MEMBER_BIDR
BEFORE INSERT OR DELETE
  ON BIZFLOW.MEMBER
FOR EACH ROW
  DECLARE
	l_transactionid		varchar2(50);
    cnt					integer;
    invalidjobtitle     EXCEPTION;
    cannotdelete        EXCEPTION;

	l_inherittype	char(1);
	l_path			varchar(500);
	l_parentid		varchar2(10);
	l_type			char(1);
	l_objid		    varchar2(20);
	l_objtype		varchar2(50);
	l_objtypestr	varchar2(50);
	l_ipaddr		varchar2(50);
	l_actor	   	    varchar2(10);
	l_actorname	    varchar2(100);
	l_objname		varchar2(100);
	l_event			varchar2(100);
	l_loginid		varchar2(100);
	l_email			varchar2(100);
	l_lictype		char(1);
	l_state			char(1);
	l_detail		varchar2(2048);


-- 12.4.0.0
BEGIN
	l_actor := '0000000000';
	l_actorname := 'System';

	-- log
	if deleting then
		l_detail := '';
		l_event := 'DELETED';
		l_type := :old.type;
		l_objid := :old.memberid;
		l_objname := :old.name;

		if (l_type = 'U') then
			begin
				select o.memberid, o.membername, u.ipaddr
				  into l_actor, l_actorname, l_ipaddr
				  from parentmember p, checkout o, usrsession u
				 where p.memberid = :old.deptid
				   and o.nodeid = p.parentid
				   and o.type = 'O'
				   and u.memberid = o.memberid;
			exception when NO_DATA_FOUND then
				null;
			end;

			l_objtype := 'USER';
			l_objtypestr := 'User';

			l_parentid := :old.deptid;
			l_loginid := :old.loginid;
			l_email := :old.email;
			l_inherittype := :old.inherittype;
			l_lictype := :old.lictype;
			l_state := :old.state;

			begin
				select memberpath
				  into l_path
				  from parentmember
				 where memberid = :old.deptid
				   and parentid = memberid;
			exception when NO_DATA_FOUND then
				l_path := 'Probably deleted';
			end;
			l_detail := l_detail || '            <MEMBERID>' || l_objid || '</MEMBERID>' || chr(13) || chr(10);
			l_detail := l_detail || '            <NAME>' || l_objname || '</NAME>' || chr(13) || chr(10);
			l_detail := l_detail || '            <DEPTID>' || l_parentid || ' [' || l_path || ']</DEPTID>' || chr(13) || chr(10);
			l_detail := l_detail || '            <LOGINID>' || l_loginid || '</LOGINID>' || chr(13) || chr(10);
			l_detail := l_detail || '            <EMAIL>' || l_email || '</EMAIL>' || chr(13) || chr(10);
			l_detail := l_detail || '            <INHERITTYPE>' || l_inherittype || '</INHERITTYPE>' || chr(13) || chr(10);
			l_detail := l_detail || '            <LICTYPE>' || l_inherittype || '</LICTYPE>' || chr(13) || chr(10);
			l_detail := l_detail || '            <STATE>' || l_state || '</STATE>' || chr(13) || chr(10);
		elsif (l_type = 'D') then
			begin
				select o.memberid, o.membername, u.ipaddr
				  into l_actor, l_actorname, l_ipaddr
				  from parentmember p, checkout o, usrsession u
				 where p.memberid = :old.memberid
				   and o.nodeid = p.parentid
				   and o.type = 'O'
				   and u.memberid = o.memberid;
			exception when NO_DATA_FOUND then
				null;
			end;
			l_objtype := 'ORGANIZATIONALUNIT';
			l_objtypestr := 'OrganizationalUnit';

			if (:old.parentdeptid = '0000000000') then
				l_path := '/';
			else
				begin
					select memberpath
					  into l_path
					  from parentmember
					 where memberid = :old.parentdeptid
					   and parentid = memberid;
				exception when NO_DATA_FOUND then
					l_path := 'Probably deleted';
				end;
			end if;

			l_parentid := :old.parentdeptid;

			l_detail := l_detail || '            <MEMBERID>' || l_objid || '</MEMBERID>' || chr(13) || chr(10);
			l_detail := l_detail || '            <NAME>' || l_objname || '</NAME>' || chr(13) || chr(10);
			l_detail := l_detail || '            <PARENTDEPTID>' || l_parentid || ' [' || l_path || ']</PARENTDEPTID>' || chr(13) || chr(10);

		elsif (l_type = 'G') then
			begin
				select o.memberid, o.membername, u.ipaddr
				  into l_actor, l_actorname, l_ipaddr
				  from parentmember p, checkout o, usrsession u
				 where p.memberid = :old.memberid
				   and o.nodeid = p.parentid
				   and o.type = 'G'
				   and u.memberid = o.memberid;
			exception when NO_DATA_FOUND then
				null;
			end;

			l_objtype := 'USERGROUP';
			l_objtypestr := 'UserGroup';

			begin
				select memberpath
				  into l_path
				  from parentmember
				 where memberid = :old.parentdeptid
				   and parentid = memberid;
			exception when NO_DATA_FOUND then
				l_path := 'Probably deleted';
			end;

			l_parentid := :old.parentdeptid;

			l_detail := l_detail || '            <MEMBERID>' || l_objid || '</MEMBERID>' || chr(13) || chr(10);
			l_detail := l_detail || '            <NAME>' || l_objname || '</NAME>' || chr(13) || chr(10);
			l_detail := l_detail || '            <PARENTDEPTID>' || l_parentid || ' [' || l_path || ']</PARENTDEPTID>' || chr(13) || chr(10);

		end if;

		if (l_actor is not null and l_detail is not null) then
			l_detail :=	'<?xml version="1.0" encoding="UTF-8"?>'|| chr(13) || chr(10) ||
						'<ADMINAUDIT xmlns:del="http://www.handysoft.com/bizflow/XDiff/Delete" xmlns:xdf="http://www.handysoft.com/bizflow/XDiff">'	|| chr(13) || chr(10) ||
						'    <MEMBER>' || chr(13) || chr(10) ||
						'        <' || l_objtypestr || '>' || chr(13) || chr(10) ||
						l_detail ||
						'        </' || l_objtypestr || '>' || chr(13) || chr(10) ||
						'    </MEMBER>' || chr(13) || chr(10) ||
						'</ADMINAUDIT>';

			insert into auditinfoadm (seq, actor, actorname, dtime, event, objid, objtype, objname, ipaddr, detail)
			values (hws_adminaudit.nextval, l_actor, l_actorname, getutcdate(), l_event, l_objid, l_objtype, l_objname, l_ipaddr,l_detail);
		end if;
	end if;



	-- bug19059: start
	-- Pass key to member_air
	if (inserting and :new.type in ('U', 'D', 'H', 'G')) then
	    select DBMS_TRANSACTION.LOCAL_TRANSACTION_ID into l_transactionid from dual;

		insert into hwtemp (tmpkey, vara)
		values (l_transactionid, :new.memberid);
		--dbms_output.put_line('member_bidr inserted = ' || l_transactionid || ', ' || :new.memberid);
	end if;
	-- bug19059: end

	IF inserting AND :new.type in ( 'D', 'U', 'G', 'R' ) THEN

        IF :new.type = 'U' THEN
			IF :new.jobtitleid is null THEN
				:new.jobtitleid := '9999999999';
			END IF;

			IF :new.passwddtime is null THEN
				:new.passwddtime := getutcdate();
			END IF;

            SELECT count(1) INTO cnt
              FROM jobtitle
             WHERE jobtitleid = :new.jobtitleid;

            IF cnt = 0 THEN
                RAISE invalidjobtitle;
            END IF;
        END IF;

        -- from 10.0 (seoul),
        -- the 'deptid' of the department is '9999999996'
        IF :new.type = 'D' THEN
            :new.deptid := '9999999996';
        END IF;

        INSERT INTO witemcnt (memberid, state, urgent, prtcptype, cnt)
            values (:new.memberid, 'I', 'F', :new.type, 0);
        INSERT INTO witemcnt (memberid, state, urgent, prtcptype, cnt)
            values (:new.memberid, 'R', 'F', :new.type, 0);
        INSERT INTO witemcnt (memberid, state, urgent, prtcptype, cnt)
            values (:new.memberid, 'P', 'F', :new.type, 0);
        INSERT INTO witemcnt (memberid, state, urgent, prtcptype, cnt)
            values (:new.memberid, 'V', 'F', :new.type, 0);
        INSERT INTO witemcnt (memberid, state, urgent, prtcptype, cnt)
            values (:new.memberid, 'I', 'T', :new.type, 0);
        INSERT INTO witemcnt (memberid, state, urgent, prtcptype, cnt)
            values (:new.memberid, 'R', 'T', :new.type, 0);
        INSERT INTO witemcnt (memberid, state, urgent, prtcptype, cnt)
            values (:new.memberid, 'P', 'T', :new.type, 0);
        INSERT INTO witemcnt (memberid, state, urgent, prtcptype, cnt)
            values (:new.memberid, 'V', 'T', :new.type, 0);

    ELSIF inserting AND :new.type ='H' THEN
        :new.deptid := '0000000000';
        :new.parentdeptid := '0000000000';

    ELSIF deleting AND :old.memberid = '0000000000' THEN
        RAISE cannotdelete;

    ELSIF deleting AND :old.type in ( 'D', 'U', 'G', 'R' ) THEN
		DELETE FROM witemcnt WHERE memberid = :old.memberid;
		DELETE FROM password WHERE memberid = :old.memberid;
		-- bug19059: start
		IF (:old.type in ('D','G')) THEN
			delete from parentmember where memberid = :old.memberid;
		END IF;
		-- bug19059: end
	ELSIF deleting AND :old.type = 'H' THEN
		delete from orgmanagerlist where memberid = :old.memberid;
		-- bug19059: start
		delete from parentmember where memberid = :old.memberid;
		-- bug19059: end
    END IF;


EXCEPTION
	WHEN invalidjobtitle THEN
		RAISE_APPLICATION_ERROR(-20804, 'Invalid JobTitleID ' || :new.jobtitleid);
	WHEN cannotdelete THEN
		RAISE_APPLICATION_ERROR(-20812, 'Cannot delete MemberID 0000000000.');
	WHEN OTHERS THEN
		RAISE_APPLICATION_ERROR(-20903, SQLERRM);
END;
/
