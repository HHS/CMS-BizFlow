CREATE TRIGGER BIZFLOW.ATTACH_BIDR
BEFORE INSERT OR DELETE
  ON BIZFLOW.ATTACH
FOR EACH ROW
  DECLARE
l_creatorname    varchar2(100);
l_actname        varchar2(100);
l_cnt            number;
l_category       varchar2(256);

cannotmodify    EXCEPTION;

-- 12.4.0.0
BEGIN
    IF inserting THEN
        IF :new.type <> 'S' and :new.type <> 'H' THEN
            UPDATE procs SET attachcnt = attachcnt + 1
             WHERE svrid = :new.svrid AND procid = :new.procid;
        END IF;

        SELECT name INTO l_creatorname FROM member
         WHERE memberid = :new.creator;
        :new.creatorname := l_creatorname;

        if(:new.actseq <> 0) THEN
            SELECT count(1) INTO l_cnt FROM act
             WHERE svrid = :new.svrid AND procid = :new.procid
               AND actseq = :new.actseq;

            if(l_cnt = 0) THEN
                RAISE cannotmodify;
            END IF;

            SELECT name INTO l_actname FROM act
                WHERE svrid = :new.svrid AND procid = :new.procid
                    AND actseq = :new.actseq;
            :new.actname := l_actname;
        END IF;

		IF(:new.category IS NULL) THEN
			SELECT COUNT(1)  INTO l_cnt
			  FROM mdata m
			 WHERE m.svrid = :new.svrid
			   AND m.procid = :new.procid
			   AND m.name = '_default_attach_category'
			   AND m.objtype = 'D';

			IF(l_cnt <> 0) THEN
				SELECT SUBSTRB(NVL(m.value, ''), 1, 256)  INTO l_category
				  FROM mdata m
				 WHERE m.svrid = :new.svrid
				   AND m.procid = :new.procid
				   AND m.name = '_default_attach_category'
				   AND m.objtype = 'D';

				:new.category := l_category;
			ELSE
				SELECT COUNT(1)  INTO l_cnt
				  FROM mdatadef md, procs p
				 WHERE p.svrid = :new.svrid
				   AND p.procid = :new.procid
				   AND md.svrid = p.svrid
				   AND md.procdefid = p.preprocdefid
				   AND md.name = '_default_attach_category'
				   AND md.objtype = 'D';

				IF(l_cnt <> 0) THEN
					SELECT SUBSTRB(NVL(md.value, ''), 1, 256)  INTO l_category
					  FROM mdatadef md, procs p
					 WHERE p.svrid = :new.svrid
					   AND p.procid = :new.procid
					   AND md.svrid = p.svrid
					   AND md.procdefid = p.preprocdefid
					   AND md.name = '_default_attach_category'
					   AND md.objtype = 'D';

					:new.category := l_category;
				ELSE
					SELECT COUNT(1)  INTO l_cnt
					  FROM rlvntdata r
					 WHERE r.svrid = :new.svrid
					   AND r.procid = :new.procid
					   AND r.rlvntdataname = 'default_attach_category';

					IF(l_cnt <> 0) THEN
						SELECT SUBSTRB(TO_CHAR(NVL(r.value, '')), 1, 256)  INTO l_category
						  FROM rlvntdata r
						 WHERE r.svrid = :new.svrid
						   AND r.procid = :new.procid
						   AND r.rlvntdataname = 'default_attach_category';

						:new.category := l_category;
					END IF;
				END IF;
			END IF;
		END IF;

    ELSIF  deleting THEN
        IF :old.type <> 'S' and :old.type <> 'H' THEN
            UPDATE procs SET attachcnt = attachcnt - 1
                WHERE svrid = :old.svrid AND procid = :old.procid;
        END IF;
    END IF;

EXCEPTION
   WHEN cannotmodify THEN
        RAISE_APPLICATION_ERROR(-20801, 'This Activity does not exists');
   WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20908, SQLERRM);
END;
/
