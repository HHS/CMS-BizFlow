CREATE FUNCTION FN_GETTASKINFO
(
    IN_PROCID IN NUMBER,
    IN_ACTSEQ IN NUMBER,
    IN_COLUMNNAME IN VARCHAR2
)
    RETURN VARCHAR2
IS
    S_RESULT VARCHAR2(4000);

    S_ASSIGNORNAME VARCHAR2(100);
    S_ORIGINATORNAME VARCHAR2(100);
    S_TITLE VARCHAR2(255);
    S_WBS VARCHAR2(200);
    S_STATUS VARCHAR2(25);
    S_PRIORITY VARCHAR2(40);
    D_STARTDATE date;
    D_DUEDATE date;
    D_ENDDATE date;
    C_ISMAINTASK char(1);
    S_DESC VARCHAR2(2048);
    N_NUM NUMBER;
    C_EXIST CHAR(1);
    S_SUSPENDED char(1);
    N_SUBTASKACTSEQ NUMBER;
    N_PROCID NUMBER;
    N_TASKID NUMBER;
    N_SUBTASKID NUMBER;
    N_TMPSUBTASKID NUMBER;
    S_EMAILSENDER VARCHAR2(255);

-- 12.4.0.0
BEGIN
    C_EXIST := 'F';
    C_ISMAINTASK := 'F';
    N_PROCID := IN_PROCID;
    N_TASKID := -1;
    N_SUBTASKID := 0;

    SELECT COUNT(1) INTO N_NUM
        FROM SubTasks
        WHERE ProcID = IN_PROCID
          AND (ACTSEQ = IN_ACTSEQ
                    OR  AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%'
                    OR  AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%'
                    OR  AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) );

    IF (N_NUM > 0) THEN

        C_EXIST := 'T';
        C_ISMAINTASK := 'F';

        SELECT TaskInitiatorName, Title, customid, State, StartDate, Description,
            duedate, enddate, priority, suspended, taskid, subtaskid, EmailSender
            INTO S_ASSIGNORNAME, S_TITLE, S_WBS, S_STATUS, D_STARTDATE, S_DESC, D_DUEDATE, D_ENDDATE, S_PRIORITY, S_SUSPENDED, N_TASKID, N_SUBTASKID, S_EMAILSENDER
            FROM SubTasks
            WHERE ProcID = IN_PROCID
                 AND (ACTSEQ = IN_ACTSEQ
                    OR  AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%'
                    OR  AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%'
                    OR  AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) );

    END IF;


    IF (C_EXIST = 'F') THEN
        SELECT COUNT(1) INTO N_NUM
        FROM Tasks
        WHERE ProcID = IN_PROCID
          AND (ACTSEQ = IN_ACTSEQ
                    OR  AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%'
                    OR  AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%'
                    OR  AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) );

        IF (N_NUM > 0) THEN
            C_EXIST := 'T';
            C_ISMAINTASK := 'T';

             SELECT TaskInitiatorName, OriginatorName, Title, customid, State, StartDate, Description,
             duedate, enddate, priority, suspended, taskid, EmailSender
             INTO S_ASSIGNORNAME, S_ORIGINATORNAME, S_TITLE, S_WBS, S_STATUS, D_STARTDATE, S_DESC, D_DUEDATE, D_ENDDATE, S_PRIORITY, S_SUSPENDED, N_TASKID, S_EMAILSENDER
             FROM Tasks
             WHERE ProcID = IN_PROCID
                 AND (ACTSEQ = IN_ACTSEQ
                    OR  AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%'
                    OR  AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%'
                    OR  AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) );
        ELSE -- Deadline Extension Request
            C_EXIST := 'T';
            SELECT
                fn_get_rlvntdatavalue(IN_PROCID, 'I', 'S', 'displayid'),
                fn_get_rlvntdatavalue(IN_PROCID, 'I', 'P', 'initiator'),
                fn_get_rlvntdatavalue(IN_PROCID, 'I', 'S', 'title'),
                fn_get_rlvntdatavalue(IN_PROCID, 'I', 'S', 'priority'),
                Tasks.ProcID, taskid
              INTO S_WBS, S_ASSIGNORNAME, S_TITLE, S_PRIORITY, N_PROCID, N_TASKID
              FROM Tasks
             WHERE TaskID = TO_NUMBER(fn_get_rlvntdatavalue(IN_PROCID, 'I', 'S', 'taskid'));
        END IF;

    END IF;

    IF (C_EXIST = 'T') THEN
        -- Get Status
        IF (IN_COLUMNNAME = 'initiatorname') THEN

            S_RESULT := S_ASSIGNORNAME;

            IF (C_ISMAINTASK = 'T' AND S_ORIGINATORNAME IS NOT NULL) THEN
                S_RESULT := S_ORIGINATORNAME;
            END IF;

        ELSIF (IN_COLUMNNAME = 'wbs') THEN
            S_RESULT := S_WBS;
        ELSIF (IN_COLUMNNAME = 'emailsender') THEN
            S_RESULT := S_EMAILSENDER;
        ELSIF (IN_COLUMNNAME = 'commentcount') THEN
            N_NUM := 0;

            IF (N_TASKID > 0) THEN
              IF(N_SUBTASKID > 0) THEN
                N_NUM := fn_GetSubTaskCommentsCnt2(N_TASKID, N_SUBTASKID);
              ELSE
                N_NUM := fn_GetTaskCommentsCnt(N_TASKID);
              END IF;
            END IF;

            S_RESULT := N_NUM;

        ELSIF (IN_COLUMNNAME = 'latestcomment') THEN
            IF C_ISMAINTASK = 'T' THEN
                SELECT COUNT(1) INTO N_NUM FROM cmnt WHERE procid = N_PROCID AND actseq = 0;
                IF N_NUM > 0 THEN
                	-- For tasks initiated in 11.5 or earlier version
                    SELECT CONTENTS INTO S_RESULT FROM (
                        SELECT C.CONTENTS AS CONTENTS
                          FROM CMNT C, WITEM W, ACT A
                         WHERE C.PROCID = W.PROCID
                           AND C.WITEMSEQ = W.WITEMSEQ
                           AND W.PROCID = A.PROCID
                           AND W.ACTSEQ = A.ACTSEQ
                           AND A.PROCID = N_PROCID
                           AND (A.ACTSEQ = IN_ACTSEQ
                                OR A.ACTSEQ IN (SELECT SELF.ACTSEQ FROM SUBTASKS SELF
                                                 WHERE SELF.PROCID = N_PROCID
                                                   AND SELF.PARENTTASKID = 0))
                         ORDER BY C.CMNTSEQ DESC
                    ) WHERE ROWNUM=1;
                ELSE
                    SELECT CONTENTS INTO S_RESULT FROM (
                        SELECT C.CONTENTS AS CONTENTS
                          FROM CMNT C
                         WHERE C.PROCID = N_PROCID
                           AND (C.ACTSEQ = IN_ACTSEQ
                                OR C.ACTSEQ IN (SELECT SELF.ACTSEQ FROM SUBTASKS SELF
                                                 WHERE SELF.PROCID = N_PROCID
                                                   AND SELF.PARENTTASKID = 0))
                         ORDER BY C.CMNTSEQ DESC
                    ) WHERE ROWNUM=1;
                END IF;
            ELSE
                SELECT COUNT(1) INTO N_NUM FROM cmnt WHERE procid = N_PROCID AND actseq = 0;
                IF N_NUM > 0 THEN
                	-- For tasks initiated in 11.5 or earlier version
                    SELECT CONTENTS INTO S_RESULT FROM (
                        SELECT C.CONTENTS AS CONTENTS
                          FROM CMNT C, WITEM W, ACT A
                         WHERE C.PROCID = W.PROCID
                           AND C.WITEMSEQ = W.WITEMSEQ
                           AND W.PROCID = A.PROCID
                           AND W.ACTSEQ = A.ACTSEQ
                           AND A.PROCID = N_PROCID
                           AND (A.ACTSEQ = IN_ACTSEQ
                                OR A.ACTSEQ IN (SELECT CHILD.ACTSEQ FROM SUBTASKS SELF, SUBTASKS CHILD
                                         WHERE SELF.PROCID = N_PROCID
                                           AND SELF.PROCID = CHILD.PROCID
                                           AND SELF.ACTSEQ = IN_ACTSEQ
                                           AND SELF.SUBTASKID = CHILD.PARENTTASKID))
                         ORDER BY C.CMNTSEQ DESC
                    ) WHERE ROWNUM=1;
                ELSE
                    SELECT CONTENTS INTO S_RESULT FROM (
                        SELECT C.CONTENTS AS CONTENTS
                          FROM CMNT C
                         WHERE C.PROCID = N_PROCID
                           AND (C.ACTSEQ = IN_ACTSEQ
                                OR C.ACTSEQ IN (SELECT CHILD.ACTSEQ FROM SUBTASKS SELF, SUBTASKS CHILD
                                         WHERE SELF.PROCID = N_PROCID
                                           AND SELF.PROCID = CHILD.PROCID
                                           AND SELF.ACTSEQ = IN_ACTSEQ
                                           AND SELF.SUBTASKID = CHILD.PARENTTASKID))
                         ORDER BY C.CMNTSEQ DESC
                    ) WHERE ROWNUM=1;
                END IF;
            END IF;
        ELSIF (IN_COLUMNNAME = 'guidance') THEN
            IF C_ISMAINTASK = 'T' THEN
                SELECT COUNT(1) INTO N_NUM FROM cmnt WHERE procid = N_PROCID AND actseq = 0;
                IF N_NUM > 0 THEN
                	-- For tasks initiated in 11.5 or earlier version
                    SELECT CONTENTS INTO S_RESULT FROM (
                        SELECT C.CONTENTS AS CONTENTS
                          FROM CMNT C, WITEM W, ACT A
                         WHERE C.PROCID = W.PROCID
                           AND C.WITEMSEQ = W.WITEMSEQ
                           AND W.PROCID = A.PROCID
                           AND W.ACTSEQ = A.ACTSEQ
                           AND A.PROCID = N_PROCID
                           AND (A.ACTSEQ = IN_ACTSEQ
                                OR A.ACTSEQ IN (SELECT SELF.ACTSEQ FROM SUBTASKS SELF
                                                 WHERE SELF.PROCID = N_PROCID
                                                   AND SELF.PARENTTASKID = 0))
                         ORDER BY C.CMNTSEQ ASC
                    ) WHERE ROWNUM=1;
                ELSE
                    SELECT CONTENTS INTO S_RESULT FROM (
                        SELECT C.CONTENTS AS CONTENTS
                          FROM CMNT C
                         WHERE C.PROCID = N_PROCID
                           AND (C.ACTSEQ = IN_ACTSEQ
                                OR C.ACTSEQ IN (SELECT SELF.ACTSEQ FROM SUBTASKS SELF
                                                 WHERE SELF.PROCID = N_PROCID
                                                   AND SELF.PARENTTASKID = 0))
                         ORDER BY C.CMNTSEQ ASC
                    ) WHERE ROWNUM=1;
                END IF;
            ELSE
                SELECT COUNT(1) INTO N_NUM FROM cmnt WHERE procid = N_PROCID AND actseq = 0;
                IF N_NUM > 0 THEN
                	-- For tasks initiated in 11.5 or earlier version
                    SELECT CONTENTS INTO S_RESULT FROM (
                        SELECT C.CONTENTS AS CONTENTS
                          FROM CMNT C, WITEM W, ACT A
                         WHERE C.PROCID = W.PROCID
                           AND C.WITEMSEQ = W.WITEMSEQ
                           AND W.PROCID = A.PROCID
                           AND W.ACTSEQ = A.ACTSEQ
                           AND A.PROCID = N_PROCID
                           AND (A.ACTSEQ = IN_ACTSEQ
                                OR A.ACTSEQ IN (SELECT CHILD.ACTSEQ FROM SUBTASKS SELF, SUBTASKS CHILD
                                         WHERE SELF.PROCID = N_PROCID
                                           AND SELF.PROCID = CHILD.PROCID
                                           AND SELF.ACTSEQ = IN_ACTSEQ
                                           AND SELF.SUBTASKID = CHILD.PARENTTASKID))
                         ORDER BY C.CMNTSEQ ASC
                    ) WHERE ROWNUM=1;
                ELSE
                    SELECT CONTENTS INTO S_RESULT FROM (
                        SELECT C.CONTENTS AS CONTENTS
                          FROM CMNT C
                         WHERE C.PROCID = N_PROCID
                           AND (C.ACTSEQ = IN_ACTSEQ
                                OR C.ACTSEQ IN (SELECT CHILD.ACTSEQ FROM SUBTASKS SELF, SUBTASKS CHILD
                                         WHERE SELF.PROCID = N_PROCID
                                           AND SELF.PROCID = CHILD.PROCID
                                           AND SELF.ACTSEQ = IN_ACTSEQ
                                           AND SELF.SUBTASKID = CHILD.PARENTTASKID))
                         ORDER BY C.CMNTSEQ ASC
                    ) WHERE ROWNUM=1;
                END IF;
            END IF;
        ELSIF (IN_COLUMNNAME = 'title') THEN
              IF (LENGTH(S_TITLE) > 100) THEN
                 S_RESULT := SUBSTR(S_TITLE, 0, 97) || '...';
            ELSE
                 S_RESULT := S_TITLE;
            END IF;
        ELSIF (IN_COLUMNNAME = 'priority') THEN
            S_RESULT := S_PRIORITY;
        ELSIF (IN_COLUMNNAME = 'taskdesc') THEN
            IF (LENGTH(S_DESC) > 100) THEN
                 S_RESULT := SUBSTR(S_DESC, 0, 97) || '...';
            ELSE
                 S_RESULT := S_DESC;
            END IF;
        ELSIF (IN_COLUMNNAME = 'status') THEN

            IF (S_SUSPENDED = 'T') THEN
                S_RESULT := 'Suspended';
            ELSE
                IF (C_ISMAINTASK = 'T') THEN
                    IF (D_ENDDATE IS NOT NULL) THEN
                        IF (D_ENDDATE > D_DUEDATE) THEN
                            S_RESULT := 'Complete_Overdue';
                        ELSE
                            S_RESULT := 'Complete';
                        END IF;
                    ELSE
                        IF (D_DUEDATE- SYS_EXTRACT_UTC (CURRENT_TIMESTAMP) < NUMTODSINTERVAL (0, 'SECOND') ) THEN
                            S_RESULT := 'Overdue';
                        ELSE
                            IF (S_STATUS = 'Approved') THEN
                                S_RESULT := 'Approved';
                            ELSIF (S_STATUS = 'Disapproved') THEN
                                S_RESULT := 'Disapproved';
                            ELSIF (S_STATUS = 'PendingSubTasks') THEN
                                S_RESULT := 'PendingSubTasks';
                            ELSIF (S_STATUS = 'Elevated') THEN
                                S_RESULT := 'Elevated';
                            ELSE
                                S_RESULT := 'Active';
                            END IF;
                        END IF;
                    END IF;
                ELSE
                    IF (D_ENDDATE IS NOT NULL) THEN
                        IF (S_STATUS = 'Closed') THEN
                            S_RESULT := 'Closed';
                        ELSIF (D_ENDDATE > D_DUEDATE) THEN
                            S_RESULT := 'Complete_Overdue';
                        ELSE
                            S_RESULT := 'Complete';
                        END IF;
                    ELSE
                        IF (S_STATUS = 'Completed') THEN
                            S_RESULT := 'Complete';
                        ELSIF (S_STATUS = 'Closed') THEN
                            S_RESULT := 'Closed';
                        ELSIF (D_DUEDATE- SYS_EXTRACT_UTC (CURRENT_TIMESTAMP) < NUMTODSINTERVAL (0, 'SECOND') ) THEN
                            S_RESULT := 'Overdue';
                        ELSIF (S_STATUS = 'Declined') THEN
                            S_RESULT := 'Declined';
                        ELSIF (S_STATUS = 'Opened') THEN
                            S_RESULT := 'Opened';
                        ELSIF (S_STATUS = 'Assigned') THEN
                            S_RESULT := 'Assigned';
                        ELSIF (S_STATUS = 'PendingSubTasks') THEN
                            S_RESULT := 'PendingSubTasks';
                        Else
                            S_RESULT := 'Active';
                        END IF;
                    END IF;
                END IF; -- (C_ISMAINTASK = 'T')

            END IF; -- (S_SUSPENDED = 'T')
        ELSIF (IN_COLUMNNAME = 'customstring1') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring1 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring1 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring2') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring2 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring2 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring3') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring3 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring3 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring4') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring4 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring4 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring5') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring5 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring5 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring6') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring6 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring6 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring7') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring7 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring7 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring8') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring8 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring8 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring9') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring9 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring9 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring10') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring10 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring10 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring11') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring11 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring11 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring12') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring12 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring12 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring13') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring13 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring13 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring14') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring14 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring14 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring15') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring15 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring15 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring16') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring16 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring16 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring17') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring17 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring17 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring18') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring18 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring18 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring19') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring2 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring2 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring20') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring20 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring20 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring21') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring21 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring21 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring22') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring22 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring22 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring23') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring23 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring23 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring24') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring24 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring24 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring25') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring25 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring25 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring26') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring26 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring26 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring27') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring27 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring27 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring28') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring28 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring28 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring29') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring29 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring29 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customstring30') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customstring30 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customstring30 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customnumber1') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customnumber1 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customnumber1 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customnumber2') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customnumber2 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customnumber2 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customnumber3') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customnumber3 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customnumber3 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customnumber4') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customnumber4 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customnumber4 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customnumber5') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customnumber5 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customnumber5 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customnumber6') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customnumber6 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customnumber6 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customnumber7') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customnumber7 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customnumber7 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customnumber8') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customnumber8 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customnumber8 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customnumber9') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customnumber9 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customnumber9 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customnumber10') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customnumber10 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customnumber10 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customnumber11') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customnumber11 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customnumber11 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customnumber12') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customnumber12 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customnumber12 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customnumber13') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customnumber13 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customnumber13 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customnumber14') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customnumber14 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customnumber14 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customnumber15') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customnumber15 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customnumber15 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customnumber16') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customnumber16 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customnumber16 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customnumber17') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customnumber17 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customnumber17 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customnumber18') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customnumber18 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customnumber18 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customnumber19') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customnumber19 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customnumber19 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customnumber20') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select b.customnumber20 into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR	a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select b.customnumber20 into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customdate1') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select to_char(b.customdate1, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select to_char(b.customdate1, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR	a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customdate2') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select to_char(b.customdate2, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select to_char(b.customdate2, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR	a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customdate3') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select to_char(b.customdate3, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select to_char(b.customdate3, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR	a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customdate4') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select to_char(b.customdate4, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select to_char(b.customdate4, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR	a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customdate5') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select to_char(b.customdate5, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select to_char(b.customdate5, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR	a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customdate6') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select to_char(b.customdate6, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select to_char(b.customdate6, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR	a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customdate7') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select to_char(b.customdate7, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select to_char(b.customdate7, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR	a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customdate8') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select to_char(b.customdate8, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select to_char(b.customdate8, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR	a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customdate9') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select to_char(b.customdate9, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select to_char(b.customdate9, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR	a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customdate10') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select to_char(b.customdate10, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select to_char(b.customdate10, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customdate11') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select to_char(b.customdate11, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select to_char(b.customdate11, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customdate12') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select to_char(b.customdate12, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select to_char(b.customdate12, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customdate13') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select to_char(b.customdate13, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select to_char(b.customdate13, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customdate14') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select to_char(b.customdate14, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select to_char(b.customdate14, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customdate15') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select to_char(b.customdate15, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select to_char(b.customdate15, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customdate16') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select to_char(b.customdate16, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select to_char(b.customdate16, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customdate17') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select to_char(b.customdate17, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select to_char(b.customdate17, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customdate18') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select to_char(b.customdate18, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select to_char(b.customdate18, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customdate19') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select to_char(b.customdate19, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select to_char(b.customdate19, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'customdate20') THEN
            IF (C_ISMAINTASK = 'T') THEN
                select to_char(b.customdate20, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from tasks a join tasksaux b on a.taskid = b.taskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            ELSE
                select to_char(b.customdate20, 'yyyy/mm/dd hh24:mi:ss') into S_RESULT from subtasks a join subtasksaux b on a.taskid = b.taskid and a.subtaskid = b.subtaskid WHERE a.ProcID = IN_PROCID AND (a.ACTSEQ = IN_ACTSEQ OR  a.AllActSeqs LIKE TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ) || ',%' OR  a.AllActSeqs LIKE '%,' || TO_CHAR(IN_ACTSEQ));
            END IF;
        ELSIF (IN_COLUMNNAME = 'assignorforchild') THEN
            S_RESULT := NULL;
            IF (N_TASKID > 0) THEN
	            S_RESULT := 'NODATA';
				IF (N_SUBTASKID > 0) THEN -- S_RESULT should be assignor for child task of current subtask.
					N_TMPSUBTASKID := -1;
				    SELECT COUNT(1) INTO N_NUM
					  FROM subtasks
					 WHERE taskid = N_TASKID
					   AND parenttaskid = N_SUBTASKID;
				    IF (N_NUM > 0) THEN
					    SELECT subtaskid INTO N_TMPSUBTASKID
						  FROM subtasks
						 WHERE taskid = N_TASKID
						   AND parenttaskid = N_SUBTASKID;
					    IF (N_TMPSUBTASKID > 0) THEN
						    SELECT COUNT(1) INTO N_NUM
							  FROM taskprtcp
							 WHERE taskid = N_TASKID
							   AND subtaskid = N_TMPSUBTASKID
							   AND type = 'U'
							   AND kind = 'ASSIGNOR';
						    IF (N_NUM > 0) THEN
								SELECT prtcp INTO S_RESULT
								  FROM taskprtcp
								 WHERE taskid = N_TASKID
								   AND subtaskid = N_TMPSUBTASKID
								   AND type = 'U'
								   AND kind = 'ASSIGNOR';
						    END IF;
						END IF;
				    END IF;
				ELSE -- S_RESULT should be assignor for main task.
				    SELECT COUNT(1) INTO N_NUM
				      FROM taskprtcp
				     WHERE taskid = N_TASKID
				       AND subtaskid = N_SUBTASKID
				       AND TYPE = 'U'
				       AND NVL(kind,'ASSIGNOR') = 'ASSIGNOR';

				    IF (N_NUM > 0) THEN
						SELECT prtcp INTO S_RESULT
						  FROM taskprtcp
						 WHERE taskid = N_TASKID
						   AND subtaskid = N_SUBTASKID
						   AND type = 'U'
						   AND NVL(kind,'ASSIGNOR') = 'ASSIGNOR';
				    END IF;
				END IF;
			END IF;
        ELSIF (IN_COLUMNNAME = 'assignee') THEN
            S_RESULT := NULL;
            IF (N_TASKID > 0) THEN
	            S_RESULT := 'NODATA';
			    SELECT COUNT(1) INTO N_NUM
			      FROM taskprtcp
			     WHERE taskid = N_TASKID
			       AND subtaskid = N_SUBTASKID
			       AND TYPE = 'U'
			       AND kind = 'ASSIGNEE';

			    IF (N_NUM > 0) THEN
					SELECT prtcp INTO S_RESULT
					  FROM taskprtcp
					 WHERE taskid = N_TASKID
					   AND subtaskid = N_SUBTASKID
					   AND type = 'U'
					   AND kind = 'ASSIGNEE';
			    END IF;
            END IF;

        END IF; -- (IN_COLUMNNAME = 'status')

    END IF; -- N_NUM > 0

    RETURN S_RESULT;
END;
/
