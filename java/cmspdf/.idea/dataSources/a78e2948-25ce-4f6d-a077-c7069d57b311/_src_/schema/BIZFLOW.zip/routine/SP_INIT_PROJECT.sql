CREATE procedure                  sp_init_project
(
	i_svrid			in	fldrlist.svrid%type default null,
	i_projectid		in	fldrlist.fldrid%type default null,
	i_projectroleid	in	number default null,
	i_creatorid		in	fldrlist.creatorid%type default null,
	i_creationdtime in  date
)
IS
--
-- 12.4.0.0
--
l_prjrole_publication		varchar2(10);
l_prjrole_publicationname	 varchar2(100);
l_prjrole_prjmanager	varchar2(10);
l_prjrole_deginer		varchar2(10);
l_prjrole_publisher		varchar2(10);
l_prjrole_guest			varchar2(10);

BEGIN

	update fldrlist
		set creatorname = ( select name from member where memberid = i_creatorid ),
			creationdtime = i_creationdtime
		where svrid = i_svrid
			and fldrid = i_projectid;

	-- below B/L logic is equal to that of
	--	'/server/hwsfldr/sfuproject.cpp, GetProjectRoleIDFromNumber()'
	l_prjrole_publication := 'prja' || trim(to_char(i_projectroleid, '000000'));
	l_prjrole_publicationname := '_' || trim(to_char(i_projectid)) || '_publication';
	l_prjrole_prjmanager := 'prja' || trim(to_char(i_projectroleid + 1, '000000'));
	l_prjrole_deginer := 'prja' || trim(to_char(i_projectroleid + 2, '000000'));
	l_prjrole_publisher := 'prja' || trim(to_char(i_projectroleid + 3, '000000'));
	l_prjrole_guest := 'prja' || trim(to_char(i_projectroleid + 4, '000000'));

	-- insert the default folders: process definition, application
	insert into fldrlist ( svrid, prjid, fldrid, type, ispublic, inherittype, parentfldrid, disporder, ver, name, creatorid )
	values ( i_svrid, i_projectid, i_projectid + 1, 'D', 'T', 'N', i_projectid, 100, 1, 'Process Definitions', i_creatorid	);

	insert into fldrlist (svrid, prjid, fldrid, type, ispublic, inherittype, parentfldrid, disporder, ver, name, creatorid )
	values ( i_svrid, i_projectid, i_projectid + 2, 'A', 'T', 'N', i_projectid, 100, 1, 'Application', i_creatorid	);

	-- insert the project publication authority group.
	insert into member ( memberid, type, name, disporder, deptid, passwddtime, managerid ) values ( l_prjrole_publication, 'A', l_prjrole_publicationname, 100, i_projectid, i_creationdtime ,i_creatorid  );

	-- insert the default project role
	insert into member ( memberid, type, name, disporder, deptid, passwddtime, managerid, alias ) values ( l_prjrole_prjmanager, 'A', 'Project Manager', 100, i_projectid, i_creationdtime, i_creatorid, 'PROJECTMANAGER');
	insert into member ( memberid, type, name, disporder, deptid, passwddtime, managerid, alias ) values ( l_prjrole_deginer, 'A', 'Designer', 101, i_projectid, i_creationdtime, i_creatorid, 'DESIGNER');
	insert into member ( memberid, type, name, disporder, deptid, passwddtime, managerid, alias ) values ( l_prjrole_publisher, 'A', 'Publisher', 102, i_projectid, i_creationdtime, i_creatorid, 'PUBLISHER');
	insert into member ( memberid, type, name, disporder, deptid, passwddtime, managerid, alias ) values ( l_prjrole_guest, 'A', 'Guest', 103, i_projectid, i_creationdtime, i_creatorid, 'GUEST' );

	insert into usrgrpprtcp ( usrgrpid, prtcp, prtcptype, disporder, usrgrphid ) values ( 'licsgrp003', l_prjrole_prjmanager, 'A', 100, i_projectid );
	insert into usrgrpprtcp ( usrgrpid, prtcp, prtcptype, disporder, usrgrphid ) values ( 'licsgrp003', l_prjrole_deginer, 'A', 100, i_projectid );
	insert into usrgrpprtcp ( usrgrpid, prtcp, prtcptype, disporder, usrgrphid ) values ( 'licsgrp003', l_prjrole_publisher, 'A', 100, i_projectid );
	insert into usrgrpprtcp ( usrgrpid, prtcp, prtcptype, disporder, usrgrphid ) values ( 'licsgrp003', l_prjrole_guest, 'A', 100, i_projectid );

	--Hidden Authority Group for Publication
	-- fldrmemberlist (project)
	--AUTHID_ITEM_PUBLISH					0x08000000
	insert into fldrmemberlist ( svrid, fldrid, memberid, type, isexclude, disporder, auth, name )
	values ( i_svrid, i_projectid, l_prjrole_publication, 'A', 'F', 101, 134217728, 'Default Publication AG');

	--Project Manager
	-- fldrmemberlist (project)
	--AUTHID_FOLDER_VIEW					0x00000001
	--AUTHID_FOLDER_MODIFY					0x00000008
	-- fldrmemberlist (folder)
	--AUTHID_FOLDER_VIEW					0x00000001
	--AUTHID_FOLDER_CONTENTS_VIEW			0x00000002
	--AUTHID_ITEM_VIEW						0x00000100
	--AUTHID_ITEM_CREATE					0x00000200
	--AUTHID_ITEM_DELETE					0x00000400
	--AUTHID_ITEM_MODIFY					0x00000800
	-- fldrmanagerlist(project)
	--AUTHID_FOLDER_PROJECT_MANAGE			0x00000080
	--AUTHID_ITEM_CREATE					0x00000200  (for 'Import Objects' function. Ref#14273)
	-- fldrmanagerlist(folder)
	--AUTHID_FOLDER_SUBFOLDER_CREATE		0x00000010
	--AUTHID_FOLDER_SUBFOLDER_DELETE		0x00000020
	--AUTHID_FOLDER_SUBFOLDER_MODIFY		0x00000040
	insert into fldrmemberlist ( svrid, fldrid, memberid, type, isexclude, disporder, auth, name )
	values ( i_svrid, i_projectid, l_prjrole_prjmanager, 'A', 'F', 101, 9, 'Project Manager');
	insert into fldrmemberlist ( svrid, fldrid, memberid, type, isexclude, disporder, auth, name )
	values ( i_svrid, i_projectid + 1, l_prjrole_prjmanager, 'A', 'F', 101, 3955, 'Project Manager');
	insert into fldrmemberlist ( svrid, fldrid, memberid, type, isexclude, disporder, auth, name )
	values ( i_svrid, i_projectid + 2, l_prjrole_prjmanager, 'A', 'F', 101, 3955, 'Project Manager');

	insert into fldrmanagerlist ( svrid, fldrid, managerid, disporder, auth, name )
	values ( i_svrid, i_projectid, l_prjrole_prjmanager, 101, 640, 'Project Manager');
	insert into fldrmanagerlist ( svrid, fldrid, managerid, disporder, auth, name )
	values ( i_svrid, i_projectid + 1, l_prjrole_prjmanager, 101, 112, 'Project Manager');
	insert into fldrmanagerlist ( svrid, fldrid, managerid, disporder, auth, name )
	values ( i_svrid, i_projectid + 2, l_prjrole_prjmanager, 101, 112, 'Project Manager');

	--Designer
	-- fldrmemberlist (project)
	--AUTHID_FOLDER_VIEW					0x00000001
	-- fldrmemberlist (folder)
	--AUTHID_FOLDER_VIEW					0x00000001
	--AUTHID_FOLDER_CONTENTS_VIEW			0x00000002
	--AUTHID_ITEM_VIEW						0x00000100
	--AUTHID_ITEM_CREATE					0x00000200
	--AUTHID_ITEM_DELETE					0x00000400
	--AUTHID_ITEM_MODIFY					0x00000800
	-- fldrmanagerlist
	--AUTHID_FOLDER_SUBFOLDER_CREATE		0x00000010
	--AUTHID_FOLDER_SUBFOLDER_DELETE		0x00000020
	--AUTHID_FOLDER_SUBFOLDER_MODIFY		0x00000040
	insert into fldrmemberlist ( svrid, fldrid, memberid, type, isexclude, disporder, auth, name )
	values ( i_svrid, i_projectid, l_prjrole_deginer, 'A', 'F', 101, 1, 'Designer');
	insert into fldrmemberlist ( svrid, fldrid, memberid, type, isexclude, disporder, auth, name )
	values ( i_svrid, i_projectid + 1, l_prjrole_deginer, 'A', 'F', 101, 3843, 'Designer');
	insert into fldrmemberlist ( svrid, fldrid, memberid, type, isexclude, disporder, auth, name )
	values ( i_svrid, i_projectid + 2, l_prjrole_deginer, 'A', 'F', 101, 3843, 'Designer');

	insert into fldrmanagerlist ( svrid, fldrid, managerid, disporder, auth, name )
	values ( i_svrid, i_projectid + 1, l_prjrole_deginer, 101, 112, 'Designer');
	insert into fldrmanagerlist ( svrid, fldrid, managerid, disporder, auth, name )
	values ( i_svrid, i_projectid + 2, l_prjrole_deginer, 101, 112, 'Designer');

	--Publisher
	--AUTHID_FOLDER_VIEW					0x00000001
	--AUTHID_FOLDER_CONTENTS_VIEW			0x00000002
	--AUTHID_ITEM_PUBLISH					0x08000000
	insert into fldrmemberlist ( svrid, fldrid, memberid, type, isexclude, disporder, auth, name )
	values ( i_svrid, i_projectid, l_prjrole_publisher, 'A', 'F', 101, 1, 'Publisher');
	insert into fldrmemberlist ( svrid, fldrid, memberid, type, isexclude, disporder, auth, name )
	values ( i_svrid, i_projectid + 1, l_prjrole_publisher, 'A', 'F', 101, 134217731, 'Publisher');
	insert into fldrmemberlist ( svrid, fldrid, memberid, type, isexclude, disporder, auth, name )
	values ( i_svrid, i_projectid + 2, l_prjrole_publisher, 'A', 'F', 101, 134217731, 'Publisher');

	--Guest
	--AUTHID_FOLDER_VIEW					0x00000001
	--AUTHID_FOLDER_CONTENTS_VIEW			0x00000002
	--AUTHID_ITEM_VIEW						0x00000100
	insert into fldrmemberlist ( svrid, fldrid, memberid, type, isexclude, disporder, auth, name )
	values ( i_svrid, i_projectid, l_prjrole_guest, 'A', 'F', 101, 1, 'Guest');
	insert into fldrmemberlist ( svrid, fldrid, memberid, type, isexclude, disporder, auth, name )
	values ( i_svrid, i_projectid + 1, l_prjrole_guest, 'A', 'F', 101, 259, 'Guest');
	insert into fldrmemberlist ( svrid, fldrid, memberid, type, isexclude, disporder, auth, name )
	values ( i_svrid, i_projectid + 2, l_prjrole_guest, 'A', 'F', 101, 259, 'Guest');

exception
    --when paramnotenough then
    --    raise_application_error(-20505, errm);
    when others then
        raise_application_error(-20742, sqlerrm);
end;
/
