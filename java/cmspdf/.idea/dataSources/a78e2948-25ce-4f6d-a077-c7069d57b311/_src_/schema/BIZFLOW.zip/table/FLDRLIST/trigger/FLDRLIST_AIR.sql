CREATE TRIGGER BIZFLOW.FLDRLIST_AIR
AFTER INSERT
  ON BIZFLOW.FLDRLIST
  DECLARE
	cnt					integer;
	l_descorder			number;
	l_id				number;
	l_parentid			number;
	l_transactionid		varchar2(50);
	l_parentname		varchar2(100);
	l_inherittype		char(1);
	l_userflag			char(1);
	l_mngflag			char(1);
	l_path				varchar(500);
	parentiderror		exception;

-- 12.4.0.0
BEGIN
    select DBMS_TRANSACTION.LOCAL_TRANSACTION_ID into l_transactionid from dual;

	l_id := 0;
	select count(1) into cnt from hwtemp where tmpkey = l_transactionid;

	if (cnt > 0) then
		select vara into l_id from hwtemp where tmpkey = l_transactionid;
		--dbms_output.put_line('fldrlist_air inserted = ' || l_transactionid || ', ' || l_id);

		l_userflag := 'T';
		l_mngflag  := 'T';

		select parentfldrid, inherittype, name into
			   l_parentid, l_inherittype, l_path
		  from fldrlist
		 where fldrid = l_id;

		l_descorder := 1;
		l_path := '/' || l_path;

		while (l_parentid <> 0) loop
			if (l_userflag = 'T') then
				if (l_inherittype <> 'B' and l_inherittype <> 'U') then
					l_userflag := 'F';
				end if;
			end if;
			if (l_mngflag = 'T') then
				if (l_inherittype <> 'B' and l_inherittype <> 'M') then
					l_mngflag := 'F';
				end if;
			end if;

			insert into parentfldr(fldrid, parentfldrid, dirty, usrinherit, mnginherit)
			values (l_id, l_parentid, 'F', l_userflag, l_mngflag);

			select parentfldrid, inherittype, name into
				   l_parentid, l_inherittype, l_parentname
			  from fldrlist
			 where fldrid = l_parentid;

			l_descorder := l_descorder + 1;
			if (l_descorder > 50) then
				raise parentiderror;
			end if;

			l_path := '/' || l_parentname || l_path;
		end loop;

		insert into parentfldr(fldrid, parentfldrid, dirty, usrinherit, mnginherit)
		values (l_id, l_id, 'F', 'T', 'T');

		update fldrlist set fldrpath = l_path where fldrid = l_id;

		delete from hwtemp where tmpkey = l_transactionid;
	end if;

EXCEPTION
    when parentiderror then
        raise_application_error(-20819, 'Invalid parent fldrid.');
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20938, SQLERRM);
END;
/
