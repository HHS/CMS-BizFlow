CREATE procedure		   sp_check_proc_dead
   (
	 i_svrid in	varchar2,
	 i_procid in number,
	 o_value out number)	-- (o_value == 1) means 'stopped'
   is
--
-- 12.4.0.0
--
--   l_notdead_endact_cnt	number(10);
   l_run_act_cnt		number(10);
   l_proc_state			char;
   l_proc_cnt			number(10);
   -- declare program variables	as shown above

begin
	o_value := 0;
	select count(*)	into l_proc_cnt	from procs
								where svrid	= i_svrid
									and	procid = i_procid;
	if l_proc_cnt =	0 then
		return;				-- If the process instace were already deleted,	ignore ...
	end	if;

	select state into l_proc_state from	procs
								where svrid	= i_svrid
									and	procid = i_procid for update;

	if l_proc_state	not	in ('A', 'T', 'C') then

		-- Get counts from Act which is	running	state.
		select count(*)	into l_run_act_cnt
								  from act
								 where svrid = i_svrid
								   and procid =	i_procid
								   and state in	('N', 'R', 'E',	'V', 'S', 'W');
		if l_run_act_cnt > 0 then
		-- Get counts from Act which is	not	dead state.
			if l_proc_state	= 'D' then
				update procs set state = 'R' where svrid = i_svrid
											   and procid =	i_procid;
			end	if;
			return;
		else
			update procs set state = 'D' where svrid = i_svrid
										   and procid =	i_procid;
			o_value	:= 1;
			return;
		end	if;

--		-- Get counts from Act which is	not	dead and type is 'end'.
--		select count(*)	into l_notdead_endact_cnt
--								  from act
--								 where svrid = i_svrid
--								   and procid =	i_procid
--								   and type	= 'E'
--								   and state <>	'D';
--
--		-- If the Procs	have all dead state, then dead mark.
--		  if l_notdead_endact_cnt =	0 then
--			  update procs set state = 'D' where svrid = i_svrid
--										   and procid =	i_procid;
--		end	if;
--
	end	if;

exception
	when others	then
		raise_application_error(-20701,	sqlerrm);
end; --	procedure
/
