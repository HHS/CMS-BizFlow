CREATE TRIGGER BIZFLOW.FLDRLIST_BIR
BEFORE INSERT
  ON BIZFLOW.FLDRLIST
FOR EACH ROW
  DECLARE
	l_transactionid		varchar2(50);

-- 12.4.0.0
BEGIN

	-- Pass key to fldrlist_air
    select DBMS_TRANSACTION.LOCAL_TRANSACTION_ID into l_transactionid from dual;

	insert into hwtemp (tmpkey, vara)
	values (l_transactionid, :new.fldrid);
	--dbms_output.put_line('fldrlist_bir inserted = ' || l_transactionid || ', ' || :new.fldrid);

EXCEPTION
	WHEN OTHERS THEN
		RAISE_APPLICATION_ERROR(-20936, SQLERRM);
END;
/
