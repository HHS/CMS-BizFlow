CREATE FUNCTION fn_get_designee(
    i_memberid IN VARCHAR2,
    i_current_time IN VARCHAR2)
RETURN designee_type_coll
AS
    designee designee_type_coll;
    l_current_time DATE;
-- 12.4.0.0
BEGIN
    IF (i_current_time IS NULL) THEN
        l_current_time := getutcdate();
    ELSE
        l_current_time := TO_DATE(i_current_time, 'yyyy/mm/dd HH24:MI:SS');
    END IF;

    SELECT designee_type(v.memberid, v.prtcptype, v.issurrogater)
      BULK COLLECT INTO designee
      FROM (SELECT memberid,
                   prtcptype,
                   issurrogater
              FROM vmyprtcp
             START WITH prtcp = i_memberid
               AND issurrogater = 'F'
           CONNECT BY prtcp = PRIOR memberid
               AND issurrogater = 'T'
               AND absstartdtime <= l_current_time
               AND absenddtime > l_current_time
           ) v;
    RETURN designee;
END;
/
