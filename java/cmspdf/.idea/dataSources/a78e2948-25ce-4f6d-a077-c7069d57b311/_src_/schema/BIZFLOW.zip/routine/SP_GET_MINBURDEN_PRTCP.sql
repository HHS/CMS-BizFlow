CREATE procedure          sp_get_minburden_prtcp
   (i_prtcptype in char,
   	i_prtcp in varchar2,
    o_nprtcp out varchar2)
   is
--
-- 12.4.0.0
--

cursor cur_get_member (l_deptid varchar2) is
				select memberid
					from member
				  		where deptid = l_deptid
							and type = 'U'
							and state in ('N', 'L');

cursor cur_get_grp_prtcp (l_usrgrpid varchar2) is
				select u.prtcp
					from usrgrpprtcp u, member m
						where u.usrgrpid = l_usrgrpid
							and u.prtcptype = 'U'
							and m.memberid = u.prtcp
							and m.state in ('N', 'L');
l_owitemcnt	number := 0;
l_nwitemcnt number;
l_memberid	varchar2(10);

begin
	o_nprtcp := '';

	if i_prtcptype = 'D' then

		open cur_get_member(i_prtcp);

		loop
			fetch cur_get_member into l_memberid;
			exit when cur_get_member%notfound;

			select count(*) into l_nwitemcnt from witem
				where prtcp = l_memberid
					and state in ('I', 'R', 'V', 'S', 'P');
			if l_nwitemcnt = 0 then
				o_nprtcp := l_memberid;
				close cur_get_member;
				return;
			elsif l_owitemcnt = 0 then
				o_nprtcp := l_memberid;
				l_owitemcnt := l_nwitemcnt;
			elsif l_nwitemcnt < l_owitemcnt then
				o_nprtcp := l_memberid;
				l_owitemcnt := l_nwitemcnt;
			end if;
		end loop;
		close cur_get_member;

	elsif i_prtcptype in ('G', 'R') then

		open cur_get_grp_prtcp(i_prtcp);

		loop
			fetch cur_get_grp_prtcp into l_memberid;
			exit when cur_get_grp_prtcp%notfound;

			select count(*) into l_nwitemcnt from witem
				where prtcp = l_memberid
					and state in ('I', 'R', 'V', 'S', 'P');
			if l_nwitemcnt = 0 then
				o_nprtcp := l_memberid;
				close cur_get_grp_prtcp;
				return;
			elsif l_owitemcnt = 0 then
				o_nprtcp := l_memberid;
				l_owitemcnt := l_nwitemcnt;
			elsif l_nwitemcnt < l_owitemcnt then
				o_nprtcp := l_memberid;
				l_owitemcnt := l_nwitemcnt;
			end if;
		end loop;
		close cur_get_grp_prtcp;

	end if;

exception
    when others then
        if cur_get_member%isopen then
            close cur_get_member;
        end if;
        if cur_get_grp_prtcp%isopen then
            close cur_get_grp_prtcp;
        end if;
        raise_application_error(-20715, sqlerrm);

end; -- procedure sp_get_asmin_prtcp
/
