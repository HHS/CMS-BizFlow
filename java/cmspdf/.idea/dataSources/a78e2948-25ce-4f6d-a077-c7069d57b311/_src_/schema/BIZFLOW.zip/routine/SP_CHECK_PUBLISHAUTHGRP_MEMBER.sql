CREATE procedure                  sp_check_publishauthgrp_member
(
	i_svrid			in	fldrlist.svrid%type default null,
	i_projectid		in	fldrlist.fldrid%type default null,
	i_projectroleid	in	member.memberid%type default null,
	i_prtcpid		in  usrgrpprtcp.prtcp%type default null
)
IS
--
-- 12.4.0.0
--
	cursor cur_get_member_by_roleid (i_id varchar2) is
		select prtcp from usrgrpprtcp
			where usrgrpid = i_id;
	cursor cur_get_member_by_projectid (i_id2 number) is
		select distinct prtcp from usrgrpprtcp
			where usrgrpid  in
			(
				select b.memberid from fldrlist a, fldrmemberlist b
				where
				a.fldrid = b.fldrid
				and a.prjid = i_id2
			);
	l_prtcpid					varchar2(10);
	l_publish_authgroup_id		varchar2(10);
	l_cnt						number(10);
	l_loop						char(1);
BEGIN

	if i_prtcpid is not null then
		select count(1) into l_cnt from member where memberid = i_prtcpid;
		if l_cnt > 0 then
			l_loop := 'N';
			l_prtcpid := i_prtcpid;
		else
			return;
		end if;
	else
		if i_projectroleid is not null then
			select count(1) into l_cnt from member where memberid = i_projectroleid;
			if l_cnt > 0 then
				open cur_get_member_by_roleid(i_projectroleid);
				l_loop := 'Y';
			else
				return;
			end if;
		else
			open cur_get_member_by_projectid(i_projectid);
			l_loop := 'Y';
		end if;
	end if;

	select memberid into l_publish_authgroup_id
		from member
		where name = '_' || trim(to_char(i_projectid)) || '_publication'
			and deptid = i_projectid
			and type = 'A';

	loop
		if l_loop = 'Y' then
			if i_projectroleid is not null then
				fetch cur_get_member_by_roleid into l_prtcpid;
				exit when cur_get_member_by_roleid%NOTFOUND;
			else
				fetch cur_get_member_by_projectid into l_prtcpid;
				exit when cur_get_member_by_projectid%NOTFOUND;
			end if;
		end if;

		select
			count(*) into l_cnt
		from
			usrgrpprtcp u, fldrmemberlist fm, fldrlist f
		where
			u.prtcp = l_prtcpid
			and u.usrgrpid = fm.memberid
			and fm.fldrid = f.fldrid
			and f.prjid = i_projectid
			and bitand(fm.auth, 134217728) > 0;
		if ((l_loop = 'N' and i_projectroleid is null) or l_cnt = 0) then
			delete from usrgrpprtcp
				where usrgrpid = l_publish_authgroup_id
					and prtcp = l_prtcpid;
		else
			select
				count(*) into l_cnt
			from
				usrgrpprtcp
			where
				usrgrpid = l_publish_authgroup_id
				and prtcp = l_prtcpid;

			if l_cnt = 0 then
				insert into usrgrpprtcp (usrgrpid, prtcp, prtcptype, disporder, usrgrphid)
					values (l_publish_authgroup_id, l_prtcpid, 'U', 100, i_projectid);
			end if;
		end if;

		if l_loop = 'N' then
			return;
		end if;

	end loop;
	if l_loop = 'Y' then
		if i_projectroleid is not null then
			close cur_get_member_by_roleid;
		else
			close cur_get_member_by_projectid;
		end if;
	end if;
exception
    when others then
        raise_application_error(-20742, sqlerrm);
end;
/
