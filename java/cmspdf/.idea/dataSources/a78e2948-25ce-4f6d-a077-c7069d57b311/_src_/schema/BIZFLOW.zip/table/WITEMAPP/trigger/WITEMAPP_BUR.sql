CREATE TRIGGER BIZFLOW.WITEMAPP_BUR
BEFORE UPDATE
  ON BIZFLOW.WITEMAPP
FOR EACH ROW WHEN (FOR EACH ROW )
BEGIN
    DELETE FROM appcheckout WHERE svrid = :new.svrid
                            AND procid = :new.procid
                            AND mapid = :new.mapid
                            AND prtcp = :new.prtcp;

EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20915, SQLERRM);
END;
/
