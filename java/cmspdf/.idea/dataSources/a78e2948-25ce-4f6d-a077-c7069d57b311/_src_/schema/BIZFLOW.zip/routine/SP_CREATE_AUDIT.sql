CREATE PROCEDURE SP_CREATE_AUDIT
   (pOBJTYPE        IN      AUDITINFO.OBJTYPE%TYPE DEFAULT NULL,
    pEVENT          IN      AUDITINFO.EVENT%TYPE DEFAULT NULL,
    pDTIME          IN      VARCHAR2 DEFAULT NULL,
    pACTOR          IN      AUDITINFO.ACTOR%TYPE DEFAULT NULL,
    pSVRID          IN      PROCS.SVRID%TYPE DEFAULT NULL,
    pPROCID         IN      PROCS.PROCID%TYPE DEFAULT NULL,
    pACTSEQ         IN      ACT.ACTSEQ%TYPE DEFAULT NULL,
    pWITEMSEQ       IN      WITEM.WITEMSEQ%TYPE DEFAULT NULL,
    pWITEMAPPSEQ    IN      WITEMAPP.WITEMAPPSEQ%TYPE DEFAULT NULL,
    pEVENTERRCODE	IN      AUDITINFO.ERRNO%TYPE DEFAULT 0,
	pREALUSRLOGINID	IN      MEMBER.LOGINID%TYPE DEFAULT NULL,
	pOBJNAME	IN	AUDITINFO.OBJNAME%TYPE DEFAULT NULL,
	pDESCRIPTION	IN	AUDITINFO.OBJDSCPT%TYPE DEFAULT NULL)
   IS
--
-- 12.4.0.0
--
    PARAMNOTENOUGH          EXCEPTION;

    nEXECSEQ                NUMBER(10);
    ERRM                    VARCHAR2(800);
    nerrno                  number;
	l_RealUsrLoginID			VARCHAR2(100);

BEGIN
    IF (pOBJTYPE IS NULL) OR (pEVENT IS NULL)   OR
       (pDTIME IS NULL)   OR (pSVRID IS NULL)   OR (pPROCID IS NULL) THEN
        ERRM := 'Argument is missing.';
        raise paramnotenough;
    end if;

	-- bug18880
	l_RealUsrLoginID := '';
	IF pREALUSRLOGINID is not NULL THEN
		l_RealUsrLoginID := ' [' || pREALUSRLOGINID || ']';
	END IF;

    -- common
    select hws_audit.nextval
      into nexecseq
      from dual;

    if pobjtype = 'P' then
        -- process instance
        insert into auditinfo
        (svrid, procid, execseq, event, actor, actorname, execdtime,
         objtype, objname, objdscpt, objstate, objseq, witemappseq,
         appname, resp, respgrpseq, respseq, errno)
        select a.svrid, a.procid, nexecseq, pevent, pactor, b.name || l_RealUsrLoginID, to_date(ltrim(rtrim(pdtime)), 'YYYY/MM/DD HH24:MI:SS'),
               pobjtype, NVL(pOBJNAME, a.name), NVL(pDESCRIPTION, a.dscpt), a.state, null, null,
               null, null, null, null, peventerrcode
          from procs a, member b
         where a.svrid = psvrid
           and a.procid = pprocid
           and b.memberid = pactor;
    elsif pobjtype = 'A' then
        -- activity
        insert into auditinfo
        (svrid, procid, execseq, event, actor, actorname, execdtime,
         objtype, objname, objdscpt, objstate, objseq, witemappseq,
         appname, resp, respgrpseq, respseq, errno)
        select a.svrid, a.procid, nexecseq, pevent, pactor, b.name || l_RealUsrLoginID, to_date(ltrim(rtrim(pdtime)), 'YYYY/MM/DD HH24:MI:SS'),
               pobjtype, a.name, a.dscpt, a.state, a.actseq, null,
               null, null, null, null, peventerrcode
          from act a, member b
         where a.svrid = psvrid
           and a.procid = pprocid
           and a.actseq = pactseq
           and b.memberid = pactor;
    elsif pobjtype = 'W' then
        if pwitemappseq = 0 then
            -- work item
            insert into auditinfo
            (svrid, procid, execseq, event, actor, actorname, execdtime,
             objtype, objname, objdscpt, objstate, objseq, witemappseq,
             appname, resp, respgrpseq, respseq, errno)
            select a.svrid, a.procid, nexecseq, pevent, pactor, b.name || l_RealUsrLoginID, to_date(pdtime, 'YYYY/MM/DD HH24:MI:SS'),
                   pobjtype, c.name, c.dscpt, a.state, a.witemseq, null,
                   null, d.name, c.respgrpseq, a.respseq, peventerrcode
              from witem a, member b, act c, resp d
             where a.svrid = psvrid
               and a.procid = pprocid
               and a.witemseq = pwitemseq
               and b.memberid = pactor
               and c.svrid = a.svrid
               and c.procid = a.procid
               and c.actseq = a.actseq
               and d.svrid(+) = a.svrid
               and d.procid(+) = a.procid
               and d.respgrpseq(+) = a.respgrpseq
               and d.respseq(+) = a.respseq;
        else
            insert into auditinfo
            (svrid, procid, execseq, event, actor, actorname, execdtime,
             objtype, objname, objdscpt, objstate, objseq, witemappseq,
             appname, resp, respgrpseq, respseq, errno)
            select a.svrid, a.procid, nexecseq, pevent, pactor, b.name || l_RealUsrLoginID, to_date(pdtime, 'YYYY/MM/DD HH24:MI:SS'),
                   pobjtype, c.name, c.dscpt, a.state, a.witemseq, pwitemappseq,
                   e.name, null, null, null, peventerrcode
              from witem a, member b, act c, witemapp d, procapp e
             where a.svrid = psvrid
               and a.procid = pprocid
               and a.witemseq = pwitemseq
               and b.memberid = pactor
               and c.svrid = a.svrid
               and c.procid = a.procid
               and c.actseq = a.actseq
               and d.svrid = a.svrid
               and d.procid = a.procid
               and d.witemseq = a.witemseq
               and d.witemappseq = pwitemappseq
               and e.svrid = d.svrid
               and e.procid = d.procid
               and e.procappseq = d.procappseq;
        end if;
    elsif pobjtype = 'R' then
        -- process variable
        insert into auditinfo
        (svrid, procid, execseq, event, actor, actorname, execdtime,
         objtype, objname, objdscpt, objstate, objseq, witemappseq,
         appname, resp, respgrpseq, respseq, errno)
        select b.svrid, pprocid, nexecseq, pevent, pactor, b.name || l_RealUsrLoginID, to_date(pdtime, 'YYYY/MM/DD HH24:MI:SS'),
               pobjtype, NVL(pobjname, ' '), pdescription, ' ', null, null,
               null, null, null, null, peventerrcode
          from member b
         where b.memberid = pactor;
    elsif pobjtype = 'C' then
        -- comment
        if pwitemseq <> 0 then
            insert into auditinfo
            (svrid, procid, execseq, event, actor, actorname, execdtime,
             objtype, objname, objdscpt, objstate, objseq, witemappseq,
             appname, resp, respgrpseq, respseq, errno)
            select a.svrid, a.procid, nexecseq, pevent, pactor, b.name || l_RealUsrLoginID, to_date(pdtime, 'YYYY/MM/DD HH24:MI:SS'),
                   pobjtype, a.name, pdescription, ' ', pactseq, null,
                   null, null, null, null, peventerrcode
              from witem w, act a, member b
             where w.svrid = psvrid
               and w.procid = pprocid
               and w.witemseq = pwitemseq
               and w.svrid = a.svrid
               and w.procid = a.procid
               and w.actseq = a.actseq
               and b.memberid = pactor;
        else
            insert into auditinfo
            (svrid, procid, execseq, event, actor, actorname, execdtime,
             objtype, objname, objdscpt, objstate, objseq, witemappseq,
             appname, resp, respgrpseq, respseq, errno)
            select b.svrid, pprocid, nexecseq, pevent, pactor, b.name || l_RealUsrLoginID, to_date(pdtime, 'YYYY/MM/DD HH24:MI:SS'),
                   pobjtype, ' ', pdescription, ' ', pactseq, null,
                   null, null, null, null, peventerrcode
              from member b
             where b.memberid = pactor;
        end if;
    else
        errm := 'Can''t recognize the Object Type.';
        raise paramnotenough;
    end if;

exception
    when paramnotenough then
        raise_application_error(-20505, errm);
    when others then
        raise_application_error(-20707, sqlerrm);
end;
/
