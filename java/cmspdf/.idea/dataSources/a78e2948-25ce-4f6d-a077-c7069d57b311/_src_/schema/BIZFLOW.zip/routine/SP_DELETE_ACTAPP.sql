CREATE procedure sp_delete_actapp
  (
     i_svrid  in varchar2,
     i_procid in number
  )
is
--
-- 12.4.0.0
--
begin
    delete from actapp a
     where a.svrid = i_svrid
       and a.procid = i_procid
       and exists (select * from procapp b where b.svrid = a.svrid
                   and b.procid = a.procid
                   and b.procappseq = a.procappseq
                   and b.keepingflag = 'F');
exception
    when others then
        raise_application_error(-20710, sqlerrm);
end;
/
