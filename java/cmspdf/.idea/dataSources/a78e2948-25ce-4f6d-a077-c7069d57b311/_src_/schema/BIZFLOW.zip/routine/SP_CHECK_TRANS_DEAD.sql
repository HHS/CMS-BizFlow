CREATE procedure          sp_check_trans_dead
   (
     i_svrid in varchar2,
     i_procid in number,
     i_actseq in number,
     o_value out number)
   is
--
-- 12.4.0.0
--
   l_tot_trans_cnt      number(10);
   l_max_loop_cnt		number(10);
   l_dead_trans_cnt		number(10);
   l_act_state			char;
   l_act_jointype		char;
   l_processed_trans_cnt number(10);
   -- declare program variables as shown above

begin
    select jointype into l_act_jointype from act
     where svrid = i_svrid
       and procid = i_procid
       and actseq = i_actseq;

	-- lock to Act table for state column evaluation.
    select state into l_act_state from act
                                where svrid = i_svrid
                                    and procid = i_procid
                                    and actseq = i_actseq for update;

	-- Do not DEAD marking which is running state activity.
	if l_act_state = 'R'
	  or l_act_state = 'V' then
		o_value := 0;
		return;
	end if;

	-- Counts and evaluate Max loopcnt from all Act input transactions.
	select count(*), max(loopcnt) into l_tot_trans_cnt, l_max_loop_cnt
   	                      from trans
       	                 where svrid = i_svrid
           	               and procid = i_procid
               	           and tonode = i_actseq
                       	   and type in ('N', 'E', 'D', 'V');

	-- Get counts from all Act input transactions which has dead state.
   	select count(*) into l_dead_trans_cnt
       	                      from trans a
           	                 where a.svrid = i_svrid
               	               and a.procid = i_procid
                   	           and a.tonode = i_actseq
							   and a.loopcnt = l_max_loop_cnt
                       	       and a.state = 'D'
                           	   and a.type in ('N', 'E', 'D', 'V');

	-- Add by Kim Kwang Kean (for PARALLEL Gateway)
	if l_act_jointype = 'P' then
	    -- 02/28/2008 Requested by Kyungwon Kim: Hynix related issue
--		-- Do not DEAD marking which is PARALLEL gateway.
--		-- PARALLEL Gateway is always false.
--		o_value := 0;

        select count(1) into l_processed_trans_cnt
          from trans a, act b
         where b.svrid = a.svrid
		   and b.procid = a.procid
		   and b.actseq = a.fromnode
		   and a.svrid = i_svrid
           and a.procid = i_procid
           and a.tonode = i_actseq
           and a.loopcnt = l_max_loop_cnt
           and a.state not in ('E', '?')
           and a.type in ('N', 'E', 'D', 'V');

		if l_dead_trans_cnt > 0
		   and l_processed_trans_cnt = l_tot_trans_cnt then
			o_value := 1;
		else
			o_value := 0;
		end if;
	else
    		-- if all state is dead, then return true.
		if l_dead_trans_cnt = l_tot_trans_cnt then
			o_value := 1;
		else
			o_value := 0;
		end if;
	end if;

exception
    when others then
        raise_application_error(-20703, sqlerrm);
end; -- procedure
/
