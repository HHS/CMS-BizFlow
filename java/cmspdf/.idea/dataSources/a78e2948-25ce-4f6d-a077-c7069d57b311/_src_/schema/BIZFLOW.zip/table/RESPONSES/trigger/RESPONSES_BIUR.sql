CREATE TRIGGER BIZFLOW.RESPONSES_BIUR
BEFORE INSERT OR UPDATE
  ON BIZFLOW.RESPONSES
FOR EACH ROW
  BEGIN
	if :new.AssigneeResponse is null then
		:new.AssigneeResponseDate := null;
	else
		:new.AssigneeResponseDate := getutcdate();
	end if;

	if :new.InitiatorResponse is null then
		:new.InitiatorResponseDate := null;
	else
		:new.InitiatorResponseDate := getutcdate();
	end if;
END;
/
