CREATE function		 fn_get_customattrvalue
  ( i_procid IN number,
	i_actseq IN number,
	i_objecttype IN char,
	i_valuetype IN char,
	i_name IN varchar2)
  RETURN  varchar2 IS
	l_value 			varchar2(2000);
	l_revisionid int;
	l_procdefid int;
-- 12.4.0.0
BEGIN
-- i_objecttype = D/A
-- i_valuetype = S/N/D/I/F/U/E

	select revisionid, preprocdefid into l_revisionid, l_procdefid
	  from procs
	 where procid = i_procid;

	IF l_revisionid <> 0 THEN
		IF i_objecttype = 'D' THEN
			select value into l_value from mdata
			 where procid = i_procid
			   and objtype = i_objecttype
			   and valuetype = i_valuetype
			   and name = i_name;
		ELSE
			select value into l_value from mdata
			 where procid = i_procid
			   and objtype = i_objecttype
			   and objseq = i_actseq
			   and valuetype = i_valuetype
			   and name = i_name;
		END IF;
	ELSE
		IF i_objecttype = 'D' THEN
			select value into l_value from mdatadef
			 where procdefid = l_procdefid
			   and objtype = i_objecttype
			   and valuetype = i_valuetype
			   and name = i_name;
		ELSE
			select value into l_value from mdatadef
			 where procdefid = l_procdefid
			   and objtype = i_objecttype
			   and objseq = i_actseq
			   and valuetype = i_valuetype
			   and name = i_name;
		END IF;
	END IF;

	IF i_valuetype in ('S', 'N', 'D', 'I') THEN
		RETURN SUBSTRB(l_value, 1, 100);
	END IF;

	RETURN l_value;
END;
/
