CREATE procedure    sp_get_mymanager_ugh
(
	i_usrgrpid		in	varchar,
	i_membertype	in	varchar,
	i_memberid		in	varchar,
	o_managerid		out	varchar
)   is
--
-- 12.4.0.0
--

	l_usrgrpid		varchar2(10);
	l_managerid		varchar2(10);
	l_membertype	char;

begin
	l_usrgrpid := i_usrgrpid;

	loop
		select managerid into l_managerid
		  from member
		 where memberid = l_usrgrpid;

		if l_managerid is not NULL then
			if l_managerid = '0000000000' then

				select parentdeptid into l_usrgrpid from member
				 where memberid = l_usrgrpid;

			elsif i_membertype = 'U' and l_managerid = i_memberid then

				select parentdeptid into l_usrgrpid from member
				 where memberid = l_usrgrpid;

				-- if type of the parent is hierarchy then exit this loop
				select type into l_membertype from member
				 where memberid = l_usrgrpid;
				if l_membertype = 'H' then
					exit;
				end if;

			else
				exit;
			end if;
		else
			exit;
		end if;
	end loop;

	o_managerid := l_managerid;

exception
	when others then
		raise_application_error(-20738, sqlerrm);
end;
/
