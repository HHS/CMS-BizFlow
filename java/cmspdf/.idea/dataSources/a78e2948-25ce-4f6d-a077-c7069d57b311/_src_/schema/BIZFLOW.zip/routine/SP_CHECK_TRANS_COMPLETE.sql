CREATE PROCEDURE sp_check_trans_complete
   (
     i_svrid in varchar2,
     i_procid in number,
     i_actseq in number,
     i_activetrans in number,
     o_value out number)
   is
--
-- 12.4.0.0
--
   l_tot_trans_cnt            number(10);
   l_max_loop_cnt            number(10);
   l_processed_trans_cnt    number(10);
   l_cmplt_trans_cnt        number(10);
   l_act_jointype            char;
   l_running_act_cnt        number(10);
   l_cmplt_one_trans_cnt    number(10);
   -- declare program variables as shown above

begin

    select jointype into l_act_jointype from act
     where svrid = i_svrid
       and procid = i_procid
       and actseq = i_actseq;

    select count(1) into l_tot_trans_cnt
      from trans a, act b
     where b.svrid = a.svrid
       and b.procid = a.procid
       and b.actseq = a.fromnode
       and a.svrid = i_svrid
       and a.procid = i_procid
       and a.tonode = i_actseq
       and a.type in ('N', 'E', 'D', 'V');

    select count(*) into l_running_act_cnt from act
     where svrid = i_svrid
       and procid = i_procid
       and state in ('R', 'V', 'W');

    select count(*) into l_cmplt_one_trans_cnt from trans
     where svrid = i_svrid
       and procid = i_procid
       and tonode = i_actseq
       and state = 'C'
       and loopcnt > 0;

    l_max_loop_cnt := 1;

    -- Add by Kim Kwang Kean (for OR Gateway), 03-JUL-2006
    if (l_act_jointype = 'A'
		or l_act_jointype = 'R'
		--or l_act_jointype = 'C' -- Promise 87911 : Mod by JungMyungHoon(for Complex Gateway), 05-MAY-2008
		or l_act_jointype = 'P') then

        select count(1) into l_cmplt_trans_cnt
          from trans a, act b
         where b.svrid = a.svrid
		   and b.procid = a.procid
		   and b.actseq = a.fromnode
		   and a.svrid = i_svrid
           and a.procid = i_procid
           and a.tonode = i_actseq
           and a.loopcnt = l_max_loop_cnt
           and a.state = 'C'
           and a.type in ('N', 'E', 'D', 'V');

        select count(1) into l_processed_trans_cnt
          from trans a, act b
         where b.svrid = a.svrid
		   and b.procid = a.procid
		   and b.actseq = a.fromnode
		   and a.svrid = i_svrid
           and a.procid = i_procid
           and a.tonode = i_actseq
           and a.loopcnt = l_max_loop_cnt
           and a.state not in ('E', 'W', '?')
           and a.type in ('N', 'E', 'D', 'V');

        if ((l_tot_trans_cnt = l_processed_trans_cnt and l_cmplt_trans_cnt > 0 ) or
		(l_running_act_cnt = 0 and l_cmplt_one_trans_cnt > 0 and i_activetrans <= 1)) then
			o_value := 1;
        else
            o_value := 0;
        end if;

    else
        select count(1) into l_cmplt_trans_cnt
          from trans a, act b
         where b.svrid = a.svrid
		   and b.procid = a.procid
		   and b.actseq = a.fromnode
		   and a.svrid = i_svrid
           and a.procid = i_procid
           and a.tonode = i_actseq
           and a.loopcnt = l_max_loop_cnt
           and a.state = 'C'
           and a.type in ('N', 'E', 'D', 'V');

        if (l_act_jointype = 'O'
		or l_act_jointype = 'C') then -- Promise 87911 : Add by JungMyungHoon(for Complex Gateway), 05-MAY-2008
            if l_cmplt_trans_cnt > 0 then
                o_value := 1;
            else
                o_value := 0;
            end if;
        -- Modify by Kim Kwang Kean (for Data-based XOR Gateway), 03-JUL-2006
        -- elsif l_act_jointype = 'X' then
        elsif l_act_jointype = 'X' or l_act_jointype = 'D' then
            -- cs14912 ProcessStop cover
            if ((l_cmplt_trans_cnt = 1) or (l_running_act_cnt = 0 and l_cmplt_one_trans_cnt > 0)) then
                o_value := 1;
            else
                o_value := 0;
            end if;
        -- Add by Kim Kwang Kean (for PARALLEL Gateway), 03-JUL-2006
        -- 02/28/2008 Requested by Kyungwon Kim: Hynix related issue
--        elsif l_act_jointype = 'P' then
--            if (l_tot_trans_cnt = l_cmplt_trans_cnt and
--				l_cmplt_trans_cnt > 0) then
--                o_value := 1;
--            else
--                o_value := 0;
--            end if;
        end if;

    end if;

exception
    when others then
        raise_application_error(-20702, sqlerrm);
end; -- procedure
/
