CREATE procedure          sp_check_parentusrgrplist
(
	i_userid   in varchar2,
	i_usrgrpid in varchar2
)
is
--
-- 12.4.0.0
--
	cursor cur_get_member (i_id varchar2) is
	select usrgrpid from vusrgrpprtcp
	 where prtcp = i_id and usrgrptype in ('G','D');

	l_cnt				integer;
	l_dirty_cnt			integer;
	l_grp_cnt			integer;
	l_call_depth		integer;
	l_descorder			integer;
	l_usrgrpid			varchar2(10);
	l_memberid			varchar2(10);
	l_parentmemberid	varchar2(10);
	l_parentname	 	varchar2(100);
	l_memberpath		varchar2(500);
	l_name				varchar2(100);
	l_inherittype		char;
	l_membertype		char;
	l_userflag			char;
	l_mngflag			char;
	l_loop				char;
	deptiderror			exception;
begin
	if i_userid is not null then
		select count(1) into l_cnt from member where memberid = i_userid;
		if l_cnt > 0 then
			open cur_get_member(i_userid);
			l_loop := 'Y';
		else
			return;
		end if;
	else
		select count(1) into l_cnt from member where memberid = i_usrgrpid;
		if l_cnt > 0 then
			l_usrgrpid := i_usrgrpid;
			l_loop := 'N';
		else
			return;
		end if;
	end if;
-- begin -- CS-7129 added by mhjeong on 2005/03/07 (code merged by kkkim on 2005/10/27 KST)
	if l_loop = 'Y' then
		delete from parentmember pm
		where pm.dirty = 'T'
		and exists
		(
			select *
			from vusrgrpprtcp vp
			where vp.prtcp = i_userid
			and vp.usrgrptype in ('G','D')
			and vp.usrgrpid = pm.memberid
		);
	else
		delete from parentmember
		where memberid = l_usrgrpid
		and dirty = 'T';
	end if;
-- end -- CS-7129 added by mhjeong on 2005/03/07 (code merged by kkkim on 2005/10/27 KST)

	loop
		if l_loop = 'Y' then
			fetch cur_get_member into l_usrgrpid;
			exit when cur_get_member%NOTFOUND;
		end if;

		if l_usrgrpid is not null then
-- begin -- CS-7129 deleted by mhjeong on 2005/03/07 (code merged by kkkim on 2005/10/27 KST)
--			select count(1) into l_dirty_cnt from parentmember
--			where memberid = l_usrgrpid
--			  and dirty = 'T';

--			if (l_dirty_cnt > 0) then
--				delete from parentmember where memberid = l_usrgrpid;
--			end if;
-- end -- CS-7129 deleted by mhjeong on 2005/03/07 (code merged by kkkim on 2005/10/27 KST)

			select count(1) into l_grp_cnt from parentmember
			 where memberid = l_usrgrpid;

			if l_grp_cnt = 0 then
				l_userflag := 'T';
				l_mngflag := 'T';

				select memberid, parentdeptid, inherittype, type, name
				  into l_memberid, l_parentmemberid, l_inherittype, l_membertype, l_memberpath
-- begin cs14234: LGE Hot fix(bug18678, cs11970) kwkim 4/9/2007
--				  from member
				  from vusrgrp
-- end cs14234: LGE Hot fix(bug18678, cs11970) kwkim 4/9/2007
				 where memberid = l_usrgrpid;

				l_memberpath := '/' || l_memberpath;

				insert into parentmember (memberid, parentid, type, dirty, usrinherit, mnginherit, descorder)
                values (l_usrgrpid, l_usrgrpid, l_membertype, 'F', l_userflag, l_mngflag, 0);

				l_descorder := 1;
				l_call_depth := 0;
				while (l_parentmemberid <> '0000000000') loop
					if (l_userflag = 'T') then
						if (l_inherittype <> 'B' and l_inherittype <> 'U' and
							l_inherittype <> 'P' and l_inherittype <> 'Q') then
							l_userflag := 'F';
						end if;
					end if;
					if (l_mngflag = 'T') then
						if (l_inherittype <> 'B' and l_inherittype <> 'M' and
							l_inherittype <> 'Q') then
							l_mngflag := 'F';
						end if;
					end if;

					-- CS-8995 added by mhjeong	(code merged by kkkim on 2005/10/27 KST)
					select count(1) into l_cnt FROM parentmember WHERE memberid = l_usrgrpid AND parentid = l_parentmemberid;
					-- CS11129
					if l_cnt > 0 then
						return;
					end if;

					insert into parentmember(memberid, parentid, type, dirty, usrinherit, mnginherit, descorder)
					values (l_usrgrpid, l_parentmemberid, l_membertype, 'F', l_userflag, l_mngflag, l_descorder);

					select memberid, parentdeptid, inherittype, type, name
					  into l_memberid, l_parentmemberid, l_inherittype, l_membertype, l_parentname
-- begin cs14234: LGE Hot fix(bug18678, cs11970) kwkim 4/9/2007
--					  from member
					  from vusrgrp
-- end cs14234: LGE Hot fix(bug18678, cs11970) kwkim 4/9/2007
					 where memberid = l_parentmemberid;

					l_call_depth := l_call_depth + 1;
					l_descorder := l_descorder + 1;
					if l_call_depth > 50 then
						raise deptiderror;
					end if;

					l_memberpath := '/' || l_parentname || l_memberpath;
				end loop;

				update parentmember set memberpath = l_memberpath
					where memberid = l_usrgrpid and parentid = l_usrgrpid;

			end if;
		end if;

		if l_loop = 'N' then
			return;
		end if;

	end loop;

	if l_loop = 'Y' then
		close cur_get_member;
	end if;

exception
	when deptiderror then
		raise_application_error(-20526, 'Invalid parent User Group ID');
	when others then
		raise_application_error(-20737, sqlerrm);
end;
/
