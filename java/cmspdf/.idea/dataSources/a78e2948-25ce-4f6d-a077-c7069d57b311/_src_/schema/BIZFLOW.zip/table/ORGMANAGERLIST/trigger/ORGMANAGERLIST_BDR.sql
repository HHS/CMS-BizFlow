CREATE TRIGGER BIZFLOW.ORGMANAGERLIST_BDR
BEFORE DELETE
  ON BIZFLOW.ORGMANAGERLIST
FOR EACH ROW
  DECLARE
cnt				integer;
l_type			char(1);
l_actor			varchar2(10);
l_actorname		varchar2(100);
l_objid			varchar2(10);
l_objtype			varchar2(50);
l_objname		varchar2(100);
l_manager		varchar2(10);
l_managername	varchar2(100);
l_ipaddr			varchar2(50);
l_event			varchar2(100);
l_nodatafound		boolean;

-- 12.4.0.0
BEGIN
	l_actor :='0000000000';
	l_actorname := 'System';
	l_event := 'ADMINISTRATIVECONTROLREMOVED';
	l_objid := :old.memberid;
	l_manager := :old.managerid;
	l_managername := :old.name;
	l_objtype := '';

	select name, type into l_objname,l_type
	  from member
	 where memberid = :old.memberid;

	if (l_type = 'D')
	then
		l_objtype := 'ORGANIZATIONALUNIT';

		begin
			select o.memberid, o.membername, u.ipaddr
			  into l_actor, l_actorname, l_ipaddr
			  from parentmember p, checkout o, usrsession u
			 where p.memberid = :old.memberid
			   and o.nodeid = p.parentid
			   and o.type = 'O'
			   and u.memberid = o.memberid;
		exception when NO_DATA_FOUND then
			null;
		end;

	elsif (l_type = 'G') then
		l_objtype := 'USERGROUP';

		begin
			select o.memberid, o.membername, u.ipaddr
			  into l_actor, l_actorname, l_ipaddr
			  from parentmember p, checkout o, usrsession u
			 where p.memberid = :old.memberid
			   and o.nodeid = p.parentid
			   and o.type = 'G'
			   and u.memberid = o.memberid;
		exception when NO_DATA_FOUND then
			null;
		end;

	end if;

	if (l_objtype <> '') then
		insert into auditinfoadm (seq, actor, actorname, dtime, event, objid, objtype, objname, ipaddr, detail)
		values (hws_adminaudit.nextval, l_actor, l_actorname, getutcdate(), l_event, l_objid, l_objtype, l_objname, l_ipaddr, l_managername);
	end if;

EXCEPTION
	WHEN OTHERS THEN
		RAISE_APPLICATION_ERROR(-20943, SQLERRM);
END;
/
