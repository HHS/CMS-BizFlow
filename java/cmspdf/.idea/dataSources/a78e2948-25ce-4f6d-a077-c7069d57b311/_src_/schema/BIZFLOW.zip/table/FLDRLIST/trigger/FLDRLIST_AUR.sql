CREATE TRIGGER BIZFLOW.FLDRLIST_AUR
AFTER UPDATE
  ON BIZFLOW.FLDRLIST
  DECLARE
	l_descorder			number;
	l_updated			number;
	l_position			number;
	l_id				number;
	l_childid			number;
	l_parentid			number;
	l_transactionid		varchar2(50);
	l_name				varchar2(100);
	l_parentname		varchar2(100);
	l_inherittype		char(1);
	l_userflag			char(1);
	l_mngflag			char(1);
	l_path				varchar(500);
	l_oldpath			varchar(500);
	l_exist				boolean;
	parentiderror		exception;

	cursor cur_get_updatedid (l_transid varchar2) is
		select vara, varb from hwtemp
		 where tmpkey = l_transid;

	cursor cur_get_children (l_pid varchar2) is
		select fldrid from parentfldr
		 where parentfldrid = l_pid;

-- 12.4.0.0
BEGIN
    select DBMS_TRANSACTION.LOCAL_TRANSACTION_ID into l_transactionid from dual;

	l_id := 0;
	l_updated := 0;
	l_exist := false;

	open cur_get_updatedid(l_transactionid);

	loop
		fetch cur_get_updatedid into l_id, l_updated;
		exit when cur_get_updatedid%notfound;

		l_exist := true;

		--dbms_output.put_line('fldrlist_aur updated = ' || l_transactionid || ', ' || l_id || ', ' || l_updated);
		-- In case that moved
		if (l_updated = 1 or l_updated = 3 or
			l_updated = 5 or l_updated = 7) then

			open cur_get_children(l_id);

			delete from parentfldr
			 where fldrid in (select fldrid from parentfldr
								 where parentfldrid = l_id);

			loop
				fetch cur_get_children into l_childid;
				exit when cur_get_children%notfound;

				l_userflag := 'T';
				l_mngflag  := 'T';

				select parentfldrid, inherittype, name into
					   l_parentid, l_inherittype, l_path
				  from fldrlist
				 where fldrid = l_childid;

				l_descorder := 1;
				l_path := '/' || l_path;

				while (l_parentid <> 0) loop
					if (l_userflag = 'T') then
						if (l_inherittype <>'B'
							and l_inherittype <>'U'
							and l_inherittype <>'P'
							and l_inherittype <>'Q') then
							l_userflag := 'F';
						end if;
					end if;
					if (l_mngflag = 'T') then
						if (l_inherittype <> 'B'
							and l_inherittype <> 'M'
							and l_inherittype <> 'Q') then
							l_mngflag := 'F';
						end if;
					end if;

					insert into parentfldr(fldrid, parentfldrid, dirty, usrinherit, mnginherit)
					values (l_childid, l_parentid, 'F', l_userflag, l_mngflag);

					select parentfldrid, inherittype, name into
						   l_parentid, l_inherittype, l_parentname
					  from fldrlist
					 where fldrid = l_parentid;

					l_descorder := l_descorder + 1;
					if (l_descorder > 50) then
						close cur_get_children;
						close cur_get_updatedid;
						raise parentiderror;
					end if;

					l_path := '/' || l_parentname || l_path;
				end loop;

				insert into parentfldr(fldrid, parentfldrid, dirty, usrinherit, mnginherit)
				values (l_childid, l_childid, 'F', 'T', 'T');

				update fldrlist set fldrpath = l_path where fldrid = l_childid;
			end loop;
			close cur_get_children;

		end if;

		-- In case that inherittype updated
		if (l_updated = 2 or l_updated = 6) then

			open cur_get_children(l_id);

			loop
				fetch cur_get_children into l_childid;
				exit when cur_get_children%notfound;

				l_userflag := 'T';
				l_mngflag  := 'T';

				select parentfldrid, inherittype into
					   l_parentid, l_inherittype
				  from fldrlist
				 where fldrid = l_childid;

				l_descorder := 1;
				while (l_parentid <> 0) loop
					if (l_userflag = 'T') then
						if (l_inherittype <>'B'
							and l_inherittype <>'U'
							and l_inherittype <>'P'
							and l_inherittype <>'Q') then
							l_userflag := 'F';
						end if;
					end if;
					if (l_mngflag = 'T') then
						if (l_inherittype <> 'B'
							and l_inherittype <> 'M'
							and l_inherittype <> 'Q') then
							l_mngflag := 'F';
						end if;
					end if;

					update parentfldr
					   set usrinherit = l_userflag, mnginherit = l_mngflag
					 where fldrid = l_childid
					   and parentfldrid = l_parentid;

					select parentfldrid, inherittype into
						   l_parentid, l_inherittype
					  from fldrlist
					 where fldrid = l_parentid;

					l_descorder := l_descorder + 1;

					if (l_descorder > 50) then
						close cur_get_children;
						close cur_get_updatedid;
						raise parentiderror;
					end if;
				end loop;
			end loop;
			close cur_get_children;
		end if;

		-- In case that name updated
		if (l_updated = 4 or l_updated = 6) then
			select parentfldrid, name, fldrpath
			  into l_parentid, l_name, l_oldpath
			  from fldrlist
			 where fldrid = l_id;

			if (l_parentid <> 0) then
				select fldrpath into l_path
				  from fldrlist
				 where fldrid = l_parentid;

				l_path := l_path || '/' || l_name;
			else
				l_path := '/' || l_name;
			end if;

			l_position := LENGTH(l_oldpath) + 1;

			update fldrlist
			   set fldrpath = l_path || SUBSTR(fldrpath, l_position)
			 where fldrid in (select fldrid from parentfldr
			   					 where parentfldrid = l_id);
		end if;

	end loop;
	close cur_get_updatedid;

	if (l_exist) then
		delete from hwtemp where tmpkey = l_transactionid;
	end if;

EXCEPTION
    when parentiderror then
        raise_application_error(-20819, 'Invalid parent fldrid.');
    WHEN OTHERS THEN
		if cur_get_updatedid%isopen then
		    close cur_get_updatedid;
		end if;
		if cur_get_children%isopen then
		    close cur_get_children;
		end if;
        RAISE_APPLICATION_ERROR(-20939, SQLERRM);
END;
/
