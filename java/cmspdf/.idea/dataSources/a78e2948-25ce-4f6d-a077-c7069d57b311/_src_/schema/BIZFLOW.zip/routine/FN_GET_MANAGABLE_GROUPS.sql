CREATE FUNCTION fn_get_managable_groups(
    i_memberid IN VARCHAR2)
RETURN group_type_coll
AS
    groups group_type_coll;
-- 12.4.0.0
BEGIN
    SELECT group_type(g.childid)
      BULK COLLECT INTO groups
      FROM (SELECT p.parentid,
                   m.memberid AS childid,
                   m.managerid
              FROM member m, parentmember p
        START WITH m.managerid = i_memberid
               AND p.memberid = m.memberid
               AND p.descorder = 1
        CONNECT BY p.parentid = PRIOR m.memberid
               AND p.memberid = m.memberid
               AND p.descorder = 1
               AND (m.managerid = i_memberid or m.managerid = '0000000000')
           ) g;
    RETURN groups;
END;
/
