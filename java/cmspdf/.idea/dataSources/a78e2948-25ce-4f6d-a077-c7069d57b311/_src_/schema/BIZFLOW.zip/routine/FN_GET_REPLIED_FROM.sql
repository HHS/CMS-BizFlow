CREATE function		 fn_get_replied_from
  ( i_procid IN number,
	i_workid IN number)
  RETURN  number IS
	l_value 	int;
-- 12.4.0.0
BEGIN
	select witemseq into l_value
	  from witemti
	 where procid = i_procid
	   and fromseq = i_workid
	   and state = 'J'
	   and rownum = 1
	 order by dtime desc;

	RETURN l_value;
END;
/
