CREATE FUNCTION FN_GETTASKCOMMENTSCNT (IN_TASKID IN NUMBER)
    RETURN NUMBER
IS
    L_RESULTVAR   NUMBER;
-- 12.4.0.0
BEGIN

    SELECT COUNT(1) INTO L_RESULTVAR FROM cmnt c, witem w, act a, Tasks s
        WHERE c.svrid = w.svrid AND c.procid = w.procid AND c.witemseq = w.witemseq
        AND w.svrid = a.svrid AND w.procid = a.procid AND w.actseq = a.actseq
        AND w.actseq = s.actseq
        AND c.type != 'GUIDANCE'
        AND a.procid = s.ProcID AND a.actseq IN (
            select objseq from mdata where ObjType = 'A' AND ObjSubType ='P' AND ValueType='S' AND  procid = s.ProcID AND name = 'taskid' AND value = TO_CHAR( s.TaskID )
        )
        AND LENGTH(c.contents) > 0
        AND s.TaskID = IN_TASKID;

    RETURN L_RESULTVAR;
END;
/
