CREATE function        fn_get_dst_diff
  (	i_memberid IN varchar2,
	i_cur_date IN date)
  RETURN  number IS
   l_dstid			number;
   l_sign			char(1);
   l_timediff		number := 0;
   l_cnt			number;
   l_cur_date		date := i_cur_date;
-- 12.4.0.0
BEGIN

	select dstid into l_dstid from calhead where memberid = i_memberid and dayofweek = '0';
	if l_dstid <> 0 then
		select count(sign) into l_cnt from dst where dstid = l_dstid
										and startdtime <= l_cur_date
										and l_cur_date <= enddtime;
		if l_cnt = 1 then
			select sign, timediff into l_sign, l_timediff from dst
					where dstid = l_dstid
						and startdtime <= l_cur_date
						and l_cur_date <= enddtime;
			if l_sign = '-' then
				l_timediff := l_timediff * (-1);
			end if;
		end if;
	end if;

--dbms_output.put_line('l_timediff = ' || to_char(l_timediff));
    RETURN l_timediff;
END;
/
