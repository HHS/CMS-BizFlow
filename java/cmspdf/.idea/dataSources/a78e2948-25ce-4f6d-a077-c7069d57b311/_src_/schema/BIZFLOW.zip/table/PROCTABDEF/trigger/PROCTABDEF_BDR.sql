CREATE TRIGGER BIZFLOW.PROCTABDEF_BDR
BEFORE DELETE
  ON BIZFLOW.PROCTABDEF
FOR EACH ROW
  DECLARE
    cnt     integer;
    l_transactionid     varchar2(50);
BEGIN
-- 12.4.0.0

    -- To pass key to proctabdef_adr
    SELECT DBMS_TRANSACTION.LOCAL_TRANSACTION_ID INTO l_transactionid FROM dual;

    SELECT count(1) INTO cnt
      FROM hwtemp
     WHERE tmpkey = l_transactionid
       AND vara = :old.orgprocdefid;

    IF cnt = 0 THEN
        INSERT INTO hwtemp (tmpkey, vara) VALUES (l_transactionid, :old.orgprocdefid);
        --dbms_output.put_line('proctabdef_bdr inserted = ' || l_transactionid || ', ' || :old.orgprocdefid);
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20942, SQLERRM);
END;
/
