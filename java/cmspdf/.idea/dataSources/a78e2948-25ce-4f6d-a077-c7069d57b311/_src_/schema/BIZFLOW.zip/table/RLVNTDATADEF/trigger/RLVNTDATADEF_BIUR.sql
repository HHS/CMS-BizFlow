CREATE TRIGGER BIZFLOW.RLVNTDATADEF_BIUR
BEFORE INSERT OR UPDATE
  ON BIZFLOW.RLVNTDATADEF
FOR EACH ROW
  DECLARE
    l_dispname			varchar2(100);
    l_memberid			varchar2(10);
	l_cnt				number;

-- 12.4.0.0
BEGIN

	IF :new.valuetype not in ('A', 'P',	'F', 'Q', 'B', 'X', 'Y') THEN
		:new.dispvalue := null;
	END IF;

    IF :new.value is null THEN
        RETURN;
    END IF;

    IF :new.valuetype = 'A' THEN

		select count(1) into l_cnt from procappdef
						where procdefid = :new.procdefid
						 	and rlvntdatadefseq = :new.rlvntdatadefseq;
		IF l_cnt > 0 THEN
			-- RlvntDataDef does not have EnvType; therefore, you should refer to ProcAppDef.
			-- If a variable is defined without initial value, default EnvType will be 'O' (Operational Env).
			SELECT apt.name INTO l_dispname FROM apptmplt apt, procappdef pad
			 WHERE apt.svrid = pad.svrid
				and apt.envtype = pad.envtype
				and apt.isfinal = 'T'
				and apt.orgappid = to_number(SUBSTR(:new.value, 12, 10))
				and pad.svrid = SUBSTR(:new.value, 1, 10)
				and pad.procdefid = :new.procdefid
				and pad.rlvntdatadefseq = :new.rlvntdatadefseq;
		ELSE
			-- When an array item of definition variable is created dinamically in runtime,
			-- ProcAppDef so far does not exist.
			-- After being downloaded, it should be created by process designer.
			SELECT apt.name INTO l_dispname FROM apptmplt apt
			 WHERE apt.envtype = 'O'
				and apt.isfinal = 'T'
				and apt.orgappid = to_number(SUBSTR(:new.value, 12, 10))
				and apt.svrid = SUBSTR(:new.value, 1, 10);
		END IF;

		:new.dispvalue := l_dispname;

    ELSIF  :new.valuetype = 'P' THEN

        l_memberid := SUBSTR(:new.value, 4, 10);
        SELECT name INTO l_dispname FROM member
            WHERE memberid = l_memberid;

        :new.dispvalue := l_dispname;

    END IF;

	IF :new.scope = 'D' THEN
		update drlvntdataval set dscpt = :new.dscpt
				where rlvntdatadefname = :new.rlvntdatadefname
					and orgprocdefid = (select orgprocdefid from procdef where procdefid = :new.procdefid);
	END IF;

EXCEPTION
   WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20907, SQLERRM);
END;
/
