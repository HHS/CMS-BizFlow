CREATE TRIGGER ACT_BUR
BEFORE UPDATE OF STATE
  ON ACT
FOR EACH ROW WHEN (FOR EACH ROW )
DECLARE
-- 12.4.0.0

l_svrid     varchar2(10);
l_procid    number;
l_respseq   number;
l_respname  varchar2(100);
l_respinfo	number;
l_delim1    varchar2(3);
l_delim2    varchar(1);
l_delim3	varchar(1);
l_tmpstr    varchar2(255);

CURSOR cur_get_respdata (l_svrid varchar2, l_procid number, l_respgrpseq number) is
    SELECT r.respseq, r.name, r.respinfo
    FROM resp r
    WHERE r.svrid = l_svrid
      AND r.procid = l_procid
      AND r.respgrpseq = l_respgrpseq;

BEGIN

    -- cs5663:
    IF :new.startdtime <> :old.startdtime
	   and :new.startdtime > :new.cmpltdtime THEN
		:new.cmpltdtime := null;
    END IF;

    IF :new.state = 'C' THEN

        -- 06/09/03 Caffrey and krlee
        -- added to avoid a bug of 'progress per workitem'
	IF :new.transtype <> 'G' THEN
            UPDATE witem SET state = 'D', loopcnt = :new.loopcnt, onasync = 'F'
             WHERE svrid = :new.svrid
               AND procid = :new.procid
               AND actseq = :new.actseq
               AND state in ('I', 'R', 'V', 'E', 'S', 'P', 'Y')
               AND loopcnt = 0;
        END IF;

        UPDATE witem SET loopcnt = :new.loopcnt
         WHERE svrid = :new.svrid
            AND procid = :new.procid
            AND actseq = :new.actseq
            AND state in ('C', 'A', 'T', 'D', 'W')
            AND loopcnt = 0;

    ELSIF  :new.state = 'R' THEN

        l_delim1 := '~\_';
        l_delim2 := '=';
        l_delim3 := ',';

        :new.resplist := null;
        OPEN cur_get_respdata(:new.svrid, :new.procid, :new.respgrpseq);
        LOOP
            FETCH cur_get_respdata INTO l_respseq, l_respname, l_respinfo;
            EXIT WHEN cur_get_respdata%notfound;

            l_tmpstr := l_respseq || l_delim2 || l_respinfo || l_delim3 || l_respname || l_delim1;

            IF :new.resplist is null
                OR lengthb(:new.resplist) + lengthb(l_tmpstr) < 255 THEN
                :new.resplist := :new.resplist || l_tmpstr;
            ELSE
                EXIT;
            END IF;
        end LOOP;
        CLOSE cur_get_respdata;
    ELSIF  :new.state = 'E' THEN

        UPDATE procs SET state = 'E'
         WHERE svrid = :new.svrid
            AND procid = :new.procid;

    END IF;

EXCEPTION
    WHEN OTHERS THEN
        IF cur_get_respdata%isopen THEN
            CLOSE cur_get_respdata;
        END IF;
        RAISE_APPLICATION_ERROR(-20912, SQLERRM);
END;
/
