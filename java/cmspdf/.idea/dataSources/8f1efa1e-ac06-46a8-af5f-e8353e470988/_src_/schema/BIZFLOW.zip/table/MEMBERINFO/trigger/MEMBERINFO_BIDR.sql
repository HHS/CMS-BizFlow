CREATE TRIGGER MEMBERINFO_BIDR
BEFORE INSERT OR DELETE
  ON MEMBERINFO
FOR EACH ROW
  DECLARE
	cnt				integer;
	l_jobtitleid	varchar2(10);
	invalidjobtitle	EXCEPTION;
	cannotdelete	EXCEPTION;
-- 12.4.0.0
BEGIN
	IF inserting AND :new.memberid <> '0000000000' THEN
		IF :new.ida is not null THEN
			SELECT count(1) INTO cnt
			  FROM jobtitle
			 WHERE jobtitleid = :new.ida;

			IF cnt = 0 THEN
				l_jobtitleid := :new.ida;
				RAISE invalidjobtitle;
			END IF;
		END IF;

		IF :new.idb is not null THEN
			SELECT count(1) INTO cnt
			  FROM jobtitle
			 WHERE jobtitleid = :new.idb;

			IF cnt = 0 THEN
				l_jobtitleid := :new.idb;
				RAISE invalidjobtitle;
			END IF;
		END IF;

		UPDATE member SET memberinfoid = :new.memberid
		WHERE memberid = :new.memberid;

	ELSIF deleting THEN
		IF :old.memberid = '0000000000' THEN
			RAISE cannotdelete;
		END IF;

		UPDATE member SET memberinfoid = '0000000000'
		WHERE memberid = :old.memberid;
	END IF;

EXCEPTION
	WHEN invalidjobtitle THEN
		RAISE_APPLICATION_ERROR(-20807, 'Invalid JobTitleID ' || l_jobtitleid);
	WHEN cannotdelete THEN
		RAISE_APPLICATION_ERROR(-20812, 'Cannot delete MemberID 0000000000.');
	WHEN OTHERS THEN
		RAISE_APPLICATION_ERROR(-20924, SQLERRM);
END;
/
