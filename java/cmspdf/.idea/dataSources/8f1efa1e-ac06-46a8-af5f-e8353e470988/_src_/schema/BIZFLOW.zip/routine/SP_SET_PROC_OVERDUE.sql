CREATE procedure          sp_set_proc_overdue
   (
	 i_presvrdtime in date,
	 i_svrdtime in date)
   is
--
-- 12.4.0.0
--

begin

	update procs set state = 'V'
		where state = 'R'
			and deadlinedtime <= i_svrdtime
			and deadlinedtime > i_presvrdtime;

exception
    when others then
        raise_application_error(-20718, sqlerrm);
end; -- procedure
/
