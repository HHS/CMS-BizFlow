CREATE VIEW V_TASKPRTCPALL AS SELECT taskid, subtaskid, prtcp, type, kind, externaluser FROM taskprtcp WHERE type = 'U'
UNION ALL
select t.taskid, t.subtaskid, p.prtcp, p.prtcptype as type, t.kind, '' as externaluser FROM taskprtcp t, usrgrpprtcp p
WHERE type ='G' AND t.prtcp = p.usrgrpid
UNION ALL
SELECT p.taskid, p.subtaskid, v.memberid as prtcp, 'U', p.kind, '' as externaluser FROM taskprtcp p, vmyprtcp v
WHERE p.prtcp = v.prtcp
  AND  v.issurrogater = 'T' AND v.prtcptype in ('U', 'G')
  and v.absstartdtime <=  SYS_EXTRACT_UTC (CURRENT_TIMESTAMP)
  and v.absenddtime > SYS_EXTRACT_UTC (CURRENT_TIMESTAMP)
UNION ALL
SELECT taskid, subtaskid, prtcp, type, kind, externaluser FROM completetaskprtcp
UNION ALL
SELECT t.taskid, t.subtaskid, p.prtcp, p.prtcptype as type, t.kind, '' as externaluser FROM completetaskprtcp t, usrgrpprtcp p
WHERE type ='G' AND t.prtcp = p.usrgrpid
UNION ALL
SELECT p.taskid, p.subtaskid, v.memberid as prtcp, 'U', p.kind, '' as externaluser FROM completetaskprtcp p, vmyprtcp v
WHERE p.prtcp = v.prtcp
  AND  v.issurrogater = 'T' AND v.prtcptype in ('U', 'G')
  and v.absstartdtime <=  SYS_EXTRACT_UTC (CURRENT_TIMESTAMP)
  and v.absenddtime > SYS_EXTRACT_UTC (CURRENT_TIMESTAMP)
/
