CREATE TYPE designee_type IS OBJECT
(
    memberid VARCHAR2(10),
    prtcptype CHAR(1),
    issurrogater CHAR(1)
);
/
