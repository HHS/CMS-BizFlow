CREATE function		 fn_get_configuration_value
  (
     i_section		in varchar2,
     i_entry		in varchar2,
     i_default		in varchar2)
  RETURN  varchar2 IS
	l_value 	varchar2(2000);
-- 12.4.0.0
BEGIN
	select nvl(value, i_default) into l_value
	  from configuration
	 where section = upper(i_section)
           and entry = upper(i_entry);
    RETURN l_value;

EXCEPTION WHEN NO_DATA_FOUND THEN
    RETURN i_default;
END;
/
