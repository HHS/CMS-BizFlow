CREATE TRIGGER PASSWORD_BIR
BEFORE INSERT
  ON PASSWORD
FOR EACH ROW
  DECLARE
	MAX_DAY integer;
	MAX_NUMBER integer;
-- 12.4.0.0
BEGIN
	MAX_DAY := fn_get_configuration_valuen('PASSWORD','MAX_DAY_OF_PASSWORD_IN_HISTORY',0);
	MAX_NUMBER := fn_get_configuration_valuen('PASSWORD','MAX_NUMBER_OF_PASSWORDS_IN_HISTORY',0);

	if(MAX_DAY = 0 and MAX_NUMBER = 0) then
		return;
	end if;

	if(0 < MAX_DAY and 0 < MAX_NUMBER) then
		DELETE password
		 WHERE memberid = :new.memberid
		   AND seq in (SELECT seq FROM (
						SELECT r_.*, row_number() OVER (ORDER BY lastuseddtime desc) AS rownum_ FROM (
						SELECT * from password where memberid = :new.memberid
						) r_) t_
						WHERE rownum_ >= MAX_NUMBER and lastuseddtime < getutcdate()-MAX_DAY);
	elsif(0 < MAX_DAY and 0 = MAX_NUMBER) then
		DELETE FROM password
		 WHERE memberid = :new.memberid
		   AND lastuseddtime < getutcdate()-MAX_DAY;
	elsif(0 = MAX_DAY and 0 < MAX_NUMBER) then
		DELETE password
		 WHERE memberid = :new.memberid
		   AND seq in (SELECT seq FROM (
						SELECT r_.*, row_number() OVER (ORDER BY lastuseddtime desc) AS rownum_ FROM (
						SELECT * from password where memberid = :new.memberid
						) r_) t_
						WHERE rownum_ >= MAX_NUMBER);
	end if;
END;
/
