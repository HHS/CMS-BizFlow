CREATE VIEW HWV_DBSCHEMA_TABLES AS SELECT
    null AS table_catalog,
    null AS table_owner,
    object_name AS table_name,
    object_type AS table_type
  FROM    user_objects
 WHERE object_type in ('TABLE', 'VIEW', 'SYNONYM')
   AND status='VALID'
/
