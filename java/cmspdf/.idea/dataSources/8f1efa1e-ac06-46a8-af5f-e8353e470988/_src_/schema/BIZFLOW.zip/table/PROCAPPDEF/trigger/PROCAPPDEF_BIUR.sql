CREATE TRIGGER PROCAPPDEF_BIUR
BEFORE INSERT OR UPDATE OF APPID
  ON PROCAPPDEF
FOR EACH ROW WHEN (FOR EACH ROW )
DECLARE
cnt        integer;
cannotINSERT    EXCEPTION;
cannotmodify    EXCEPTION;

-- 12.4.0.0
BEGIN
SELECT count(1) INTO cnt FROM apptmplt
    WHERE svrid = :new.appsvrid
        AND orgappid = :new.orgappid
	AND envtype = :new.envtype
       AND isfinal = 'T';

IF inserting THEN
    if(cnt = 0) THEN
        RAISE cannotINSERT;
    END IF;
ELSE
    if(cnt = 0) THEN
        RAISE cannotmodify;
    END IF;
END IF;

EXCEPTION
   WHEN cannotINSERT THEN
        RAISE_APPLICATION_ERROR(-20808, 'This Application does not exists.');
   WHEN cannotmodify THEN
        RAISE_APPLICATION_ERROR(-20809, 'This Application does not exists.');
   WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20909, SQLERRM);
END;
/
