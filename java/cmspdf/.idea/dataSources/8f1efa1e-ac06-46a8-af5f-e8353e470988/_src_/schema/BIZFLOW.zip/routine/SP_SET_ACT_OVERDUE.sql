CREATE procedure          sp_set_act_overdue
   (
	i_presvrdtime in date,
	i_svrdtime in date)
   is
--
-- 12.4.0.0
--

begin

	update act set state = 'V'
		where state = 'R'
			and procid in (select procid from procs p where p.state in ('R', 'E', 'V', 'S')
														and p.deadlinedtime <= i_svrdtime
														and p.deadlinedtime > i_presvrdtime);

	update act set state = 'V'
		where state = 'R'
			and type <> 'W'
			and deadlinedtime <= i_svrdtime
			and deadlinedtime > i_presvrdtime;

exception
    when others then
        raise_application_error(-20717, sqlerrm);
end; -- procedure
/
