CREATE VIEW V_WORKITEM AS select c.procid as PROCESS_ID, c.witemseq as WORKITEM_ID, fn_get_reportdomainlookupvalue('witem.prtcptype', c.prtcptype) as PARTICIPANT_TYPE,
         fn_get_reportdomainlookupvalue('witem.state', c.state) as STATE_LABEL,
         c.state as STATE,
         c.actseq as ACTIVITY_ID,
         c.prtcp as PARTICIPANT_ID, c.prtcpname as PARTICIPANT_NAME,c.cmpltusr as COMPLETER_ID, c.cmpltusrname as COMPLETER_NAME,
         c.creationdtime as CREATION_DATE,
         c.startdtime as START_DATE, c.cmpltdtime as COMPLETION_DATE, '' as COMPLETION_DURATION
  from witem c
  where c.onasync = 'F'
/
