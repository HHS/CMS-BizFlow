CREATE VIEW V_TASKAPPROVERS AS SELECT
	taskid,
	seq,
	type,
	prtcp,
	name
FROM taskapprovers
UNION ALL
SELECT
	taskid,
	seq,
	type,
	prtcp,
	name
FROM completetaskapprovers
/
