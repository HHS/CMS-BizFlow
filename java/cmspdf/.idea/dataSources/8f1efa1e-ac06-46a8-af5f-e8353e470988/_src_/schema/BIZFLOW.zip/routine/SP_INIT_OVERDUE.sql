CREATE procedure          sp_init_overdue
   (
  i_svrid in varchar2,
  i_procid in number)
   is
--
-- 12.4.0.0
--

begin

 update witem set state = 'I' where svrid = i_svrid
         and procid = i_procid
         and state = 'V';

 update act set state = 'R' where svrid = i_svrid
         and procid = i_procid
         and state = 'V';

 update procs set state = 'R' where svrid = i_svrid
         and procid = i_procid
         and state = 'V';

exception
    when others then
        raise_application_error(-20734, sqlerrm);
end; -- procedure
/
