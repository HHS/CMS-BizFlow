CREATE procedure		   sp_va_checkin
(
	i_svrid in varchar2,
	i_procid in number,
	i_actseq in number,
	i_mapid in number,
	i_dmdocid in varchar2,
	i_dmver in varchar2,
	i_prtcp in varchar2,
	i_modifydtime in date
)
	is
--
-- 12.4.0.0
--
	l_cnt				number;
	new_internalid		number(10);
	old_lastappverseq	number(10);
	l_appinstid			number(10);
	cannotcheckin  		exception;
	errm				varchar2(800);
begin
	-- id.
	select count(*) into l_cnt
		from va_appmap
			where svrid = i_svrid
				and procid = i_procid
				and mapid = i_mapid;

	if (l_cnt = 0) then
		errm := 'Can not CheckIn.';
		raise cannotcheckin;
	end if;

	select	appinstid, lastappverseq
		into l_appinstid, old_lastappverseq
	from va_appmap
		where svrid = i_svrid
				and procid = i_procid
				and mapid = i_mapid;

    update va_appmap
		set internalid = internalid + 1
	where svrid = i_svrid
		and procid = i_procid
		and appinstid = l_appinstid;

    select internalid - 1
		into new_internalid
		from va_appmap
	where svrid = i_svrid
		and procid = i_procid
		and appinstid = l_appinstid;

	insert into va_appvermap (
		svrid, procid, appinstid, appverseq,
		actseq, actappseq, mapid,
		appsvrid, appid,
		dmsvrid, dmdocid, dmver, dmverlabel,
		modifydtime, prtcp, prtcpname)
	select
		i_svrid, i_procid, a.appinstid, new_internalid,
		i_actseq, 0, i_mapid,
		a.appsvrid, a.appid,
		b.dmsvrid, i_dmdocid, i_dmver, i_dmver,
		i_modifydtime, i_prtcp, c.name
	from va_appmap a, va_appvermap b, member c
		where a.svrid = i_svrid
				and a.procid = i_procid
				and a.mapid = i_mapid
				and a.svrid = b.svrid
				and a.procid = b.procid
				and a.appinstid = b.appinstid
				and a.lastappverseq = b.appverseq
				and c.memberid = i_prtcp;

	if sql%rowcount = 0 then
		errm := 'Can not CheckIn.';
		raise cannotcheckin;
    end if;

	insert into va_verlink (
		svrid, procid, appinstid,
		appverseqfrom, appverseqto)
	values
		(i_svrid, i_procid, l_appinstid, old_lastappverseq, new_internalid);

	update va_appmap
	set lastappverseq = new_internalid
		where svrid = i_svrid
			and procid = i_procid
			and appinstid = l_appinstid;

exception
    when cannotcheckin then
        raise_application_error(-20516, errm);
	when others then
		raise_application_error(-20731, sqlerrm);
end; -- procedure
/
