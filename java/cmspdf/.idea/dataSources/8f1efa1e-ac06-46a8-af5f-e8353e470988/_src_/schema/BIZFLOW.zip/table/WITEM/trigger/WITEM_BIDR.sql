CREATE TRIGGER WITEM_BIDR
BEFORE INSERT OR DELETE
  ON WITEM
FOR EACH ROW
  BEGIN

    IF inserting AND :new.state = 'I' THEN
        UPDATE witemcnt c SET cnt = cnt + 1
            WHERE c.memberid = :new.prtcp
                AND c.state = :new.state
                AND c.urgent = :new.urgent;
		-- 06/25/2008
		-- ticket 21811
		-- hwschd will scan workitems according to server.ini file
		-- default values are 30 days(start) and 7 days(running)
		-- therefore, the following routine is deleted.

		---- begin of cs12722: When deadlinedtime is already overdue when workitem is created, we will change state attribute.
		---- This is going to update act table also. We are not sure this may cause deadlock possibly.
		---- 'sysdate - 1' comes from the sp_set_witem_overdue. That stored procedure is checking 7days before. (-7)
		---- So -1 is enough for covering GMT as well as -7 days.
		--IF :new.deadlinedtime < sysdate THEN
		--	:new.state := 'V';
		--	UPDATE act SET state = 'V'
		--	WHERE procid = :new.procid
		--  		AND actseq = :new.actseq;
		--END IF;
		---- end of cs12722
    ELSE
        IF deleting THEN
            UPDATE witemcnt c SET cnt = cnt - 1
                WHERE c.memberid = :old.prtcp
                    AND c.state = :old.state
                    AND c.urgent = :old.urgent
                    AND c.cnt > 0;

			DELETE from witemapp
				WHERE procid = :old.procid
					AND witemseq = :old.witemseq;
        END IF;
    END IF;

 EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20918, SQLERRM);
END;
/
