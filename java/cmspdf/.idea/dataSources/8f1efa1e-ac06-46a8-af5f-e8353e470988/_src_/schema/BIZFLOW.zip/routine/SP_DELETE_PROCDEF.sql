CREATE procedure		   sp_delete_procdef
(
	 i_svrid in varchar2,
	 i_procdefid in number,
	 i_orgprocdefid in number
)
   is
--
-- 12.4.0.0
--
	l_cnt number;

	cannotdelete	exception;
	cannotdelete2	exception;
	cannotdelete3	exception;

begin
	if (i_orgprocdefid > 0) then
		select count(rowid)
		  into l_cnt
		  from procs
		 where presvrid = i_svrid
		   and orgprocdefid = i_orgprocdefid
		   and state in ('R', 'E', 'V', 'S', 'D', 'J');

		if (l_cnt > 0) then
			raise cannotdelete;
		end if;

		select count(1) into l_cnt
		  from actdef a, procdef p
			where a.subsvrid = i_svrid
				and a.suborgprocdefid = i_orgprocdefid
				and a.subenvtype = 'O'
				and a.procdefid = p.procdefid
				and p.isfinal = 'T';
		if (l_cnt > 0) then
			raise cannotdelete2;
		end if;

		select count(*) into l_cnt from act a, procs b
			where a.subsvrid = i_svrid
				and a.suborgprocdefid = i_orgprocdefid
				and b.svrid = a.svrid
				and b.procid = a.procid
				and b.state in ('R', 'E', 'V', 'S', 'D', 'J');
		if (l_cnt > 0) then
			raise cannotdelete2;
		end if;

		select count(rowid) into l_cnt from covelist
			where type = 'Q'
				and etcinfo = i_svrid || '.' || to_char(i_orgprocdefid);
		if (l_cnt > 0) then
			raise cannotdelete3;
		end if;
	end if;

	delete paramdef 		where svrid = i_svrid  and procdefid = i_procdefid;
	delete rlvntdatadef		where svrid = i_svrid  and procdefid = i_procdefid;
	delete conddef			where svrid = i_svrid  and procdefid = i_procdefid;
	delete eventdef			where svrid = i_svrid  and procdefid = i_procdefid;
	delete actappdef		where svrid = i_svrid  and procdefid = i_procdefid;
	delete actloopdef		where svrid = i_svrid  and procdefid = i_procdefid;
	delete procappdef		where svrid = i_svrid  and procdefid = i_procdefid;
	delete transdef 		where svrid = i_svrid  and procdefid = i_procdefid;
	delete excptdef 		where svrid = i_svrid  and procdefid = i_procdefid;
	delete prtcpdef 		where svrid = i_svrid  and procdefid = i_procdefid;
	delete actdef			where svrid = i_svrid  and procdefid = i_procdefid;
	delete procdef			where svrid = i_svrid  and procdefid = i_procdefid;
	delete respgrpdef		where svrid = i_svrid  and procdefid = i_procdefid;
	delete respdef			where svrid = i_svrid  and procdefid = i_procdefid;
	delete mdatadef		where svrid = i_svrid  and procdefid = i_procdefid;
	delete cpdef			where svrid = i_svrid  and procdefid = i_procdefid;

exception
	when cannotdelete then
		raise_application_error(-20513, 'There are running process instances related to the process definition.');
	when cannotdelete2 then
		raise_application_error(-20514, 'The process definition is used in more than one subprocess activity.');
	when cannotdelete3 then
		raise_application_error(-20529, 'The process definition is used in more than one Web Service.');

	when others then
		raise_application_error(-20712, sqlerrm);

end; -- procedure
/
