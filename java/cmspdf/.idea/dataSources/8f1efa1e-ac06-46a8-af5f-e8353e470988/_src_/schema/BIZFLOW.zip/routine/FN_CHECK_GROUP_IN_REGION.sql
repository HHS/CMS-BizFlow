CREATE FUNCTION FN_CHECK_GROUP_IN_REGION
(
    IN_GROUPORDEPTID IN VARCHAR2,
    IN_MEMBERID IN VARCHAR2
)
RETURN VARCHAR2
IS
	S_RESULT VARCHAR2(10);
	C_ORGTYPE CHAR(1);
	S_SYSTEMROOTDEPTPATH VARCHAR2(500);
	S_MYROOTDEPTPATH VARCHAR2(500);
	S_USRGRPHID VARCHAR2(10);
    N_CNT NUMBER;

-- 12.4.0.0
BEGIN

	S_RESULT := '';
	N_CNT := 0;
    SELECT COUNT(1) INTO N_CNT FROM member WHERE deptid = '9000000000' AND memberid = IN_MEMBERID;
    IF (N_CNT > 0) THEN
		S_RESULT := IN_GROUPORDEPTID;
		RETURN S_RESULT;
	END IF;

    SELECT NVL(type,'?') INTO C_ORGTYPE FROM vusrgrp	 WHERE memberid = IN_GROUPORDEPTID;
	IF (C_ORGTYPE = 'D') THEN
		SELECT COUNT(1) INTO N_CNT FROM vusrgrp WHERE memberid = '9999999996' AND type = 'H' AND headofregion <> 'T';
		IF (N_CNT > 0) THEN
			S_RESULT := IN_GROUPORDEPTID;
			RETURN S_RESULT;
		END IF;

		SELECT memberpath INTO S_SYSTEMROOTDEPTPATH
		  FROM parentmember
		 WHERE  parentid = memberid
		   AND memberid = '9000000000';
		SELECT grpp.memberpath INTO S_MYROOTDEPTPATH
		  FROM member vm, parentmember p, vusrgrp grp
		  LEFT JOIN parentmember grpp ON grpp.memberid = grp.memberid AND grpp.parentid = grpp.memberid
		 WHERE grp.memberid = p.parentid
		   AND p.memberid = vm.deptid
		   AND vm.memberid = IN_MEMBERID
		   AND p.parentid <> '9999999996'
		   AND grp.parentdeptid = '9000000000';

		SELECT COUNT(1) INTO N_CNT
		  FROM parentmember
		 WHERE  parentid = memberid
		   AND memberid = IN_GROUPORDEPTID
		   AND (memberpath in (S_SYSTEMROOTDEPTPATH, S_MYROOTDEPTPATH) OR memberpath LIKE S_MYROOTDEPTPATH || '/%');
		IF (N_CNT > 0) THEN
			S_RESULT := IN_GROUPORDEPTID;
		END IF;
	ELSIF (C_ORGTYPE = 'G') THEN
		SELECT COUNT(1) INTO N_CNT
		  FROM vusrgrp grp, vusrgrp hgrp
		 WHERE hgrp.headofregion <> 'T'
		   AND hgrp.type = 'H'
		   AND hgrp.memberid = grp.deptid
		   AND grp.memberid = IN_GROUPORDEPTID;
		IF (N_CNT > 0) THEN
			S_RESULT := IN_GROUPORDEPTID;
			RETURN S_RESULT;
		END IF;
		SELECT deptid INTO S_USRGRPHID FROM vusrgrp WHERE memberid = IN_GROUPORDEPTID;

		SELECT COUNT(1) INTO N_CNT
		  FROM parentmember pm, usrgrpprtcp u, parentmember p, vusrgrp grp LEFT JOIN parentmember grpp ON grpp.memberid = grp.memberid AND grpp.parentid = grpp.memberid
		 WHERE pm.parentid = pm.memberid AND pm.memberid = IN_GROUPORDEPTID
		   AND ((pm.memberpath IN (grpp.memberpath)) OR (pm.memberpath LIKE grpp.memberpath || '/%'))
		   AND grp.memberid = p.parentid
		   AND grp.parentdeptid = grp.deptid
		   AND u.prtcp =  IN_MEMBERID
		   AND u.usrgrphid = S_USRGRPHID
		   AND p.memberid = u.usrgrpid
		   AND p.parentid <> u.usrgrphid;
		IF (N_CNT > 0) THEN
			S_RESULT := IN_GROUPORDEPTID;
		END IF;
	ELSIF (C_ORGTYPE = 'H') THEN
		S_RESULT := IN_GROUPORDEPTID;
	END IF;
	RETURN S_RESULT;
END;
/
