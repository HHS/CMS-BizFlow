CREATE procedure		   sp_create_instance
   (
	 i_def_svrid in varchar2,
	 i_def_orgprocdefid in number,

	 i_svrid in varchar2,
	 i_procid in number,

	 i_procname in varchar2,
	 i_passwdflag in varchar2,
	 i_urgent in varchar2,
	 i_state in varchar2,
	 i_returnsvrid in varchar2,
	 i_parentsvrid in varchar2,
	 i_parentprocid in number,
	 i_parentactseq in number,
	 i_parentacttype in varchar2,
	 i_creationdtime in date,
	 i_instfldrid in number,
	 i_archivefldrid in number,
	 i_creator in varchar2,
	 i_description in varchar2,
	 i_customid in varchar2)
   is
--
-- 12.4.0.0
--
	i_def_procdefid		number(10);
begin

    select procdefid into i_def_procdefid
		from procdef
		where svrid = i_def_svrid
			and orgprocdefid = i_def_orgprocdefid
			and isfinal = 'T'
			and publicationstate = 'P';

	-- table procs
	insert into procs (
		svrid, procid, urgent, state, deadlinetype, subproctype, caltype,
		passwdflag, ver, instfldrid, archivefldrid, name,
		creator, creatorname, creationdtime, deadline, presvrid, orgprocdefid,
		preprocdefid, preprocdefname, returnsvrid, parentsvrid, parentprocid, parentactseq, usrgrphid, calmemberid,
		parentacttype, dscpt, dmsaveflag, dmidtype, dmsvrid, dmfldrid, customid
	)
	select	i_svrid, i_procid, i_urgent, i_state, a.deadlinetype, a.subproctype, a.caltype,
		i_passwdflag, 1, i_instfldrid, i_archivefldrid, i_procname,
		i_creator, b.name, i_creationdtime, a.deadline, i_def_svrid, orgprocdefid,
		i_def_procdefid, a.name, i_returnsvrid, i_parentsvrid, i_parentprocid, i_parentactseq, usrgrphid, calmemberid,
		i_parentacttype, substrb(i_description, 1, 255), dmsaveflag, dmidtype, dmsvrid, dmfldrid, i_customid
	from procdef a, member b
	where a.svrid = i_def_svrid
	and a.procdefid = i_def_procdefid
	and b.memberid = i_creator;

	-- table act
	insert into act	(
		svrid, procid, actseq, type, jointype, caltype,
		casetype, deadlinetype, transtype, existinfofile, existcmntrans,
		isrepsign, subproctype, sendapp, sendattach, sendcmnt, attaddcnt, suborgprocdefid,
		checkpostcond, cmpltopt, rbackopt, defsvrid, defprocdefid, name, priority, actauth, actinfo,
		deadline, respgrpseq, respseq, capacity, cost,
		providerid, waitingtime, workingtime, planstarttime, plancmplttime,
		subsvrid, subprocdefid, postcondseq, dscpt,
		eventtype, actlooptype, mergecondseq, splitcondseq
	)
	select	i_svrid, i_procid, actdefseq, type, jointype, caltype,
		casetype, deadlinetype, transtype, existinfofile, existcmntrans,
		isrepsign, subproctype, sendapp, sendattach, sendcmnt, attaddcnt, suborgprocdefid,
		checkpostcond, cmpltopt, rbackopt, i_def_svrid, i_def_procdefid, name, priority, actauth, actinfo,
		deadline, respgrpseq, respseq, capacity, cost,
		providerid, waitingtime, workingtime, planstarttime, plancmplttime,
		subsvrid, subprocdefid, postconddefseq, dscpt,
		eventtype, actlooptype, mergeconddefseq, splitconddefseq
	 from  actdef
	where svrid = i_def_svrid
	  and procdefid = i_def_procdefid;

	-- table actloop
    	insert into actloop
    	(
    		svrid, procid, actseq, testtime, miordering, miflowtype, loopcnt,
    		loopmaxcnt, condseq, miflowcondseq
    	)
    	select
    		i_svrid, i_procid, actdefseq, testtime, miordering, miflowtype, loopcnt,
    		loopmaxcnt, conddefseq, miflowconddefseq
    	 from actloopdef
    	where svrid = i_def_svrid
    	  and procdefid = i_def_procdefid;

    	-- table event
    	insert into event
    	(
    		svrid, procid, eventseq, triggerpoint, eventtype, msgimpltype,
			timertype, timertime, actseq, tonode, transseq, startactseq, rlvntdataseq,
			dscpt, linkid, sendapp, sendattach, sendcmnt, subsvrid, subprocdefid,
			suborgprocdefid, eraid
    	)
    	select
    		i_svrid, i_procid, eventdefseq, triggerpoint, eventtype, msgimpltype,
			timertype, timertime, actdefseq, tonode, transdefseq, startactdefseq, rlvntdatadefseq,
			dscpt, linkid, sendapp, sendattach, sendcmnt, subsvrid, subprocdefid,
			suborgprocdefid, eraid
    	 from eventdef
    	where svrid = i_def_svrid
    	  and procdefid = i_def_procdefid;

	-- table rlvntdata
	insert into rlvntdata
	(
		svrid, procid, rlvntdataseq, ispublic, scope, valuetype,
		rlvntdataname, value, dispvalue, dscpt
	)
	select
		i_svrid, i_procid, rlvntdatadefseq, ispublic, scope, valuetype,
		rlvntdatadefname, value, dispvalue, dscpt
	  from rlvntdatadef
	 where svrid = i_def_svrid
	   and procdefid = i_def_procdefid;

	-- table prtcp
	insert into prtcp
	(
		svrid, procid, actseq, prtcpseq, kind, type,
		assignrule, existscriptfile, prtcpauth, prtcp, mapid, disporder, usrgrphid,
		expr, calmemberid
	)
	select
		i_svrid, i_procid, actdefseq, prtcpdefseq, kind, type,
		assignrule, existscriptfile, prtcpauth, prtcp, mapid, disporder, usrgrphid,
		expr, calmemberid
	  from prtcpdef
	 where svrid = i_def_svrid
	   and procdefid = i_def_procdefid;

	-- table excpt
	insert into excpt
	(
		svrid, procid, excptseq, type, resptype,
		actseq, actappseq, incvalue, alertstarttime, alertduration,
		alertinterval, alertreceiver, email, exename, alertsubject, alertmsg
	)
	select
		i_svrid, i_procid, excptdefseq, type, resptype,
		actdefseq, actappdefseq, incvalue, alertstarttime, alertduration,
		alertinterval, alertreceiver, email, exename, alertsubject, alertmsg
	  from excptdef
	 where svrid = i_def_svrid
	   and procdefid = i_def_procdefid;

	-- table trans
	insert into trans
	(
		svrid, procid, transseq, type, iscmntrans,
		fromnode, tonode, condseq, actioncondseq, name, evalorder
	)
	select
		i_svrid, i_procid, transdefseq, type, iscmntrans,
		fromnode, tonode, conddefseq, actionconddefseq, name, evalorder
	  from transdef
	 where svrid = i_def_svrid
	   and procdefid = i_def_procdefid;

	-- table procapp
	insert into procapp
	(
		svrid, procid, procappseq, type, sendtype,
		keepingflag, viewtype, name, appsvrid, appid, orgappid,
		appver, disporder, rlvntdataseq, invokedmethod, extname,
		dscpt, dmsaveflag, dmidtype, dmsvrid, dmfldrid, dmdockind
	)
	select
		i_svrid, i_procid, procappdefseq, type, sendtype,
		keepingflag, viewtype, name, appsvrid, appid, orgappid,
		appver, disporder, rlvntdatadefseq, invokedmethod, extname,
		dscpt, dmsaveflag, dmidtype, dmsvrid, dmfldrid, dmdockind
	  from procappdef
	 where svrid = i_def_svrid
	   and procdefid = i_def_procdefid;

	-- table actapp
	insert into actapp
	(
		svrid, procid, actseq, actappseq, updatable,
		initoption, viewtype, jobseq, procappseq, appsvrid,
		appid, appver, inrlvntdataseq, outrlvntdataseq
	)
	select
		i_svrid, i_procid, actdefseq, actappdefseq, updatable,
		initoption, viewtype, jobseq, procappdefseq, appsvrid,
		appid, appver, inrlvntdatadefseq, outrlvntdatadefseq
	  from actappdef
	 where svrid = i_def_svrid
	   and procdefid = i_def_procdefid;

	-- table cond
	insert into cond
	(
		svrid, procid, condseq, type, dscpt,
		expr
	)
	select
		i_svrid, i_procid, conddefseq, type, dscpt,
		expr
	  from conddef
	 where svrid = i_def_svrid
	   and procdefid = i_def_procdefid;

	-- table param
	insert into param
	(
		svrid, procid, actseq, paramseq, inouttype, toscope,
		rlvntdataseq, disporder, todataname, const
	)
	select
		i_svrid, i_procid, actdefseq, paramdefseq, inouttype, toscope,
		rlvntdatadefseq, disporder, todataname, const
	  from paramdef
	 where svrid = i_def_svrid
	   and procdefid = i_def_procdefid;

	-- table resp
	insert into resp
	(
		svrid, procid, respgrpseq, respseq,
		disporder, name, respinfo
	)
	select
		i_svrid, i_procid, respgrpdefseq, respdefseq,
		disporder, name, respinfo
	  from respdef
	 where svrid = i_def_svrid
	   and procdefid = i_def_procdefid;

	-- table respgrp
	insert into respgrp
	(
		svrid, procid, respgrpseq, name, dscpt
	)
	select
		i_svrid, i_procid, respgrpdefseq, name, dscpt
	  from respgrpdef
	 where svrid = i_def_svrid
	   and procdefid = i_def_procdefid;

	-- BEGIN - Add by Kim Kwang Kean for Critical Path. (09/28/2007)
	-- table cp
	insert into cp	(
		svrid, procid, cpseq, value
	)
	select	i_svrid, i_procid, cpdefseq, value
	 from  cpdef
	where svrid = i_def_svrid
	  and procdefid = i_def_procdefid;
	-- END - Add by Kim Kwang Kean for Critical Path. (09/28/2007)

	-- table mdata
	-- insert into mdata
	-- (
	-- 	svrid, procid, mdataseq, objtype, objsubtype, valuetype,
	-- 	objseq, mdinfo, orgmdtmpltid, mditemseq, name, value, dscpt
	-- )
	-- select
	-- 	i_svrid, i_procid, mdatadefseq, objtype, objsubtype, valuetype,
	-- 	objseq, mdinfo, orgmdtmpltid, mditemseq, name, value, dscpt
	--   from mdatadef
	--  where svrid = i_def_svrid
	--    and procdefid = i_def_procdefid;

	-- You should keep the order of following SQL.
	update procapp pa set (appid, appsvrid, type, name, appver, invokedmethod, extname, dscpt,
							keepingflag) = (select appt.appid, appt.svrid, appt.type, appt.name,
															appt.appver, appt.invokedmethod, appt.extname, appt.dscpt,
															appt.keepingflag
														from apptmplt appt
														where appt.orgappid = pa.orgappid
															and appt.isfinal = 'T'
															and appt.envtype = 'O')
			where pa.svrid = i_svrid
				and pa.procid = i_procid
				and pa.rlvntdataseq = 0;

	update actapp aa set (appid, appsvrid, appver) = (select appt.appid, appsvrid, appt.appver
														from apptmplt appt, procapp pa
														where appt.orgappid = pa.orgappid
															and appt.isfinal = 'T'
															and appt.envtype = 'O'
															and pa.procid = aa.procid
															and pa.procappseq = aa.procappseq)
			where aa.svrid = i_svrid
				and aa.procid = i_procid
				and 0 = (select pa.rlvntdataseq from procapp pa
								where pa.procid = aa.procid
									and pa.procappseq = aa.procappseq);

exception
	when others then
		raise_application_error(-20708, sqlerrm);
end; -- procedure
/
