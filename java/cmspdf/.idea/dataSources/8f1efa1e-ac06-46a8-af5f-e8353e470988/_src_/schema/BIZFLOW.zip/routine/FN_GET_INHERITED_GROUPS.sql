CREATE FUNCTION fn_get_inherited_groups(
    i_memberid IN VARCHAR2)
RETURN group_type2_coll
AS
    groups group_type2_coll;
-- 12.4.0.0
BEGIN
    SELECT group_type2(g.memberid)
      BULK COLLECT INTO groups
      FROM (SELECT dept.memberid, dept.parentdeptid, dept.inherittype
              FROM member dept
              LEFT JOIN member deptmember ON dept.memberid = deptmember.deptid
        START WITH deptmember.memberid = i_memberid
               AND deptmember.type = 'U'
               AND dept.type = 'D'
        CONNECT BY PRIOR dept.parentdeptid = dept.memberid
               AND PRIOR dept.inherittype IN ('U', 'B', 'P', 'Q')
         UNION ALL
            SELECT grp.memberid, grp.parentdeptid, grp.inherittype
              FROM member grp
              LEFT JOIN usrgrpprtcp grpmember ON grp.memberid = grpmember.usrgrpid
        START WITH grpmember.prtcp = i_memberid
               AND grpmember.prtcptype = 'U'
               AND grp.type = 'G'
        CONNECT BY PRIOR grp.parentdeptid = grp.memberid
               AND PRIOR grp.inherittype IN ('U', 'B', 'P', 'Q')
           ) g;
    RETURN groups;
END;
/
