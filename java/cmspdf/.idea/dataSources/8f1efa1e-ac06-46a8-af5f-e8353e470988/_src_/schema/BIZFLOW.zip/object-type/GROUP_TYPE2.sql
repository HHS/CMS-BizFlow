CREATE TYPE group_type2 IS OBJECT
(
    memberid VARCHAR2(10)
);
/
