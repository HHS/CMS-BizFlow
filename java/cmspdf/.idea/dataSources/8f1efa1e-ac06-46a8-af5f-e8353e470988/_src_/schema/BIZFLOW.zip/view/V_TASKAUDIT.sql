CREATE VIEW V_TASKAUDIT AS SELECT TaskID, SubTaskID, FromName, ToName, FromGroupName, FromID, ToID, FromGroupID, CreationDT, ValueType, Value FROM dtaskeraudit
UNION ALL
SELECT TaskID, SubTaskID, FromName, ToName, FromGroupName, FromID, ToID, FromGroupID, CreationDT, ValueType, Value FROM completedtaskeraudit
UNION ALL
SELECT s.TaskID, s.SubTaskID, c.creatorname, '', NULL, c.creator, '', NULL, c.creationdtime, c.type, c.contents
    FROM cmnt c, witem w, act a, SubTasks s
    WHERE c.svrid = w.svrid AND c.procid = w.procid AND c.witemseq = w.witemseq
        AND w.svrid = a.svrid AND w.procid = a.procid AND w.actseq = a.actseq
        AND a.procid = s.ProcID AND a.actseq IN (
            select objseq from mdata where ObjType = 'A' AND ObjSubType ='P' AND ValueType='S' AND  procid = s.ProcID AND name = 'subtaskid' AND value = TO_CHAR( s.SubTaskID )
        )
UNION ALL
SELECT s.TaskID, s.SubTaskID, c.creatorname, '', NULL, c.creator, '', NULL, c.creationdtime, c.type, c.contents
    FROM cmnt c, witem w, act a, CompleteSubTasks s
    WHERE c.svrid = w.svrid AND c.procid = w.procid AND c.witemseq = w.witemseq
        AND w.svrid = a.svrid AND w.procid = a.procid AND w.actseq = a.actseq
        AND a.procid = s.ProcID AND a.actseq IN (
            select objseq from mdata where ObjType = 'A' AND ObjSubType ='P' AND ValueType='S' AND  procid = s.ProcID AND name = 'subtaskid' AND value = TO_CHAR( s.SubTaskID )
        )
/
