CREATE TRIGGER PROCTABDEF_ADR
AFTER DELETE
  ON PROCTABDEF
  DECLARE
    cnt     integer;
    l_id                number;
    l_transactionid     varchar2(50);

    cursor cur_get_id is
        SELECT vara FROM hwtemp WHERE tmpkey = l_transactionid;

BEGIN
-- 12.4.0.0
    SELECT DBMS_TRANSACTION.LOCAL_TRANSACTION_ID INTO l_transactionid FROM dual;

    OPEN cur_get_id;

    LOOP
        FETCH cur_get_id INTO l_id;
        EXIT WHEN cur_get_id%notfound;

        --dbms_output.put_line('proctabdef_adr: ' || l_transactionid || ', ' || l_id);

        SELECT count(1) INTO cnt
          FROM proctabdef
         WHERE orgprocdefid = l_id;

        IF cnt = 0 THEN
            UPDATE procdef SET customtab = 'F'
             WHERE orgprocdefid = l_id;
        END IF;
    END LOOP;

    CLOSE cur_get_id;

    DELETE FROM hwtemp WHERE tmpkey = l_transactionid;

EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20940, SQLERRM);
END;
/
