CREATE PROCEDURE sp_check_complete_all_end
   (
     i_svrid in varchar2,
     i_procid in number,
     o_value out number)
   is
--
-- 12.4.0.0
--
   l_total_cnt               number(10);
   l_total_cmplt_cnt         number(10);
   l_total_dead_cnt          number(10);
   l_running_act_cnt         number(10);
   l_evaluated_cnt           number(10);
   -- declare program variables as shown above

begin

    select count(1) into l_total_cnt
      from act
     where svrid = i_svrid
       and procid = i_procid
       and type = 'E'
       and eventtype in ('N', 'M', 'L');

    select count(1) into l_total_cmplt_cnt
      from act
     where svrid = i_svrid
       and procid = i_procid
       and type = 'E'
       and eventtype in ('N', 'M', 'L')
       and state = 'C';

    select count(1) into l_total_dead_cnt
      from act
     where svrid = i_svrid
       and procid = i_procid
       and type = 'E'
       and eventtype in ('N', 'M', 'L')
       and state = 'D';

    l_evaluated_cnt := l_total_cmplt_cnt + l_total_dead_cnt;

    if l_total_cnt > l_evaluated_cnt then
        o_value := 0;
    else
        if l_total_dead_cnt = 0 then
            o_value := 1;
        else
            select count(1) into l_running_act_cnt
              from act
             where svrid = i_svrid
               and procid = i_procid
               and state in ('R', 'V');

            if l_running_act_cnt = 0 then
                o_value := 1;
            else
                o_value := 0;
            end if;
        end if;
    end if;

exception
    when others then
        raise_application_error(-20748, sqlerrm);
end; -- procedure
/
