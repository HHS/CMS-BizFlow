CREATE TRIGGER USRGRPPRTCP_BDR
BEFORE DELETE
  ON USRGRPPRTCP
FOR EACH ROW
  DECLARE
cnt				integer;
l_usrgrphid		varchar2(10);
l_prtcptype		char(1);
l_prtcp			varchar2(10);
l_prtcpname		varchar2(100);
l_usrgrptype	char(1);
l_usrgrpid		varchar2(10);
l_usrgrpname	varchar2(100);
l_actor			varchar2(10);
l_actorname		varchar2(100);
l_event			varchar2(100);
l_objid			varchar2(10);
l_objtype		varchar2(50);
l_objname		varchar2(100);
l_ipaddr		varchar2(50);
l_path			varchar2(500);
l_detail		varchar2(2048);


-- 12.4.0.0
BEGIN

	l_actor := '0000000000';
	l_actorname := 'System';
	l_detail := '';

	l_prtcp := :old.prtcp;
	l_prtcptype := :old.prtcptype;
	l_usrgrpid := :old.usrgrpid;

	begin
		select prtcp.name, g.type, g.name
		  into l_prtcpname, l_usrgrptype, l_usrgrpname
		  from member prtcp, member g
		 where prtcp.memberid = :old.prtcp
		   and g.memberid = :old.usrgrpid;
	exception when NO_DATA_FOUND then
		return;
	end;

	l_objid := l_prtcp;
	l_objtype := 'USER';
	l_objname := l_prtcpname;

	if (l_prtcptype = 'U') then

		if (l_usrgrptype = 'A')
		then
			l_event := 'AUTHORITYREVOKED';
			l_detail := l_usrgrpname;
			begin
				select o.memberid, o.membername, u.ipaddr
				  into l_actor, l_actorname, l_ipaddr
				  from member m, parentmember p, checkout o, usrsession u
				 where m.memberid = :old.prtcp
				   and p.memberid = m.deptid
				   and o.nodeid = p.parentid
				   and o.type = 'O'
				   and u.memberid = o.memberid;
			exception when NO_DATA_FOUND then
				null;
			end;

		elsif (l_usrgrptype = 'L') then
			l_event := 'LICENSEGRANTED';
			l_detail := l_usrgrpname;
			begin
				select o.memberid, o.membername, u.ipaddr
				  into l_actor, l_actorname, l_ipaddr
				  from member m, parentmember p, checkout o, usrsession u
				 where m.memberid = :old.prtcp
				   and p.memberid = m.deptid
				   and o.nodeid = p.parentid
				   and o.type = 'O'
				   and u.memberid = o.memberid;
			exception when NO_DATA_FOUND then
				null;
			end;
		elsif (l_usrgrptype = 'G') then
			l_event := 'REMOVEDFROMUSERGROUP';

			begin
				select memberpath into l_detail
				  from parentmember
				 where memberid = :old.usrgrpid
				   and parentid = memberid;
			exception when NO_DATA_FOUND then
				l_detail := null;
			end;

			begin
				select o.memberid, o.membername, u.ipaddr
				  into l_actor, l_actorname, l_ipaddr
				  from parentmember p, checkout o, usrsession u
				 where p.memberid = :old.usrgrpid
				   and o.nodeid = p.parentid
				   and o.type in ('H','G')
				   and u.memberid = o.memberid;
			exception when NO_DATA_FOUND then
				begin
					select o.memberid, o.membername, u.ipaddr
					  into l_actor, l_actorname, l_ipaddr
					  from member m, parentmember p, checkout o, usrsession u
					 where m.memberid = :old.prtcp
					   and p.memberid = m.deptid
					   and o.nodeid = p.parentid
					   and o.type = 'O'
					   and u.memberid = o.memberid;
				exception when NO_DATA_FOUND then
					null;
				end;
			end;
		end if;
	elsif (l_prtcptype = 'G') then
		l_objid := l_prtcp;
		l_objtype := 'USERGROUP';
		l_objname := l_prtcpname;

		if (l_usrgrptype = 'A') then
			l_event := 'AUTHORITYREVOKED';
			l_detail := l_usrgrpname;

			begin
				select o.memberid, o.membername, u.ipaddr
				  into l_actor, l_actorname, l_ipaddr
				  from parentmember p, checkout o, usrsession u
				 where p.memberid = :old.prtcp
				   and o.nodeid = p.parentid
				   and o.type = 'G'
				   and u.memberid = o.memberid;
			exception when NO_DATA_FOUND then
				null;
			end;
		end if;
	end if;

	if (l_detail is not null) then
		insert into auditinfoadm (seq, actor, actorname, dtime, event, objid, objtype, objname, ipaddr, detail)
		values (hws_adminaudit.nextval, l_actor, l_actorname, getutcdate(), l_event, l_objid, l_objtype, l_objname, l_ipaddr, l_detail);
	end if;
EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20944, SQLERRM);
END;
/
