CREATE TRIGGER RESPGRPDEF_BDR
BEFORE DELETE
  ON RESPGRPDEF
FOR EACH ROW
  BEGIN

    DELETE FROM respdef
     WHERE svrid = :old.svrid
       AND procdefid = :old.procdefid
       AND respgrpdefseq = :old.respgrpdefseq;

 EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20922, SQLERRM);
END;
/
