CREATE procedure sp_update_procapp
   (
     i_svrid        in varchar2,
     i_procid       in number,
     i_actseq       in number)
   is
--
-- 12.4.0.0
--
cursor cur_get_rlvntdata_for_orgappid (l_svrid varchar2, l_procid number, l_actseq number) is
    select p.procappseq, substr(r.value, 1, 10), to_number(substr(r.value, 12, 10)), a.initoption
	from actapp a, procapp p, vrlvntdata r
	where a.svrid = l_svrid
		and a.procid = l_procid
		and a.actseq = l_actseq
		and p.svrid = a.svrid
		and p.procid = a.procid
		and p.procappseq = a.procappseq
		and r.svrid = p.svrid
		and r.procid = p.procid
		and r.rlvntdataseq = p.rlvntdataseq
		and r.valuetype = 'A';

	l_procappseq		number(10);
	l_orgappid			number(10);
	l_appsvrid			varchar2(10);
    l_initoption            varchar2(1);
    l_is_orgappid_valid     number(10);     -- true (non-zero) if has an active form on operational environment, false (0) otherwise.
    l_is_appid_valid        number(10);     -- true (non-zero) if exists on apptmplt, false (0) otherwise.
    l_last_used_appid       number(10);     -- non-zero if found the same form on preceding completed activities, 0 otherwise.

--    cannotupdate 	exception;
begin
	open cur_get_rlvntdata_for_orgappid(i_svrid, i_procid, i_actseq);
	loop
        fetch cur_get_rlvntdata_for_orgappid into l_procappseq, l_appsvrid, l_orgappid, l_initoption;
		exit when cur_get_rlvntdata_for_orgappid%notfound;

        l_is_appid_valid := -1;

        select count(*) into l_is_orgappid_valid from apptmplt where svrid = l_appsvrid and orgappid = l_orgappid and isfinal = 'T' and envtype = 'O';
        if l_is_orgappid_valid > 0 then
            -- initoption: don't care, orgapplid: valid, appid: don't care => use orgappid
            -- case 1: regular cases with 10.1+ versions, a valid form was assigned to a PV
            update procapp
               set        (orgappid, appid, appsvrid, type, name, appver, invokedmethod, extname, dscpt, keepingflag, dmsvrid) =
                   (select orgappid, appid, svrid,    type, name, appver, invokedmethod, extname, dscpt, keepingflag, dmsvrid
			             from apptmplt
        				where svrid = l_appsvrid
              				and orgappid = l_orgappid
							and isfinal = 'T'
							and envtype = 'O')
     			where svrid  = i_svrid
       				and procid = i_procid
       				and procappseq = l_procappseq;
        else
            select count(*) into l_is_appid_valid from apptmplt where svrid = l_appsvrid and appid = l_orgappid;
            if l_is_appid_valid = 0 then
                -- initoption: don't care, orgapplid: invalid, appid: invalid => use 0
                -- case 4: the PV has a blank value or invalid value (that does not exist on APPTMPLT)
                update procapp
                   set orgappid = 0, appid = 0, name = '???', appver = 0, invokedmethod = null, extname = null, dscpt = null
                 where svrid  = i_svrid
                       and procid = i_procid
                       and procappseq = l_procappseq;
            end if;
/*
            if l_is_appid_valid > 0 then
                -- initoption: don't care, orgapplid: invalid, appid: valid => use appid
                -- case 2: the form being referred was deleted from the operational environment, no active form. do nothing.
                -- case 3: this running instance was created from 9.0 or earlier version, the form was updated on the same version, after that bizflow was upgraded to 10.1+ version, so the form being referred does not have active version, just do nothing.
            end if;
*/
        end if;

        if l_initoption = 'O' or l_initoption = 'L' then
            select nvl(max(appid), 0)
            into l_last_used_appid
            from witemapp
            where svrid = i_svrid
                and procid = i_procid
                and state = 'C'
                and appid in (
                    select appid from apptmplt where envtype = 'O' and orgappid = l_orgappid
                );
            if l_last_used_appid > 0 then
                -- initoption: O or L, orgapplid: don't care, appid: don't care (assumes valid), appid used on this process? yes => use appid
                -- The form on this activity has Open mode and an existing form was found. The existing form will be used on the activity.
                update actapp
                   set        (appid, appsvrid, appver) =
                       (select appid, svrid,    appver
                          from apptmplt
                         where svrid = l_appsvrid
                               and appid = l_last_used_appid)
                 where svrid  = i_svrid
                       and procid = i_procid
                       and procappseq = l_procappseq;

                 update witemapp
                   set        (appid, appsvrid, appver) =
                       (select appid, svrid,    appver
                          from apptmplt
                         where svrid = l_appsvrid
                               and appid = l_last_used_appid)
                 where svrid  = i_svrid
                       and procid = i_procid
                       and actseq = i_actseq /* cs20264 */
                       and procappseq = l_procappseq;
            else
                if l_is_orgappid_valid > 0 then
                    -- initoption: O or L, orgapplid: valid, appid: don't care (assumes valid), appid used on this process? no => use orgappid
                    -- The form on this activity has Open mode, but never opened before. The latest version of the form will be used.
                    update actapp
                       set        (appid, appsvrid, appver) =
				(select appid, svrid, appver
			             from apptmplt
        				where svrid = l_appsvrid
              				and orgappid = l_orgappid
							and isfinal = 'T'
							and envtype = 'O')
     			where svrid  = i_svrid
       				and procid = i_procid
       				and procappseq = l_procappseq;

                     update witemapp
                       set        (appid, appsvrid, appver) =
				(select appid, svrid, appver
			             from apptmplt
        				where svrid = l_appsvrid
              				and orgappid = l_orgappid
							and isfinal = 'T'
							and envtype = 'O')
     			where svrid  = i_svrid
       				and procid = i_procid
                           and actseq = i_actseq /* cs20264 */
                           and procappseq = l_procappseq;
                else
                    -- initoption: O or L, orgapplid: invalid, appid: don't care (assumes valid), appid used on this process? no => use 0
                    -- The form on this activity has OPEN mode, but no existing instance of form was found from this process, no active form was found from APPTMPLT. The form will be removed from this activity.
                    update actapp
                       set appid = 0, appsvrid = '0000000000', appver = 0
                     where svrid  = i_svrid
                           and procid = i_procid
				and actseq = i_actseq
       				and procappseq = l_procappseq;

                    update witemapp
                       set appid = 0, appsvrid = '0000000000', appver = 0
                     where svrid  = i_svrid
                           and procid = i_procid
                           and actseq = i_actseq
                           and procappseq = l_procappseq;
                end if;
            end if;
		else
            if l_is_orgappid_valid > 0 then
                -- initoption: N, orgapplid: valid, appid: don't care (assumes valid) => use orgappid
                -- The form on this activity has NEW mode and a valid active form was found from APPTMPLT. The latest form will be used on this activity.
                update actapp
                   set        (appid, appsvrid, appver) =
                       (select appid, svrid,    appver
                          from apptmplt
                         where svrid = l_appsvrid
                               and orgappid = l_orgappid
                               and isfinal = 'T'
                               and envtype = 'O')
     			where svrid  = i_svrid
       				and procid = i_procid
       				and procappseq = l_procappseq;

                 update witemapp
                   set        (appid, appsvrid, appver) =
                       (select appid, svrid,    appver
                          from apptmplt
                         where svrid = l_appsvrid
                               and orgappid = l_orgappid
                               and isfinal = 'T'
                               and envtype = 'O')
                 where svrid  = i_svrid
                       and procid = i_procid
                       and actseq = i_actseq /* cs20264 */
                       and procappseq = l_procappseq;
            else
                -- initoption: N, orgapplid: invalid, appid: don't care (assumes valid) => use 0
                -- The form on this activity has NEW mode and no active form was found from APPTMPLT. This form will be removed from the work item.
                update actapp
                   set appid = 0, appsvrid = '0000000000', appver = 0
    			where svrid  = i_svrid
					and procid = i_procid
					and actseq = i_actseq
					and procappseq = l_procappseq;

                update witemapp
                   set appid = 0, appsvrid = '0000000000', appver = 0
    			where svrid  = i_svrid
					and procid = i_procid
					and actseq = i_actseq
					and procappseq = l_procappseq;
			end if;
        end if;
	end loop;
	close cur_get_rlvntdata_for_orgappid;

exception
	when others then
        if cur_get_rlvntdata_for_orgappid%isopen then
            close cur_get_rlvntdata_for_orgappid;
        end if;
        raise_application_error(-20723, sqlerrm);
end; -- procedure
/
