CREATE procedure sp_copy_md
(
	i_svrid	in varchar2,
	i_old_mdtmpltid	in number,
	i_new_mdtmpltid in number
)
is
--
-- 12.4.0.0
--
begin
	update mdtmplt
		set isfinal = 'F'
		where svrid = i_svrid
			and mdtmpltid = i_old_mdtmpltid;

	insert into mdtmplt
	(
		mdtmpltid, svrid, type, parentmdtmpltid, orgmdtmpltid,
		mdtmpltver, fldrid, name, isfinal, dscpt, chkincmnt
	)
	select
		i_new_mdtmpltid, svrid, type, parentmdtmpltid, orgmdtmpltid,
		mdtmpltver+1, fldrid, name, 'T', dscpt, chkincmnt
	from mdtmplt
		where svrid = i_svrid
		and mdtmpltid = i_old_mdtmpltid;

	insert into mditem
	(
		mdtmpltid, mditemseq, svrid, objtype, objsubtype, valuetype,
		mdinfo, name, value, dscpt
	)
	select
		i_new_mdtmpltid, mditemseq, svrid, objtype, objsubtype, valuetype,
		mdinfo, name, value, dscpt
	from mditem
		where svrid = i_svrid
		and mdtmpltid = i_old_mdtmpltid;

	insert into enumdata
	(
		mdtmpltid, mditemseq, enumdataseq, svrid, value
	)
	select
		i_new_mdtmpltid, mditemseq, enumdataseq, svrid, value
	from enumdata
		where svrid = i_svrid
		and mdtmpltid = i_old_mdtmpltid;

exception
    when others then
        raise_application_error(-20722, sqlerrm);
end;
/
