CREATE procedure sp_create_audit_adm
(
    i_actor      in varchar2,
    i_actorname  in varchar2,
    i_event      in varchar2,
    i_objid      in varchar2,
    i_objtype    in varchar2,
    i_objname    in varchar2,
    i_ipaddr     in varchar2,
    i_detail     in varchar2
)
IS
--
-- 12.4.0.0
--
    l_count         number;
    l_actor			varchar2(10);
    l_actorname     varchar2(100);
    l_ipaddr        varchar2(40);
    l_objname       varchar2(100);
    l_detail        varchar2(4000);
    invalidparam    exception;

BEGIN

    if (i_event is null) then
        raise invalidparam;
    end if;

    if (i_actorname is null) then
	    if (i_actor is null) then
	        raise invalidparam;
	    end if;
        select name into l_actorname from member where memberid = i_actor;
    else
        l_actorname := i_actorname;
    end if;

    if ('$$MEMBER' = SUBSTR(i_objname, 1, 8)) then
        select name into l_objname from member where memberid = SUBSTR(i_objname, 10, 10);
    else
        l_objname := i_objname;
    end if;

    if ('$$USRSESSION' = i_ipaddr) then
        select COUNT(1) into l_count from usrsession where memberid = i_actor;
        if l_count > 0 then
            select ipaddr into l_ipaddr from usrsession where memberid = i_actor;
        else
            l_ipaddr := '';
        end if;
    else
        l_ipaddr := i_ipaddr;
    end if;

    if ('$$MEMBER' = SUBSTR(i_detail, 1, 8)) then
        select name into l_detail from member where memberid = SUBSTR(i_detail, 10, 10);
    else
        l_detail := i_detail;
    end if;

    if (i_actor is null) then
        l_actor := '0000000000';
    else
        l_actor := i_actor;
    end if;

    insert into auditinfoadm (seq, actor, actorname, dtime, event, objid, objtype, objname, ipaddr, detail)
    values (hws_adminaudit.nextval, l_actor, l_actorname, getutcdate(), i_event, i_objid, i_objtype, l_objname, l_ipaddr, l_detail);

EXCEPTION
    when invalidparam then
        raise_application_error(-20541, 'Invalid parameters.');
    when others then
        raise_application_error(-20749, sqlerrm);
END;
/
