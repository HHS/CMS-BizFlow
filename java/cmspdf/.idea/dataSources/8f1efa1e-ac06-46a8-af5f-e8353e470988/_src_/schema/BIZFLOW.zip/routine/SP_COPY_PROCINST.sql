CREATE procedure sp_copy_procinst
(
    i_svrid     in varchar2,
    i_procid	in number,
    i_newprocid in number,
    i_parentprocid in number
)
is
    l_cnt    	number;
    l_taskcnt  	number;
    cannotcopy  exception;
    errm    	varchar2(800);
	l_taskid    number;
	l_newtaskid number;
    l_customid 	varchar2(200);
--
-- 12.4.0.0
--
begin
    -- validation of source proc. inst.
	select count(1) into l_cnt from procs
	 where svrid     = i_svrid
	   and procid = i_procid;
	if (l_cnt <> 1) then
		errm := 'There is no Process Instance in the Folder.';
		raise cannotcopy;
	end if;

	l_taskcnt := 0;
	-- Is OfficeEngine Process?
--	SELECT Count(1) into l_taskcnt FROM v_Tasks WHERE ProcID = i_procid;

    -- table procs
	insert into procs
	(
		svrid, procid, urgent, deadlinetype, subproctype,
       passwdflag, state, dmsaveflag, dmidtype, caltype,
       internalid, cmntcnt, orgprocdefid, attachcnt,
       revisionid, instfldrid, ver, archivefldrid, name,
       creationdtime, creator, creatorname, deadline,
       presvrid, preprocdefid, preprocdefname, usrgrphid,
       calmemberid, customid, cmpltdtime, deadlinedtime,
       returnsvrid, parentsvrid, parentprocid, parentactseq,
       parentacttype, checkoutusr, modifydtime, modifier,
       modifiername, lastcorrespondence, dmsvrid, dmfldrid, dscpt
	)
	select
		a.svrid, i_newprocid, a.urgent, a.deadlinetype, a.subproctype,
       a.passwdflag, a.state, a.dmsaveflag, a.dmidtype, a.caltype,
       a.internalid, 0, a.orgprocdefid, 0,
       a.revisionid, a.instfldrid, a.ver, a.archivefldrid, a.name,
       a.creationdtime, a.creator, a.creatorname, a.deadline,
       a.presvrid, a.preprocdefid, a.preprocdefname, a.usrgrphid,
       a.calmemberid, a.customid, a.cmpltdtime, a.deadlinedtime,
       a.returnsvrid, a.parentsvrid, a.parentprocid, a.parentactseq,
       a.parentacttype, a.checkoutusr, a.modifydtime, a.modifier,
       a.modifiername, a.lastcorrespondence, a.dmsvrid, a.dmfldrid, a.dscpt
	from procs a
		where a.svrid = i_svrid
		and a.procid = i_procid;

    If l_taskcnt <= 0 Then
	    -- table act
	    insert into act
		(
			svrid, procid, actseq, type, jointype, casetype,
	       deadlinetype, transtype, caltype, existinfofile,
	       existcmntrans, isrepsign, subproctype, sendapp,
	       sendattach, sendcmnt, attaddcnt, state, prestate,
	       checkpostcond, cmpltopt, rbackopt, eventtype,
	       actlooptype, defsvrid, defprocdefid, name, priority,
	       actauth, actinfo, deadline, respgrpseq, respseq,
	       capacity, cost, providerid, loopcnt, cmpltcnt,
	       spcfromnode, waitingtime, workingtime, planstarttime,
	       plancmplttime, subsvrid, subprocdefid, suborgprocdefid,
	       postcondseq, mergecondseq, splitcondseq, dscpt,
	       resplist, planstartdtime, plancmpltdtime, startdtime,
	       cmpltdtime, deadlinedtime
		)
		select
			a.svrid, i_newprocid, a.actseq, a.type, a.jointype, a.casetype,
	       a.deadlinetype, a.transtype, a.caltype, a.existinfofile,
	       a.existcmntrans, a.isrepsign, a.subproctype, a.sendapp,
	       a.sendattach, a.sendcmnt, a.attaddcnt, a.state, a.prestate,
	       a.checkpostcond, a.cmpltopt, a.rbackopt, a.eventtype,
	       a.actlooptype, a.defsvrid, a.defprocdefid, a.name, a.priority,
	       a.actauth, a.actinfo, a.deadline, a.respgrpseq, a.respseq,
	       a.capacity, a.cost, a.providerid, a.loopcnt, a.cmpltcnt,
	       a.spcfromnode, a.waitingtime, a.workingtime, a.planstarttime,
	       a.plancmplttime, a.subsvrid, a.subprocdefid, a.suborgprocdefid,
	       a.postcondseq, a.mergecondseq, a.splitcondseq, a.dscpt,
	       a.resplist, a.planstartdtime, a.plancmpltdtime, a.startdtime,
	       a.cmpltdtime, a.deadlinedtime
		from act a
			where a.svrid = i_svrid
			and a.procid = i_procid;
    End if;

    -- table actloop
	insert into actloop
	(
		svrid, procid, actseq, testtime, miordering,
       miflowtype, loopcnt, loopmaxcnt, condseq,
       miflowcondseq
	)
	select
		a.svrid, i_newprocid, a.actseq, a.testtime, a.miordering,
       a.miflowtype, a.loopcnt, a.loopmaxcnt, a.condseq,
       a.miflowcondseq
	from actloop a
		where a.svrid = i_svrid
		and a.procid = i_procid;


    -- table prtcp
	insert into prtcp
	(
		svrid, procid, actseq, prtcpseq, kind, useflag,
       type, assignrule, existscriptfile, prtcpauth, prtcp,
       mapid, disporder, calmemberid, usrgrphid, deptname,
       jobtitlename, expr, prtcpname
	)
	select
		a.svrid, i_newprocid, a.actseq, a.prtcpseq, a.kind, a.useflag,
       a.type, a.assignrule, a.existscriptfile, a.prtcpauth, a.prtcp,
       a.mapid, a.disporder, a.calmemberid, a.usrgrphid, a.deptname,
       a.jobtitlename, a.expr, a.prtcpname
	from prtcp a
		where a.svrid = i_svrid
		and a.procid = i_procid;


    -- table excpt
	insert into excpt
	(
		svrid, procid, excptseq, type, resptype, actseq,
       actappseq, incvalue, alertstarttime, alertduration,
       alertinterval, alertreceiver, email, exename,
       alertsubject, alertmsg
	)
	select
		a.svrid, i_newprocid, a.excptseq, a.type, a.resptype, a.actseq,
       a.actappseq, a.incvalue, a.alertstarttime, a.alertduration,
       a.alertinterval, a.alertreceiver, a.email, a.exename,
       a.alertsubject, a.alertmsg
	from excpt a
		where a.svrid = i_svrid
		and a.procid = i_procid;


    -- table trans
    insert into trans
    (
    	svrid, procid, transseq, state, type, iscmntrans,
       fromnode, tonode, condseq, actioncondseq, loopcnt,
       evalorder, name
    )
    select
	    a.svrid, i_newprocid, a.transseq, a.state, a.type, a.iscmntrans,
       a.fromnode, a.tonode, a.condseq, a.actioncondseq, a.loopcnt,
       a.evalorder, a.name
      from trans a
     where svrid = i_svrid
       and procid = i_procid;

    -- table procapp
    insert into procapp
    (
	    svrid, procid, procappseq, type, sendtype,
       keepingflag, viewtype, dmsaveflag, dmidtype, appsvrid,
       appid, orgappid, appver, disporder, name,
       rlvntdataseq, invokedmethod, extname, dmsvrid,
       dmfldrid, dmdockind, dscpt
    )
    select
	    a.svrid, i_newprocid, a.procappseq, a.type, a.sendtype,
       a.keepingflag, a.viewtype, a.dmsaveflag, a.dmidtype, a.appsvrid,
       a.appid, a.orgappid, a.appver, a.disporder, a.name,
       a.rlvntdataseq, a.invokedmethod, a.extname, a.dmsvrid,
       a.dmfldrid, a.dmdockind, a.dscpt
      from procapp a
     where svrid = i_svrid
       and procid = i_procid;

    -- table actapp
    insert into actapp
    (
    	svrid, procid, actseq, actappseq, updatable,
       initoption, viewtype, jobseq, procappseq, appsvrid,
       appid, appver, inrlvntdataseq, outrlvntdataseq,
       modifydtime
    )
    select
		a.svrid, i_newprocid, a.actseq, a.actappseq, a.updatable,
       a.initoption, a.viewtype, a.jobseq, a.procappseq, a.appsvrid,
       a.appid, a.appver, a.inrlvntdataseq, a.outrlvntdataseq,
       a.modifydtime
    from actapp a
        where svrid = i_svrid
        and procid = i_procid;

    -- table cond
    insert into cond
    (
	    svrid, procid, condseq, type, dscpt, expr
	)
    select
	    a.svrid, i_newprocid, a.condseq, a.type, a.dscpt, a.expr
      from cond a
     where svrid = i_svrid
       and procid = i_procid;

    -- table event
    insert into event
    (
	    svrid, procid, actseq, eventseq, triggerpoint,
       eventtype, msgimpltype, sendapp, sendattach, sendcmnt,
       timertype, tonode, transseq, startactseq, timertime,
       rlvntdataseq, subsvrid, subprocdefid, suborgprocdefid,
       dscpt, linkid, eraid
	)
    select
	    a.svrid, i_newprocid, a.actseq, a.eventseq, a.triggerpoint,
       a.eventtype, a.msgimpltype, a.sendapp, a.sendattach, a.sendcmnt,
       a.timertype, a.tonode, a.transseq, a.startactseq, a.timertime,
       a.rlvntdataseq, a.subsvrid, a.subprocdefid, a.suborgprocdefid,
       a.dscpt, a.linkid, a.eraid
      from event a
     where svrid = i_svrid
       and procid = i_procid;

    If l_taskcnt > 0 Then
	    -- table rlvntdata
	    insert into rlvntdata
	    (
			svrid, procid, rlvntdataseq, ispublic, scope,
	       valuetype, parentinouttype, rlvntdataname, dispvalue,
	       dscpt, value, indexvalue
	    )
	    select
		    a.svrid, i_newprocid, a.rlvntdataseq, a.ispublic, a.scope,
	       a.valuetype, a.parentinouttype, a.rlvntdataname, a.dispvalue,
	       a.dscpt, a.value, a.indexvalue
	     from rlvntdata a
	     where svrid = i_svrid
	       and procid = i_procid
	       and rlvntdataname not in ('taskid', 'displayid');
    Else
	    -- table rlvntdata
	    insert into rlvntdata
	    (
			svrid, procid, rlvntdataseq, ispublic, scope,
	       valuetype, parentinouttype, rlvntdataname, dispvalue,
	       dscpt, value, indexvalue
	    )
	    select
		    a.svrid, i_newprocid, a.rlvntdataseq, a.ispublic, a.scope,
	       a.valuetype, a.parentinouttype, a.rlvntdataname, a.dispvalue,
	       a.dscpt, a.value, a.indexvalue
	     from rlvntdata a
	     where svrid = i_svrid
	       and procid = i_procid;
    End if;

    -- table param
    insert into param
    (
	    svrid, procid, actseq, paramseq, inouttype, toscope,
       rlvntdataseq, disporder, todataname, const
    )
    select
	    a.svrid, i_newprocid, a.actseq, a.paramseq, a.inouttype, a.toscope,
       a.rlvntdataseq, a.disporder, a.todataname, a.const
      from param a
     where svrid = i_svrid
       and procid = i_procid;

	-- table respgrp
	insert into respgrp
	(
        svrid, procid, respgrpseq, name, dscpt
	)
	select
        a.svrid, i_newprocid, a.respgrpseq, a.name, a.dscpt
	 from respgrp a
	where svrid = i_svrid
	  and procid = i_procid;

	-- table resp
	insert into resp
	(
        svrid, procid, respgrpseq, respseq, disporder,
       respinfo, name
	)
	select
        a.svrid, i_newprocid, a.respgrpseq, a.respseq, a.disporder,
       a.respinfo, a.name
	 from resp a
	where svrid = i_svrid
	  and procid = i_procid;

    If l_taskcnt > 0 Then
		-- table mdata
		insert into mdata
		(
			svrid, procid, mdataseq, objtype, objsubtype,
	       valuetype, objseq, mdinfo, orgmdtmpltid, mditemseq,
	       name, value, dscpt
		)
		select
	        a.svrid, i_newprocid, a.mdataseq, a.objtype, a.objsubtype,
	       a.valuetype, a.objseq, a.mdinfo, a.orgmdtmpltid, a.mditemseq,
	       a.name, a.value, a.dscpt
		 from mdata a
		where svrid = i_svrid
		  and procid = i_procid
          and name <> 'taskid';
    Else
		-- table mdata
		insert into mdata
		(
			svrid, procid, mdataseq, objtype, objsubtype,
	       valuetype, objseq, mdinfo, orgmdtmpltid, mditemseq,
	       name, value, dscpt
		)
		select
	        a.svrid, i_newprocid, a.mdataseq, a.objtype, a.objsubtype,
	       a.valuetype, a.objseq, a.mdinfo, a.orgmdtmpltid, a.mditemseq,
	       a.name, a.value, a.dscpt
		 from mdata a
		where svrid = i_svrid
		  and procid = i_procid;
    End if;

	-- table witem
	insert into witem
	(
		svrid, procid, witemseq, prtcptype, onasync, state,
       urgent, existinfofile, checkpostcond, actseq, priority,
       respgrpseq, respseq, deadline, prtcp, prtcpname,
       creationdtime, loopcnt, cmpltusr, calmemberid,
       startdtime, cmpltdtime, deadlinedtime, cmpltusrname,
       checkoutusr
	)
	select
        a.svrid, i_newprocid, a.witemseq, a.prtcptype, a.onasync, a.state,
       a.urgent, a.existinfofile, a.checkpostcond, a.actseq, a.priority,
       a.respgrpseq, a.respseq, a.deadline, a.prtcp, a.prtcpname,
       a.creationdtime, a.loopcnt, a.cmpltusr, a.calmemberid,
       a.startdtime, a.cmpltdtime, a.deadlinedtime, a.cmpltusrname,
       a.checkoutusr
	 from witem a
	where svrid = i_svrid
	  and procid = i_procid;

	-- table witemapp
	insert into witemapp
	(
		svrid, procid, witemseq, witemappseq, state, pkitype,
       procappseq, actappseq, actseq, mapid, appver,
       appsvrid, appid, prtcp, prtcpname, modifydtime
	)
	select
        a.svrid, i_newprocid, a.witemseq, a.witemappseq, a.state, a.pkitype,
       a.procappseq, a.actappseq, a.actseq, a.mapid, a.appver,
       a.appsvrid, a.appid, a.prtcp, a.prtcpname, a.modifydtime
	 from witemapp a
	where svrid = i_svrid
	  and procid = i_procid;

	-- table deadline
	insert into deadline
	(
		svrid, procid, deadlineseq, deadlinetype, resptype,
       chkoutid, actseq, actappseq, witemseq, excptseq,
       deadline, incvalue, startdtime, enddtime, nextdtime,
       interval, errno, calmemberid, receiver, email,
       exename, subject, msg
	)
	select
        a.svrid, i_newprocid, a.deadlineseq, a.deadlinetype, a.resptype,
       a.chkoutid, a.actseq, a.actappseq, a.witemseq, a.excptseq,
       a.deadline, a.incvalue, a.startdtime, a.enddtime, a.nextdtime,
       a.interval, a.errno, a.calmemberid, a.receiver, a.email,
       a.exename, a.subject, a.msg
	 from deadline a
	where svrid = i_svrid
	  and procid = i_procid;

	-- table attach
	insert into attach
	(
		svrid, procid, attachseq, witemseq, correspondenceseq, type, sendtype, gettype,
       pkitype, dmdocrtype, actseq, mapid, creationdtime,
       creator, creatorname, attachsize, dispname, filename,
       actname, dmsvrid, dmdocid, dmdockind, dscpt, category
	)
	select
        a.svrid, i_newprocid, a.attachseq, a.witemseq, a.correspondenceseq, a.type, a.sendtype, a.gettype,
       a.pkitype, a.dmdocrtype, a.actseq, a.mapid, a.creationdtime,
       a.creator, a.creatorname, a.attachsize, a.dispname, a.filename,
       a.actname, a.dmsvrid, a.dmdocid, a.dmdockind, a.dscpt, a.category
	 from attach a
	where svrid = i_svrid
	  and procid = i_procid;

	-- table cmnt
	insert into cmnt
	(
		svrid, procid, cmntseq, gettype, sendtype, witemseq,
		parentcmntseq, type, actseq, modifydtime,
       creationdtime, creator, creatorname, jobtitleid,
       jobtitlename, deptid, deptname, actname, contents
	)
	select
        a.svrid, i_newprocid, a.cmntseq, a.gettype, a.sendtype, a.witemseq,
        a.parentcmntseq, a.type, a.actseq, a.modifydtime,
       a.creationdtime, a.creator, a.creatorname, a.jobtitleid,
       a.jobtitlename, a.deptid, a.deptname, a.actname, a.contents
	 from cmnt a
	where svrid = i_svrid
	  and procid = i_procid;

	-- table witemti
	insert into witemti
	(
		svrid, procid, witemseq, fromseq, state, actseq
	)
	select
        a.svrid, i_newprocid, a.witemseq, a.fromseq, a.state, a.actseq
	 from witemti a
	where svrid = i_svrid
	  and procid = i_procid;

	-- table cbdata
	insert into cbdata
	(
		svrid, procid, actseq, providerid, mapid, callbackid
	)
	select
        a.svrid, i_newprocid, a.actseq, a.providerid, a.mapid, a.callbackid
	 from cbdata a
	where svrid = i_svrid
	  and procid = i_procid;

	-- table va_appmap
	insert into va_appmap
	(
		svrid, procid, appinstid, type, mapid, internalid,
       lastappverseq, dmver, dmsvrid, dmdocid, appsvrid,
       appid
	)
	select
        a.svrid, i_newprocid, a.appinstid, a.type, a.mapid, a.internalid,
       a.lastappverseq, a.dmver, a.dmsvrid, a.dmdocid, a.appsvrid,
       a.appid
	 from va_appmap a
	where svrid = i_svrid
	  and procid = i_procid;

	-- table va_appvermap
	insert into va_appvermap
	(
		svrid, procid, appinstid, appverseq, actseq,
       actappseq, mapid, dmver, prtcp, dmsvrid, dmdocid,
       modifydtime, appsvrid, appid, dmverlabel, prtcpname
	)
	select
        a.svrid, i_newprocid, a.appinstid, a.appverseq, a.actseq,
       a.actappseq, a.mapid, a.dmver, a.prtcp, a.dmsvrid, a.dmdocid,
       a.modifydtime, a.appsvrid, a.appid, a.dmverlabel, a.prtcpname
	 from va_appvermap a
	where svrid = i_svrid
	  and procid = i_procid;

	-- table va_verlink
	insert into va_verlink
	(
		svrid, procid, appinstid, appverseqfrom, appverseqto
	)
	select
        a.svrid, i_newprocid, a.appinstid, a.appverseqfrom, a.appverseqto
	 from va_verlink a
	where svrid = i_svrid
	  and procid = i_procid;

	-- table auditinfo
	insert into auditinfo
	(
		svrid, procid, execseq, event, objtype, objstate,
       execdtime, errno, actor, actorname, objname, objseq,
       witemappseq, respgrpseq, respseq, resp, appname,
       objdscpt
	)
	select
        a.svrid, i_newprocid, a.execseq, a.event, a.objtype, a.objstate,
       a.execdtime, a.errno, a.actor, a.actorname, a.objname, a.objseq,
       a.witemappseq, a.respgrpseq, a.respseq, a.resp, a.appname,
       a.objdscpt
	 from auditinfo a
	where svrid = i_svrid
	  and procid = i_procid;

	-- table Correspondence
--	INSERT INTO Correspondence(SvrID,ProcID,CorrespondenceSeq,ActSeq,TaskID,SubTaskID,CreationDTime,ParentTaskID,OrgProcID,OrgActSeq,Type,mediatype,creator,creatorname,readDTime,reader,readername,registerdtime,registrant,registrantname,FromUser,ToUser,CCUser,SentDate,Subject,BodyContent)
--	SELECT SvrID,i_newprocid,CorrespondenceSeq,ActSeq,TaskID,SubTaskID,CreationDTime,ParentTaskID,OrgProcID,OrgActSeq,Type,mediatype,creator,creatorname,readDTime,reader,readername,registerdtime,registrant,registrantname,FromUser,ToUser,CCUser,SentDate,Subject,BodyContent
--	  FROM Correspondence
--	 WHERE svrid = i_svrid AND procid = i_procid;

	-- table procslink
--	INSERT INTO procslink(svrid,procid,linkedprocid,creationdtime,creator,creatorname)
--	SELECT svrid,i_newprocid,linkedprocid,creationdtime,creator,creatorname
--	  FROM procslink
--	 WHERE svrid = i_svrid AND procid = i_procid;

    -- OfficeEngine tables
--    If l_taskcnt > 0 Then
--	    SP_GET_ID (i_svrid, 'taskid', 1, l_newtaskid);
--        SELECT TaskID, replace(customid, to_char(TaskID), to_char(l_newtaskid)) INTO l_taskid, l_customid FROM v_Tasks WHERE ProcID = i_procid;

	    -- table act
--	    insert into act
--		(
--			svrid, procid, actseq, type, jointype, casetype,
--	       deadlinetype, transtype, caltype, existinfofile,
--	       existcmntrans, isrepsign, subproctype, sendapp,
--	       sendattach, sendcmnt, attaddcnt, state, prestate,
--	       checkpostcond, cmpltopt, rbackopt, eventtype,
--	       actlooptype, defsvrid, defprocdefid, name, priority,
--	       actauth, actinfo, deadline, respgrpseq, respseq,
--	       capacity, cost, providerid, loopcnt, cmpltcnt,
--	       spcfromnode, waitingtime, workingtime, planstarttime,
--	       plancmplttime, subsvrid, subprocdefid, suborgprocdefid,
--	       postcondseq, mergecondseq, splitcondseq, dscpt,
--	       resplist, planstartdtime, plancmpltdtime, startdtime,
--	       cmpltdtime, deadlinedtime
--		)
--		select
--			a.svrid, i_newprocid, a.actseq, a.type, a.jointype, a.casetype,
--	       a.deadlinetype, a.transtype, a.caltype, a.existinfofile,
--	       a.existcmntrans, a.isrepsign, a.subproctype, a.sendapp,
--	       a.sendattach, a.sendcmnt, a.attaddcnt, a.state, a.prestate,
--	       a.checkpostcond, a.cmpltopt, a.rbackopt, a.eventtype,
--	       a.actlooptype, a.defsvrid, a.defprocdefid, replace(a.name, to_char(l_taskid), to_char(l_newtaskid)), a.priority,
--	       a.actauth, a.actinfo, a.deadline, a.respgrpseq, a.respseq,
--	       a.capacity, a.cost, a.providerid, a.loopcnt, a.cmpltcnt,
--	       a.spcfromnode, a.waitingtime, a.workingtime, a.planstarttime,
--	       a.plancmplttime, a.subsvrid, a.subprocdefid, a.suborgprocdefid,
--	       a.postcondseq, a.mergecondseq, a.splitcondseq, a.dscpt,
--	       a.resplist, a.planstartdtime, a.plancmpltdtime, a.startdtime,
--	       a.cmpltdtime, a.deadlinedtime
--		from act a
--			where a.svrid = i_svrid
--			and a.procid = i_procid;

	    -- table rlvntdata
--	    insert into rlvntdata ( svrid, procid, rlvntdataseq, ispublic, scope, valuetype, parentinouttype, rlvntdataname, dscpt, value )
--	    select a.svrid, i_newprocid,  a.rlvntdataseq, a.ispublic, a.scope, a.valuetype, a.parentinouttype, a.rlvntdataname, a.dscpt,
--	       case when a.rlvntdataname = 'taskid' then to_char(l_taskid) else l_customid end
--	     from rlvntdata a
--	     where svrid = i_svrid
--	       and procid = i_procid
--	       and a.rlvntdataname in ('taskid', 'displayid');

		-- table mdata
--		insert into mdata
--		(
--			svrid, procid, mdataseq, objtype, objsubtype,
--	       valuetype, objseq, mdinfo, orgmdtmpltid, mditemseq,
--	       name, value, dscpt
--		)
--		select
--	        a.svrid, i_newprocid, a.mdataseq, a.objtype, a.objsubtype,
--	       a.valuetype, a.objseq, a.mdinfo, a.orgmdtmpltid, a.mditemseq,
--	       a.name, replace(a.value, to_char(l_taskid), to_char(l_newtaskid)), a.dscpt
--		 from mdata a
--		where svrid = i_svrid
--		  and procid = i_procid
--          and name = 'taskid';

--        INSERT INTO Tasks(TaskID,ProcID,ActSeq,finalrevieweractseq,AllActSeqs,originatortype,Originator,OriginatorName,finalreviewertype,FinalReviewer,FinalReviewerName,Source,taskinitiatortype,TaskInitiator,TaskInitiatorName,CreationDT,StartDate,DueDate,EndDate,Title,Description,Priority,Category1,Category2,State,AssignorText1,AssignorLookup1,ver,customid,TaskInfoID,emailSender,showcorrespondence)
--		     SELECT l_newtaskid,i_newprocid,ActSeq,finalrevieweractseq,AllActSeqs,originatortype,Originator,OriginatorName,finalreviewertype,FinalReviewer,FinalReviewerName,Source,taskinitiatortype,TaskInitiator,TaskInitiatorName,CreationDT,StartDate,DueDate,EndDate,Title,Description,Priority,Category1,Category2,State,AssignorText1,AssignorLookup1,ver,l_customid,l_newtaskid,emailSender,showcorrespondence FROM Tasks WHERE TaskID = l_taskid;
--		INSERT INTO TasksAux(TaskID,customNumber1,customNumber2,customNumber3,customNumber4,customNumber5,customNumber6,customNumber7,customNumber8,customNumber9,customNumber10,customNumber11,customNumber12,customNumber13,customNumber14,customNumber15,customNumber16,customNumber17,customNumber18,customNumber19,customNumber20,customDate1,customDate2,customDate3,customDate4,customDate5,customDate6,customDate7,customDate8,customDate9,customDate10,customDate11,customDate12,customDate13,customDate14,customDate15,customDate16,customDate17,customDate18,customDate19,customDate20,customString1,customString2,customString3,customString4,customString5,customString6,customString7,customString8,customString9,customString10,customString11,customString12,customString13,customString14,customString15,customString16,customString17,customString18,customString19,customString20,customString21,customString22,customString23,customString24,customString25,customString26,customString27,customString28,customString29,customString30)
--			SELECT l_newtaskid,customNumber1,customNumber2,customNumber3,customNumber4,customNumber5,customNumber6,customNumber7,customNumber8,customNumber9,customNumber10,customNumber11,customNumber12,customNumber13,customNumber14,customNumber15,customNumber16,customNumber17,customNumber18,customNumber19,customNumber20,customDate1,customDate2,customDate3,customDate4,customDate5,customDate6,customDate7,customDate8,customDate9,customDate10,customDate11,customDate12,customDate13,customDate14,customDate15,customDate16,customDate17,customDate18,customDate19,customDate20,customString1,customString2,customString3,customString4,customString5,customString6,customString7,customString8,customString9,customString10,customString11,customString12,customString13,customString14,customString15,customString16,customString17,customString18,customString19,customString20,customString21,customString22,customString23,customString24,customString25,customString26,customString27,customString28,customString29,customString30
--	        FROM TasksAux  WHERE TaskID = l_taskid;
--        INSERT INTO CompleteTasks(TaskID,ProcID,ActSeq,finalrevieweractseq,AllActSeqs,originatortype,Originator,OriginatorName,finalreviewertype,FinalReviewer,FinalReviewerName,Source,taskinitiatortype,TaskInitiator,TaskInitiatorName,CreationDT,StartDate,DueDate,EndDate,Title,Description,Priority,Category1,Category2,State,AssignorText1,AssignorLookup1,ver,customid,TaskInfoID,emailSender,showcorrespondence)
--		     SELECT l_newtaskid,i_newprocid,ActSeq,finalrevieweractseq,AllActSeqs,originatortype,Originator,OriginatorName,finalreviewertype,FinalReviewer,FinalReviewerName,Source,taskinitiatortype,TaskInitiator,TaskInitiatorName,CreationDT,StartDate,DueDate,EndDate,Title,Description,Priority,Category1,Category2,State,AssignorText1,AssignorLookup1,ver,l_customid,l_newtaskid,emailSender,showcorrespondence FROM CompleteTasks WHERE TaskID = l_taskid;
--		INSERT INTO CompleteTasksAux(TaskID,customNumber1,customNumber2,customNumber3,customNumber4,customNumber5,customNumber6,customNumber7,customNumber8,customNumber9,customNumber10,customNumber11,customNumber12,customNumber13,customNumber14,customNumber15,customNumber16,customNumber17,customNumber18,customNumber19,customNumber20,customDate1,customDate2,customDate3,customDate4,customDate5,customDate6,customDate7,customDate8,customDate9,customDate10,customDate11,customDate12,customDate13,customDate14,customDate15,customDate16,customDate17,customDate18,customDate19,customDate20,customString1,customString2,customString3,customString4,customString5,customString6,customString7,customString8,customString9,customString10,customString11,customString12,customString13,customString14,customString15,customString16,customString17,customString18,customString19,customString20,customString21,customString22,customString23,customString24,customString25,customString26,customString27,customString28,customString29,customString30)
--			SELECT l_newtaskid,customNumber1,customNumber2,customNumber3,customNumber4,customNumber5,customNumber6,customNumber7,customNumber8,customNumber9,customNumber10,customNumber11,customNumber12,customNumber13,customNumber14,customNumber15,customNumber16,customNumber17,customNumber18,customNumber19,customNumber20,customDate1,customDate2,customDate3,customDate4,customDate5,customDate6,customDate7,customDate8,customDate9,customDate10,customDate11,customDate12,customDate13,customDate14,customDate15,customDate16,customDate17,customDate18,customDate19,customDate20,customString1,customString2,customString3,customString4,customString5,customString6,customString7,customString8,customString9,customString10,customString11,customString12,customString13,customString14,customString15,customString16,customString17,customString18,customString19,customString20,customString21,customString22,customString23,customString24,customString25,customString26,customString27,customString28,customString29,customString30
--	        FROM CompleteTasksAux  WHERE TaskID = l_taskid;

--        INSERT INTO SubTasks(TaskID,SubTaskID,ParentTaskID,ProcID,ActSeq,AllActSeqs,TransSeq,alttransseq,ConnectorSeq,RouteBack,groupoption,WBS,taskinitiatortype ,TaskInitiator,TaskInitiatorName,initiateuser,initiateusername,assigneetype ,Assignee,AssigneeName,ExternalUser,StartDate,DueDate,EndDate,Title,Description,AllParentActSeqs,InheritHistoryActSeqs,Priority,State,AssigneeText1,AssigneeLookup1,ver,customid,TaskInfoID,SubTaskInfoID,emailSender,showcorrespondence)
--		     SELECT l_newtaskid,SubTaskID,ParentTaskID,i_newprocid,ActSeq,AllActSeqs,TransSeq,alttransseq,ConnectorSeq,RouteBack,groupoption,replace(WBS, to_char(TaskID), to_char(l_newtaskid)),taskinitiatortype ,TaskInitiator,TaskInitiatorName,initiateuser,initiateusername,assigneetype ,Assignee,AssigneeName,ExternalUser,StartDate,DueDate,EndDate,Title,Description,AllParentActSeqs,InheritHistoryActSeqs,Priority,State,AssigneeText1,AssigneeLookup1,ver,replace(customid, to_char(TaskID), to_char(l_newtaskid)),l_newtaskid,SubTaskInfoID,emailSender,showcorrespondence FROM SubTasks WHERE TaskID = l_taskid;
--	    INSERT INTO SubTasksAux(TaskID,SubTaskID,customNumber1,customNumber2,customNumber3,customNumber4,customNumber5,customNumber6,customNumber7,customNumber8,customNumber9,customNumber10,customNumber11,customNumber12,customNumber13,customNumber14,customNumber15,customNumber16,customNumber17,customNumber18,customNumber19,customNumber20,customDate1,customDate2,customDate3,customDate4,customDate5,customDate6,customDate7,customDate8,customDate9,customDate10,customDate11,customDate12,customDate13,customDate14,customDate15,customDate16,customDate17,customDate18,customDate19,customDate20,customString1,customString2,customString3,customString4,customString5,customString6,customString7,customString8,customString9,customString10,customString11,customString12,customString13,customString14,customString15,customString16,customString17,customString18,customString19,customString20,customString21,customString22,customString23,customString24,customString25,customString26,customString27,customString28,customString29,customString30)
--			SELECT l_newtaskid,SubTaskID,customNumber1,customNumber2,customNumber3,customNumber4,customNumber5,customNumber6,customNumber7,customNumber8,customNumber9,customNumber10,customNumber11,customNumber12,customNumber13,customNumber14,customNumber15,customNumber16,customNumber17,customNumber18,customNumber19,customNumber20,customDate1,customDate2,customDate3,customDate4,customDate5,customDate6,customDate7,customDate8,customDate9,customDate10,customDate11,customDate12,customDate13,customDate14,customDate15,customDate16,customDate17,customDate18,customDate19,customDate20,customString1,customString2,customString3,customString4,customString5,customString6,customString7,customString8,customString9,customString10,customString11,customString12,customString13,customString14,customString15,customString16,customString17,customString18,customString19,customString20,customString21,customString22,customString23,customString24,customString25,customString26,customString27,customString28,customString29,customString30
--	        FROM SubTasksAux WHERE TaskID = l_taskid;
--        INSERT INTO CompleteSubTasks(TaskID,SubTaskID,ParentTaskID,ProcID,ActSeq,AllActSeqs,TransSeq,alttransseq,ConnectorSeq,RouteBack,groupoption,WBS,taskinitiatortype ,TaskInitiator,TaskInitiatorName,initiateuser,initiateusername,assigneetype ,Assignee,AssigneeName,ExternalUser,StartDate,DueDate,EndDate,Title,Description,AllParentActSeqs,InheritHistoryActSeqs,Priority,State,AssigneeText1,AssigneeLookup1,ver,customid,TaskInfoID,SubTaskInfoID,emailSender,showcorrespondence)
--		     SELECT l_newtaskid,SubTaskID,ParentTaskID,i_newprocid,ActSeq,AllActSeqs,TransSeq,alttransseq,ConnectorSeq,RouteBack,groupoption,replace(WBS, to_char(TaskID), to_char(l_newtaskid)),taskinitiatortype ,TaskInitiator,TaskInitiatorName,initiateuser,initiateusername,assigneetype ,Assignee,AssigneeName,ExternalUser,StartDate,DueDate,EndDate,Title,Description,AllParentActSeqs,InheritHistoryActSeqs,Priority,State,AssigneeText1,AssigneeLookup1,ver,replace(customid, to_char(TaskID), to_char(l_newtaskid)),l_newtaskid,SubTaskInfoID,emailSender,showcorrespondence FROM CompleteSubTasks WHERE TaskID = l_taskid;
--	    INSERT INTO CompleteSubTasksAux(TaskID,SubTaskID,customNumber1,customNumber2,customNumber3,customNumber4,customNumber5,customNumber6,customNumber7,customNumber8,customNumber9,customNumber10,customNumber11,customNumber12,customNumber13,customNumber14,customNumber15,customNumber16,customNumber17,customNumber18,customNumber19,customNumber20,customDate1,customDate2,customDate3,customDate4,customDate5,customDate6,customDate7,customDate8,customDate9,customDate10,customDate11,customDate12,customDate13,customDate14,customDate15,customDate16,customDate17,customDate18,customDate19,customDate20,customString1,customString2,customString3,customString4,customString5,customString6,customString7,customString8,customString9,customString10,customString11,customString12,customString13,customString14,customString15,customString16,customString17,customString18,customString19,customString20,customString21,customString22,customString23,customString24,customString25,customString26,customString27,customString28,customString29,customString30)
--			SELECT l_newtaskid,SubTaskID,customNumber1,customNumber2,customNumber3,customNumber4,customNumber5,customNumber6,customNumber7,customNumber8,customNumber9,customNumber10,customNumber11,customNumber12,customNumber13,customNumber14,customNumber15,customNumber16,customNumber17,customNumber18,customNumber19,customNumber20,customDate1,customDate2,customDate3,customDate4,customDate5,customDate6,customDate7,customDate8,customDate9,customDate10,customDate11,customDate12,customDate13,customDate14,customDate15,customDate16,customDate17,customDate18,customDate19,customDate20,customString1,customString2,customString3,customString4,customString5,customString6,customString7,customString8,customString9,customString10,customString11,customString12,customString13,customString14,customString15,customString16,customString17,customString18,customString19,customString20,customString21,customString22,customString23,customString24,customString25,customString26,customString27,customString28,customString29,customString30
--	        FROM CompleteSubTasksAux  WHERE TaskID = l_taskid;

--	    INSERT INTO Responses(TaskID,SubTaskID,AssigneeResponse,InitiatorResponse)
--		     SELECT l_newtaskid,SubTaskID,AssigneeResponse,InitiatorResponse FROM Responses WHERE TaskID = l_taskid;
--	    INSERT INTO CompleteResponses(TaskID,SubTaskID,AssigneeResponse,InitiatorResponse)
--		     SELECT l_newtaskid,SubTaskID,AssigneeResponse,InitiatorResponse FROM CompleteResponses WHERE TaskID = l_taskid;

--	    INSERT INTO DTaskerAudit(TaskID, SubTaskID,Seq,FromName,FromGroupName,ToName,FromID,FromGroupID,ToID,CreationDT,ValueType,Value)
--		     SELECT l_newtaskid, SubTaskID,Seq,FromName,FromGroupName,ToName,FromID,FromGroupID,ToID,CreationDT,ValueType,Value FROM DTaskerAudit WHERE TaskID = l_taskid;
--	    INSERT INTO CompleteDTaskerAudit(TaskID, SubTaskID,Seq,FromName,FromGroupName,ToName,FromID,FromGroupID,ToID,CreationDT,ValueType,Value)
--		     SELECT l_newtaskid, SubTaskID,Seq,FromName,FromGroupName,ToName,FromID,FromGroupID,ToID,CreationDT,ValueType,Value FROM CompleteDTaskerAudit WHERE TaskID = l_taskid;

--	    INSERT INTO TaskAssociation(TaskID,SubTaskID,ProcID,ActSeq,WitemSeq)
--		     SELECT l_newtaskid,SubTaskID,i_parentprocid,ActSeq,WitemSeq FROM TaskAssociation WHERE TaskID = l_taskid;
--	    INSERT INTO CompleteTaskAssociation(TaskID,SubTaskID,ProcID,ActSeq,WitemSeq)
--		     SELECT l_newtaskid,SubTaskID,i_parentprocid,ActSeq,WitemSeq FROM CompleteTaskAssociation WHERE TaskID = l_taskid;

--	    INSERT INTO taskprtcp(taskid,subtaskid,prtcp,type,kind,externaluser)
--		     SELECT l_newtaskid,subtaskid,prtcp,type,kind,externaluser FROM taskprtcp WHERE TaskID = l_taskid;
--	    INSERT INTO completetaskprtcp(taskid,subtaskid,prtcp,type,kind,externaluser)
--		     SELECT l_newtaskid,subtaskid,prtcp,type,kind,externaluser FROM completetaskprtcp WHERE TaskID = l_taskid;

--		INSERT INTO taskapprovers(taskid,seq,type,prtcp,name)
--			SELECT l_newtaskid,seq,type,prtcp,name FROM taskapprovers WHERE TaskID = l_taskid;
--		INSERT INTO completetaskapprovers(taskid,seq,type,prtcp,name)
--			SELECT l_newtaskid,seq,type,prtcp,name FROM completetaskapprovers  WHERE TaskID = l_taskid;
--    End if;

    -- QuickProcess tables
--    SELECT Count(1) INTO l_cnt FROM plantask WHERE procid = i_procid;
--    If l_cnt > 0 Then
--		INSERT INTO plantask(procid, taskid, disporder, stepname, duedtime, deadlinetype, deadline, allowcollab, allowmoretask, allowreject, allowgoaladd, allowgoaldelete, allowgoalcheck, allowflowedit, allowprocend, dscpt, instruction, prtcptype, prtcp, prtcpname, category1, category2, selfnote, rate, ratecmnt, reminderdtime, reminderstate, actseq)
--		SELECT i_newprocid, taskid, disporder, stepname, duedtime, deadlinetype, deadline, allowcollab, allowmoretask, allowreject, allowgoaladd, allowgoaldelete, allowgoalcheck, allowflowedit, allowprocend, dscpt, instruction, prtcptype, prtcp, prtcpname, category1, category2, selfnote, rate, ratecmnt, reminderdtime, reminderstate, actseq
--        FROM plantask
--        WHERE procid = i_procid;

--		INSERT INTO plangoal(goalid, name, disporder, state, creationdtime, creator, creatorname, modifydtime, modifier, modifiername, dscpt, procid, taskid)
--		SELECT goalid, name, disporder, state, creationdtime, creator, creatorname, modifydtime, modifier, modifiername, dscpt, i_newprocid, taskid
--        FROM plangoal
--        WHERE procid = i_procid;

--		INSERT INTO plantasklimitedassignee(procid, taskid, taskassigneeid, assigneetype, assignee, assigneename)
--		SELECT i_newprocid, taskid, taskassigneeid, assigneetype, assignee, assigneename
--        FROM plantasklimitedassignee
--        WHERE procid = i_procid;

--		INSERT INTO planprtcp(procid, prtcpkind, prtcpid, prtcptype, prtcp, prtcpname, cmnt)
--		SELECT i_newprocid, prtcpkind, prtcpid, prtcptype, prtcp, prtcpname, cmnt
--        FROM planprtcp
--        WHERE procid = i_procid;

--		INSERT INTO planreminder(procid, prtcpkind, prtcpid, taskid, reminderid, name, value, resid, type, days, hours, mins)
--		SELECT i_newprocid, prtcpkind, prtcpid, taskid, reminderid, name, value, resid, type, days, hours, mins
--        FROM planreminder
--        WHERE procid = i_procid;

--		INSERT INTO plantaskaux(procid, taskid, customnumber1, customnumber2, customnumber3, customnumber4, customnumber5, customnumber6, customnumber7, customnumber8, customdate1, customdate2, customdate3, customdate4, customdate5, customdate6, customdate7, customdate8, customstring1, customstring2, customstring3, customstring4, customstring5, customstring6, customstring7, customstring8, customstring9, customstring10, customstring11, customstring12)
--		SELECT i_newprocid, taskid, customnumber1, customnumber2, customnumber3, customnumber4, customnumber5, customnumber6, customnumber7, customnumber8, customdate1, customdate2, customdate3, customdate4, customdate5, customdate6, customdate7, customdate8, customstring1, customstring2, customstring3, customstring4, customstring5, customstring6, customstring7, customstring8, customstring9, customstring10, customstring11, customstring12
--        FROM plantaskaux
--        WHERE procid = i_procid;

--		INSERT INTO plansubtask(procid, taskid, subtaskid, name, duedtime, guidance, priority, fyi, showhistory)
--		SELECT i_newprocid, taskid, subtaskid, name, duedtime, guidance, priority, fyi, showhistory
--        FROM plansubtask
--        WHERE procid = i_procid;

--		INSERT INTO plansubtaskaux(procid, taskid, subtaskid, customnumber1, customnumber2, customnumber3, customnumber4, customnumber5, customnumber6, customnumber7, customnumber8, customdate1, customdate2, customdate3, customdate4, customdate5, customdate6, customdate7, customdate8, customstring1, customstring2, customstring3, customstring4, customstring5, customstring6, customstring7, customstring8, customstring9, customstring10, customstring11, customstring12)
--		SELECT i_newprocid, taskid, subtaskid, customnumber1, customnumber2, customnumber3, customnumber4, customnumber5, customnumber6, customnumber7, customnumber8, customdate1, customdate2, customdate3, customdate4, customdate5, customdate6, customdate7, customdate8, customstring1, customstring2, customstring3, customstring4, customstring5, customstring6, customstring7, customstring8, customstring9, customstring10, customstring11, customstring12
--        FROM plansubtaskaux
--        WHERE procid = i_procid;

--		INSERT INTO plansubtaskprtcp(procid, taskid, subtaskid, subtaskprtcpid, prtcptype, prtcp, prtcpname, kind, externaluser)
--		SELECT i_newprocid, taskid, subtaskid, subtaskprtcpid, prtcptype, prtcp, prtcpname, kind, externaluser
--        FROM plansubtaskprtcp
--        WHERE procid = i_procid;

--    End if;

exception
    when cannotcopy then
        raise_application_error(-20540, errm);
    when others then
        raise_application_error(-20747, sqlerrm);
end; -- procedure
/
