CREATE procedure          sp_get_mymanager
(
    i_membertype   in  varchar,
    i_memberid     in  varchar,
    o_managerid    out  varchar
)   is
--
-- 12.4.0.0
--

	l_deptid	varchar2(10);
	l_managerid	varchar2(10);

begin
	if i_membertype = 'U' then
	    select deptid into l_deptid from member where memberid = i_memberid;
	else
	    l_deptid := i_memberid;
	end if;

    loop
		select managerid into l_managerid
			from member
			where memberid = l_deptid;

		if l_managerid = '0000000000'
			or l_managerid = i_memberid then
			if l_deptid = '9000000000' then
				l_managerid := '9999999999';
				exit;
			end if;

			select parentdeptid into l_deptid from member
				where memberid = l_deptid;
		else
			exit;
		end if;
    end loop;

    o_managerid := l_managerid;

exception
    when others then
        raise_application_error(-20732, sqlerrm);
end;
/
