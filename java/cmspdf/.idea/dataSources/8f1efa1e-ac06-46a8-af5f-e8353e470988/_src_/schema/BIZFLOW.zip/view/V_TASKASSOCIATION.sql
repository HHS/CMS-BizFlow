CREATE VIEW V_TASKASSOCIATION AS select TaskID, SubTaskID, ProcID, ActSeq, WitemSeq
  from TaskAssociation
UNION ALL
select TaskID, SubTaskID, ProcID, ActSeq, WitemSeq
  from CompleteTaskAssociation
/
