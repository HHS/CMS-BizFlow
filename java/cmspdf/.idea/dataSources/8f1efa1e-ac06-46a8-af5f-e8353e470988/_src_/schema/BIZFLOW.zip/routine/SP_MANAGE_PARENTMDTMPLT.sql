CREATE procedure sp_manage_parentmdtmplt
	(
		i_updatetype		in varchar,
		i_svrid  		in varchar2,
		i_parentmdtmpltid 	in number,
		i_orgmdtmpltid 		in number,
		i_mdtmpltid		in number,
		i_name 			in varchar2,
		i_fldrid		in number
	)
	is
-- 12.4.0.0
	-- get the list of child templates list
	cursor cur_childmdtmplt is
	select m.orgmdtmpltid, m.parentmdtmpltid, m.name from parentmdtmplt p, mdtmplt m
		where m.orgmdtmpltid = p.mdtmpltid
		and m.isfinal = 'T'
		and p.parentmdtmpltid = i_orgmdtmpltid
		and p.svrid = i_svrid;
	l_tmpltcnt			integer;
	l_name				varchar2(100);
	l_parentmdtmpltid		varchar2(10);
	l_orgmdtmpltid			varchar2(10);
	m_orgmdtmpltid			varchar2(10);
	parentiderror   exception;
    	duplicatename   exception;
    	mdtmpltiderr    exception;
    	subinheritance  exception;
    	duplicatemdnameerror exception;
begin
	if(i_updatetype = 'A') then
	-- check if the template is base or not
	   if(i_parentmdtmpltid = 0) then
			select count(*) into l_tmpltcnt from parentmdtmplt;
			if(l_tmpltcnt <> 0) then
				raise parentiderror;
			end if;
	   end if;

		select count(*) into l_tmpltcnt from mdtmplt
				where isfinal = 'T'
					and parentmdtmpltid = i_parentmdtmpltid
					and name = i_name
					and orgmdtmpltid <> i_orgmdtmpltid;
		if(l_tmpltcnt > 0) then
			raise duplicatemdnameerror;
		end if;

	   insert into parentmdtmplt (parentmdtmpltid, mdtmpltid, svrid)
				values(i_parentmdtmpltid, i_orgmdtmpltid, i_svrid);
	-- add all dependency records
	   l_parentmdtmpltid := i_parentmdtmpltid;
	   while(l_parentmdtmpltid <> 0) loop
		select count(*) into l_tmpltcnt from mdtmplt
		where orgmdtmpltid = l_parentmdtmpltid
		and isfinal = 'T';

		if(l_tmpltcnt = 0) then
			raise parentiderror;
		end if;

		l_orgmdtmpltid := l_parentmdtmpltid;
		select parentmdtmpltid , name into l_parentmdtmpltid, l_name  from mdtmplt
		where svrid = i_svrid and orgmdtmpltid = l_orgmdtmpltid and isfinal ='T';

		if(i_name = l_name) then
			raise duplicatename;
		end if;

		if(l_parentmdtmpltid <> 0) then
			insert into parentmdtmplt (parentmdtmpltid, mdtmpltid, svrid)
					values(l_parentmdtmpltid, i_orgmdtmpltid, i_svrid);
		end if;

	   end loop;
	end if;

	if(i_updatetype = 'D') then
	-- check if other templates inherit this template
		select count(*) into l_tmpltcnt from parentmdtmplt
		where parentmdtmpltid = i_orgmdtmpltid and svrid = i_svrid;

		if(l_tmpltcnt <> 0) then
			raise subinheritance;
		end if;
	-- delete all dependency records
		delete from parentmdtmplt where mdtmpltid = i_orgmdtmpltid and svrid = i_svrid;
		delete from fldrmanagerlist where fldrid = i_fldrid;
		delete from fldrlist where fldrid = i_fldrid;
		delete from mditem where mdtmpltid = i_mdtmpltid;
		delete from enumdata where mdtmpltid = i_mdtmpltid;
	end if;

	if(i_updatetype = 'U') then
	-- delete the dependency about old record
		delete from parentmdtmplt
			where svrid = i_svrid
			and mdtmpltid = i_orgmdtmpltid;

	-- insert the modified record
		insert into parentmdtmplt (parentmdtmpltid, mdtmpltid, svrid)
			values(i_parentmdtmpltid, i_orgmdtmpltid, i_svrid);

		l_parentmdtmpltid := i_parentmdtmpltid;

		while(l_parentmdtmpltid <> 0) loop
			select count(1) into l_tmpltcnt from mdtmplt
			where orgmdtmpltid = l_parentmdtmpltid
			and isfinal = 'T';

			if(l_tmpltcnt = 0) then
				raise parentiderror;
			end if;

			l_orgmdtmpltid := l_parentmdtmpltid;
			select parentmdtmpltid, name into l_parentmdtmpltid, l_name from mdtmplt
				where svrid = i_svrid
				and orgmdtmpltid = l_orgmdtmpltid
				and isfinal = 'T';

			if (l_parentmdtmpltid <> 0) then
				insert into parentmdtmplt (parentmdtmpltid, mdtmpltid, svrid)
					values(l_parentmdtmpltid, i_orgmdtmpltid, i_svrid);
			end if;
		end loop;

	-- add the dependency record about the modified record
		open cur_childmdtmplt;
		loop
			fetch cur_childmdtmplt into l_orgmdtmpltid, l_parentmdtmpltid, l_name;
			exit when cur_childmdtmplt%notfound;

			delete from parentmdtmplt
				where svrid = i_svrid
				  and mdtmpltid = l_orgmdtmpltid;

			insert into parentmdtmplt (parentmdtmpltid, mdtmpltid, svrid)
				values(l_parentmdtmpltid, l_orgmdtmpltid, i_svrid);

			while(l_parentmdtmpltid <> 0) loop

				select COUNT(1) into l_tmpltcnt from mdtmplt
				where orgmdtmpltid = l_parentmdtmpltid
				and isfinal = 'T' ;

				if(l_tmpltcnt = 0) then
					raise parentiderror;
				end if;

				m_orgmdtmpltid := l_parentmdtmpltid;
				select parentmdtmpltid, l_name into l_parentmdtmpltid, l_name from mdtmplt
				where svrid = i_svrid
				and orgmdtmpltid = m_orgmdtmpltid
				and isfinal = 'T';

				if (l_parentmdtmpltid <> 0) then
					insert into parentmdtmplt (parentmdtmpltid, mdtmpltid, svrid)
						values(l_parentmdtmpltid, l_orgmdtmpltid,  i_svrid);
				end if;
			end loop;
		end loop;
	end if;
exception
	when parentiderror then
		raise_application_error(-20519, sqlerrm);
	when duplicatename then
		raise_application_error(-20521, sqlerrm);
	when mdtmpltiderr then
		raise_application_error(-20519, sqlerrm);
	when subinheritance then
		raise_application_error(-20520, sqlerrm);
	when duplicatemdnameerror then
		raise_application_error(-20537, sqlerrm);
	when others then
		if cur_childmdtmplt%isopen then
		    close cur_childmdtmplt;
		end if;
		raise_application_error(-20717, sqlerrm);
end;
/
