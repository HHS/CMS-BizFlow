CREATE procedure                  sp_create_ldap_audit
(
	i_pkgid			in	number,
	i_execseq		in	number,
	i_state			in	char,
	i_importdtime	in	date,
	i_actor			in	varchar2
)
IS
--
-- 12.4.0.0
--
	--PARAMNOTENOUGH          EXCEPTION;

	--ERRM                    VARCHAR2(800);
	--nerrno                  number;

BEGIN

	insert into ldapauditinfo
	(
	   packageid,
	   execseq,
	   state,
	   importdtime,
	   importer,
	   importername
	)
	select
		i_pkgid,
		i_execseq,
		i_state,
		i_importdtime,
		i_actor,
		a.name
	from member a
	where a.memberid = i_actor;

	--errm := 'Can''t recognize the Object Type.';
	--raise paramnotenough;

exception
    --when paramnotenough then
    --    raise_application_error(-20505, errm);
    when others then
        raise_application_error(-20741, sqlerrm);
end;
/
