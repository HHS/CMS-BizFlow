CREATE procedure          sp_copy_procdef
(
    i_def_svrid     in varchar2,
    i_def_procdefid in number,
    i_def_fldrsvrid in varchar2,
    i_def_fldrid    in number,
    i_isprojectfolder in number,

    i_def_nsvrid     in varchar2,
    i_def_nprocdefid in number,
    i_def_nfldrsvrid in varchar2,
    i_def_nfldrid    in number,
	i_nisprojectfolder in number,
	i_creator        in varchar2,
    i_creationdtime  in date
)
is
    l_cnt    	number;
    cannotcopy  exception;
    errm    	varchar2(800);
--
-- 12.4.0.0
--
begin
    -- validation of source proc. def.
	if (i_isprojectfolder = 0) then
		-- (source) operational environment.
		select count(1) into l_cnt from procdef
		 where svrid     = i_def_svrid
		   and procdefid = i_def_procdefid
		   and fldrsvrid = i_def_fldrsvrid
		   and fldrid    = i_def_fldrid;
		if (l_cnt <> 1) then
			errm := 'There is no Process Definition in the Folder.';
			raise cannotcopy;
		end if;
	else
		-- (source) project environment.
		select count(1) into l_cnt from procdef
		 where svrid     = i_def_svrid
		   and procdefid = i_def_procdefid
		   and fldrsvrid = i_def_fldrsvrid
		   and prjfldrid    = i_def_fldrid;
		if (l_cnt <> 1) then
			errm := 'There is no Process Definition in the Folder.';
			raise cannotcopy;
		end if;
	end if;

    -- table procdef
	insert into procdef
	(
		svrid, procdefid, verctrltype, deadlinetype, subproctype,
		passwdflag,publicationstate, pkitype, dmsaveflag, dmidtype,
		fldrsvrid,fldrid, ver, instfldrid, archivefldrid,
		name,deadline, creationdtime, creator, creatorname,
		creatordeptname,presvrid, preprocdefid, dmsvrid, dmfldrid,
		dscpt, isfinal, envtype, caltype, prjfldrid, orgprocdefid,
		orgmdtmpltid, usrgrphid, calmemberid, publishdtime, publisher,
		publishername, chkincmnt, procauth, modifydtime, modifier, modifiername
	)
	select
		i_def_nsvrid, i_def_nprocdefid, a.verctrltype, a.deadlinetype, a.subproctype,
		a.passwdflag, a.publicationstate, a.pkitype, a.dmsaveflag, a.dmidtype,
		a.fldrsvrid, a.fldrid, 1, a.instfldrid, a.archivefldrid,
		a.name,a.deadline, i_creationdtime, i_creator, b.name,
		b.deptname, i_def_svrid, i_def_nprocdefid, a.dmsvrid, a.dmfldrid,
		a.dscpt, a.isfinal, a.envtype, a.caltype, a.prjfldrid, a.orgprocdefid,
		a.orgmdtmpltid, a.usrgrphid, a.calmemberid, a.publishdtime,a.publisher,
		a.publishername, '', a.procauth,  a.modifydtime, a.modifier, a.modifiername
	from procdef a, member b
		where a.svrid = i_def_svrid
		and a.procdefid = i_def_procdefid
		and b.memberid = i_creator;

    -- table actdef
    insert into actdef
    (
        svrid,
        procdefid,
        actdefseq,
        type,
        jointype,
        casetype,
        deadlinetype,
        transtype,
        existinfofile,
        existcmntrans,
        isrepsign,
        subproctype,
	    cmpltopt,
	    rbackopt,
		subenvtype,
        sendapp,
        sendattach,
        sendcmnt,
        checkpostcond,
        name,
        priority,
        actauth,
		actinfo,
        deadline,
        respgrpseq,
        respseq,
        capacity,
        cost,
        providerid,
        subsvrid,
        subprocdefid,
        postconddefseq,
        fldrsvrid,
        fldrid,
        waitingtime,
        workingtime,
        planstarttime,
        plancmplttime,
        dscpt,
		caltype,
		suborgprocdefid,
		attaddcnt,
	eventtype,
	actlooptype,
	mergeconddefseq,
	splitconddefseq
	)
    select
        i_def_nsvrid,
        i_def_nprocdefid,
        actdefseq,
        type,
        jointype,
        casetype,
        deadlinetype,
        transtype,
        existinfofile,
        existcmntrans,
        isrepsign,
        subproctype,
	    cmpltopt,
	    rbackopt,
		subenvtype,
        sendapp,
        sendattach,
        sendcmnt,
        checkpostcond,
        name,
        priority,
        actauth,
		actinfo,
        deadline,
        respgrpseq,
        respseq,
        capacity,
        cost,
        providerid,
        subsvrid,
        subprocdefid,
        postconddefseq,
        i_def_nfldrsvrid,
        i_def_nfldrid,
        waitingtime,
        workingtime,
        planstarttime,
        plancmplttime,
        dscpt,
		caltype,
		suborgprocdefid,
		attaddcnt,
	eventtype,
	actlooptype,
	mergeconddefseq,
	splitconddefseq
     from  actdef
        where svrid = i_def_svrid
        and procdefid = i_def_procdefid;

    -- table actloopdef
    insert into actloopdef
    (
        svrid,
        procdefid,
        actdefseq,
        testtime,
        miordering,
        miflowtype,
        loopcnt,
        loopmaxcnt,
        conddefseq,
        miflowconddefseq
		)
    select
        i_def_nsvrid,
        i_def_nprocdefid,
        actdefseq,
        testtime,
        miordering,
        miflowtype,
        loopcnt,
        loopmaxcnt,
        conddefseq,
        miflowconddefseq
     from  actloopdef
        where svrid = i_def_svrid
        and procdefid = i_def_procdefid;

    -- table prtcpdef
    insert into prtcpdef
    (
        svrid,
        procdefid,
        actdefseq,
        prtcpdefseq,
	    kind,
        type,
        assignrule,
        existscriptfile,
		prtcpauth,
        prtcp,
        mapid,
        disporder,
		calmemberid,
		usrgrphid,
        expr
    )
    select
        i_def_nsvrid,
        i_def_nprocdefid,
        actdefseq,
        prtcpdefseq,
	    kind,
        type,
        assignrule,
        existscriptfile,
		prtcpauth,
        prtcp,
        mapid,
        disporder,
		calmemberid,
		usrgrphid,
        expr
     from prtcpdef
     where svrid = i_def_svrid
       and procdefid = i_def_procdefid;

    -- table excptdef
    insert into excptdef
    (
        svrid,
        procdefid,
        excptdefseq,
        type,
        resptype,
        actdefseq,
        actappdefseq,
        incvalue,
        alertstarttime,
        alertduration,
        alertinterval,
        alertreceiver,
        email,
        exename,
		alertsubject,
        alertmsg
    )
    select
        i_def_nsvrid,
        i_def_nprocdefid,
        excptdefseq,
        type,
        resptype,
        actdefseq,
        actappdefseq,
        incvalue,
        alertstarttime,
        alertduration,
        alertinterval,
        alertreceiver,
        email,
        exename,
		alertsubject,
        alertmsg
     from excptdef
     where svrid = i_def_svrid
       and procdefid = i_def_procdefid;

    -- table transdef
    insert into transdef
    (
    	svrid,
	    procdefid,
	    transdefseq,
	    type,
	    iscmntrans,
	    fromnode,
	    tonode,
	    conddefseq,
	    actionconddefseq,
	    evalorder,
	    name
    )
    select
	    i_def_nsvrid,
	    i_def_nprocdefid,
	    transdefseq,
	    type,
	    iscmntrans,
	    fromnode,
	    tonode,
	    conddefseq,
	    actionconddefseq,
	    evalorder,
	    name
      from transdef
     where svrid = i_def_svrid
       and procdefid = i_def_procdefid;

    -- table procappdef
    insert into procappdef
    (
	    svrid,
	    procdefid,
	    procappdefseq,
	    type,
		envtype,
	    sendtype,
	    keepingflag,
	    viewtype,
        dmsaveflag,
        dmidtype,
	    appsvrid,
	    appid,
		orgappid,
	    appver,
	    disporder,
	    name,
	    rlvntdatadefseq,
	    invokedmethod,
	    extname,
        dmsvrid,
        dmfldrid,
        dmdockind,
	    dscpt
    )
    select
	    i_def_nsvrid,
	    i_def_nprocdefid,
	    procappdefseq,
	    type,
		envtype,
	    sendtype,
	    keepingflag,
	    viewtype,
        dmsaveflag,
        dmidtype,
	    appsvrid,
	    appid,
		orgappid,
	    appver,
	    disporder,
	    name,
	    rlvntdatadefseq,
	    invokedmethod,
	    extname,
        dmsvrid,
        dmfldrid,
        dmdockind,
	    dscpt
      from procappdef
     where svrid = i_def_svrid
       and procdefid = i_def_procdefid;

    -- table actappdef
    insert into actappdef
    (
    	svrid,
	    procdefid,
	    actdefseq,
	    actappdefseq,
	    updatable,
	    initoption,
        viewtype,
	    jobseq,
	    procappdefseq,
	    appsvrid,
	    appid,
	    appver,
	    inrlvntdatadefseq,
	    outrlvntdatadefseq
    )
    select
	    i_def_nsvrid,
	    i_def_nprocdefid,
	    actdefseq,
	    actappdefseq,
	    updatable,
	    initoption,
        viewtype,
	    jobseq,
	    procappdefseq,
	    appsvrid,
	    appid,
	    appver,
	    inrlvntdatadefseq,
	    outrlvntdatadefseq
    from actappdef
        where svrid = i_def_svrid
        and procdefid = i_def_procdefid;

    -- table conddef
    insert into conddef
    (
	    svrid,
	    procdefid,
	    conddefseq,
	    type,
	    dscpt,
	    expr
	)
    select
	    i_def_nsvrid,
	    i_def_nprocdefid,
	    conddefseq,
	    type,
	    dscpt,
	    expr
      from conddef
     where svrid = i_def_svrid
       and procdefid = i_def_procdefid;

    -- table eventdef
    insert into eventdef
    (
	    svrid,
	    procdefid,
	    eventdefseq,
	    triggerpoint,
	    eventtype,
	    msgimpltype,
	    sendapp,
	    sendattach,
	    sendcmnt,
	    subsvrid,
	    subprocdefid,
	    suborgprocdefid,
	    timertype,
	    timertime,
	    actdefseq,
	    tonode,
		transdefseq,
	    startactdefseq,
	    rlvntdatadefseq,
			dscpt,
			linkid,
			eraid
		)
    select
	    i_def_nsvrid,
	    i_def_nprocdefid,
	    eventdefseq,
	    triggerpoint,
	    eventtype,
	    msgimpltype,
	    sendapp,
	    sendattach,
	    sendcmnt,
	    subsvrid,
	    subprocdefid,
	    suborgprocdefid,
	    timertype,
	    timertime,actdefseq,
	    tonode,
		transdefseq,
	    startactdefseq,
	    rlvntdatadefseq,
			dscpt,
			linkid,
			eraid
      from eventdef
     where svrid = i_def_svrid
       and procdefid = i_def_procdefid;

    -- table rlvntdatadef
    insert into rlvntdatadef
    (
	    svrid,
    	procdefid,
        rlvntdatadefseq,
    	ispublic,
	    valuetype,
	    rlvntdatadefname,
	    scope,
	    grlvntdataid,
    	value,
        dispvalue,
	    dscpt
    )
    select
	    i_def_nsvrid,
	    i_def_nprocdefid,
        rlvntdatadefseq,
    	ispublic,
	    valuetype,
	    rlvntdatadefname,
	    scope,
	    grlvntdataid,
    	value,
        dispvalue,
	    dscpt
     from rlvntdatadef
     where svrid = i_def_svrid
       and procdefid = i_def_procdefid;

    -- table paramdef
    insert into paramdef
    (
	    svrid,
	    procdefid,
	    actdefseq,
	    paramdefseq,
	    inouttype,
		toscope,
	    rlvntdatadefseq,
	    disporder,
	    todataname,
	    const
    )
    select
	    i_def_nsvrid,
	    i_def_nprocdefid,
	    actdefseq,
	    paramdefseq,
	    inouttype,
		toscope,
	    rlvntdatadefseq,
	    disporder,
	    todataname,
	    const
      from paramdef
     where svrid = i_def_svrid
       and procdefid = i_def_procdefid;

	-- table respgrpdef
	insert into respgrpdef
	(
        svrid,
        procdefid,
        respgrpdefseq,
        name,
        dscpt
	)
	select
        svrid,
        i_def_nprocdefid,
        respgrpdefseq,
        name,
        dscpt
	 from respgrpdef
	where svrid = i_def_svrid
	  and procdefid = i_def_procdefid;

	-- table respdef
	insert into respdef
	(
        svrid,
        procdefid,
        respgrpdefseq,
        respdefseq,
        disporder,
		respinfo,
        name
	)
	select
        svrid,
        i_def_nprocdefid,
        respgrpdefseq,
        respdefseq,
        disporder,
		respinfo,
        name
	 from respdef
	where svrid = i_def_svrid
	  and procdefid = i_def_procdefid;

	-- table mdatadef
	insert into mdatadef
	(
		svrid, procdefid,
		mdatadefseq, objtype, objsubtype, valuetype,
		objseq, mdinfo, orgmdtmpltid, mditemseq, name, dscpt, value
	)
	select
        svrid,
        i_def_nprocdefid,
		mdatadefseq, objtype, objsubtype, valuetype,
		objseq, mdinfo, orgmdtmpltid, mditemseq, name, dscpt, value
	 from mdatadef
	where svrid = i_def_svrid
	  and procdefid = i_def_procdefid;

	-- BEGIN - Add by Kim Kwang Kean for Critical Path. (09/28/2007)
	-- table cpdef
	insert into cpdef
	(
		svrid, procdefid, cpdefseq, value
	)
	select
        svrid, i_def_nprocdefid, cpdefseq, value
	 from cpdef
	where svrid = i_def_svrid
	  and procdefid = i_def_procdefid;
	-- END - Add by Kim Kwang Kean for Critical Path. (09/28/2007)

	if (i_isprojectfolder = 0 and i_nisprojectfolder = 0) then
		-- copy proc.def. in the operational env.
		update procdef
			set fldrsvrid = i_def_nfldrsvrid, fldrid = i_def_nfldrid, orgprocdefid = i_def_nprocdefid,
				ver = 1, isfinal = 'T', prjfldrid = 0
			where svrid = i_def_nsvrid
				and procdefid = i_def_nprocdefid;
	elsif (i_isprojectfolder = 1 and i_nisprojectfolder = 1) then
		-- copy proc.def. in the project env.
		update procdef
			set fldrsvrid = i_def_nfldrsvrid, fldrid = 0, orgprocdefid = i_def_nprocdefid,
				ver = 1, isfinal = 'T', prjfldrid = i_def_nfldrid
			where svrid = i_def_nsvrid
				and procdefid = i_def_nprocdefid;
	elsif (i_isprojectfolder = 0 and i_nisprojectfolder = 1) then
		-- import api(from operational env. to project env.).
		update procdef
			set prjfldrid = i_def_nfldrid
			where svrid = i_def_svrid
				and orgprocdefid = (select orgprocdefid from procdef where svrid = i_def_svrid and procdefid = i_def_procdefid);

		update procdef
			set publicationstate = 'O', ver = ver + 1,
				isfinal = 'T', envtype = 'P'
			where svrid = i_def_nsvrid
				and procdefid = i_def_nprocdefid;
	        select count(1) into l_cnt from apptmplt a, procappdef p
					where a.svrid = i_def_nsvrid
			                    and p.svrid = i_def_nsvrid
			                    and p.procdefid = i_def_nprocdefid
					and a.orgappid = p.orgappid
					and a.envtype = 'P'
					and a.isfinal = 'T';
	        if (l_cnt > 0) then
	   		   update procappdef p
			      	set (appid, envtype) = (select a.appid, a.envtype from apptmplt a
			      		where a.svrid = i_def_nsvrid
			  			and a.orgappid = p.orgappid
			  			and a.envtype = 'P'
			  			and a.isfinal = 'T')
			  	where p.svrid = i_def_nsvrid
			  		and p.procdefid = i_def_nprocdefid
					and exists (select 1 from apptmplt a where a.orgappid = p.orgappid and a.envtype='P' and a.isfinal='T')
					-- cs13195: remove the applications through process variable from the join result to fix error ORA-01704.
					and p.orgappid <> 0;
	        end if;
	else
		-- publish api(from project env. to operational env.).
		update procdef
			set isfinal = 'F'
			where svrid = i_def_svrid
				and orgprocdefid = (select orgprocdefid from procdef where svrid = i_def_svrid and procdefid = i_def_procdefid)
				and envtype = 'O'
				and isfinal = 'T';

		update procdef
			set fldrid = i_def_nfldrid
			where svrid = i_def_svrid
				and orgprocdefid = (select orgprocdefid from procdef where svrid = i_def_svrid and procdefid = i_def_procdefid);

		update procdef
			set publicationstate = 'P', ver = ver + 1,
				isfinal = 'T', envtype = 'O'
			where svrid = i_def_nsvrid
				and procdefid = i_def_nprocdefid;

		update procappdef
			set envtype = 'O'
			where svrid = i_def_nsvrid
				and procdefid = i_def_nprocdefid;

		update actdef
			set subenvtype = 'O'
			where svrid = i_def_nsvrid
				and procdefid = i_def_nprocdefid
				and suborgprocdefid > 0;

		-- in publish api, publish the process-definition-variable.
		insert into drlvntdataval
		(
			orgprocdefid,
			rlvntdatadefname,
			svrid,
			valuetype,
			dispvalue,
			dscpt,
			value
		)
		select
			a.orgprocdefid,
			b.rlvntdatadefname,
			b.svrid,
			b.valuetype,
			b.dispvalue,
			b.dscpt,
			b.value
		from procdef a, rlvntdatadef b
		where a.svrid = i_def_nsvrid
			and a.procdefid = i_def_nprocdefid
			and b.svrid = a.svrid
			and b.procdefid = a.procdefid
			and b.scope = 'D'
			and not exists (
				select c.orgprocdefid from drlvntdataval c
				where c.orgprocdefid = a.orgprocdefid
					and c.svrid = a.svrid
					and c.rlvntdatadefname = b.rlvntdatadefname
			);
    end if;
exception
    when cannotcopy then
        raise_application_error(-20502, errm);
    when others then
        raise_application_error(-20704, sqlerrm);
end; -- procedure
/
