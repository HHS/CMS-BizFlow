CREATE TRIGGER APPTMPLT_BIR
BEFORE INSERT
  ON APPTMPLT
FOR EACH ROW
  DECLARE
l_authorname    varchar2(100);

-- 12.4.0.0
BEGIN
    SELECT name INTO l_authorname FROM member
        WHERE memberid = :new.author;
    :new.authorname := l_authorname;

EXCEPTION
   WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20920, SQLERRM);
END;
/
