CREATE TRIGGER MEMBER_AUR
AFTER UPDATE OF STATE, LICTYPE, INHERITTYPE, LOGINID, DEPTID, PARENTDEPTID, EMAIL, MANAGERID, PASSWD
  ON MEMBER
  DECLARE
	l_descorder			number;
	l_updated			number;
	l_position			number;
	l_id				varchar2(10);
	l_childid			varchar2(10);
	l_parentid			varchar2(10);
	l_transactionid		varchar2(50);
	l_name				varchar2(100);
	l_parentname		varchar2(100);
	l_inherittype		char(1);
	l_userflag			char(1);
	l_mngflag			char(1);
	l_membertype		char(1);
	l_path				varchar(500);
	l_oldpath			varchar(500);
	l_exist				boolean;
	parentiderror		exception;
	l_auditinfoadm_seq	 number;
	l_detail			varchar2(2048);
	l_oldmanagerid			varchar2(10);
	l_newmanagerid		varchar2(10);
	l_managername		varchar2(100);
	l_index				integer;

	cursor cur_get_updatedid (l_transid varchar2) is
		select vara, varb, varc, vard, vare from hwtemp
		 where tmpkey = l_transid;

	cursor cur_get_children (l_pid varchar2) is
		select memberid from parentmember
		 where parentid = l_pid;

-- 12.4.0.0
BEGIN
    select DBMS_TRANSACTION.LOCAL_TRANSACTION_ID into l_transactionid from dual;

	l_id := '';
	l_updated := 0;
	l_exist := false;

	open cur_get_updatedid(l_transactionid);

	loop
		fetch cur_get_updatedid into l_id, l_updated, l_auditinfoadm_seq, l_oldmanagerid, l_newmanagerid;
		exit when cur_get_updatedid%notfound;

		l_exist := true;

		--dbms_output.put_line('member_aur updated = ' || l_transactionid || ', ' || l_id || ', ' || l_updated);
		-- In case that moved
		if (l_updated = 1 or l_updated = 3 or
			l_updated = 5 or l_updated = 7) then

			open cur_get_children(l_id);

			delete from parentmember
			 where memberid in (select memberid from parentmember
								 where parentid = l_id);

			loop
				fetch cur_get_children into l_childid;
				exit when cur_get_children%notfound;

				l_userflag := 'T';
				l_mngflag  := 'T';

				select parentdeptid, inherittype, type, name into
					   l_parentid, l_inherittype, l_membertype, l_path
				  from vusrgrp
				 where memberid = l_childid;

				l_descorder := 1;
				l_path := '/' || l_path;

				while (l_parentid <> '0000000000') loop
					if (l_userflag = 'T') then
						if (l_inherittype <>'B'
							and l_inherittype <>'U'
							and l_inherittype <>'P'
							and l_inherittype <>'Q') then
							l_userflag := 'F';
						end if;
					end if;
					if (l_mngflag = 'T') then
						if (l_inherittype <> 'B'
							and l_inherittype <> 'M'
							and l_inherittype <> 'Q') then
							l_mngflag := 'F';
						end if;
					end if;

					insert into parentmember (
							memberid, parentid, type,
							dirty, usrinherit, mnginherit,	descorder)
					select l_childid, l_parentid, l_membertype, 'F', l_userflag, l_mngflag, l_descorder
					from dual WHERE NOT EXISTS (select 1 from parentmember where memberid = l_childid and parentid = l_parentid);

					select parentdeptid, inherittype, name into
						   l_parentid, l_inherittype, l_parentname
					  from vusrgrp
					 where memberid = l_parentid;

					l_descorder := l_descorder + 1;

					if (l_descorder > 50) then
						close cur_get_children;
						close cur_get_updatedid;
						raise parentiderror;
					end if;

					l_path := '/' || l_parentname || l_path;
				end loop;

				insert into parentmember(
						memberid, parentid, type,
						dirty, usrinherit, mnginherit, descorder, memberpath)
				select l_childid, l_childid, l_membertype, 'F', 'T', 'T', 0, l_path
				from dual WHERE NOT EXISTS (select 1 from parentmember where memberid = l_childid and parentid = l_childid);
			end loop;
			close cur_get_children;

		end if;

		-- In case that inherittype updated
		if (l_updated = 2 or l_updated = 6) then

			open cur_get_children(l_id);

			loop
				fetch cur_get_children into l_childid;
				exit when cur_get_children%notfound;

				l_userflag := 'T';
				l_mngflag  := 'T';

				select parentdeptid, inherittype into
					   l_parentid, l_inherittype
				  from vusrgrp
				 where memberid = l_childid;

				l_descorder := 1;
				while (l_parentid <> '0000000000') loop
					if (l_userflag = 'T') then
						if (l_inherittype <>'B'
							and l_inherittype <>'U'
							and l_inherittype <>'P'
							and l_inherittype <>'Q') then
							l_userflag := 'F';
						end if;
					end if;
					if (l_mngflag = 'T') then
						if (l_inherittype <> 'B'
							and l_inherittype <> 'M'
							and l_inherittype <> 'Q') then
							l_mngflag := 'F';
						end if;
					end if;

					update parentmember
					   set usrinherit = l_userflag, mnginherit = l_mngflag
					 where memberid = l_childid
					   and parentid = l_parentid;

					select parentdeptid, inherittype into
						   l_parentid, l_inherittype
					  from vusrgrp
					 where memberid = l_parentid;

					l_descorder := l_descorder + 1;

					if (l_descorder > 50) then
						close cur_get_children;
						close cur_get_updatedid;
						raise parentiderror;
					end if;
				end loop;
			end loop;
			close cur_get_children;

		end if;

		-- In case that name updated
		if (l_updated = 4 or l_updated = 6) then
			select m.parentdeptid, m.name, p.memberpath
			  into l_parentid, l_name, l_oldpath
			  from member m, parentmember p
			 where p.parentid = p.memberid
			   and p.memberid = m.memberid
			   and m.memberid = l_id;

			if (l_parentid <> '0000000000') then
				select memberpath into l_path
				  from parentmember
				 where memberid = l_parentid
				   and parentid = l_parentid;

				l_path := l_path || '/' || l_name;
			else
				l_path := '/' || l_name;
			end if;

			l_position := LENGTH(l_oldpath) + 1;

			update parentmember
			   set memberpath = l_path || SUBSTR(memberpath, l_position)
			 where parentid = memberid
			   and memberid in (select memberid from parentmember
			   					 where parentid = l_id);

		end if;

	end loop;
	close cur_get_updatedid;

	if (-1 < l_auditinfoadm_seq) then
		select  detail into l_detail
		  from auditinfoadm
		 where seq = l_auditinfoadm_seq;

		-- replace new path
		l_index := dbms_lob.instr(l_detail,'_NEW_PATH_',1,1);

		if(0 < l_index) then
			begin
				select p.memberpath into l_path
				  from parentmember p, member m
				 where m.memberid = l_id
				   and p.memberid = m.parentdeptid
				   and p.parentid = p.memberid;

				l_detail := dbms_lob.substr(l_detail,l_index-1,1) || l_path || dbms_lob.substr(l_detail,4000, l_index+10);

			exception when others then
				null;
			end;
		end if;

		-- replace old manager name
		l_index := dbms_lob.instr(l_detail,'_OLD_MNGR_',1,1);
		if(0 < l_index and l_oldmanagerid is not null) then
			begin
				select name into l_managername from member where memberid = l_oldmanagerid;
				l_detail := dbms_lob.substr(l_detail,l_index-1,1) || l_managername || dbms_lob.substr(l_detail,4000, l_index+10);
			exception when others then
				null;
			end;
		end if;

		-- replace new manager name
		l_index := dbms_lob.instr(l_detail,'_NEW_MNGR_',1,1);
		if(0 < l_index and l_newmanagerid is not null) then
			begin
				select name into l_managername from member where memberid = l_newmanagerid;
				l_detail := dbms_lob.substr(l_detail,l_index-1,1) || l_managername || dbms_lob.substr(l_detail,4000, l_index+10);
			exception when others then
				null;
			end;
		end if;

		update auditinfoadm
		      set detail = l_detail
		  where seq = l_auditinfoadm_seq;

	end if;

	if (l_exist) then
		delete from hwtemp where tmpkey = l_transactionid;
	end if;

EXCEPTION
    when parentiderror then
        raise_application_error(-20818, 'Invalid parent memberid.');
    WHEN OTHERS THEN
		if cur_get_updatedid%isopen then
		    close cur_get_updatedid;
		end if;
		if cur_get_children%isopen then
		    close cur_get_children;
		end if;
        RAISE_APPLICATION_ERROR(-20934, SQLERRM);
END;
/
