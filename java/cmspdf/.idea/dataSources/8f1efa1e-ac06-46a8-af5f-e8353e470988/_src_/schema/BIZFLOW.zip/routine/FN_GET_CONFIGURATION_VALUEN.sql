CREATE FUNCTION		 fn_get_configuration_valuen
  (
	i_section		IN VARCHAR2,
	i_entry			IN VARCHAR2,
	i_default		IN INT)
  RETURN  INT IS
	l_value 		VARCHAR2(2000);
	int_value		INT;
-- 12.4.0.0
BEGIN

	l_value := NULL;

	SELECT value INTO l_value
	  FROM configuration
	 WHERE section = UPPER(i_section)
       AND entry = UPPER(i_entry);

	IF (l_value IS NULL) THEN
		int_value := i_default;
	ELSE
		int_value := CAST(l_value AS INT);
	END IF;

    RETURN int_value;

EXCEPTION WHEN NO_DATA_FOUND THEN
    RETURN i_default;
END;
/
