CREATE TRIGGER JOBTITLE_BDR
BEFORE DELETE
  ON JOBTITLE
FOR EACH ROW
  DECLARE
    cnt    integer;
    cannotdelete    EXCEPTION;
-- 12.4.0.0
BEGIN
   SELECT count(1) INTO cnt FROM member m
   WHERE m.jobtitleid = :old.jobtitleid
      OR exists(SELECT '1' FROM memberinfo i
                 WHERE m.memberid = i.memberid
                   AND (i.ida = :old.jobtitleid OR
                        i.idb = :old.jobtitleid));
   IF (cnt > 0) THEN
      RAISE cannotdelete;
   END IF;

   IF ( :old.jobtitleid = '9999999999' ) THEN
      RAISE cannotdelete;
   END IF;

EXCEPTION
   WHEN cannotdelete THEN
        RAISE_APPLICATION_ERROR(-20803, 'This JobTitle has Members');
   WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20902, SQLERRM);
END;
/
