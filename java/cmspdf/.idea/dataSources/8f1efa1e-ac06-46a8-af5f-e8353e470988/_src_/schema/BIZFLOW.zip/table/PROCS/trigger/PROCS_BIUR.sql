CREATE TRIGGER PROCS_BIUR
BEFORE INSERT OR UPDATE OF INSTFLDRID, ARCHIVEFLDRID
  ON PROCS
FOR EACH ROW
  declare
l_count     number;

invalid_instance_folder exception;
invalid_archive_folder exception;
-- 12.4.0.0
BEGIN

    select count(1) into l_count from fldrlist where fldrid = :new.instfldrid and type='I';
    if l_count = 0 then
        raise invalid_instance_folder;
    end if;

    select count(1) into l_count from fldrlist where fldrid = :new.archivefldrid and type='S';
    if l_count = 0 then
        raise invalid_archive_folder;
    end if;

exception
    when invalid_instance_folder then
        raise_application_error(-20813, 'Invalid instance folderid.');
    when invalid_archive_folder then
        raise_application_error(-20814, 'Invalid archive folderid.');
    when others then
        raise_application_error(-20925, sqlerrm);
END;
/
