CREATE TRIGGER RLVNTDATA_BIUR
BEFORE INSERT OR UPDATE OF VALUETYPE, VALUE
  ON RLVNTDATA
FOR EACH ROW
  DECLARE
    l_dispname        varchar2(100);
-- 12.4.0.0
BEGIN
    IF :new.value is null THEN
		:new.dispvalue := null;
		-- bug19175 custom sql $$OP_ macro is not generate "is null" clause when filter operator is <>
		:new.indexvalue := ' ';
        RETURN;
    END IF;

	IF :new.valuetype not in ('A', 'P',	'F', 'Q', 'B', 'X', 'Y') THEN
		:new.dispvalue := null;
	END IF;

	IF :new.valuetype in ('S', 'N', 'P', 'A', 'F', 'D', 'X') THEN
		:new.indexvalue := SUBSTR(:new.value, 1, 100);
	END IF;

    IF :new.valuetype = 'A' THEN
		IF :new.value is not null THEN
			SELECT name INTO l_dispname
			  FROM apptmplt
			 WHERE svrid = SUBSTR(:new.value, 1, 10)
			   AND envtype = 'O'
				AND isfinal = 'T'
				AND orgappid = to_number(SUBSTR(:new.value, 12, 10));
		ELSE
			l_dispname := NULL;
		END IF;

        :new.dispvalue := l_dispname;
    ELSIF  :new.valuetype = 'P' THEN
      -- Modified to add exception handling code when initiator is used as participant in quick processes
      BEGIN
        IF :new.value is not null THEN
          SELECT name INTO l_dispname
            FROM member
           WHERE memberid = SUBSTR(:new.value, 4, 10);
        ELSE
          l_dispname := NULL;
        END IF;
        :new.dispvalue := l_dispname;

      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          null;
      END;
    END IF;

EXCEPTION
   WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20906, SQLERRM);
END;
/
