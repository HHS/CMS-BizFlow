CREATE VIEW VMYRLVNTDATA AS SELECT r.svrid, r.procid, wt.prtcp, r.rlvntdataname, r.value
	FROM rlvntdata r, (SELECT svrid, procid, prtcp FROM witem where
						state in ('I', 'R', 'P', 'V')) wt
	WHERE r.svrid = wt.svrid
		AND r.procid = wt.procid
/
