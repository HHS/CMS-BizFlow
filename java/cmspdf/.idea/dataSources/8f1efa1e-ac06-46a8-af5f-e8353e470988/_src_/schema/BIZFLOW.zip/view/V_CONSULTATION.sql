CREATE VIEW V_CONSULTATION AS SELECT a.procid AS PROCESS_ID,
         fn_get_reportdomainlookupvalue('procs.state', a.state) AS PROCESS_STATE_DESC,
         a.state AS PROCESS_STATE, -- #1 State
         a.name AS PROCESS_NAME, -- #2 Name
         a.creationdtime AS PROCESS_CREATION_DATE, -- #3 Create Date
         a.creator AS PROCESS_CREATOR_ID,
         a.creatorname AS PROCESS_CREATOR_NAME, -- #4 Initiator Name
         b.name AS CURRENT_ACTIVITY_NAME, -- #5 Current Step
         c.PRTCPNAME AS CURRENT_USER_NAME,
         c.prtcp AS CURRENT_USER_ID, -- #6 Current Participant
         fn_get_rlvntdatavalue(a.procid, 'I', 'S', 'requestStatus') AS REQUEST_STATUS, -- #7 Current Status
         TO_DATE(REPLACE(fn_get_rlvntdatavalue(a.procid, 'I', 'D', 'requestStatusDate'), 'T', ' '),  'YYYY-MM-DD HH24:MI:SS') AS REQUEST_STATUS_DATE, -- #8 Current State Date
         fn_get_busdaysdiff(TO_DATE(REPLACE(fn_get_rlvntdatavalue(a.procid, 'I', 'D', 'requestStatusDate'), 'T', ' '),  'YYYY-MM-DD HH24:MI:SS'), SYSDATE) as REQUEST_STATUS_AGE, -- #9. Current State Age
         a.cmpltdtime AS PROCESS_COMPLETION_DATE, -- #10 Complete Date
         fn_get_busdaysdiff(a.creationdtime, a.cmpltdtime) AS PROCESS_AGE, -- #11 Days to Complete (Process)
         fn_get_accbusdaysdiff(a.procid, 'Create Request') AS CREATE_REQUEST_AGE, -- #13 Days to Complete (Hold Strategic Consultation Meeting - Accumulated days)
         fn_get_accbusdaysdiff(a.procid, 'Hold Strategic Consultation Meeting') AS HOLD_MEETING_AGE, -- #13 Days to Complete (Hold Strategic Consultation Meeting - Accumulated days)
         fn_get_accbusdaysdiff(a.procid, 'Acknowledge Strat Cons Meeting') AS ACK_MEETING_AGE, -- #14 Days to Complete (Acknowledge Strat Cons Meeting - Accumulated days)
         NVL((SELECT cmpltcnt FROM act WHERE procid = a.procid AND name = 'Acknowledge Strat Cons Meeting'), 0) AS ACK_MEETING_COMPLETION_COUNT,
         fn_get_accbusdaysdiff(a.procid, 'Approve Strat Cons Meeting') AS APRV_MEETING_AGE,-- #16 Days to Complete (Approve Strat Cons Meeting - Accumulated days)
         NVL((SELECT cmpltcnt FROM act WHERE procid = a.procid AND name = 'Approve Strat Cons Meeting'), 0) AS APRV_MEETING_COMPLETION_COUNT,
         fn_get_rlvntdatavalue(a.procid, 'I', 'S', 'adminCode') AS V_ADMIN_CODE,
         fn_get_rlvntdatavalue(a.procid, 'I', 'S', 'cancelReason') AS V_CANCEL_REASON,
         fn_get_rlvntdatavalue(a.procid, 'I', 'S', 'requestNum') AS V_REQUEST_NUMBER,
         fn_get_rlvntdatavalue(a.procid, 'I', 'S', 'requestType') AS V_REQUEST_TYPE,
         fn_get_rlvntdatavalue(a.procid, 'I', 'S', 'classificationType') AS V_CLASSIFICATION_TYPE
  FROM PROCS a
    LEFT JOIN ACT b ON a.procid = b.procid AND b.state IN ('R', 'V', 'E') AND b.type = 'P'
    LEFT JOIN WITEM c ON a.procid = c.procid AND b.actseq = c.actseq AND c.state in ('I','V','E','P','R')
  WHERE a.preprocdefname = 'Strategic Consultation'
  ORDER BY a.PROCID
/
