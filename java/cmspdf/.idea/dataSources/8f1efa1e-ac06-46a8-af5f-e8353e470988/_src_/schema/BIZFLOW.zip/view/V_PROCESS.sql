CREATE VIEW V_PROCESS AS select a.procid as PROCESS_ID, fn_get_reportdomainlookupvalue('procs.state', a.state) as STATE_LABEL, a.state as STATE,
  a.cmntcnt as COMMENT_COUNT, a.attachcnt as ATTACHMENT_COUNT, a.name as NAME, a.creationdtime as CREATION_DATE,
  a.creator as CREATOR_ID, a.creatorname as CREATOR_NAME, a.cmpltdtime as COMPLETION_DATE, a.parentprocid as PARENT_PROCESS_ID, b.name as PARENT_PROCESS_NAME, 
  a.parentactseq as PARENT_ACTIVITY_ID,
  fn_get_busdaysdiff(a.creationdtime, a.cmpltdtime) as COMPLETION_DURATION
from PROCS a left join PROCS b on a.parentprocid = b.PROCID
/
