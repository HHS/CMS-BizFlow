CREATE TRIGGER EXCPT_ADR
AFTER DELETE
  ON EXCPT
FOR EACH ROW
  BEGIN
    DELETE FROM deadline
     WHERE svrid = :old.svrid
        AND procid = :old.procid
        AND excptseq = :old.excptseq;

 EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20900, SQLERRM);
END;
/
