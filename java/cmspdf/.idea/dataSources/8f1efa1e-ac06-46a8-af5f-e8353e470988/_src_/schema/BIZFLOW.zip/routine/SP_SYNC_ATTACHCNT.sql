CREATE procedure sp_sync_attachcnt
   is
--
-- 12.4.0.0
--
    l_svrid             varchar2(10);
    l_procid            number;
	l_attachcnt			number;

cursor cur_get_attachcnt is
	select svrid, procid, count(*) count_of_attach
	from attach where type <> 'S' and type <> 'H'
					group by svrid, procid;

begin

	update procs set attachcnt = 0;
	commit;

	open cur_get_attachcnt;
	loop
		fetch cur_get_attachcnt into l_svrid, l_procid, l_attachcnt;
		exit when cur_get_attachcnt%notfound;

		update procs set attachcnt = l_attachcnt
				where svrid = l_svrid
                    and procid = l_procid;
	end loop;
	close cur_get_attachcnt;

exception
    when others then
        if cur_get_attachcnt%isopen then
            close cur_get_attachcnt;
        end if;
end;
/
