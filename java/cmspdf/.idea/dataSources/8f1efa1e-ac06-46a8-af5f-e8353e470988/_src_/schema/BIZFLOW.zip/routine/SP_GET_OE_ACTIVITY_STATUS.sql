CREATE PROCEDURE sp_get_oe_activity_status
	(i_userid in varchar2,
	i_procid in number,
	i_actseq in number,
	i_workseq in number,
	o_status out number)
	IS
	-- return staus
	-- 0: not mandatory application, not initiated task, can complete activity
	-- 1: completed task, can complete activity
	-- 2: not oe activity
	-- 3: no oe license
	-- 4: mandatory application, not initiated task
	-- 5: initiated task, not completed task

	l_viewtype char;
	l_status char;
	l_cnt number;

-- 12.4.0.0
	BEGIN
	-- check OfficeEngine license
	select count(*)
	  into l_cnt
	  from usrgrpprtcp
	 where prtcp = i_userid
	   and usrgrpid='licsgrp005';

	if (0<l_cnt) then
		select b.viewtype
		  into l_viewtype
		  from act a, actapp b, apptmplt c
		 where a.procid = i_procid
		   and a.actseq= i_actseq
		   and a.type <> 'R'
		   and a.procid = b.procid
		   and a.actseq = b.actseq
		   and c.appid = b.appid
		   and c.type = 'H'
		   and c.invokedmethod like '%solutions/tasktracker%/wih_addon.jsp%'
		   and rownum = 1;

		l_status := 'N';

		SELECT status
		  INTO l_status
		  FROM(
			SELECT 'I' status FROM TaskAssociation
			WHERE procid = i_procid AND actseq = i_actseq
			UNION
			SELECT 'C' status FROM CompleteTaskAssociation
			WHERE procid = i_procid AND actseq = i_actseq
			) t;

		if ('N' = l_status) then
			if ('M' = l_viewtype) then
				o_status := 4;  -- mandatory application, not initiated task
			else
				o_status := 0;  -- not mandatory application, not initiated task, can complete activity
			end if;
		elsif ('C' = l_status) then
			o_status := 1;	-- completed task, can complete activity
		elsif ('I' = l_status) then
			SELECT COUNT(1)
			  INTO l_cnt
			  FROM TaskAssociation ta, subTasks st
			 WHERE ta.procid = i_procid
			   AND ta.actseq = i_actseq
			   AND st.taskid = ta.taskid
			   AND st.routeback = 'T';
			if (0 < l_cnt) then
				o_status := 5; -- initiated task, not completed task
			else
				o_status := 1; -- initiated task, all fyi subtasks
			end if;
		end if;
	else
		o_status := 3;
	end if;

	exception
		when NO_DATA_FOUND then
			o_status := 2; -- not oe activity
		when others then
			raise_application_error(-20700, sqlerrm);
end;
/
