CREATE TRIGGER USRSESSION_BIUDR
BEFORE INSERT OR UPDATE OR DELETE
  ON USRSESSION
FOR EACH ROW
  DECLARE
	l_cnt	INTEGER;
BEGIN
	IF inserting THEN
		INSERT INTO auditinfoadm (seq, actor, actorname, dtime, event, ipaddr)
			SELECT hws_adminaudit.nextval, :new.memberid, name, getutcdate(), 'login', :new.ipaddr
			  FROM member m WHERE :new.memberid = m.memberid;
	ELSIF updating THEN
		IF (:old.logincnt <= :new.logincnt) THEN
			INSERT INTO auditinfoadm (seq, actor, actorname, dtime, event, ipaddr)
			SELECT hws_adminaudit.nextval, :new.memberid, name, getutcdate(), 'login', :new.ipaddr
			FROM member m WHERE :new.memberid = m.memberid;
		ELSE
			INSERT INTO auditinfoadm (seq, actor, actorname, dtime, event, ipaddr)
			SELECT hws_adminaudit.nextval, :new.memberid, name, getutcdate(), 'logout', :new.ipaddr
			FROM member m WHERE :new.memberid = m.memberid;
		END IF;
	ELSIF deleting THEN
		UPDATE procdef SET checkoutusr = null WHERE checkoutusr = :old.memberid;
		-- Intentionally, we won't touch procs because it might cause slow performance.
		--UPDATE procs SET checkoutusr = NULL WHERE checkoutusr = :old.memberid;
		UPDATE witem set checkoutusr = NULL, checkoutdtime = NULL WHERE checkoutusr = :old.memberid;
		DELETE FROM appcheckout WHERE prtcp = :old.memberid;
		DELETE FROM checkout WHERE memberid = :old.memberid;
		UPDATE witem SET checkoutusr = NULL WHERE checkoutusr = :old.memberid;

		SELECT COUNT(1) INTO l_cnt FROM member where memberid = :old.memberid;
		IF (l_cnt > 0) THEN
			INSERT INTO auditinfoadm (seq, actor, actorname, dtime, event, ipaddr)
				SELECT hws_adminaudit.nextval, :old.memberid, name, getutcdate(),  'logout', :old.ipaddr
				  FROM member m WHERE :old.memberid = m.memberid;
		ELSE
			INSERT INTO auditinfoadm (seq, actor, actorname, dtime, event, ipaddr)
			VALUES (hws_adminaudit.nextval, :old.memberid, 'Unknown', getutcdate(),  'logout', :old.ipaddr);
		END IF;
	END IF;
END;
/
