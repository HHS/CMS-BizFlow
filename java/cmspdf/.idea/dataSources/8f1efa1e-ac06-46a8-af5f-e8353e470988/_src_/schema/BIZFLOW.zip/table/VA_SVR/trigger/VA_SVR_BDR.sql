CREATE TRIGGER VA_SVR_BDR
BEFORE DELETE
  ON VA_SVR
FOR EACH ROW
  DECLARE
    cnt    			integer;
    cannotdeletepd	EXCEPTION;
    cannotdeletepi	EXCEPTION;
    cannotdeleteejb	EXCEPTION;

-- 12.4.0.0
BEGIN
	SELECT count(1) INTO cnt FROM procdef pd
	 WHERE pd.dmidtype = 'C' AND pd.dmsvrid = :old.svrid;
	IF (cnt > 0) THEN
		RAISE cannotdeletepd;
	END IF;

	SELECT count(1) INTO cnt FROM procs p
	 WHERE p.dmidtype = 'C' AND p.dmsvrid = :old.svrid
	   AND p.state in ('I','R','V','C','E','A','T','S','P','D','W','Y');
	IF (cnt > 0) THEN
		RAISE cannotdeletepi;
	END IF;

	SELECT count(1) INTO cnt FROM apptmplt a
		WHERE :old.svctype = 'EJB' AND a.dmsvrid = :old.svrid;
	IF (cnt > 0) THEN
		RAISE cannotdeleteejb;
	END IF;

EXCEPTION
	WHEN cannotdeletepd THEN
		RAISE_APPLICATION_ERROR(-20815, 'This EDMS server is being used in Process Definition');
	WHEN cannotdeletepi THEN
		RAISE_APPLICATION_ERROR(-20816, 'This EDMS server is being used in Process Instance');
	WHEN cannotdeleteejb THEN
		RAISE_APPLICATION_ERROR(-20817, 'The EJB server connection being used in the EJB type application');
	WHEN OTHERS THEN
		RAISE_APPLICATION_ERROR(-20929, SQLERRM);
END;
/
