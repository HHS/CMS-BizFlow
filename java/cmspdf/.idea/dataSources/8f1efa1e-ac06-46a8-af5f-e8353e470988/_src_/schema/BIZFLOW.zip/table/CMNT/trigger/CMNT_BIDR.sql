CREATE TRIGGER CMNT_BIDR
BEFORE INSERT OR DELETE
  ON CMNT
FOR EACH ROW
  DECLARE
    l_actname         varchar2(100);
    l_actseq	          number;
    l_creatorname    varchar2(100);
    l_jobtitleid    varchar2(10);
    l_jobtitlename    varchar2(100);
    l_deptid    varchar2(10);
    l_deptname    varchar2(100);
-- 12.4.0.0
BEGIN
IF inserting THEN
    UPDATE procs SET cmntcnt = cmntcnt + 1 WHERE svrid = :new.svrid AND procid = :new.procid;

    IF (:new.witemseq <> 0) THEN
        SELECT a.name, a.actseq INTO l_actname, l_actseq FROM act a, witem b
         WHERE b.svrid = :new.svrid
           AND b.procid = :new.procid
           AND b.witemseq = :new.witemseq
           AND a.svrid = b.svrid
           AND a.procid = b.procid
           AND a.actseq = b.actseq;
        :new.actname := l_actname;
        :new.actseq := l_actseq;
    END IF;

    SELECT name, jobtitleid, jobtitlename, deptid, deptname
        INTO l_creatorname, l_jobtitleid, l_jobtitlename, l_deptid, l_deptname FROM member
        WHERE memberid = :new.creator;
    :new.creatorname := l_creatorname;
    :new.jobtitleid := l_jobtitleid;
    :new.jobtitlename := l_jobtitlename;
    :new.deptid := l_deptid;
    :new.deptname := l_deptname;

ELSIF  deleting THEN
    UPDATE procs SET cmntcnt = cmntcnt - 1 WHERE svrid = :old.svrid AND procid = :old.procid;
END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20913, SQLERRM);
END;
/
