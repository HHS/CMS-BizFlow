CREATE TYPE designator_type IS OBJECT
(
    prtcp VARCHAR2(10),
    prtcptype CHAR(1),
    issurrogater CHAR(1)
);
/
