CREATE PROCEDURE sp_deletetask (
    IN_TASKID IN INT
)
IS
    L_PROCID INT;
    L_COUNT INT;
    L_SERVERID VARCHAR2(10);
-- 12.4.0.0
BEGIN

    L_PROCID := 0;
    -- get process id
    -- First check from Tasks
    SELECT COUNT(1) INTO L_COUNT FROM Tasks WHERE TaskID = IN_TASKID;
    IF (L_COUNT = 1) THEN
        SELECT procid INTO L_PROCID FROM Tasks WHERE TaskID = IN_TASKID;
    ELSE
        SELECT COUNT(1) INTO L_COUNT FROM CompleteTasks WHERE TaskID = IN_TASKID;
        IF (L_COUNT = 1) THEN
            SELECT procid INTO L_PROCID FROM CompleteTasks WHERE TaskID = IN_TASKID;
        END IF;
    END IF;


    DELETE FROM Tasks WHERE TaskID = IN_TASKID;
	DELETE FROM SubTasks WHERE TaskID = IN_TASKID;
	DELETE FROM Responses WHERE TaskID = IN_TASKID;
	DELETE FROM DTaskerAudit WHERE TaskID = IN_TASKID;
	DELETE FROM TaskAssociation WHERE TaskID = IN_TASKID;
	DELETE FROM taskprtcp WHERE TaskID = IN_TASKID;
	DELETE FROM taskapprovers WHERE TaskID = IN_TASKID;

	DELETE FROM CompleteTasks WHERE TaskID = IN_TASKID;
	DELETE FROM CompleteSubTasks WHERE TaskID = IN_TASKID;
	DELETE FROM CompleteResponses WHERE TaskID = IN_TASKID;
	DELETE FROM CompleteDTaskerAudit WHERE TaskID = IN_TASKID;
	DELETE FROM CompleteTaskAssociation WHERE TaskID = IN_TASKID;
	DELETE FROM completetaskprtcp WHERE TaskID = IN_TASKID;
	DELETE FROM completetaskapprovers WHERE TaskID = IN_TASKID;

    IF (L_PROCID > 0) THEN
        -- just check one more time to avoid oracle no recourd found error.
        SELECT COUNT(1) INTO L_COUNT FROM procs WHERE procid = L_PROCID;

        IF (L_COUNT = 1) THEN
            -- If procid is found, delete process.
            SELECT svrid INTO L_SERVERID FROM procs WHERE procid = L_PROCID;

            sp_delete_proc(L_SERVERID, L_PROCID);
        END IF;

    END IF;



END;
/
