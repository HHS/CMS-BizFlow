CREATE VIEW V_TASKPRTCP AS SELECT taskid, subtaskid, prtcp, type, kind, externaluser FROM taskprtcp
UNION ALL
SELECT taskid, subtaskid, prtcp, type, kind, externaluser FROM completetaskprtcp
/
