CREATE VIEW VUSRGRP AS SELECT '9999999996' AS memberid, 'H' As type, 'A' AS state, '' AS inherittype, 'Organization Chart' AS name, 0 AS disporder,
	   '' AS deptid, '0000000000' AS parentdeptid, '' AS managerid,
	   NVL(i.dupusrflag,'F') as dupusrflag, NVL(i.dupnameflag,'T') as dupnameflag, NVL(i.managerrule,0) as managerrule, m.dscpt, m.email, NVL(i.headofregion, 'F') as headofregion
  FROM member m LEFT JOIN memberinfo i ON m.memberid = i.memberid
 WHERE m.memberid = '9999999996'
 UNION ALL
SELECT m.memberid, m.type, m.state, '' AS inherittype, m.name, m.disporder,
	   '' AS deptid, '0000000000' AS parentdeptid, '' AS managerid,
	   i.dupusrflag, i.dupnameflag, i.managerrule, m.dscpt, m.email, NVL(i.headofregion, 'F') as headofregion
  FROM member m, memberinfo i
 WHERE m.deptid = '0000000000'
   AND m.memberid <> '9999999996'
   AND m.type = 'H'
   AND m.memberid = i.memberid
 UNION ALL
SELECT m.memberid, m.type, 'N' AS state, m.inherittype, m.name, m.disporder,
	   '9999999996' AS deptid, '9999999996' AS parentdeptid, m.managerid,
	   '?' AS dupusrflag, '?' AS dupnameflag, 0 AS managerrule, m.dscpt, m.email, '' as headofregion
  FROM member m
 WHERE m.memberid = '9000000000'
 UNION ALL
SELECT m.memberid, m.type, 'N' AS state, m.inherittype, m.name, m.disporder,
	   '9999999996' AS deptid, m.parentdeptid, m.managerid,
	   '?' AS dupusrflag, '?' AS dupnameflag, 0 AS managerrule, m.dscpt, m.email, '' as headofregion
  FROM member m
 WHERE m.memberid <> '9000000000'
   AND m.type = 'D'
 UNION ALL
SELECT m.memberid, m.type, 'N' AS state, m.inherittype, m.name, m.disporder,
	   m.deptid, m.parentdeptid, m.managerid,
	   '?' AS dupusrflag, '?' AS dupnameflag, 0 AS managerrule, m.dscpt, m.email, '' as headofregion
  FROM member m
 WHERE m.type = 'G'
/
