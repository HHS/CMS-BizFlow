CREATE TRIGGER QUEUEERRLOG_BIR
BEFORE INSERT
  ON QUEUEERRLOG
FOR EACH ROW
  DECLARE
    l_name        varchar2(100);
    l_actname    varchar2(100);
-- 12.4.0.0
BEGIN
    IF :new.procdefid = 0
        AND :new.procid <> 0 THEN

        SELECT name INTO l_name FROM procs WHERE svrid = :new.svrid AND procid = :new.procid;
        IF :new.witemseq <> 0 THEN
        SELECT a.name INTO l_actname FROM act a, witem w
                                    WHERE w.svrid = :new.svrid
                                        AND w.procid = :new.procid
                                        AND w.witemseq = :new.witemseq
                                        AND a.svrid = w.svrid
                                        AND a.procid = w.procid
                                        AND a.actseq = w.actseq;
        :new.detailinfo := l_name || ' [' || l_actname || ']';
         ELSE
            :new.detailinfo := l_name;
         END IF;
    ELSIF  :new.procdefid <> 0
        AND :new.procid = 0 THEN

        SELECT name INTO l_name FROM procdef WHERE svrid = :new.svrid AND procdefid = :new.procdefid;
        :new.detailinfo := l_name;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20923, SQLERRM);
END;
/
