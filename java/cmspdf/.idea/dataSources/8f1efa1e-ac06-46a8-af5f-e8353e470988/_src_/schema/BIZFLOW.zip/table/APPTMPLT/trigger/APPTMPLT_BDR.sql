CREATE TRIGGER APPTMPLT_BDR
AFTER DELETE
  ON APPTMPLT
FOR EACH ROW
  DECLARE
    cnt    			integer;
-- 12.4.0.0
BEGIN

    SELECT count(1) INTO cnt FROM actappdef
     WHERE appid = :old.appid;
    IF (cnt > 0) THEN
         UPDATE actappdef
            SET appid = 0
          WHERE procdefid in (SELECT procdefid
                                FROM procappdef
                               WHERE envtype = 'P' AND appid = :old.appid);
    END IF;

    SELECT count(1) INTO cnt FROM procappdef
     WHERE appid = :old.appid;
    IF (cnt > 0) THEN
         UPDATE procappdef
            SET appid = 0, orgappid = 0
          WHERE procdefid in (SELECT procdefid
                                FROM procappdef
                               WHERE envtype = 'P' AND appid = :old.appid);
    END IF;

 EXCEPTION
    WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20920, SQLERRM);
END;
/
