CREATE VIEW HWV_DBSCHEMA_VIEWS AS SELECT
    null AS table_catalog,
    null AS table_schema,
    view_name AS table_name
FROM    user_views
/
