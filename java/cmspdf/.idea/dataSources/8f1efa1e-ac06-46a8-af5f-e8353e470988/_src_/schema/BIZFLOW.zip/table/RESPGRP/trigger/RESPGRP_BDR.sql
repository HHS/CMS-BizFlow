CREATE TRIGGER RESPGRP_BDR
BEFORE DELETE
  ON RESPGRP
FOR EACH ROW
  DECLARE
 cnt    integer := 0 ;
 cannotdelete    EXCEPTION;

-- 12.4.0.0
BEGIN

    SELECT count(respgrpseq) INTO cnt FROM act
    WHERE svrid = :old.svrid
      AND procid = :old.procid
      AND respgrpseq = :old.respgrpseq
      AND state in ('N','R','E','V','S','J','W')
      AND respgrpseq <> 0
      AND rownum < 2 ;

    IF ( cnt <> 0  ) THEN
        RAISE cannotdelete;
    ELSE
        DELETE FROM resp
         WHERE svrid = :old.svrid
           AND procid = :old.procid
           AND respgrpseq = :old.respgrpseq;
    END IF;

EXCEPTION
    WHEN cannotdelete THEN
         RAISE_APPLICATION_ERROR(-20810, 'This Response Group is used already by Activities');
    WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20905, SQLERRM);
END;
/
