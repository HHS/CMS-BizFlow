CREATE VIEW V_CLASSIFICATION AS SELECT a.procid AS PROCESS_ID,
         fn_get_reportdomainlookupvalue('procs.state', a.state) AS PROCESS_STATE_DESC,
         a.state AS PROCESS_STATE, -- #1 State
         a.name AS PROCESS_NAME, -- #2 Name
         a.creationdtime AS PROCESS_CREATION_DATE, -- #3 Create Date
         a.creator AS PROCESS_CREATOR_ID,
         a.creatorname AS PROCESS_CREATOR_NAME, -- #4 Initiator Name
         b.name AS CURRENT_ACTIVITY_NAME, -- #5 Current Step
         c.PRTCPNAME AS CURRENT_USER_NAME,
         c.prtcp AS CURRENT_USER_ID, -- #6 Current Participant
         fn_get_rlvntdatavalue(a.procid, 'I', 'S', 'requestStatus') AS REQUEST_STATUS, -- #7 Current Status
         TO_DATE(REPLACE(fn_get_rlvntdatavalue(a.procid, 'I', 'D', 'requestStatusDate'), 'T', ' '),  'YYYY-MM-DD HH24:MI:SS') AS REQUEST_STATUS_DATE, -- #8 Current State Date
         fn_get_busdaysdiff(TO_DATE(REPLACE(fn_get_rlvntdatavalue(a.procid, 'I', 'D', 'requestStatusDate'), 'T', ' '),  'YYYY-MM-DD HH24:MI:SS'), SYSDATE) as REQUEST_STATUS_AGE, -- #9. Current State Age
         a.cmpltdtime AS PROCESS_COMPLETION_DATE, -- #10 Complete Date
         fn_get_busdaysdiff(a.creationdtime, a.cmpltdtime) AS PROCESS_AGE, -- #11 Days to Complete (Process)

         fn_get_accbusdaysdiff(a.procid, 'Complete PD Coversheet and Classification Analysis') AS COMPLETE_PD_COVERSHEET_AGE, -- #12 Days to Complete (Complete PD Coversheet and Classification Analysis)
         NVL((SELECT cmpltcnt FROM act WHERE procid = a.procid AND name = 'Complete PD Coversheet and Classification Analysis'), 0) as COMPLETE_PD_COVERSHEET_COUNT, -- #13

         fn_get_accbusdaysdiff(a.procid, 'Confirm Classification Analysis') AS CONFIRM_ANALYSIS_AGE, -- #14 Days to Complete (Confirm Classification Analysis)
         NVL((SELECT cmpltcnt FROM act WHERE procid = a.procid AND name = 'Confirm Classification Analysis'), 0) AS CONFIRM_ANALYSIS_COUNT, -- #15

         fn_get_accbusdaysdiff(a.procid, 'Confirm BUS Code') AS CONFIRM_BUS_CODE_AGE, -- #16 Days to Complete (Confirm BUS code)

         fn_get_accbusdaysdiff(a.procid, 'Review DWC Entry') AS REVIEW_DWC_ENTRY_AGE, -- #17 Days to Complete (Confirm Classification Analysis)
         NVL((SELECT cmpltcnt FROM act WHERE procid = a.procid AND name = 'Review DWC Entry'), 0) AS REVIEW_DWC_ENTRY_COUNT, -- #18 Completion count

         fn_get_accbusdaysdiff(a.procid, 'Approve PD Coversheet - SO') AS APPROVE_PD_COVERSHEET_AGE, -- #19 Days to Complete (Approve PD Coversheet)
         NVL((SELECT cmpltcnt FROM act WHERE procid = a.procid AND name = 'Approve PD Coversheet - SO'), 0) AS APPROVE_PD_COVERSHEET_COUNT, -- #20 Completion count

         fn_get_accbusdaysdiff(a.procid, 'Approve Coversheet and Create Final Pkg') AS CREATE_FINAL_PKG_AGE, -- #21 Days to Complete (Approve Coversheet and Create Final Pkg)
         NVL((SELECT cmpltcnt FROM act WHERE procid = a.procid AND name = 'Approve Coversheet and Create Final Pkg'), 0) AS CREATE_FINAL_PKG_COUNT, -- #22 Completion count

         fn_get_rlvntdatavalue(a.procid, 'I', 'S', 'adminCode') AS V_ADMIN_CODE,
         fn_get_rlvntdatavalue(a.procid, 'I', 'S', 'cancelReason') AS V_CANCEL_REASON,
         fn_get_rlvntdatavalue(a.procid, 'I', 'S', 'requestNum') AS V_REQUEST_NUMBER,
         fn_get_rlvntdatavalue(a.procid, 'I', 'S', 'requestType') AS V_REQUEST_TYPE,
         fn_get_rlvntdatavalue(a.procid, 'I', 'S', 'classificationType') AS V_CLASSIFICATION_TYPE
  FROM PROCS a
    LEFT JOIN ACT b ON a.procid = b.procid AND b.state IN ('R', 'V', 'E') AND b.type = 'P'
    LEFT JOIN WITEM c ON a.procid = c.procid AND b.actseq = c.actseq AND c.state in ('I','V','E','P','R')
  WHERE a.preprocdefname = 'Classification'
  ORDER BY a.PROCID
/
