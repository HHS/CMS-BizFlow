CREATE procedure		   sp_get_enddate
(
	i_memberid	in	varchar2,
	i_cur_date 	in	date,
	i_deadline	in 	number,
	o_to_date	out date
)	is
-- 12.4.0.0

cursor cur_get_working_next (l_memberid varchar2, l_from_date date, l_to_date date) is
				select c.caldtime, ch.totdaywtime, 'T' as isdefault, c.dayofweek
				  from cal c, calhead ch
				 where ch.daytype = 'W'
				 	and ch.memberid = l_memberid
					and ch.dayofweek = c.dayofweek
				 	and not exists (select caldtime from membercal
										where caldtime = c.caldtime
											and memberid = l_memberid)
					and caldtime > l_from_date - 1
					and caldtime <= l_to_date - 1
				union all
				select caldtime, ch.totdaywtime, 'T' as isdefault, m.dayofweek
				  from membercal m, calhead ch
				 where m.daytype = 'W'
				 	and m.isdefault = 'T'
					and ch.memberid = m.memberid
					and ch.dayofweek = m.dayofweek
				 	and m.memberid = l_memberid
				 	and m.caldtime > l_from_date - 1
					and m.caldtime <= l_to_date - 1
				union all
				select caldtime, totdaywtime, 'F' as isdefault, dayofweek
				  from membercal
				 where daytype = 'W'
				 	and isdefault = 'F'
				 	and memberid = l_memberid
				 	and caldtime > l_from_date - 1
					and caldtime <= l_to_date - 1
				order by caldtime;

cursor cur_get_working_prev (l_memberid varchar2, l_from_date date, l_to_date date) is
				select c.caldtime, ch.totdaywtime, 'T' as isdefault, c.dayofweek
				  from cal c, calhead ch
				 where ch.daytype = 'W'
				 	and ch.memberid = l_memberid
					and ch.dayofweek = c.dayofweek
				 	and not exists (select caldtime from membercal
										where caldtime = c.caldtime
											and memberid = l_memberid)
					and caldtime > l_to_date
					and caldtime <= l_from_date
				union all
				select caldtime, ch.totdaywtime, 'T' as isdefault, m.dayofweek
				  from membercal m, calhead ch
				 where m.daytype = 'W'
				 	and m.isdefault = 'T'
					and ch.memberid = m.memberid
					and ch.dayofweek = m.dayofweek
				 	and m.memberid = l_memberid
					and m.caldtime > l_to_date
					and m.caldtime <= l_from_date
				union all
				select caldtime, totdaywtime, 'F' as isdefault, dayofweek
				  from membercal
				 where daytype = 'W'
				 	and isdefault = 'F'
				 	and memberid = l_memberid
					and caldtime > l_to_date
					and caldtime <= l_from_date
				order by caldtime desc;

	l_memberid				varchar2(10) := i_memberid;
	l_membertype			char(1);
	l_deptid				varchar2(10);
	l_from_date				date;
	l_to_date				date;
	l_deadline_timeleft 	number;
	l_today_timeleft		number;
	l_dst_diff				number;

	l_tzsign				char(1);
	l_timediff				number;
	l_cal_wdate				date;
	l_totdaywtime			number;
	l_isdefault				char(1);
	l_dayofweek				char(1);

	l_loopflag				number := 1;
	l_tmpcnt				number;

	l_prefetch_size			number := 31;
	insufficientcal			exception;

begin
	l_from_date := i_cur_date;
	l_to_date := i_cur_date;

	if (l_memberid is null or l_memberid = '') then
		l_memberid := '0000000000';
	end if;

	loop
		select count(memberid) into l_tmpcnt from calhead where memberid = l_memberid and dayofweek = '0';
		if l_tmpcnt > 0 then
			select tzsign, timediff into l_tzsign, l_timediff from calhead where memberid = l_memberid and dayofweek = '0';

			l_dst_diff := fn_get_dst_diff(l_memberid, i_cur_date);
			if l_tzsign = '-' then
				l_from_date := l_from_date - l_dst_diff/3600/24 + l_timediff/3600/24 * -1;
				l_to_date := l_to_date - l_dst_diff/3600/24 + l_timediff/3600/24 * -1;
			else
				l_from_date := l_from_date - l_dst_diff/3600/24 + l_timediff/3600/24;
				l_to_date := l_to_date - l_dst_diff/3600/24 + l_timediff/3600/24;
			end if;

			exit;
		else
			select parentdeptid, deptid, type into l_memberid, l_deptid, l_membertype
											from member
												where memberid = l_memberid;
			if l_membertype = 'U' then
				l_memberid := l_deptid;
			end if;
		end if;
	end loop;
--dbms_output.put_line('l_memberid = ' || l_memberid);

	if i_deadline >= 0 then
		l_deadline_timeleft := i_deadline;
		open cur_get_working_next(l_memberid, l_from_date, l_from_date + l_prefetch_size);
		l_from_date := l_from_date + l_prefetch_size;
		loop
			loop
				fetch cur_get_working_next	 into l_cal_wdate, l_totdaywtime, l_isdefault, l_dayofweek;
				exit when cur_get_working_next%notfound;
--dbms_output.put_line('l_to_date = ' || l_to_date || ', l_cal_wdate = ' || l_cal_wdate || ', l_totdaywtime = ' || to_char(l_totdaywtime));

				if l_to_date < l_cal_wdate then
					l_to_date := l_cal_wdate;
				end if;

				if l_to_date = l_cal_wdate then
					if l_totdaywtime <= l_deadline_timeleft then
						l_deadline_timeleft := l_deadline_timeleft - l_totdaywtime;
						if l_deadline_timeleft = 0 then
							l_to_date := fn_get_wtime_slot(l_isdefault, l_dayofweek, l_memberid, l_cal_wdate, l_to_date, l_totdaywtime);
							l_loopflag := 0;
--dbms_output.put_line('First1: l_deadline_timeleft = ' || to_char(l_deadline_timeleft));
							exit;
						else
							l_to_date := l_to_date + 1;
						end if;
--dbms_output.put_line('First2: l_deadline_timeleft = ' || to_char(l_deadline_timeleft));
					else
						l_to_date := fn_get_wtime_slot(l_isdefault, l_dayofweek, l_memberid, l_cal_wdate, l_to_date, l_deadline_timeleft);
--dbms_output.put_line('First3: l_deadline_timeleft = ' || to_char(l_deadline_timeleft));
						l_loopflag := 0;
						exit;
					end if;
				elsif l_cal_wdate < l_to_date then
					l_today_timeleft := fn_get_wtime_leftover(l_isdefault, l_dayofweek, l_memberid, l_cal_wdate, l_to_date);
--dbms_output.put_line('Second0: l_today_timeleft = ' || to_char(l_today_timeleft));
					if l_today_timeleft <> 0
						and l_deadline_timeleft = 0 then
						l_to_date := fn_get_wtime_slot(l_isdefault, l_dayofweek, l_memberid, l_cal_wdate, l_to_date,
													 l_deadline_timeleft + l_totdaywtime - l_today_timeleft);
						l_loopflag := 0;
--dbms_output.put_line('Second1: l_deadline_timeleft = ' || to_char(l_deadline_timeleft));
						exit;
					elsif l_today_timeleft = 0
						and l_deadline_timeleft = 0 then
						l_to_date := l_cal_wdate + 1;
--dbms_output.put_line('Second2: l_deadline_timeleft = ' || to_char(l_deadline_timeleft));
					elsif l_today_timeleft < l_deadline_timeleft then
						l_deadline_timeleft := l_deadline_timeleft - l_today_timeleft;
						l_to_date := l_cal_wdate + 1;
--dbms_output.put_line('Second3: l_deadline_timeleft = ' || to_char(l_deadline_timeleft));
					else
						l_to_date := fn_get_wtime_slot(l_isdefault, l_dayofweek, l_memberid, l_cal_wdate, l_to_date,
													l_deadline_timeleft + l_totdaywtime - l_today_timeleft);
						l_loopflag := 0;
--dbms_output.put_line('Second4: l_deadline_timeleft = ' || to_char(l_deadline_timeleft));
						exit;
					end if;
				end if;
			end loop;

			if l_loopflag = 1 then
				close cur_get_working_next;

				select count(1) into l_tmpcnt from cal
					where caldtime >= l_from_date + l_prefetch_size
						and caldtime <= l_from_date + l_prefetch_size + 1;
				if l_tmpcnt = 0 then
					raise insufficientcal;
				else
--dbms_output.put_line('* cur_get_working_next(' || TO_CHAR(l_from_date) || ', ' || TO_CHAR(l_from_date + l_prefetch_size) || ')');
					open cur_get_working_next(l_memberid, l_from_date, l_from_date + l_prefetch_size);
					l_from_date := l_from_date + l_prefetch_size;
				end if;
			else
				exit;
			end if;
		end loop;
	else
		l_deadline_timeleft := i_deadline * -1;
		open cur_get_working_prev(l_memberid, l_from_date, l_from_date - l_prefetch_size);
		l_from_date := l_from_date - l_prefetch_size;
		loop
			loop
				fetch cur_get_working_prev	 into l_cal_wdate, l_totdaywtime, l_isdefault, l_dayofweek;
				exit when cur_get_working_prev%notfound;
--dbms_output.put_line('l_cal_wdate = ' || l_cal_wdate || ', l_totdaywtime = ' || to_char(l_totdaywtime));

				if l_cal_wdate + 1 <= l_to_date then
					l_to_date := l_cal_wdate;
				end if;

				if l_cal_wdate = l_to_date then
					if l_totdaywtime <= l_deadline_timeleft then
						l_deadline_timeleft := l_deadline_timeleft - l_totdaywtime;
						if l_deadline_timeleft = 0 then
							l_to_date := fn_get_wtime_slot(l_isdefault, l_dayofweek, l_memberid, l_cal_wdate, l_cal_wdate, 0);
							l_loopflag := 0;
--dbms_output.put_line('First1: l_deadline_timeleft = ' || to_char(l_deadline_timeleft));
							exit;
						else
							l_to_date := l_to_date - 1;
						end if;
--dbms_output.put_line('First2: l_deadline_timeleft = ' || to_char(l_deadline_timeleft));
					else
						l_to_date := fn_get_wtime_slot(l_isdefault, l_dayofweek, l_memberid, l_cal_wdate, l_cal_wdate,
													l_totdaywtime - l_deadline_timeleft);
--dbms_output.put_line('First3: l_deadline_timeleft = ' || to_char(l_deadline_timeleft));
						l_loopflag := 0;
						exit;
					end if;
				elsif l_cal_wdate < l_to_date then
					l_today_timeleft := l_totdaywtime - fn_get_wtime_leftover(l_isdefault, l_dayofweek, l_memberid, l_cal_wdate, l_to_date);
--dbms_output.put_line('Second0: l_today_timeleft = ' || to_char(l_today_timeleft));
					if l_today_timeleft < l_deadline_timeleft then
						l_deadline_timeleft := l_deadline_timeleft - l_today_timeleft;
						l_to_date := l_cal_wdate - 1;
--dbms_output.put_line('Second1: l_deadline_timeleft = ' || to_char(l_deadline_timeleft));
					else
						l_to_date := fn_get_wtime_slot(l_isdefault, l_dayofweek, l_memberid, l_cal_wdate, l_cal_wdate,
													l_today_timeleft - l_deadline_timeleft);
						l_loopflag := 0;
--dbms_output.put_line('Second2: l_deadline_timeleft = ' || to_char(l_deadline_timeleft));
						exit;
					end if;
				end if;
			end loop;

			if l_loopflag = 1 then
				close cur_get_working_prev;

				select count(1) into l_tmpcnt from cal
					where caldtime >= l_from_date - l_prefetch_size - 1
						and caldtime <= l_from_date - l_prefetch_size;
				if l_tmpcnt = 0 then
					raise insufficientcal;
				else
--dbms_output.put_line('* cur_get_working_prev(' || TO_CHAR(l_from_date) || ', ' || TO_CHAR(l_from_date + l_prefetch_size) || ')');
					open cur_get_working_prev(l_memberid, l_from_date, l_from_date - l_prefetch_size);
					l_from_date := l_from_date - l_prefetch_size;
				end if;
			else
				exit;
			end if;
		end loop;
	end if;

	if l_tzsign = '-' then
		l_to_date := l_to_date - l_timediff/3600/24 * -1;
	else
		l_to_date := l_to_date - l_timediff/3600/24;
	end if;

	l_dst_diff := fn_get_dst_diff(l_memberid, l_to_date);
	o_to_date := l_to_date + l_dst_diff/3600/24;

exception
	when insufficientcal then
		raise_application_error(-20530, 'Insufficient calendar data.');
	when others then
		o_to_date := i_cur_date;
		if cur_get_working_next%isopen then
			close cur_get_working_next;
		end if;
		if cur_get_working_prev%isopen then
			close cur_get_working_prev;
		end if;
end;
/
