CREATE VIEW VMYPRTCP AS SELECT memberid, type AS membertype, memberid AS prtcp, type AS prtcptype, 'F' AS issurrogater,
		to_date('1900/01/01 00:00:00', 'YYYY/MM/DD HH24:MI:SS') absstartdtime,
		to_date('2100/01/01 00:00:00', 'YYYY/MM/DD HH24:MI:SS') absenddtime
	FROM member
UNION ALL
SELECT m.memberid, m.type AS membertype, absm.memberid AS prtcp, absm.type AS prtcptype, 'T' AS issurrogater,
		absm.absstartdtime, absm.absenddtime
	FROM member m, member absm
		WHERE absm.abssurrogater = m.memberid
			AND m.type = 'U'
			AND absm.isabsent = 'T'
UNION ALL
SELECT m.memberid, m.type AS membertype, m.deptid AS prtcp, 'D' AS prtcptype, 'F' AS issurrogater,
		to_date('1900/01/01 00:00:00', 'YYYY/MM/DD HH24:MI:SS') absstartdtime,
		to_date('2100/01/01 00:00:00', 'YYYY/MM/DD HH24:MI:SS') absenddtime
	FROM member m
		WHERE m.deptid is not null
UNION ALL
SELECT m.memberid, m.type AS membertype, absm.deptid AS prtcp, 'D' AS prtcptype, 'T' AS issurrogater,
		absm.absstartdtime, absm.absenddtime
	FROM member m, member absm
		WHERE absm.abssurrogater = m.memberid
			AND m.type = 'U'
			AND absm.isabsent = 'T'
			AND absm.deptid <> m.deptid
			AND absm.deptid is not null
UNION ALL
SELECT m.memberid, m.type AS membertype, n.memberid, n.type AS prtcptype, 'F' AS issurrogater,
		to_date('1900/01/01 00:00:00', 'YYYY/MM/DD HH24:MI:SS') absstartdtime,
		to_date('2100/01/01 00:00:00', 'YYYY/MM/DD HH24:MI:SS') absenddtime
	FROM member m, usrgrpprtcp u, member n
		WHERE u.prtcp = m.memberid
			AND m.type in ('U', 'D')
			AND n.memberid = u.usrgrpid
			AND n.type in ('G', 'R')
UNION ALL
SELECT m.memberid, m.type AS membertype, n.memberid, n.type AS prtcptype, 'T' AS issurrogater,
		absm.absstartdtime, absm.absenddtime
	FROM member m, member absm, usrgrpprtcp absu, member n
		WHERE absm.abssurrogater = m.memberid
			AND m.type = 'U'
			AND absm.isabsent = 'T'
			AND absu.prtcp = absm.memberid
			AND n.memberid = absu.usrgrpid
			AND n.type in ('G', 'R')
			AND not exists (select u.usrgrpid from usrgrpprtcp u where u.prtcp = m.memberid and u.usrgrpid = absu.usrgrpid)
union
SELECT m.memberid, m.type AS membertype, n.memberid, n.type AS prtcptype, 'F' AS issurrogater,
		to_date('1900/01/01 00:00:00', 'YYYY/MM/DD HH24:MI:SS') absstartdtime,
		to_date('2100/01/01 00:00:00', 'YYYY/MM/DD HH24:MI:SS') absenddtime
	FROM member m, usrgrpprtcp u, member n
		WHERE u.prtcp = m.deptid
			AND m.type = 'U'
			AND n.memberid = u.usrgrpid
			AND n.type in ('G', 'R')
/
