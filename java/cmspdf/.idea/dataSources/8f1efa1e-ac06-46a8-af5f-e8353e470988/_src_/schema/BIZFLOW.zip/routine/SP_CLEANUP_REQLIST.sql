CREATE procedure sp_cleanup_reqlist
   is
--
-- 12.4.0.0
--
begin

	delete from reqlist where reqdtime < getutcdate() - 2/24;
end;
/
