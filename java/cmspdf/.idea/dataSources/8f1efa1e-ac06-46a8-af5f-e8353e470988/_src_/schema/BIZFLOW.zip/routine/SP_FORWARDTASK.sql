CREATE PROCEDURE sp_forwardTask(
 IN_TASKID IN NUMBER,
 IN_SUBTASKID IN NUMBER,
 IN_NEWASSIGNEETYPE IN CHAR,
 IN_NEWASSIGNEE IN VARCHAR2,
 IN_NEWASSIGNEENAME IN VARCHAR2,
 OUT_CNT OUT NUMBER
 ) IS

L_PROCID NUMBER;
L_CNT NUMBER;
L_INITIATOR VARCHAR2(10);
L_INITIATORNAME VARCHAR2(100);
L_PREVIOUSASSIGNEE VARCHAR2(10);
L_PREVIOUSASSIGNEENAME VARCHAR2(100);
L_WBS VARCHAR2(200);
L_AUDIT BOOLEAN := FALSE;
L_HIERARCHYID VARCHAR2(10);

CURSOR cur_subtasks(param_taskid IN NUMBER, param_prtcp IN VARCHAR2, param_wbs VARCHAR2) IS
        SELECT taskid, subtaskid FROM taskprtcp
        WHERE TaskID = param_taskid AND prtcp = param_prtcp
		  AND SubTaskID IN (SELECT SubTaskID FROM SubTasks WHERE WBS like param_wbs || '-%'  AND EndDate is null);
-- 12.4.0.0
BEGIN

    IF (IN_SUBTASKID > 0) THEN
        -- It is for sub task.
        SELECT TaskInitiator, TaskInitiatorName, AssigneeName, Assignee, WBS, ProcID
            INTO L_INITIATOR, L_INITIATORNAME, L_PREVIOUSASSIGNEENAME,  L_PREVIOUSASSIGNEE, L_WBS, L_PROCID
    	FROM SubTasks
    	WHERE TaskID = IN_TASKID AND SubTaskID = IN_SUBTASKID;
    ELSE
        -- It is for main task.
        SELECT TaskInitiator, TaskInitiatorName, TaskInitiatorName, TaskInitiator, TaskID, ProcID
            INTO L_INITIATOR, L_INITIATORNAME, L_PREVIOUSASSIGNEENAME,  L_PREVIOUSASSIGNEE, L_WBS, L_PROCID
    	FROM Tasks
    	WHERE TaskID = IN_TASKID;

	    -- Update Task Initiator

         UPDATE TASKS
           SET taskinitiatortype = IN_NEWASSIGNEETYPE,
               TaskInitiator = IN_NEWASSIGNEE,
               TaskInitiatorName = IN_NEWASSIGNEENAME
    	 WHERE TaskID = IN_TASKID;

    	 UPDATE rlvntdata
		   SET value = '[' || IN_NEWASSIGNEETYPE || ']' || IN_NEWASSIGNEE
		 WHERE procid = L_PROCID
		   AND rlvntdataname = 'initiator';

        -- UPDATE taskprtcp
        SELECT Count(1) INTO L_CNT FROM taskprtcp
        WHERE TaskID = IN_TASKID AND SubTaskID = 0 AND prtcp = IN_NEWASSIGNEE;

        -- This is to prevent Primary key constraint error on taskprtcp table.
        IF (L_CNT = 0) THEN
            UPDATE taskprtcp SET prtcp = IN_NEWASSIGNEE, type = IN_NEWASSIGNEETYPE
        		WHERE TaskID = IN_TASKID AND SubTaskID = 0 AND prtcp = L_PREVIOUSASSIGNEE;
        END IF;

        -- delete junk records
        DELETE FROM taskprtcp
        		WHERE TaskID = IN_TASKID AND SubTaskID = 0 AND prtcp = L_PREVIOUSASSIGNEE;


	    -- Change TaskInitiator with given user for its all subtasks.

    	--UPDATE SubTasks
    	--   SET taskinitiatortype = IN_NEWASSIGNEETYPE,
    	--       TaskInitiator = IN_NEWASSIGNEE,
    	--	   TaskInitiatorName = IN_NEWASSIGNEENAME
    	-- WHERE TASKID = IN_TASKID;

        L_AUDIT := TRUE;
    END IF;

    -- Replace prtcp of the subtask and its child subtasks.

   SELECT Count(1) INTO L_CNT FROM taskprtcp
   WHERE taskid = IN_TASKID AND subtaskid = IN_SUBTASKID AND prtcp = IN_NEWASSIGNEE AND (kind = 'ASSIGNEE' OR kind IS NULL);

   -- This is to prevent Primary key constraint error on taskprtcp table.
   IF (L_CNT = 0) THEN
       UPDATE taskprtcp SET prtcp = IN_NEWASSIGNEE, type = IN_NEWASSIGNEETYPE
            WHERE taskid = IN_TASKID AND subtaskid = IN_SUBTASKID AND prtcp = L_PREVIOUSASSIGNEE AND (kind = 'ASSIGNEE' OR kind IS NULL);
   END IF;

   -- Delete junk records
   DELETE FROM taskprtcp
       WHERE taskid = IN_TASKID AND subtaskid = IN_SUBTASKID AND prtcp = L_PREVIOUSASSIGNEE AND (kind = 'ASSIGNEE' OR kind IS NULL);

    FOR tasks in cur_subtasks(IN_TASKID, L_PREVIOUSASSIGNEE, L_WBS)
    LOOP
        SELECT Count(1) INTO L_CNT FROM taskprtcp
        WHERE taskid = tasks.taskid AND subtaskid = tasks.subtaskid AND prtcp = IN_NEWASSIGNEE AND (kind = 'ASSIGNOR' OR kind IS NULL);

        -- This is to prevent Primary key constraint error on taskprtcp table.
        IF (L_CNT = 0) THEN
            UPDATE taskprtcp SET prtcp = IN_NEWASSIGNEE, type = IN_NEWASSIGNEETYPE
	            WHERE taskid = tasks.taskid AND subtaskid = tasks.subtaskid AND prtcp = L_PREVIOUSASSIGNEE AND (kind = 'ASSIGNOR' OR kind IS NULL);
	        SELECT Count(1) INTO L_CNT FROM taskprtcp
	        WHERE taskid = tasks.taskid AND subtaskid = tasks.subtaskid AND prtcp = IN_NEWASSIGNEE;

	        IF (L_CNT = 0) THEN
			   INSERT INTO taskprtcp(taskid, subtaskid, prtcp, type, kind)
				   VALUES( tasks.taskid, tasks.subtaskid, IN_NEWASSIGNEE, IN_NEWASSIGNEETYPE, 'ASSIGNOR');
	        END IF;
        END IF;

        -- Delete junk records
        DELETE FROM taskprtcp
            WHERE taskid = tasks.taskid AND subtaskid = tasks.subtaskid AND prtcp = L_PREVIOUSASSIGNEE AND (kind = 'ASSIGNOR' OR kind IS NULL);

    END LOOP;

    -- Update Assignee of the subtask and its all child subtasks.

    UPDATE SubTasks
	   SET TaskInitiatorType = IN_NEWASSIGNEETYPE,
	       TaskInitiator =  IN_NEWASSIGNEE,
	       TaskInitiatorName = IN_NEWASSIGNEENAME
	 WHERE TaskInitiator = L_PREVIOUSASSIGNEE
	   AND WBS like L_WBS || '%'
	   AND EndDate is null
	   AND SubTaskID <> IN_SUBTASKID;

	UPDATE SubTasks
	   SET assigneetype = IN_NEWASSIGNEETYPE,
	       Assignee = IN_NEWASSIGNEE,
		   AssigneeName = IN_NEWASSIGNEENAME
	 WHERE Assignee = L_PREVIOUSASSIGNEE
	   AND WBS like L_WBS || '%'
	   AND EndDate is null;

    OUT_CNT := SQL%ROWCOUNT;


    -- If user forwarded on main task, above rowcount might be 0.  In this case, we set it to 1.
    IF (OUT_CNT = 0 AND IN_SUBTASKID = 0) THEN
        OUT_CNT := 1;
    END IF;

	IF (OUT_CNT > 0) THEN

	    IF IN_NEWASSIGNEETYPE = 'G' THEN
            SELECT deptid INTO L_HIERARCHYID FROM member
                 WHERE memberid = IN_NEWASSIGNEE;
        END IF;

	    -- update assignee_ variables.
	    IF IN_NEWASSIGNEETYPE = 'G' THEN
            UPDATE rlvntdata
               SET value= '[' || IN_NEWASSIGNEETYPE || ']' || IN_NEWASSIGNEE || ',O,' || L_HIERARCHYID
             WHERE procid = L_PROCID
               AND rlvntdataname IN (SELECT 'assignee_' || TaskID || '_' || SubTaskID FROM SubTasks WHERE ProcId = L_PROCID AND WBS LIKE L_WBS || '%')
               AND value LIKE '%' || L_PREVIOUSASSIGNEE || '%';
        ELSE
            UPDATE rlvntdata
               SET value= '[' || IN_NEWASSIGNEETYPE || ']' || IN_NEWASSIGNEE
             WHERE procid = L_PROCID
               AND rlvntdataname IN (SELECT 'assignee_' || TaskID || '_' || SubTaskID FROM SubTasks WHERE ProcId = L_PROCID AND WBS LIKE L_WBS || '%')
               AND value LIKE '%' || L_PREVIOUSASSIGNEE || '%';
        END IF;

        -- update reviewer_ variables
        IF IN_NEWASSIGNEETYPE = 'G' THEN
            UPDATE rlvntdata
               SET value= '[' || IN_NEWASSIGNEETYPE || ']' || IN_NEWASSIGNEE || ',O,' || L_HIERARCHYID
             WHERE procid = L_PROCID
               AND rlvntdataname IN (SELECT 'reviewer_' || TaskID || '_' || SubTaskID FROM SubTasks WHERE ProcId = L_PROCID AND WBS LIKE L_WBS || '%')
               AND value LIKE '%' || L_PREVIOUSASSIGNEE || '%'
               AND rlvntdataname <> ('reviewer_' || IN_TASKID || '_' || IN_SUBTASKID);
        ELSE
            UPDATE rlvntdata
               SET value= '[' || IN_NEWASSIGNEETYPE || ']' || IN_NEWASSIGNEE
             WHERE procid = L_PROCID
               AND rlvntdataname IN (SELECT 'reviewer_' || TaskID || '_' || SubTaskID FROM SubTasks WHERE ProcId = L_PROCID AND WBS LIKE L_WBS || '%')
               AND value LIKE '%' || L_PREVIOUSASSIGNEE || '%'
               AND rlvntdataname <> ('reviewer_' || IN_TASKID || '_' || IN_SUBTASKID);
        END IF;

		-- update participant of those running workitem
		-- assignee activity
		UPDATE witem SET prtcptype = IN_NEWASSIGNEETYPE,
		                 prtcp = IN_NEWASSIGNEE,
		                 prtcpname = IN_NEWASSIGNEENAME,
		                 checkoutusr = null
        WHERE procid = L_PROCID
              AND prtcp = L_PREVIOUSASSIGNEE
              AND witemseq IN
                (
                    SELECT w.witemseq FROM witem w, SubTasks s
                    WHERE w.procid = s.procid AND w.actseq = s.actseq
                    AND w.state IN ('I','R','V','P')
                    AND w.procid = L_PROCID AND s.WBS LIKE L_WBS || '%'
                );
        -- reviewer activity
		UPDATE witem SET prtcptype = IN_NEWASSIGNEETYPE,
		                 prtcp = IN_NEWASSIGNEE,
		                 prtcpname = IN_NEWASSIGNEENAME,
		                 checkoutusr = null
        WHERE procid = L_PROCID
              AND prtcp = L_PREVIOUSASSIGNEE
              AND witemseq IN
                (
                    SELECT w.witemseq FROM witem w, SubTasks s
                    WHERE w.procid = s.procid AND (s.ExternalUSER IS NULL AND w.actseq = s.actseq + 1)
                    AND w.state IN ('I','R','V','P')
                    AND w.procid = L_PROCID AND s.WBS LIKE L_WBS || '%'
                    AND s.SubTaskID <> IN_SUBTASKID
                );

        L_AUDIT := TRUE;
	END IF;

    IF L_AUDIT THEN
		INSERT INTO DTaskerAudit (TaskID, SubTaskID, Seq, FromName, ToName, FromID, ToID, CreationDT, ValueType, Value)
				VALUES (IN_TASKID, IN_SUBTASKID, hws_dtaskeraudit.nextval, L_INITIATORNAME, IN_NEWASSIGNEENAME, L_INITIATOR, IN_NEWASSIGNEE,
						sys_extract_utc(current_timestamp), 'Forward', 'From ' || L_PREVIOUSASSIGNEENAME || ' To ' || IN_NEWASSIGNEENAME);
    END IF;
END;
/
