CREATE VIEW VUSRGRPPRTCP AS SELECT m.deptid AS usrgrpid, m.deptname AS usrgrpname, 'D' AS usrgrptype,
	   m.memberid AS prtcp, m.type AS prtcptype, m.state AS prtcpstate, m.disporder,
	   m.isabsent, m.deptid, m.deptname, m.jobtitlename, m.name AS username,
	   m.absstartdtime, m.absenddtime, m.absmsg, m.abssurrogater, m2.name AS abssurrogatername
  FROM member m left outer join member m2 on m.abssurrogater = m2.memberid
 WHERE m.type = 'U'
 UNION ALL
SELECT u.usrgrpid, g.name AS usrgrpname, g.type AS usrgrptype,
	   u.prtcp, u.prtcptype, m.state AS prtcpstate, u.disporder,
	   m.isabsent, m.deptid, m.deptname, m.jobtitlename, m.name AS username,
	   m.absstartdtime, m.absenddtime, m.absmsg, m.abssurrogater, m2.name AS abssurrogatername
  FROM usrgrpprtcp u
       inner join member m on u.prtcp = m.memberid
	   inner join member g on u.usrgrpid = g.memberid
	   left outer join member m2 on m.abssurrogater = m2.memberid
/
