CREATE FUNCTION fn_get_accbusdaysdiff(i_procid IN int, i_actname IN varchar)
  RETURN INT
IS
  L_EVENT CHAR(1);
  L_EXECDTIME DATE;
  L_END DATE;
  L_FOUND_COMPLETED_DATE CHAR(1);
  L_DAYDIFF INT;
  L_DAYDIFF_TOTAL INT;

  CURSOR auditinfo_cursor IS
    select event, execdtime from AUDITINFO
    where objname = i_actname
          and event in ('R', 'C')
          and objtype = 'A'
          and procid = i_procid
    order by EXECSEQ desc;
  BEGIN
    L_FOUND_COMPLETED_DATE := 'N';
    L_DAYDIFF := 0;
    L_DAYDIFF_TOTAL := 0;

    OPEN auditinfo_cursor;

    LOOP
      FETCH auditinfo_cursor INTO L_EVENT, L_EXECDTIME;
      EXIT WHEN auditinfo_cursor%NOTFOUND;

      if (L_EVENT = 'R' and L_FOUND_COMPLETED_DATE = 'Y') THEN
        select FN_GET_BUSDAYSDIFF(L_EXECDTIME, L_END) into L_DAYDIFF from dual;
        L_DAYDIFF_TOTAL := L_DAYDIFF_TOTAL + L_DAYDIFF;
        L_FOUND_COMPLETED_DATE := 'N';
      ELSIF (L_EVENT = 'C') THEN
        L_FOUND_COMPLETED_DATE := 'Y';
        L_END := L_EXECDTIME;
      END IF;

    END LOOP;

    CLOSE auditinfo_cursor;

    RETURN L_DAYDIFF_TOTAL;
  END;
/
