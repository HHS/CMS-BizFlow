CREATE procedure sp_set_witemapp_pkitype
   (
	 i_svrid	in varchar2,
	 i_procid	in number,
	 i_mapid	in number,
	 i_pkitype	in char)
   is
--
-- 12.4.0.0
--

cursor cur_get_witemapp_for_pkitype (l_mapid number) is
	select witemseq, witemappseq
	from witemapp
	where svrid = i_svrid
		and procid = i_procid
		and mapid = i_mapid order by witemseq, witemappseq;

l_witemseq		number;
l_witemappseq	number;

begin

	open cur_get_witemapp_for_pkitype(i_svrid);
	loop
		fetch cur_get_witemapp_for_pkitype into l_witemseq, l_witemappseq;
		exit when cur_get_witemapp_for_pkitype%notfound;

		update witemapp set pkitype = i_pkitype
			where svrid = i_svrid
				and procid = i_procid
				and witemseq = l_witemseq
				and witemappseq = l_witemappseq;
	end loop;
	close cur_get_witemapp_for_pkitype;

exception
    when others then
        if cur_get_witemapp_for_pkitype%isopen then
            close cur_get_witemapp_for_pkitype;
        end if;
		raise_application_error(-20720, sqlerrm);
end; -- procedure
/
