CREATE VIEW VACTPRTCP AS SELECT
	p.procid, p.actseq, p.prtcpseq, p.svrid, p.kind, p.type, p.useflag, p.assignrule,
	p.existscriptfile, p.prtcpauth, p.prtcp, p.disporder, p.usrgrphid, p.mapid,
	p.jobtitlename, p.deptname, p.expr, p.prtcpname, p.calmemberid
		FROM prtcp p, member m
			WHERE p.type = 'U'
				and p.usrgrphid is null
				and m.memberid = p.prtcp
				and m.state in ('N', 'L')
UNION ALL
SELECT
	p.procid, p.actseq, p.prtcpseq, p.svrid, p.kind, p.type, p.useflag, p.assignrule,
	p.existscriptfile, p.prtcpauth, p.prtcp, p.disporder, p.usrgrphid, p.mapid,
	p.jobtitlename, p.deptname, p.expr, p.prtcpname, p.calmemberid
		FROM prtcp p, member m, member ugh
			WHERE p.type = 'U'
				and p.usrgrphid is not null
				and m.memberid = p.prtcp
				and m.state in ('N', 'L')
				and ugh.memberid = p.usrgrphid
				and ugh.state = 'A'
UNION ALL
SELECT
	p.procid, p.actseq, p.prtcpseq, p.svrid, p.kind, p.type, p.useflag, p.assignrule,
	p.existscriptfile, p.prtcpauth, p.prtcp, p.disporder, p.usrgrphid, p.mapid,
	p.jobtitlename, p.deptname, p.expr, p.prtcpname, p.calmemberid
		FROM prtcp p
			WHERE p.type <> 'U'
				and p.usrgrphid is null
UNION ALL
SELECT
	p.procid, p.actseq, p.prtcpseq, p.svrid, p.kind, p.type, p.useflag, p.assignrule,
	p.existscriptfile, p.prtcpauth, p.prtcp, p.disporder, p.usrgrphid, p.mapid,
	p.jobtitlename, p.deptname, p.expr, p.prtcpname, p.calmemberid
		FROM prtcp p, member ugh
			WHERE p.type <> 'U'
				and p.usrgrphid is not null
				and ugh.memberid = p.usrgrphid
				and ugh.state = 'A'
/
