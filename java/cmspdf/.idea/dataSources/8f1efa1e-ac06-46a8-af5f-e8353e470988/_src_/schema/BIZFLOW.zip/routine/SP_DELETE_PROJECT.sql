CREATE procedure                  sp_delete_project
(
	i_svrid			in	fldrlist.svrid%type default null,
	i_projectid		in	fldrlist.fldrid%type default null
)
IS
--
-- 12.4.0.0
--
cursor cur_get_folder_for_delete (l_svrid varchar2, l_projectid number) is
	select fldrid
	from fldrlist
	where svrid = l_svrid
		and prjid = l_projectid
		order by fldrpath desc;
l_folderid		number;

BEGIN
	-- clear publish folder id
	update procdef set prjfldrid = 0
	where prjfldrid in ( select fldrid from fldrlist where prjid = i_projectid );

	update apptmplt set prjfldrid = 0
	where prjfldrid in ( select fldrid from fldrlist where prjid = i_projectid );

	-- delete the project role member
	delete from usrgrpprtcp
	where usrgrpid in ( select memberid from member where deptid = i_projectid );

	delete from usrgrpprtcp
	where prtcp in ( select memberid from member where deptid = i_projectid );

	-- delete the project folder member
	delete from fldrmemberlist
	where fldrid in ( select fldrid from fldrlist where prjid = i_projectid );

	-- delete the project folder manager
	delete from fldrmanagerlist
	where fldrid in ( select fldrid from fldrlist where prjid = i_projectid );

	-- delete the project role
	delete from member
	where deptid = i_projectid;

	-- delete the project folder
	open cur_get_folder_for_delete(i_svrid, i_projectid);
	loop
		fetch cur_get_folder_for_delete into l_folderid;
		exit when cur_get_folder_for_delete%notfound;

		delete from fldrlist
		where fldrid = l_folderid;
	end loop;
	close cur_get_folder_for_delete;

exception
    when others then
        raise_application_error(-20744, sqlerrm);
end;
/
