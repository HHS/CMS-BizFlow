CREATE TRIGGER TRANS_BUR
BEFORE UPDATE OF STATE
  ON TRANS
FOR EACH ROW
  BEGIN
    IF :new.state = 'C' or :new.state = 'D' THEN
		:new.modifydtime := getutcdate();
    END IF;
END;
/
