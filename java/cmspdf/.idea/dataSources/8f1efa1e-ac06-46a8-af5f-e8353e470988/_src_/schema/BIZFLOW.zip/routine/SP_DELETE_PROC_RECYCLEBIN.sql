CREATE procedure          sp_delete_proc_recyclebin
   (
     i_svrid in varchar2,
     i_procid in number)
   is
--
-- 12.4.0.0
--

cursor cur_get_witem_for_delete (l_svrid varchar2, l_procid number) is
	select state, witemseq
	from witem
	where svrid = l_svrid
		and procid = l_procid
		order by witemseq;

l_state			char;
l_witemseq		number;

begin

	open cur_get_witem_for_delete(i_svrid, i_procid);
	loop
		fetch cur_get_witem_for_delete into l_state, l_witemseq;
		exit when cur_get_witem_for_delete%notfound;

		if l_state = 'I' then
			l_state := '1';
		elsif l_state = 'R' then
			l_state := '2';
		elsif l_state = 'V' then
			l_state := '3';
		elsif l_state = 'C' then
			l_state := '4';
		elsif l_state = 'E' then
			l_state := '5';
		elsif l_state = 'A' then
			l_state := '6';
		elsif l_state = 'T' then
			l_state := '7';
		elsif l_state = 'S' then
			l_state := '8';
		elsif l_state = 'P' then
			l_state := '9';
		elsif l_state = 'D' then
			l_state := '+';
		elsif l_state = 'W' then
			l_state := '-';
		elsif l_state = 'Y' then
			l_state := '*';
		end if;

		update witem set state = l_state
			where svrid = i_svrid
				and procid = i_procid
				and witemseq = l_witemseq;

	end loop;
	close cur_get_witem_for_delete;

	select state into l_state from procs
		where svrid = i_svrid and procid = i_procid;

	if l_state = 'N' then
		l_state := '0';
	elsif l_state = 'R' then
		l_state := '1';
	elsif l_state = 'E' then
		l_state := '2';
	elsif l_state = 'V' then
		l_state := '3';
	elsif l_state = 'S' then
		l_state := '4';
	elsif l_state = 'A' then
		l_state := '5';
	elsif l_state = 'T' then
		l_state := '6';
	elsif l_state = 'C' then
		l_state := '7';
	elsif l_state = 'D' then
		l_state := '8';
	elsif l_state = 'J' then
		l_state := '9';
	end if;

	update procs set state = l_state where svrid = i_svrid and procid = i_procid;
exception
    when others then
        raise_application_error(-20724, sqlerrm);
        if cur_get_witem_for_delete%isopen then
            close cur_get_witem_for_delete;
        end if;
end; -- procedure
/
