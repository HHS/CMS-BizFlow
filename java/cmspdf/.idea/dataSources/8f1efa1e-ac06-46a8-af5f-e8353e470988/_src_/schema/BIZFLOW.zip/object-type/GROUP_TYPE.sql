CREATE TYPE group_type IS OBJECT
(
    memberid VARCHAR2(10)
);
/
